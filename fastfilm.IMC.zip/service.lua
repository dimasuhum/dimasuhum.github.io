-- fast-film plugin

require('support')
require('video')
require('parser')

--HOME = 'http://www.fast-film.ru'
HOME = 'http://www.fast-fiml.ru'


HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/page=3
	-- #stream/page=4
	-- #stream/page=5
	-- #stream/page=6
	-- #stream/page=7
	-- #stream/page=8
	-- #stream/page=9
	-- #stream/page=10
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/new/all/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. tostring(page) .. '.html'
		end
		local x = http.getz(url)
        
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
     --   for title, url, image in string.gmatch(x, '<div class="film%-wrap".-alt="(.-)".-<a href="(.-)".-style="background:.-(http.-jpg)') do
       
       
    	for url, image, title, total in string.gmatch(x, '<div class="film%-wrap".-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)</span>(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
       --   table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
			table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
        
		
          for url, title in string.gmatch(x, '<div class=.-float_right collection%-profile.-nav%-icon generic_favorit_controll email%-off.-collection%-item%-head.-<a href=.-(/favorite/public.-)\'.-<big>(.-)<') do
         t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
  
  

--<div class=item_main_box2.-class="quality_type">(.-)<.-<a href=.-(/film/.-html).-background:.-(http.-jpg)

        for url, image, title  in string.gmatch(x, '<div class=\'item_main_box2\'.-<a href=.-(/film/.-html).-background:.-(http.-jpg).-class=\'use_tooltip item_title\'title=\'(.-)\'') do
        
       url = string.gsub(url, '^(.-)', HOME)
    --   title = string.gsub(title, ''', '')
    --    t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
	--	end
	
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       table.insert(t, {title = 'КОЛЛЕКЦИИ', mrl = '#stream/genre=' .. '/favorite/public/'})
		
--http://www.fast-fiml.ru/favorite/public/
     	local x = http.getz(HOME .. '/new-torrent/')
        
		local x = string.match(x, '<div id="leftmenu".->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-/).->(.-)</a>') do
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
    	local x = http.getz(HOME .. '/last-tv-torrent/')
        
		local x = string.match(x, '<div id="leftmenu".->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-tv/).->(.-)</a>') do
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		local x = http.getz(HOME .. '/last-multfilm-torrent/')
        
		local x = string.match(x, '<div id="leftmenu".->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-multfilm/).->(.-)</a>') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
--http://www.fast-fiml.ru/new-torrent/
--http://www.fast-fiml.ru/last-tv-torrent/
--http://www.fast-fiml.ru/last-multfilm-torrent/
		 table.insert(t, {title = 'Фильмы: HD 2160р', mrl = '#stream/genre=' .. '/video/tag/hd-2160r/'})
         table.insert(t, {title = 'Фильмы: HD 1080', mrl = '#stream/genre=' .. '/video/tag/hdtv-1080i/'})
		 table.insert(t, {title = 'Фильмы: HD 720', mrl = '#stream/genre=' .. '/video/tag/hdtv-720p/'})
         table.insert(t, {title = 'Фильмы: 3D', mrl = '#stream/genre=' .. '/video/tag/3d/'})

         table.insert(t, {title = 'Сериалы: HD 2160р', mrl = '#stream/genre=' .. '/tv/tag/hd-2160r/'})
         table.insert(t, {title = 'Сериалы: HD 1080', mrl = '#stream/genre=' .. '/tv/tag/hdtv-1080i/'})
		 table.insert(t, {title = 'Сериалы: HD 720', mrl = '#stream/genre=' .. '/tv/tag/hdtv-720p/'})
         table.insert(t, {title = 'Сериалы: 3D', mrl = '#stream/genre=' .. '/tv/tag/3d/'})		 

         table.insert(t, {title = 'Мультфильмы: HD 2160р', mrl = '#stream/genre=' .. '/multfilm/tag/hd-2160r/'})
         table.insert(t, {title = 'Мультфильмы: HD 1080', mrl = '#stream/genre=' .. '/multfilm/tag/hdtv-1080i/'})
		 table.insert(t, {title = 'Мультфильмы: HD 720', mrl = '#stream/genre=' .. '/multfilm/tag/hdtv-720p/'})
         table.insert(t, {title = 'Мультфильмы: 3D', mrl = '#stream/genre=' .. '/multfilm/tag/3d/'})		 

          table.insert(t, {title = 'Документальные: HD 2160р', mrl = '#stream/genre=' .. '/documentary/tag/hd-2160r/'})
         table.insert(t, {title = 'Документальные: HD 1080', mrl = '#stream/genre=' .. '/documentary/tag/hdtv-1080i/'})
		 table.insert(t, {title = 'Документальные: HD 720', mrl = '#stream/genre=' .. '/documentary/tag/hdtv-720p/'})
         table.insert(t, {title = 'Документальные: 3D', mrl = '#stream/genre=' .. '/documentary/tag/3d/'})




--<a href="/all/tag/be-continued/  <li class='more'><a href="/tags/   

        local x = http.getz(HOME .. '/new/all/')
        
	--	local x = string.match(x, '<em class="nav%-icon nav%-tag_blue.->(.-)<.-Еще Теги')
		
		for genre, title in string.gmatch(x, '<a href=.-(/all/tag/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end

          local x = http.getz(HOME .. '/tags/all/')
        
	--	local x = string.match(x, '<div class="ui%-widget ui%-widget%-content".->(.-)</ul>')
		
		for genre, image, title in string.gmatch(x, '<div class="item_tag".-<a href=.-(/all/tag/.-/).-background%-image:.-(http.-jpg).-</div>(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end

--http://www.fast-torrent.ru/search/{searchTerms}/1.html


        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = 'http://www.fast-torrent.ru/search/' .. urlencode(args.keyword) .. '/' .. tostring(page) .. '.html'

		
		local x = http.getz(url)
		
        for url, image, title, total in string.gmatch(x, '<div class="film%-wrap".-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)</span>(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
       --   table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
			table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '/' ..  tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
		

	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<meta itemprop="description" content="(.-)"')
    --    t['poster'] = args.p
		t['poster'] = parse_match(x,'var test_image.-(http.-jpg)')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Жанр</strong>:.-)</p>' ,'(Режиссер</strong>:.-)</p>' ,'(В ролях</strong>:.-)</p>' , 
		})
		
		
         



         for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
         print(url)
		 url = string.gsub(url, '^(.-)', 'http://divantv.zz.mu/kinomovie/zombie.m3u.php?kp_id=')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
		
         for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
         print(url)
		 url = string.gsub(url, '^(.-)', 'https://voidboost.net/embed/')
    
       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end



        for url in string.gmatch(x, '\'file\':.-#2(.-)\'') do
         url = string.gsub(url, '\\/\\/_\\/\\/', '')
         url = string.gsub(url, 'Xl5eXl5eIyNA', '')
         url = string.gsub(url, 'QCMhQEBAIyMkJEBA', '')
         url = string.gsub(url, 'Xl4jQEAhIUAjISQ=', '')
         url = string.gsub(url,'JCQkIyMjIyEhISEhISE=', '')
         url = string.gsub(url,'QCFeXiFAI0BAJCQkJCQ=', '')

         url=http.urldecode(base64_decode(url))
         
        if url then
			for title, url in string.gmatch(url, '(240p)].-or (http.-mp4),') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
		if url then
			for title, url in string.gmatch(url, '(360p)].-or (http.-mp4),') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if url then
			for title, url in string.gmatch(url, '(480p)].-or (http.-mp4),') do
             t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(720p)].-or (http.-mp4),') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p)].-or (http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
				
			end
		end	
		if url then
			for url, title in string.gmatch(x, '<option data%-token="(.-)" data%-d=.-value.->.->(.-)</option>') do
		url = string.gsub(url, '^(.-)', 'https://voidboost.net/movie/') .. '/iframe'		
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
				
			end
		end
		end
		
		
		
		
    --	if url then


			for url1 in string.gmatch(x, '<option value=".-">Сезон (.-)</option>') do
        --    url1 = string.gsub(url1, '^(.-)', '/iframe?s=')
       
       
       
            for url2 in string.gmatch(x, '<option value=".-">Серия (.-)</option>') do
        --    url2 = string.gsub(url2, '^(.-)', '&e=')
         for url3, title in string.gmatch(x, '<option data%-token="(.-)".->(.-)</option>') do
        url3 = string.gsub(url3, '^(.-)', 'https://voidboost.net/serial/')		
        
        
	--	url = string.gsub(url, '^(.-)', 'https://voidboost.net/serial/' .. url2 .. '/' .. '/iframe?' .. 's=') .. '&e=' .. url1		
			table.insert(t, {title = tolazy(title) .. ' | ' .. 'Сезон' .. url1 .. ' | ' .. 'Серия' .. url2, mrl = '#stream/q=content&id=' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
		--	table.insert(t, {title = url3 .. url1 .. url2, mrl = '#stream/q=content&id=' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})	
			end
			end
			end
		
     --    end
      --   end
--local url = string.match(url, '<select name="episode".->(.-)</select>

  --https://voidboost.net/serial/898fab5168c5debbc3c1784ddf2df0a2/iframe?s=1&e=1&h=gidonline.io
    --    local x = string.match(x, '<select name="translator".-Перевод.->(.-)</select>')
		
	--	for url, title in string.gmatch(x, '<option data%-token="(.-)".->(.-)</option>') do
	--	url = string.gsub(url, '^(.-)', 'https://voidboost.net/movie/') .. '/iframe'		
	--	?h=gidonline.io'
--https://voidboost.net/movie/4e0dd6021dc6bdc254cc7becdff1627c/iframe?h=gidonline.io
	--		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
	--	end
     





		
		
    --	local x = string.match(x, '<p itemprop="description.->(.-)</table>')
		
		for url, title in string.gmatch(x, '<br><a href=.-(/film/.-html).->(.-)</a>') do
           url = string.gsub(url, '^(.-)', HOME)
		
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end	

         for url, title in string.gmatch(x, '<strong><a href=.-(/film/.-html).->(.-)</a>') do
           url = string.gsub(url, '^(.-)', HOME)
		
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end	



        for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end
   
         for title, url, total in string.gmatch(x, '<em class="directors_cut".-class=\'c3.->(.-)<.-Файл:.-<a href="(/download.-torrent)".->(.-).torrent') do
		
         print(url)
		 url = string.gsub(url, '^(.-)', HOME)

         table.insert(t, {title = title .. '|' .. (total), mrl = url})

			
		end
  
  

  
  

   
   
      
         for title, url, total in string.gmatch(x, '<em class="directors_cut".-class=\'c3.->(.-)<.-Файл:.-<a href="(/download.-torrent)".->(.-).torrent') do
		
         print(url)
		 url = string.gsub(url, '^(.-)', HOME)

         table.insert(t, {title = title .. '|' .. (total), mrl = url})

			
		end
   
   

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end