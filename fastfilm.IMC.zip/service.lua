-- fast-film plugin


require('support')
--require('video')
--require('parser')
require('client')
require('fxml')

local video = require('video')
local parser = require('parser')

local json = require('json')

local fxml = onCreate







--CDATA[http://stvplay.mooo.com:81/torrents/tmdb/tmdb.php?link=https://bitru.org/download.php?id=639863&path=&file=Особо

--https://bitru.org/browse.php?s=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9(1979)

--http://stvplay.mooo.com:81/torrents/tmdb/tmdb.php?find=%D0%9E%D1%81%D0%BE%D0%B1%D0%BE%20%D0%BE%D0%BF%D0%B0%D1%81%D0%BD%D1%8B%D0%B9%20%D0%BF%D0%B0%D1%81%D1%81%D0%B0%D0%B6%D0%B8%D1%80

--https://findmagnet.org/?q=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9

--https://www.magicsearch.net/search/%D0%A7%D1%83%D0%B6%D0%BE%D0%B9%201979/

--https://www.magicsearch.net/api/json_info?hashes=11487944


--local REPO1 = 'http://xplay.bz/'

--local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


--http://fast-torrent.club/toggle_info/ti_386060

--http://fast-torrent.club/download/torrent/428804/%D0%9E%D0%BF%D0%BF%D0%B5%D0%BD%D0%B3%D0%B5%D0%B9%D0%BC%D0%B5%D1%80%20-%20Oppenheimer%20(2023)%20HDRip%20%7C%20LineFilm%20%7C%20IMAX.torrent


--local HOME = 'http://fast-fiml.ru'
--local HOME = 'http://fast-torrent.ru'
local HOME = 'http://fast-torrent.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




local conn1 = client.new()
conn1['encoding'] = 'windows-1251'
conn1['root'] = HOME_SLASH

--HOME = 'http://www.fast-film.ru'
--HOME = 'http://www.fast-fiml.ru'


--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

-- #self/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/
-- #stream/url=http://xplay.bz/
-- #stream/url=http://staticdata.appinfo.su/staticfiles/fimg/open.png
-- #stream/url=http://xplay.bz/list
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka%2Flist%3Fcat%3Dfilms
-- #stream/url=http://imboom.ru/?ma=playlist
-- #stream/url=http://imboom.ru/?ma=imboomiptv
-- #stream/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/list



	
	-- #stream/page=2
	-- #stream/page=3
	-- #stream/page=4
	-- #stream/page=5
	-- #stream/page=6
	-- #stream/page=7
	-- #stream/page=8
	-- #stream/page=9
	-- #stream/page=10
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/new/all/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. tostring(page) .. '.html'
		end
	--	local x = http.getz(url)
        local x = conn:load(url)

      -- for title, url, image in string.gmatch(x, '<div class=film%-wrap".-alt="(.-)".-<a href="(.-)".-style="background:.-(http.-jpg)') do
       
       
  	for url, image, title in string.gmatch(x, '<div class=.-film%-wrap.-href=.-(/.-html).-itemprop="image" content="(.-)".-itemprop="name">(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		--	table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
        
		
          for url, title in string.gmatch(x, '<div class=.-float_right collection%-profile.-nav%-icon generic_favorit_controll email%-off.-collection%-item%-head.-<a href=.-(/favorite/public.-)\'.-<big>(.-)<') do
         t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
  
  
  
    --  for title, url, image   in string.gmatch(x, '<div class="film%-wrap".-alt="(.-)".-<a href="(.-)".-itemprop="image" content="(.-)"') do
        
      -- url = string.gsub(url, '^(.-)', HOME)

	--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
	--	end
  
  
  
 -- for title, url, image in string.gmatch(x,'<div class=.-film%-image.-alt="(.-)".-<a href="(.-)".-itemprop="image" content="(.-)"') do 
 -- url = string.gsub(url, '^(.-)', HOME)
    --   title = string.gsub(title, ''', '')
    --    t['view'] = 'simple'
--		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
	--	end
		

--<div class=item_main_box2.-class="quality_type">(.-)<.-<a href=.-(/film/.-html).-background:.-(http.-jpg)

        for url, image, title  in string.gmatch(x, '<div class=\'item_main_box2\'.-<a href=.-(/film/.-html).-background:.-(http.-jpg).-class=\'use_tooltip item_title\'title=\'(.-)\'') do
        
       url = string.gsub(url, '^(.-)', HOME)
    --   title = string.gsub(title, ''', '')
    --    t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
	--	end
	
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       table.insert(t, {title = 'КОЛЛЕКЦИИ', mrl = '#stream/genre=' .. '/favorite/public/'})
    	table.insert(t, {title = 'Новые коллекции', mrl = '#stream/genre=' .. '/favorite/public/?order=1'})

     table.insert(t, {title = 'Самые большие коллекции', mrl = '#stream/genre=' .. '/favorite/public/?order=2'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=6'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=3'})
	
	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=4'})
	
--http://www.fast-fiml.ru/last-tv-torrent/

 table.insert(t, {title = 'Коллекции blumhouse', mrl = '#stream/genre=' .. '/company/blumhouse-productions/'})
 
-- http://fast-torrent.club/company/blumhouse-productions/

 table.insert(t, {title = 'Коллекции 20th-century-fox', mrl = '#stream/genre=' .. '/company/20th-century-fox/'})
 
-- http://fast-torrent.club/company/20th-century-fox/
 
table.insert(t, {title = 'Коллекции netflix', mrl = '#stream/genre=' .. '/company/netflix/'})




--http://fast-torrent.club/company/netflix/




table.insert(t, {title = 'Коллекции new-line-cinema', mrl = '#stream/genre=' .. '/company/new-line-cinema/'})


 --http://fast-torrent.club/company/new-line-cinema/
 
 table.insert(t, {title = 'Коллекции walt-disney-pictures', mrl = '#stream/genre=' .. '/company/walt-disney-pictures/'})
 
 
--http://fast-torrent.club/company/walt-disney-pictures/

 
 table.insert(t, {title = 'Коллекции universal-television', mrl = '#stream/genre=' .. '/company/universal-television/'})
 
-- http://fast-torrent.club/company/universal-television/

table.insert(t, {title = 'Коллекции columbia-pictures', mrl = '#stream/genre=' .. '/company/columbia-pictures/'})

 
 --http://fast-torrent.club/company/columbia-pictures/

table.insert(t, {title = 'Коллекции warner-bros', mrl = '#stream/genre=' .. '/company/warner-bros/'})

 
-- http://fast-torrent.club/company/warner-bros/
 

table.insert(t, {title = 'Коллекции dreamworks', mrl = '#stream/genre=' .. '/company/dreamworks/'})

 
     	local x = conn:load(HOME .. '/new-torrent/')
   
        
		local x = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-/).->(.-)</a>') do
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
    	local x = conn:load(HOME .. '/last-tv-torrent/')
        
		local x = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
	
   --     for genre, title in string.gmatch(x, '<a href="(.-tv/).->(.-)</a>') do
	
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-tv/).->(.-)</a>') do
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		local x = conn:load(HOME .. '/last-multfilm-torrent/')
        
		local x = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-/).->(.-)</a>') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
--http://www.fast-fiml.ru/new-torrent/
--http://www.fast-fiml.ru/last-tv-torrent/
--http://www.fast-fiml.ru/last-multfilm-torrent/




--<a href="/all/tag/be-continued/  <li class='more'><a href="/tags/   

        local x = conn:load(HOME .. '/new/all/')
        
	--	local x = string.match(x, '<em class="nav%-icon nav%-tag_blue.->(.-)<.-Еще Теги')
		
		for genre, title in string.gmatch(x, '<a href=.-(/all/tag/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end

          local x = conn:load(HOME .. '/tags/all/')
        
	--	local x = string.match(x, '<div class="ui%-widget ui%-widget%-content".->(.-)</ul>')
		
		for genre, image, title in string.gmatch(x, '<div class="item_tag".-<a href=.-(/all/tag/.-/).-background%-image:.-(http.-jpg).-</div>(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end

--http://www.fast-torrent.ru/search/{searchTerms}/1.html


        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = 'http://www.fast-torrent.ru/search/' .. urlencode(args.keyword) .. '/' .. tostring(page) .. '.html'

		
		local x = conn:load(url)
		
        for url, image, title, total in string.gmatch(x, '<div class="film%-wrap".-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)</span>(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
       --   table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
			table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '/' ..  tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
		
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?id=106291&kinopoisk_id=1355296
	
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?kinopoisk_id=1355296&title=&original_title=&s=1
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<meta itemprop="description" content="(.-)"')
        t['poster'] = args.p
	--	t['poster'] = parse_match(x,'var test_image.-(http.-jpg)')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Жанр</strong>:.-)</p>' ,'(Режиссер</strong>:.-)</p>' ,'(В ролях</strong>:.-)</p>' , 
		})


--http://stvplay.mooo.com:81/torrents/rutor.php?search=%D0%B1%D1%83%D0%BC%D0%B0%D0%B6%D0%BD%D1%8B%D0%B9%20%D0%B4%D0%BE%D0%BC

--http://stvplay.mooo.com:81/torrents/rutor.php?fid=1019382

      
--https://torrs.ru/search?query=чужой (1979)

--https://yandex.ru/search/touch/?text=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9(1979)&lr=


--http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=4443920&box_mac=acace24b8434
    
   -- for title3 in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
 
 
 
 
     
 
 
 
 
 
    for title3 in string.gmatch(x, 'http.-rating.kinopoisk.-/(.-).gif') do

   url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
     
  --   table.insert(t, {title = url1, mrl = url1})
     
      local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end
end




  --   for title3, title, title1 in string.gmatch(x, 'var kinopoisk_id.-= (.-);.-<h1.-span.->(.-)<.-%((.-)%)') do


--end



for title3 in string.gmatch(x, 'http.-rating.kinopoisk.-/(.-).gif') do
 
   url1 = string.gsub(title3, '^(.-)', 'http://93.183.92.183:9118/lite/mirage?kinopoisk_id=') .. '&uid=m7alois3'
    
--http://147.45.77.28:9118/lite/mirage?kinopoisk_id=386&uid=m7alois3
 
   table.insert(t, {title = 'Mirage', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
 --       end
 --   local x = conn:load(url1)
     
     for  url2, url3,  total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
  
      url3 = string.gsub(url3, '\\u0026', '&')

    
       local x = conn:load(url2 .. url3)
    
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
    
       url4 = string.gsub(url4, '^(.-)', 'http://93.183.92.183:9118')
    
      t['view'] = 'simple'

    table.insert(t, {title = tolazy(total2) .. '(' .. tolazy(total3) .. ')', mrl = url4})

      end 
      end
     
  

      
       for url2, total  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
       url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       
     url2 = string.gsub(url2, '\\u0026', '&')
     
   --  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)


      for url3, url4, total1, total2  in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-voice_name":"(.-)".-class="videos__item%-title">(.-серия)</div>') do

       url3 = string.gsub(url3, '^(.-)', 'http://93.183.92.183:9118')
       
     url4 = string.gsub(url4, '\\u0026', '&')
      local x = conn:load(url3 .. url4)
     local x = string.match(x, '"quality"(.-)}')
      for  total3, url5 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
   
     url5 = string.gsub(url5, '^(.-)', 'http://93.183.92.183:9118')
    
       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total2) .. '(' .. total3 .. ')' .. '(' .. total1 .. ')', mrl = url5})

    end
end
end
 
 --end


       for title3, title, title1 in string.gmatch(x, 'var kinopoisk_id.-= (.-);.-<h1.-span.->(.-)<.-%((.-)%)') do

      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
       url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 
    table.insert(t, {title = 'Hdvb(v2)', mrl = '#stream/q=content&id=' .. url1, image = image})
        end

       for  url2, url3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   --   local x = conn:load(url2 .. url3)

    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :' .. tolazy(total2), mrl = url2 .. url3})

      end 
      

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end
 







   --     for title3, title, title1 in string.gmatch(x, 'var kinopoisk_id.-= (.-);.-<h1.-span.->(.-)<.-%((.-)%)') do

  --    title = urlencode(title)
     
 --     title = string.gsub(title, '+', '%%20')


     
     
  --  for title3, title, title1 in string.gmatch(x, 'var kinopoisk_id.-= (.-);.-<h1.-span.->(.-)<.-%((.-)%)') do

   --   title = urlencode(title)
     
  --    title = string.gsub(title, '+', '%%20')

     
     
    

   




   for title3, title, title1 in string.gmatch(x, 'var kinopoisk_id.-= (.-);.-<h1.-span.->(.-)<.-%((.-)%)') do

      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
       url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=') 


    table.insert(t, {title = 'Zetflix', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
   
   
   for  total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-hidxlglk.-class="videos__item%-title">(.-)</div>') do
  
  
     local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-m3u8)"') do
      
      url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')

      
      
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
        for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end









        for title3, title, title1 in string.gmatch(x, 'var kinopoisk_id.-= (.-);.-<h1.-span.->(.-)<.-%((.-)%)') do

      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
     --url = string.gsub(title, '^(.-)', 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=') .. '&year=' .. title1 .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
  
    -- local x = conn:load(url)
     
      
   -- for title3 in string.gmatch(x, 'docs.-{"id":(.-),') do
    

   url1 = string.gsub(title3, '^(.-)', 'https://lampa.maxvol.pro/lite/lumex?kinopoisk_id=') 
       --.. '&uid=m7alois3'
 
    table.insert(t, {title = 'Lumex', mrl = '#stream/q=content&id=' .. url1, image = image})
         end
    --     end
--    local x = conn:load(url1)
    
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
  
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.67.229.77&h=https://p.lumex.space'
  
 -- table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '240/index', '1080/index')
      url3 = string.gsub(url3, '240.mp4', '1080.mp4')
  url3 = string.gsub(url3, '^(.-)', 'http://45.67.229.77/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

   table.insert(t, {title = 'lumex :' .. tolazy(total), mrl = url3})
       
    end
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lampa.maxvol.pro')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'https://lampa.maxvol.pro')
    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.67.229.77&h=https://p.lumex.space'
    
     local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '240/index', '720/index')
      url5 = string.gsub(url5, '240.mp4', '720.mp4')
  url5 = string.gsub(url5, '^(.-)', 'http://45.67.229.77/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url5})

       
    end
end
end
end
     
   
   
   
   
   
   
     for title3 in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do  


    
    url1 = string.gsub(title3, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=')

 --   table.insert(t, {title = url1, mrl = '#stream/q=content&id=' .. url1})
     table.insert(t, {title = 'Источники', mrl = '#stream/q=content&id=' .. url1})
 --    end
   end

  --  local x = conn:load(args.id)
     for title3, title, title1  in string.gmatch(x, '"current_page":.-"id".-"kinopoisk_id":(.-),.-"name_russian":"(.-)".-"year.-:"(.-)"') do
    
    title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')

  --   title = urlencode(title)
      
  --    title = string.gsub(title, '+', '%%20')

 

     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')



url1 = string.gsub(title, '^(.-)', 'https://lams.maxvol.pro/lite/kinobase?title=') .. '&year=' .. title1
    --.. '&uid=m7alois3'
   
  -- table.insert(t, {title = url1, mrl = url1})

  
 
     local x = conn:load(url1)
    
      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lams.maxvol.pro')
    --  t['view'] = 'simple'

   table.insert(t, {title = tolazy(total) .. ' (' .. total1 .. ')', mrl = url2})

     end  
    end

--http://movixhd.online/lite/kinobase?title=%d0%b1%d1%83%d0%bc%d0%b0%d0%b6%d0%bd%d1%8b%d0%b9+%d0%b4%d0%be%d0%bc&year=2017&s=1
  

   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lams.maxvol.pro')
    
       
    
      local x = conn:load(url2)

      
       

      for  total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-/proxy.-class="videos__item%-title">(.-серия)</div>') do
      
    local x = string.match(x, '"quality"(.-)}}')
    
    for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
  total3 = string.gsub(total3, ',"', '')
         
    url3 = string.gsub(url3, '^(.-)', 'https://lams.maxvol.pro')
    
     --  t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' ' .. tolazy(total2) .. ' (' .. total3 .. ')', mrl = url4})

    end   
    end
    end 
     

 
     
     
      url1 = string.gsub(title3, '^(.-)', 'http://movixhd.online/lite/veoveo?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
   
   local x = conn:load(url1)
     
       for  url2, total2 in string.gmatch(x, 'class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do

      t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2), mrl = url2})

      end 



     for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)

for total3, url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-media="" s=.-e="(.-)".-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total3) .. ' серия' .. tolazy(total4), mrl = url4})

      end 
      end



url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
     t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end





--  https://lampa.ds220kirill.synology.me

      
     url1 = string.gsub(title3, '^(.-)', 'http://movixhd.online/lite/videodb?kinopoisk_id=')
     --.. '&title=' .. title .. '&year=' .. title1 
  
  
    
      local x = conn:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://movixhd.online')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://movixhd.online') 
       local x = conn:load(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://movixhd.online') 
       local x = conn:load(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://movixhd.online')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
    



     
     url1 = string.gsub(title3, '^(.-)', 'http://movixhd.online/lite/vdbmovies?kinopoisk_id=') .. '&uid=m7alois3'


    local x = conn:load(url1)

       for total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-/proxy.-mp4.-class="videos__item%-title">(.-)</div>') do
  
  
  
      local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url1 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)"') do
      
  
  
     url1 = string.gsub(url1, '\\u0026', '&')
    url1 = string.gsub(url1, '^(.-)', 'http://movixhd.online')


      t['view'] = 'simple'


   table.insert(t, {title = 'vdbmovies' .. ':'.. tolazy(total) .. ( total1), mrl = url1})

       
    end
    end
    

    
  
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

    --     url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'http://movixhd.online')
    

      local x = conn:load(url2)

     
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
  
     --    url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'http://movixhd.online')
    
       
    
     local x = conn:load(url3)
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://movixhd.online')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end
  
        
   
     



     url1 = string.gsub(title3, '^(.-)', 'http://movixhd.online/lite/filmix?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
  
      local x = conn:load(url1)
      
     for  url3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

   table.insert(t, {title = 'filmix' .. ':'.. tolazy(total2), mrl = url3})

     end  


      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for url5, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'filmix :' .. total .. ' '  .. tolazy(total3) .. total2, mrl = url5})

       
    end

end
end


    



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/remux?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

    local x = conn:load(url1)

    

      for  url2, total in string.gmatch(x, '"url".-(http.-)quality.-class="videos__item%-title">(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      
       url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
      
       for  url3 in string.gmatch(x, '"play".-"url":.-(http.-)"') do

       t['view'] = 'simple'

   table.insert(t, {title = 'remux :' .. tolazy(total), mrl = url3})

     end  
    end






   
    

    
    
 
 
 
 
 
    url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&search=') .. '-' .. title1
      --.. '&box_mac=acace24b8434'
			
			
			
			
      local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')

     
     for url1 in string.gmatch(x, 'fxml.-<channel>.-(http.-)]]') do

 --    total1=base64_decode(total1)
     
--     total1 = string.gsub(total1, 'item/', '')


--http://kb-team.club/?do=%2Fplugin&bid=kinofit-kinofit_4k&search=%D1%87%D1%83%D0%B6%D0%BE%D0%B9-1979&box_mac=acace24b8434
       
    local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
     
     
   --   for title in string.gmatch(x, '"id":(.-),') do

    --     print(url)
		 
   --      title = string.gsub(title, '^(.-)', 'item/')
         
      --   title=base64_encode(title)
 

   --    url1 = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=')
       
      
   --    local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')


     
     
     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = total .. (total1), mrl = url2})
    
        end
        end
        end
  
    
url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
    --.. '&rjson=true'

    local x = conn:load(url1)



      for  url2, url3,  total, total1 in string.gmatch(x, '"play".-"url":"(http.-pidtor)(.-)".-class="videos__item%-title">(.-)<.-<!%-%-(.-)%-') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total) .. ' ' .. total1, mrl = url2 .. url3})

       
    end
    
url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 
      


         url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 

    


   
    
    
    

  url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=') 
  --.. '&uid=m7alois3'
    
    
      local x = conn:load(url1)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=') 

    local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vibix :' .. tolazy(total1) .. total2, mrl = url3})

       
    end

end


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/rezka?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

     local x = conn:load(url1)
 
  
  
       for  url3, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. tolazy(total1), mrl = url3})
  --   end
     end  
  
         local x = conn:load(url1)

     
     for url3, total2  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
     
     url3 = string.gsub(url3, '\\u0026', '&')

     url3 = string.gsub(url3, '\\u002B', '+')

  
     local x = conn:load(url1)

   for url4, total3  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')

     url4 = string.gsub(url4, '\\u002B', '+')
     

      local x = conn:load(url3)

      for url5, total4  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')

     url5 = string.gsub(url5, '\\u002B', '+')
     
    
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. total2 .. ' '  .. tolazy(total3) .. ' ' .. total4, mrl = url5})

       
    end
end
end

end
--end
   
   
     
 --  local x = conn1:load(args.id)
  
  --   for title, total in string.gmatch(x, '<h1><span.->(.-)</span>.-%((.-)%)') do      
        
  --     title = urlencode(title)
     
  --    title = string.gsub(title, '+', '%%20')
      
 --    url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    
 --   table.insert(t, {title = 'Источники 2', mrl = '#stream/q=content&id=' .. url, image = image})
      --   end

       
  --   local x = conn:load(args.id)

 --   for title, title1 in string.gmatch(x, '%[{"size".-"name":"(.-)".-"relased":(.-),') do

--     title = urlencode(title)
      
  --    title = string.gsub(title, '+', '%%20')

 --   url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')
    --.. ',' .. title1

  --   local x = conn:load(url)



  --  for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do





    



--https://lam.akter-black.com/lite/pidtor?year=2024&serial=1&title=%D0%A7%D0%B5%D0%BB%D1%8E%D1%81%D0%BA%D0%B8%D0%BD%2E%20%D0%9F%D0%B5%D1%80%D0%B2%D1%8B%D0%B5&original_title=




 



    
      

 
    

--end
--end



       
       
       
       
      
       

     for title, total in string.gmatch(x, '<h1><span.->(.-)</span>.-%((.-)%).-<br') do      
        
    --   title = urlencode(title)
     
     title = string.gsub(title, ' ', '-')
   


      url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&search=') .. '-' .. total
      --.. '&box_mac=acace24b8434'
			
			
			
			
      local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')

     
     for total1 in string.gmatch(x, 'fxml.-<channel>.-http.-&goto=(.-)]]') do

     total1=base64_decode(total1)
     
     total1 = string.gsub(total1, 'item/', '')

   
  
   

       url1 = string.gsub(total1, '^(.-)', 'http://filmixapp.cyou/api/v2/post/') .. '?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380'
         
         
        	table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url1, image = image})
		
			

		end
   end
   

       
        
     local x = conn:load(args.id)
     
     
     
     
      for title in string.gmatch(x, '"id":(.-),') do

    --     print(url)
		 
         title = string.gsub(title, '^(.-)', 'item/')
         
         title=base64_encode(title)
 

       url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=')
       
      
       local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')


     
     
     for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = total .. (total1), mrl = url2})
    
        end
        end
        end
  
    
    
      



        for title in string.gmatch(x, '"id":(.-),') do

    --     print(url)
		 
         title = string.gsub(title, '^(.-)', 'item/')
         
         title=base64_encode(title)
 

       url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=')
       
      
       local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')





      for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
       total = string.gsub(total, '<!%[CDATA%[', '')
       total = string.gsub(total, ']]>', '')
       
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

    
     for total1, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-сезон)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
       total1 = string.gsub(total1, '<!%[CDATA%[', '')
       total1 = string.gsub(total1, ']]>', '')
   
        local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
     
     for total2, total3, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      total2 = string.gsub(total2, '<!%[CDATA%[', '')
       total2 = string.gsub(total2, ']]>', '')
      
      local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
 
     
     
     for total4, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do
    
       total4 = string.gsub(total4, '<!%[CDATA%[', '')
       total4 = string.gsub(total4, ']]>', '')
    
    
    
       t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total) .. tolazy(total1) .. tolazy(total2) .. tolazy(total3) .. (total4), mrl = url4})
    
        end
        end
        end
        end
        end
     
     
     
     
     
  --   for title, total in string.gmatch(x, '<h1><span.->(.-)</span>.-%((.-)%).-<br') do        
        
  --     title = urlencode(title)
     
--      title = string.gsub(title, '+', '%%20')
      


 --    url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
     
 --    local x = conn:load(url)
     
     
     
     
      
         
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end