-- fast-film plugin


require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate


--local REPO1 = 'http://xplay.bz/'

--local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'

--local HOME = 'http://fast-fiml.ru'
local HOME = 'http://fast-torrent.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




--HOME = 'http://www.fast-film.ru'
--HOME = 'http://www.fast-fiml.ru'


--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

-- #self/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/
-- #stream/url=http://xplay.bz/
-- #stream/url=http://staticdata.appinfo.su/staticfiles/fimg/open.png
-- #stream/url=http://xplay.bz/list
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka%2Flist%3Fcat%3Dfilms
-- #stream/url=http://imboom.ru/?ma=playlist
-- #stream/url=http://imboom.ru/?ma=imboomiptv
-- #stream/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/list



	
	-- #stream/page=2
	-- #stream/page=3
	-- #stream/page=4
	-- #stream/page=5
	-- #stream/page=6
	-- #stream/page=7
	-- #stream/page=8
	-- #stream/page=9
	-- #stream/page=10
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/new/all/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. tostring(page) .. '.html'
		end
	--	local x = http.getz(url)
        local x = conn:load(url)

      -- for title, url, image in string.gmatch(x, '<div class=film%-wrap".-alt="(.-)".-<a href="(.-)".-style="background:.-(http.-jpg)') do
       
       
  	for url, image, title in string.gmatch(x, '<div class=.-film%-wrap.-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		--	table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
        
		
          for url, title in string.gmatch(x, '<div class=.-float_right collection%-profile.-nav%-icon generic_favorit_controll email%-off.-collection%-item%-head.-<a href=.-(/favorite/public.-)\'.-<big>(.-)<') do
         t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
  
  
  
    --  for title, url, image   in string.gmatch(x, '<div class="film%-wrap".-alt="(.-)".-<a href="(.-)".-itemprop="image" content="(.-)"') do
        
      -- url = string.gsub(url, '^(.-)', HOME)

	--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
	--	end
  
  
  
  

--<div class=item_main_box2.-class="quality_type">(.-)<.-<a href=.-(/film/.-html).-background:.-(http.-jpg)

        for url, image, title  in string.gmatch(x, '<div class=\'item_main_box2\'.-<a href=.-(/film/.-html).-background:.-(http.-jpg).-class=\'use_tooltip item_title\'title=\'(.-)\'') do
        
       url = string.gsub(url, '^(.-)', HOME)
    --   title = string.gsub(title, ''', '')
    --    t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
	--	end
	
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       table.insert(t, {title = 'КОЛЛЕКЦИИ', mrl = '#stream/genre=' .. '/favorite/public/'})
    	table.insert(t, {title = 'Новые коллекции', mrl = '#stream/genre=' .. '/favorite/public/?order=1'})

     table.insert(t, {title = 'Самые большие коллекции', mrl = '#stream/genre=' .. '/favorite/public/?order=2'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=6'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=3'})
	
	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=4'})
	
--http://www.fast-fiml.ru/last-tv-torrent/
     	local x = conn:load(HOME .. '/new-torrent/')
   
        
		local x = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-/).->(.-)</a>') do
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
    	local x = conn:load(HOME .. '/last-tv-torrent/')
        
		local x = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
	
   --     for genre, title in string.gmatch(x, '<a href="(.-tv/).->(.-)</a>') do
	
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-tv/).->(.-)</a>') do
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		local x = conn:load(HOME .. '/last-multfilm-torrent/')
        
		local x = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-/).->(.-)</a>') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
--http://www.fast-fiml.ru/new-torrent/
--http://www.fast-fiml.ru/last-tv-torrent/
--http://www.fast-fiml.ru/last-multfilm-torrent/




--<a href="/all/tag/be-continued/  <li class='more'><a href="/tags/   

        local x = conn:load(HOME .. '/new/all/')
        
	--	local x = string.match(x, '<em class="nav%-icon nav%-tag_blue.->(.-)<.-Еще Теги')
		
		for genre, title in string.gmatch(x, '<a href=.-(/all/tag/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end

          local x = conn:load(HOME .. '/tags/all/')
        
	--	local x = string.match(x, '<div class="ui%-widget ui%-widget%-content".->(.-)</ul>')
		
		for genre, image, title in string.gmatch(x, '<div class="item_tag".-<a href=.-(/all/tag/.-/).-background%-image:.-(http.-jpg).-</div>(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end

--http://www.fast-torrent.ru/search/{searchTerms}/1.html


        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = 'http://www.fast-torrent.ru/search/' .. urlencode(args.keyword) .. '/' .. tostring(page) .. '.html'

		
		local x = conn:load(url)
		
        for url, image, title, total in string.gmatch(x, '<div class="film%-wrap".-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)</span>(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
       --   table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
			table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '/' ..  tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
		
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?id=106291&kinopoisk_id=1355296
	
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?kinopoisk_id=1355296&title=&original_title=&s=1
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<meta itemprop="description" content="(.-)"')
    --    t['poster'] = args.p
		t['poster'] = parse_match(x,'var test_image.-(http.-jpg)')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Жанр</strong>:.-)</p>' ,'(Режиссер</strong>:.-)</p>' ,'(В ролях</strong>:.-)</p>' , 
		})


--<span itemprop="name" id='film_name'>Ведьма. Деревня проклятых</span>(2019)<br

   --    for url  in string.gmatch(x, '<h1.-<span.->(.-)</span.-</h1>') do
       
   --    url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://www.vk.com/?id=search&search=')
       
   --   table.insert(t,{title= url,mrl= url})
		--	end
       
       
--http://fxmlparsers.in.net/http://www.vk.com/?id=search&search=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%201979



        for url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
   
   
      url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=') 
         table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

         end

         
         
        for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   


         url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?id=0&kinopoisk_id=')

    --    url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=0&kinopoisk_id=')
        

      local x =  http.getz(url)
       
      
       
       for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(1080p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(720p).-(http.-mp4)') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(480p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(360p).-(http.-mp4)') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end
--end
        
        
          for url2  in string.gmatch(x, 'current_page".-"data":%[{"id.-"kinopoisk_id":(.-),') do
       

        url = string.gsub(url2, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=22&kid=')
       
        local x = http.getz(url)


       for title, url3 in string.gmatch(x, '\'title\': \'(Сезон) (.-)\',') do

     
      
      local x = http.getz('https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)


  
        for url5, total5  in string.gmatch(x, 'method":"link".-(&t=.-)".->(.-)</div>') do


       local x = http.getz('https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3 .. url5)



       for url4, total2  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do
       

       t['view'] = 'simple'
   
   

      table.insert(t, {title = title .. ' ' .. url3 .. (total2) .. (total5), mrl = url4})
    

	end
    end
    end
    end
  
        
   
   
   
   
          

        for url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
       print(url)
       
    --    url = string.gsub(url, '^(.-)', 'https://videocdn.svetacdn.in/IAF0wWTdNYZm?kp_id=')
        --.. '&domain=kinobd.net'
       
		 url = string.gsub(url, '^(.-)', 'https://videocdn.tv/api/short?api_token=bVycnMuy5Dfe0IkzXt87eeVa9EtIkUl5&kinopoisk_id=')
       
        local x = http.getz(url)
      for  url  in string.gmatch(x, '"iframe_src":"(.-)"') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})

   --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})

		end
   end
    
  

  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(360p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
        
        
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
        
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       
       
        for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(480p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
  
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
  
  
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
  
      for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(720p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
  
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(1080p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
  
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
	
		
       for title, url  in string.gmatch(x, 'movie.-%[(360p)](-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
     	 for title, url  in string.gmatch(x, 'movie.-%[(480p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
	for title, url  in string.gmatch(x, 'movie.-%[(720p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
		
        for title, url  in string.gmatch(x, 'movie.-%[(1080p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
		

   --    for title  in string.gmatch(x, '<h1.-itemprop="name".->(.-)</span>') do

      --   print(url)
		 

    --     url = string.gsub(title, '^(.-)', 'http://xplay.bz/list?search=')
         

    --    local x = fxml({url = url})
      --  for _, v in ipairs(x) do
 

    --	if string.find(v.mrl, '^#') then
    	
		--	v.mrl = v.mrl .. '&package=' .. urlencode(REPO .. 'xplay.IMC.zip')
	--	end
--		table.insert(t, v)
--	end
    --  end 

--5024220


        for url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do


        url = string.gsub(url, '^(.-)', 'http://byzkhkgr.deploy.cx/ip?ip=185.228.133.208/https://cdnmovies-stream.online/kinopoisk/') .. '/iframe?domain=kinobd.net'

  --      url = string.gsub(url, '^(.-)', 'https://cdnmovies-stream.online/kinopoisk/') .. '/iframe?domain=kinobd.net'
    	
			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end

         
         
         for url in string.gmatch(x, 'player.-:.-#2(.-)"') do
       
       

         url = string.gsub(url, '\\/\\/Ni14UVdNaDdlcnRMcDh0X005aHVVRGsxTTBWcllK', '')
         url = string.gsub(url, '\\/\\/d05wMndCVE5jUFJRdlRDMF9DcHhDc3FfOFQxdTlR', '')
         url = string.gsub(url, '\\/\\/bWQtT2QyRzlSV09nU2E1SG9CU1NiV3JDeUlxUXlZ', '')
         url = string.gsub(url,'\\/\\/a3p1T1lRcUJfUVNPTC14ek5fS3oza2tna0hoSGl0', '')
         url = string.gsub(url,'VfR0xFc1h4bnBVNExqamQwUmVZLVZI', '')
         url = string.gsub(url,'\\/\\/UnlUd3RmMT', '')




         url=http.urldecode(base64_decode(url))
  


        
        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(240p)](http.-.m3u8)') do
			
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        
		        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(360p)](http.-.m3u8)') do
			
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
			
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(480p)](http.-.m3u8)') do
	
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
	
			
           --  title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(720p)](http.-.m3u8)') do
		
		
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
		
			
         --    title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(1080p)](http.-.m3u8)') do
		
		
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
		
		
			
         --    title = tolazy(title)
            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        end


--https://1f29036bcf55d.sarnage.cc/kinopoisk/386/iframe?domain=kinobd.net
		
      --  for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
		-- print(url) 
	--	url = string.gsub(url, '^(.-)', 'http://sarnage.cc/kinopoisk/')
	--	table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

	--	end
     
     
        
     
    --    local x = conn:load(args.id)
     
        -- for url in string.gmatch(x,'let player = new Playerjs.-id:"player".-file:.-#2(.-)\'') do
        -- url = string.gsub(url, '//', '')
        -- url = string.gsub(url, 'bHZmeWNnbmRxY', '')
        -- url = string.gsub(url, 'ZGY4dmc2', '')
        -- url = string.gsub(url, 'OXI5enhXZGx5ZisqZmd4NDU1ZzhmaDl6LWUqUQ==', '')
         --url = string.gsub(url, 'NTR2amZoY2dkYnJ5ZGtjZmtuZHo1Njg0MzZmcmVkKypk', '')
        -- url = string.gsub(url, 'UqcSpZ', '')
        -- url = string.gsub(url, 'YXorLWVydyozNDU3ZWRndGpkLWZlcXNwdGYvcm', '')
        --url = string.gsub(url, 'LSpmcm9mcHNjcHJwYW1mcFEqNDU2MTIuMzI1NmRmcmdk', '')
        --url = string.gsub(url, '3lkcmNnY2ZnKzk1MTQ3Z2ZkZ2YtemQq', '')
        
 
         --url=http.urldecode(base64_decode(url))
        
		--if url then
			--for title,  url in string.gmatch(url, '{"title":(.-)"file":"(.-)"') do
           --t['view'] = 'simple'
       
       

       
         
         --title = string.gsub(title, '"subtitle":".-",', '')
        -- title = string.gsub(title, '"folder":%[{"title":', '')
         
        --title = string.gsub(title, ',', '')
			--	table.insert(t,{title=tolazy(title),mrl= url})
		--	end
		--end	
  
       --end


        for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
    
        print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-or (//video.zagonka.org/movies/.-mp4)') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end
      






--https://api.embr.ws/embed/movie/67086



         for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
         print(url)
		 url = string.gsub(url, '^(.-)', 'http://divantv.zz.mu/kinomovie/zombie.m3u.php?kp_id=')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
		
  --       for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
      --   print(url)
	--	 url = string.gsub(url, '^(.-)', 'https://voidboost.net/embed/')

   --    table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    --     end
          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do

            
          local slist=string.match(x, '<select name="season".->(.-)</select>')
          
           if slist then
          
             for url1, title in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
             

             
            local slist=string.match(x, '<select name="episode".->(.-)</select>')
            
           if slist then
            for url2, total in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do
         

          t['view'] = 'simple'
        	table.insert(t, {title = title .. ':' .. (total) .. ' (' .. total1 .. ')', mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
			end
			end
   	    	end	
   	    	end
            end	
   	    	end
    

--https://voidboost.net/movie/149fa08a44c989e65e37289b4c796736/iframe?h=baskino.me

          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
             
             
          t['view'] = 'simple'
        	table.insert(t, {title = total1, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/movie/' .. url3 .. '/iframe?'})
             
            end
            end
    
          
	--		for url1, title in string.gmatch(x, '<option value="(.-)".->(Сезон.-)</option>') do
	--		end
     --     local x = string.match(x, '<select name="episode".->(.-)</select>')
			
     --      for url2, total in string.gmatch(x, '<option value="(.-)".->(Серия.-)</option>') do
	--	   end
            
         
    --      local x = string.match(x, '<select name="translator.->Перевод.->(.-)</div>')
      --      for url3, total1 in string.gmatch(x, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
    
         
         
       -- 	table.insert(t, {title = 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
	--		end

   		
   		
       for url  in string.gmatch(x, 'var CDNplayerConfig.-file.-#2(.-)\'') do
     --    print(url)
		 url = string.gsub(url, '//_//', '')
         url = string.gsub(url, 'Xl4jQEAhIUAjISQ=', '')
         url = string.gsub(url, 'JCQkIyMjIyEhISEhISE=', '')
         url = string.gsub(url, 'QCFeXiFAI0BAJCQkJCQ=', '')
         




         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, url in string.gmatch(url, '(360p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if url then
			for title, url in string.gmatch(url, '(480p).-(http.-.mp4)') do
             t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
				
               table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(720p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p)].-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p Ultra).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end
			end
		
    --	local x = string.match(x, '<p itemprop="description.->(.-)</table>')
		
		for url, title in string.gmatch(x, '<br><a href=.-(/film/.-html).->(.-)</a>') do
           url = string.gsub(url, '^(.-)', HOME)
		
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end	

         for url, title in string.gmatch(x, '<strong><a href=.-(/film/.-html).->(.-)</a>') do
           url = string.gsub(url, '^(.-)', HOME)
		
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end	



        for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end
   
     --    for title, url, total in string.gmatch(x, '<em class="directors_cut".-class=\'c3.->(.-)<.-Файл:.-<a href="(/download.-torrent)".->(.-).torrent') do
		
     --    print(url)
--		 url = string.gsub(url, '^(.-)', HOME)

   --      table.insert(t, {title = title .. '|' .. (total), mrl = url})

			
--		end
  
  

  
  

   
   
      
     --    for title, url, total in string.gmatch(x, '<em class="directors_cut".-class=\'c3.->(.-)<.-Файл:.-<a href="(/download.-torrent)".->(.-).torrent') do
		
      --   print(url)
	--	 url = string.gsub(url, '^(.-)', HOME)

    --     table.insert(t, {title = title .. '|' .. (total), mrl = url})

			
	--	end
  
  
    --    for title in string.gmatch(x, '<meta property="og:title" content="(.-)"') do
  
  
       --  for title in string.gmatch(x, '<h1.-span.->(.-)</span>') do
   --     title=http.urlencode(title)

   --      title = string.gsub(title, '+', '%%20')
    
    
    --      url = string.gsub(title, '^(.-)', 'http://stvplay.mooo.com:81/vk/vk.php?search=')
    
      --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
    
     --   end
   
   --    local x = http.getz(url)
       
--   for url, total in string.gmatch(x, '</channel.-<channel.-playlist_url>.-(http.-)].-description>.-<h3>(.-)</h3>') do

 --    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})
    
      --  end
 --  end
   --    local x = http.getz(url)
   
   --     for total1, url in string.gmatch(x, '<title>.-(1080p).-<stream_url>.-(https.-)]') do
   
  --    table.insert(t, {title = total1 ..  ' ' ..  total, mrl = url})
    
     --   end
 --  end
--   end
          
  
   
         
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end