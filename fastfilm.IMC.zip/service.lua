-- fast-film plugin


require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate


--local REPO1 = 'http://xplay.bz/'

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'

local HOME = 'http://www.fast-fiml.ru'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'UTF-8'
conn['root'] = HOME_SLASH





--HOME = 'http://www.fast-film.ru'
--HOME = 'http://www.fast-fiml.ru'


--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

-- #self/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/
-- #stream/url=http://xplay.bz/
-- #stream/url=http://staticdata.appinfo.su/staticfiles/fimg/open.png
-- #stream/url=http://xplay.bz/list
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka%2Flist%3Fcat%3Dfilms
-- #stream/url=http://imboom.ru/?ma=playlist
-- #stream/url=http://imboom.ru/?ma=imboomiptv
-- #stream/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/list



	
	-- #stream/page=2
	-- #stream/page=3
	-- #stream/page=4
	-- #stream/page=5
	-- #stream/page=6
	-- #stream/page=7
	-- #stream/page=8
	-- #stream/page=9
	-- #stream/page=10
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/new/all/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. tostring(page) .. '.html'
		end
		local x = http.getz(url)
        
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
     --   for title, url, image in string.gmatch(x, '<div class="film%-wrap".-alt="(.-)".-<a href="(.-)".-style="background:.-(http.-jpg)') do
       
       
    	for url, image, title, total in string.gmatch(x, '<div class="film%-wrap".-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)</span>(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
       --   table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
			table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
        
		
          for url, title in string.gmatch(x, '<div class=.-float_right collection%-profile.-nav%-icon generic_favorit_controll email%-off.-collection%-item%-head.-<a href=.-(/favorite/public.-)\'.-<big>(.-)<') do
         t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
  
  
  
      for title, url, image   in string.gmatch(x, '<div class="film%-wrap".-alt="(.-)".-<a href="(.-)".-itemprop="image" content="(.-)"') do
        
       url = string.gsub(url, '^(.-)', HOME)

		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
  
  
  
  

--<div class=item_main_box2.-class="quality_type">(.-)<.-<a href=.-(/film/.-html).-background:.-(http.-jpg)

        for url, image, title  in string.gmatch(x, '<div class=\'item_main_box2\'.-<a href=.-(/film/.-html).-background:.-(http.-jpg).-class=\'use_tooltip item_title\'title=\'(.-)\'') do
        
       url = string.gsub(url, '^(.-)', HOME)
    --   title = string.gsub(title, ''', '')
    --    t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
	--	end
	
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       table.insert(t, {title = 'КОЛЛЕКЦИИ', mrl = '#stream/genre=' .. '/favorite/public/'})
    	table.insert(t, {title = 'Новые коллекции', mrl = '#stream/genre=' .. '/favorite/public/?order=1'})

     table.insert(t, {title = 'Самые большие коллекции', mrl = '#stream/genre=' .. '/favorite/public/?order=2'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=6'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=3'})
	
	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=4'})
	
--http://www.fast-fiml.ru/favorite/public/
     	local x = http.getz(HOME .. '/new-torrent/')
        
		local x = string.match(x, '<div id="leftmenu".->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-/).->(.-)</a>') do
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
    	local x = http.getz(HOME .. '/last-tv-torrent/')
        
		local x = string.match(x, '<div id="leftmenu".->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-tv/).->(.-)</a>') do
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		local x = http.getz(HOME .. '/last-multfilm-torrent/')
        
		local x = string.match(x, '<div id="leftmenu".->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-multfilm/).->(.-)</a>') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
--http://www.fast-fiml.ru/new-torrent/
--http://www.fast-fiml.ru/last-tv-torrent/
--http://www.fast-fiml.ru/last-multfilm-torrent/
		 table.insert(t, {title = 'Фильмы: HD 2160р', mrl = '#stream/genre=' .. '/video/tag/hd-2160r/'})
         table.insert(t, {title = 'Фильмы: HD 1080', mrl = '#stream/genre=' .. '/video/tag/hdtv-1080i/'})
		 table.insert(t, {title = 'Фильмы: HD 720', mrl = '#stream/genre=' .. '/video/tag/hdtv-720p/'})
         table.insert(t, {title = 'Фильмы: 3D', mrl = '#stream/genre=' .. '/video/tag/3d/'})

         table.insert(t, {title = 'Сериалы: HD 2160р', mrl = '#stream/genre=' .. '/tv/tag/hd-2160r/'})
         table.insert(t, {title = 'Сериалы: HD 1080', mrl = '#stream/genre=' .. '/tv/tag/hdtv-1080i/'})
		 table.insert(t, {title = 'Сериалы: HD 720', mrl = '#stream/genre=' .. '/tv/tag/hdtv-720p/'})
         table.insert(t, {title = 'Сериалы: 3D', mrl = '#stream/genre=' .. '/tv/tag/3d/'})		 

         table.insert(t, {title = 'Мультфильмы: HD 2160р', mrl = '#stream/genre=' .. '/multfilm/tag/hd-2160r/'})
         table.insert(t, {title = 'Мультфильмы: HD 1080', mrl = '#stream/genre=' .. '/multfilm/tag/hdtv-1080i/'})
		 table.insert(t, {title = 'Мультфильмы: HD 720', mrl = '#stream/genre=' .. '/multfilm/tag/hdtv-720p/'})
         table.insert(t, {title = 'Мультфильмы: 3D', mrl = '#stream/genre=' .. '/multfilm/tag/3d/'})		 

          table.insert(t, {title = 'Документальные: HD 2160р', mrl = '#stream/genre=' .. '/documentary/tag/hd-2160r/'})
         table.insert(t, {title = 'Документальные: HD 1080', mrl = '#stream/genre=' .. '/documentary/tag/hdtv-1080i/'})
		 table.insert(t, {title = 'Документальные: HD 720', mrl = '#stream/genre=' .. '/documentary/tag/hdtv-720p/'})
         table.insert(t, {title = 'Документальные: 3D', mrl = '#stream/genre=' .. '/documentary/tag/3d/'})



--<a href="/all/tag/be-continued/  <li class='more'><a href="/tags/   

        local x = http.getz(HOME .. '/new/all/')
        
	--	local x = string.match(x, '<em class="nav%-icon nav%-tag_blue.->(.-)<.-Еще Теги')
		
		for genre, title in string.gmatch(x, '<a href=.-(/all/tag/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end

          local x = http.getz(HOME .. '/tags/all/')
        
	--	local x = string.match(x, '<div class="ui%-widget ui%-widget%-content".->(.-)</ul>')
		
		for genre, image, title in string.gmatch(x, '<div class="item_tag".-<a href=.-(/all/tag/.-/).-background%-image:.-(http.-jpg).-</div>(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end

--http://www.fast-torrent.ru/search/{searchTerms}/1.html


        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = 'http://www.fast-torrent.ru/search/' .. urlencode(args.keyword) .. '/' .. tostring(page) .. '.html'

		
		local x = http.getz(url)
		
        for url, image, title, total in string.gmatch(x, '<div class="film%-wrap".-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)</span>(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
       --   table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
			table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '/' ..  tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
		
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?id=106291&kinopoisk_id=1355296
	
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?kinopoisk_id=1355296&title=&original_title=&s=1
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<meta itemprop="description" content="(.-)"')
    --    t['poster'] = args.p
		t['poster'] = parse_match(x,'var test_image.-(http.-jpg)')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Жанр</strong>:.-)</p>' ,'(Режиссер</strong>:.-)</p>' ,'(В ролях</strong>:.-)</p>' , 
		})

--http://xplay.bz/view?id=891699&cat=movie&original_language=en&kinopoisk_id=4908570


--http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964&imdb_id=&token=866cc7c7309614101880fb1d701c4f14&box_mac=&box_user=

--http://xplay.bz/view?id=74114&token=866cc7c7309614101880fb1d701c4f14&kinopoisk_id=806964&cat=movie


--http://xplay.bz/view?id=74114&token=866cc7c7309614101880fb1d701c4f14&kinopoisk_id=806964&cat=movie

--http://xplay.bz/view/videodb?id=695548695548&token=866cc7c7309614101880fb1d701c4f14&kinopoisk_id=695548&cat=movie


--http://xplay.bz/view/videodb.php?id=74114&cat=movie&kinopoisk_id=806964

		--http://xplay.bz/view?kinopoisk_id=806964&cat=movie&id=74114
		
--http://xplay.bz/view/videodb?id=74114&cat=movie&kinopoisk_id=806964&imdb_id=&token=2b9b26e0546757073eb2dba5a8f9cda4&box_mac=667866143df0&box_user=daniulov.d@yandex.ru




--http://xplay.bz/view?&cat=0&kinopoisk_id=5429849

--http://xplay.bz/watch/add?id=956262&cat=movie

--http://xplay.bz/view/videodb?id=956262&kinopoisk_id=4912476&token=4e8f234e3cf7cdf3ea4bef8f0b81a013&cat=movie


--http://xplay.bz/view?id=1212073&cat=movie&original_language=de&kinopoisk_id=5429849&imdb_id=tt29538571


--http://xplay.bz/view/videodb?id=1212073&cat=movie&kinopoisk_id=5429849&imdb_id=tt29538571&token=0d0d38a6bd17ba322ac2e94e850ba124&box_mac=&box_user=

--http://xplay.bz/list?search=Индиана Джонс и колесо судьбы
--http://www.fast-fiml.ru/film/indiana-dzhons-5.html

   
   
   
          

         for url, url1  in string.gmatch(x, 'var FILM_ID.-= (.-);.-var kinopoisk_id.-= (.-);') do
       print(url)
		 url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=') .. '&kinopoisk_id=' .. url1

		--	table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
	--	end
		
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?id=106291&kinopoisk_id=1355296
	
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?kinopoisk_id=1355296&title=&original_title=&s=1
	
       --  local x = http.getz(url)
	--	 for url, title  in string.gmatch(x, '{"method":"link","url":".-(/lite.-)".-class="videos__season%-layers".-class="videos__item%-title videos__season%-title">(.-)</div>') do
        --  url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118')

      --    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})

    --   end
    --   end
       
       local x = http.getz(url)
         for title, total, url in string.gmatch(x, '"title":"(.-)".-(1080p).-(http.-mp4)') do
         --   t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"title":"(.-)".-(720p).-(http.-mp4)') do
         --   t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"title":"(.-)".-(480p).-(http.-mp4)') do
        --    t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"title":"(.-)".-(360p).-(http.-mp4)') do
       --     t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
			
			end

       for title  in string.gmatch(x, '<h1.-itemprop="name".->(.-)</span>') do

         print(url)
		 

         url = string.gsub(title, '^(.-)', 'http://xplay.bz/list?search=')
         

        local x = fxml({url = url})
        for _, v in ipairs(x) do
 

    	if string.find(v.mrl, '^#') then
    	
			v.mrl = v.mrl .. '&package=' .. urlencode(REPO .. 'xplay.IMC.zip')
		end
		table.insert(t, v)
	end
      end 






    --   for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do

     --     print(url)
--		 url = string.gsub(url, '^(.-)', 'https://mute-value.cdnmovies-stream.online/kinopoisk/') .. '/iframe?domain=kinobox.tv'

		--	table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
--		end

         
         
         for url in string.gmatch(x, 'player.-:.-#2(.-)"') do
       
       
   --    local url=string.match(x,'player.-:.-#2(.-)"')
         print(url)
	--	 url = string.gsub(url, '\\', '')
   --      url = string.gsub(url, '/', '')
         url = string.gsub(url, '\\/\\/Ni14UVdNaDdlcnRMcDh0X005aHVVRGsxTTBWcllK', '')
         url = string.gsub(url, '\\/\\/d05wMndCVE5jUFJRdlRDMF9DcHhDc3FfOFQxdTlR', '')
         url = string.gsub(url, '\\/\\/bWQtT2QyRzlSV09nU2E1SG9CU1NiV3JDeUlxUXlZ', '')
         url = string.gsub(url,'\\/\\/a3p1T1lRcUJfUVNPTC14ek5fS3oza2tna0hoSGl0', '')
         url = string.gsub(url,'VfR0xFc1h4bnBVNExqamQwUmVZLVZI', '')
         url = string.gsub(url,'\\/\\/UnlUd3RmMT', '')




         url=http.urldecode(base64_decode(url))
  

--[%w_']
        
        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(240p)](http.-.m3u8)') do
			

           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        
		        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(360p)](http.-.m3u8)') do
			

            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
			
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(480p)](http.-.m3u8)') do
			
           --  title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(720p)](http.-.m3u8)') do
			
         --    title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(1080p)](http.-.m3u8)') do
			
         --    title = tolazy(title)
            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        end



		
      --  for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
		-- print(url) 
	--	url = string.gsub(url, '^(.-)', 'http://sarnage.cc/kinopoisk/')
	--	table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

	--	end
     
     
        
     
    --    local x = conn:load(args.id)
     
        -- for url in string.gmatch(x,'let player = new Playerjs.-id:"player".-file:.-#2(.-)\'') do
        -- url = string.gsub(url, '//', '')
        -- url = string.gsub(url, 'bHZmeWNnbmRxY', '')
        -- url = string.gsub(url, 'ZGY4dmc2', '')
        -- url = string.gsub(url, 'OXI5enhXZGx5ZisqZmd4NDU1ZzhmaDl6LWUqUQ==', '')
         --url = string.gsub(url, 'NTR2amZoY2dkYnJ5ZGtjZmtuZHo1Njg0MzZmcmVkKypk', '')
        -- url = string.gsub(url, 'UqcSpZ', '')
        -- url = string.gsub(url, 'YXorLWVydyozNDU3ZWRndGpkLWZlcXNwdGYvcm', '')
        --url = string.gsub(url, 'LSpmcm9mcHNjcHJwYW1mcFEqNDU2MTIuMzI1NmRmcmdk', '')
        --url = string.gsub(url, '3lkcmNnY2ZnKzk1MTQ3Z2ZkZ2YtemQq', '')
        
 
         --url=http.urldecode(base64_decode(url))
        
		--if url then
			--for title,  url in string.gmatch(url, '{"title":(.-)"file":"(.-)"') do
           --t['view'] = 'simple'
       
       

       
         
         --title = string.gsub(title, '"subtitle":".-",', '')
        -- title = string.gsub(title, '"folder":%[{"title":', '')
         
        --title = string.gsub(title, ',', '')
			--	table.insert(t,{title=tolazy(title),mrl= url})
		--	end
		--end	
  
       --end


        for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
    
        print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-or (//video.zagonka.org/movies/.-mp4)') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end
      






--https://api.embr.ws/embed/movie/67086



         for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
         print(url)
		 url = string.gsub(url, '^(.-)', 'http://divantv.zz.mu/kinomovie/zombie.m3u.php?kp_id=')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
		
         for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
      --   print(url)
		 url = string.gsub(url, '^(.-)', 'https://voidboost.net/embed/')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
         end
          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do

            
          local slist=string.match(x, '<select name="season".->(.-)</select>')
          
           if slist then
          
             for url1, title in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
             

             
            local slist=string.match(x, '<select name="episode".->(.-)</select>')
            
           if slist then
            for url2, total in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do
         

          t['view'] = 'simple'
        	table.insert(t, {title = title .. ':' .. (total) .. ' (' .. total1 .. ')', mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
			end
			end
   	    	end	
   	    	end
            end	
   	    	end
    

--https://voidboost.net/movie/149fa08a44c989e65e37289b4c796736/iframe?h=baskino.me

          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
             
             
          t['view'] = 'simple'
        	table.insert(t, {title = total1, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/movie/' .. url3 .. '/iframe?'})
             
            end
            end
    
          
	--		for url1, title in string.gmatch(x, '<option value="(.-)".->(Сезон.-)</option>') do
	--		end
     --     local x = string.match(x, '<select name="episode".->(.-)</select>')
			
     --      for url2, total in string.gmatch(x, '<option value="(.-)".->(Серия.-)</option>') do
	--	   end
            
         
    --      local x = string.match(x, '<select name="translator.->Перевод.->(.-)</div>')
      --      for url3, total1 in string.gmatch(x, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
    
         
         
       -- 	table.insert(t, {title = 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
	--		end

   		
   		
       for url  in string.gmatch(x, 'var CDNplayerConfig.-file.-#2(.-)\'') do
     --    print(url)
		 url = string.gsub(url, '//_//', '')
         url = string.gsub(url, 'Xl4jQEAhIUAjISQ=', '')
         url = string.gsub(url, 'JCQkIyMjIyEhISEhISE=', '')
         url = string.gsub(url, 'QCFeXiFAI0BAJCQkJCQ=', '')
         




         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, url in string.gmatch(url, '(360p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if url then
			for title, url in string.gmatch(url, '(480p).-(http.-.mp4)') do
             t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
				
               table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(720p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p)].-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p Ultra).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end
			end
		
    --	local x = string.match(x, '<p itemprop="description.->(.-)</table>')
		
		for url, title in string.gmatch(x, '<br><a href=.-(/film/.-html).->(.-)</a>') do
           url = string.gsub(url, '^(.-)', HOME)
		
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end	

         for url, title in string.gmatch(x, '<strong><a href=.-(/film/.-html).->(.-)</a>') do
           url = string.gsub(url, '^(.-)', HOME)
		
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end	



        for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end
   
     --    for title, url, total in string.gmatch(x, '<em class="directors_cut".-class=\'c3.->(.-)<.-Файл:.-<a href="(/download.-torrent)".->(.-).torrent') do
		
     --    print(url)
--		 url = string.gsub(url, '^(.-)', HOME)

   --      table.insert(t, {title = title .. '|' .. (total), mrl = url})

			
--		end
  
  

  
  

   
   
      
     --    for title, url, total in string.gmatch(x, '<em class="directors_cut".-class=\'c3.->(.-)<.-Файл:.-<a href="(/download.-torrent)".->(.-).torrent') do
		
      --   print(url)
	--	 url = string.gsub(url, '^(.-)', HOME)

    --     table.insert(t, {title = title .. '|' .. (total), mrl = url})

			
	--	end
  
  
  
  
          
  
   
         
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end