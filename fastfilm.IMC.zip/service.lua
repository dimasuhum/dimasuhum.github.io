-- fast-film plugin


require('support')
--require('video')
--require('parser')
require('client')
require('fxml')

local video = require('video')
local parser = require('parser')

local json = require('json')

local fxml = onCreate







--CDATA[http://stvplay.mooo.com:81/torrents/tmdb/tmdb.php?link=https://bitru.org/download.php?id=639863&path=&file=Особо

--https://bitru.org/browse.php?s=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9(1979)

--http://stvplay.mooo.com:81/torrents/tmdb/tmdb.php?find=%D0%9E%D1%81%D0%BE%D0%B1%D0%BE%20%D0%BE%D0%BF%D0%B0%D1%81%D0%BD%D1%8B%D0%B9%20%D0%BF%D0%B0%D1%81%D1%81%D0%B0%D0%B6%D0%B8%D1%80

--https://findmagnet.org/?q=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9

--https://www.magicsearch.net/search/%D0%A7%D1%83%D0%B6%D0%BE%D0%B9%201979/

--https://www.magicsearch.net/api/json_info?hashes=11487944


--local REPO1 = 'http://xplay.bz/'

--local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


--http://fast-torrent.club/toggle_info/ti_386060

--http://fast-torrent.club/download/torrent/428804/%D0%9E%D0%BF%D0%BF%D0%B5%D0%BD%D0%B3%D0%B5%D0%B9%D0%BC%D0%B5%D1%80%20-%20Oppenheimer%20(2023)%20HDRip%20%7C%20LineFilm%20%7C%20IMAX.torrent


--local HOME = 'http://fast-fiml.ru'
--local HOME = 'http://fast-torrent.ru'
local HOME = 'http://fast-torrent.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




local conn1 = client.new()
conn1['encoding'] = 'windows-1251'
conn1['root'] = HOME_SLASH

--HOME = 'http://www.fast-film.ru'
--HOME = 'http://www.fast-fiml.ru'


--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

-- #self/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/
-- #stream/url=http://xplay.bz/
-- #stream/url=http://staticdata.appinfo.su/staticfiles/fimg/open.png
-- #stream/url=http://xplay.bz/list
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka%2Flist%3Fcat%3Dfilms
-- #stream/url=http://imboom.ru/?ma=playlist
-- #stream/url=http://imboom.ru/?ma=imboomiptv
-- #stream/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/list



	
	-- #stream/page=2
	-- #stream/page=3
	-- #stream/page=4
	-- #stream/page=5
	-- #stream/page=6
	-- #stream/page=7
	-- #stream/page=8
	-- #stream/page=9
	-- #stream/page=10
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/new/all/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. tostring(page) .. '.html'
		end

        local x = conn:load(url)


       
  	for url, image, title in string.gmatch(x, '<div class=.-film%-wrap.-href=.-(/.-html).-itemprop="image" content="(.-)".-itemprop="name">(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})

		
		end
        
		
          
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       table.insert(t, {title = 'КОЛЛЕКЦИИ', mrl = '#stream/q=collection&id=' .. '/favorite/public/', image = '#self/film.png'})
  
  
  
  
  
    	table.insert(t, {title = 'Новые коллекции', mrl = '#stream/q=collectionz&id=' .. '?order=1',image = '#self/film.png'})

     table.insert(t, {title = 'Самые большие коллекции', mrl = '#stream/q=collectionz&id=' .. '?order=2',image = '#self/film.png'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/q=collectionz&id=' .. '?order=6',image = '#self/film.png'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/q=collectionz&id=' .. '?order=3',image = '#self/film.png'})
	
	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/q=collectionz&id=' .. '?order=4',image = '#self/film.png'})

table.insert(t, {title = 'Поиск по коллекциям', mrl = '#stream/q=searchcoll', image = '#self/search.png'})



	
--http://www.fast-fiml.ru/last-tv-torrent/

 
table.insert(t, {title = 'Теги фильмов', mrl = '#stream/q=tagf', image = '#self/setting.png'})

 table.insert(t, {title = 'Теги сериалов', mrl = '#stream/q=tags', image = '#self/setting.png'})
 
 table.insert(t, {title = 'Теги мультфильмов', mrl = '#stream/q=tagm', image = '#self/setting.png'})
 
 table.insert(t, {title = 'Теги документалки', mrl = '#stream/q=tagd', image = '#self/setting.png'})
 
     	local x = conn:load(HOME .. '/new-torrent/')
   
        
		local slist = string.match(x, '<ul class=.-nav%-menu.-<a href=.->Фильмы</a>(.-)<br/>')
		
		for genre, title in string.gmatch(slist, '<li.-<a href=\'(/.-/).->(.-)</a>') do
	--	table.insert(t, {title = genre, mrl = '#stream/genre=' .. genre})

			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end
    	local x = conn:load(HOME .. '/last-tv-torrent/')
        
		local slist = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
	
   --     for genre, title in string.gmatch(x, '<a href="(.-tv/).->(.-)</a>') do
	
		for genre, title in string.gmatch(slist, '<li.-<a href=\'(/.-tv/).->(.-)</a>') do
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end
		local x = conn:load(HOME .. '/last-multfilm-torrent/')
        
		local slist = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
		for genre, title in string.gmatch(slist, '<li.-<a href=\'(/.-)\'.->(.-)</a>') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end

local x = conn:load(HOME .. '/new/documentary/')
        
		local slist = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
		for genre, title in string.gmatch(slist, '<li.-<a href=\'(/.-)\'.->(.-)</a>') do
			table.insert(t, {title = 'ДОКУМЕНТАЛЬНЫЕ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end






elseif args.q == 'collection' then

local page = tonumber(args.page or 1)

local x = conn:load(HOME .. args.id .. tostring(page) .. '.html')

table.insert(t, {title = 'Поиск по коллекциям', mrl = '#stream/q=searchcoll', image = '#self/search.png'})


 for image, url, title in string.gmatch(x, '<div class=.-float_right collection%-profile.-<img src=.-(http.-)\'.-nav%-icon generic_favorit_controll email%-off.-collection%-item%-head.-<a href=.-(/favorite/public.-)\'.-<big>(.-)<') do
    
    
      --   t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=collections&id=' .. url, image = image})
		end


local url = '#folder/page=' .. tostring(page + 1) .. '&q=collection&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})




elseif args.q == 'collectionz' then

local page = tonumber(args.page or 1)

local x = conn:load(HOME .. '/favorite/public/' .. tostring(page) .. '.html' .. args.id)

table.insert(t, {title = 'Поиск по коллекциям', mrl = '#stream/q=searchcoll', image = '#self/search.png'})


 for image, url, title in string.gmatch(x, '<div class=.-float_right collection%-profile.-<img src=.-(http.-)\'.-nav%-icon generic_favorit_controll email%-off.-collection%-item%-head.-<a href=.-(/favorite/public.-)\'.-<big>(.-)<') do
    
    
      --   t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=collections&id=' .. url, image = image})
		end


local url = '#folder/page=' .. tostring(page + 1) .. '&q=collectionz&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})






elseif args.q == 'collections' then

local page = tonumber(args.page or 1)

local x = conn:load(HOME .. args.id .. tostring(page) .. '.html')

for url, image, title  in string.gmatch(x, '<div class=\'item_main_box2\'.-collection_id=.-<a href=.-(/.-html).-background:.-(http.-jpg).-class=\'use_tooltip item_title\'title=\'(.-)\'') do
        
       url = string.gsub(url, '^(.-)', HOME)
    --   title = string.gsub(title, ''', '')
    --    t['view'] = 'simple'

		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	
	
--	table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})	
		end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=collections&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})




elseif args.q == 'tagf' then

local x = conn:load(HOME .. '/new-torrent/')
        t['view'] = 'simple'
	--	local x = string.match(x, '<em class="nav%-icon nav%-tag_blue.->(.-)<.-Еще Теги')
		
		for genre, title in string.gmatch(x, '<a href=\'(/video/tag/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/setting.png'})
		end

    local x = conn:load(HOME .. '/tags/video/')

     t['view'] = 'simple'
   for genre, image, title in string.gmatch(x, '<div class="item_tag".-<a href=.-(/video/tag/.-/).-background%-image:.-(http.-jpg).-</div>(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/setting.png'})
		end



--http://www.fast-torrent.ru/last-tv-torrent/

elseif args.q == 'tags' then

local x = conn:load(HOME .. '/last-tv-torrent/')
        t['view'] = 'simple'
	--	local x = string.match(x, '<em class="nav%-icon nav%-tag_blue.->(.-)<.-Еще Теги')
		
		for genre, title in string.gmatch(x, '<a href=\'(/tv/tag/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/setting.png'})
		end

    local x = conn:load(HOME .. '/tags/tv/')

     t['view'] = 'simple'
   for genre, image, title in string.gmatch(x, '<div class="item_tag".-<a href=.-(/tv/tag/.-/).-background%-image:.-(http.-jpg).-</div>(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/setting.png'})
		end


--http://www.fast-torrent.ru/last-multfilm-torrent/

elseif args.q == 'tagm' then

local x = conn:load(HOME .. '/last-multfilm-torrent/')
        t['view'] = 'simple'
	--	local x = string.match(x, '<em class="nav%-icon nav%-tag_blue.->(.-)<.-Еще Теги')
		
		for genre, title in string.gmatch(x, '<a href=\'(/multfilm/tag/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/setting.png'})
		end

    local x = conn:load(HOME .. '/tags/multfilm/')

     t['view'] = 'simple'
   for genre, image, title in string.gmatch(x, '<div class="item_tag".-<a href=.-(/multfilm/tag/.-/).-background%-image:.-(http.-jpg).-</div>(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/setting.png'})
		end


--http://www.fast-torrent.ru/new/documentary/

elseif args.q == 'tagd' then

local x = conn:load(HOME .. '/new/documentary/')
        t['view'] = 'simple'
	--	local x = string.match(x, '<em class="nav%-icon nav%-tag_blue.->(.-)<.-Еще Теги')
		
		for genre, title in string.gmatch(x, '<a href=\'(/documentary/tag/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/setting.png'})
		end

    local x = conn:load(HOME .. '/tags/documentary/')

     t['view'] = 'simple'
   for genre, image, title in string.gmatch(x, '<div class="item_tag".-<a href=.-(/documentary/tag/.-/).-background%-image:.-(http.-jpg).-</div>(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/setting.png'})
		end



elseif args.q == 'actor' then

     local x = conn:load(HOME .. args.id)
    
    t['view'] = 'simple'
--http://www.fast-torrent.ru/film/chuzhoj.html

  local slist = string.match(x, '<strong>Режиссер(.-)desc')
	
--	if slist then
		
		for genre, title in string.gmatch(slist, 'href=.-(/video/actor/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/setting.png'})
		
end

elseif args.q == 'coll' then

     local x = conn:load(HOME .. args.id)
    
  --  t['view'] = 'simple'
--http://www.fast-torrent.ru/film/chuzhoj.html

  --local slist = string.match(x, '<p itemprop="description"(.-)end')
	
--	if slist then
		
		for title, genre, image in string.gmatch(x, '<td class=\'use_tooltip\' title="(.-):.-<a href=\'(/favorite/public/.-)\'.-<img src="(.-)"') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		
end

elseif args.q == 'pohoj' then

     local x = conn:load(HOME .. args.id)
    
  --  t['view'] = 'simple'
--http://www.fast-torrent.ru/film/chuzhoj.html

 -- local slist = string.match(x, '<p itemprop="description"(.-)/favorite/public')

    for url, image, title  in string.gmatch(x, '<li class="use_tooltip anthologyitem".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
   
   url = string.gsub(url, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})

end


--<a href="/favorite/public/




--http://fast-torrent.club/favorite/public/%D0%A3%D0%B6%D0%B0%D1%81/

elseif args.q == 'searchcoll' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/favorite/public/' .. urlencode(args.keyword) .. '/' .. tostring(page) .. '.html'

		
		local x = conn:load(url)

for image, url, title in string.gmatch(x, '<div class=.-float_right collection%-profile.-<img src=.-(http.-)\'.-nav%-icon generic_favorit_controll email%-off.-collection%-item%-head.-<a href=.-(/favorite/public.-)\'.-<big>(.-)<') do
    
    
         t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=collections&id=' .. url, image = image})
		end

local url = '#folder/q=searchcoll&keyword=' .. urlencode(args.keyword) .. '/' ..  tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		

        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = 'http://www.fast-torrent.ru/search/' .. urlencode(args.keyword) .. '/' .. tostring(page) .. '.html'

		
		local x = conn:load(url)
		
        for url, image, title, total in string.gmatch(x, '<div class="film%-wrap".-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)</span>(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
       --   table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
			table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '/' ..  tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
		
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?id=106291&kinopoisk_id=1355296
	
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?kinopoisk_id=1355296&title=&original_title=&s=1
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-%)).-</h1>')
		t['description'] = parse_match(x,'<meta itemprop="description" content="(.-)"')
        t['poster'] = args.p
	--	t['poster'] = parse_match(x,'var test_image.-(http.-jpg)')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Жанр</strong>:.-)</p>',  
				})



--for id in string.gmatch(x, '<p itemprop="description"(.-)/favorite/public/') do
     
     
--table.insert(t, {title = id, mrl = '#stream/q=videot&id=' .. id, image = image})
--		end	
     
     
    for id1, id2 in string.gmatch(x, '<h1><span.->(.-)</span>.-%((.-)%)') do        
        
    --   title = urlencode(title)
     
 --    title = string.gsub(title, '+', '%%20')
      

   table.insert(t, {title = 'Смотреть', mrl = '#stream/q=jacred&id1=' .. id1 .. '&id2=' .. id2, image = image})
		
		end



for id3, id1, id2 in string.gmatch(x, 'var kinopoisk_id.-= (.-);.-<h1><span.->(.-)<.-%((.-)%)') do

table.insert(t, {title = 'Источники', mrl = '#stream/q=video&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
		
		end

   for id in string.gmatch(x, '<link rel="canonical" href="(/.-)"') do
    table.insert(t, {title = 'В ролях', mrl = '#stream/q=actor&id=' .. id, image = image})
	end	
    
    for id in string.gmatch(x, '<link rel="canonical" href="(/.-)"') do
    table.insert(t, {title = 'Похожие', mrl = '#stream/q=pohoj&id=' .. id, image = image})
	end	
    
    
   for id in string.gmatch(x, '<link rel="canonical" href="(/.-)"') do
    table.insert(t, {title = 'В коллекциях', mrl = '#stream/q=coll&id=' .. id, image = image})
	end	

--<a href="/favorite/public/




		
		
  --   url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
   
  
  
  
  
  
  
  
  
  
  
   elseif args.q == 'torrss' then

     local x = conn:load('https://torrs.ru/search?query=' .. urlencode(args.id1) .. '(' .. args.id2 .. ')')



     x = string.gsub(x, '",', '\\u0026')	
    for title, id in string.gmatch(x,'"size".-"title":"(.-)\\u0026.-"magnet":"magnet:?.-btih:(.-)\\u0026') do
      

        id = id:lower()
        t['view'] = 'simple'
   
   id = string.gsub(id, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/serial/') .. '?tr='

     table.insert(t, {title = title, mrl = '#stream/q=videot&id=' .. id, image = image})
		end	
	
    elseif args.q == 'videot' then

  --    args.id = args.id:lower() 

   local x = conn:load(args.id)
      

    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end



    elseif args.q == 'video' then

       t['view'] = 'simple'



  --  table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3, image = image})

     


  
  
  table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
-- table.insert(t, {title = 'Hdvb2', mrl = '#stream/q=hdvbf&id3=' .. args.id3})
  
table.insert(t, {title = 'Zagonka', mrl = '#stream/q=zagonka&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})

--  table.insert(t, {title = 'Hdvb2', mrl = '#stream/q=hdvb2&id3=' .. args.id3})
  
  
 -- table.insert(t, {title = 'Flixcdn-mp4', mrl = '#stream/q=flixcdnm&id3=' .. args.id3, image = image})
  
--  table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id3=' .. args.id3, image = image})
  
       table.insert(t, {title = 'Collaps', mrl = '#stream/q=collaps&id3=' .. args.id3})

--table.insert(t, {title = 'Collaps2', mrl = '#stream/q=collaps2&id3=' .. args.id3})



  table.insert(t, {title = 'Collaps-dash', mrl = '#stream/q=collaps-dash&id3=' .. args.id3})
  
       
       table.insert(t, {title = 'Kino4k', mrl = '#stream/q=kino4k&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
   table.insert(t, {title = 'Filmix', mrl = '#stream/q=filmix&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
--table.insert(t, {title = 'Filmix2', mrl = '#stream/q=filmix2&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
 table.insert(t, {title = 'Kinofit', mrl = '#stream/q=kinofit&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 
 
 
 --  table.insert(t, {title = 'Lumex', mrl = '#stream/q=lumex&id3=' .. args.id3})
   
   table.insert(t, {title = 'Videocdn', mrl = '#stream/q=videocdn&id3=' .. args.id3})
 
   
   
   table.insert(t, {title = 'Kinopub', mrl = '#stream/q=kinopub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  table.insert(t, {title = 'Kinoportal', mrl = '#stream/q=kinopubtv&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3})
       
   
   
   
       
    table.insert(t, {title = 'Alloha', mrl = '#stream/q=alloha&id3=' .. args.id3})
 
 -- table.insert(t, {title = 'Mirage', mrl = '#stream/q=mirage&id3=' .. args.id3})
  
  table.insert(t, {title = 'Aladdin', mrl = '#stream/q=spectre&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
 table.insert(t, {title = 'Paladin', mrl = '#stream/q=phantom&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  
  
  
  table.insert(t, {title = 'Mirage', mrl = '#stream/q=mirage&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  table.insert(t, {title = 'Turbo', mrl = '#stream/q=videodb1&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
  
  table.insert(t, {title = 'Videodb', mrl = '#stream/q=videodb&id3=' .. args.id3})
  
  
table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
  
  table.insert(t, {title = 'ZetflixDB', mrl = '#stream/q=zetflixdb&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 table.insert(t, {title = 'TurboDB', mrl = '#stream/q=turbo&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})

table.insert(t, {title = 'Vibix', mrl = '#stream/q=vibix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})


 
table.insert(t, {title = 'Seasonvar', mrl = '#stream/q=seasonvar&id1=' .. args.id1, image = image})
  
  
  
  
  
--  table.insert(t, {title = 'Cdnmovies', mrl = '#stream/q=cdnmovies&id3=' .. args.id3})


--  table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=vdbmovies&id3=' .. args.id3})
  

 
 
  
 
 table.insert(t, {title = 'Fanserial', mrl = '#stream/q=fanserial&id3=' .. args.id3})
 
   
table.insert(t, {title = 'Videx', mrl = '#stream/q=videx&id3=' .. args.id3})
 
  
   table.insert(t, {title = 'Krasview', mrl = '#stream/q=krasview&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
    table.insert(t, {title = 'Awmzone', mrl = '#stream/q=awmzone&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = image})
    
    table.insert(t, {title = 'Anwap', mrl = '#stream/q=anwap&id1=' .. args.id1 .. '&id5=' .. '1' .. '&id6=' .. 'on'})
    
      table.insert(t, {title = 'Rezka', mrl = '#stream/q=hdrezkatest&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
      
   
   table.insert(t, {title = 'HdRezka', mrl = '#stream/q=hdrezka&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
   table.insert(t, {title = 'Kinobase', mrl = '#stream/q=kinobase&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
--table.insert(t, {title = 'Kinotop', mrl = '#stream/q=kinotop&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
 
--table.insert(t, {title = 'Kinoserials', mrl = '#stream/q=videoseed2&id3=' ..  args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 
 
table.insert(t, {title = 'Videohub', mrl = '#stream/q=videohub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  table.insert(t, {title = 'Kinogo', mrl = '#stream/q=kinogox&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
 
 table.insert(t, {title = 'Videoseed', mrl = '#stream/q=videoseed&id3=' ..  args.id3})
 
 
   table.insert(t, {title = 'Vkmovie', mrl = '#stream/q=vkmovie&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
table.insert(t, {title = 'Remux', mrl = '#stream/q=remux&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   
table.insert(t, {title = 'Jacred', mrl = '#stream/q=jacred&id1=' .. args.id1 .. '&id2=' .. args.id2, image = image})
  
  
   
   table.insert(t, {title = 'Jac', mrl = '#stream/q=jac&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Pidtor', mrl = '#stream/q=pidtor&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Torrs', mrl = '#stream/q=torrs&id1=' .. args.id1 .. '&id2=' .. args.id2, image = image})
   
   

   
   table.insert(t, {title = 'Kinotochka', mrl = '#stream/q=kinotochka&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   

   
   
   
   table.insert(t, {title = 'Veo', mrl = '#stream/q=veo&id3=' .. args.id3, image = image})
   
   
table.insert(t, {title = 'Veoveo', mrl = '#stream/q=veoveo&id3=' .. args.id3 .. '&id1=' .. args.id1})

--table.insert(t, {title = 'Rapidcdn', mrl = '#stream/q=rapidcdn&id1=' .. args.id1 .. '&id2=' .. args.id2})




--table.insert(t, {title = 'Xkino', mrl = '#stream/q=xkino&id4=' .. args.id4})

--https://storage.videoseedcdn.com/movies/bd691b21ee132554ba429035fcd60e94f9ccaae8/04a52eaa9575c08e155647bda7b47423:2026011806/1080.mp4:hls:manifest.m3u8

--https://tv-1-kinoserial.net/api_player.php?kp_id=386&token=fbdcf2438c4f9f0ed76121801807891a

--https://storage.videoseedcdn.com/movies/aec50961c21ef09d0040260875ff6627d9728a49/bfd76f0b07fdcc385574bcc1bbc18767:2026011806/1080.mp4:hls:manifest.m3u8

--https://tv-1-videoseedcdn.com/embed/26728/?token=fbdcf2438c4f9f0ed76121801807891a

--https://videoseed.tv/apiv2.php?item=movie&token=5333b968b6a054766ee984eee92d202d&kp=386

--https://videoseed.tv/apiv2.php?item=movie&token=fbdcf2438c4f9f0ed76121801807891a&kp=386
 
-- https://api.videoseed.tv/embed/32489/?token=fbdcf2438c4f9f0ed76121801807891a
 
 
--https://api.videoseed.tv/apiv2.php?item=movie&token=fbdcf2438c4f9f0ed76121801807891a&kp=386
 
 
 
 
-- https://api.rstprgapipt.com/balancer-api/iframe?kp=1338024&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI
 
 
 
-- https://lamp-movie.ru/proxy/ZHIM6TGAty9DENCUXI0WgbWABkCG8d5eYFt9ugGnaifV6o6r4JSbogF6tULIbPy8ubQ2zoTCK7p91ZFpyLN2Z7YbW7aoURb34AcmP8Rj2V237gA+0RssGh+FWHxl56EabeEQbhVAsos4xLa2TRcCY5fayg05xD6Ujjcn9TIBhmKLnGKR\u002BOq5SdPykrmA/9dQRUwcv6hGPPC4RohGLKfc9+k/BdPpgiYpind0xbQrLLKuyLhGqI3IqW+ZG4ei4LUygJ1bCikGN41iVikFBHYLX/PnD9XLxbU+/CgZXJ9fkgHyKt6qW29Obzzc3Hd4DIhFYCM9Yz5oP4ccX/7nlQ/1qo2gh9oVSUYqevvoK7E6SnU=.m3u8
 
 
 --https://evkh.lol
 
-- https://lam.maxvol.pro/lite/kinogo?kinopoisk_id=386&title=чужой&year=1979
 
--http://lampac.egorpomidor.site
 
 -- http://93.183.95.219:11378/lite/kinogo?href=56119-strazhi-galaktiki-chast-3-2023.html
 
--https://lampa.persh1n.ru/lite/kinogo?href=56119-strazhi-galaktiki-chast-3-2023.html

--https://lampa.persh1n.ru/lite/kinogo?rjson=False&title=%D0%A1%D1%82%D1%80%D0%B0%D0%B6%D0%B8+%D0%93%D0%B0%D0%BB%D0%B0%D0%BA%D1%82%D0%B8%D0%BA%D0%B8+%D0%A7%D0%B0%D1%81%D1%82%D1%8C+3+&serial=1&year=2025


--https://lampa.persh1n.ru/lite/kinogo?rjson=False&title=%D0%A1%D1%82%D1%80%D0%B0%D0%B6%D0%B8+%D0%93%D0%B0%D0%BB%D0%B0%D0%BA%D1%82%D0%B8%D0%BA%D0%B8%2E+%D0%A7%D0%B0%D1%81%D1%82%D1%8C+3&serial=1&original_language=ru&year=2023





    elseif args.q == 'flixcdnm' then

 
-- https://cdn0.cdnhub.help/show/kinopoisk/386?domain=piratka.tv
 
 
 local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local')



local slist = string.match(x, '<select name="translator"(.-)movies')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
         
    local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local&translation=' .. id5)



  --  local slist = string.match(x, 'file.-:(.-)CDNquality')

  --  if slist then
 
 for title1, url in string.gmatch(x, '%[(240)](http.-mp4)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
 
 for title1, url in string.gmatch(x, '%[(360)](http.-mp4)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
 
for title1, url in string.gmatch(x, '%[(480)](http.-mp4)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
 
for title1, url in string.gmatch(x, '%[(720)](http.-mp4)') do

url = string.gsub(url, '/480.mp4', '/720.mp4') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
 
for title1, url in string.gmatch(x, '%[(1080)](http.-mp4)') do

url = string.gsub(url, '/480.mp4', '/1080.mp4') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
 
 
   end
end
 



 
    local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local&autoplay=1&extrans=1')



local slist = string.match(x, '<select name="season"(.-)</select>')
  
      if slist then
                                             for id2, title1 in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
                                    

  local slist = string.match(x, '<select name="episode"(.-)</select>')
  
      if slist then
                                            for id4, title2 in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do





  local slist = string.match(x, '<select name="translator"(.-)series')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
 id5 = string.gsub(id5, '^(.-)', 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local&autoplay=1&extrans=1&translation=') 
 
 

    t['view'] = 'simple'

   table.insert(t, {title = title1 .. ' ' .. title2 .. ' ' .. title, mrl = '#stream/q=flixcdns&id3=' .. args.id3 .. '&id5=' .. id5 .. '&id1=' .. title .. '&id2=' .. id2 .. '&id4=' .. id4})

  end
   end
   end
   end
    end
 end
   
   
    
    elseif args.q == 'flixcdns' then  
    
    local x = conn:load(args.id5 .. '&season=' .. args.id2 .. '&episode=' .. args.id4)
    
 --     local slist = string.match(x, 'file.-:(.-)CDNquality')

  --  if slist then
 
 for title, url in string.gmatch(x, '%[(240)](http.-mp4)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
  
for title, url in string.gmatch(x, '%[(360)](http.-mp4)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})

end

for title, url in string.gmatch(x, '%[(480)](http.-mp4)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})

end


for title, url in string.gmatch(x, '%[(720)](http.-mp4)') do

url = string.gsub(url, '/480.mp4', '/720.mp4') 

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})

end


for title, url in string.gmatch(x, '%[(1080)](http.-mp4)') do

url = string.gsub(url, '/480.mp4', '/1080.mp4')  

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})

end


  elseif args.q == 'flixcdn' then

 
-- https://cdn0.cdnhub.help/show/kinopoisk/386?domain=piratka.tv
 
 
 local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local')

--local x = conn:load('https://cdn0.cdnhub.help/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv')

local slist = string.match(x, '<select name="translator"(.-)movies')
 
 
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
         
    local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local&translation=' .. id5)


 


  --  local slist = string.match(x, 'charset(.-)window.PlayerjsEvents')



    if x then
 
 for title1, url in string.gmatch(x, '%[(240)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
   
   for title1, url in string.gmatch(x, '%[(360)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
  
for title1, url in string.gmatch(x, '%[(480)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
   
for title1, url in string.gmatch(x, '%[(720)](http.-m3u8)') do

url = string.gsub(url, '/480.mp4', '/720.mp4')  

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   
for title1, url in string.gmatch(x, '%[(1080)](http.-m3u8)') do

url = string.gsub(url, '/480.mp4', '/1080.mp4')  

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   
   
   end
end
 end



 
    local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local&autoplay=1&extrans=1')



local slist = string.match(x, '<select name="season"(.-)</select>')
  
      if slist then
                                             for id2, title1 in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
                                    

  local slist = string.match(x, '<select name="episode"(.-)</select>')
  
      if slist then
                                            for id4, title2 in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do





  local slist = string.match(x, '<select name="translator"(.-)series')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
 id5 = string.gsub(id5, '^(.-)', 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local&autoplay=1&extrans=1&translation=') 
 
 

    t['view'] = 'simple'

   table.insert(t, {title = title1 .. ' ' .. title2 .. ' ' .. title, mrl = '#stream/q=flixcdns&id3=' .. args.id3 .. '&id5=' .. id5 .. '&id1=' .. title .. '&id2=' .. id2 .. '&id4=' .. id4})

  end
   end
   end
   end
    end
 end
   
   
    
    elseif args.q == 'flixcdns' then  
    
    local x = conn:load(args.id5 .. '&season=' .. args.id2 .. '&episode=' .. args.id4)
    
   --   local slist = string.match(x, 'file.-:(.-)CDNquality')

  --  if slist then
 
 
 for title, url in string.gmatch(x, '%[(240)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
 
 for title, url in string.gmatch(x, '%[(360)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
   
for title, url in string.gmatch(x, '%[(480)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end

for title, url in string.gmatch(x, '%[(720)](http.-m3u8)') do

url = string.gsub(url, '/480.mp4', '/720.mp4') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end

for title, url in string.gmatch(x, '%[(1080)](http.-m3u8)') do

url = string.gsub(url, '/480.mp4', '/1080.mp4')  
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end





--  https://player0.flixcdn.space/show/kinopoisk/386?domain=piratka.tv&autoplay=1&extrans=1&translation=


elseif args.q == 'krasview' then



    local x = conn1:load('https://krasview.ru/movie?mode=vector-search&ajax&query=' .. urlencode(args.id1) .. '+' .. args.id2)

--table.insert(t, {title = 'https://krasview.ru/movie?mode=vector-search&ajax&query=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://krasview.ru/movie?mode=search&ajax&query=' .. urlencode(args.id1) .. ',' .. args.id2})


   for url, total in string.gmatch(x, '<li id=.-<a href=.-(http.-)\'.-alt=\'(.-)\'>') do


--table.insert(t, {title = url, mrl = url})

  
  local headers = {
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
  
  
  
      local x = http.getz(url, headers)



    for id in string.gmatch(x, '<ul class=.-video%-gallery.-itemscope itemtype=.-id=\'v%-(.-)\'') do

t['view'] = 'simple'

table.insert(t, {title = total, mrl = '#stream/q=krasviewvideo&id=' .. id})

end
end






--https://sersoap.ru/series/Game_of_Thrones/?page=2

    local x = conn1:load('https://krasview.ru/series?mode=search&ajax&query=' .. urlencode(args.id1))
    --.. ',' .. args.id2)


    for url, total in string.gmatch(x, '<li id=.-<a href=\'(http.-)\'.-alt=\'(.-)\'') do
         t['view'] = 'simple'
 
    table.insert(t, {title = tolazy(total), mrl = '#stream/q=krasviews&id=' .. url})
    end
 
   elseif args.q == 'krasviews' then

local page = tonumber(args.page or 1)

      local x = conn1:load(args.id .. '?page=' .. tostring(page))



   for id, title in string.gmatch(x, '<li itemprop=\'itemListElement\' itemscope itemtype=.-id=\'v%-(.-)\'.-alt=\'(.-)\'') do

t['view'] = 'simple'

table.insert(t, {title = title, mrl = '#stream/q=krasviewvideo&id=' .. id})


end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=krasviews&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})





elseif args.q == 'krasviewvideo' then

local headers = {
    ["Host"] = "zedfilm.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://zedfilm.ru/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
     args.id = string.gsub(args.id, '^(.-)', 'https://zedfilm.ru/') 
 
 --  table.insert(t, {title = args.id, mrl = args.id})
   
     local x = http.getz(args.id, headers)
 
 local slist = string.match(x, 'video_Init.-\'(.-)\'') 
 
 
    slist = base64_decode(slist)
   
  --local url  = string.match(slist, '"url":"(http.-).mp.-"') 
   for url in string.gmatch(slist, '"url":"(http.-).mp.-"') do
    
    
      url = string.gsub(url, 'media', 'm')
     -- url = string.gsub(url, '^(.-)', '.mp4')
      
      if url then
    print(url2)
    return {view = 'playback', mrl = url .. '.mp4', seekable = 'true', direct = 'true'}
-- end
      
 
end
end






--https://m4.krasview.ru/video/07022833dea865d/eb9e2b471a474eb-1080.mp4

  --http://93.183.95.219:11378
 
 
 
elseif args.q == 'kinogox' then

local url = 'https://kinogo2026.com/index.php?story=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&do=search&subaction=search'


--https://proxy4.rte.net.ru/https://kinogo.biz/index.php?story=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB+2025&do=search&subaction=search

--https://kinogo2026.com/index.php?story=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB+2025&do=search&subaction=search


 
local x = conn:load(url)


--table.insert(t, {title = url, mrl = url})

 for url1, title in string.gmatch(x, '<h2.-href.-(http.-html).->(.-)<') do
 

 local x = conn:load(url1)
 
--table.insert(t, {title = url1, mrl = url1})
 
 
 
--local url = "host.cinemap.cc"

 
 local headers2 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Sec-Fetch-Storage-Access"] = "none",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://kinogo2026.com/",
    ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}
 
 local url2 = string.match(x, '(//cinemar.cc/embed/.-)"')
 

 
--  https://proxy4.rte.net.ru/
  
 local url = 'https:' .. url2


 local x = http.getz(url, headers2)



 for url3 in string.gmatch(x,'\"file\":\".-(W3sia.-)%"+') do
 
 url3 = string.gsub(url3,'#','')
 

 

 
url3 = base64_decode(http.urldecode(url3))
 


 url3 = string.gsub(url3, '\\u0410', 'А')
      url3 = string.gsub(url3, '\\u0430', 'а')
       
       url3 = string.gsub(url3, '\\u0411', 'Б')
       url3 = string.gsub(url3, '\\u0431', 'б')  
       url3 = string.gsub(url3, '\\u0412', 'В')
      url3 = string.gsub(url3, '\\u0432', 'в')
       url3 = string.gsub(url3, '\\u0413', 'Г')
       url3 = string.gsub(url3, '\\u0433', 'г')  
      url3 = string.gsub(url3, '\\u0414', 'Д')
      url3 = string.gsub(url3, '\\u0434', 'д')
       url3 = string.gsub(url3, '\\u0415', 'Е')
       url3 = string.gsub(url3, '\\u0435', 'е')  
      url3 = string.gsub(url3, '\\u0401', 'Ё')
      url3 = string.gsub(url3, '\\u0451', 'ё')
       url3 = string.gsub(url3, '\\u0416', 'Ж')
       url3 = string.gsub(url3, '\\u0436', 'ж')  
       url3 = string.gsub(url3, '\\u0417', 'З')
      url3 = string.gsub(url3, '\\u0437', 'з')
       url3 = string.gsub(url3, '\\u0418', 'И')
       url3 = string.gsub(url3, '\\u0438', 'и')  
       url3 = string.gsub(url3, '\\u0419', 'Й')
      url3 = string.gsub(url3, '\\u0439', 'й')
       url3 = string.gsub(url3, '\\u041a', 'К')
       url3 = string.gsub(url3, '\\u043a', 'к')  
       url3 = string.gsub(url3, '\\u041b', 'Л')
       url3 = string.gsub(url3, '\\u043b', 'л')
       url3 = string.gsub(url3, '\\u041c', 'М')
       url3 = string.gsub(url3, '\\u043c', 'м')
       url3 = string.gsub(url3, '\\u041d', 'Н')
       url3 = string.gsub(url3, '\\u043d', 'н')
       url3 = string.gsub(url3, '\\u041e', 'О')
       url3 = string.gsub(url3, '\\u043e', 'о')
       url3 = string.gsub(url3, '\\u041f', 'П')
       url3 = string.gsub(url3, '\\u043f', 'п')
       url3 = string.gsub(url3, '\\u0420', 'Р')
       url3 = string.gsub(url3, '\\u0440', 'р')
       url3 = string.gsub(url3, '\\u0421', 'С')
       url3 = string.gsub(url3, '\\u0441', 'с')
       url3 = string.gsub(url3, '\\u0422', 'Т')
       url3 = string.gsub(url3, '\\u0442', 'т')
       url3 = string.gsub(url3, '\\u0423', 'У')
       url3 = string.gsub(url3, '\\u0443', 'у')
       url3 = string.gsub(url3, '\\u0424', 'Ф')
        url3 = string.gsub(url3, '\\u0444', 'ф')
        url3 = string.gsub(url3, '\\u0425', 'Х')
        url3 = string.gsub(url3, '\\u0445', 'х')
        url3 = string.gsub(url3, '\\u0426', 'Ц')
        url3 = string.gsub(url3, '\\u0446', 'ц')
        url3 = string.gsub(url3, '\\u0427', 'Ч')
        url3 = string.gsub(url3, '\\u0447', 'ч')
        url3 = string.gsub(url3, '\\u0428', 'Ш')
        url3 = string.gsub(url3, '\\u0448', 'ш')
        url3 = string.gsub(url3, '\\u0429', 'Щ')
        url3 = string.gsub(url3, '\\u0449', 'щ')
        url3 = string.gsub(url3, '\\u042a', 'Ъ')
        url3 = string.gsub(url3, '\\u044a', 'ъ')
        url3 = string.gsub(url3, '\\u042b', 'Ы')
        url3 = string.gsub(url3, '\\u044b', 'ы')
        url3 = string.gsub(url3, '\\u042c', 'Ь')
        url3 = string.gsub(url3, '\\u044c', 'ь')
        url3 = string.gsub(url3, '\\u042d', 'Э')
        url3 = string.gsub(url3, '\\u044d', 'э')
        url3 = string.gsub(url3, '\\u042e', 'Ю')
        url3 = string.gsub(url3, '\\u044e', 'ю')
        url3 = string.gsub(url3, '\\u042f', 'Я')
        url3 = string.gsub(url3, '\\u044f', 'я')
        url3 = string.gsub(url3, '\\u00ab', '<<')
        url3 = string.gsub(url3, '\\u00bb', '>>')
        url3 = string.gsub(url3, '\\u2014', '-')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/ua.png\\" alt=\\"\\">', '')


 
for title, title1, url4 in string.gmatch(url3, '{"id":".-","src_id":.-,"voice_id":.-,"title":"(.-)","title2":"(.-)",.-"file":"(.-m3u8)"') do
 
 t['view'] = 'simple'
 
 url4 = string.gsub(url4,'\\','')
 
 url4 = string.gsub(url4,'^(.-)','https:')
 
 url4 = string.gsub(url4,'/hls','/1080.mp4:hls:manifest.')
 

 
 table.insert(t, {title = '(1080p) ' .. title1 .. title, mrl = url4})

end


 for title, title1, url4 in string.gmatch(url3, '{"id":".-","src_id":.-,"voice_id":.-,"title":"(.-)","title2":"(.-)",.-"file":"(.-m3u8)"') do
 
 t['view'] = 'simple'
 
 url4 = string.gsub(url4,'\\','')
 
 url4 = string.gsub(url4,'^(.-)','https:')
 
 url4 = string.gsub(url4,'/hls','/720.mp4:hls:manifest.')
 

 
 table.insert(t, {title = '(720p) ' .. title1 .. title, mrl = url4})

end


for title, title1, url4 in string.gmatch(url3, '{"id":".-","src_id":.-,"voice_id":.-,"title":"(.-)","title2":"(.-)",.-"file":"(.-m3u8)"') do
 
 t['view'] = 'simple'
 
 url4 = string.gsub(url4,'\\','')
 
 url4 = string.gsub(url4,'^(.-)','https:')
 
 url4 = string.gsub(url4,'/hls','/480.mp4:hls:manifest.')
 

 
 table.insert(t, {title = '(480p) ' .. title1 .. title, mrl = url4})

end

for title, title1, url4 in string.gmatch(url3, '{"id":".-","src_id":.-,"voice_id":.-,"title":"(.-)","title2":"(.-)",.-"file":"(.-m3u8)"') do
 
 t['view'] = 'simple'
 
 url4 = string.gsub(url4,'\\','')
 
 url4 = string.gsub(url4,'^(.-)','https:')
 
 url4 = string.gsub(url4,'/hls','/360.mp4:hls:manifest.')
 

 
 table.insert(t, {title = '(360p) ' .. title1 .. title, mrl = url4})

end


 end
 end
 
 
 
 
 
 
  elseif args.q == 'kinogo' then
 
 local x = conn:load('http://lampac.egorpomidor.site/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
 --table.insert(t, {title = 'http://lampac.egorpomidor.site/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'http://lampac.egorpomidor.site/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
 
    for url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"http.-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
  
  
      
      
 url = string.gsub(url, '\\u0026', '&')
     url = string.gsub(url, '\\u002B', '+')
  
            url = string.gsub(url, '^(.-)', 'http://lampac.egorpomidor.site') 
     


      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total), mrl = url})

       
    end
 --   end
 
 
 
 for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
      --  url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    

      local x = conn:load(url2)

  -- x = string.gsub(x, '< img', '')
   --  x = string.gsub(x, '<img', '')
   --  x = string.gsub(x, '">', '')
  
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do
         
  
         url3 = string.gsub(url3, '\\u0026', '&')
 
     -- url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
    
       
    
     local x = conn:load(url3)
     
    -- x = string.gsub(x, '<img', '')
  --   x = string.gsub(x, '">', '')
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
  
            url4 = string.gsub(url4, '^(.-)', 'http://lampac.egorpomidor.site') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end
 
 
-- https://a7c5ea7c.obrut.show/embed/1EjM/content/MTM4EjM?domain=gokino.su
 
 
--https://gokino.su/vv-player.php?path=/&movie_id=14981

 elseif args.q == 'veo' then

    local x = conn:load('https://api.rstprgapipt.com/balancer-api/iframe?kp=' .. args.id3 .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI')
 
  
 
   for id in string.gmatch(x, 'MOVIE_ID=(.-);') do
 


 local x = conn:load('https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI')
 
-- https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=14981&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI
 
 local slist = string.match(x, '"order":0.-"season".-"order":0(.-)}]}]')
 
 if slist then
 
 for url1, title in string.gmatch(slist, '"filepath":"(http.-)".-"title":"(.-)"') do
 
 t['view'] = 'simple'

   table.insert(t, {title = '(1080p)' .. title, mrl = url1})
end
end


 
 
 
 for total, total1, url1, title in string.gmatch(x, '"order":(.-),"season":.-"order":(.-)}.-"filepath":"(http.-)".-"title":"(.-)"') do
 
 --if total > 0 then
 
 t['view'] = 'simple'

 --= string.gsub(x, '0 сезон 0 серия', '')


   table.insert(t, {title = total1 .. ' ' .. 'сезон ' .. total .. ' серия ' .. title, mrl = url1})
-- end
 end

end
 
 
-- https://storage.videoseedcdn.com/movies/aec50961c21ef09d0040260875ff6627d9728a49/bfd76f0b07fdcc385574bcc1bbc18767:2026011806/1080.mp4:hls:manifest.m3u8
 
 
 elseif args.q == 'videoseed2' then
 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
   for url in string.gmatch(x, 'status.-"iframe":"http.-(/embed.-)"') do



   
   local headers = {
    ["Host"] = "kinoserials.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://kinoserials.tv/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 
 

   
 local x = http.getz('https://kinoserials.tv' .. url, headers)
 
 
 local slist = string.match(x, '"#2(.-\"+)') 
 
 if slist then
 
 slist = string.gsub(slist, '|||', '')
 
 slist = string.gsub(slist, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 slist = string.gsub(slist, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 slist = string.gsub(slist, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
slist = string.gsub(slist, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

slist = string.gsub(slist, 'N3IzYXcyRWF0MD', '')

slist = string.gsub(slist, 'NBaUNHQTI2ME9CcWc', '')
 
slist = string.gsub(slist, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    


slist = http.urldecode(base64_decode(slist))


slist = string.gsub(slist, ';{', '"{')



for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   

   
 t['view'] = 'simple'


table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})
end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   

   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end
 end
end
 
 

 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')
	
	
x = string.gsub(x, 'tv%-1%-', '')

x = string.gsub(x, '%- %d сезон"', '')


        
 for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"http.-(/embed.-)"') do
 

   
   t['view'] = 'simple'
   
 table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds2&id=' .. id})
 
 end

elseif args.q == 'videoseeds2' then

local headers = {
    ["Host"] = "kinoserials.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://kinoserials.tv/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}


local x = http.getz('https://kinoserials.tv' .. args.id)



local x = string.match(x, '#2(.-\"+)')
 
 if x then
 
 x = string.gsub(x, '|||', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    x =http.urldecode(base64_decode(x))


x = string.gsub(x, ';{', '"{')


 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   

   
 t['view'] = 'simple'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   

 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end
 end








 
 elseif args.q == 'videoseed' then

local url = 'https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3


  local headers = {
    ["Host"] = "api.videoseed.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

      local x = http.get(url, headers)
 

 
    for url in string.gmatch(x, 'status.-"iframe":"(http.-)"') do

  url = string.gsub(url, '\\', '')

--tv-3-kinolot.net

local headers = {

    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["Cookie"] = "PHPSESSID=0f872a7617175500ab7b29ec4dbba1b4;kt_rt_token=6091e1d0bf421f73804d2f0dcc2bf1cf;kt_ips=159.69.148.100",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache",
["Vary"] = "Accept-Encoding",
["Content-Encoding"] = "gzip"
}

   
  
     local x = http.getz(url, headers)
 

   
    local slist = string.match(x, '#2(.-)\"+') 
 
 
 
 if slist then
 
 
 slist = string.gsub(slist, '|||', '')
 
 slist = string.gsub(slist, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 slist = string.gsub(slist, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 slist = string.gsub(slist, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
slist = string.gsub(slist, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

slist = string.gsub(slist, 'N3IzYXcyRWF0MD', '')

slist = string.gsub(slist, 'NBaUNHQTI2ME9CcWc', '')
 
slist = string.gsub(slist, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')


    slist = base64_decode(slist)

slist = string.gsub(slist, ';{', '"{')

--table.insert(t, {title = x, mrl = x})


--local slist = string.match(x, '"file":"(.-)"') 
 

   for total, url1 in string.gmatch(slist,'"{(.-)}.-(http.-m3u8)') do
  
  
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end

end
end


local url = 'https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3



    local headers = {
    ["Host"] = "api.videoseed.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

      local x = http.get(url, headers)
 

 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')
	
	
--x = string.gsub(x, 'tv%-1%-', '')

x = string.gsub(x, '%- %d сезон"', '')




 for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"(http.-)"') do
 

   
   t['view'] = 'simple'
   
 table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds&id=' .. id})
 
 end
 
 elseif args.q == 'videoseeds' then

local headers = {
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

 local x = http.getz(args.id, headers)


 
    local x = string.match(x, '#2(.-)\"+') 
 
 if x then
 
 
 
 x = string.gsub(x, '|||', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

--http.urlencode(
    x =http.urldecode(base64_decode(x))

x = string.gsub(x, ';{', '"{')

  -- local slist = string.match(x, '"file":"(.-)"')


 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
  
  
  
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end
end
 

 
 
 
 
 
 --https://movie.kinodostuptut.com/search?filters={"yearRange":[1979]}&q=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%2C
 
 elseif args.q == 'rapidcdn' then
  
  
   local x = conn:load('https://movie.kinodostuptut.com/search?filters={"yearRange":[' .. args.id2 .. ']}&q=' .. urlencode(args.id1))
 
  t['view'] = 'simple'

      
      for url, image, title, total in string.gmatch(x, '<a class="group relative block.-href="(.-)".-<img.-src="(.-)".-<span class="text%-sm.->(.-)</span>.-class="text%-xs.->(.-)</span>') do
      
    url = string.gsub(url, '^(.-)', 'https://movie.kinodostuptut.com')
    
    table.insert(t, {title = tolazy(title) .. ',' .. total, mrl = '#stream/q=rapidcdns&id=' .. url, image = image})

     end 
 
 

      elseif args.q == 'rapidcdns' then
    
   -- Хищник: Планета смерти | сезон 0 | эпизод 0 в хорошем качестве без регистрации, смс и vpn\
    
      local x = conn:load(args.id)

      for url, title in string.gmatch(x, '"m3u8MasterFilePath.-"(http.-)\\".-{.-"title.-":.-"Смотреть сериал (.-)в хорошем') do
     
     
     title = string.gsub(title, '| сезон 0 | эпизод 0', '')
     
     t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = url})

     end 
 
    elseif args.q == 'xkino' then
  
  
 -- https://fast.xkino.ne/play.php?kp=7418579&player=player&name=Идеальная афера&year=2025)
 
-- https://fast.xkino.net/Hischnik_planeta_smerti_2025.mp4" 
 -- <div>360p</div
  
-- https://fast.xkino.net/Hischnik_planeta_smerti_2025.hd.mp4" 
 -- <div>720p</div
 
 --https://ru.kinozona.net/play.php?player=player&kp=386&name=чужой&year=1979
 
-- https://fast.xkino.net/Hischnik_planeta_smerti_2025.1080.mp4
  
--  https://ru.kinozona.net/tor.php?id=17117
  
  --  https://ru.kinozona.net/vote.php?play_id=17117
    
 -- https://ru.kinozona.net/stars.php?name=alien
--  https://xkino.net
  
      local x = conn:load('https://ru.kinozona.net/stars.php?name=' .. urlencode(args.id4))
  
  t['view'] = 'simple'

      
      for url, image, title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<br.->(.-)</a>') do
 
      
  --   https://xkino.net/12806-zaslanec-iz-kosmosa-(4-sezon).html 
      
      
    url = string.gsub(url, '^(.-)', 'https://ru.kinozona.net/')

image = string.gsub(image, '/posters/mini/', '')

image = string.gsub(image, '^(.-)', 'https://img.xkino.net/')


  
   table.insert(t, {title = tolazy(title), mrl = '#stream/q=xkinos&id=' .. url})

     end 
  
  
  elseif args.q == 'xkinos' then
    
    
      local x = conn:load(args.id)
  
  
  local slist = string.match(x, 'new Playerjs.-file(.-)poster')

if slist then


for  total, url2, url3 in string.gmatch(slist, '%[(.-)](http.-/mp4/)(.-mp4)') do
  
t['view'] = 'simple'

    table.insert(t, {title = tolazy(total), mrl = url2 .. url3})

     end 
  end
  
  
  
    for url4, url5 in string.gmatch(x, 'Playerjs.-file:"(http.-txt?)(.-)"') do
  
     local x = conn:load(url4 .. url5)
  
  
for total3 in string.gmatch(x, '"title":"(.-)"') do
  
  local slist = string.match(x, 'file(.-)}')

    if slist then


for  total4, url6 in string.gmatch(slist, '%[(.-)](http.-mp4)') do
  
t['view'] = 'simple'
  
  table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url6})

     end 
  end
  end
  end
  
  
  
  
 -- http://seasonvar.ru/?mode=search&query
  
  
  elseif args.q == 'seasonvar' then
    
   

    
      local x = conn:load('http://seasonvar.ru/?mode=search&query=' .. urlencode(args.id1))
  
  
 -- local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
     --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'http:')
        
        t['view'] = 'simple'
		
			
--https://seasonvar.ru/serial-21789-Mama_moej_docheri_pspnayd.html
  
--  var pl = {'0': "https://seasonvar.ru/playls2/21761794037102e3e58571b1ee97a194/trans/21789/plist.txt?time=1772428242"};
    
  
  
  
  local x = conn:load('http://seasonvar.ru' .. url)
 
 
 local slist = string.match(x, '<ul class="tabs%-result">(.-)</ul>')
      
if slist then

   for url2, total in string.gmatch(slist, '<a href="(.-)".-Сериал (.-)<') do
   
  table.insert(t, {title = tolazy(total), mrl = '#stream/q=seasonvars&id=' .. url2, image = image})
		
		end
end
end



   
   elseif args.q == 'seasonvars' then
  
  
 local headers = {['X-Requested-With'] = 'XMLHttpRequest',
 ['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'}
   
   local x = conn:load('https://apn-latest.onrender.com/http://seasonvar.ru' .. args.id)
    
 --  url = url_for(x)
  
 -- url = urldecode(url)
   
   -- table.insert(t,{title = url, mrl = url})
        
      --  local x = conn:load(url2)
 
 for id1, total1 in string.gmatch(x,'"(/playls2.-)".-data%-translate%-percent=.->(.-)</li>') do
 
 --for total1 in string.gmatch(x,'/playls.-data%-translate%-percent=.->(.-)</li>') do
 
    --    for id1 in string.gmatch(x,'player = new Playerjs.-var pl.-"(/playls2.-)"') do
        
        
local id2 = string.match(x,'(playls.-)"')
 
 url = url_for(id2)
    
    table.insert(t,{title = url, mrl = url})
 
 
 
    --    table.insert(t,{title = 'http://seasonvar.ru' .. id2, mrl = 'http://seasonvar.ru' .. id2})
            
    local x = conn:load('https://apn-latest.onrender.com/http://seasonvar.ru' .. id1)
    
    table.insert(t,{title = 'http://seasonvar.ru' .. id1, mrl = 'http://seasonvar.ru' .. id1})
    
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id2 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id2 = string.gsub(id2, '\\/\\/b2xvbG8=', '') 
      
      id2=http.urldecode(base64_decode(id2))
       id2 = string.gsub(id2, '^(.-)', 'http:') 
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title1) .. ' ' .. total1, mrl = id2})
            end  
	end
 -- end
 
local x = conn:load('http://seasonvar.ru' .. args.id)
        
 
 local id2 = string.match(x,'var pl.-(/playls2.-)"')

            local x = conn:load('http://seasonvar.ru' .. id2)
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id3 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id3 = string.gsub(id3, '\\/\\/b2xvbG8=', '') 
      
      id3=http.urldecode(base64_decode(id3))
       id3 = string.gsub(id3, '^(.-)', 'http:') 
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title1), mrl = id3})
            end  
            
            
  
  
  
elseif args.q == 'zetflixdb' then
  
  
--http://31.129.234.181:80/lite/zetflix?kinopoisk_id=386&title=чужой&year=1979&uid=guest
 
    local x = http.get('http://31.129.234.181/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=guest')
   
    
   for total, url, title in string.gmatch(x, 'method.-url.-quality.-"(%d+p)".-http.-(/proxy.-)".-videos__item%-title.->(.-)<') do
 
 url = string.gsub(url, '.m3u8', '')
 
    url = string.gsub(url, '\\u0026', '')
    url = string.gsub(url, '^(.-)', 'http://31.129.234.181') .. '.m3u8'
    --'&uid=guest'
     
      t['view'] = 'simple'
    
    
   -- table.insert(t, {title = url, mrl = url})
    
    table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = url})
     end 
 
   
    for total, url, title in string.gmatch(x, 'videos__item videos__movie.-method.-url.-quality.-/proxy.-,"(%d+p)".-http.-(/proxy.-)".-videos__item%-title.->(.-)<') do
 
    url = string.gsub(url, '.m3u8', '')
 
    url = string.gsub(url, '\\u0026', '')
    url = string.gsub(url, '^(.-)', 'http://31.129.234.181') .. '.m3u8'
    --'&uid=guest'
     
      t['view'] = 'simple'
    
    table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = url})
     end 
    
for total, url, title in string.gmatch(x, 'videos__item videos__movie.-method.-url.-quality.-/proxy.-/proxy.-,"(%d+p)".-http.-(/proxy.-)".-videos__item%-title.->(.-)<') do
 
    url = string.gsub(url, '.m3u8', '')
 
    url = string.gsub(url, '\\u0026', '')
    url = string.gsub(url, '^(.-)', 'http://31.129.234.181') .. '.m3u8'
    --'&uid=guest'
     
      t['view'] = 'simple'
    
    table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = url})
     end 
    
for total, url, title in string.gmatch(x, 'videos__item videos__movie.-method.-url.-quality.-/proxy.-/proxy.-/proxy.-,"(%d+p)".-http.-(/proxy.-)".-videos__item%-title.->(.-)<') do
 
    url = string.gsub(url, '.m3u8', '')
 
    url = string.gsub(url, '\\u0026', '')
    url = string.gsub(url, '^(.-)', 'http://31.129.234.181') .. '.m3u8'
    --'&uid=guest'
     
      t['view'] = 'simple'
    
    table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = url})
     end 
    
for total, url, title in string.gmatch(x, 'videos__item videos__movie.-method.-url.-quality.-/proxy.-/proxy.-/proxy.-/proxy.-,"(%d+p)".-http.-(/proxy.-)".-videos__item%-title.->(.-)<') do
 
    url = string.gsub(url, '.m3u8', '')
 
    url = string.gsub(url, '\\u0026', '')
    url = string.gsub(url, '^(.-)', 'http://31.129.234.181') .. '.m3u8'
    --'&uid=guest'
     
      t['view'] = 'simple'
    
    table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = url})
     end
   
   
    
    

local x = http.get('http://31.129.234.181/lite/zetflix?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=guest')
   


      for  url2, total in string.gmatch(x, 'class="videos__item videos__season.-"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)<') do
 
url2 = string.gsub(url2, '\\u0026', '&') 
 url2 = string.gsub(url2, '\\u002B', '+') 
 
 
    -- url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url2 .. '&uid=guest')
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

url3 = string.gsub(url3, '\\u0026', '&') 
url3 = string.gsub(url3, '\\u002B', '+') 

    --  url3 = string.gsub(url3, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url3 .. '&uid=guest')

   x = string.gsub(x, '\\u0026', '&') 
x = string.gsub(x, '\\u002B', '+') 
     
   
    --http://31.129.234.181/lite/zetflix/video?serial=1&kinopoisk_id=(.-)&.-&s=(.-)&e=(.-)&t=(.-)"
   
   
   
      for id, id1, id2, id3, total2 in string.gmatch(x, 'class="videos__item videos__movie.-"method".-"call".-"url".-http.-kinopoisk_id=(.-)&.-&s=(.-)&e=(.-)&t=(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
   -- url4 = string.gsub(url4, '^(.-)', 'http://lam.maxvol.pro')
    
     
 --    url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = '#stream/q=zetflixdbs&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

     end
     end
    end

elseif args.q == 'zetflixdbs' then

local x = http.getz('http://31.129.234.181/lite/zetflix/video?serial=1&kinopoisk_id=' .. args.id .. '&s=' .. args.id1 .. '&e=' .. args.id2 .. '&t=' .. urlencode(args.id3) .. '&uid=guest')



local slist = string.match(x, 'quality(.-)}')
      
if slist then

   for  total, url2 in string.gmatch(slist, '"(%d+p)":"http.-(/proxy.-)"') do

  url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181') 
--total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

      end 
    end




  
  
            
   
    elseif args.q == 'zetflix' then
    
 --  https://beta.l-vid.online/lite/videodb?kinopoisk_id=386&title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&year=1979&token=a46f8a8a-8878-4fa5-8554-8296ba62260d

--https://beta.l-vid.online/online/js/a46f8a8a-8878-4fa5-8554-8296ba62260d


--https://beta.l-vid.online/online/js/8126ef1f-0a68-4b87-be2b-732e679461cc



 --   http://beta2.l-vid.online:888/lite/videodb?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn
    
    local headers = {['X-Requested-With'] = 'XMLHttpRequest'}
    
    
    
      local x = http.get('http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

   
 x = string.gsub(x, '\\u0026', '&')
 

 
   for url, total in string.gmatch(x, 'videos__item videos__movie.-stream.-http.-(/lite.-)&.-videos__item%-title.->(.-)<') do
  
 
      local x = http.get('http://beta.l-vid.online' .. url .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
  
  
   local slist = string.match(x, 'qualit.-{(.-)}')
   
   for  total1, url2 in string.gmatch(slist, '"(.-)":"http.-(/lite.-)"') do
      
    url2 = string.gsub(url2, '^(.-)', 'http://beta2.l-vid.online:888')



--http://178.20.46.40:12600/lite/videodb/manifest.m3u8?
      
  --   total1 = string.gsub(total1, ':{"', '') 
      
       t['view'] = 'simple'



    table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
  
 -- http://beta2.l-vid.online:888/lite/zetflix/manifest.m3u8?link=https%3A%2F%2Fcdn-54243ba5.obrut.show%2Fstream%2FAO%2FMHc0RHa%2FQbvNmLuR2YyVGc1RmclBXdz5ie%2F4U3Mt5CdzVmZp5WYtpzcshmO0AXbuADO08SMxYTM0AjNyAjM6MGO5MGOlR2YjJmYwImNyADZjNDM0cTYjVDN1MzN0gDNvUjNmVGOkJmZwYTMzgDNmJDMjRzY1QGN5AjN0gDM1QTOiRDNkdDMjNzLzVWayV2c2R3L
  

   
  local x = http.get('http://beta.l-vid.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

--table.insert(t, {title = 'http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn', mrl = 'http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn'})
   
   x = string.gsub(x, '\\u0026', '&')

   
        for url3, total1  in string.gmatch(x, 'videos__item videos__season.-method.-link.-url.-http.-&s=(.-)&.-videos__item%-title videos__season%-title.->(.-)<') do


   local x = http.get('http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&s=' .. url3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')



    --  local x = http.getz('http://beta.l-vid.online' .. url3 .. '&uid=bwygkgxn')

      for url4, total2  in string.gmatch(x, 'videos__button.-method.-link.-url.-http.-(/lite.-)&#.->(.-)<') do

url4 = string.gsub(url4, '\\u0026', '&')



     local x = http.getz('http://beta.l-vid.online' .. url4 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')


x = string.gsub(x, '\\u0026', '&')

      for url5, total3  in string.gmatch(x, 'videos__item videos__movie.-method.-stream.-http.-/lite.-http.-(http.-)%%22.-videos__item%-title.->(.-серия)<') do

     url5 = string.gsub(url5, '^(.-)', 'http://beta2.l-vid.online:888/lite/zetflix/manifest.m3u8?link=')
    

      t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' -'  .. total3 .. tolazy(total2), mrl = url5})

   
    end
end
end

elseif args.q == 'getstv' then
    
   
   
   
   
--https://evkh.lol
--http://z01.online/lite/getstv?kinopoisk_id=386&title=Чужой&year=1979
    
      local x = conn:load('http://z01.online/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
     url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

     local x = conn:load(url1)
   
 

 
     local slist = string.match(x, 'quality(.-)}')
      
if slist then

   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

    total1 = string.gsub(total1, ',"', '') 
    total1 = string.gsub(total1, '1080p":"/error.mp4"', '')
    
    
    
    
total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

      end 
    end

    end
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-"stream".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end

    
    
elseif args.q == 'mirage1' then
    

   
local x = conn:load('https://evkh.lol/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do

url4 = string.gsub(url4, '\\u0026', '&')
url4 = string.gsub(url4, '\\u002B', '+')



      url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do


url5 = string.gsub(url5, '\\u0026', '&')
url5 = string.gsub(url5, '\\u002B', '+')

      url5 = string.gsub(url5, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
    

     
    elseif args.q == 'mirage' then
    
  
 -- https://vizhu.top
--  https://lampa.persh1n.ru
  
--  http://93.183.95.219:11378
    
  --  https://lam.maxvol.pro/lite/mirage?kinopoisk_id=386&title=чужой&year=1979
    
     local x = conn:load('https://mylam.ru/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



  -- x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

      t['view'] = 'simple'


    table.insert(t, {title = total, mrl = url})

 
    end
    
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')

url5 = string.gsub(url5, '\\u002B', '+') 
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
     
--http://online7.skaz.tv/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025

  --  http://z01.online/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025 
 
 
 
 
 
 
  
 elseif args.q == 'paladin' then
  
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

     local url = 'https://beta.l-vid.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
   if x then
   
--   for url1, total in string.gmatch(x, 'method.-url.-(http.-)&#.-videos__item%-title.->(.-)<') do
  
  x = string.gsub(x, '\\u0026', '&')

for id, id1, total in string.gmatch(x, 'method.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do



      t['view'] = 'simple'

 table.insert(t, {title = total, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
 
 -- table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

      end 
   
   
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-(http.-)&.-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')

--url3 = string.gsub(url3, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


       local x = conn:load(url3)

    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&.->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')

 -- url4 = string.gsub(url4, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


     local x = conn:load(url4)
    
    x = string.gsub(x, '\\u0026', '&')
    

   for id, id1, total2 in string.gmatch(x, 'method.-stream.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do
 

  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
  

end
end
end
end     
      
 elseif args.q == 'paladins' then
    
local headers = {
    ["Host"] = "beta2.l-vid.online:888",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cache-Control"] = "no-cache"
}

local x = http.getz('http://beta2.l-vid.online:888/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d', headers)

      local slist = string.match(x, '"quality"(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":"(http.-)"') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
   url6 = string.gsub(url6, '\\u002B', '+')

--  url6 = string.gsub(url6, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = url6})

end
end
 
 
 
 
  elseif args.q == 'spectre' then
  
 -- http://31.129.234.181/lite/phantom/?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

  
  local url = 'http://31.129.234.181/lite/spectre?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0'


local x = http.get(url)
  
  if x then
  
   
   for url1, total in string.gmatch(x, 'method.-url.-http.-(/lite.-)".-videos__item%-title.->(.-)<') do
  
   
        url1 = string.gsub(url1, '\\u0026', '&')

  
     local x = conn:load('http://31.129.234.181' .. url1 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

 

   local slist = string.match(x, 'quality(.-)}')
      
      
   if slist then
   for  total1, url2 in string.gmatch(slist, '"(%d+p)".-http.-(/proxy.-m3u8)') do
  
   url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')   
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
      t['view'] = 'simple'

 
  table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})
 

      end 
    end
    end
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-http.-(/lite.-)".-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')



       local x = http.get('http://31.129.234.181' .. url3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-(/lite.-)".->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')


     local x = http.get('http://31.129.234.181' .. url4 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
    
    x = string.gsub(x, '\\u0026', '&')
    
--table.insert(t, {title = 'http://94.249.239.39' .. url4, mrl = 'http://94.249.239.39' .. url4})



  
  
   for id, id1, total2 in string.gmatch(x, 'method.-call.-url.-http.-id_file=(.-)&token_movie=(.-)".-videos__item%-title.->(.-)<') do
 
-- url5 = string.gsub(url5, '\\u0026', '&')
    
 --  url5 = string.gsub(url5, '\\u002B', '+')
 
   
  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=spectres&id=' .. id .. '&id1=' .. id1})
  
 -- table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=spectres&id=' .. id .. '&id1=' .. id1  .. '&id2=' .. id2 .. '&id3=' .. id3})
  


end
end
end
 end    
      
 elseif args.q == 'spectres' then
    
     
 --http://94.249.239.39/lite/mirage/video?t=34&s=1&e=1&token_movie=de9688cf5cb8bd7dd2876e9a61ed19
 
 
     local x = conn:load('http://31.129.234.181/lite/spectre/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


--local x = http.get('http://94.249.239.39/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
--.. '&uid=bwygkgxn')

if x then


      local slist = string.match(x, 'quality.-{(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":.-http.-(/proxy.-m3u8)') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
  

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = 'http://31.129.234.181' .. url6})
--.. '&uid=bwygkgxn'})

end
end
end
 
 
 
 elseif args.q == 'phantom' then
  
 -- http://31.129.234.181/lite/phantom/?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

  
  local url = 'http://31.129.234.181/lite/phantom?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0'


local x = http.get(url)
  
  if x then
  
   
   for url1, total in string.gmatch(x, 'method.-url.-http.-(/lite.-)".-videos__item%-title.->(.-)<') do
  
   
        url1 = string.gsub(url1, '\\u0026', '&')

  
     local x = conn:load('http://31.129.234.181' .. url1 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

 

   local slist = string.match(x, 'quality(.-)}')
      
      
   if slist then
   for  total1, url2 in string.gmatch(slist, '"(%d+p)".-http.-(/proxy.-m3u8)') do
  
   url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')   
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
      t['view'] = 'simple'

 
  table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})
 

      end 
    end
    end
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-http.-(/lite.-)".-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')



       local x = http.get('http://31.129.234.181' .. url3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-(/lite.-)".->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')


     local x = http.get('http://31.129.234.181' .. url4 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
    
    x = string.gsub(x, '\\u0026', '&')
    
--table.insert(t, {title = 'http://94.249.239.39' .. url4, mrl = 'http://94.249.239.39' .. url4})



  
  
   for id, id1, total2 in string.gmatch(x, 'method.-call.-url.-http.-id_file=(.-)&token_movie=(.-)".-videos__item%-title.->(.-)<') do
 
-- url5 = string.gsub(url5, '\\u0026', '&')
    
 --  url5 = string.gsub(url5, '\\u002B', '+')
 
   
  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=phantoms&id=' .. id .. '&id1=' .. id1})
  
 -- table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladinnsss&id=' .. id .. '&id1=' .. id1  .. '&id2=' .. id2 .. '&id3=' .. id3})
  


end
end
end
 end    
      
 elseif args.q == 'phantoms' then
    
     
 --http://94.249.239.39/lite/mirage/video?t=34&s=1&e=1&token_movie=de9688cf5cb8bd7dd2876e9a61ed19
 
 
     local x = conn:load('http://31.129.234.181/lite/phantom/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


--local x = http.get('http://94.249.239.39/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
--.. '&uid=bwygkgxn')

if x then


      local slist = string.match(x, 'quality.-{(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":.-http.-(/proxy.-m3u8)') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
  

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = 'http://31.129.234.181' .. url6})
--.. '&uid=bwygkgxn'})

end
end
end
 
 
 
 
 
   
    elseif args.q == 'videohub' then
    
 
 
-- https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=386
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 
 
 local slist = string.match(x, '"isSerial":false(.-)trailers')
 
 if slist then
 
 
 
 
for id, total, total1 in string.gmatch(slist, '"vkId":"(.-)".-"voiceStudio":"(.-)".-"voiceType":"(.-)"') do
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = '#stream/q=cdnvideohubm&id=' .. id})
 

 
 
	
 local headers = {
    ["Host"] = "plapi.cdnvideohub.com",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


     
 local x = http.getz('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, headers)
 
-- x = string.gsub(x, '\\u0026', '&')
  -- x = string.gsub(x, '\\u002B', '+')
  
 local slist = string.match(x, '"sources"(.-)}')
 

   slist = string.gsub(slist, 'mpegFullHdUrl', '1080p')
   
   slist = string.gsub(slist, 'mpegHighUrl', '720p')
   
slist = string.gsub(slist, 'mpegMediumUrl', '480p')

slist = string.gsub(slist, 'mpegLowUrl', '360p')
   
   
   
   
    
    if slist then
    
    for title, url in string.gmatch(slist, '"(1080p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url})
 end
 
 for title, url in string.gmatch(slist, '"(720p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url})
 end
 
for title, url in string.gmatch(slist, '"(480p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url})
 end
 
 
for title, url in string.gmatch(slist, '"(360p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url})
 end
 
 end
 end
 end
 
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 local slist = string.match(x, '"isSerial":true(.-)trailers')
 
 if slist then
 
 

 for id, total, total1, season, episode in string.gmatch(slist, '"vkId":"(.-)".-"voiceStudio":"(.-)".-"voiceType":"(.-)".-"season":(.-),.-episode":(%d+)}') do
 
 t['view'] = 'simple'
 
 table.insert(t, {title = 'Сезон :' .. season .. ' серия : ' .. episode  .. ' '.. total .. ' ' .. total1,  mrl = '#stream/q=videohubm&id=' .. id})
 end
 end
 


elseif args.q == 'videohubm' then
 
 local headers = {
    ["Host"] = "plapi.cdnvideohub.com",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


     
 local x = http.getz('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. args.id, headers)
 
-- x = string.gsub(x, '\\u0026', '&')
  -- x = string.gsub(x, '\\u002B', '+')
  
 local slist = string.match(x, '"sources"(.-)}')
 

   slist = string.gsub(slist, 'mpegFullHdUrl', '1080p')
   
   slist = string.gsub(slist, 'mpegHighUrl', '720p')
   
slist = string.gsub(slist, 'mpegMediumUrl', '480p')

slist = string.gsub(slist, 'mpegLowUrl', '360p')
   
   
   
   
    
    if slist then
    
    for title, url in string.gmatch(slist, '"(1080p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = title, mrl = url})
 end
 
 for title, url in string.gmatch(slist, '"(720p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = title, mrl = url})
 end
 
for title, url in string.gmatch(slist, '"(480p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = title, mrl = url})
 end
 
 
for title, url in string.gmatch(slist, '"(360p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = title, mrl = url})
 end
 
 end
 
 
 
 
     
    elseif args.q == 'cdnvideohub' then
    
 
 
-- https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=386
 
-- local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3, mrl = 'https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3})
 
-- "titleName":"Чужой","isSerial":false,"items"

--"vkId":"7554357484052","voiceStudio":"","voiceType":""}

-- "vkId":"11917742136012","voiceStudio":"Jaskier","voiceType":"Многоголосый"
 
-- for title in string.gmatch(x, '"titleName":"(.-)","isSerial":false') do
 
-- for id, total, total1 in string.gmatch(x, '"vkId":"(.-)","voiceStudio":"(.-)","voiceType":"(.-)"') do
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = '#stream/q=cdnvideohubm&id=' .. id})
 
-- end
 --end
 
 
 

     
-- https://plapi.cdnvideohub.com/api/v1/player/sv/video/11917742136012
 
 --table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id})
 
-- end
-- end
 
 
 
  local x = conn:load('https://lam.maxvol.pro/lite/cdnvideohub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)





for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url = string.gsub(url, '\\u0026', '&')
   url = string.gsub(url, '\\u002B', '+')
  
  local x = conn:load(url)
  
  
  for  url1 in string.gmatch(x, '"method":"play","url":".-(/proxy.-)"') do
  
  url1 = string.gsub(url1, '\\u0026', '&')
  url1 = string.gsub(url1, '\\u002B', '+')
  
  
url1 = string.gsub(url1, '^(.-)', 'https://lam.maxvol.pro')


t['view'] = 'simple'

  table.insert(t, {title = total, mrl = url1})

end
end
  
  
  for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')
    url5 = string.gsub(url5, '\\u002B', '+')
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end

elseif args.q == 'cdnvideohubm' then
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. args.id)
 
 local slist = string.match(x, '"sources"(.-)}')
    
    if slist then
    
     for total1, url2 in string.gmatch(slist, '"(.-Url)":"(http.-)"') do



  url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = string.gsub(url2, '\\u002B', '+')  
     
     url2 = string.gsub(url2, 'GECKO', 'CHROME_ANDROID')
     

     
      t['view'] = 'simple'

   table.insert(t, {title = url2, mrl = url2})
    end
    end
    
--  https://vd299.okcdn.ru/?expires=1768797038930&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=5&sig=oiqy4nM5q6Y&ct=0&urls=185.226.55.24&clientType=46&zs=41&id=10216803469855
   
 -- https://vd299.okcdn.ru/?expires=1768798368123&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=5&sig=blL2z7YgIDE&ct=0&urls=45.136.22.28&clientType=46&zs=41&id=10216803469855
   
   
    
  --https://vd299.okcdn.ru/?expires=1768798513604&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=2&sig=CKjpvCr3_h0&ct=0&urls=45.136.22.28&clientType=46&zs=41&id=10216803469855
 
 
 --http://vd299.okcdn.ru/?expires=1768797559897&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=5&sig=k-en2-mOVts&ct=0&urls=45.136.22.28&clientType=46&zs=41&id=10216803469855
  
 -- http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=386&box_mac=acace24b8434
  
  
  --http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&stream=11634d91da3c2975c8557c6890fe6a&audio=0&box_mac=acace24b8434
    
    
    
    
  elseif args.q == 'alloha' then
 
 local data = 'http://kb-team.club/msx/msxFork.php?plugin=' .. base64_encode('plugin&bid=alloha-aloha&act=view&id=' .. args.id3) .. '&device=acace24b8434'
 
 --http://kb-team.club/msx/msxFork.php?plugin=cGx1Z2luJmJpZD1hbGxvaGEtYWxvaGEmYWN0PXZpZXcmaWQ9Mzg2&device=acace24b8434
 
 
 
    local x = conn:load(data)

--table.insert(t,{title = data,mrl = data})
    
    if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 
 
    local x = string.match(x,'"label":".-Просмотр"(.-)]') 
    
    for total, url in string.gmatch(x, '{"label":"(.-)".-"action".-content.-(http.-)"') do
  
  url = string.gsub(url, '\\', '') 
     
  
       local x = conn:load(url)
   
  -- table.insert(t,{title= url,mrl = url})
    
    
   
   for total1, url1 in string.gmatch(x, '"playerLabel":"(.-)".-video.-(http.-)"') do
   
   url1 = string.gsub(url1, '\\', '') 
   url1 = urldecode(url1)
   
  
  t['view'] = 'simple'
  
     table.insert(t,{title= tolazy(total) .. ' ' .. '(' .. total1 .. 'p)',mrl = url1})
    
    end
    end
end
    

local x = conn:load(data)

--table.insert(t,{title = data,mrl = data})



for title, url2 in string.gmatch(x,'{"label":"\\u0421.-(%d+)",.-action".-content.-(http.-)"') do
      
      url2 = string.gsub(url2, '\\', '')
  
  
      
   local x = conn:load(url2)
  
   
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')

--Выберите Сезон и Серию

--local x = string.match(x,'Выберите Сезон и Серию(.-)]') 

for title1, url3 in string.gmatch(x,'label":"(.-)".-"action".-content.-http.-plugin=(.-)&') do

   
url3 = string.gsub(url3, '\\', '')

t['view'] = 'simple'

table.insert(t, {title = 'сезон ' .. title .. ' ' .. tolazy(title1), mrl = '#stream/q=allohaz&id=' .. url3})

   end
  end
   
       
  elseif args.q == 'allohaz' then
 
   
  local x = conn:load('http://kb-team.club/msx/msxFork.php?view&plugin=' .. args.id .. '&device=acace24b8434')
  
--local x = conn:load(url3)
  
  for title2, url4 in string.gmatch(x,'"playerLabel":".-(%d+)".-video.-(http.-)",') do
  url4 = string.gsub(url4, '\\', '')
        
   local x = conn:load(url4)

 
    for url5 in string.gmatch(x,'url.-(http.-)"') do 
   
url5 = string.gsub(url5, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = ' серия ' .. title2, mrl = url5})

      end 
      end
    
    
    
    
  elseif args.q == 'alloha1' then
 
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=' .. args.id3 .. '&box_mac=acace24b8434')

    
    
  
    --   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, id1, id2, id3, id4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA.-&stream=(.-)&season=(.-)&translate=(.-)&ta=(.-)]]') do
  
  
  t['view'] = 'simple'
  
    
    table.insert(t,{title= tolazy(total) .. ' ' .. tolazy(total1),mrl = '#stream/q=allohas&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
    
    end
    end

    



    

local x = conn:load('https://evkh.lol/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do


url4 = string.gsub(url4, '\\u002B', '+') 
     
      url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do

url5 = string.gsub(url5, '\\u002B', '+') 


      url5 = string.gsub(url5, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end




elseif args.q == 'allohas' then
    
    
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&stream=' .. args.id1 .. '&season=' .. args.id2 .. '&translate=' .. args.id3 .. '&ta=' .. args.id4 .. '&box_mac=acace24b8434')
  
  

  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
    t['view'] = 'simple'
				table.insert(t,{title= tolazy(total3) .. ' ' .. (total2),mrl = url5})
			end
          end
    
    



--http://78.40.199.67:10630/proxy/O3hSoc5CijVra2vCgfLNLB/PmRc+hqhKQgIOtzJlZSEN/U78WLhH33d7PTzmOoNEDwNxZZPw/cCL2DPw8vwZ+AtWC4MYaTNCqweYtblqcNLYD84RO+a9J2fQBoSstZ6c38UCxMq/hdkhO3eN06Bby6mor91qcMJXtoj7oQMvQb4LCGTqcuao/k4kE+O4e5YUbcSaRf6wbvMr+xw/pxPJLRjH3XBJVkyFY+94Tn8pggp22Td/Cka0vh7ih0qoejU+TjFZIFz8s/7BYVPvw5Tv8b+OOh3cAe7fQCrhzls/hqQ=.mp4
  

elseif args.q == 'cdnmovies' then
      
      local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?kinopoisk_id=' .. args.id3)


 local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630')
    
    

      local x = conn:load(url2)

     
      for id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-&kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=cdnmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})
  
  
  end
  end


 
     elseif args.q == 'cdnmoviess' then
 
 
     local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?' .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end





--https://lamp-movie.ru
    
    elseif args.q == 'vdbmovies' then
      
      local x = conn:load('https://lam.maxvol.pro/lite/vdbmovies?kinopoisk_id=' .. args.id3)


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    
    

      local x = conn:load(url2)

     
      for id4, id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"(http.-)&.-kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=vdbmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
  
  
  end
  end


 
     elseif args.q == 'vdbmoviess' then
 
 
     local x = conn:load(args.id4 .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


--https://lam.akter-black.com/lite/hdvb?imdb_id=tt29927663

--http://93.183.95.219:11378

 elseif args.q == 'hdvb' then
      
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

      for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"http.-(vid.-)(/movie.-)"') do
      
if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)


local id, key = string.match(x, '"file":"%~(.-)".-"key":"(.-)"')

--local key = string.match(x, '"file".-"key":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.fotpro135alto.com/playlist/') .. '.txt'



local headers1 = {
    ["Host"] = "vid11.fotpro135alto.com",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)

         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. title, mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. title, mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. title, mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. title, mrl = url3})

       end
       end
   end
   end
     
    
    
    
    
    
     
     local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
     
    -- table.insert(t, {title = 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3, mrl = '#stream/q=hdvbs&id1=' .. 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3})
     
     
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

     
     
     
  --   table.insert(t, {title = url, mrl = '#stream/q=hdvbs&id1=' .. url})
     
   
    --  for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') do
      
      local origin, url = string.match(x, '"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') 

if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=177873309816283985; _ym_d=1778733098; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)

x = string.gsub(x, '\\', '')

local id, key = string.match(x, '"file":"(.-)".-"key":"(.-)"')

--local key = string.match(x, '"file".-"key":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.fotpro135alto.com')

local headers1 = {
    ["Host"] = "vid11.fotpro135alto.com",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')







for id1, text in string.gmatch(x, '"file":"%~(.-)".-"text2":"(.-)"') do

--local text = string.match(x, '"file".-"text2":"(.-)"')


id1 = string.gsub(id1, '^(.-)', 'https://vid11.fotpro135alto.com/playlist/') .. '.txt'


local x = http.postz(id1, headers1)



for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. text, mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. text, mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. text, mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. text, mrl = url3})

       end
     
end
     
end
end
 
 
 
 
elseif args.q == 'zagonka' then
 


--args.id1 = string.gsub(args.id1, ':', '') 
args.id1 = string.gsub(args.id1, ' ', '%%20') 
		
 -- args.id1 = urlencode(args.id1)
 
-- args.id1 = string.gsub(args.id1, '+', '%%20') 
   
       local url = 'http://abc.zagonkop.gb.net/engine/ajax/xsearch/f.php?q=' .. args.id1
       --.. '%%20' .. args.id2

--table.insert(t, {title = url, mrl = url})	

local headers = {    
      ["host"] = "abc.zagonkop.gb.net",
      ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0",
       ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive"
}



local x = http.getz(url, headers)


local x = json.decode(x)

		for _, v in ipairs(x) do
		--	local url = 'http://rutube.ru/video/' .. v['id'] .. '/'
	
	t['view'] = 'simple'
	
	table.insert(t, {title = v['text'], mrl = '#stream/q=zagonkaz&id1=' .. v['id'] .. '&id=' .. v['url']})

end






--for ids, urls in string.gmatch(x, '{"id":"(.-)".-url.-(/.-)"') do

--{"id":"(.-)","text":"(.-)","url":"\/135628-ubivat-nado-vovremja-1998-onlayn.html"

--local ids, urls = string.match(x, '{"id":"(.-)".-url.-(/.-)"')

--urls = string.gsub(urls, '^(.-)', 'http://abc.zagonkop.gb.net') 

 
--t['view'] = 'simple'

--table.insert(t, {title = urldecode(args.id1) .. '(' .. args.id2 .. ')', mrl = '#stream/q=zagonkaz&id=' .. urls .. '&id1=' .. ids .. '&id2=' .. args.id2})

--end


elseif args.q == 'zagonkaz' then

  local url1 = 'http://abc.zagonkop.gb.net/embed/' .. args.id1


--http://abc.zagonkop.gb.net/embed/kp-5499518


local headersz = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = 'http://abc.zagonkop.gb.net' .. args.id,
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}



  local x = http.getz(url1, headersz)


--local id = string.match(x, 'data%-id="(.-)"')

--table.insert(t, {title = id, mrl = id})


x = string.gsub(x, 'ZYzNM', '')
        x = string.gsub(x, 'ZUzls', '')
x = string.gsub(x, 'ZUzVw', '')

x = string.gsub(x, 'ZUTB5', '')

x = string.gsub(x, 'ZaTdV', '')


local x = string.match(x, 'Playerjs%(\'#2(.-)\'%)+') 
   
  if x then      
    
    
    x = base64_decode(x)
     
 x = string.gsub(x, '{v1}', '.mp4')   

 
 
 for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')
 
 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(1080p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/720.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(720p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(480p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/360.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(360p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end
 
 
-- url = url_for(x)
--url = urldecode(url)
  
  
 -- table.insert(t, {title = url, mrl = url})
 
 
 x = string.gsub(x, '_tr_2469_', '_tr_Syncmer_') 

x = string.gsub(x, '_tr_30_', '_tr_Coldfilm_') 





x = string.gsub(x, '_tr_233_', '_tr_Coldfilm_') 

x = string.gsub(x, '_tr_3025_', '_tr_Ultradox_')

x = string.gsub(x, '_tr_768_', '_tr_Ultradox_')

x = string.gsub(x, '_tr_1432_', '_tr_Rudub_')

x = string.gsub(x, '_tr_2388_', '_tr_Rudub_')

x = string.gsub(x, '_tr_286_', '_tr_Rezka_')

x = string.gsub(x, '_tr_281_', '_tr_Rg.paravozik_')

x = string.gsub(x, '_tr_10_', '_tr_Lostfilm_')

x = string.gsub(x, '_tr_380_', '_tr_Tvshows_')

x = string.gsub(x, '_tr_397_', '_tr_Пифагор_')

x = string.gsub(x, '_tr_17_', '_tr_Jaskier_')

x = string.gsub(x, '_tr_16_', '_tr_Gears Media_')

x = string.gsub(x, '_tr_6_', '_tr_Профессиональный_')

x = string.gsub(x, '_tr_7_', '_tr_Дубляж_')

x = string.gsub(x, '_tr_998_', '_tr_LE-Production_')

x = string.gsub(x, '_tr_14_', '_tr_Alexfilm_')

x = string.gsub(x, '_tr_1538_', '_tr_RED Head Sound_')

x = string.gsub(x, '_tr_1410_', '_tr_RED Head Sound_')

x = string.gsub(x, '_tr_2648_', '_tr_1Win Studio_')

x = string.gsub(x, '_tr_554_', '_tr_Newcomers_')

x = string.gsub(x, '_tr_210_', '_tr_Goldteam_')


x = string.gsub(x, '_tr_1285_', '_tr_Goldteam_')

x = string.gsub(x, '_tr_3014_', '_tr_Nonamestudio_')

x = string.gsub(x, '_tr_180_', '_tr_Viruseproject_')

x = string.gsub(x, '_tr_2836_', '_tr_Hate Studio_')

x = string.gsub(x, '_tr_2981_', '_tr_Capybara_')

x = string.gsub(x, '_tr_381_', '_tr_Оригинал_')

x = string.gsub(x, '_tr_1308_', '_tr_Оригинал_')

x = string.gsub(x, '_tr_24_', '_tr_Ideafilm_')

x = string.gsub(x, '_tr_521_', '_tr_Westfilm_')

x = string.gsub(x, '_tr_12_', '_tr_Baibako_')

x = string.gsub(x, '_tr_436_', '_tr_Kerobtv_')

x = string.gsub(x, '_tr_432_', '_tr_Kerobtv_')

x = string.gsub(x, '_tr_359_', '_tr_Lakefilms_')

x = string.gsub(x, '_tr_2963_', '_tr_Dragon Money Studio_')

x = string.gsub(x, '_tr_22_', '_tr_Кубик в Кубе_')

x = string.gsub(x, '_tr_2828_', '_tr_Закадры_')

x = string.gsub(x, '_tr_13_', '_tr_Newstudio_')

x = string.gsub(x, '_tr_2732_', '_tr_Whiskey Sound_')

x = string.gsub(x, '_tr_996_', '_tr_Flarrow Films_')

x = string.gsub(x, '_tr_563_', '_tr_Кравец_')

x = string.gsub(x, '_tr_19_', '_tr_Omskbird Records_')

x = string.gsub(x, '_tr_331_', '_tr_AMS_')


  


for season, tr, episode, url3 in string.gmatch(x, '<div.-class.-in_e.-class=\'mfs\'.-"s_(.-)_tr_(.-)_e_(.-)_.-file.-(//.-mp4)') do


 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
  end


for season, tr, episode, url3 in string.gmatch(x, '<div.-class.-in_e.-class=\'mfs\'.-"s_(.-)_tr_(.-)_e_(.-)_.-file.-(//.-mp4)') do

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
 end
 
 end

 
 
 
 
 
    
elseif args.q == 'turbo' then

--https://proxy4.rte.net.ru/


--https://go.zet-flix.online/iplayer/player.php?id=JTJGaXBsYXllciUyRnZpZGVvZGIucGhwJTNGa3AlM0QzODY=

local url = 'https://54243ba5.obrut.show/embed/AO/kinopoisk/' .. args.id3 .. '/'


local headers = {
    ["Host"] = "54243ba5.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cookie"] = "wd_trust=AAAAAGnw-KMyM0U0OTMyRQFSZP9Ll3IMgg; XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}







local x = http.getz(url, headers)




--url = url_for(x)

--url = urldecode(url)


x = string.gsub(x, '//ci9yL3I=', '')
 
x = string.gsub(x, '//by9vL28=', '')
 
x = string.gsub(x, '//dC90L3Q=', '')
 
x = string.gsub(x, '//Yi9iL2I=', '')

x = string.gsub(x, '//dS91L3U=', '')
	
					


local slist = string.match(x, 'new.-Player.-(eyJsYW5.-\"+)')
 
 
 if slist then
 
 slist = base64_decode(slist)
 
slist = string.gsub(slist, '\\u0410', 'А')
      slist = string.gsub(slist, '\\u0430', 'а')
      slist = string.gsub(slist, '\\u0411', 'Б')
       slist = string.gsub(slist, '\\u0431', 'б')
       slist = string.gsub(slist, '\\u0412', 'В')
      slist = string.gsub(slist, '\\u0432', 'в')
       slist = string.gsub(slist, '\\u0413', 'Г')
       slist = string.gsub(slist, '\\u0433', 'г')      slist = string.gsub(slist, '\\u0414', 'Д')
      slist = string.gsub(slist, '\\u0434', 'д')
       slist = string.gsub(slist, '\\u0415', 'Е')
       slist = string.gsub(slist, '\\u0435', 'е')      slist = string.gsub(slist, '\\u0401', 'Ё')
      slist = string.gsub(slist, '\\u0451', 'ё')
       slist = string.gsub(slist, '\\u0416', 'Ж')
       slist = string.gsub(slist, '\\u0436', 'ж')
       slist = string.gsub(slist, '\\u0417', 'З')
      slist = string.gsub(slist, '\\u0437', 'з')
       slist = string.gsub(slist, '\\u0418', 'И')
       slist = string.gsub(slist, '\\u0438', 'и')     slist = string.gsub(slist, '\\u0419', 'Й')
      slist = string.gsub(slist, '\\u0439', 'й')
       slist = string.gsub(slist, '\\u041a', 'К')
       slist = string.gsub(slist, '\\u043a', 'к')
       slist = string.gsub(slist, '\\u041b', 'Л')
       slist = string.gsub(slist, '\\u043b', 'л')
       slist = string.gsub(slist, '\\u041c', 'М')
       slist = string.gsub(slist, '\\u043c', 'м')
       slist = string.gsub(slist, '\\u041d', 'Н')
       slist = string.gsub(slist, '\\u043d', 'н')
       slist = string.gsub(slist, '\\u041e', 'О')
       slist = string.gsub(slist, '\\u043e', 'о')
       slist = string.gsub(slist, '\\u041f', 'П')
       slist = string.gsub(slist, '\\u043f', 'п')
    slist = string.gsub(slist, '\\u0420', 'Р')
    slist = string.gsub(slist, '\\u0440', 'р')
    slist = string.gsub(slist, '\\u0421', 'С')
    slist = string.gsub(slist, '\\u0441', 'с')
    slist = string.gsub(slist, '\\u0422', 'Т')
    slist = string.gsub(slist, '\\u0442', 'т')
    slist = string.gsub(slist, '\\u0423', 'У')
    slist = string.gsub(slist, '\\u0443', 'у')
    slist = string.gsub(slist, '\\u0424', 'Ф')
    slist = string.gsub(slist, '\\u0444', 'ф')
    slist = string.gsub(slist, '\\u0425', 'Х')
    slist = string.gsub(slist, '\\u0445', 'х')
    slist = string.gsub(slist, '\\u0426', 'Ц')
    slist = string.gsub(slist, '\\u0446', 'ц')
    slist = string.gsub(slist, '\\u0427', 'Ч')
    slist = string.gsub(slist, '\\u0447', 'ч')
    slist = string.gsub(slist, '\\u0428', 'Ш')
    slist = string.gsub(slist, '\\u0448', 'ш')
    slist = string.gsub(slist, '\\u0429', 'Щ')
    slist = string.gsub(slist, '\\u0449', 'щ')
    slist = string.gsub(slist, '\\u042a', 'Ъ')
    slist = string.gsub(slist, '\\u044a', 'ъ')
    slist = string.gsub(slist, '\\u042b', 'Ы')
    slist = string.gsub(slist, '\\u044b', 'ы')
    slist = string.gsub(slist, '\\u042c', 'Ь')
    slist = string.gsub(slist, '\\u044c', 'ь')
    slist = string.gsub(slist, '\\u042d', 'Э')
    slist = string.gsub(slist, '\\u044d', 'э')
    slist = string.gsub(slist, '\\u042e', 'Ю')
    slist = string.gsub(slist, '\\u044e', 'ю')
    slist = string.gsub(slist, '\\u042f', 'Я')
    slist = string.gsub(slist, '\\u044f', 'я')
    slist = string.gsub(slist, '\\u00ab', '<<')
    slist = string.gsub(slist, '\\u00bb', '>>')
    slist = string.gsub(slist, '\\u2014', '-')
 
 

 for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(240p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

title = string.gsub(title, 'Season [%d+]', '')
title = string.gsub(title, 'Episode [%d+]', '')



title = string.gsub(title, '","folder":%[{"title":"', '')


 t['view'] = 'simple'
 
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=turbovideo&id=' .. url1})
 
 end
 

 

 
for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(360p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')
title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')
title = string.gsub(title, '","folder":%[{"title":"', '')

title = string.gsub(title, 'Season [%d+]', '')
title = string.gsub(title, 'Episode [%d+]', '')
 t['view'] = 'simple'
 
 


table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=turbovideo&id=' .. url1})
 
 end
 
for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(480p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

title = string.gsub(title, '","folder":%[{"title":"', '')

title = string.gsub(title, 'Season [%d+]', '')
title = string.gsub(title, 'Episode [%d+]', '')


 t['view'] = 'simple'
 

 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=turbovideo&id=' .. url1})
 
 end
 
 
for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(720p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

title = string.gsub(title, '","folder":%[{"title":"', '')

title = string.gsub(title, 'Season [%d+]', '')
title = string.gsub(title, 'Episode [%d+]', '')


 t['view'] = 'simple'
 
 

 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=turbovideo&id=' .. url1})
 
 end
 
 for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(1080p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')
title = string.gsub(title, '","folder":%[{"title":"', '')


title = string.gsub(title, 'Season [%d+]', '')
title = string.gsub(title, 'Episode [%d+]', '')

 t['view'] = 'simple'
 


 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=turbovideo&id=' .. url1})
 
 end
    end

elseif args.q == 'turbovideo' then
  
  local headers = {
    ["Host"] = "54243ba5.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cookie"] = "wd_trust=AAAAAGnw-KMyM0U0OTMyRQFSZP9Ll3IMgg; XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}
  
  
  
 local x = http.getz(args.id, headers)
 
 --if x then
 

local url = string.match(x,'<meta http%-equiv="refresh".-url=.-(http.-m3u8)')
  
 -- for url in string.gmatch(x,'<meta http%-equiv="refresh".-url=.-(http.-m3u8)') do
  
-- table.insert(t, {title = 'Смотреть', mrl = url})
  if url then
    print(url)
    return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}
 end

 
 
 
 
 
 
 
 elseif args.q == 'videodb1' then
  
  
    local x = conn:load('https://proxy4.rte.net.ru/http://31.129.234.181/lite/zetflixdb?kinopoisk_id=' .. args.id3 .. '&uid=guest')
   

   
   for  url2, total in string.gmatch(x, '"method".-"url":.-(http.-)".-class="videos__item%-title">(.-)<') do
 

      url2 = string.gsub(url2, '\\u0026', '&') 
     
     
      t['view'] = 'simple'
    

 
    table.insert(t, {title = tolazy(total), mrl = url2})

      end 
    

      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
      
    
      url2 = string.gsub(url2, '\\u0026', '&') 
 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

    
      url3 = string.gsub(url3, '\\u0026', '&') 

       local x = http.getz(url3 .. '&uid=guest')

   
      for  url4, total2 in string.gmatch(x, '"method":"play".-"url".-(http.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    
      url4 = string.gsub(url4, '\\u0026', '&') 

      t['view'] = 'simple'
 
 
   --  table.insert(t, {title = url4, mrl = url4})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4})

     end
     end
    end
 
 
 
 
 
 
elseif args.q == 'videodb' then
  
  
 local x = conn:load('https://x.vmestefilms.online/api/kinopoisk/?kp_id=' .. args.id3)
  
     local total = string.match(x, '"slug":.-"(.-)",')
  
  if total then
  
  local id = string.match(x, '"TURBO".-"id": (.-)}')

if id then

  
    local x = conn:load('http://78.40.195.218:9118/lite/videodb?rjson=False&href=https://x.vmestefilms.online/room/' .. id .. '/' .. total .. '/')
   
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-http.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://78.40.195.218:9118')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
    url2 = string.gsub(url2, '^(.-)', 'http://78.40.195.218:9118') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://78.40.195.218:9118') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-http.-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://78.40.195.218:9118')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
end
end

 
    
    elseif args.q == 'videodb1' then
    
    local x = conn:load('https://lam.maxvol.pro/lite/videodb?kinopoisk_id=' .. args.id3)
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(http.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
   --  url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
    -- url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

    --  url3 = string.gsub(url3, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(http.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
   -- url4 = string.gsub(url4, '^(.-)', 'http://lam.maxvol.pro')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end


   elseif args.q == 'videocdn' then
 
 
 
 
local x = conn:load('http://kb-team.club/msx/kinozal/videocdn.php?act=watch&vid=' .. args.id3 .. '&device=acace24b8434') 


if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 
 

 
 for title, url1 in string.gmatch(x,'"playerLabel":"(.-)".-video.-(http.-)"') do



url1 = string.gsub(url1, '\\', '')

 t['view'] = 'simple'

   table.insert(t, {title = title, mrl = url1})

      end 
 
      
      
     for url2 in string.gmatch(x,'"label".-"action":"panel.-(http.-)"') do
      
      url2 = string.gsub(url2, '\\', '')
  
  
      
   local x = conn:load(url2)
  
   
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')


for title1, url3 in string.gmatch(x,'"playerLabel":"(.-)".-"action":"player:show".-"action.-video.-(http.-)"') do


   
url3 = string.gsub(url3, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = tolazy(title1), mrl = url3})

      end 
  
  
  for title2, url3 in string.gmatch(x,'"label":".-uddfa(.-)".-"action":"panel:(http.-)"') do
  url3 = string.gsub(url3, '\\', '')
        
   local x = conn:load(url3)
  
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
  
  
--  table.insert(t, {title = url, mrl = url})
  
 
    for title3, url4 in string.gmatch(x,'"playerLabel":"(.-)".-"action":"player:show".-video.-(http.-)"') do 
   
url4 = string.gsub(url4, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = title2 .. ' ' .. tolazy(title3), mrl = url4})

      end 
      end
   end
     
 end
 
 
-- https://lampa.ip917.ru/lite/lumex/video.m3u8?playlist=%2fvalidate%2fU2FsdGVkX1-HWJXR-68d4L5FZ5G8XZbankXomi3bA2NSRN28LPBPtpORtthxOnUsx0Lg3KqSB6Kfg3EJql4hhh7YMO-Pp2SLx9TnO-tBp5myBFbjXKKEuKfrYZ2wVwdb45iSZaB5Cok7fK_Cb4QprlmNkOfV5hLruFWpJtTVIuGIf3Dk65SDRFcyJOHKPXleu07ieysuHAkAZEDcjDZUECF4FIdxBkqkYwP6CPUt4x8&csrf=636ebee3ad5caa58ecd60717b4c38dc7&max_quality=1080&uid=2hlekqiu   
--https://lamp-movie.ru
--http://lam.maxvol.pro
--http://89.110.96.198:12267/lite/lumex?kinopoisk_id=386
    
 --   http://z01.online/lite/vdbmovies?kinopoisk_id=386
    
 --   http://z01.online/lite/lumex?kinopoisk_id=386
 
 --http://z01.online/lite/videocdn?kinopoisk_id=4910542
    
--   local x = conn:load('http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3) 
   local x = conn:load('https://lam.maxvol.pro/lite/lumex?kinopoisk_id=' .. args.id3) 
   
   --.. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3, mrl = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":.-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
      url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

  --   local x = conn:load(url1)
   
 

 
 --    local slist = string.match(x, 'quality(.-)}')
      
--if slist then

--   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

  --  total1 = string.gsub(total1, ',"', '') 
--total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url1})

      end 
--    end

  --  end
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end


   
   
    elseif args.q == 'lumex' then
    
  --  http://lam.maxvol.pro
 --   http://178.20.46.40:12600

--http://lam.maxvol.pro/lite/lumex?kinopoisk_id=4910542

   local x = conn:load('https://lam.maxvol.pro/lite/lumex?kinopoisk_id=' .. args.id3)
   -- https://lam.akter-black.com
    
   --  local x = conn:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
--  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

 --  table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p) ' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
 
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
      
url3 = string.gsub(url3, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p) '.. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '480.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p) ' .. tolazy(total), mrl = url3})
       
    end
    
   local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '360/index')
      url3 = string.gsub(url3, '360.mp4', '360.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '360.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(360p) ' .. tolazy(total), mrl = url3})
       
    end 
    
local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '240/index')
      url3 = string.gsub(url3, '360.mp4', '240.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '240.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(240p) ' .. tolazy(total), mrl = url3})
       
    end
    
    
    
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
       --   url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end
  end
  
  

 elseif args.q == 'lumexs' then
    
     local x = conn:load('https://lam.maxvol.pro/lite/lumex?content_id=' .. args.id1 .. '&kinopoisk_id=' .. args.id2 .. '&clarification=' .. args.id3 .. '&s=' .. args.id4 .. '&t=' .. args.id5)



for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = 'Сезон ' .. args.id4 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end






      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
 
 
 
 local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '1080/index')
      url5 = string.gsub(url5, '360.mp4', '1080.mp4')
      
     url5 = string.gsub(url5, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8') 
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(1080p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
 

     local x = conn:load(url4)
  
  for url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
  
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(720p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
   
   local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '480/index')
      url5 = string.gsub(url5, '360.mp4', '480.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '480.mp4:hls:manifest.m3u8')
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(480p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
  
end

   
   
--   http://178.20.46.40:12600/lite/filmix?title=чужой&year=1979
    
--https://vizhu.top/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
 -- https://lamp-movie.ru/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
  
--http://z01.online/lite/filmix?postid=173202
      
elseif args.q == 'filmix' then

--https://api.filmix.tv/api-fx/post/178338/video-links

--http://z01.online/lite/filmix?title=чужой&year=1979

local x = conn:load('http://178.20.46.40:12600/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2)

for id in string.gmatch(x,'<div class="videos__line".-"method":"link".-"url":"http.-postid=(.-)\\u0026') do


local x = conn:load('https://api.filmix.tv/api-fx/post/' .. id .. '/video-links')



x = string.gsub(x, '\\', '')

--x = string.gsub(x, '"http.-.mp4"', '')


local video = string.match(x, '{"season":null(.-)"video"}]')



if video then

local video1 = string.match(video, '"files":%[(.-)"updated"') do

if video1 then

for url, url1, total in string.gmatch(video1,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video1,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
end
end


local video2 = string.match(video, '"files".-"files":%[(.-)"updated"') do

if video2 then


for url, url1, total in string.gmatch(video2,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video2,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end
 
 
local video3 = string.match(video, '"files".-"files".-"files":%[(.-)"updated"') do


if video3 then

for url, url1, total in string.gmatch(video3,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video3,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end
 
 local video4 = string.match(video, '"files".-"files".-"files".-"files":%[(.-)"updated"') do

if video4 then

for url, url1, total in string.gmatch(video4,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video4,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end
 
local video5 = string.match(video, '"files".-"files".-"files".-"files".-"files":%[(.-)"updated"') do

if video5 then

for url, url1, total in string.gmatch(video5,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video5,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end

 
 end




--x = string.gsub(x, '"http.-.mp4"', '')

       for url1, url2, url3, url4, url5, total in string.gmatch(x,'"url":"(http.-/hls/)(.-)(/s%d+)(e%d+)(_.-)".-quality":(.-),') do


			

    title1 = string.gsub(url3, '/s', 'Сезон ')
    title = string.gsub(url4, 'e', 'серия  ')
    
    title2 = string.gsub(url2, '(.-%d)', '')
    
      t['view'] = 'simple'
      
      table.insert(t, {title = '(' .. total .. 'p)' .. title1 .. ' ' .. title .. ' ' .. title2, mrl = url1 .. url2 .. url3 .. url4 .. url5, image = image})
      

      end
	
end




   
    elseif args.q == 'kino4k' then
    
    -- local x = conn:load(args.id)
		local x = conn:load('http://wtch.ch/lite/fxapi?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 

    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
   if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
    
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end

    
end
end





--https://lamp-movie.ru


--http://178.20.46.40:12600/lite/filmix?title=чужой+1979

elseif args.q == 'kinofit' then

local x = conn:load('http://178.20.46.40:12600/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2)

for id in string.gmatch(x,'<div class="videos__line".-"method":"link".-"url":"http.-postid=(.-)\\u0026') do


id = string.gsub(id, '^(.-)', 'item/')
         
         id=base64_encode(id)
 

 
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')


  
     for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = (total1) .. ' ' .. tolazy(total), mrl = url2})
    
        end
        end
        
  
      




     local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')



      for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
  
       total = string.gsub(total, '<!%[CDATA%[', '')
       total = string.gsub(total, ']]>', '')
       
     local x = conn:load(url1 .. '&box_mac=acace24b8434')

    
    for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-сезон).-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
       total1 = string.gsub(total1, ']]> <![CDATA[', '')
       total1 = string.gsub(total1, ']]>', '')
   
        local x = conn:load(url2 .. '&box_mac=acace24b8434')
   

     
     for total2, total3, url3 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<playlist_url><!%[CDATA%[http.-&goto=(.-)&.-]]') do
    
 --     total2 = string.gsub(total2, '<!%[CDATA%[', '')
   --   total2 = string.gsub(total2, ']]>', '')
 
 
 t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total2) .. ' ' .. tolazy(total), mrl = '#stream/q=kinofits&id=' .. url3})
 
 end
 end
 end
 end
 
 
 elseif args.q == 'kinofits' then

local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. args.id .. '&viewseason' .. '&box_mac=acace24b8434')
 
 
      
  --    local x = conn:load(url3 .. '&box_mac=acace24b8434')
 
     
     
     for total4, url4 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]].-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do
    
       total4 = string.gsub(total4, '<!%[CDATA%[', '')
      total4 = string.gsub(total4, ']]>', '')
    
    
    
      t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total4), mrl = url4})
    
        end
      


elseif args.q == 'hdrezkatest1' then


	local url = 'https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-/(film.-)"') do


local x = conn:load('http://78.40.195.218:9118/lite/rezka?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')


x = string.gsub(x, '\\u0026', '&')

for id, id1, title in string.gmatch(x, 'class=.-videos__movie.-"method".-"call".-"url".-http.-&id=(.-)&t=(.-)&.-class="videos__item%-title">(.-)<') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=hdrezkatestm&id=' .. id .. '&id1=' .. id1})

end
end
   
local url = 'https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		

for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-/(series.-)"') do


	local x = conn:load('http://78.40.195.218:9118/lite/rezka?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')



x = string.gsub(x, '\\u0026', '&')

for url in string.gmatch(x, '<div class=.-videos__season.-"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-)<') do

local x = conn:load('http://78.40.195.218:9118' .. url)

	x = string.gsub(x, '\\u0026', '&')
	
	for id, title in string.gmatch(x,'class="videos__button.-"method".-"link".-"url".-"http.-&href=series.-&id=.-&t=(.-)"}.->(.-)<') do
	
	
	for id1, id2, id3, title1 in string.gmatch(x,'<div class="videos__item videos__movie.-"method".-"call".-"url":"http.-&id=(.-)&.-&s=(.-)&e=(.-)".-class="videos__item%-title">(.-)<') do
	

	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=hdrezkatests&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

end
end
end
end




elseif args.q == 'hdrezkatest' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=hdrezkatestm&id=' .. id .. '&id1=' .. id1})

end
end



local headersv = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "cf_clearance=Y2IBRMvwTZdt8Tbx_1Xs5tv8TnX6zZJ9DHd_BiAk8Rc-1779116549-1.2.1.1-dEerxteOpSv71mNrWStyPma5Hvvi4QYC_IgXwQ4AOLH6M1IvxzDIUnL_ayXn34I6wJcND4vbGokfcZ_D_zPh3Ir5uH5.YBGgg_LBytoWGQnfpGRFAZT.fafeIP2SnbZxYevAi3eck6JGb6SkFnqvzAIdIg_eJLJ58sNyrMxTfPySORsH2L8VxKJU566frP5aygOAo.gtgpZgvfhGuTrSiejVkpcHTzdfPkPLySxj0RW06Ef6MF5xg.TCIvTjd1j6Mt1z_a42hJZJs68da06VWiRvwU7lPD.VXHRJle6LgpJ2QWGOKhewXNI_zwBXiHx5oGVIJMGflag4AF60zGtnDW8bWFHG8Nmaf9gyTyBxPkUgMDpuz_RDG0ffnp3EUDq7Vd5QN2r_lBKjkY2AF7yQa2LaG.gg3J4j_rVWARbxE28; PHPSESSID=bc8a53857dvost9vn3jpt7lvv5; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _ym_isad=1; _clck=1snsa8l%5E2%5Eg65%5E0%5E2329; _clsk=ivnhi3%5E1779116875943%5E2%5E0%5Eq.clarity.ms%2Fcollect; _ym_hostIndex=0-1%2C1-0",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}





local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do
	--	local x = http.getz('https://kinopub.me' .. args.id, headersv)
		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}
		
		local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headersv, params)			
					

local x = json.decode(x)


url = url_for('get_movie', {file = x['url'], t = t['name']})


--url = string.gsub(url, '%%3D', '=')

--url = string.gsub(url, '#self/file=%%23h', '')


--url = string.gsub(url, '//_--//JCQjISFAIyFAIyM=', '')
--url = string.gsub(url, '//_--//Xl5eIUAjIyEhIyM=', '')
--url = string.gsub(url, '//_--//IyMjI14hISMjIUBA', '')

--url = string.gsub(url, '//_--//QEBAQEAhIyMhXl5e', '')
--url = string.gsub(url, '//_--//JCQhIUAkJEBeIUAjJCRA', '')

--url = base64_decode(url)

url = urldecode(url)

for quali, url1 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do

quali = string.gsub(quali, '<span class="pjs%-prem%-quality">', '')

quali = string.gsub(quali, '<img src="https://st.hdrezka.ac/templates/hdrezka/images/prem%-icon.svg" alt=""></span>', '')

quali = string.gsub(quali, '<img src="https://static.hdrezka.ac/templates/hdrezka/images/prem-icon.svg" alt=""></span>', '')


quali = string.gsub(quali, '<img src="http://static.rezka.cloud/templates/hdrezka/images/prem-icon.svg" alt=""></span>', '')


t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url1})

end
end
	end	
end
   
   
   
 
   
local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=hdrezkatests&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

end
end
end
end
end

end
 


      elseif args.q == 'hdrezkatests' then
   
   
   local headerss = {
["Host"] = "hdrzk.org",
 ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
 ["X-Requested-With"] = "XMLHttpRequest",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5"
}
	
	
local headers = {
    ["Host"] = "kinopub.me",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Origin"] = "https://kinopub.me",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://kinopub.me/",
    ["Cookie"] = "PHPSESSID=3k1irc24d5vkhlq0o8tgkreu98; dle_user_taken=1; dle_user_token=9fa1c21c1cce7e5a08ff3af2359d0a95; _ym_uid=177849923871001680; _ym_d=1778499238; _ym_isad=2; _clck=1v54x0m%5E2%5Eg5y%5E0%5E2322; _clsk=1ctr31s%5E1778499240957%5E1%5E0%5Eq.clarity.ms%2Fcollect",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}
	
	
    
    local headersx = {['X-Requested-With'] = 'XMLHttpRequest'}
					local params = http.encode{
		id = args.id1,
		translator_id = args.id,
		season = args.id2,
		episode = args.id3,
		action = 'get_stream'
					}
					
					local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})

local x = json.decode(x)

	url = url_for('get_stream', {file = x['url'], t = t['name']})



--url = string.gsub(url, '%%3D', '=')

--url = string.gsub(url, '#self/file=%%23h', '')


--url = string.gsub(url, '//_--//JCQjISFAIyFAIyM=', '')
--url = string.gsub(url, '//_--//Xl5eIUAjIyEhIyM=', '')
--url = string.gsub(url, '//_--//IyMjI14hISMjIUBA', '')

--url = string.gsub(url, '//_--//QEBAQEAhIyMhXl5e', '')
--url = string.gsub(url, '//_--//JCQhIUAkJEBeIUAjJCRA', '')

url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do

quali = string.gsub(quali, '<span class="pjs%-prem%-quality">', '')

quali = string.gsub(quali, '<img src="https://st.hdrezka.ac/templates/hdrezka/images/prem%-icon.svg" alt=""></span>', '')

quali = string.gsub(quali, '<img src="https://static.hdrezka.ac/templates/hdrezka/images/prem-icon.svg" alt=""></span>', '')


quali = string.gsub(quali, '<img src="http://static.rezka.cloud/templates/hdrezka/images/prem-icon.svg" alt=""></span>', '')


t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url3})

end      
   
   
   
    
    	elseif args.q == 'hdrezkatestm' then
    
local headerss = {
["Host"] = "hdrzk.org",
 ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
 ["X-Requested-With"] = "XMLHttpRequest",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5"
}
	
	
local headers = {
    ["Host"] = "kinopub.me",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Origin"] = "https://kinopub.me",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://kinopub.me/",
    ["Cookie"] = "PHPSESSID=3k1irc24d5vkhlq0o8tgkreu98; dle_user_taken=1; dle_user_token=9fa1c21c1cce7e5a08ff3af2359d0a95; _ym_uid=177849923871001680; _ym_d=1778499238; _ym_isad=2; _clck=1v54x0m%5E2%5Eg5y%5E0%5E2322; _clsk=1ctr31s%5E1778499240957%5E1%5E0%5Eq.clarity.ms%2Fcollect",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}
	
	
	
					local params = http.encode{
						id = args.id,
						translator_id = args.id1,
						action = 'get_movie'
					}
					
					local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})




local x = json.decode(x)

	url = url_for('get_movie', {file = x['url'], t = t['name']})



--url = string.gsub(url, '%%3D', '=')

--url = string.gsub(url, '#self/file=%%23h', '')


--url = string.gsub(url, '//_--//JCQjISFAIyFAIyM=', '')
--url = string.gsub(url, '//_--//Xl5eIUAjIyEhIyM=', '')
--url = string.gsub(url, '//_--//IyMjI14hISMjIUBA', '')

--url = string.gsub(url, '//_--//QEBAQEAhIyMhXl5e', '')
--url = string.gsub(url, '//_--//JCQhIUAkJEBeIUAjJCRA', '')

url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do

quali = string.gsub(quali, '<span class="pjs%-prem%-quality">', '')

quali = string.gsub(quali, '<img src="https://st.hdrezka.ac/templates/hdrezka/images/prem%-icon.svg" alt=""></span>', '')

quali = string.gsub(quali, '<img src="https://static.hdrezka.ac/templates/hdrezka/images/prem-icon.svg" alt=""></span>', '')


quali = string.gsub(quali, '<img src="http://static.rezka.cloud/templates/hdrezka/images/prem-icon.svg" alt=""></span>', '')

t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url3})

end






     elseif args.q == 'hdrezka' then

  --http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=чужой:+земля-2025&box_mac=acace24b8434

--local url = 'http://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load('https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href=.-//.-/(.-)"') do
   
 
-- http://78.40.195.218:9118/lite/rezka/?href=series/horror/79810-ono-dobro-pozhalovat-v-derri-2025-latest.html&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv
 
      local x = conn:load('http://78.40.195.218:9118/lite/rezka/?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')


 x = string.gsub(x, '\\u0026', '&')

for id, title in string.gmatch(x, 'class=.-videos__movie.-"method".-"call".-"url.-voice=(.-html).-class="videos__item%-title">(.-)<') do

id = urldecode(id)
 
 
 
 
     --     for id, title in string.gmatch(x,'data%-translator_id.-href="(.-)">(.-)</a>') do
     t['view'] = 'simple'
  
  

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. id) .. '&box_mac=acace24b8434')
    

  
  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title =tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
  end
  
  local x = conn:load('http://78.40.195.218:9118/lite/rezka/?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')


 x = string.gsub(x, '\\u0026', '&')
 
  for url3, id1, total in string.gmatch(x, 'class="videos__button.-"method".-"url".-href=(.-html).-&t=(.-)".->(.-)<') do
 
 url3 = urldecode(url3)
  
         
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. url3) .. '&box_mac=acace24b8434')
  
  
         
for title1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=.-&translate=.-&season=(.-)&episode=(.-)]]') do
   
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(total), mrl = '#stream/q=rezkis&id=' .. url3 .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
        
end
 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. url) .. '&box_mac=acace24b8434')
    

      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end

    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
  
t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    end
   
    
elseif args.q == 'rezkis' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. args.id) .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end

elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end







     
     elseif args.q == 'rezka' then

--https://evkh.lol/lite/rhsprem?kinopoisk_id=464475&title=франкенштейн&year=2025

--https://lampa.remagick.ru/lite/rhsprem

    		local x = conn:load('https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '+' .. args.id2)
    
  --table.insert(t, {title = 'https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '+' .. args.id2, mrl = 'https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
  
       local url = string.match(x, '<div class="videos__line".-method.-"url".-href=(.-)"') 
       
    local slist = string.match(x, '"quality"(.-)}')
      
    if slist then
   
   for  total1, url3 in string.gmatch(slist, '"(%d+p)":"(http.-mp4)') do
  
    --  url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'simple'

   table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
    end
  
 -- https://lampa.remagick.ru/lite/rhsprem?href=films%2fhorror%2f82897-prishlite-pomosch-2026.html
  
  
  
  
  local x = conn:load('https://lampa.remagick.ru/lite/rhsprem?href=' .. url)
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
      -- t['view'] = 'simple'
   
      local x = conn:load(url2)

  local slist = string.match(x, '"quality"(.-)}')
      
      
   
   for  total1, url3 in string.gmatch(slist, '"(%d+p)":"(http.-mp4)') do
  
   --   url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')' .. total, mrl = url3})

     end  
 end
     




   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      



      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rez' then

   local x = conn:load('https://lampa.remagick.ru/lite/rhsprem/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
  
--https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=4760854&title=%D0%9A%D0%BE%D1%80%D0%BE%D0%BB%D1%8C+%D0%A2%D0%B0%D0%BB%D1%81%D1%8B&year=2025&serial=1

        elseif args.q == 'kinobase' then

--http://31.129.234.181:80/lite/kinobase?href=film/244146-na-vershine&t=&s=1&uid=guest

   local x = conn:load('https://kinobase.org/search?query=' .. urlencode(args.id1) .. '+' .. args.id2)
   
 for title in string.gmatch(x, '<div class="poster".-<a href="/(.-)"') do
        
   
    url = string.gsub(title, '^(.-)', 'http://31.129.234.181/lite/kinobase?href=') .. '&t=&s=1'
    

     local x = conn:load(url .. '&uid=guest')
   

      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
   --   local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(%d+p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
     t['view'] = 'simple'

url2 = string.gsub(url2, '\\u002B', '+')

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2})
    end
     end  
  

  
     for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
      local x = conn:load(url)
   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
    
       
      local x = conn:load(url2 .. '&uid=guest')

      
      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
    
url3 = string.gsub(url3, '\\u002B', '+')

    
         
    url3 = string.gsub(url3, '^(.-)', 'http://31.129.234.181')
    
       t['view'] = 'simple'



    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3})

    end   
    end
    end
   
end




   elseif args.q == 'kinotop' then


   
local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=search&search=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&box_mac=acace24b8434')
   
       for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do
 
       local x = conn:load(url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')
  
  
     for total1, url2  in string.gmatch(x, '<channel.-<title><!%[CDATA%[(%d+p)]]></title.-<stream_url><!%[CDATA%[(http.-)]]') do
    
    
     t['view'] = 'simple'
      table.insert(t, {title = total1, mrl = url2})

       end
     end
   

for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[http.-(&media=.-)]]') do


       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=watch' .. url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')


     for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = (total3) .. (total4), mrl = url3})

end
   
   
  for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-сезон)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
        local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = total2 .. (total3) .. (total4), mrl = url3})

end
end
     end
      

elseif args.q == 'jac' then

    

   local x = conn:load('https://lam.akter-black.com/lite/jac?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
   
       t['view'] = 'simple'
    table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     
     


		local x = conn:load('https://lam.akter-black.com/lite/jac?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
  
  
  
  
  
       t['view'] = 'simple'
     table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     


--https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=570402&title=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB&year=2025
     
--  https://lam.maxvol.pro/lite/pidtor/serial/548bae27dca47ab2805465cc12ab1d9a89d15426?tr=
     
     
     
     
     
     elseif args.q == 'result' then
      args.id = args.id:lower() 
      
      local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end
   
   
   
    elseif args.q == 'pidtor' then
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
 -- table.insert(t, {title = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})

      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-?tr=).-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
  


--https://lam.akter-black.com/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=






for url2, title in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')

      local x = conn:load(url2)
    

    
      for url3, total  in string.gmatch(x, '"method":"link".-"url":"http.-/lite/pidtor/serial/(.-)?tr=.-class="videos__item%-title videos__season%-title">(.-)</div>') do


--url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')

     url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'
     table.insert(t, {title = title .. ' ' ..  total,mrl = '#stream/q=result&id=' .. url3,image = image})
     end
     
   end
 
 
 
 
 
 
elseif args.q == 'jacred' then

local x = conn:load('http://jacred.stream/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
 


 x = string.gsub(x, '",', '\\u0026')	
 
	
 
  x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
     x = string.gsub(x, '\\u041A', 'К')
       x = string.gsub(x, '\\u043A', 'к')  
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  x = string.gsub(x, '\\u041B', 'Л')
       x = string.gsub(x, '\\u041b', 'Л')
    x = string.gsub(x, '\\u043B', 'л')
       x = string.gsub(x, '\\u043b', 'л')
     
     x = string.gsub(x, '\\u041C', 'М')
       x = string.gsub(x, '\\u043C', 'м')
       x = string.gsub(x, '\\u041D', 'Н')
       x = string.gsub(x, '\\u043D', 'н')
       x = string.gsub(x, '\\u041E', 'О')
     
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
    x = string.gsub(x, '\\u043E', 'о')
       x = string.gsub(x, '\\u043e', 'о')
    
    x = string.gsub(x, '\\u041F', 'П')
       x = string.gsub(x, '\\u043F', 'п')
     
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
          x = string.gsub(x, '\\u042A', 'Ъ')
        x = string.gsub(x, '\\u044A', 'ъ')
        x = string.gsub(x, '\\u042B', 'Ы')
        x = string.gsub(x, '\\u044B', 'ы')
        x = string.gsub(x, '\\u042C', 'Ь')
        x = string.gsub(x, '\\u044C', 'ь')
        x = string.gsub(x, '\\u042D', 'Э')
        x = string.gsub(x, '\\u044D', 'э')
        x = string.gsub(x, '\\u042E', 'Ю')
        x = string.gsub(x, '\\u044E', 'ю')
        x = string.gsub(x, '\\u042F', 'Я')
     
     x = string.gsub(x, '\\u044F', 'я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')

 
 for id, title, total, total1, total2 in string.gmatch(x,'{"tracker".-"magnet:?.-btih:(.-)\\u0026.-name":"(.-)\\u0026.-"relased":(.-),.-"quality":(.-),"voices":%[(.-)]') do
 
total2 = string.gsub(total2, '\\u0026', '",')
 
 
    t['view'] = 'simple'
   
 -- https://lam.akter-black.com/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u 
 -- https://ts.maxvol.pro/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u
  
  
   table.insert(t, {title =  '(' .. total1 .. 'p) ' .. args.id1 .. ' (' .. args.id2 .. ') '  .. ' ' .. total2, mrl = 'm3u+https://ts.maxvol.pro/stream?link=' .. id .. '&m3u'})
 
--   table.insert(t, {title = '(' .. total1 .. 'p) ' .. args.id1 .. ' (' .. args.id2 .. ') '  .. ' ' .. total2, mrl = '#stream/q=jacreds&id=' .. id, image = image})
		end
 
 
 elseif args.q == 'jacreds' then

     args.id = args.id:lower() 

local x = conn:load('https://ts.maxvol.pro/stream?link=' .. args.id .. '&m3u')
 
 
 for title, url in string.gmatch(x,'EXTINF:.-,(.-)(http.-&play)') do
 
 t['view'] = 'simple'
   
 table.insert(t, {title = title, mrl = url})
		end
 
 
 
 
 
 elseif args.q == 'torrs' then

local x = conn:load('http://torrs.ru/search?query=' .. urlencode(args.id1) .. '(' .. args.id2 .. ')')
   
 --  table.insert(t, {title = 'http://torrs.ru/search?query=' .. urldecode(args.id) .. '(' .. args.id1 .. ')', mrl = '#stream/q=result&id=' .. 'http://torrs.ru/search?query=' .. urldecode(args.id) .. '(' .. args.id1 .. ')', image = image})
   
	--	local x = conn:load(url)
		x = string.gsub(x, '",', '\\u0026')	
    --    x = string.gsub(x, '&', '\\u0026')	
		
    for title, total in string.gmatch(x,'"size".-"title":"(.-)\\u0026.-"magnet":"magnet:?.-btih:(.-)\\u0026') do
      
--title = string.gsub(title, '\\u0026','&')
     -- total = string.gsub(total, '\\u0026','&')
   t['view'] = 'simple'
   
   table.insert(t, {title = title, mrl = '#stream/q=results&id=' .. total, image = image})
		end


elseif args.q == 'results' then
		
      args.id = args.id:lower() 

local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      
      
      
      
      
      --	 https://lam.akter-black.com/lite/pidtor/serial/7d2dd45792a2695ff0cc88cde4af51cd5189dfb4?tr=	
--https://lam.akter-black.com/lite/jac?serial=1&title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%20%D0%B7%D0%B5%D0%BC%D0%BB%D1%8F


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   end
 
 
 
 
 
 
    elseif args.q == 'awmzone' then

--https://lampa.plus



local headers = {
    ["Host"] = "lampa.plus",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6IkRHakdrTGkySDVEaVNRWE1hOUdCWEE9PSIsInZhbHVlIjoid1VGNlpvRGt0N3dENTZXQkxOMllwdHZlMDZzRTlwRDV1aWc5Q2JJUDRhbk1rSzR5dDZuMGhIaS9OSFdQcFhLWHk0ZnBxZDk2R1B6S2hvc2phK29JbSt4TElabGxPdXlPSEgwUEJoQ2daS3BGd0FzdjFPNEFEOERPUVBZZVFxMjkiLCJtYWMiOiIxYjc5YWIxNzk2YzZhODUzMTk3MjA3ODlhMGZlNWFiM2NlNjkzYmVlNzAzZmIwNTcxODFhNmUzZTcyYzBiMDdlIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlFMZEFSVWhwTWpxNUpkSGNCSDdYT1E9PSIsInZhbHVlIjoiNkxHdWhoWE1KOGYyQzBSazZvNldVOGlQb1pta3dOalJtLzBjcktVTFBFTVJCNEwxbXNQUmdPbE9OMHJXejUrdFhmSS9GSk0rOUkzVG8ydHhxU21uRDNzSnh4ekNUeUJGaHV1MGVRUzhFQllzdzVwS3FyRTNQbk1xZXdQd0tpQUYiLCJtYWMiOiI4ZDQ0NjFmMGJmYmJjZDdmOGFhOTUyMzQxYzQzNzAzOGFlZDMwYWQzMjU2NDhhZDM4OTMyYzU4Mzc3YTQ5OTkxIiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none"
}
 
 
  local search = 'https://lampa.plus/mary/spotlight?search=' .. urlencode(args.id1)
  
--  https://lampa.plus/36040688-mumiia.html
  
  local x = http.getz(search, headers)



for link in string.gmatch(x,'avatar.-name.-link":"(.-)"') do

link = string.gsub(link, '^(.-)', 'https://lampa.plus')

link = string.gsub(link, '\\', '')
local x = conn:load(link)

if x then

x = string.gsub(x, '\\', '')



local id, title = string.match(x,'"embedUrl":"http.-players/(.-)".-<h1.->(.-)<')


t['view'] = 'simple'

  table.insert(t, {title = title, mrl = '#stream/q=awmzonepl&id=' .. 'https://lampa.plus/embed-players/' .. id})
  
  end
end









local headers = {
    ["Host"] = "turboserial.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6IkRHakdrTGkySDVEaVNRWE1hOUdCWEE9PSIsInZhbHVlIjoid1VGNlpvRGt0N3dENTZXQkxOMllwdHZlMDZzRTlwRDV1aWc5Q2JJUDRhbk1rSzR5dDZuMGhIaS9OSFdQcFhLWHk0ZnBxZDk2R1B6S2hvc2phK29JbSt4TElabGxPdXlPSEgwUEJoQ2daS3BGd0FzdjFPNEFEOERPUVBZZVFxMjkiLCJtYWMiOiIxYjc5YWIxNzk2YzZhODUzMTk3MjA3ODlhMGZlNWFiM2NlNjkzYmVlNzAzZmIwNTcxODFhNmUzZTcyYzBiMDdlIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlFMZEFSVWhwTWpxNUpkSGNCSDdYT1E9PSIsInZhbHVlIjoiNkxHdWhoWE1KOGYyQzBSazZvNldVOGlQb1pta3dOalJtLzBjcktVTFBFTVJCNEwxbXNQUmdPbE9OMHJXejUrdFhmSS9GSk0rOUkzVG8ydHhxU21uRDNzSnh4ekNUeUJGaHV1MGVRUzhFQllzdzVwS3FyRTNQbk1xZXdQd0tpQUYiLCJtYWMiOiI4ZDQ0NjFmMGJmYmJjZDdmOGFhOTUyMzQxYzQzNzAzOGFlZDMwYWQzMjU2NDhhZDM4OTMyYzU4Mzc3YTQ5OTkxIiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none"
}
 
 
  local search = 'https://turboserial.com/mary/spotlight?search=' .. urlencode(args.id1)
  
  
  
  local x = http.getz(search, headers)



for link in string.gmatch(x,'avatar.-name.-link":"(.-)"') do

link = string.gsub(link, '^(.-)', 'https://turboserial.com')

link = string.gsub(link, '\\', '')
local x = conn:load(link)

if x then

x = string.gsub(x, '\\', '')
 
local id, title = string.match(x,'"embedUrl":"http.-players/(.-)".-<h1.->(.-)</h1>')


t['view'] = 'simple'

  table.insert(t, {title = title, mrl = '#stream/q=awmzonepl&id=' .. 'https://turboserial.com/embed-players/' .. id})
  
  end
end


elseif args.q == 'awmzonepl' then

local url = args.id

local headers = {
   ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6ImJIZEJtYTVWZWJ0U3N3cHlGKzAxVlE9PSIsInZhbHVlIjoiOVNRNFRPWjZXZmpob01WZk5sSkJGTTNPNk9PN0NaZ2w4dVhIYVpVaklFWURXVFRTTjl5aDA3aE92N2VzMVJZV09HNGhiemNzRUtzcHJ1S1JwWmhIS1RMNTVNejh2RmxzMmZROWdwSDhXc01xTSttV2MyVHBwcmFuczNybTlieXAiLCJtYWMiOiJkOTE3NzUyYzUyNGNhNmVhMDJkMWE2YTZhZDA1NjEzMjA3MWVhNzk1Yjc3YjVmNWY4ZWYyZTc2OWEwNzRhZmVhIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6InVDdE9UWE5lQjJjUVgzbmNPMWZML0E9PSIsInZhbHVlIjoicE04emNaeGJiSXVMQXppNmIva1RjYkcrZ3FDSkZKLzBYbkM3RFczTzBBUkNEUUx2K0tEMjhzUjQ4cXByVE1JZmJNbFRkYnZJbkdmTWVHM2I3RTd6czMzZGN1YVhLVnF5L3Y5cDAwTGNvN1BYNTZYVFBrRW9hU0d4YVh3K21QQnAiLCJtYWMiOiI4MjBiNmJhM2RkNTBjYmY5ZTFlNmU1NTA3N2JkMzNhMDMzZjcxMGFkZTA2OWE5YWZlZjE2NTRhODhhYWZiZjI1IiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
["Priority"] = "u=0, i"
}

 
  local x = conn:load(url)

  
  
  local slist = string.match(x,'Playerjs.-atob.-&#039;(.-)&#039;%)+')
  
  if slist then
  

  
  slist = base64_decode(slist)
  

local slist1 = string.match(slist,'"file":"#2(.-)\"+')



slist1 = string.gsub(slist1, '\\', '') 


slist1 = string.gsub(slist1, 'cG9zb3Npa2xvdW4=', '')

slist1 = string.gsub(slist1,'ZHZhZG9sYm9lYmE=', '')



slist1 = string.gsub(slist1, '//', '') 

slist1 = base64_decode(slist1)

slist1 = urldecode(slist1)



for title, url1, url2 in string.gmatch(slist1,'{(.-)}(http.-)(/movie.-m3u8)') do

url2 = string.gsub(url2, '/hls', '/1080.mp4:hls:manifest')

t['view'] = 'simple'

  table.insert(t, {title = '(1080p) ' .. title, mrl =  url1 .. url2})
  
  end
  
for title, url1, url2 in string.gmatch(slist1,'{(.-)}(http.-)(/movie.-m3u8)') do

url2 = string.gsub(url2, '/hls', '/720.mp4:hls:manifest')

t['view'] = 'simple'

  table.insert(t, {title = '(720p) ' .. title, mrl = url1 .. url2})
  
  end
 
 for title, url1, url2 in string.gmatch(slist1,'{(.-)}(http.-)(/movie.-m3u8)') do

url2 = string.gsub(url2, '/hls', '/480.mp4:hls:manifest')

t['view'] = 'simple'

  table.insert(t, {title = '(480p) ' .. title, mrl = url1 .. url2})
  
  end
 
for title, url1, url2 in string.gmatch(slist1,'{(.-)}(http.-)(/movie.-m3u8)') do

url2 = string.gsub(url2, '/hls', '/360.mp4:hls:manifest')

t['view'] = 'simple'

  table.insert(t, {title = '(360p) ' .. title, mrl = url1 .. url2})
  
  end
 
 
 
 
 for season, episode, slist2 in string.gmatch(slist,'{"id":"S(.-)E(.-)".-"file":"#2(.-)\"+') do

slist2 = string.gsub(slist2, '\\', '') 


slist2 = string.gsub(slist2, 'cG9zb3Npa2xvdW4=', '')

slist2 = string.gsub(slist2,'ZHZhZG9sYm9lYmE=', '')



slist2 = string.gsub(slist2, '//', '') 

slist2 = base64_decode(slist2)

slist2 = urldecode(slist2)
 
 
 for title, url2 in string.gmatch(slist2,'{(.-)}(http.-m3u8)') do

url2 = string.gsub(url2, '/hls', '/1080.mp4:hls:manifest')

t['view'] = 'simple'

  table.insert(t, {title = '(1080p) ' .. 'Сезон ' .. season .. ' Серия ' .. episode .. ' ' .. title, mrl = url2})
  
  end
 end
 
 
 end
 
 
 
       

elseif args.q == 'anwap' then
  
  
--https://tv.anwap.today/films/search/?toch=on&slv=чужой-Alien&vid=1
  
  
--  local x = conn:load('https://tv.anwap.today/films/search/?slv=' .. urlencode(args.id1) .. '-' .. urlencode(args.id4) .. '&vid=' .. args.id5 .. '&toch=' .. args.id6)
  
  local x = conn:load('https://tv.anwap.today/films/search/?toch=on' .. '&slv=' .. urlencode(args.id1) .. '&vid=1')

  
local slist=string.match(x, '</form><div class="save">По.-id="cn"(.-)"menuniz"')
  

  if slist then
    for url, title in string.gmatch(slist, '<div class="my_razdel film".-<a href="(.-)".-alt="(.-)"') do

     local x = conn:load('https://tv.anwap.today' .. url)

    local slist=string.match(x, '<ul class="tl2">(.-)</ul>')


		if slist then
			for url1, title2 in string.gmatch(slist, '<a href="(/films/load.-)">Скачать MP4(.-)<.-</a>') do
       print(url)
	   	url1 = string.gsub(url1, '^(.-)', 'https://tv.anwap.today')
   
      t['view'] = 'simple'
        table.insert(t, {title = title2 .. tolazy(title), mrl = url1})
	
		end
		end
		end
		end
  
  
--https://tv.anwap.today/films/search/?slv=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&alien&vid=1&toch=on
--https://tv.anwap.today/serials/search/?word=%D1%87%D1%83%D0%B6%D0%BE%D0%B9-alien&vid=1&t=on

local x = conn:load('https://tv.anwap.today/serials/search/?t=on' .. '&word=' .. urlencode(args.id1) .. '&vid=1') 

--local x = conn:load('https://tv.anwap.today/serials/search/?word=' .. urlencode(args.id1) .. '-' .. urlencode(args.id4) .. '&vid=' .. args.id5 .. '&toch=' .. args.id6)




   local slist=string.match(x, '</form><div class="save">По.-id="cn"(.-)"menuniz"')

	if slist then

       for url, title in string.gmatch(slist, '<div class="my_razdel film".-<a href="(.-)".-alt="(.-)"') do

    
    local x = conn:load('https://tv.anwap.today' .. url)

       local slist=string.match(x, '<ul class="tl2">(.-)"popular"')


		if slist then
			for url1, title1 in string.gmatch(slist, '<li><a href="(/serials/s.-)">(.-)</a></li>') do
       
       t['view'] = 'simple'
      
       table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=sezon&id=' .. url1})
        
        end
		end
		end	
end


elseif args.q == 'sezon' then

local page = tonumber(args.page or 1)
    
    local x = conn:load('https://tv.anwap.today' .. args.id .. '-' .. tostring(page))
		

      -- local slist=string.match(x, '<ul class="tl">(.-)</ul>')


	--	if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/down.-)">(.-)</a>') do
       print(url)
	  -- 	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=sezond&id=' .. url})
		end 
	
	
			
	local url = '#stream/page=' .. tostring(page + 1) .. '&q=sezon&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


  
    elseif args.q == 'sezond' then
  
   local x = conn:load('https://tv.anwap.today' .. args.id)
  
  
  
  local slist=string.match(x, 'tlsiconkoi.-<ul class="tlsiconkoi">(.-)</ul>')


		if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/load.-)".-Скачать(.-)<span') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = 'Смотреть' .. tolazy(title), mrl = url})
	
		end
		end	







elseif args.q == 'collaps' then
  
  
  local x = conn:load('http://178.20.46.40:12600/lite/collaps?kinopoisk_id=' .. args.id3)

for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})


       
    end

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end





      local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)
   
   
   for title in string.gmatch(x, '"iframe_url":"http.-/embed/.-/(.-)"') do
   

      

url = string.gsub(title, '^(.-)', 'http://178.20.46.40:12600/lite/collaps?orid=')
     local x = conn:load(url)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

     end  
  

     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/collaps.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end
end
end



--https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=386

elseif args.q == 'collaps2' then

local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)

 
   for url in string.gmatch(x, '"iframe_url":"(http.-)"') do

local slist = string.match(x, '"voiceActing"(.-)]')

    if slist then 
    
    for total in string.gmatch(slist, '"(.-)"') do



local x = conn:load(url .. '?oneSound=' .. urlencode(total))


table.insert(t, {title = url .. '?oneSound=' .. urlencode(total), mrl = url .. '?oneSound=' .. urlencode(total)})

for url1 in string.gmatch(x, 'hls: "(http.-)"') do

table.insert(t, {title = tolazy(total), mrl = 'https://dl.showvid.ws/x-px?m=' .. url1 .. '&x-cdn=10551403'})

       
    end
end
end
end
 


elseif args.q == 'collaps-dash' then
  
 

  local x = conn:load('http://178.20.46.40:12600/lite/collaps-dash?kinopoisk_id=' .. args.id3)



   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



elseif args.q == 'kinotochka' then
  
 

--https://kinovibe.vip/embed/8003

 local url = 'https://kinovibe.cc/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3
--https://kinovibe.co/embed/kinopoisk/386/


  
-- local url = 'https://kinovibe.cc/?do=search&mode=advanced&subaction=search&story=' .. urlencode(args.id1)

		
		local x = conn:load(url)
		
       
			x = string.gsub(x, '\\', '')
			
  
 -- https://kinovibe.vip/27131-persi-dzhekson-i-olimpiycy-2-sezon-2025.html
 
 
  
  local url1 = string.match(x,'"url":"(http.-)"')
  
 -- elseif args.q == 'kinotochkav' then
  
  

    local x = conn:load(url1)

local url, url1 = string.match(x, 'Playerjs.-file:"(http.-video_mp4)(.-mp4)')

			
t['view'] = 'simple'

 table.insert(t, {title = 'Смотреть', mrl = url .. url1})



for url in string.gmatch(x, 'Playerjs.-file:"(http.-_480.mp4)') do

			
t['view'] = 'simple'

 table.insert(t, {title = '480p', mrl = url})


url = string.gsub(url, '_480.mp4', '_720.mp4')
			
t['view'] = 'simple'
 
 table.insert(t, {title = '720p', mrl = url})



end
    




 for url in string.gmatch(x, 'Playerjs.-file:"(http.-txt)"') do

   local x = conn:load(url)

--table.insert(t, {title = url, mrl = url})

--x = string.gsub(x, '[480,720]', '')


for total, title, url1 in string.gmatch(x,'"comment":"(.-Серия).-(%[.-])".-"file":"(http.-/s%d+e%d+)%_.-"') do



t['view'] = 'simple'
  
  table.insert(t, {title =  '(' .. '480' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_480.mp4'})


table.insert(t, {title = '(' .. '720' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_720.mp4'})



end




local x = conn:load(url)

  for title, url2, url3, url4 in string.gmatch(x,'"comment":".-(%[.-])".-"file":"(http.-/s)(%d+)e(%d+)%.mp4"') do
  
  t['view'] = 'simple'


table.insert(t, {title = 'Сезон ' .. url3.. ' ' .. 'серия ' .. url4 .. title, mrl = url2 .. url3 .. 'e' .. url4 .. '.mp4'})


end
end






elseif args.q == 'fanserial' then

--https://1fanserials.online/index.php?story=чужой,1979&do=search&subaction=search

-- https://fanserial.me/index.php?do=search&subaction=search&story=чужой,1979
 
 --id="searchinput.-class="item%-search%-header".-<a href="(http.-)".->(.-)</a>.-class="name%-origin%-search".-%((.-)%)<
 
  -- local x = http.getz('https://fanserial.me/index.php?do=search&subaction=search&story=' .. urlencode('крид'))
   
  -- local url = string.match(x,'id="searchinput.-class="item%-search%-header".-<a href="(http.-)"')
   
 
 
 
 
 local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
["Host"] = "fanserial.me",
["Accept"] = "*/*",
["Content-Type"] = "application/x-www-form-urlencoded",
["Accept-Encoding"] = "gzip",
["Cookie"] = "_ym_uid=1777913146128317156; _ym_d=1777913146; _ma=ccc1a7ff-54a2-f4c4-90c2-90b0f4c074ee; _ym_isad=2; _ym_visorc=w; fid=efe7497d-0d56-490a-9e4c-e1aeff67020e; PHPSESSID=db8a1adeb7a3bace8946bec8bcefa97c; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0; _ohmybid_cmf=2; _sltm=6061bae9d3ecdabb90c437f9b908d7a0~0; _sltb=0; domain_sid=kqnq02X0-pv6Oaaf-2H5P%3A1777913292231"
}
 
 local url = 'https://fanserial.me/43771-alien.html'
 
 local x = http.getz(url, headers) 
 
 local key = string.match(x,'<iframe.-src="/.-/.-key=(.-)"')
 
 local x = http.getz('https://fanserial.me/film.php?kp=' .. args.id3 ..'&key=' .. key) 
 
 
 if x then
 
 for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(1080p)' .. tolazy(title), mrl = url})

end
 
   for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '720.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(title), mrl = url})

end
 
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '480.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(title), mrl = url})

end
 
 
 for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '360.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(title), mrl = url})

end
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '240.mp4:hls:manifest')


   
   
 t['view'] = 'simple'

table.insert(t, {title = '(240p)' .. tolazy(title), mrl = url})

end
 
 end
 
 
 
 
 
 


 
 local x = conn:load('https://lomont.site/gt/' .. args.id3 .. '?&alloff=true')


if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 


local data = string.match(x,'<div id="inputData"(.-)<div id="vPreloader"') 

if data then

for video, season, episode, title, voice in string.gmatch(data,'"video_id":(.-),"season":(.-),"episode":(.-),"voice_name":"(.-)","voice_id":(.-),') do


--table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = url})

t['view'] = 'simple'


table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = '#stream/q=fanserials&id3=' .. args.id3 .. '&id=' .. video .. '&id1=' .. season .. '&id2=' .. episode .. '&id4=' .. voice .. '&id5=' .. title})


end
end
end

 elseif args.q == 'fanserials' then

local x = conn:load('https://lomont.site/gt/' .. args.id3 .. '?video_id=' .. args.id .. '&season=' .. args.id1 .. '&episode=' .. args.id2 .. '&voice=' .. args.id4 .. '&alloff=true')
  --   print(x)


if x then

local url = string.match(x,'"hls":"(http.-)"')

--for url in string.gmatch(x, '"hls":"(http.-)"') do

url = string.gsub(url, '\\', '')
  
 
      t['view'] = 'simple'


table.insert(t, {title = 'Сезон ' .. args.id1 .. ' серия ' .. args.id2 .. ' ' .. args.id5, mrl = url})

end



  elseif args.q == 'fancdn' then
 
 --https://lam.maxvol.pro/lite/fancdn?kinopoisk_id=386
 
 local x = conn:load('http://z01.online/lite/fancdn?kinopoisk_id=' .. args.id3)

-- table.insert(t, {title = 'http://178.20.46.40:12600/lite/fancdn?kinopoisk_id=' .. args.id3, mrl = 'http://178.20.46.40:12600/lite/fancdn?kinopoisk_id=' .. args.id3})

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
  
        --  url = string.gsub(url, '^(.-)', 'https://lam.maxvol.pro') 
     
url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
 
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls.m3u8', '480.mp4:hls:manifest.m3u8')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end







elseif args.q == 'videx' then

--http://31.129.234.181/lite/vibix/?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0

local x = conn:load('http://31.129.234.181/lite/vibix/?kinopoisk_id=' .. args.id3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
 

 if x then
 
 x = string.gsub(x, '\\u0026', '&')
-- x = string.gsub(x, '0&referer', '1&referer')
 
-- x = string.gsub(x, '&account', '?kp=' .. args.id3 .. '&domain=kinobaza.vercel.app&parent_domain=kinobaza.vercel.app&account')
 
 
 for total, url, title in string.gmatch(x, 'div class="videos__item videos__movie.-"(1080p)".-(http.-)".-class="videos__item%-title">(.-)<') do
  
    

 
  t['view'] = 'simple'

--table.insert(t, {title = url, mrl = url .. '?sync=true' .. url2})


 table.insert(t, {title = total .. ' ' .. title, mrl = url})


end
 for total, url, title in string.gmatch(x, 'div class="videos__item videos__movie.-"(720p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  
  --  url = string.gsub(url, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end

 for total, url, title in string.gmatch(x, 'div class="videos__item videos__movie.-"(480p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  
 --   url = string.gsub(url, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end
end
  
local x = conn:load('http://31.129.234.181/lite/vibix/?kinopoisk_id=' .. args.id3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
 


 if x then

x = string.gsub(x, '\\u0026', '&')

for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do


 local x = conn:load(url .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
 

 
 
 x = string.gsub(x, '\\u0026', '&')
 

 
  for total, url1, title1 in string.gmatch(x, '"(1080p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title .. ' ' .. title1, mrl = url1})

  end
  

  for total, url1, title1 in string.gmatch(x, '"(720p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  

--  url1 = string.gsub(url1, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title .. ' ' .. title1, mrl = url1})

  end 
  


  for total, url1, title1 in string.gmatch(x, '"(480p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  

--  url1 = string.gsub(url1, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title .. ' ' .. title1, mrl = url1})

  end 
  
  end
  end




elseif args.q == 'vibix' then

 local x = conn:load('https://hpmd.stull.xyz/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 

 if x then
 
 x = string.gsub(x, '\\u0026', '&')
-- x = string.gsub(x, '0&referer', '1&referer')
 
-- x = string.gsub(x, '&account', '?kp=' .. args.id3 .. '&domain=kinobaza.vercel.app&parent_domain=kinobaza.vercel.app&account')
 
 
 for total, url, title in string.gmatch(x, 'div class="videos__item videos__movie.-"(1080p)".-(http.-)".-class="videos__item%-title">(.-)<') do
  
    

 
  t['view'] = 'simple'

--table.insert(t, {title = url, mrl = url .. '?sync=true' .. url2})


 table.insert(t, {title = total .. ' ' .. title, mrl = url})


end
 for total, url, title in string.gmatch(x, 'div class="videos__item videos__movie.-"(720p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  
  --  url = string.gsub(url, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end

 for total, url, title in string.gmatch(x, 'div class="videos__item videos__movie.-"(480p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  
 --   url = string.gsub(url, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end
end
  
local x = conn:load('https://hpmd.stull.xyz/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
 
 -- if x then
  
    for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do


 local x = conn:load(url .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
 x = string.gsub(x, '\\u0026', '&')
 
 --x = string.gsub(x, '0&referer', '1&referer')
 
-- x = string.gsub(x, '&account', '?kp=' .. args.id3 .. '&domain=kinobaza.vercel.app&parent_domain=kinobaza.vercel.app&account')
 
  for total, url1, title1 in string.gmatch(x, '"(1080p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  

  
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title .. ' ' .. title1, mrl = url1})

  end
  
 local x = conn:load(url .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
 x = string.gsub(x, '\\u0026', '&')
 
 --x = string.gsub(x, '0&referer', '1&referer')
 
--x = string.gsub(x, '&account', '?kp=' .. args.id3 .. '&domain=kinobaza.vercel.app&parent_domain=kinobaza.vercel.app&account')
 
  for total, url1, title1 in string.gmatch(x, '"(720p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  

--  url1 = string.gsub(url1, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title .. ' ' .. title1, mrl = url1})

  end 
  
  local x = conn:load(url .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
x = string.gsub(x, '\\u0026', '&')
 
-- x = string.gsub(x, '0&referer', '1&referer')
  
--x = string.gsub(x, '&account', '?kp=' .. args.id3 .. '&domain=kinobaza.vercel.app&parent_domain=kinobaza.vercel.app&account')

  for total, url1, title1 in string.gmatch(x, '"(480p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  

--  url1 = string.gsub(url1, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title .. ' ' .. title1, mrl = url1})

  end 
  
  
  end
  


 elseif args.q == 'vibix2' then
 
 local x = conn:load('http://api.atodo.fun/api/search?query=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
  for id, type in string.gmatch(x, '"results".-"id":(.-),.-"media_type":"(.-)"') do
 
 

 local x = conn:load('http://api.atodo.fun/api/source/xinu?id=' .. id .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=' .. type)
 
  
 
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
	
 
 
  local slist = string.match(x, '"type":"movie"(.-)]')
 
 if slist then
 
 for title, total, url in string.gmatch(slist,'"translation_name":"(.-)".-"(1080)":"(http.-)"') do
 
  
  url = string.gsub(url, '\\', '')
  
  t['view'] = 'simple'

 table.insert(t, {title = '(' .. total .. 'p)' .. ' ' .. title, mrl = url})

end

for title, total, url in string.gmatch(slist,'"translation_name":"(.-)".-"(720)":"(http.-)"') do
 
  
  url = string.gsub(url, '\\', '')
  
  t['view'] = 'simple'

 table.insert(t, {title = '(' .. total .. 'p)' .. ' ' .. title, mrl = url})

end

for title, total, url in string.gmatch(slist,'"translation_name":"(.-)".-"(480)":"(http.-)"') do
 
  
  url = string.gsub(url, '\\', '')
  
  t['view'] = 'simple'

 table.insert(t, {title = '(' .. total .. 'p)' .. ' ' .. title, mrl = url})

end
end

 

x = string.gsub(x, '}}}}}]}]}]}', '"season_id"translation_id""vibix"')


x = string.gsub(x, '}}}}}]}}}]}', '"season_id""translation_id""vibix"')

local slist = string.match(x, '"type":"show"(.-)"vibix"')

if slist then

slist = string.gsub(slist, '\\', '')

local slist1 = string.match(slist, '"translation_id"(.-)"translation_id"')

local translation = string.match(slist1,'"translation_name":"(.-)"') 




--for seasons in string.match(slist1, '"season_name":"(.-)"') do

  slist1 = string.gsub(slist1, 'qualities', translation)


--url = url_for(slist1, {
  
    for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(480)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end

for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(720)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(1080)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
 
 
 
 local slist1 = string.match(slist, '"translation_id".-"translation_id".-"translation_id"(.-)"translation_id"')

local translation = string.match(slist1,'"translation_name":"(.-)"') 




--for seasons in string.match(slist1, '"season_name":"(.-)"') do

  slist1 = string.gsub(slist1, 'qualities', translation)


--url = url_for(slist1, {
  
    for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(480)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end

for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(720)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(1080)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
 local slist1 = string.match(slist, '"translation_id".-"translation_id"(.-)"translation_id"')

local translation = string.match(slist1,'"translation_name":"(.-)"') 




--for seasons in string.match(slist1, '"season_name":"(.-)"') do

  slist1 = string.gsub(slist1, 'qualities', translation)


--url = url_for(slist1, {
  
    for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(480)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end

for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(720)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(1080)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
 
    end  
  end

elseif args.q == 'vibix1' then
  
  
  
--  https://reyohoho-old.onrender.com/#386
  
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  
 -- for url in string.gmatch(x, '(<option player.-</option>)') do
  
  
 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed/.-)"') do
 
 
 
 --https://672431256.videoframe2.com/api/v1/embed-serials/5523?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com/embed-serials/5523
  
--https://672431256.videoframe2.com/api/v1/embed/215500?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com/embed/215500 
 
 local x = conn:load('https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url)
 
 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slis = string.gsub(slist, ',', '"')
 slist = string.gsub(slist, ';', '"')
 
for total, title, url in string.gmatch(slist, '%[(480p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
	
t['view'] = 'simple'
 
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 
 
for total, title, url in string.gmatch(slist, '%[(720p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"%{.-}http.-"({.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 


for total, title, url in string.gmatch(slist, '%[(1080p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end

end
    end
  
  
  
  
  
  
  
   
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  

 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed%-serials.-)"') do
 

 local x = conn:load('https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url)
  
 -- table.insert(t, {title = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url, mrl = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url})
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slist = string.gsub(slist, ',', '"')
-- slist = string.gsub(slist, ';', '"')
slist = string.gsub(slist, ']{', '"name":')
slist = string.gsub(slist, ';{', '"name1":')

-- for total1 in string.gmatch(slist, '"title":"(Сезон.-)"') do
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
    end
  end





--http://178.20.46.40:12600

--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979

--https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=386

elseif args.q == 'veoveo' then
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
   
--table.insert(t, {title = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1), mrl = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1)})
      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'veoveo :' .. tolazy(total), mrl = url2})

       
    end
     
--  local x = conn:load('http://178.20.46.40:12600/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
 
 

 
 
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do
     
   --  url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600') 
     
     
     local x = conn:load(url2)

--table.insert(t, {title = url2, mrl = url2})

for  url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total4), mrl = url3})

      end 
      end


elseif args.q == 'kinopub' then
  
  
 
local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=movie' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

for url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[Воспроизвести]].-<playlist_url><!%[CDATA%[(http.-)]]') do


      local x = conn:load(url2 .. '&box_mac=acace24b8434')

 for title, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title), mrl = url3})
   
   end
   end
 end




 
 local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=serial' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

 
 
   
   for title, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   local x = conn:load(url2 .. '&box_mac=acace24b8434')
   
  for title1, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url><!%[CDATA%[(http.-)]]') do
  
  local x = conn:load(url3 .. '&box_mac=acace24b8434')
  
   for title2, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title) .. ' ' .. tolazy(title1) .. ' (' .. tolazy(title2) .. ')', mrl = url4})
   end
   end
   end
   
end
   



elseif args.q == 'kinopubtv' then
 
--https://beta.l-vid.online/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn


local url = 'https://lampa.li/lite/kinopub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
  
  x = string.gsub(x, '\\u0026', '&')


  for  total in string.gmatch(x, '<div class="videos__item videos__movie.-class="videos__item%-title">(.-)</div>') do
  
  local slist = string.match(x, 'quality.-{(.-)}')
      
      
   
   for  total1, url2 in string.gmatch(slist, '(%d+p).-http.-(/proxy.-m3u8)') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
   url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     


      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total), mrl = url2})

       
    end
    end
 
 
 for  url2, total2 in string.gmatch(x, 'class=.-videos__item videos__season.-method.-url.-(http.-)&#.-videos__season%-title.->(.-сезон)<') do
 
 
 url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 

     
     local x = conn:load(url2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 x = string.gsub(x, '\\u0026', '&')
     x = string.gsub(x, '\\u002B', '+')
 
 
    for id, id1, id2, id3, total3 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-postid=(.-)&title=(.-)&.-&s=(.-)&t=(.-)&.->(.-)</div>') do


   t['view'] = 'simple'

    

table.insert(t, {title = tolazy(total2) .. ' ' .. tolazy(total3), mrl = '#stream/q=kinopubs&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})


      end 
      end

    
    elseif args.q == 'kinopubs' then
   
   local x = conn:load('https://lampa.li/lite/kinopub?rjson=False&postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&s=' .. args.id2 .. '&t=' .. args.id3 .. '&codec=aac' .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   


    for  total in string.gmatch(x, '<div class="videos__item videos.-class="videos__item%-title">(.-)</div>') do
  
  local x = string.match(x, 'quality.-{(.-)}')
      
      
   
   for  total1, url2 in string.gmatch(x, '(%d+p).-http.-(/proxy.-m3u8)') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
      url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     


      t['view'] = 'simple'


   table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

       
    end
    end




--https://lamp-movie.ru/lite/kinopub?title=чужой-1979




elseif args.q == 'filmix2' then

    

local x = conn:load('https://evkh.lol/lite/filmixtv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
  url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
  url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
 
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
    
    --     for  total3, url4, total2 in string.gmatch(x, '"(.-p)":"http.-mp4.-(http.-mp4).-class="videos__item%-title">(.-)<') do
-- total3 = string.gsub(total3, ',"', '')
 --   t['view'] = 'simple'
--    table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
    
--end
-- end


    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
 
    
    if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
   
  if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
 
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
 
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
 
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
 
 
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
   
end
end
   
   elseif args.q == 'vkmovie' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lam.maxvol.pro/lite/vkmovie?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
     

     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro')
      url4 = string.gsub(url4, '\\u002B', '+')
       t['view'] = 'simple'

   table.insert(t, {title = '(' .. total3 .. ') ' .. tolazy(total2), mrl = url4})
    end
     end  


elseif args.q == 'remux' then


--https://lam.akter-black.com/lite/remux?kinopoisk_id=386&title=чужой&year=1979

		local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



      for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')
      
      

    --   url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
   
   
   
for  url3, total1 in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url3 = string.gsub(url3, '\\u0026', '&')
      url3 = string.gsub(url3, '\\u002B', '+')
      
 
 
 local x = conn:load(url3)
 
       for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url4 = string.gsub(url4, '\\u0026', '&')
      url4 = string.gsub(url4, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url4})

     end  
    end
end

local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
   
     for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
 
 
 local x = conn:load(url)
 
       for url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total), mrl = url2})

     end  
    end




      
         
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end