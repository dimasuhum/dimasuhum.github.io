-- fast-film plugin


require('support')
--require('video')
--require('parser')
require('client')
require('fxml')

local video = require('video')
local parser = require('parser')

local json = require('json')

local fxml = onCreate







--CDATA[http://stvplay.mooo.com:81/torrents/tmdb/tmdb.php?link=https://bitru.org/download.php?id=639863&path=&file=Особо

--https://bitru.org/browse.php?s=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9(1979)

--http://stvplay.mooo.com:81/torrents/tmdb/tmdb.php?find=%D0%9E%D1%81%D0%BE%D0%B1%D0%BE%20%D0%BE%D0%BF%D0%B0%D1%81%D0%BD%D1%8B%D0%B9%20%D0%BF%D0%B0%D1%81%D1%81%D0%B0%D0%B6%D0%B8%D1%80

--https://findmagnet.org/?q=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9

--https://www.magicsearch.net/search/%D0%A7%D1%83%D0%B6%D0%BE%D0%B9%201979/

--https://www.magicsearch.net/api/json_info?hashes=11487944


--local REPO1 = 'http://xplay.bz/'

--local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


--http://fast-torrent.club/toggle_info/ti_386060

--http://fast-torrent.club/download/torrent/428804/%D0%9E%D0%BF%D0%BF%D0%B5%D0%BD%D0%B3%D0%B5%D0%B9%D0%BC%D0%B5%D1%80%20-%20Oppenheimer%20(2023)%20HDRip%20%7C%20LineFilm%20%7C%20IMAX.torrent


--local HOME = 'http://fast-fiml.ru'
local HOME = 'http://fast-torrent.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




local conn1 = client.new()
conn1['encoding'] = 'windows-1251'
conn1['root'] = HOME_SLASH

--HOME = 'http://www.fast-film.ru'
--HOME = 'http://www.fast-fiml.ru'


--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

-- #self/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/
-- #stream/url=http://xplay.bz/
-- #stream/url=http://staticdata.appinfo.su/staticfiles/fimg/open.png
-- #stream/url=http://xplay.bz/list
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka%2Flist%3Fcat%3Dfilms
-- #stream/url=http://imboom.ru/?ma=playlist
-- #stream/url=http://imboom.ru/?ma=imboomiptv
-- #stream/url=http://xplay.bz/view?id=74114&cat=movie&kinopoisk_id=806964
-- #self/url=http://xplay.bz/list



	
	-- #stream/page=2
	-- #stream/page=3
	-- #stream/page=4
	-- #stream/page=5
	-- #stream/page=6
	-- #stream/page=7
	-- #stream/page=8
	-- #stream/page=9
	-- #stream/page=10
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/new/all/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. tostring(page) .. '.html'
		end
	--	local x = http.getz(url)
        local x = conn:load(url)

      -- for title, url, image in string.gmatch(x, '<div class=film%-wrap".-alt="(.-)".-<a href="(.-)".-style="background:.-(http.-jpg)') do
       
       
  	for url, image, title in string.gmatch(x, '<div class=.-film%-wrap.-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		--	table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
        
		
          for url, title in string.gmatch(x, '<div class=.-float_right collection%-profile.-nav%-icon generic_favorit_controll email%-off.-collection%-item%-head.-<a href=.-(/favorite/public.-)\'.-<big>(.-)<') do
         t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
  
  
  
    --  for title, url, image   in string.gmatch(x, '<div class="film%-wrap".-alt="(.-)".-<a href="(.-)".-itemprop="image" content="(.-)"') do
        
      -- url = string.gsub(url, '^(.-)', HOME)

	--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
	--	end
  
  
  
  

--<div class=item_main_box2.-class="quality_type">(.-)<.-<a href=.-(/film/.-html).-background:.-(http.-jpg)

        for url, image, title  in string.gmatch(x, '<div class=\'item_main_box2\'.-<a href=.-(/film/.-html).-background:.-(http.-jpg).-class=\'use_tooltip item_title\'title=\'(.-)\'') do
        
       url = string.gsub(url, '^(.-)', HOME)
    --   title = string.gsub(title, ''', '')
    --    t['view'] = 'simple'
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
	--	end
	
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       table.insert(t, {title = 'КОЛЛЕКЦИИ', mrl = '#stream/genre=' .. '/favorite/public/'})
    	table.insert(t, {title = 'Новые коллекции', mrl = '#stream/genre=' .. '/favorite/public/?order=1'})

     table.insert(t, {title = 'Самые большие коллекции', mrl = '#stream/genre=' .. '/favorite/public/?order=2'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=6'})

	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=3'})
	
	table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/favorite/public/?order=4'})
	
--http://www.fast-fiml.ru/last-tv-torrent/
     	local x = conn:load(HOME .. '/new-torrent/')
   
        
		local x = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-/).->(.-)</a>') do
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
    	local x = conn:load(HOME .. '/last-tv-torrent/')
        
		local x = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
	
   --     for genre, title in string.gmatch(x, '<a href="(.-tv/).->(.-)</a>') do
	
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-tv/).->(.-)</a>') do
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		local x = conn:load(HOME .. '/last-multfilm-torrent/')
        
		local x = string.match(x, '<div id=.-leftmenu.->(.-)<br/>')
		
		for genre, title in string.gmatch(x, '<li.-<a href=.-(/.-/).->(.-)</a>') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
--http://www.fast-fiml.ru/new-torrent/
--http://www.fast-fiml.ru/last-tv-torrent/
--http://www.fast-fiml.ru/last-multfilm-torrent/




--<a href="/all/tag/be-continued/  <li class='more'><a href="/tags/   

        local x = conn:load(HOME .. '/new/all/')
        
	--	local x = string.match(x, '<em class="nav%-icon nav%-tag_blue.->(.-)<.-Еще Теги')
		
		for genre, title in string.gmatch(x, '<a href=.-(/all/tag/.-/).->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end

          local x = conn:load(HOME .. '/tags/all/')
        
	--	local x = string.match(x, '<div class="ui%-widget ui%-widget%-content".->(.-)</ul>')
		
		for genre, image, title in string.gmatch(x, '<div class="item_tag".-<a href=.-(/all/tag/.-/).-background%-image:.-(http.-jpg).-</div>(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end

--http://www.fast-torrent.ru/search/{searchTerms}/1.html


        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = 'http://www.fast-torrent.ru/search/' .. urlencode(args.keyword) .. '/' .. tostring(page) .. '.html'

		
		local x = conn:load(url)
		
        for url, image, title, total in string.gmatch(x, '<div class="film%-wrap".-<a href="(.-)".-itemprop="image".-content="(.-)".-itemprop="name">(.-)</span>(.-)<') do
          url = string.gsub(url, '^(.-)', HOME)
       --   table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
			table.insert(t, {title = title .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '/' ..  tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
		
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?id=106291&kinopoisk_id=1355296
	
	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?kinopoisk_id=1355296&title=&original_title=&s=1
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<meta itemprop="description" content="(.-)"')
        t['poster'] = args.p
	--	t['poster'] = parse_match(x,'var test_image.-(http.-jpg)')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Жанр</strong>:.-)</p>' ,'(Режиссер</strong>:.-)</p>' ,'(В ролях</strong>:.-)</p>' , 
		})

--http://stvplay.mooo.com:81/torrents/rutor.php?search=%D0%B1%D1%83%D0%BC%D0%B0%D0%B6%D0%BD%D1%8B%D0%B9%20%D0%B4%D0%BE%D0%BC

--http://stvplay.mooo.com:81/torrents/rutor.php?fid=1019382

      
--https://torrs.ru/search?query=чужой (1979)





    for title, total in string.gmatch(x, '<h1.-span.->(.-)<.-%((.-)%)') do

    title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
	
   
   url = string.gsub(title, '^(.-)', 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=') .. '&year=' .. total .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
  
     local x = conn:load(url)
     
      
    for total1, total2 in string.gmatch(x, 'docs.-{"id":(.-),.-name":"(.-)"') do
    

  
     url1 = string.gsub(total1, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
      local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end
    end
    end
   
   
   
   
   
       for title  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
   
   

     url1 = string.gsub(title, '^(.-)', 'http://hidxlglk.deploy.cx/lite/lumex?kinopoisk_id=') .. '&uid=m7alois3'
    
    table.insert(t, {title = 'Lumex', mrl = '#stream/q=content&id=' .. url1})
 
    end
    
  --  local x = conn1:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/lite.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
       t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end
     

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn1:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn1:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://hidxlglk.deploy.cx')
    
  --    url4 = string.gsub(url4, 'rjson=False&', '')
    
    
       t['view'] = 'simple'
   
   
    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end

   
   
   
        for url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
   
        url = string.gsub(url, '^(.-)', 'https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=')
    --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
       local x = conn:load(url)
   

   
       for title, url  in string.gmatch(x, 'url.-http.-kinovibe.co.-%-(.-).html.-embed.-(http.-)"') do
   
       url = string.gsub(url, '\\', '')
   
       title = string.gsub(title, 'series', '')
         
    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})

       end
       end
   

        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
         
        t['view'] = 'simple'
         
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
     
         t['view'] = 'simple'
     
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
         t['view'] = 'simple'
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end



		
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-id:"playerjshd".-file:"(.-txt)"') do
         -- print(url)
      --    t['view'] = 'grid'
       --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' ..  url})
    --table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})
--		end

       local x = conn:load(url)



           for title, url in string.gmatch(x, '"comment":"(.-)".-file.-(https://s.-mp4)"') do
			print(url)  

          url = string.gsub(url, '_[480,720]', '')
          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title), mrl = url})
        end



		for title, url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do

          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title) .. ' (480p)'  , mrl = url .. url1 .. '_480.mp4'})
   

        end
	
	
          for title,  url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do
		--	print(url)  

      --    url = string.gsub(url, '(.-)', url) .. '_720.mp4'
          t['view'] = 'grid'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title) .. ' (720p)', mrl = url .. url1 .. '_720.mp4'})
   
   --     table.insert(t, {title = tolazy(title) .. (total), mrl = url})
        end
	
      end
   
       
       
--http://fxmlparsers.in.net/http://www.vk.com/?id=search&search=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%201979

        
   


   
   
   
     for url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
      


      url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=') 
      table.insert(t, {title = 'cdnvideohub плеер', mrl = '#stream/q=content&id=' .. url})

       end
  
         
         for title  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
  
       url = string.gsub(title, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=23&kid=')
 
       if url == 'https://player.cdnvideohub.com/playerjs?partner=23&kid=' .. title then
       
       
      --  table.insert(t, {title = 'cdnvideohub плеер', mrl = '#stream/q=content&id=' .. url})
 
   --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})

     --  end
        
        
      local x = conn:load(url)
        
        for title, url in string.gmatch(x, '\'title\':.-\'(.-)\'.-\'file.-(http.-)\'') do
     
        url = string.gsub(url, '\\u0026', '&')
     
      url = string.gsub(url, '_IPHONE', '')
     url = string.gsub(url, '\\', '')
     
            t['view'] = 'simple'
        table.insert(t, {title = title, mrl = url})
      end
       end
   
  end













   

    
    
        
         
        for title  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   


         url = string.gsub(title, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=')

      if url == 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. title then 

    

      local x =  conn:load(url)
       
    
      
       
       for total, url, title in string.gmatch(x, '"method":"play","url".-(1080p).-(http.-)".-class="videos__item%-title">(.-)<') do
       

            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
			
			
      for total, url, title in string.gmatch(x, '"method":"play","url".-(720p).-(http.-)".-class="videos__item%-title">(.-)<') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
   
      for total, url, title in string.gmatch(x, '"method":"play","url".-(480p).-(http.-)".-class="videos__item%-title">(.-)<') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for total, url, title in string.gmatch(x, '"method":"play","url".-(360p).-(http.-)".-class="videos__item%-title">(.-)<') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end

        end
        
          for url2  in string.gmatch(x, 'current_page".-"data":%[{"id.-"kinopoisk_id":(.-),') do
       

        url = string.gsub(url2, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=22&kid=')
       
        local x = conn:load(url)


       for title, url3 in string.gmatch(x, '\'title\': \'(Season) (.-)\',') do



  
       url = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=') .. '&title=&original_title=&s=' .. url3 
  
  

      local x = conn:load(url)
     
     

  
        for url5, total5  in string.gmatch(x, 'method":"link".-(&t=.-)".->(.-)</div>') do


       local x = conn:load('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3 .. url5)



       for url4, total2  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do

        total2 = string.gsub(total2, '\\u0441\\u0435\\u0440\\u0438\\u044F', 'серия')

       t['view'] = 'simple'
   
   

      table.insert(t, {title = title .. ' ' .. url3 .. (total2) .. (total5), mrl = url4})
    

	end
    end
    end
    end
  

 
 
 




        for  url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
    
        print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Zagonka плеер', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		
		if url then
			for title, total,  url1, url2 in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p)].-(//.-movies)(/.-})') do
           t['view'] = 'simple'
       
         url1 = string.gsub(url1, '^(.-)', 'http:')
         url2 = string.gsub(url2, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url1 .. url2})
			end
		end	
			
        if url then
			for title, total, url1, url2 in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p)].-(//.-movies)(/.-})') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
           url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url1 .. url2})
			end
		end	
        if url then
			for title, total, url1, url2 in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD)].-(//.-movies)(/.-})') do
            t['view'] = 'simple'
         
         url1 = string.gsub(url1, '^(.-)', 'http:')
         url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url1 .. url2})
			end
		end	
   
   

        local slist = string.match(url,'Coldfilm.-Coldfilm(.-)}]}') 


      if slist then

			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Coldfilm' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
	
		end	
    end
  
  
    
  
     local slist = string.match(url,'Ultradox.-Ultradox(.-)}]}')

      if slist then


			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Ultradox' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
			end
		end
			
  
   
  
  
       local slist = string.match(url,'Lostfilm.-Lostfilm(.-)}]}')


       if slist then

			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Lostfilm' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
		end
		end	
  
  
      local slist = string.match(url,'Rezka.-Rezka(.-)}]}')

       if slist then


			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Rezka' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
				
		end
		end	
  
     
     
     
     local slist = string.match(url,'Rudub.-Rudub(.-)}]}')
     
     
         if slist then

			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Rudub' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
		
		end	
     end
       
      
      local slist = string.match(url,'"title"(.-)}]}')
     
     
         if slist then
     for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_tr_7_e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
		
		end	
        end
       

end



     
     
     

  
     for title, total in string.gmatch(x, '<h1><span.->(.-)</span>.-%((.-)%).-<br') do      
        
       title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      


     url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    

    
     
    table.insert(t, {title = 'Источники', mrl = '#stream/q=content&id=' .. url, image = image})
         end

       


     







for title, title1 in string.gmatch(x, '%[{"size".-"name":"(.-)".-"relased":(.-),') do

     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')

    url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '+'  .. '(' .. title1 .. ')'
  
         local x = conn1:load(url)
    
     
       for title3  in string.gmatch(x, '"fxml".-playlist_url.-?id=info&cid=(.-)"') do

         url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 

      
         local x = conn:load(url1)

   
   
   
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :' .. tolazy(total2), mrl = url2})

      end 
 
     
  

      
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. total3, mrl = url4})

       
    end

end
end





      url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/fancdn?kinopoisk_id=')
      --.. '&uid=m7alois3'
    
    
      local x = conn:load(url1)
   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url1 = string.gsub(url1, '\\u0026', '&')
  --  url1 = string.gsub(url1, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'


 --   table.insert(t, {title = url2, mrl = url2})

   table.insert(t, {title = 'fancdn :' .. tolazy(total), mrl = url2})

       
    end

    
     
     
     
     

      url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/fancdn?kinopoisk_id=') .. '&uid=m7alois3'
    
     local x = conn:load(url1)
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = 'fancdn :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end








    





   --    title1 = string.gsub(title1, '%%20', '-')

    url1 = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&search=') .. '-' .. title1
     
     url1 = string.gsub(url1, '%%20', '-')
     
     
     --.. '&box_mac=acace24b8434'
			
	
		   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')


     for total1 in string.gmatch(x, 'fxml.-<channel>.-http.-&goto=(.-)]]') do




    total1=base64_decode(total1)
     
    total1 = string.gsub(total1, 'item/', '')
     
  

  
     url2 = string.gsub(total1, '^(.-)', 'https://api.manhan.one/rc/filmix?postid=')
  
  
        local x = conn:load(url2)
      
     for  url3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

   table.insert(t, {title = 'filmix' .. ':'.. tolazy(total2), mrl = url3})

     end  


      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for url5, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'filmix :' .. total .. ' '  .. tolazy(total3) .. total2, mrl = url5})

       
    end

end
end
end








    url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title='alloha' .. ':' .. tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
      t['view'] = 'simple'
				table.insert(t,{title= 'alloha :' .. tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end






     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/zetflix?kinopoisk_id=') 

    
       local x = conn:load(url1)
   
   
   for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total), mrl = url2})

       
    end
    
    
    
        for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end






  url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=') .. '&uid=m7alois3'
    
    
      local x = conn:load(url1)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=') 

    local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total1) .. total2, mrl = url3})

       
    end

end


url1 = string.gsub(title, '^(.-)', 'https://lam.akter-black.com/lite/rezka?kinopoisk_id=' .. title3 .. '&title=') .. '+' .. '&clarification=0&year=' .. title1

     local x = conn:load(url1)
 
  
      for url2, total  in string.gmatch(x, '<div class="videos__line".-class="videos__item videos.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
     
       local x = conn:load(url2)
  
  
  
       for  url3, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. tolazy(total1), mrl = url3})

     end  
  
         local x = conn:load(url2)

     
     for url3, total2  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
     
     url3 = string.gsub(url3, '\\u0026', '&')

     url3 = string.gsub(url3, '\\u002B', '+')

  
     local x = conn:load(url2)

   for url4, total3  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')

     url4 = string.gsub(url4, '\\u002B', '+')
     

      local x = conn:load(url3)

      for url5, total4  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')

     url5 = string.gsub(url5, '\\u002B', '+')
     
    
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. total2 .. ' '  .. tolazy(total3) .. ' ' .. total4, mrl = url5})

       
    end
end
end
end







url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/mirage?kinopoisk_id=') .. '&uid=m7alois3'

      
         local x = conn:load(url1)

   
   
   
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'mirage :' .. tolazy(total2), mrl = url2})

      end 
 
     
  

      
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'mirage :'  .. total2 .. ' '  .. tolazy(total) .. total3, mrl = url4})

       
    end

end
end


        url1 = string.gsub(title, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=') .. '+' .. title1 .. '+'
	
    	 local x = conn:load(url1)
      
      	for url2 in string.gmatch(x, '<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn:load(url2)
    
    
    for total, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<logo.-<!%[CDATA%[.-</logo.-<description><!%[CDATA%[.-</description>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	
	     local x = conn:load(url3)
	     
	     for total1, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. total1 .. ' ' .. total, mrl = url4, image = image})
         end
	     end
    end
    	




end
end
    
     





       
       
       
       
       
       
     

     for title, total in string.gmatch(x, '<h1><span.->(.-)</span>.-%((.-)%).-<br') do      
        
    --   title = urlencode(title)
     
     title = string.gsub(title, ' ', '-')
   


      url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&search=') .. '-' .. total
      --.. '&box_mac=acace24b8434'
			
			
			
			
      local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')

     
     for total1 in string.gmatch(x, 'fxml.-<channel>.-http.-&goto=(.-)]]') do

     total1=base64_decode(total1)
     
     total1 = string.gsub(total1, 'item/', '')

   
  
   

       url1 = string.gsub(total1, '^(.-)', 'http://filmixapp.cyou/api/v2/post/') .. '?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380'
         
         
        	table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url1, image = image})
		
			

		end
   end
   

       
        
     
     
     
     
      for title in string.gmatch(x, '"id":(.-),') do

    --     print(url)
		 
         title = string.gsub(title, '^(.-)', 'item/')
         
         title=base64_encode(title)
 

       url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=')
       
      
       local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')


     
     
     for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = total .. (total1), mrl = url2})
    
        end
        end
        end
  
    
    
      



        for title in string.gmatch(x, '"id":(.-),') do

    --     print(url)
		 
         title = string.gsub(title, '^(.-)', 'item/')
         
         title=base64_encode(title)
 

       url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=')
       
      
       local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')





      for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
       total = string.gsub(total, '<!%[CDATA%[', '')
       total = string.gsub(total, ']]>', '')
       
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

    
     for total1, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-сезон)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
       total1 = string.gsub(total1, '<!%[CDATA%[', '')
       total1 = string.gsub(total1, ']]>', '')
   
        local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
     
     for total2, total3, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      total2 = string.gsub(total2, '<!%[CDATA%[', '')
       total2 = string.gsub(total2, ']]>', '')
      
      local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
 
     
     
     for total4, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do
    
       total4 = string.gsub(total4, '<!%[CDATA%[', '')
       total4 = string.gsub(total4, ']]>', '')
    
    
    
       t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total) .. tolazy(total1) .. tolazy(total2) .. tolazy(total3) .. (total4), mrl = url4})
    
        end
        end
        end
        end
        end
     
     
     
     
     
     for title, total in string.gmatch(x, '<h1><span.->(.-)</span>.-%((.-)%).-<br') do        
        
       title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      


     url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
     
     local x = conn:load(url)
     
     for total in string.gmatch(x,'%[{"size.-trackerName.-kinozal.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        

       url1 = string.gsub(total, '^(.-)','http://torr.unknot.ru:8090/stream/?link=') .. '&m3u'
      

        local x = conn:load(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     --    t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
       --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
       -- t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	


     local x = conn:load(url)
     
      for total in string.gmatch(x,'%[{"size.-trackerName.-nnmclub.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        
      url1 = string.gsub(total, '^(.-)','http://torr.unknot.ru:8090/stream/?link=') .. '&m3u'
      

        local x = conn:load(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     
   --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
      --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
      --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	
    end

     
     
     
      
         
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end