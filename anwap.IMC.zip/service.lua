-- anwap plugin

require('support')
--require('video')
--require('parser')
require('client')

local video = require('video')
local parser = require('parser')





--local HOME = 'https://tv.anwap.today'
local HOME = 'https://m.anwap.media'
local HOME_SLASH = HOME .. '/'

local conn = client.new()

--conn['encoding'] = 'utf-8'
conn['encoding'] = 'UTF-8'
local conn1 = client.new()
conn1['encoding'] = 'utf-8'

local conn2 = client.new()
conn2['encoding'] = 'windows-1251'


conn['root'] = HOME_SLASH

     
   --  local url = {'https://kinobox.tv/api/players?kinopoisk='}



--HOME = 'https://m.anwap.bio'
--HOME = 'https://m.anwap.tube'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from anwap plugin')
	return 1
end

function onUnLoad()
	print('Bye from anwap plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
    table.insert(t['menu'], {title = 'Поиск сериалов', mrl = '#folder/q=/serials/search', image = '#self/search.png'})
	
	
	-- #stream/page=2

	-- #stream/genre=/films/r3-
	-- #stream/genre=/films/p-
	-- #stream/genre=/serial/page/
	-- #stream/genre=/films/top
	-- #stream/genre=/serials/top
	-- #stream/genre=/films/collection/11
	
	-- #stream/genre=/films/collection/67
	
	
	if not args.q then
		local page = tonumber(args.page or 1)
		

		local genre = args.genre or '/'
        local url = HOME .. genre .. 'films/p-' .. tostring(page)

    local x = conn:load(url)
    
    
for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
         url = string.gsub(url, '^(.-)', HOME)
         
         
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
     
     
     
     
     
    
       
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       
  
  
--https://tv.anwap.today/films/top
  
--  local x = conn:load(HOME .. '/films/top')
  
   --   x = string.match(x, '<ul class="perehod">(.-)</ul>')
	--	for id, title in string.gmatch(x, '<a.-href="(/films/).-">(.-)</a>') do
		
	
   --   table.insert(t, {title = 'ФИЛЬМЫ :' .. title, mrl = '#stream/q=top&id=' .. id})
      
    --  end
      
      
  
 -- local x = conn:load(HOME .. '/serials/top')
  
   --   x = string.match(x, '<ul class="perehod">(.-)</ul>')
	--	for id, title in string.gmatch(x, '<a.-href="(/serials/.-)">(.-)</a>') do
		
	
   --   table.insert(t, {title = 'СЕРИАЛЫ :' .. title, mrl = '#stream/q=top&id=' .. id})
      
   --   end
      
      
      
table.insert(t, {title = 'ВСЕ ФИЛЬМЫ', mrl = '#stream/q=films&id=' .. '/films/', image = HOME .. '/style/img/films.png?w=0'})


  table.insert(t, {title = 'ФИЛЬМЫ : по жанрам', mrl = '#stream/q=genre&id=' .. '/films/genre', image = HOME  .. '/style/img/kategorii.png?w=0'})
  
       table.insert(t, {title = 'ФИЛЬМЫ : подборка', mrl = '#stream/q=collections&id=' .. '/films/collections', image = HOME  .. '/style/img/dop.png?w=0'})
       
     table.insert(t, {title = 'ФИЛЬМЫ : по годам', mrl = '#stream/q=years&id=' .. '/films/years', image = HOME .. '/style/img/raspisan.png?w=0'})
    
    table.insert(t, {title = 'ФИЛЬМЫ : по странам', mrl = '#stream/q=countries&id=' .. '/films/countries', image = HOME .. '/style/img/raspisan.png?w=0'})
    
    table.insert(t, {title = 'ВСЕ СЕРИАЛЫ', mrl = '#stream/q=serials&id=' .. '/serials/', image = HOME .. '/style/img/films.png?w=0'})
    
    
     table.insert(t, {title = 'СЕРИАЛЫ : по жанрам', mrl = '#stream/q=genre&id=' .. '/serials/genre', image = HOME  .. '/style/img/kategorii.png?w=0'})
     
       table.insert(t, {title = 'СЕРИАЛЫ : подборка', mrl = '#stream/q=collections&id=' .. '/serials/collections', image = HOME  .. '/style/img/dop.png?w=0'})

      table.insert(t, {title = 'СЕРИАЛЫ : по годам', mrl = '#stream/q=years&id=' .. '/serials/years', image = HOME .. '/style/img/raspisan.png?w=0'})

      table.insert(t, {title = 'СЕРИАЛЫ : по странам', mrl = '#stream/q=countries&id=' .. '/serials/countries', image = HOME .. '/style/img/raspisan.png?w=0'})
 
 
 

        
        
        
        
     --   table.insert(t, {title = 'СЕРИАЛЫ : Тор за сегодня', mrl = '#stream/genre=' .. '/serials/top'})
       
  --     table.insert(t, {title = 'СЕРИАЛЫ : Тор ANWAP', mrl = '#stream/genre=' .. '/serials/top/like'})
       
   --    table.insert(t, {title = 'СЕРИАЛЫ : Тор КиноПоиск', mrl = '#stream/genre=' .. '/serials/top/kp'})


     --  table.insert(t, {title = 'СЕРИАЛЫ : Тор imdb', mrl = '#stream/genre=' .. '/serials/top/imdb'})
        
        
		
	--	https://tv.anwap.today/films/top
        
        
        

        
        
        
elseif args.q == 'films' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. 'p-' .. tostring(page))


     --   x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
        url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=films&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
       


elseif args.q == 'serials' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. 'p-' .. tostring(page))


     --   x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
        url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=serials&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
       


--https://tv.anwap.today/films/search/?slv=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8&vid=1&page=2
--https://m.anwap.tube/serials/search/?word=%D0%BF%D0%B8&vid=1



elseif args.q == 'countries' then

    
    local x = conn:load(HOME .. args.id)

   
		x = string.match(x, '"zag2".-class="zag2">(.-)"menuniz"')
		for url, title in string.gmatch(x, '<a href="(.-)".-<strong>(.-)</strong>') do
     t['view'] = 'simple'
		
			table.insert(t, {title = title, mrl = '#stream/q=genrez&id=' .. url})
		end




elseif args.q == 'genre' then

    
    local x = conn:load(HOME .. args.id)
   
   t['view'] = 'grid_large'
        x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)</h2>') do
         image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genrez&id=' .. url, image = image})
		end
        
        
elseif args.q == 'genrez' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '-' .. tostring(page))


    --    x = string.match(x, '<div class="zag2"(.-)Показать')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film.-<a href="(/.-)".-src="(.-)".-alt="(.-)"') do
         url = string.gsub(url, '^(.-)', HOME)
         
         
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=genrez&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
        
        
        

elseif args.q == 'collections' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '/' .. tostring(page))

t['view'] = 'grid_large'
        x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)</h2>') do
         image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=collection&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=collections&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
       



elseif args.q == 'collection' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '/' .. tostring(page))


     --   x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
        url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=collection&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
       



elseif args.q == 'years' then
    
    local x = conn:load(HOME .. args.id)
t['view'] = 'simple'

         x = string.match(x, '"zag2".-<div class="zag2">(.-)</div>')
         for url,  title in string.gmatch(x, '<a href="(/.-)".-<strong>(.-)</strong>') do
	--		url = string.gsub(url, '^(.-)', HOME)
			
            --image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=year&id=' .. url, image = image})
		end
        


   elseif args.q == 'year' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '/' .. tostring(page))


      --  x = string.match(x, '<div class="zag2"(.-)Показать')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
         url = string.gsub(url, '^(.-)', HOME)
         
         
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=year&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		


elseif args.q == 'sezon' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '-' .. tostring(page))
		

      -- local slist=string.match(x, '<ul class="tl">(.-)</ul>')


	--	if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/down.-)">(.-)<') do
       print(url)
	  -- 	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=sezond&id=' .. url})
		end 
	
	
			
	local url = '#stream/page=' .. tostring(page + 1) .. '&q=sezon&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


  
    elseif args.q == 'sezond1' then
  
   local x = conn:load(HOME .. args.id)
  
  
  
  local slist=string.match(x, 'tlsiconkoi.-<ul class="tlsiconkoi">(.-)</ul>')


		if slist then
			for url, title in string.gmatch(x, 'href="(/serials/load.-)".-Скачать(.-)<span') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = 'Смотреть' .. tolazy(title), mrl = url})
	
		end
		end	

elseif args.q == 'podborka' then

      local x = conn:load(HOME .. args.id)
	
	local x=string.match(x, 'Актеры:(.-)<div class="clear"')

			for url, title in string.gmatch(x, '<a href="(.-)" class="in f sound">(.-)</a>') do
 
t['view'] = 'simple'
	table.insert(t, {title = title, mrl = '#stream/q=collection&id=' .. url})
  end




elseif args.q == 'popular' then
      
      local x = conn:load(args.id)
   
    --  x = string.match(x, '<div class="popular".-Похожие(.-)Рекомендуем')
	
	
	for url, total, image, title in string.gmatch(x, '<div class="section_item".-<a href="(.-)".-class="godv">(.-)<.-<img src="(.-)".-alt="(.-)"') do


	url = string.gsub(url, '^(.-)', HOME)
			
    image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		



     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/films/search/?slv=' .. urlencode(args.keyword) .. '&vid=1' .. '&page=' .. tostring(page)


		local x = conn:load(url)
		
                 for url, image,  title in string.gmatch(x, '<div class="clear".-<a href="(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', HOME)
			
           image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})


    elseif args.q == '/serials/search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/serials/search/?word=' .. urlencode(args.keyword) .. '&vid=1' .. '&page=' .. tostring(page)


		local x = conn:load(url)
		
                 for url, image,  title in string.gmatch(x, '<div class="clear".-<a href="(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', HOME)
			
            image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})




	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
        t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x, '<div class="filmopis screen3".-<p>(.-)</p>')
			t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="filmopis screen".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			
			
			
	    	t['annotation'] = parse_array(x, {'(Год:</td>.-)</a>', '(Страна:</td>.-)</td>',
			'(Жанр:</td>.-)</td>',
			'(Актеры:</td>.-)</td>'})
			
			
			

local slist1=string.match(x,'"file":"#2(.-)"')

if slist1 then 

slist1 = string.gsub(slist1, '//', '')
        slist1 = string.gsub(slist1, 'WXQ2cmpGZA==', '')
slist1 = string.gsub(slist1, 'RmtpVTdoRw==', '')

slist1 = string.gsub(slist1, 'RXJTdzNBc2k=', '')

slist1 = string.gsub(slist1, 'UlRkM1M2NUZn', '')

    slist1 = base64_decode(slist1)
   
--   table.insert(t, {title = slist1, mrl = slist1})
   
local url1 = string.match(slist1, '(http.-m3u8)') 
   
 --  if url1 then

    --  table.insert(t, {title = slist1, mrl = slist1})
        table.insert(t, {title = 'Смотреть', mrl = url1})
	

end


        local slist=string.match(x, '<ul class="tl2">(.-)"popular"')


		if slist then
			for url, title in string.gmatch(x, '<li><a href="(/serials/s.-)">(.-)</a></li>') do

   local x = conn:load(HOME .. url)
		

      -- local slist=string.match(x, '<ul class="tl">(.-)</ul>')


	--	if slist then
			local ser = string.match(x,'<div class="blm".-<a href="(/serials/down/.-)"')
       print(url)
	  -- 	url = string.gsub(url, '^(.-)', HOME)
      --  t['view'] = 'simple'
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=sezond&id=' .. ser})
		end 
      
   --    table.insert(t, {title = tolazy(title), mrl = '#stream/q=sezon&id=' .. url})
        
        
		end
	--	end	

--https://tv.anwap.today/serials/s6022

   
	
        
for url in string.gmatch(x, '<meta property="og:url" content="(http.-)"') do
  
--local x = conn:load(args.id)
    
   table.insert(t, {title = 'Похожие', mrl = '#stream/q=popular&id=' .. url})
  
  end
 
 
 
  for id in string.gmatch(x, '<meta property="og:url" content="https://.-(/.-)"') do
   
 table.insert(t, {title = 'В подборках', mrl = '#stream/q=podborka&id=' .. id})
  end
 
 
   
        
	

	
     local id, id1 = string.match(x, 'class=.-ball.-<h1.-alt.->(.-)</.-Год:.-class=.-year.->(.-)</')
   
   id = string.gsub(id, 'Скачать сериал ', '')
   id = string.gsub(id, 'Скачать фильм ', '')

    id = urlencode(id)
      
     id = string.gsub(id, '+', '%%20')

    local id2 = string.match(x,'Оригинал:.-<td>(.-)</td>')

if id2 then
  
  
  local url = 'https://kinopoiskapiunofficial.tech/api/v2.1/films/search-by-keyword?keyword=' .. urlencode(id2)
	
local headers = {['accept'] = 'application/json',['X-API-KEY'] = 'c20595a1-3d8c-4cbd-92eb-fd7b0fa75c67'}


    
      local x = http.getz(url, headers) 
 
 
 
 
 local kp = string.match(x, '{"filmId":(.-),')

if kp then

   table.insert(t, {title = 'Источники', mrl = '#stream/q=video&id1=' .. id .. '&id2=' .. id1 .. '&id3=' .. kp, image = image})
 
 end      
end 
 
 
 if not id2 then 

local id, id1 = string.match(x, '<div id="title".-<h1>(.-)<.-class="key".-Год.-href=.->(.-)</a>')

   
   id = string.gsub(id, 'Скачать сериал ', '')
   id = string.gsub(id, 'Скачать фильм ', '')

    id = urlencode(id)
      
     id = string.gsub(id, '+', '%%20')



     
    local url1 = 'https://kinopoiskapiunofficial.tech/api/v2.1/films/search-by-keyword?keyword=' .. id .. '+' .. id1
	
local headers = {['accept'] = 'application/json',['X-API-KEY'] = 'c20595a1-3d8c-4cbd-92eb-fd7b0fa75c67'}
     
     
     
     local x = http.getz(url1, headers) 
 
 --table.insert(t, {title = x, mrl = '#stream/q=video&id1=' .. x, image = image})
 
local kp1 = string.match(x, '{"filmId":(.-),')

if kp1 then
  table.insert(t, {title = 'Источники', mrl = '#stream/q=video&id1=' .. id .. '&id2=' .. id1 .. '&id3=' .. kp1, image = image})
       end
     end
 --  end 
-- end
 --end
 --end
     
  
  
  
  

        
     elseif args.q == 'video' then

       t['view'] = 'list'



 --   table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})

     


  
  
  table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 table.insert(t, {title = 'HdvbF', mrl = '#stream/q=hdvbf&id3=' .. args.id3, image = '#self/movie.png'})
  
 table.insert(t, {title = 'Zagonka', mrl = '#stream/q=zagonka&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})


table.insert(t, {title = 'Kinobadi', mrl = '#stream/q=kinobadi&id3=' .. args.id3, image = '#self/movie.png'})


table.insert(t, {title = 'TurboDB', mrl = '#stream/q=turbo&id3=' .. args.id3, image = '#self/movie.png'})


 -- table.insert(t, {title = 'Hdvb3', mrl = '#stream/q=hdvb2&id3=' .. args.id3, image = '#self/movie.png'})
  
table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id3=' .. args.id3,image = '#self/movie.png'})
  
  table.insert(t, {title = 'Flixme', mrl = '#stream/q=flixme&id3=' .. args.id3,image = '#self/movie.png'})
  
       table.insert(t, {title = 'Collaps', mrl = '#stream/q=collaps&id3=' .. args.id3, image = '#self/movie.png'})

table.insert(t, {title = 'Collaps2', mrl = '#stream/q=collaps2&id3=' .. args.id3, image = '#self/movie.png'})



--  table.insert(t, {title = 'Collaps-dash', mrl = '#stream/q=collaps-dash&id3=' .. args.id3, image = '#self/movie.png'})
  
       
       table.insert(t, {title = 'Kino4k', mrl = '#stream/q=kino4k&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
  
   table.insert(t, {title = 'Filmix', mrl = '#stream/q=filmix&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
--table.insert(t, {title = 'Filmix2', mrl = '#stream/q=filmix2&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 
 table.insert(t, {title = 'Kinoportal', mrl = '#stream/q=filmixred&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3, image = '#self/movie.png'})
 
 
 
 
 --  table.insert(t, {title = 'Lumex', mrl = '#stream/q=lumex&id3=' .. args.id3, image = '#self/movie.png'})
   
 --  table.insert(t, {title = 'Videocdn', mrl = '#stream/q=videocdn&id3=' .. args.id3, image = '#self/movie.png'})
 
 --  table.insert(t, {title = 'Vcdn', mrl = '#stream/q=vcdn&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
   
--  table.insert(t, {title = 'Kinopub', mrl = '#stream/q=kinopub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
 --table.insert(t, {title = 'Kinoportal', mrl = '#stream/q=kinopubtv&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3, image = '#self/movie.png'})
       
   
   
   
       
 --  table.insert(t, {title = 'Alloha', mrl = '#stream/q=alloha&id3=' .. args.id3, image = '#self/movie.png'})
    
    table.insert(t, {title = 'Aladdin', mrl = '#stream/q=spectre&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 
table.insert(t, {title = 'Paladin', mrl = '#stream/q=phantom&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
  table.insert(t, {title = 'Mirage', mrl = '#stream/q=mirage&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})


table.insert(t, {title = 'ZeroHD', mrl = '#stream/q=zerohd&id3=' .. args.id3, image = '#self/movie.png'})


--table.insert(t, {title = 'Videodb', mrl = '#stream/q=videodb&id3=' .. args.id3 .. '&id1=' .. args.id1, image = '#self/movie.png'})

 
table.insert(t, {title = 'Fovea', mrl = '#stream/q=fovea&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 table.insert(t, {title = 'ZetflixDB', mrl = '#stream/q=zetflixdb&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 --table.insert(t, {title = 'Turbo', mrl = '#stream/q=videodb1&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 
 
  
  table.insert(t, {title = 'Vibix', mrl = '#stream/q=vibix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
 --  table.insert(t, {title = 'Videx', mrl = '#stream/q=vibix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
 --  table.insert(t, {title = 'ViDex', mrl = '#stream/q=vibex&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
 table.insert(t, {title = 'ViDex', mrl = '#stream/q=videx&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
--table.insert(t, {title = 'Kinozen', mrl = '#stream/q=kinozen&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 
 
 
   
 table.insert(t, {title = 'Awmzone', mrl = '#stream/q=awmzone&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 table.insert(t, {title = 'Fanserial', mrl = '#stream/q=fanserial&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
  
table.insert(t, {title = 'Seasonvar', mrl = '#stream/q=seasonvar&id1=' .. args.id1, image = image, image = '#self/movie.png'})
  

  
  
  
 -- table.insert(t, {title = 'Cdnmovies', mrl = '#stream/q=cdnmovies&id3=' .. args.id3, image = '#self/movie.png'})


--  table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=vdbmovies&id3=' .. args.id3, image = '#self/movie.png'})
  

  
   table.insert(t, {title = 'Krasview', mrl = '#stream/q=krasview&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 
 
 
 table.insert(t, {title = 'Scts', mrl = '#stream/q=scts&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
--   table.insert(t, {title = 'Sakhtv', mrl = '#stream/q=sakhtv&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
   
   table.insert(t, {title = 'Getstv', mrl = '#stream/q=getstv&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
    
    table.insert(t, {title = 'Anwap', mrl = '#stream/q=anwap&id1=' .. args.id1 .. '&id5=' .. '1' .. '&id6=' .. 'on', image = '#self/movie.png'})
    
   table.insert(t, {title = 'Kinotochka', mrl = '#stream/q=kinotochka&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   


table.insert(t, {title = 'Voidboost', mrl = '#stream/q=voidboost&id3=' .. args.id3, image = '#self/movie.png'})

 table.insert(t, {title = 'HDRezka', mrl = '#stream/q=hdrezkatest&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
  table.insert(t, {title = 'Rezka', mrl = '#stream/q=rezka&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
   table.insert(t, {title = 'FxmlRezka', mrl = '#stream/q=fxmlrezka&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
   
   
   table.insert(t, {title = 'Kinobase', mrl = '#stream/q=kinobase&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 

table.insert(t, {title = 'KinoC', mrl = '#stream/q=kinoc&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 
 
table.insert(t, {title = 'Kinoserials', mrl = '#stream/q=videoseed2&id3=' ..  args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
  
 table.insert(t, {title = 'Videoseed', mrl = '#stream/q=videoseed&id3=' .. args.id3, image = '#self/movie.png'})
 
 
 table.insert(t, {title = '24kino', mrl = '#stream/q=24kino&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 
 table.insert(t, {title = 'Mirkino', mrl = '#stream/q=mirkino&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
   table.insert(t, {title = 'Vkmovie', mrl = '#stream/q=vkmovie&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
   table.insert(t, {title = 'Rutube', mrl = '#stream/q=rutube&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
   
   table.insert(t, {title = 'Kinoflix', mrl = '#stream/q=kinoflix&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
   
table.insert(t, {title = 'Videohub', mrl = '#stream/q=videohub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
 
 table.insert(t, {title = 'Shizard', mrl = '#stream/q=shizard&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 
 
  table.insert(t, {title = 'Atodo', mrl = '#stream/q=atodo&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
  
 
  
 table.insert(t, {title = 'Zaybcdn', mrl = '#stream/q=zayb&id1=' .. args.id1 .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
  
-- table.insert(t, {title = 'Kinogotest', mrl = '#stream/q=kinogotest&id1=' .. args.id1 .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
  table.insert(t, {title = 'Kinogo', mrl = '#stream/q=kinogox&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
  
  
   
table.insert(t, {title = 'Remux', mrl = '#stream/q=remux&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
   
 --  table.insert(t, {title = 'Jac', mrl = '#stream/q=jac&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
  
  table.insert(t, {title = 'Jacred', mrl = '#stream/q=jacred&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
  
   
   table.insert(t, {title = 'Pidtor', mrl = '#stream/q=pidtor&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
-- table.insert(t, {title = 'Potok', mrl = '#stream/q=potok&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 --  table.insert(t, {title = 'Torrs', mrl = '#stream/q=torrs&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
   
  -- table.insert(t, {title = 'Torrs', mrl = '#stream/q=torrsuuu&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
   
   table.insert(t, {title = 'Veo', mrl = '#stream/q=veo&id3=' .. args.id3, image = '#self/movie.png'})
   
   
table.insert(t, {title = 'Veoveo', mrl = '#stream/q=veoveo&id3=' .. args.id3 .. '&id1=' .. args.id1, image = '#self/movie.png'})

--table.insert(t, {title = 'Rapidcdn', mrl = '#stream/q=rapidcdn&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})




table.insert(t, {title = 'Xkino', mrl = '#stream/q=xkino&id1=' .. args.id1, image = '#self/movie.png'})








elseif args.q == 'flixme' then
 

local iframe = 'https://lampa.li/lite/flixcdn?kinopoisk_id=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(iframe)

x = string.gsub(x, '\\u0026', '&')

for id, tr, title, total in string.gmatch(x, '<div class="videos__item videos__movie.-stream.-http.-id=(.-)&t=(.-)&title=(.-)&.-class="videos__item%-title">(.-)</div>') do

t['view'] = 'list'

table.insert(t, {title = tolazy(total), mrl = '#stream/q=flixmef&id=' .. id .. '&id1=' .. tr .. '&id2=' .. title, image = '#self/movie.png'})

end


 
 local x = conn:load(iframe)

 for  url2, total2 in string.gmatch(x, 'class=.-videos__item videos__season.-method.-url.-(http.-)&#.-videos__season%-title.->(.-сезон)<') do
 
 
 
 url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
     local x = conn:load(url2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 

    for url3, voice in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&#.->(.-)</div>') do


url3 = string.gsub(url3, '\\u0026', '&')
     url3 = string.gsub(url3, '\\u002B', '+')
 
      local x = conn:load(url3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
   x = string.gsub(x, '\\u0026', '&')

    for epi, id, sea, tr, total in string.gmatch(x, '<div class="videos__item videos__movie.-stream.-http.-?e=(.-)&id=(.-)&s=(.-)&t=(.-)&.-class="videos__item%-title">(.-)</div>') do


   t['view'] = 'list'

  table.insert(t, {title = tolazy(total2) .. ' ' .. total .. ' ' .. voice, mrl = '#stream/q=flixmes&id=' .. id .. '&id1=' .. sea .. '&id2=' .. epi .. '&id3=' .. tr, image = '#self/movie.png'})

end
end
end
    


 
 elseif args.q == 'flixmef' then
   
   
   local x = conn:load('https://lampa.li/lite/flixcdn/video?id=' .. args.id .. '&t=' .. args.id1 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')


  local qual = string.match(x, 'method.-play.-quality.-{(.-)}')
  
  
   for qul, play in string.gmatch(qual, '"(.-)":"(.-)"') do

     
      t['view'] = 'list'

   table.insert(t, {title = qul .. 'p', mrl = play, image = '#self/movie.png'})

   end
 
 
    
    elseif args.q == 'flixmes' then
   
   
local x = conn:load('https://lampa.li/lite/flixcdn/video?e=' .. args.id2 .. '&id=' .. args.id .. '&s=' .. args.id1 .. '&t=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
  

  local qual = string.match(x, '"method":"play".-"quality":{(.-)}')
  

   for total1, url2 in string.gmatch(qual, '"(720)":"(.-)"') do
      

     
   --   t['view'] = 'list'
t = {}

   table.insert(t, {mrl = url2, image = '#self/movie.png'})

    end   






elseif args.q == 'flixcdn' then

local iframe = 'https://tv.alcopa.cc/lite/flixcdn?kinopoisk_id=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'
 

--table.insert(t, {title = iframe, mrl = iframe, image = '#self/movie.png'})

 local x = conn:load(iframe)

--table.insert(t, {title = x, mrl = x, image = '#self/movie.png'})

x = string.gsub(x, '\\u0026', '&')
x = string.gsub(x, '\\u002B', '+')




for id, tr, name in string.gmatch(x, '<div class="videos__item videos__movie.-method.-call.-url.-http.-id=(.-)&t=(.-)&.-class="videos__item%-title">(.-)<') do




--https://tv.alcopa.cc/lite/flixcdn/video?id=116534&t=1&title=

t['view'] = 'list'

table.insert(t, {title = name, mrl = '#stream/q=flixcdngpf&id=' .. id .. '&id1=' .. tr, image = '#self/movie.png'})

end


local x = conn:load(iframe)

 for  url2, total2 in string.gmatch(x, 'class=.-videos__item videos__season.-method.-url.-(http.-)&#.-videos__season%-title.->(.-сезон)<') do
 
 
 
 url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
     local x = conn:load(url2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 
    for url3, voice in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&#.->(.-)</div>') do


url3 = string.gsub(url3, '\\u0026', '&')
     url3 = string.gsub(url3, '\\u002B', '+')
 
      local x = conn:load(url3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
   x = string.gsub(x, '\\u0026', '&')

    for epi, id, sea, tr, total in string.gmatch(x, '<div class="videos__item videos__movie.-stream.-http.-?e=(.-)&id=(.-)&s=(.-)&t=(.-)&.-class="videos__item%-title">(.-)</div>') do


   t['view'] = 'list'

  table.insert(t, {title = tolazy(total2) .. ' ' .. total .. ' ' .. voice, mrl = '#stream/q=flixcdngps&id=' .. id .. '&id1=' .. sea .. '&id2=' .. epi .. '&id3=' .. tr, image = '#self/movie.png'})

end
end
end



elseif args.q == 'flixcdngpf' then


local x = conn:load('https://tv.alcopa.cc/lite/flixcdn/video?id=' .. args.id .. '&t=' .. args.id1 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

x = string.gsub(x, '\\u0026', '&')
x = string.gsub(x, '\\u002B', '+')


local quality = string.match(x, '"quality":{(.-)}')

if quality then


for qual, play in string.gmatch(quality,'"(.-)":"(.-)"') do 

t['view'] = 'list'


table.insert(t, {title =  qual .. 'p', mrl = play, image = '#self/movie.png'})

end
end



elseif args.q == 'flixcdngps' then


local x = conn:load('https://tv.alcopa.cc/lite/flixcdn/video?e=' .. args.id2 .. '&id=' .. args.id .. '&s=' .. args.id1 .. '&t=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

  local qual = string.match(x, '"method":"play".-"quality":{(.-)}')
  

   for total1, url2 in string.gmatch(qual, '"(720)":"(.-)"') do
      

  -- url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     
  --    t['view'] = 'list'

t = {}
   table.insert(t, {mrl = url2, image = '#self/movie.png'})

    end   
    




    elseif args.q == 'flixcdnzzz' then


 
 local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=flixcdn.live&token=3218fae1545746e1b03cb7178bd1827b')


for id, token, translation in string.gmatch(x, '"id":(.-),"is_serial":false.-"player_files_token":"(.-)".-"translations":%[(.-)].-"type":"movie"') do



for trans, title in string.gmatch(translation, '{"id":(.-),"title":"(.-)"') do

local player = 'https://tarantino.factorios.live/api/player/files'



local headers = {
    ["Host"] = "tarantino.factorios.live",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Referer"] = "https://tarantino.factorios.live/show/kinopoisk/" .. args.id3 .. "?domain=flixcdn.live&token=3218fae1545746e1b03cb7178bd1827b",
  ["Cookie"] = "_ga_ECHML7LBXL=GS2.1.s1789617887$o4$g0$t1789617887$j60$l0$h0; _ga=GA1.1.1957743496.1789385333; ph_phc_wKePmWbYjRSmZAwc5ka8acvCQ3zdgrAtHbCMPHbth35A_posthog=%7B%22%24device_id%22%3A%2201a09fad-5b4f-704a-a4c4-28c486c5d756%22%2C%22distinct_id%22%3A%2201a09fad-5b4f-704a-a4c4-28c486c5d756%22%2C%22%24sesid%22%3A%5B1789617883720%2C%2201a0ad89-d1f8-7dd6-814d-5db0f38b07d0%22%2C1789617883720%5D%2C%22%24initial_person_info%22%3A%7B%22r%22%3A%22%24direct%22%2C%22u%22%3A%22https%3A%2F%2Ftarantino.factorios.live%2Fshow%2Fkinopoisk%2F" .. args.id3 .. "%22%7D%2C%22%24user_state%22%3A%22anonymous%22%7D"
}

--local params = '{"id":' .. id.. ',"season_number":null,"translation":' .. trans .. '}'

local params = '{"id":' .. id .. ',"season_number":null,"translation":' .. trans .. ',"turnstile_token":"","bootstrap_token":"' .. token .. '"}'




local x = http.postz(player, headers, params)

local file = string.match(x,'{"file":"(.-)}') 

if file then

t['view'] = 'list'

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

table.insert(t, {title = qual .. 'p ' .. title, mrl = url, image = '#self/movie.png'})


local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '480.mp4') 

table.insert(t, {title = '480p ' .. title, mrl = url, image = '#self/movie.png'})

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '720.mp4') 

table.insert(t, {title = '720p ' .. title, mrl = url, image = '#self/movie.png'})

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '1080.mp4') 


table.insert(t, {title = '1080p ' .. title, mrl = url, image = '#self/movie.png'})

   end
end
end
 


  local v = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=flixcdn.live&token=3218fae1545746e1b03cb7178bd1827b')


  
  for id, token, seasons, translations in string.gmatch(v, 'id":(.-),"is_serial":true.-"player_files_token":"(.-)".-"seasons_episodes":{(.-)}.-"translations":%[(.-)]') do
  
 
  
  
  
  seasons = string.gsub(seasons, '%[', '["') 
seasons = string.gsub(seasons, ']', '"]') 
seasons = string.gsub(seasons, ',', '","') 
  
  
  for season, episodes in string.gmatch(seasons,'"(.-)":%[(.-)]') do
  
  for episode in string.gmatch(episodes,'"(.-)"') do
  
  for trans, title in string.gmatch(translations,'"id":(.-),"title":"(.-)"') do
  
   
   season = string.gsub(season, ',""', '') 
   

  t['view'] = 'list'  


 
 table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = '#stream/q=flixcdns&id=' .. id .. '&id1=' .. trans .. '&id2=' .. season .. '&id3=' .. episode .. '&id4=' .. args.id3 .. '&id5=' .. token, image = '#self/movie.png'})
 
 

 
 end
 end
 end
 end
 
    
    elseif args.q == 'flixcdns' then  
  
  

    local player = 'https://tarantino.factorios.live/api/player/files'



local headers = {
    ["Host"] = "tarantino.factorios.live",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        ["Referer"] = "https://tarantino.factorios.live/show/kinopoisk/" .. args.id4 .. "?domain=flixcdn.live&token=3218fae1545746e1b03cb7178bd1827b",
    
  ["Cookie"] = "_ga_ECHML7LBXL=GS2.1.s1789617887$o4$g0$t1789617887$j60$l0$h0; _ga=GA1.1.1957743496.1789385333; ph_phc_wKePmWbYjRSmZAwc5ka8acvCQ3zdgrAtHbCMPHbth35A_posthog=%7B%22%24device_id%22%3A%2201a09fad-5b4f-704a-a4c4-28c486c5d756%22%2C%22distinct_id%22%3A%2201a09fad-5b4f-704a-a4c4-28c486c5d756%22%2C%22%24sesid%22%3A%5B1789617883720%2C%2201a0ad89-d1f8-7dd6-814d-5db0f38b07d0%22%2C1789617883720%5D%2C%22%24initial_person_info%22%3A%7B%22r%22%3A%22%24direct%22%2C%22u%22%3A%22https%3A%2F%2Ftarantino.factorios.live%2Fshow%2Fkinopoisk%2F" .. args.id3 .. "%22%7D%2C%22%24user_state%22%3A%22anonymous%22%7D"
}

local params = '{"id":' .. args.id .. ',"season_number":' .. args.id2 .. ',"episode_number":' .. args.id3 .. ',"translation":' .. args.id1 .. ',"turnstile_token":"","bootstrap_token":"' .. args.id5 .. '"}'
  

local x = http.postz(player, headers, params)

local file = string.match(x,'{"file":"(.-)}') 

if file then

t['view'] = 'list'

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

table.insert(t, {title = qual .. 'p', mrl = url, image = '#self/movie.png'})


local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '480.mp4') 

table.insert(t, {title = '480p', mrl = url, image = '#self/movie.png'})

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '720.mp4') 

table.insert(t, {title = '720p', mrl = url, image = '#self/movie.png'})

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '1080.mp4') 


table.insert(t, {title = '1080p', mrl = url, image = '#self/movie.png'})

 end 


elseif args.q == 'scts' then



local x = conn:load('https://lampa.li/lite/scts?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

if x then

--table.insert(t, {title = 'https://lampa.li/lite/scts?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn', mrl = 'http://beta.l-vid.online/lite/zona?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn'})

--https://z01.online/lite/solntse?kinopoisk_id=386&title=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&year=1979

--table.insert(t, {title = 'https://z01.online/lite/solntse?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'http://z01.online//lite/zona?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '\\u002B', '+')


   for url, total in string.gmatch(x, 'videos__item videos__movie.-stream.-(http.-)&#.-videos__item%-title.->(.-)<') do

t['view'] = 'list'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = tolazy(total), mrl = url, image = '#self/movie.png'})

     end 
end

local x = conn:load('https://z01.online/lite/solntse?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

if x then


--https://z01.online/lite/solntse?kinopoisk_id=386&title=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&year=1979

--table.insert(t, {title = 'https://z01.online/lite/solntse?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'http://z01.online//lite/zona?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '\\u002B', '+')


   for url, total in string.gmatch(x, 'videos__item videos__movie.-url.-(http.-)".-videos__item%-title.->(.-)<') do

t['view'] = 'list'


table.insert(t, {title = tolazy(total), mrl = url, image = '#self/movie.png'})

     end 
end





   elseif args.q == 'krasview' then


--https://krasview.ru/movie?mode=search&ajax&query=

--    local x = conn1:load('https://krasview.ru/movie?mode=vector-search&ajax&query=' .. urlencode(args.id1) .. '+' .. args.id2)

local x = conn1:load('https://krasview.ru/movie?mode=search&ajax&query=' .. urlencode(args.id1) .. '+' .. args.id2)



--table.insert(t, {title = 'https://krasview.ru/movie?mode=vector-search&ajax&query=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://krasview.ru/movie?mode=search&ajax&query=' .. urlencode(args.id1) .. ',' .. args.id2})


   for url, total in string.gmatch(x, '<li id=.-<a href=.-(http.-)\'.-alt=\'(.-)\'>') do


--table.insert(t, {title = url, mrl = url})

  
  local headers = {
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = url,
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
  
  
  
      local x = http.getz(url, headers)



    for id in string.gmatch(x, '<ul class=.-video%-gallery.-itemscope itemtype=.-id=\'v%-(.-)\'') do

t['view'] = 'list'

table.insert(t, {title = total, mrl = '#stream/q=krasviewvideo&id=' .. id, image = '#self/movie.png'})

end
end






--https://sersoap.ru/series/Game_of_Thrones/?page=2

    local x = conn1:load('https://krasview.ru/series?mode=search&ajax&query=' .. urlencode(args.id1) .. '+' .. args.id2)


    for url, total in string.gmatch(x, '<li id=.-<a href=\'(http.-)\'.-alt=\'(.-)\'') do
         t['view'] = 'list'
 
    table.insert(t, {title = tolazy(total), mrl = '#stream/q=krasviews&id=' .. url, image = '#self/movie.png'})
    end
 
   elseif args.q == 'krasviews' then

local page = tonumber(args.page or 1)

      local x = conn1:load(args.id .. '?page=' .. tostring(page))



   for id, title in string.gmatch(x, '<li itemprop=\'itemListElement\' itemscope itemtype=.-id=\'v%-(.-)\'.-alt=\'(.-)\'') do

t['view'] = 'list'

table.insert(t, {title = title, mrl = '#stream/q=krasviewvideo&id=' .. id, image = '#self/movie.png'})


end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=krasviews&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


--https://smartkino.ru/video/1285056-Hischnik.Planeta.smerti-Film

--https://zedfilm.ru/1285056

elseif args.q == 'krasviewvideo' then

local headers = {
    ["Host"] = "zedfilm.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://zedfilm.ru/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
     args.id = string.gsub(args.id, '^(.-)', 'https://zedfilm.ru/') 
 
 --  table.insert(t, {title = args.id, mrl = args.id})
   
     local x = http.getz(args.id, headers)
 
 local slist = string.match(x, 'video_Init.-\'(.-)\'') 
 
 
    slist = base64_decode(slist)
   
  --local url  = string.match(slist, '"url":"(http.-).mp.-"') 
   for url in string.gmatch(slist, '"url.-:"(https://media.-).mp.-"') do
    
   -- "url.-:"(https://media.-).mp.-"
    
    
      url = string.gsub(url, 'media', 'm')
     -- url = string.gsub(url, '^(.-)', '.mp4')
      
      if url then
    print(url2)
    return {view = 'playback', mrl = url .. '.mp4', seekable = 'true', direct = 'true'}
-- end
      
 
end
end


 
 
 
 
 
elseif args.q == 'zagonka' then


args.id1 = string.gsub(args.id1, ' ', '%%20') 
		
       local url = 'http://zagonka.tv/engine/ajax/xsearch/f.php?q=' .. args.id1
       --.. ' (' .. args.id2 .. ')'

--table.insert(t, {title = url, mrl = url})	

local headers = {    
      ["host"] = "zagonka.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
 ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["referer"] = "http://zagonka.tv/",
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive"
}



local x = http.getz(url, headers)



local x = json.decode(x)

		for _, v in ipairs(x) do

	t['view'] = 'list'
	
	table.insert(t, {title = v['text'], mrl = '#stream/q=zagonkaz&id1=' .. v['id'] .. '&id=' .. v['url'], image = '#self/movie.png'})

end






--for ids, urls in string.gmatch(x, '{"id":"(.-)".-url.-(/.-)"') do

--{"id":"(.-)","text":"(.-)","url":"\/135628-ubivat-nado-vovremja-1998-onlayn.html"

--local ids, urls = string.match(x, '{"id":"(.-)".-url.-(/.-)"')

--urls = string.gsub(urls, '^(.-)', 'http://abc.zagonkop.gb.net') 

 
--t['view'] = 'simple'

--table.insert(t, {title = urldecode(args.id1) .. '(' .. args.id2 .. ')', mrl = '#stream/q=zagonkaz&id=' .. urls .. '&id1=' .. ids .. '&id2=' .. args.id2})

--end



elseif args.q == 'zagonkaz' then

  local url1 = 'http://zagonka.tv/embed/' .. args.id1


local ref = '"' .. 'http://zagonka.tv' .. args.id .. '"'



local headers = {
    ["Host"] = "zagonka.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Referer"] = ref,
["Connection"] = "keep-alive",
["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
["Upgrade-Insecure-Requests"] = "1",
["Priority"] = "u=4"
}



  local x = http.getz(url1, headers)


--local id = string.match(x, 'data%-id="(.-)"')

--table.insert(t, {title = x, mrl = x})


x = string.gsub(x, 'ZYzNM', '')
        x = string.gsub(x, 'ZUzls', '')
x = string.gsub(x, 'ZUzVw', '')

x = string.gsub(x, 'ZUTB5', '')

x = string.gsub(x, 'ZaTdV', '')


local x = string.match(x, 'Playerjs%(\'#2(.-)\'%)+') 
   
  if x then      
    
    
    x = base64_decode(x)
     
 x = string.gsub(x, '{v1}', '.mp4')   

 --table.insert(t, {title = x, mrl = x})
  
 
 for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')
 
 
 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

  table.insert(t, {title = '(1080p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3, image = '#self/movie.png'})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/720.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

  table.insert(t, {title = '(720p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3, image = '#self/movie.png'})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

  table.insert(t, {title = '(480p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3, image = '#self/movie.png'})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/360.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

  table.insert(t, {title = '(360p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3, image = '#self/movie.png'})
  
  end
 
 
  
for tr, voise in string.gmatch(x, 'class=\'in_tr\'>(.-)<br>.-folder(.-)}]') do

for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3, image = '#self/movie.png'})
  
  end
end

for tr, voise in string.gmatch(x, 'class=\'in_tr\'>(.-)<br>.-folder(.-)}]') do

for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do


 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3, image = '#self/movie.png'})
 end 
 end



for voise in string.gmatch(x, '<div id=\'_not\'.-folder(.-)}]') do


for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия', mrl = url3,bimage = '#self/movie.png'})
  
  end
end


for voise in string.gmatch(x, '<div id=\'_not\'.-folder(.-)}]') do


for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

 table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия', mrl = url3, image = '#self/movie.png'})
  
  end
end
 end
  


 
--local url = 'https://kinogo2026.com/index.php?story=' .. urlencode(args.id1) .. '&do=search&subaction=search'

--https://kinonix.net/109372-mortal-kombat-2.html

--https://kinonix.net/index.php?story=чужой+1979&do=search&subaction=search

--https://proxy4.rte.net.ru/https://kinogo.biz/index.php?story=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB+2025&do=search&subaction=search

--https://kinogo2026.com/index.php?story=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB+2025&do=search&subaction=search

--https://hdrezka.inc//index.php?story=чужой+1979&do=search&subaction=search





elseif args.q == 'kinogox' then

--https://kinogo2026.com/

--https://kinonix.net

local x = conn:load('https://kinogo2026.com/index.php?story=' .. urlencode(args.id1 .. ' ' .. args.id2) .. '&do=search&subaction=search')


local search = string.match(x, '<h2.-href.-(http.-html)') 

if search then



 local x = conn:load(search)
 
local ref = '"' .. search .. '"'

local headers2 = {
    ["Host"] = "cinemar.cc",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Content-Type"] = "text/html; charset=utf-8",
    ["Sec-Fetch-Storage-Access"] = "none",
    ["Connection"] = "keep-alive",
    ["Referer"] = ref,
    ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb; device_fp=dc5352f6d0c470ed5624bc225b261ecc",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}

 
 
 local url2 = string.match(x,'(//cinemar.cc/embed/.-)"')
 

 
if url2 then
 
--  https://proxy4.rte.net.ru/
  
 local embed = 'https:' .. url2
 
local ref1 = '"' .. embed .. '"'

 local x = http.getz(embed, headers2)

--table.insert(t, {title = 'https://proxy4.rte.net.ru/' .. embed, mrl = embed, image = '#self/movie.png'})




local url3 = string.match(x, 'Cinemar%(.-#2.-(W3sia.-)%"+')

if url3 then

--local str = str
--local result = string.sub(str, 9)

--local original = "Ваш_строка_здесь"
--local result = original:gsub("%W{3}", "")



url3 = string.gsub(url3,'+','XXXXX')

url3 = string.gsub(url3, '%W{3}', '')

 --url3 = string.gsub(url3, '%W', '')
 
 url3 = string.gsub(url3,'XXXXX','+')


 
url3 = base64_decode(url3)
 

 url3 = string.gsub(url3,'"title":"\\u0421\\u0435\\u0437\\u043e\\u043d', '')
 
url3 = string.gsub(url3,'"title":"\\u0421\\u0435\\u0440\\u0438\\u044f', '')

url3 = string.gsub(url3,'<', '"')


 url3 = string.gsub(url3, '\\u0410', 'А')
      url3 = string.gsub(url3, '\\u0430', 'а')
       
       url3 = string.gsub(url3, '\\u0411', 'Б')
       url3 = string.gsub(url3, '\\u0431', 'б')  
       url3 = string.gsub(url3, '\\u0412', 'В')
      url3 = string.gsub(url3, '\\u0432', 'в')
       url3 = string.gsub(url3, '\\u0413', 'Г')
       url3 = string.gsub(url3, '\\u0433', 'г')  
      url3 = string.gsub(url3, '\\u0414', 'Д')
      url3 = string.gsub(url3, '\\u0434', 'д')
       url3 = string.gsub(url3, '\\u0415', 'Е')
       url3 = string.gsub(url3, '\\u0435', 'е')  
      url3 = string.gsub(url3, '\\u0401', 'Ё')
      url3 = string.gsub(url3, '\\u0451', 'ё')
       url3 = string.gsub(url3, '\\u0416', 'Ж')
       url3 = string.gsub(url3, '\\u0436', 'ж')  
       url3 = string.gsub(url3, '\\u0417', 'З')
      url3 = string.gsub(url3, '\\u0437', 'з')
       url3 = string.gsub(url3, '\\u0418', 'И')
       url3 = string.gsub(url3, '\\u0438', 'и')  
       url3 = string.gsub(url3, '\\u0419', 'Й')
      url3 = string.gsub(url3, '\\u0439', 'й')
       url3 = string.gsub(url3, '\\u041a', 'К')
       url3 = string.gsub(url3, '\\u043a', 'к')  
       url3 = string.gsub(url3, '\\u041b', 'Л')
       url3 = string.gsub(url3, '\\u043b', 'л')
       url3 = string.gsub(url3, '\\u041c', 'М')
       url3 = string.gsub(url3, '\\u043c', 'м')
       url3 = string.gsub(url3, '\\u041d', 'Н')
       url3 = string.gsub(url3, '\\u043d', 'н')
       url3 = string.gsub(url3, '\\u041e', 'О')
       url3 = string.gsub(url3, '\\u043e', 'о')
       url3 = string.gsub(url3, '\\u041f', 'П')
       url3 = string.gsub(url3, '\\u043f', 'п')
       url3 = string.gsub(url3, '\\u0420', 'Р')
       url3 = string.gsub(url3, '\\u0440', 'р')
       url3 = string.gsub(url3, '\\u0421', 'С')
       url3 = string.gsub(url3, '\\u0441', 'с')
       url3 = string.gsub(url3, '\\u0422', 'Т')
       url3 = string.gsub(url3, '\\u0442', 'т')
       url3 = string.gsub(url3, '\\u0423', 'У')
       url3 = string.gsub(url3, '\\u0443', 'у')
       url3 = string.gsub(url3, '\\u0424', 'Ф')
        url3 = string.gsub(url3, '\\u0444', 'ф')
        url3 = string.gsub(url3, '\\u0425', 'Х')
        url3 = string.gsub(url3, '\\u0445', 'х')
        url3 = string.gsub(url3, '\\u0426', 'Ц')
        url3 = string.gsub(url3, '\\u0446', 'ц')
        url3 = string.gsub(url3, '\\u0427', 'Ч')
        url3 = string.gsub(url3, '\\u0447', 'ч')
        url3 = string.gsub(url3, '\\u0428', 'Ш')
        url3 = string.gsub(url3, '\\u0448', 'ш')
        url3 = string.gsub(url3, '\\u0429', 'Щ')
        url3 = string.gsub(url3, '\\u0449', 'щ')
        url3 = string.gsub(url3, '\\u042a', 'Ъ')
        url3 = string.gsub(url3, '\\u044a', 'ъ')
        url3 = string.gsub(url3, '\\u042b', 'Ы')
        url3 = string.gsub(url3, '\\u044b', 'ы')
        url3 = string.gsub(url3, '\\u042c', 'Ь')
        url3 = string.gsub(url3, '\\u044c', 'ь')
        url3 = string.gsub(url3, '\\u042d', 'Э')
        url3 = string.gsub(url3, '\\u044d', 'э')
        url3 = string.gsub(url3, '\\u042e', 'Ю')
        url3 = string.gsub(url3, '\\u044e', 'ю')
        url3 = string.gsub(url3, '\\u042f', 'Я')
        url3 = string.gsub(url3, '\\u044f', 'я')
        url3 = string.gsub(url3, '\\u00ab', '<<')
        url3 = string.gsub(url3, '\\u00bb', '>>')
        url3 = string.gsub(url3, '\\u2014', '-')
	url3 = string.gsub(url3, '\\u00a0', ' ')
	url3 = string.gsub(url3, '\\u0=', 'ия')





--table.insert(t, {title = url3, mrl = url3, image = '#self/movie.png'})




for title, data in string.gmatch(url3, '"title":"(.-)".-"title2":"".-"data":"(.-)"') do

if data then

data = string.gsub(data,'\\','')


--title = string.gsub(title, '^(.-)', '{') .. '}'

--local v = json.decode(title)


--local title = v['title']

local list = 'https://cinemar.cc/api/playlist/load'


local headers3 = {
    ["Host"] = "cinemar.cc",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Content-Type"] = "application/json",
  ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb",
    ["Content-Length"] = "",
    ["Origin"] = "https://cinemar.cc",
    ["Connection"] = "keep-alive",
    ["Referer"] = ref1,
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local datas = '"' .. data .. '"'

local x = http.postz(list, headers3, datas)

if x then


-- t['view'] = 'list'
 
--table.insert(t, {title = x, mrl = x, image = '#self/movie.png'})
 
 
 local file, file1 = string.match(x,'"file":"(.-)(/movie.-)/hls.m3u8"')

 if file1 then
 
 t['view'] = 'list'


table.insert(t, {title = '(1080p) ' .. tolazy(title), mrl = file .. file1 .. '/1080.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

table.insert(t, {title = '(720p) ' .. tolazy(title), mrl = file .. file1 .. '/720.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

table.insert(t, {title = '(480p) ' .. tolazy(title), mrl = file .. file1 .. '/480.mp4:hls:manifest.m3u8', image = '#self/movie.png'})


table.insert(t, {title = '(360p) ' .. tolazy(title), mrl = file .. file1 .. '/360.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

table.insert(t, {title = '(240p) ' .. tolazy(title), mrl = file .. file1 .. '/240.mp4:hls:manifest.m3u8', image = '#self/movie.png'})


 end
end
 end
 end



for title, title1, data1 in string.gmatch(url3, '"title":"(.-)".-"title2":"(.-)".-"data":"(.-)"') do

if data1 then

data1 = string.gsub(data1,'\\','')



--title = string.gsub(title, '^(.-)', '{') .. '}'

--local v = json.decode(title)


--local title = v['title']
 
-- title1 = string.gsub(title1, '^(.-)', '{') .. '}'


--local c = json.decode(title1)


--local title1 = c['title2']
 
-- local title1 = string.match(title1, '(.-ерия)')
 
 if title1 then
 
 t['view'] = 'list'

table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=kinogoxs&id=' .. data1 .. '&id1=' .. embed, image = '#self/movie.png'})


end
end
end
end
end
end

 
if not search then

local x =  conn:load('https://hdrezka.inc/index.php?story=' .. urlencode(args.id1 .. ' ' .. args.id2) .. '&do=search&subaction=search')


--if x then

local search1 = string.match(x,'<h2.-href.-(http.-html)') 
 
 if search1 then
 
 local x = conn:load(search1)
 
local ref2 = '"' .. search1 .. '"'
 
 local headers2 = {
    ["Host"] = "cinemar.cc",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Sec-Fetch-Storage-Access"] = "none",
    ["Connection"] = "keep-alive",
    ["Referer"] = ref2,
    ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb; device_fp=dc5352f6d0c470ed5624bc225b261ecc",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}

 
 
 local url2 = string.match(x, '(//cinemar.cc/embed/.-)"')
 

 
if url2 then
 
--  https://proxy4.rte.net.ru/
  
 local embed = 'https:' .. url2
 
local ref3 = '"' .. embed .. '"'

 local x = http.getz(embed, headers2)


local player = string.match(x, 'Cinemar%((.-)%)+')

if player then


 local url3 = string.match(player, '"file":"#.-(W3sia.-)%"+')

 
url3 = string.gsub(url3,'+','XXXXX')

url3 = string.gsub(url3, '%W{3}', '')

 --url3 = string.gsub(url3, '%W', '')
 
 url3 = string.gsub(url3,'XXXXX','+')




 
url3 = base64_decode(url3)
 


 url3 = string.gsub(url3,'"title":"\\u0421\\u0435\\u0437\\u043e\\u043d', '')
 
url3 = string.gsub(url3,'"title":"\\u0421\\u0435\\u0440\\u0438\\u044f', '')

url3 = string.gsub(url3,'<', '"')

url3 = string.gsub(url3, '\\u0410', 'А')
      url3 = string.gsub(url3, '\\u0430', 'а')
       
       url3 = string.gsub(url3, '\\u0411', 'Б')
       url3 = string.gsub(url3, '\\u0431', 'б')  
       url3 = string.gsub(url3, '\\u0412', 'В')
      url3 = string.gsub(url3, '\\u0432', 'в')
       url3 = string.gsub(url3, '\\u0413', 'Г')
       url3 = string.gsub(url3, '\\u0433', 'г')  
      url3 = string.gsub(url3, '\\u0414', 'Д')
      url3 = string.gsub(url3, '\\u0434', 'д')
       url3 = string.gsub(url3, '\\u0415', 'Е')
       url3 = string.gsub(url3, '\\u0435', 'е')  
      url3 = string.gsub(url3, '\\u0401', 'Ё')
      url3 = string.gsub(url3, '\\u0451', 'ё')
       url3 = string.gsub(url3, '\\u0416', 'Ж')
       url3 = string.gsub(url3, '\\u0436', 'ж')  
       url3 = string.gsub(url3, '\\u0417', 'З')
      url3 = string.gsub(url3, '\\u0437', 'з')
       url3 = string.gsub(url3, '\\u0418', 'И')
       url3 = string.gsub(url3, '\\u0438', 'и')  
       url3 = string.gsub(url3, '\\u0419', 'Й')
      url3 = string.gsub(url3, '\\u0439', 'й')
       url3 = string.gsub(url3, '\\u041a', 'К')
       url3 = string.gsub(url3, '\\u043a', 'к')  
       url3 = string.gsub(url3, '\\u041b', 'Л')
       url3 = string.gsub(url3, '\\u043b', 'л')
       url3 = string.gsub(url3, '\\u041c', 'М')
       url3 = string.gsub(url3, '\\u043c', 'м')
       url3 = string.gsub(url3, '\\u041d', 'Н')
       url3 = string.gsub(url3, '\\u043d', 'н')
       url3 = string.gsub(url3, '\\u041e', 'О')
       url3 = string.gsub(url3, '\\u043e', 'о')
       url3 = string.gsub(url3, '\\u041f', 'П')
       url3 = string.gsub(url3, '\\u043f', 'п')
       url3 = string.gsub(url3, '\\u0420', 'Р')
       url3 = string.gsub(url3, '\\u0440', 'р')
       url3 = string.gsub(url3, '\\u0421', 'С')
       url3 = string.gsub(url3, '\\u0441', 'с')
       url3 = string.gsub(url3, '\\u0422', 'Т')
       url3 = string.gsub(url3, '\\u0442', 'т')
       url3 = string.gsub(url3, '\\u0423', 'У')
       url3 = string.gsub(url3, '\\u0443', 'у')
       url3 = string.gsub(url3, '\\u0424', 'Ф')
        url3 = string.gsub(url3, '\\u0444', 'ф')
        url3 = string.gsub(url3, '\\u0425', 'Х')
        url3 = string.gsub(url3, '\\u0445', 'х')
        url3 = string.gsub(url3, '\\u0426', 'Ц')
        url3 = string.gsub(url3, '\\u0446', 'ц')
        url3 = string.gsub(url3, '\\u0427', 'Ч')
        url3 = string.gsub(url3, '\\u0447', 'ч')
        url3 = string.gsub(url3, '\\u0428', 'Ш')
        url3 = string.gsub(url3, '\\u0448', 'ш')
        url3 = string.gsub(url3, '\\u0429', 'Щ')
        url3 = string.gsub(url3, '\\u0449', 'щ')
        url3 = string.gsub(url3, '\\u042a', 'Ъ')
        url3 = string.gsub(url3, '\\u044a', 'ъ')
        url3 = string.gsub(url3, '\\u042b', 'Ы')
        url3 = string.gsub(url3, '\\u044b', 'ы')
        url3 = string.gsub(url3, '\\u042c', 'Ь')
        url3 = string.gsub(url3, '\\u044c', 'ь')
        url3 = string.gsub(url3, '\\u042d', 'Э')
        url3 = string.gsub(url3, '\\u044d', 'э')
        url3 = string.gsub(url3, '\\u042e', 'Ю')
        url3 = string.gsub(url3, '\\u044e', 'ю')
        url3 = string.gsub(url3, '\\u042f', 'Я')
        url3 = string.gsub(url3, '\\u044f', 'я')
        url3 = string.gsub(url3, '\\u00ab', '<<')
        url3 = string.gsub(url3, '\\u00bb', '>>')
        url3 = string.gsub(url3, '\\u2014', '-')
	url3 = string.gsub(url3, '\\u00a0', ' ')
	url3 = string.gsub(url3, '\\u0=', 'ия')




for title, data in string.gmatch(url3, '"title":"(.-)".-"title2":"".-"data":(".-")') do

if data then

data = string.gsub(data,'\\','')


--title = string.gsub(title, '^(.-)', '{') .. '}'

--local v = json.decode(title)



--local title = v['title']



local list = 'https://cinemar.cc/api/playlist/load'


local headers3 = {
    ["Host"] = "cinemar.cc",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Content-Type"] = "application/json",
  ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb",
    ["Content-Length"] = "",
    ["Origin"] = "https://cinemar.cc",
    ["Connection"] = "keep-alive",
    ["Referer"] = ref3,
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local data = data

local x = http.postz(list, headers3, data)

if x then


-- t['view'] = 'list'
 
 
 local file, file1 = string.match(x,'"file":"(.-)(/movie.-)/hls.m3u8"')

 if file1 then
 
 t['view'] = 'list'


table.insert(t, {title = '(1080p) ' .. tolazy(title), mrl = file .. file1 .. '/1080.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

table.insert(t, {title = '(720p) ' .. tolazy(title), mrl = file .. file1 .. '/720.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

table.insert(t, {title = '(480p) ' .. tolazy(title), mrl = file .. file1 .. '/480.mp4:hls:manifest.m3u8', image = '#self/movie.png'})


table.insert(t, {title = '(360p) ' .. tolazy(title), mrl = file .. file1 .. '/360.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

table.insert(t, {title = '(240p) ' .. tolazy(title), mrl = file .. file1 .. '/240.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

 end
 end
end 
end 



for title, title1, data1 in string.gmatch(url3, '"title":"(.-)".-"title2":"(.-)".-"data":"(.-)"') do

if data1 then

data1 = string.gsub(data1,'\\','')


--title = string.gsub(title, '^(.-)', '{') .. '}'

--local v = json.decode(title)


--local title = v['title']

 
 --title1 = string.gsub(title1, '^(.-)', '{') .. '}'

--local c = json.decode(title1)



--local title1 = c['title2']
 
-- local title1 = string.match(title1, '(.-ерия)')
 
 if title1 then
 
 t['view'] = 'list'

table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=kinogoxs&id=' .. data1 .. '&id1=' .. embed, image = '#self/movie.png'})



end  
end
end
end
end
end



end

 
 
 elseif args.q == 'kinogoxs' then

args.id = string.gsub(args.id, ' ', '+') 
args.id1 = string.gsub(args.id1, ' ', '+') 

 local list1 = 'https://cinemar.cc/api/playlist/load'

local ref = '"' .. args.id1 .. '"'

local headers4 = {
    ["Host"] = "cinemar.cc",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Content-Type"] = "application/json",
    ["Content-Length"] = "",
    ["Origin"] = "https://cinemar.cc",
    ["Connection"] = "keep-alive",
    ["Referer"] = ref,
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}
 
 local data1 = '"' .. args.id .. '"'

--table.insert(t, {title = args.id1, mrl = data1})
 
local x = http.postz(list1, headers4, data1)
 
 
 if x then
 
 local file = string.match(x,'"file":"(.-)/hls.m3u8"')

 if file then
 
  t['view'] = 'list'


table.insert(t, {title = '(1080p)', mrl = file .. '/1080.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

table.insert(t, {title = '(720p)', mrl = file .. '/720.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

table.insert(t, {title = '(480p)', mrl = file .. '/480.mp4:hls:manifest.m3u8', image = '#self/movie.png'})


table.insert(t, {title = '(360p)', mrl = file .. '/360.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

table.insert(t, {title = '(240p)', mrl = file .. '/240.mp4:hls:manifest.m3u8', image = '#self/movie.png'})

end
end
 



--https://fanserial.me/player/?file=https://fancdn.net/iframe/?kinopoisk=386



elseif args.q == 'fanserial' then

 
 
--local url = 'https://1fanserials.org/index.php?do=search'
 
 local url = 'https://1fanserials.org/?do=search&subaction=search&story=' .. urlencode(args.id1)

 local headers = {
    ["Host"] = "1fanserials.org",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://1fanserials.org/",
    ["Connection"] = "keep-alive",
    ["Content-Type"] = "application/x-www-form-urlencoded",
["Content-Length"] = "",
    ["Cookie"] = "__ddg8_=1fmsm0vHdmBHUNd2; __ddg10_=1785251191; __ddg9_=185.228.133.239; __ddg1_=yKoRO1EMPs6rMsq5RYxZ; PHPSESSID=1a21b2ffc6e416654a5282bb064269d3; _ym_uid=1785251045348708012; _ym_d=1785251045; _ym_isad=2; _ym_visorc=b; adrfpip=nAbe16msPTPn; _ohmybid_cmf=2; domain_sid=APwDrHvXKAJ6iYZlPJ69p%3A1785251239326; _sltm=8d703f70f587d25c492c5c2b66042230~0; _sltb=0; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0, i"
}
 
 
local params = 'do=search&subaction=search&search_start=0&full_search=1&result_from=1&story=' .. args.id1 .. '&all_word_seach=1&titleonly=3&searchuser=&replyless=0&replylimit=0&searchdate=0&beforeafter=after&sortby=title&resorder=asc&showposts=0&catlist%5B%5D=10'

 
 local x = http.getz(url, headers)
 
 
  
for url in string.gmatch(x,'<h2.-href=.-(http.-html)') do


 
local x = http.getz(url, headers) 
 
 
  local movie = string.match(x,'itemprop="item.-href="/films/"(.-)"post"')
  
  if movie then
                
 for title, total, kp, key in string.gmatch(movie,'<h1.->(.-)</h1>.-Год.-class="field%-text.->(.-)<.-<iframe.-src=.-/movies/(.-)%?key=(.-)"') do

if kp then
if key then

t['view'] = 'list'

table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=fanserialsm&id=' .. kp .. '&id1=' .. key, image = '#self/movie.png'})

--table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=fanserialsm&id=' .. url .. '&id3=' .. args.id3})
 
 end
 end
 end
end 
end 
 
 




 elseif args.q == 'fanserials' then

local x = conn:load('https://lomont.site/player/responce.php?video_id=' .. args.id .. '&season=' .. args.id1 .. '&episode=' .. args.id2 .. '&voice=' .. args.id4 .. '&alloff=true', headers)
  --   print(x)


if x then

local url = string.match(x,'"src".-(http.-m3u8)"')

url = string.gsub(url, '\\', '')
  
 
  --    t['view'] = 'list'

return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}

--table.insert(t, {title = 'Сезон ' .. args.id1 .. ' серия ' .. args.id2 .. ' ' .. args.id5, mrl = url})

end





elseif args.q == 'fanserialsm' then
   
local headers = {
    ["Host"] = "1fanserials.org",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://1fanserials.org/films/",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "__ddg8_=1fmsm0vHdmBHUNd2; __ddg10_=1785251191; __ddg9_=185.228.133.239; __ddg1_=yKoRO1EMPs6rMsq5RYxZ; PHPSESSID=1a21b2ffc6e416654a5282bb064269d3; _ym_uid=1785251045348708012; _ym_d=1785251045; _ym_isad=2; _ym_visorc=b; adrfpip=nAbe16msPTPn; _ohmybid_cmf=2; domain_sid=APwDrHvXKAJ6iYZlPJ69p%3A1785251239326; _sltm=8d703f70f587d25c492c5c2b66042230~0; _sltb=0; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0, i"
}


 
 --local x = http.getz(args.id, headers) 
 
 
 
 --local kp, key = string.match(x,'<iframe.-src="/.-/(.-)%?key=(.-)"')
 
-- if key then
 
local headers1 = {
    ["Host"] = "1fanserials.org",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://1fanserials.org/movies/" .. args.id .. "?key=" .. args.id1,
    ["Connection"] = "keep-alive",
    ["Cookie"] = "__ddg8_=vWS2jN5TY7k1hQmR; __ddg10_=1785251259; __ddg9_=185.228.133.239; __ddg1_=yKoRO1EMPs6rMsq5RYxZ; PHPSESSID=1a21b2ffc6e416654a5282bb064269d3; _ym_uid=1785251045348708012; _ym_d=1785251045; _ym_isad=2; _ym_visorc=b; adrfpip=nAbe16msPTPn; _ohmybid_cmf=2; domain_sid=APwDrHvXKAJ6iYZlPJ69p%3A1785251239326; _sltm=8d703f70f587d25c492c5c2b66042230~0; _sltb=0; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}

 local x = http.getz('https://1fanserials.org/film.php?kp=' .. args.id ..'&key=' .. args.id1, headers1) 
 
 
 
 if x then
 
 for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'list'

table.insert(t, {title = '(1080p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
 
   for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '720.mp4:hls:manifest')

   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
 
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '480.mp4:hls:manifest')

   
 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
 
 
 for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '360.mp4:hls:manifest')

   
 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '240.mp4:hls:manifest')


   
   
 t['view'] = 'list'

table.insert(t, {title = '(240p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
end 
-- end

 


--https://gokino.su/vv-player.php?path=/&movie_id=14981


 elseif args.q == 'veo' then

--https://aprelteam.gokino.by/vv-player.php?path=/&movie_id=14981

local url = 'https://api.rstprgapipt.com/balancer-api/iframe?kp=' .. args.id3 .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI'



local headers = {
    ["Host"] = "api.rstprgapipt.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

  --  local x = http.getz(url, headers)
 
  local x = conn:load(url)
 
  
 
   local id = string.match(x,'MOVIE_ID=(%d+)%;')
 

 
local url1 = 'https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI'


--table.insert(t, {title = 'https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI', mrl = 'https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI'})


--table.insert(t, {title = url1, mrl = url1})

  local x = http.get(url1)


 local slist = string.match(x, '"order":0.-"season".-"order":0(.-)}]}]')
 
 if slist then
 
 for url2, title in string.gmatch(slist, '"filepath":"(http.-)".-"title":"(.-)"') do
 
 
 t['view'] = 'list'

   table.insert(t, {title = '(1080p) ' .. title, mrl = url2, image = '#self/movie.png'})
end
end


 for total, total1, url2, title in string.gmatch(x, '"order":(.-),"season":.-"order":(.-)}.-"filepath":"(http.-)".-"title":"(.-)"') do
 


local text = total1 .. ' ' .. 'сезон ' .. total .. ' серия ' .. title


text = string.gsub(text, '0 сезон 0 серия', '')

 t['view'] = 'list'
 
 table.insert(t, {title = text, mrl = url2, image = '#self/movie.png'})
 

end
 
 
-- https://storage.videoseedcdn.com/movies/aec50961c21ef09d0040260875ff6627d9728a49/bfd76f0b07fdcc385574bcc1bbc18767:2026011806/1080.mp4:hls:manifest.m3u8
 
 
-- https://iqslgbok.deploy.cx/https://kinoserials.tv/videos/32489/32489/
 
-- https://kinoserials.tv/videos?id=32489
-- https://kinoserials.tv/videos/1042459/get/
 
 --https://api.videoseed.tv/embed/32489/?token=6091e1d0bf421f73804d2f0dcc2bf1cf
 
 --https://apn-latest.onrender.com/https://videoseed.tv/videos/32489/chujoy/
 
 
 elseif args.q == 'videoseed2' then
 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
   for url in string.gmatch(x, 'status.-"iframe":"http.-(/embed.-)"') do




local url = 'https://kinoserials.tv' .. url
   
   local headers = {
    ["Host"] = "kinoserials.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 
--https://kinoserials.tv/videos/36512/zatashchi-menya-v-ad/

   
 local x = http.getz(url, headers)
 
 local slist = string.match(x, 'var player = new Playerjs%((.-)%)') 
 
 --url = url_for(slist)
 --url = urldecode(url)
 
-- table.insert(t, {title = url, mrl = url})
 
 local slist1 = string.match(slist, '#2(.-)\"+') 
 
 if slist1 then




 
 slist1 = string.gsub(slist1, '|||', '')
 
 slist1 = string.gsub(slist1, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 slist1 = string.gsub(slist1, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 slist1 = string.gsub(slist1, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
slist1 = string.gsub(slist1, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

slist1 = string.gsub(slist1, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 
 
 
 slist1 = string.gsub(slist1, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 slist1 = string.gsub(slist1, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 slist1 = string.gsub(slist1, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
slist1 = string.gsub(slist1, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

slist1 = string.gsub(slist1, 'N3IzYXcyRWF0MD', '')

slist1 = string.gsub(slist1, 'NBaUNHQTI2ME9CcWc', '')
 
slist1 = string.gsub(slist1, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    


slist1 = http.urldecode(base64_decode(slist1))


slist1 = string.gsub(slist1, ';{', '"{')



for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   

   
 t['view'] = 'list'


table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})
end

for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   

   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

   
 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   

   
 t['view'] = 'list'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end
 end
end
 
 

 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
-- table.insert(t, {title = 'https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3, mrl = x, image = '#self/movie.png'})
 



	
--x = string.gsub(x, 'tv%-1%-', '')

--x = string.gsub(x, '%- %d сезон"', '')


--local video = string.match(x,'"videos"(.-)}}}]')
 
     for title, id in string.gmatch(x, ':{("name":".-").-"iframe":"http.-(/embed.-)"') do
     
 id = string.gsub(id, '\\', '')
 
 title = string.gsub(title, '^(.-)', '{') .. '}'

local m = json.decode(title)

local title = m['name']

local title = string.match(title,'(.-серия)')

if title then

local title, title1 = string.match(title,'.-%- (.-сезон %-)(.-серия)')

 --for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"http.-(/embed.-)"') do
 

   
   t['view'] = 'list'
  
 -- table.insert(t, {title = tolazy(title), mrl = '#stream/q=videoseeds2&id=' .. id, image = '#self/movie.png'})
  
  
   table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds2&id=' .. id, image = '#self/movie.png'})
 
 end
end


elseif args.q == 'videoseeds2' then

local url = 'https://kinoserials.tv' .. args.id



local headers = {
    ["Host"] = "kinoserials.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}


local x = http.getz(url, headers)



local x = string.match(x, '#2(.-)\"+')
 
 if x then
 
 x = string.gsub(x, '|||', '')
 
 
x = string.gsub(x, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 x = string.gsub(x, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 x = string.gsub(x, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
x = string.gsub(x, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

x = string.gsub(x, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    x =http.urldecode(base64_decode(x))


x = string.gsub(x, ';{', '"{')

--local slist = string.match(x, '"file":"(.-)"')
--if x then
 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'list'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
  -- url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
   
 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
 --  url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'list'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end
 end







 
 elseif args.q == 'videoseed' then

local url = 'https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3


  local headers = {
    ["Host"] = "api.videoseed.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

      local x = http.get(url, headers)
 

 
    for url in string.gmatch(x, 'status.-"iframe":"(http.-)"') do

  url = string.gsub(url, '\\', '')

--tv-3-kinolot.net

local headersS = {

    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["Cookie"] = "PHPSESSID=0f872a7617175500ab7b29ec4dbba1b4;kt_rt_token=6091e1d0bf421f73804d2f0dcc2bf1cf;kt_ips=159.69.148.100",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache",
["Vary"] = "Accept-Encoding",
["Content-Encoding"] = "gzip"
}

   local headers1 = {
    ["Host"] = "tv-1-kinoserial.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://tv-1-kinoserial.net/",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "PHPSESSID=7b7624424d89b8f1b62693cd364c0080; path=/; domain=.tv-1-kinoserial.net; SameSite=Lax; kt_rt_token=6091e1d0bf421f73804d2f0dcc2bf1cf; Max-Age=31104000; path=/; domain=.tv-1-kinoserial.net; SameSite=Lax",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}
  
     local x = http.getz(url, headers1)
 

   
    local slist = string.match(x,'#2(.-)%)') 
 
 
 --local slist = string.match(x, '#2(.-)\"+') 
 
 if slist then
 
 
 slist = string.gsub(slist, '|||', '')
 
 
slist = string.gsub(slist, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 slist = string.gsub(slist, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 slist = string.gsub(slist, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
slist = string.gsub(slist, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

slist = string.gsub(slist, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 
 
 slist = string.gsub(slist, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 slist = string.gsub(slist, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 slist = string.gsub(slist, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
slist = string.gsub(slist, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

slist = string.gsub(slist, 'N3IzYXcyRWF0MD', '')

slist = string.gsub(slist, 'NBaUNHQTI2ME9CcWc', '')
 
slist = string.gsub(slist, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')


    slist = base64_decode(slist)

slist = string.gsub(slist, ';{', '"{')

--table.insert(t, {title = x, mrl = x})


--local slist = string.match(x, '"file":"(.-)"') 
 

   for total, url1 in string.gmatch(slist,'"{(.-)}.-(http.-m3u8)') do
  
  
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

end
end


local url = 'https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3



    local headers = {
    ["Host"] = "api.videoseed.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

      local x = http.get(url, headers)
 

 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')
	
	
--x = string.gsub(x, 'tv%-1%-', '')

x = string.gsub(x, '%- %d сезон"', '')


--https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=1384617

 for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"(http.-)"') do
 

   
   t['view'] = 'list'
   
 table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds&id=' .. id, image = '#self/movie.png'})
 
 end
 
 elseif args.q == 'videoseeds' then

local headersss = {
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}


local headers = {
    ["Host"] = "tv-1-kinoserial.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://tv-1-kinoserial.net/",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "PHPSESSID=7b7624424d89b8f1b62693cd364c0080; path=/; domain=.tv-1-kinoserial.net; SameSite=Lax; kt_rt_token=6091e1d0bf421f73804d2f0dcc2bf1cf; Max-Age=31104000; path=/; domain=.tv-1-kinoserial.net; SameSite=Lax",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}

 local x = http.getz(args.id, headers)


 
    local x = string.match(x, '#2(.-)\"+') 
 
 if x then
 
 
 
 x = string.gsub(x, '|||', '')
 
 
x = string.gsub(x, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 x = string.gsub(x, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 x = string.gsub(x, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
x = string.gsub(x, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

x = string.gsub(x, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

--http.urlencode(
    x =http.urldecode(base64_decode(x))

x = string.gsub(x, ';{', '"{')

  -- local slist = string.match(x, '"file":"(.-)"')

--table.insert(t, {title = slist, mrl = x})
 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
  
  
  
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'list'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   

   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

   
 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
 t['view'] = 'list'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end
end
 
 
 
 --https://movie.kinodostuptut.com/search?filters={"yearRange":[1979]}&q=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%2C
 
 elseif args.q == 'rapidcdn' then
  
  
   local x = conn:load('https://movie.kinodostuptut.com/search?filters={"yearRange":[' .. args.id2 .. ']}&q=' .. urlencode(args.id1))
 
  t['view'] = 'simple'

      
      for url, image, title, total in string.gmatch(x, '<a class="group relative block.-href="(.-)".-<img.-src="(.-)".-<span class="text%-sm.->(.-)</span>.-class="text%-xs.->(.-)</span>') do
      
    url = string.gsub(url, '^(.-)', 'https://movie.kinodostuptut.com')
    
    table.insert(t, {title = tolazy(title) .. ',' .. total, mrl = '#stream/q=rapidcdns&id=' .. url, image = image})

     end 
 
 

      elseif args.q == 'rapidcdns' then
    
   -- Хищник: Планета смерти | сезон 0 | эпизод 0 в хорошем качестве без регистрации, смс и vpn\
    
      local x = conn:load(args.id)

      for url, title in string.gmatch(x, '"m3u8MasterFilePath.-"(http.-)\\".-{.-"title.-":.-"Смотреть сериал (.-)в хорошем') do
     
     
     title = string.gsub(title, '| сезон 0 | эпизод 0', '')
     
     t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = url})

     end 




elseif args.q == 'kinoc' then

local url = 'https://api.cyxym.net/kino/v2?search'



local headers = {
    ["Host"] = "api.cyxym.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "multipart/form-data; boundary=----geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841",
    ["Referer"] = "https://kino.cyxym.net/",
    ["Origin"] = "https://kino.cyxym.net",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-site",
    ["Connection"] = "keep-alive",
    ["Priority"] = "u=4"}


local films = '549755813888'

local payloads = [[------geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841
Content-Disposition: form-data; name="query"

рокки
------geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841--]]




local multipart_data = [[------geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841
Content-Disposition: form-data; name="query"

]] .. args.id1 .. [[

------geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841
Content-Disposition: form-data; name="year"

]] .. args.id2 .. [[

------geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841-- ]]



local x = http.postz(url, headers, multipart_data)



local rele = string.match(x, '{"releases":%[(.-)]')



for id, title, poster, num in string.gmatch(rele, '{"id":(.-),"name":"(.-)","rating_kp":".-","poster":"(.-)","last_season":(null)}') do


poster = string.gsub(poster, '\\', '')


t['view'] = 'list'

if num then

--table.insert(t, {title = title, mrl = '#stream/q=kinocf&id=' .. id .. '&id1=' .. title .. '&id2=' .. poster, image = poster})

local api = 'https://api.cyxym.net/kino/v2?release'

local payload = [[------geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841
Content-Disposition: form-data; name="id"

   ]] .. id .. [[

------geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841--]]



local x = http.postz(api, headers, payload)

if x then

t['view'] = 'list'

local year, idf = string.match(x, '{"id":.-,.-"year":(.-),.-"is_serial":false,.-"hd":(.-),')

if idf then

table.insert(t, {title = '1080p ' .. title .. ' (' .. year .. ')', mrl = '#stream/q=kinocfi&id=' .. idf, image = poster})

end


local year, idu = string.match(x, '{"id":.-,.-"year":(.-),.-"is_serial":false,.-"uhd":(.-),')

if idu then

table.insert(t, {title = '2160p ' .. title .. ' (' .. year .. ')', mrl = '#stream/q=kinocfi&id1=' .. idu, image = poster})

end
end

end
end







for id, title, poster, season in string.gmatch(rele, '{"id":(.-),"name":"(.-)","rating_kp":".-","poster":"(.-)","last_season":"(.-)"') do

if season then

poster = string.gsub(poster, '\\', '')


t['view'] = 'list'


--table.insert(t, {title = title .. ' ' .. season, mrl = '#stream/q=kinocs&id=' .. id, image = poster})


local api = 'https://api.cyxym.net/kino/v2?release'

local payload = [[------geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841
Content-Disposition: form-data; name="id"

   ]] .. id .. [[

------geckoformboundary9aeb66aefd47c7c5fe92a4dfee62841--]]



local x = http.postz(api, headers, payload)

if x then

t['view'] = 'list'


local season = string.match(x, '"is_serial":true.-"series":{(.-)"universe"')

if season then

--season = string.gsub(season, '\\u044f.', '\\u044f')


for seasonum, serial in string.gmatch(season, '"(%d+)":{"%d+":{(.-)}}') do


--seasonum = string.gsub(seasonum, '^(.-)', 'Сезон ') ..

for name, ids, poster in string.gmatch(serial, '"name":"(.-)",.-id":(.-),.-preview":"(.-)"') do

if ids then

poster = string.gsub(poster, '\\', '')

title = string.gsub(name, '^(.-)', '{"name":"') .. '"}'

local v = json.decode(title)

local title = v['name']


t['view'] = 'list'


table.insert(t, {title = seasonum .. ' Сезон ' .. title, mrl = '#stream/q=kinocser&id=' .. ids, image = poster})

end
end
end
end
end

end
end







 elseif args.q == 'kinocfi' then



local api = 'https://api.cyxym.net/kino/v2?player'



local headers = {
    ["Host"] = "api.cyxym.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "multipart/form-data; boundary=----geckoformboundary7e5d7ac5fc3e2851dbdbab3b66fd3411",
    ["Referer"] = "https://kino.cyxym.net/",
    ["Origin"] = "https://kino.cyxym.net",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-site",
    ["Connection"] = "keep-alive",
    ["Priority"] = "u=0"}

if args.id then

local payload = [[------geckoformboundary7e5d7ac5fc3e2851dbdbab3b66fd3411
Content-Disposition: form-data; name="id"

   ]] .. args.id .. [[


------geckoformboundary7e5d7ac5fc3e2851dbdbab3b66fd3411--]]

  
  
  local v = http.postz(api, headers, payload)
 
 if v then
 
  v = string.gsub(v, '\\', '') 
  
 local url = string.match(v, '"link":"http.-://.-(/.-m3u8)')
 
 url = string.gsub(url, '^(.-)', 'https://24tv-edge.cyxym.net:8443') 
 
 t['view'] = 'list'
 t = {}
table.insert(t, {mrl = url, image = '#self/movie.png'})

end
end

if args.id1 then

local payload1 = [[------geckoformboundary7e5d7ac5fc3e2851dbdbab3b66fd3411
Content-Disposition: form-data; name="id"

   ]] .. args.id1 .. [[


------geckoformboundary7e5d7ac5fc3e2851dbdbab3b66fd3411--]]

  
  
  local b = http.postz(api, headers, payload1)
 
 if b then
 
  b = string.gsub(b, '\\', '') 
  
 local url1 = string.match(b, '"link":"http.-://.-(/.-m3u8)')
 
 if url1 then
 
 url1 = string.gsub(url1, '^(.-)', 'https://24tv-edge.cyxym.net:8443') 
 
t['view'] = 'list'
 
 
 t = {}
table.insert(t, {mrl = url1, image = '#self/movie.png'})

end
end
end




elseif args.q == 'kinocser' then

local headers = {
    ["Host"] = "api.cyxym.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "multipart/form-data; boundary=----geckoformboundary7e5d7ac5fc3e2851dbdbab3b66fd3411",
    ["Referer"] = "https://kino.cyxym.net/",
    ["Origin"] = "https://kino.cyxym.net",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-site",
    ["Connection"] = "keep-alive",
    ["Priority"] = "u=0"}
    
local api = 'https://api.cyxym.net/kino/v2?player'

local payload = [[------geckoformboundary7e5d7ac5fc3e2851dbdbab3b66fd3411
Content-Disposition: form-data; name="id"

   ]] .. args.id .. [[


------geckoformboundary7e5d7ac5fc3e2851dbdbab3b66fd3411--]]

  
  
  local v = http.postz(api, headers, payload)
 
 if v then

v = string.gsub(v, '\\', '') 
  
 local url = string.match(v, '"link":"http.-://.-(/.-m3u8)')
 
 url = string.gsub(url, '^(.-)', 'https://24tv-edge.cyxym.net:8443') 
 
 
 t = {}
table.insert(t, {mrl = url, image = logo})

end




elseif args.q == '24kino' then


local headers = {
["Host"] = "api-web-systema.platform24.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
["Accept"] = "application/json, text/plain, */*",
["Accept-Language"] = "ru-ru",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-Type"] = "application/json",
["Content-Length"] = "52",
["Origin"] = "https://tv.cyxym.net",
["Connection"] = "keep-alive",
["Referer"] = "https://tv.cyxym.net/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site"
}

local params = '{"device_id":"c99fe352-7718-4879-b92a-c6e3f61c9ccd"}'


   local url = 'https://api-web-systema.platform24.tv/v2/auth/device'

        local x = http.postz(url, headers, params)

      local token = string.match(x, '"access_token":"(.-)"')

	if token then

local url = 'https://api-web-systema.platform24.tv/v2/rows/1154861723594598690?access_token=' .. token .. '&channels_version=2&format=json&limit=15&offset=0&text=' .. urlencode(args.id1 .. ' ' .. args.id2)

if url then

 local x = conn:load(url)

--table.insert(t, {title = url, mrl = url, image = image})

--search%-movie.-"contents".-%[

 local movie = string.match(x,'search%-movie.-"contents".-%[(.-)]}')


if movie then

for id, title, year in string.gmatch(movie,'{"id":"(.-)","title":"(.-)".-"content_type":"movie".-"year":"(.-)".-"rowset_id"') do

if year then

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id .. '?access_token=' .. token .. '&format=json')


local id1, libs = string.match(x,'"graphic_title".-"id":"(.-)".-"libraries":%[{"id":(.-)}')

if id1 then

local x = conn:load('https://api-web-systema.platform24.tv/v2/libraries/' .. libs .. '/contents/' .. id1 .. '/stream?access_token=' .. token .. '&channels_version=2&format=json&ts=0&type=hls')


local play = string.match(x,'"hls":"(.-)"')   
  if play then

t['view'] = 'list'

table.insert(t, {title = 'Фильм - ' .. title .. ' (' .. year .. ')', mrl = play, image = '#self/movie.png'})

end
end
end
end
end
end



local url1 = 'https://api-web-systema.platform24.tv/v2/rows/1154861723663302975?offset=0&limit=15&channels_version=2&format=json&access_token=' .. token .. '&text=' .. urlencode(args.id1 .. ' ' .. args.id2)

if url1 then

--table.insert(t, {title = url1, mrl = url1, image = image})

local x = conn:load(url1)

--table.insert(t, {title = url1, mrl = url1, image = image})

local series = string.match(x,'search%-series.-"contents".-%[(.-)]}')


if series then

for id, title, year in string.gmatch(series,'{"id":"(.-)","title":"(.-)".-"content_type":"series".-"year":"(.-)".-"rowset_id"') do

--local id, title, year = string.match(x,'"contents".-%[{"id":"(.-)".-"title":"(.-)".-"year":"(.-)"')

if id then


t['view'] = 'list'

table.insert(t, {title = 'Сериал - ' .. title .. ' (' .. year .. ')', mrl = '#stream/q=24kinos&id=' .. id .. '&id1=' .. token, image = '#self/movie.png'})

end
end
end
end
end

elseif args.q == '24kinos' then


local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. args.id .. '?access_token=' .. args.id1 .. '&format=json')



local seasons = string.match(x,'"contents":%[(.-)]')
  
  
  for id1, season in string.gmatch(seasons,'{"id":"(.-)".-"title":"(.-)"') do

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id1 .. '?access_token=' .. args.id1 .. '&format=json')

local episodes = string.match(x,'"contents":%[(.-)]')
  
  
  for id2, series in string.gmatch(episodes,'{"id":"(.-)".-"content_type".-"series":(.-),') do

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id2 .. '?access_token=' .. args.id1 .. '&format=json')

  local id3, libs = string.match(x,'"graphic_title".-"id":"(.-)".-"libraries":%[{"id":(.-)}')

local x = conn:load('https://api-web-systema.platform24.tv/v2/libraries/' .. libs .. '/contents/' .. id3 .. '/stream?access_token=' .. args.id1 .. '&channels_version=2&format=json&ts=0&type=hls')


local play = string.match(x,'"hls":"(.-)"')   
  if play then

t['view'] = 'list'

table.insert(t, {title = season .. ' серия ' .. series, mrl = play, image = '#self/movie.png'})


end
end
end
--end
--end

--end






elseif args.q == 'mirkino' then


local url = 'https://ru.mir-kino.pp.ru/Items?userId=75280f7de0a64771b9dd63c4b23b814d&isMissing=false&limit=800&recursive=true&searchTerm=' .. urlencode(args.id1) .. '&ProductionYear=' .. args.id2 .. '&fields=PrimaryImageAspectRatio&fields=CanDelete&fields=MediaSourceCount&includeItemTypes=Movie&includeItemTypes=Series&includeItemTypes=Episode&includeItemTypes=Playlist&includeItemTypes=MusicAlbum&includeItemTypes=Audio&includeItemTypes=TvChannel&includeItemTypes=PhotoAlbum&includeItemTypes=Photo&includeItemTypes=AudioBook&includeItemTypes=Book&includeItemTypes=BoxSet&imageTypeLimit=1&enableTotalRecordCount=false'


local headers = {
    ["Host"] = "ru.mir-kino.pp.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    ["Accept"] = "application/json, text/plain, */*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Authorization"] = 'MediaBrowser Client="Jellyfin%20Web", Device="Firefox", DeviceId="TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6MTUyLjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvMTUyLjB8MTc4NDEwMDMxMDg1OQ11", Version="10.11.10", Token="7325db2c854d4d0aadea155da54f2d58"',
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local x = http.getz(url, headers)


local type = string.match(x,'{"Items":.-"Type":"(Movie)"')

if type then

local name, item, year = string.match(x,'"Name":"(.-)".-"Type":"Movie".-"ItemId":"(.-)".-"ProductionYear":(.-),')

if item then

--t['view'] = 'list'


year = string.gsub(year, '}', '')

local x = http.getz('https://ru.mir-kino.pp.ru/Items/' .. item, headers)

for id, qual in string.gmatch(x,'{"Protocol":"File","Id":"(.-)".-"Name":"(%d+p)"') do

t['view'] = 'list'


table.insert(t, {title = qual .. ' ' .. name .. ' (' .. year .. ')', mrl = 'https://ru.mir-kino.pp.ru/Videos/' .. id .. '/stream?api_key=7325db2c854d4d0aadea155da54f2d58&Static=true', image = '#self/movie.png'})

end
end
end



--table.insert(t, {title = name .. ' (' .. year .. ')', mrl = '#stream/q=mirkinof&id=' .. item, image = '#self/movie.png'})

--end
--end



local x = http.getz(url, headers)

local type = string.match(x,'{"Items":.-"Type":"(Playlist)"')

if type then

for name, item in string.gmatch(x,'"Name":"(.-)".-"Type":"Playlist".-"ItemId":"(.-)"') do




local x = http.getz('https://ru.mir-kino.pp.ru/Playlists/' .. item .. '/Items?Fields=PrimaryImageAspectRatio,MediaSourceCount,Chapters,Trickplay&EnableImageTypes=Primary,Backdrop,Banner,Thumb', headers)

local type1 = string.match(x,'{"Items":.-"Type":"(Movie)"')

if type then

for name1, item1, year in string.gmatch(x,'"Name":"(.-)".-"Type":"Movie".-"ItemId":"(.-)".-"ProductionYear":(.-),') do


if item1 then

year = string.gsub(year, '}', '')

t['view'] = 'list'

table.insert(t, {title = name1 .. ' (' .. year .. ')', mrl = '#stream/q=mirkinof&id=' .. item1, image = '#self/movie.png'})

end
end
end
end
end




local x = http.getz(url, headers)

--table.insert(t, {title = x, mrl = '#stream/q=mirkinos&id=' .. x, image = '#self/movie.png'})

local type = string.match(x,'{"Items":.-"Type":"(Series)"')

if type then

for name, id, year in string.gmatch(x,'{"Items".-"Name":"(.-)".-"Id":"(.-)".-"Type":"Series".-"ProductionYear":(.-),') do 

if id then

year = string.gsub(year, '}', '')

t['view'] = 'list'

table.insert(t, {title = name .. ' (' .. year .. ')' .. '-сериал-', mrl = '#stream/q=mirkinos&id=' .. id, image = '#self/movie.png'})

end
end
end





elseif args.q == 'mirkinos' then



local headers = {
    ["Host"] = "ru.mir-kino.pp.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    ["Accept"] = "application/json, text/plain, */*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Authorization"] = 'MediaBrowser Client="Jellyfin%20Web", Device="Firefox", DeviceId="TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6MTUyLjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvMTUyLjB8MTc4NDEwMDMxMDg1OQ11", Version="10.11.10", Token="7325db2c854d4d0aadea155da54f2d58"',
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local x = http.getz('https://ru.mir-kino.pp.ru/Shows/' .. args.id .. '/Seasons?userId=75280f7de0a64771b9dd63c4b23b814d&Fields=ItemCounts,PrimaryImageAspectRatio,CanDelete,MediaSourceCount', headers)



for name, id1, season in string.gmatch(x,'"Name":"(Сезон.-)".-"Id":"(.-)".-"SeriesId":"(.-)"') do

if season then

local x = http.getz('https://ru.mir-kino.pp.ru/Shows/' .. season .. '/Episodes?seasonId=' .. id1 .. '&userId=75280f7de0a64771b9dd63c4b23b814d&Fields=ItemCounts,PrimaryImageAspectRatio,CanDelete,MediaSourceCount,Overview', headers)



for nameser, id2 in string.gmatch(x,'"Name":"(.-)".-"Id":"(.-)"') do


local x = http.getz('https://ru.mir-kino.pp.ru/Items/' .. id2 .. '?userId=75280f7de0a64771b9dd63c4b23b814d', headers)


local episode, item = string.match(x,'{"Name":".-".-/episode/(.-)".-"ItemId":"(.-)"')

t['view'] = 'list'



table.insert(t, {title = name .. ' ' .. 'серия ' .. episode .. ' ' .. nameser, mrl = 'https://ru.mir-kino.pp.ru/Videos/' .. item .. '/stream?api_key=7325db2c854d4d0aadea155da54f2d58&Static=true', image = '#self/movie.png'})

end
end
end






elseif args.q == 'mirkinof' then



local headers = {
    ["Host"] = "ru.mir-kino.pp.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    ["Accept"] = "application/json, text/plain, */*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Authorization"] = 'MediaBrowser Client="Jellyfin%20Web", Device="Firefox", DeviceId="TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6MTUyLjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvMTUyLjB8MTc4NDEwMDMxMDg1OQ11", Version="10.11.10", Token="7325db2c854d4d0aadea155da54f2d58"',
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}


  local x = http.getz('https://ru.mir-kino.pp.ru/Items/' .. args.id, headers)



for id, qual in string.gmatch(x,'{"Protocol":"File","Id":"(.-)".-"Name":"(%d+p)"') do

--local id, qual = string.match(x,'{"Protocol":"File","Id":"(.-)".-"Name":"(2160p)"')

if id then

t['view'] = 'list'


table.insert(t, {title = qual, mrl = 'https://ru.mir-kino.pp.ru/Videos/' .. id .. '/stream?api_key=7325db2c854d4d0aadea155da54f2d58&Static=true', image = '#self/movie.png'})



end
end



 





elseif args.q == 'zerohd' then


local headers = {
["Host"] = "f.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["Origin"] = "http://f.xsmart.tv",
["Connection"] = "keep-alive",
["Priority"] = "u=0"
}

local url = 'http://f.xsmart.tv/api/'

local params = 'key=&type=gold&status=user&mac=xsm11773664f&serial=sn7a8f1f5cf44'



local x = http.postz(url, headers, params)

if x then

local key, status = string.match(x,'"key_hash":"(.-)","key_check":"(.-)"')



local kp = args.id3

if kp then


local url = 'http://f.xsmart.tv/api/parser/'


local params = 'key=' .. key .. '&adult=0&use_cdn=0&url=%3Fmode%3Dxkino%26cat%3D6%26id_film%3D' .. kp .. '&mac=xsm11773664f&platform=BROWSER'


local x = http.postz(url, headers, params)

if x then

t['view'] = 'list'


local sources = string.match(x,'sources.-%[(.-)]')

if sources then


for id, names in string.gmatch(sources,'{"id":"(.-)",("name":".-")') do

names = string.gsub(names, '^(.-)', '{') .. '}'

local k = json.decode(names)
local names = k['name']




local url2 = 'http://f.xsmart.tv/api/parser/'


local headerss = {
["Host"] = "f.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["X-Requested-With"] = "XMLHttpRequest",
["Cookie"] = "XSMART3_mac=xsm11773664f; XSMART3_serial=sn7a8f1f5cf44",
["Origin"] = "http://f.xsmart.tv",
["Connection"] = "keep-alive",
["Priority"] = "u=0"
}


local params2 = 'key=' .. key .. '&key_status=' .. status .. '&adult=0&use_cdn=0&url=%3Fmode%3Dxkino%26cat%3D6%26id_film%3D' .. kp .. '%26source%3D' .. id .. '&mac=xsm11773664f&platform=BROWSER'




local x = http.postz(url2, headerss, params2)

if x then


	t['view'] = 'list'


for url in string.gmatch(x,'{".-":.-"url".-"urls":%["(.-)"') do

if url then

url = string.gsub(url, '\\', '')


table.insert(t, {title = names, mrl = url, image = '#self/movie.png'})

end
end

for title, video in string.gmatch(x,'{("title":".-").-"url":%[(.-)]') do



title = string.gsub(title, '^(.-)', '{') .. '}'

local c = json.decode(title)

for name, url in string.gmatch(video,'("name":".-"),"url":"(.-)"') do

url = string.gsub(url, '\\', '')

--url = string.gsub(url, '^(.-)', 'https://zayb.ru')

name = string.gsub(name, '^(.-)', '{') .. '}'

local b = json.decode(name)

local name = b['name']

name = string.gsub(name, 'Низкое', '360p')
name = string.gsub(name, 'Нормальное', '480p')
name = string.gsub(name, 'Высокое', '720p')
name = string.gsub(name, 'Максимальное', '1080p')




table.insert(t, {title = c['title'], mrl = url, image = '#self/movie.png'})

--url = string.gsub(url, '360.mp4', '360.mp4')

--table.insert(t, {title = '360p' .. ' ' .. c['title'], mrl = url, image = '#self/movie.png'})

--url2 = string.gsub(url, '360.mp4', '480.mp4')

--table.insert(t, {title = '480p' .. ' ' .. c['title'], mrl = url2, image = '#self/movie.png'})


--url3 = string.gsub(url, '360.mp4', '720.mp4')

--table.insert(t, {title = '720p' .. ' ' .. c['title'], mrl = url3, image = '#self/movie.png'})

--url4 = string.gsub(url, '360.mp4', '1080.mp4')

--table.insert(t, {title = '1080p' .. ' ' .. c['title'], mrl = url4, image = '#self/movie.png'})


end
end


for title, video in string.gmatch(x,'{("title":".-"),"stream":%[(.-)}]}') do



title = string.gsub(title, '^(.-)', '{') .. '}'

local c = json.decode(title)

local title = c['title']

for total, url in string.gmatch(video,'("name":".-"),"urls":.-"(.-)"') do

url = string.gsub(url, '\\', '')


total = string.gsub(total, '^(.-)', '{') .. '}'

local b = json.decode(total)

local total = b['name']

--table.insert(t, {title = url, mrl = url, image = '#self/movie.png'})


table.insert(t, {title = title .. ' ' .. total, mrl = url, image = '#self/movie.png'})

end
end

end
end
end
end
end


-- elseif args.q == 'zerocdns' then
 
 
 local headers = {
["Host"] = "f.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["Origin"] = "http://f.xsmart.tv",
["Connection"] = "keep-alive",
["Priority"] = "u=0"
}

local url = 'http://f.xsmart.tv/api/'

local params = 'key=&type=gold&status=user&mac=xsm11773664f&serial=sn7a8f1f5cf44'


local x = http.postz(url, headers, params)

if x then

local key, status = string.match(x,'"key_hash":"(.-)","key_check":"(.-)"')

 local url1 = 'http://f.xsmart.tv/api/parser/'

local headerss = {
["Host"] = "f.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["X-Requested-With"] = "XMLHttpRequest",
["Cookie"] = "XSMART3_mac=xsm11773664f; XSMART3_serial=sn7a8f1f5cf44",
["Origin"] = "http://f.xsmart.tv",
["Connection"] = "keep-alive",
["Priority"] = "u=0"
}

local params1 = 'key=' .. key .. '&key_status=' .. status .. '&adult=0&use_cdn=0&url=%3Fmode%3Dxkino%26id_film%3D' .. args.id3 .. '%26cat%3D3%26source%3D10&mac=xsm11773664f&platform=BROWSER'
 
 
 local x = http.postz(url1, headerss, params1)

if x then



local x = json.decode(x)

for _, v in ipairs(x) do

--for seasons, id in string.gmatch(x,'"title":"(.-)".-"url":"(.-)"') do

local id = v['url']
 local season = v['title'] 

local params2 = 'key=' .. key .. '&key_status=' .. status .. '&adult=0&use_cdn=0&url=' .. urlencode(id) .. '&mac=xsm11773664f&platform=BROWSER'

 local x = http.postz(url1, headers, params2)

if x then



x = urldecode(x)

local x = json.decode(x)

for _, v in ipairs(x) do

--for episodes, id1 in string.gmatch(x,'{"title":"(.-)","url":"(.-)"') do


local id1 = v['url']
local episode = v['title'] 
 
 table.insert(t, {title = season .. ' ' .. episode, mrl = '#stream/q=zerocdnsv&id=' .. urlencode(id1), image = '#self/movie.png'})
 
 
  end
 end
 end
end
 end
 end
 
 
 elseif args.q == 'zerocdnsv' then
 
 
  
 local headers = {
["Host"] = "f.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["Origin"] = "http://f.xsmart.tv",
["Connection"] = "keep-alive",
["Priority"] = "u=0"
}


local url = 'http://f.xsmart.tv/api/'

local params = 'key=&type=gold&status=user&mac=xsm11773664f&serial=sn7a8f1f5cf44'


local x = http.postz(url, headers, params)

if x then

local key, status = string.match(x,'"key_hash":"(.-)","key_check":"(.-)"')

 
 local url1 = 'http://f.xsmart.tv/api/parser/'
 
local headerss = {
["Host"] = "f.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["X-Requested-With"] = "XMLHttpRequest",
["Cookie"] = "XSMART3_mac=xsm11773664f; XSMART3_serial=sn7a8f1f5cf44",
["Origin"] = "http://f.xsmart.tv",
["Connection"] = "keep-alive",
["Priority"] = "u=0"
}
 
 
 
 local params3 = 'key=' .. key .. '&key_status=' .. status .. '&adult=0&use_cdn=0&url=' .. urlencode(args.id) .. '&mac=xsm11773664f&platform=BROWSER'
 
 
 
 local x = http.postz(url1, headerss, params3)

if x then


 
 local x = json.decode(x)

for _, v in ipairs(x) do

 local id2 = v['url']
 local voice = v['title'] 
 
 id2 = urldecode(id2)


local url = 'http://f.xsmart.tv/api/'


 
 local params1 = 'key=' .. key .. '&type=video&key_status=' .. status .. '&adult=0&use_cdn=0&url=' .. urlencode(id2) .. '&mac=xsm11773664f&gold=Free&platform=BROWSER'
 
 
  local x = http.postz(url, headers, params1)
	
	t['view'] = 'list'
	
 local x = json.decode(x)

for _, v in ipairs(x) do

local name = v['name']
name = string.gsub(name, 'Низкое', '360p')
name = string.gsub(name, 'Нормальное', '480p')
name = string.gsub(name, 'Высокое', '720p')
name = string.gsub(name, 'Максимальное', '1080p')
  
  
  
table.insert(t, {title = voice, mrl = v['url'], image = '#self/movie.png'})
 
 end
 
end 
 
 end
 end

 
 
    elseif args.q == 'xkino' then
  
 -- https://ru.kinozona.net/poisk.php
--form=do=search&subaction=search&story=чужой
  
 -- local url = 'https://ru.kinozona.net/poisk.php?form=do%3Dsearch%26subaction%3Dsearch%26story%3D' .. urlencode(args.id1)
  
  local url = 'https://videomob.su/poisk.php'
  
--local url = 'https://ru.kinozona.net/poisk.php'
  
  local headers = {
    ["Host"] = "videomob.su",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Content-Length"] = "",
    ["Origin"] = "https://videomob.su",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://videomob.su/",
    ["Cookie"] = "PHPSESSID=kt614shanjhqpcb4qgqfuv7t0l; _ym_uid=1778172366407960634; _ym_d=1778172366; _ym_isad=2; vid=YOax6UDdZMBIbGlG; domain_sid=FP3g3yrURwKO2N-PHJz5S%3A1778172907526; adrdel=1778172387500; adrdel=1778172387500; adrcid=A61RKDqR0L5sDSPiVXIiXNg; adrcid=A61RKDqR0L5sDSPiVXIiXNg; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; ecf7d0dc55_delayCount=10; ecf7d0dc55_blockTimer=1; u_ecf7d0dc55=1; _ohmybid_cmf=2; adtech_uid=7956247a-a163-46a4-943d-af979def0958%3Akinozona.net; top100_id=t1.7627570.775262879.1778172521116; t3_sid_7627570=s1.389385681.1778172521120.1778172911440.1.20.8.1..",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

  local form = 'form=do%3Dsearch%26subaction%3Dsearch%26story%3D' .. urlencode(args.id1)
  
      local x = http.postz(url, headers, form)
      
  
for urls, title in string.gmatch(x,'<a href="(.-)">(.-)<span') do
 
 urls = string.gsub(urls, '^(.-)', 'https://videomob.su')
 
  t['view'] = 'list'
  
  
   table.insert(t, {title = title, mrl = '#stream/q=xkinos&id=' .. urls, image = '#self/movie.png'})

   end  
  
  
  elseif args.q == 'xkinos' then
    
    
      local x = conn:load(args.id)
  
    
  local id = string.match(x,'<div class="trailer".-torLoad%(\'(.-)\'')
  
  local se = string.match(x,'function torLoad%(id.-se = (.-)%)')
 
 
 
 
  local tor = string.match(x,'function torLoad.-load.-(tor.-php)')
   
   local poster = string.match(x,'function torLoad.-load.-tor.-php.-poster:"(.-)"')
   
  --  load("/tor_series.php"
    
  local url = 'https://videomob.su/' .. tor




local headers = {
    ["Host"] = "videomob.su",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Content-Length"] = "",
    ["Origin"] = "https://videomob.su",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://videomob.su/",
    ["Cookie"] = "PHPSESSID=kt614shanjhqpcb4qgqfuv7t0l; _ym_uid=1778172366407960634; _ym_d=1778172366; _ym_isad=2; vid=YOax6UDdZMBIbGlG; domain_sid=FP3g3yrURwKO2N-PHJz5S%3A1778172907526; adrdel=1778172387500; adrdel=1778172387500; adrcid=A61RKDqR0L5sDSPiVXIiXNg; adrcid=A61RKDqR0L5sDSPiVXIiXNg; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; ecf7d0dc55_delayCount=10; ecf7d0dc55_blockTimer=1; u_ecf7d0dc55=1; _ohmybid_cmf=2; adtech_uid=7956247a-a163-46a4-943d-af979def0958%3Akinozona.net; top100_id=t1.7627570.775262879.1778172521116; t3_sid_7627570=s1.389385681.1778172521120.1778172911440.1.20.8.1..",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

  local params = 'id=' .. id .. '&se=' .. se .. '&poster=' .. poster
  
      local x = http.postz(url, headers, params)

--table.insert(t, {title = url, mrl = url, image = image})   


local video = string.match(x,'<video src="(http.-)"')
 
 if video then
 
 print(video)
    return {view = 'playback', mrl = video, seekable = 'true', direct = 'true'}
 
 --table.insert(t, {title = video, mrl = video, image = image})
 
 end
 
   
   for video, title in string.gmatch(x,'(https://s.-)\'>(.-)<') do
   
 --   url = url_for(x)
--url = urldecode(url)
 
 --table.insert(t, {title = url, mrl = url, image = image})   
  
t['view'] = 'list'
  
 -- if video then
--    print(video)
 --   return {view = 'playback', mrl = video, seekable = 'true', direct = 'true'}
--end

  table.insert(t, {title = title, mrl = video, image = '#self/movie.png'})   
  
  end
  
  
 -- http://seasonvar.ru/?mode=search&query
  
  
  elseif args.q == 'seasonvar' then
    
   

    
      local x = conn:load('http://seasonvar.ru/?mode=search&query=' .. urlencode(args.id1))
  
  
 -- local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
     --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'http:')
        
        t['view'] = 'list'
		
			

  
  
  local x = conn:load('http://seasonvar.ru' .. url)
 
 
 local slist = string.match(x, '<ul class="tabs%-result">(.-)</ul>')
      
if slist then

   for url2, total in string.gmatch(slist, '<a href="(.-)".-Сериал (.-)<') do
   
  table.insert(t, {title = tolazy(total), mrl = '#stream/q=seasonvars&id=' .. url2, image = '#self/movie.png'})
		
		end
end
end



   
   elseif args.q == 'seasonvars' then
   
   local x = conn:load('http://seasonvar.ru' .. args.id)
        
        
        
        
        
      --  local x = conn:load(url2)
 
 for id1, total1 in string.gmatch(x,'"(/playls2.-)".-data%-translate%-percent=.->(.-)</li>') do
 
 
    --    for id1 in string.gmatch(x,'player = new Playerjs.-var pl.-"(/playls2.-)"') do
            
    local x = conn:load('http://seasonvar.ru' .. id1)
    

            
      for title1, id2 in string.gmatch(x,'("title":".-)SD.-"file":"#2(.-)"') do
     
   title1 = string.gsub(title1, '^(.-)', '{') .. '"}'

local v = json.decode(title1)

local title1 = v['title']  
            
      
      id2 = string.gsub(id2, '\\/\\/b2xvbG8=', '') 
      
      id2=http.urldecode(base64_decode(id2))
       id2 = string.gsub(id2, '^(.-)', 'http:') 
           t['view'] = 'list'
				table.insert(t,{title=tolazy(title1) .. ' ' .. total1, mrl = id2, image = '#self/movie.png'})
            end  
	end
  
 
  local x = conn:load('http://seasonvar.ru' .. args.id)
        
 
 local id2 = string.match(x,'var pl.-(/playls2.-)"')

            local x = conn:load('http://seasonvar.ru' .. id2)
    
    
            
      for title1, id3 in string.gmatch(x,'("title":".-)SD.-"file":"#2(.-)"') do
            
     title1 = string.gsub(title1, '^(.-)', '{') .. '"}'

local v = json.decode(title1)

local title1 = v['title']  
             
      id3 = string.gsub(id3, '\\/\\/b2xvbG8=', '') 
      
      id3=http.urldecode(base64_decode(id3))
       id3 = string.gsub(id3, '^(.-)', 'http:') 
           t['view'] = 'list'
				table.insert(t,{title=tolazy(title1), mrl = id3, image = '#self/movie.png'})
            end  
  
  
  

  
  
    elseif args.q == 'zetflix' then
    
 --  https://beta.l-vid.online/lite/videodb?kinopoisk_id=386&title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&year=1979&token=a46f8a8a-8878-4fa5-8554-8296ba62260d

--https://beta.l-vid.online/online/js/a46f8a8a-8878-4fa5-8554-8296ba62260d


--https://beta.l-vid.online/online/js/8126ef1f-0a68-4b87-be2b-732e679461cc

--http://31.129.234.181/lite/events?uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv

 --   https://lampa.li/lite/zetflix?kinopoisk_id=386&title=чужой&year=1979&uid=hlltpzjn
    
    local headers = {['X-Requested-With'] = 'XMLHttpRequest'}
    
    
    
      local x = http.get('https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

   
 x = string.gsub(x, '\\u0026', '&')
 

 
   for url, total in string.gmatch(x, 'videos__item videos__movie.-stream.-(http.-)&#.-videos__item%-title.->(.-)<') do
  
-- table.insert(t, {title = url .. '&uid=bwygkgxn', mrl = url .. '&uid=bwygkgxn'})
 
      local x = http.get(url .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
  
  
 --  local slist = string.match(x, 'qualit.-{(.-)}')
   
   for  total1, url2 in string.gmatch(x, '"(.-)".-http.-(/lite.-)"') do
      
    url2 = string.gsub(url2, '^(.-)', 'https://lampa.li')



--http://178.20.46.40:12600/lite/videodb/manifest.m3u8?
      
  --   total1 = string.gsub(total1, ':{"', '') 
      
       t['view'] = 'simple'



    table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
  
 -- http://beta2.l-vid.online:888/lite/zetflix/manifest.m3u8?link=https%3A%2F%2Fcdn-54243ba5.obrut.show%2Fstream%2FAO%2FMHc0RHa%2FQbvNmLuR2YyVGc1RmclBXdz5ie%2F4U3Mt5CdzVmZp5WYtpzcshmO0AXbuADO08SMxYTM0AjNyAjM6MGO5MGOlR2YjJmYwImNyADZjNDM0cTYjVDN1MzN0gDNvUjNmVGOkJmZwYTMzgDNmJDMjRzY1QGN5AjN0gDM1QTOiRDNkdDMjNzLzVWayV2c2R3L
  

   
 -- local x = http.get('https://beta.l-vid.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

table.insert(t, {title = 'https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn', mrl = 'http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn'})
   
 --  x = string.gsub(x, '\\u0026', '&')

   
        for url3, total1  in string.gmatch(x, 'videos__item videos__season.-method.-link.-url.-http.-&s=(.-)&#.-videos__item%-title videos__season%-title.->(.-)<') do


   local x = http.get('https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&s=' .. url3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

table.insert(t, {title = 'https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&s=' .. url3 .. '&uid=bwygkgxn', mrl = 'https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&s=' .. url3 .. '&uid=bwygkgxn'})

    --  local x = http.getz('http://beta.l-vid.online' .. url3 .. '&uid=bwygkgxn')

      for url4, total2  in string.gmatch(x, 'videos__button.-method.-link.-url.-(http.-)&#.->(.-)<') do

url4 = string.gsub(url4, '\\u0026', '&')



     local x = http.getz(url4 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')


x = string.gsub(x, '\\u0026', '&')

      for url5, total3  in string.gmatch(x, 'videos__item videos__movie.-method.-stream.-title.-url.-http.-(/proxy.-m3u8).-videos__item%-title.->(.-серия)<') do

     url5 = string.gsub(url5, '^(.-)', 'https://s.lampa.li')
    

      t['view'] = 'simple'

 
 table.insert(t, {title = url5, mrl = url5})
 
    table.insert(t, {title = total1 .. ' -'  .. total3 .. tolazy(total2), mrl = url5})

   
    end
end
end




--https://beta.l-vid.online/lite/sakhtv?title=чужой&year=1979&uid=bwygkgxn


  
 elseif args.q == 'sakhtv' then
  
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

     local url = 'https://beta.l-vid.online/lite/sakhtv?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
   if x then
  
    
  x = string.gsub(x, '\\u0026', '&')

 
  for url1, total in string.gmatch(x, 'method.-url.-(http.-)&#.-videos__item%-title.->(.-)<') do

--local x = conn:load(url1)


      t['view'] = 'simple'

 --table.insert(t, {title = total, mrl = '#stream/q=paladins&id=' .. })
 
  table.insert(t, {title = total, mrl = url1})

      end 
   
   
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-(http.-)&.-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')

--url3 = string.gsub(url3, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


       local x = conn:load(url3)

    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&.->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')

 -- url4 = string.gsub(url4, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


     local x = conn:load(url4)
    
    x = string.gsub(x, '\\u0026', '&')
    

   for id, id1, total2 in string.gmatch(x, 'method.-stream.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do
 

  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
  

end
end
end
end     
      
 elseif args.q == 'paladinsbbb' then
    
local headers = {
    ["Host"] = "beta2.l-vid.online:888",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cache-Control"] = "no-cache"
}

local x = http.getz('http://beta2.l-vid.online:888/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d', headers)

      local slist = string.match(x, '"quality"(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":"(http.-)"') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
   url6 = string.gsub(url6, '\\u002B', '+')

--  url6 = string.gsub(url6, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = url6})

end
end




elseif args.q == 'getstv' then
  
args.id1 = urldecode(args.id1)


args.id1 = string.gsub(args.id1, ' ', '%%20')


 local url = 'http://getstv.ru/get_content/search.php'



local headers = {
    ["Host"] = "getstv.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
    ["Accept"] = "application/json, text/javascript, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Content-Length"] = "",
    ["Origin"] = "http://getstv.ru",
    ["Connection"] = "keep-alive",
    ["Priority"] = "u=0"
}


local params = 'item_length=0&text=' .. args.id1
   
   local x = http.postz(url, headers, params)
   
   
    x = string.gsub(x, '\\', '')
   
   
   
   
   for id, total, image in string.gmatch(x, '{"gtv_id":"(.-)","title_ru":"(.-)".-"poster":"(http.-)"') do
   
   
  local url1 = 'http://getstv.ru/get_content/page_item.php'

local params1 = 'gtv_id=' .. id .. '&key_device=2ERNBXCN'
   
   local x = http.postz(url1, headers, params1)
   
   x = string.gsub(x, '\\', '')
   

   for id, image, name, year, type, token, tr, seasons in string.gmatch(x, '{"gtv_id":"(.-)".-"poster":"(.-)".-"title_ru":"(.-)".-"year":"(.-)".-"type":"(serial)".-"token":"(.-)".-"tr_id":"(.-)".-"seasons":{(.-)}}}}') do
 
 local seasons = seasons .. '}}}]'
 
 seasons = string.gsub(seasons, '}}}', '}}}]')
 
 
   t['view'] = 'list'
  
  table.insert(t, {title = name .. ' (' .. year .. ') ' .. 'сериал', mrl = '#stream/q=getstvs&id=' .. token .. '&id1=' .. id .. '&id2=' .. tr .. '&id3=' .. type .. '&id4=' .. seasons, image = image}) 
  
  end

 
  for id, image, name, year, type, token, tr in string.gmatch(x, '{"gtv_id":"(.-)".-"poster":"(.-)".-"title_ru":"(.-)".-"year":"(.-)".-"type":"(movie)".-"token":"(.-)".-"tr_id":"(.-)"') do
   
   if type then
   
   
   local video = 'http://getstv.ru/get_content/video_free.php'
   
   local params2 = 'token=' .. token .. '&gtv_id=' .. id .. '&tr_id=' .. tr .. '&type=' .. type .. '&key_device=2ERNBXCN'
   
   local x = http.postz(video, headers, params2)
   
    x = string.gsub(x, '\\', '')
    
    
    t['view'] = 'list'
    
    local zero = string.match(x,'"(http.-)"')
   
 
 table.insert(t, {title = name .. ' (' .. year .. ')', mrl = zero, image = image})

 end
end
end



 
 elseif args.q == 'getstvs' then
  
  local seasons = args.id4
    
   for season, episodes in string.gmatch(seasons, '"s_n":"(.-)".-episodes":{(.-)}}]') do
 

 for episode in string.gmatch(episodes, '"e_n":"(.-)"') do


    local video = 'http://getstv.ru/get_content/video_free.php'
   
   local params = 'token=' .. args.id .. '&gtv_id=' .. args.id1 .. '&tr_id=' .. args.id2 .. '&type=' .. args.id3 .. '&season=' .. season .. '&episode=' .. episode .. '&key_device=2ERNBXCN'
    
   local headers = {
    ["Host"] = "getstv.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
    ["Accept"] = "application/json, text/javascript, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Content-Length"] = "",
    ["Origin"] = "http://getstv.ru",
    ["Connection"] = "keep-alive",
    ["Priority"] = "u=0"
}



   
   local x = http.postz(video, headers, params)
   
   if x then
   
    x = string.gsub(x, '\\', '')
   
    t['view'] = 'list'
    
    local zero = string.match(x,'"(http.-)"')
   
 
 table.insert(t, {title = 'Сезон ' .. season .. ' еризод ' .. episode, mrl = zero, image = '#self/movie.png'})

 end
end
end
--token=free&gtv_id=22309&tr_id=0&type=movie&key_device=2ERNBXCN
    
    
 
elseif args.q == 'mirage' then
    
  
--https://akter-black.com/lite/alloha?id=1304313&imdb_id=tt32612507&kinopoisk_id=6785084&title=%D0%9C%D1%83%D0%BC%D0%B8%D1%8F&original_title=Lee%20Cronin%27s%20The%20Mummy&serial=0&original_language=en&year=2026&source=tmdb&clarification=0&similar=false&rchtype=web&uid=hobqwt4m
  
 -- memkey=m2FtOXt7C35vHdKNklFlpw&
  
     local x = conn:load('https://lam.akter-black.com/lite/spectre?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')



 --  x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"url":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

 local x = conn:load(url .. '&uid=hobqwt4m')
 
 
 
-- local x = conn:load(url)
 
 local slist = string.match(x,'quality.-{(.-)}')
 
 if slist then
 
 for qual, url1 in string.gmatch(slist, '"(%d+p)".-(http.-m3u8)') do
   
 
     t['view'] = 'list'


    table.insert(t, {title = '(' .. qual .. ') ' .. total, mrl = url1, image = '#self/movie.png'})

 end
    end
   end 
 
 
-- local x = conn:load('https://akter-black.com/lite/alloha?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')
 
 
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3 .. '&uid=hobqwt4m')


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4 .. '&uid=hobqwt4m')

--table.insert(t, {title = url4, mrl = url4})

x = string.gsub(x, '\\u0026', '&')

     for id, id1, id2, id3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"url":"http.-?t=(.-)&s=(.-)&e=(.-)&token_movie=(.-)&orid.-class="videos__item%-title">(.-)</div>') do

   
    t['view'] = 'list'



--https://akter-black.com/lite/alloha/video?t=234&s=1&e=2&token_movie=352d33e54cf583160797cae895ff80&orid





table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = '#stream/q=mirages&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2  .. '&id3=' ..  id3, image = '#self/movie.png'})

end
end
end
     
     elseif args.q == 'mirages' then
     
     local x = conn:load('https://lam.akter-black.com/lite/spectre/video?t=' .. args.id .. '&s=' .. args.id1 .. '&e=' .. args.id2 .. '&token_movie=' .. args.id3 .. '&uid=hobqwt4m')
    
    local slist = string.match(x,'quality.-{(.-)}')
 
 if slist then
 
 for qual, url1 in string.gmatch(slist, '"(%d+p)".-(http.-m3u8)') do
   
 
     t['view'] = 'list'


    table.insert(t, {title = '(' .. qual .. ')', mrl = url1, image = '#self/movie.png'})

 end
    end 

     
    elseif args.q == 'mirage1' then
    
  
 -- https://vizhu.top
--  https://lampa.persh1n.ru
  
--  http://93.183.95.219:11378
 
-- http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=912590&stream=e8793ac5f12fe96596a7f3b2d9b59b&audio=0&box_mac=acace24b8434
 
-- https://lam.maxvol.pro/lite/mirage/video?id_file=911588\u0026token_movie=a6ef0986c7558c5792c3ad19d43611",
 
    
  --  https://lam.maxvol.pro/lite/mirage?kinopoisk_id=386&title=чужой&year=1979
 
-- http://78.40.199.67:10630
 
    
     local x = conn:load('https://mylam.ru/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



  -- x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

      t['view'] = 'simple'


    table.insert(t, {title = total, mrl = url})

 
    end
    
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')

url5 = string.gsub(url5, '\\u002B', '+') 
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
     
--http://online7.skaz.tv/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025

  --  http://z01.online/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025 
 
 
 --http://rc.bwa.ad/lite/events?
 
 local x = conn:load('http://z01.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



  -- x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

      t['view'] = 'simple'


    table.insert(t, {title = '720p ' .. total, mrl = url})

 
    end
    
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')

url5 = string.gsub(url5, '\\u002B', '+') 
    t['view'] = 'simple'

table.insert(t, {title = '720p ' .. total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
 
 


 
 
  
 elseif args.q == 'paladin' then
  
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

     local url = 'https://beta.l-vid.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
   if x then
   
--   for url1, total in string.gmatch(x, 'method.-url.-(http.-)&#.-videos__item%-title.->(.-)<') do
  
  x = string.gsub(x, '\\u0026', '&')

for id, id1, total in string.gmatch(x, 'method.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do



      t['view'] = 'simple'

 table.insert(t, {title = total, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
 
 -- table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

      end 
   
   
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-(http.-)&.-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')

--url3 = string.gsub(url3, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


       local x = conn:load(url3)

    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&.->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')

 -- url4 = string.gsub(url4, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


     local x = conn:load(url4)
    
    x = string.gsub(x, '\\u0026', '&')
    

   for id, id1, total2 in string.gmatch(x, 'method.-stream.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do
 

  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
  

end
end
end
end     
      
 elseif args.q == 'paladins' then
    
local headers = {
    ["Host"] = "beta2.l-vid.online:888",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cache-Control"] = "no-cache"
}

local x = http.getz('http://beta2.l-vid.online:888/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d', headers)

      local slist = string.match(x, '"quality"(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":"(http.-)"') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
   url6 = string.gsub(url6, '\\u002B', '+')

--  url6 = string.gsub(url6, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = url6})

end
end
 

 elseif args.q == 'spectre' then
 
 -- https://lam.akter-black.com/lite/spectre/video?id_file=911588&token_movie=a6ef0986c7558c5792c3ad19d43611&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
 
-- https://beta.mitsu.tv/api/lite/phantom?kinopoisk_id=386&title=чужой&year=1979
  
 -- http://31.129.234.181/lite/phantom/?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

  
  local url = 'https://beta.mitsu.tv/api/lite/phantom?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2

local x = conn:load(url)
  
  if x then
  
   
   for url1, total in string.gmatch(x, 'method.-url.-http.-(/lite.-)".-videos__item%-title.->(.-)<') do
  
   
        url1 = string.gsub(url1, '\\u0026', '&')

  
     local x = conn:load('https://beta.mitsu.tv/api' .. url1)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

 

   local slist = string.match(x, 'quality(.-)}')
      
      
   if slist then
   for  total1, url2 in string.gmatch(slist, '"(%d+p)".-http.-(/proxy.-m3u8)') do
  
   url2 = string.gsub(url2, '^(.-)', 'https://beta.mitsu.tv/api')   
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
      t['view'] = 'list'

 
  table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2, image = '#self/movie.png'})
 

      end 
    end
    end
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-http.-(/lite.-)".-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')



       local x = http.get('https://beta.mitsu.tv/api' .. url3)
       --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-(/lite.-)".->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')


     local x = http.get('https://beta.mitsu.tv/api' .. url4)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
    
    x = string.gsub(x, '\\u0026', '&')
    
--table.insert(t, {title = 'http://94.249.239.39' .. url4, mrl = 'http://94.249.239.39' .. url4})



  
  
   for id, id1, total2 in string.gmatch(x, 'method.-call.-url.-http.-id_file=(.-)&token_movie=(.-)".-videos__item%-title.->(.-)<') do
 
-- url5 = string.gsub(url5, '\\u0026', '&')
    
 --  url5 = string.gsub(url5, '\\u002B', '+')
 
   
  t['view'] = 'list'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=spectres&id=' .. id .. '&id1=' .. id1, image = '#self/movie.png'})
  
 -- table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=spectres&id=' .. id .. '&id1=' .. id1  .. '&id2=' .. id2 .. '&id3=' .. id3})
  


end
end
end
 end    
      
 elseif args.q == 'spectres' then
    
     
 --http://94.249.239.39/lite/mirage/video?t=34&s=1&e=1&token_movie=de9688cf5cb8bd7dd2876e9a61ed19
 
 
     local x = conn:load('https://beta.mitsu.tv/api/lite/phantom/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


--local x = http.get('http://94.249.239.39/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
--.. '&uid=bwygkgxn')

if x then


      local slist = string.match(x, 'quality.-{(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":.-http.-(/proxy.-m3u8)') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
  

    t['view'] = 'list'


table.insert(t, {title = '(' .. total3 .. ')', mrl = 'https://beta.mitsu.tv/api' .. url6, image = '#self/movie.png'})
--.. '&uid=bwygkgxn'})

end
end
end
 
 
 
 
 
 elseif args.q == 'phantom' then
  
 -- http://31.129.234.181/lite/phantom/?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
  
 -- http://89.110.97.220:10254
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
--  https://lam.maxvol.pro/proxy/d94c671c57900e92e8369d532bd0d311.m3u8
  
--http://fork.nnmtv.pw:34347
  
  local url = 'https://lam.maxvol.pro/lite/phantom?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0'


local x = http.get(url)
  
  if x then
  
   
   for url1, total in string.gmatch(x, 'method.-url.-http.-(/lite.-)".-videos__item%-title.->(.-)<') do
  
   
        url1 = string.gsub(url1, '\\u0026', '&')

  
     local x = conn:load('https://lam.maxvol.pro' .. url1)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

 

   local slist = string.match(x, 'quality(.-)}')
      
      
   if slist then
   for  total1, url2 in string.gmatch(slist, '"(%d+p)".-http.-(/proxy.-m3u8)') do
  
   url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')   
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
      t['view'] = 'list'

 
  table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2, image = '#self/movie.png'})
 

      end 
    end
    end
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-http.-(/lite.-)".-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')



       local x = http.get('https://lam.maxvol.pro' .. url3)
       --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-(/lite.-)".->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')


     local x = http.get('https://lam.maxvol.pro' .. url4)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
    
    x = string.gsub(x, '\\u0026', '&')
    
--table.insert(t, {title = 'http://94.249.239.39' .. url4, mrl = 'http://94.249.239.39' .. url4})



  
  
   for id, id1, total2 in string.gmatch(x, 'method.-call.-url.-http.-id_file=(.-)&token_movie=(.-)".-videos__item%-title.->(.-)<') do
 
-- url5 = string.gsub(url5, '\\u0026', '&')
    
 --  url5 = string.gsub(url5, '\\u002B', '+')
 
   
  t['view'] = 'list'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=phantoms&id=' .. id .. '&id1=' .. id1, image = '#self/movie.png'})
  
 -- table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladinnsss&id=' .. id .. '&id1=' .. id1  .. '&id2=' .. id2 .. '&id3=' .. id3})
  


end
end
end
 end    
      
 elseif args.q == 'phantoms' then
    
     
 --http://94.249.239.39/lite/mirage/video?t=34&s=1&e=1&token_movie=de9688cf5cb8bd7dd2876e9a61ed19
 
 
     local x = conn:load('https://lam.maxvol.pro/lite/phantom/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


--local x = http.get('http://94.249.239.39/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
--.. '&uid=bwygkgxn')

if x then


      local slist = string.match(x, 'quality.-{(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":.-http.-(/proxy.-m3u8)') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
  

    t['view'] = 'list'


table.insert(t, {title = '(' .. total3 .. ')', mrl = 'https://lam.maxvol.pro' .. url6, image = '#self/movie.png'})
--.. '&uid=bwygkgxn'})

end
end
end
  
  
  
--https://kinogotv.cc/index.php?story=%D0%BE%D0%B1%D1%81%D0%B5%D1%81%D1%81%D0%B8%D1%8F+(2025)&do=search&subaction=search
 
 
 
 
 
 
 elseif args.q == 'zayb' then

--https://tvoy-film.ru/13344-spetsnaz-lvitsa-2023.html

--https://tvoy-film.ru/33021-chuzhoy-1979.html


--local page = tonumber(args.page or '1')
    
--local offset = (page - 1) * 3 + 1
		
	--	for i = 1, 3 do
 

	 --  local url = 'https://free.guljaj.com/tags.php?id=&tag=' .. genre .. '&page=' .. tostring(offset + i - 1) 


local search = 'https://tvoy-film.ru/?do=search&subaction=search&story=' .. urlencode(args.id1)
--.. '&page=' .. tostring(offset + i - 1)

local x = conn:load(search)


for image, title, url in string.gmatch(x, '<article class="card has%-expanded%-link p%-relative grid%-item".-<img src="(/uploads.-)".-alt="(.-)".-<a href="(.-)"') do

image = string.gsub(image, '^(.-)', 'https://tvoy-film.ru/')

t['view'] = 'list'


table.insert(t, {title = title, mrl = '#stream/q=zaybf&id=' .. url, image = image})

end
--end

--https://kinolord.ru
--https://tvoy-film.ru/



--https://pegasus.zayb.ru/movies/f7d679f747ad1a224c4d196aacc4269d3da79315/ac9835b0b60e31443766e3bdfd221de0:2026101103/240.mp4:hls:manifest.m3u8


elseif args.q == 'zaybf' then

local x = conn:load(args.id)


local url = 'https://tvoy-film.ru/engine/videodb/sources.php'

local tr, type = string.match(x, '"translators":{(.-)}}.-"type":"(movies)"')

if type then

for voices, sub, allsubs, hls, hash, qual, qual1, qual2, qual3, qual4 in string.gmatch(tr, '"(.-)":{"sub":(.-),"allsubs":"(.-)","hls":"(.-)","hash":"(.-)","quality":%[(1080),(720),(480),(360),(240)]') do

voices = string.gsub(voices, '^(.-)', '{"voices":"') .. '"}'

local v = json.decode(voices)

local voices = v['voices']



--local url = 'https://tvoy-film.ru/engine/ajax/controller.php'
--?mod=cachevideodb&kinopoisk_id=386'

--&idvid=34973


local params = 'sub=' .. sub .. '&allsubs=' .. allsubs .. '&hls=' .. hls .. '&hash=' .. hash .. '&quality%5B%5D=' .. qual .. '&quality%5B%5D=' .. qual1 .. '&quality%5B%5D=' .. qual2 .. '&quality%5B%5D=' .. qual3 .. '&quality%5B%5D=' .. qual4 .. '&type=' .. type



--["Host"] = "kinorulet.ru"

local headers = {
["Host"] = "tvoy-film.ru",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
["Accept"] = "application/json, text/javascript, */*; q=0.01",

["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["X-Requested-With"] = "XMLHttpRequest",
["Origin"] = "https://tvoy-film.ru",
["Connection"] = "keep-alive",
["Referer"] = "https://tvoy-film.ru/",
["Cookie"] = "PHPSESSID=5843b23d6c5e847248a883edc5f181de; _ym_uid=1791718613154336582; _ym_d=1791718613; _ym_isad=2; adrdel=1791718677149; adrcid=AoxNqG1XPdfDT4CxPyykAag; acs_3=%7B%22hash%22%3A%2278168166d1d84ba31a91bed5b79968efe721107d%22%2C%22nst%22%3A1791805089144%2C%22sl%22%3A%7B%22224%22%3A1791718689144%2C%221228%22%3A1791718689144%7D%7D; domain_sid=72HucE7pU7LrZp74EGFIn%3A1791718937941; _ohmybid_cmf=2; adtech_uid=0ad3b749-4a89-4ddd-a8ff-3712da3a3396%3Akinorulet.ru; top100_id=t1.7627570.1983149360.1791718798151; t3_sid_7627570=s1.1356340385.1791718798154.1791718798164.1.2.1.0...0",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-origin"

}

local c = http.postz(url, headers, params)



local video = string.match(c, '(http.-m3u8)')

video = string.gsub(video, '\\', '')

video = string.gsub(video, '.m3u8', ':manifest.m3u8')

video = string.gsub(video, 'hls', qual .. '.mp4:hls')

t['view'] = 'list'


table.insert(t, {title = qual .. 'p ' .. voices, mrl = video, image = '#self/movie.png'})

local video1 = string.match(c, '(http.-m3u8)')

video1 = string.gsub(video1, '\\', '')

video1 = string.gsub(video1, '.m3u8', ':manifest.m3u8')

video1 = string.gsub(video1, 'hls', qual1 .. '.mp4:hls')

t['view'] = 'list'

table.insert(t, {title = qual1 .. 'p ' .. voices, mrl = video1, image = '#self/movie.png'})



local video2 = string.match(c, '(http.-m3u8)')

video2 = string.gsub(video2, '\\', '')

video2 = string.gsub(video2, '.m3u8', ':manifest.m3u8')

video2 = string.gsub(video2, 'hls', qual2 .. '.mp4:hls')

t['view'] = 'list'

table.insert(t, {title = qual2 .. 'p ' .. voices, mrl = video2, image = '#self/movie.png'})

local video3 = string.match(c, '(http.-m3u8)')

video3 = string.gsub(video3, '\\', '')

video3 = string.gsub(video3, '.m3u8', ':manifest.m3u8')

video3 = string.gsub(video3, 'hls', qual3 .. '.mp4:hls')

t['view'] = 'list'

table.insert(t, {title = qual3 .. 'p ' .. voices, mrl = video3, image = '#self/movie.png'})

end
end




local tr, type = string.match(x, '"translators":{(.-)type":"(.-)"')

--if type then

type = string.gsub(type, 'tv', 'tvseries')

for voices, season, data in string.gmatch(tr, '"(.-)":{"seasons":{"(%d+)".-("sub.-)}}}}') do

data = string.gsub(data, ']', ']}}')


--"translators":{"(.-)":{"seasons":{(.-)}}}}


if season then


voices = string.gsub(voices, '^(.-)', '{"voices":"') .. '"}'

local v = json.decode(voices)

local voices = v['voices']


--for season in string.gmatch(seasons, '"(%d+)":{"%d+":{"sub') do

--for data in string.gmatch(seasons, '"%d+":{("sub.-)}}') do



for sub, allsubs, num, hls, hash, qual, qual1, qual2, qual3, qual4 in string.gmatch(data, '"sub":(.-),"allsubs":"(.-)","num":"(.-)","hls":"(.-)","hash":"(.-)","quality":%[(1080),(720),(480),(360),(240)]') do

local params = 'sub=' .. sub .. '&allsubs=' .. allsubs .. '&num=' .. num .. '&hls=' .. hls .. '&hash=' .. hash .. '&quality%5B%5D=' .. qual .. '&quality%5B%5D=' .. qual1 .. '&quality%5B%5D=' .. qual2 .. '&quality%5B%5D=' .. qual3 .. '&quality%5B%5D=' .. qual4 .. '&type=' .. type

local c = http.postz(url, headers, params)

local video = string.match(c, '(http.-m3u8)')

video = string.gsub(video, '\\', '')

video = string.gsub(video, '.m3u8', ':manifest.m3u8')

video = string.gsub(video, 'hls', qual .. '.mp4:hls')

t['view'] = 'list'

--table.insert(t, {title = season .. ' ' .. data, mrl = seasons, image = '#self/movie.png'})

table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. num .. ' ' .. voices, mrl = video, image = '#self/movie.png'})

end
end
end
--end
--end
 
 
 
 
 
 elseif args.q == 'atodo' then
 
-- t['view'] = 'list'
 
 
 local headers = {
    ["Host"] = "api.atodo.fun",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

 
 local x = conn:load('https://api.alloha.tv/?token=de19b0b4e75ce15a9be8e63c0f5858&kp=' .. args.id3)

local imdb, tmdb = string.match(x, '"id_imdb":"(.-)".-"id_tmdb":(.-),')

   local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
  
  
  local media = string.match(x, '"type":"(movie)"')
  
   
if imdb then
if tmdb then
 
-- x = string.gsub(x, '"serial"', '"tv"')
 
-- local media = 'movie'
 
if media then
 
 local iframe = 'https://api.atodo.fun/api/source/xinu?id=' .. tmdb .. '&title=' .. urlencode(args.id1) .. '&original_title=&original_language=&imdb_id=' .. imdb .. '&year=' .. args.id2 .. '&type=' .. media
 
 
 
    local x = http.getz(iframe, headers)




x = string.gsub(x, '{"video_id":', '')
x = string.gsub(x, '}}', '}')


--table.insert(t, {title = iframe, mrl = iframe, image = '#self/movie.png'})


   
 local v = json.decode(x)

for _, m in ipairs(v['translations']) do


local id = '{"video_id":"' .. m['data'] .. '"}'

id = base64_encode(id)

local x = http.getz('https://api.atodo.fun/api/source/xinu?data=' .. id, headers)

if x then

x = string.gsub(x, '\\', '')

local qualities = string.match(x,'qualities.-{(.-)}')

if qualities then

for qual, url in string.gmatch(qualities,'"(.-)":"(.-)"') do
  
  if url then
  
  t['view'] = 'list'

 table.insert(t, {title = qual .. 'p ' ..  m['translation_name'], mrl = url, image = '#self/movie.png'})
 
 end
end
end
end
end
end
end
end

-- https://api.atodo.fun/api/source/xinu?data=eyJ2aWRlb19pZCI6IjE1NTY2MDQwMjkxOTI1In0%3D
 

local x = conn:load('https://api.alloha.tv/?token=de19b0b4e75ce15a9be8e63c0f5858&kp=' .. args.id3)

local imdb, tmdb = string.match(x, '"id_imdb":"(.-)".-"id_tmdb":(.-),')

   local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
  
   x = string.gsub(x, '"serial"', '"tv"')
 
  
  local media = string.match(x, '"type":"(tv)"')
  
   
if imdb then
if tmdb then
 
if media then
 
 local iframe = 'https://api.atodo.fun/api/source/xinu?id=' .. tmdb .. '&title=' .. urlencode(args.id1) .. '&original_title=&original_language=&imdb_id=' .. imdb .. '&year=' .. args.id2 .. '&type=' .. media
 
--table.insert(t, {title = iframe, mrl = iframe, image = '#self/movie.png'})
 
    local x = http.getz(iframe, headers)




x = string.gsub(x, '{"video_id":', '')
x = string.gsub(x, '}}', '}')


local v = json.decode(x)

for _, m in ipairs(v['translations']) do

for _, n in ipairs(m['seasons']) do

for _, b in ipairs(n['episodes']) do

local title = n['season_name'] .. ' ' .. b['episode_name'] .. ' ' .. m['translation_name']

t['view'] = 'list'

table.insert(t, {title = title, mrl = '#stream/q=atodos&id=' .. b['data'], image = '#self/movie.png'})

end
end
end
end
end
end

elseif args.q == 'atodos' then

local headers = {
    ["Host"] = "api.atodo.fun",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local id = '{"video_id":"' .. args.id .. '"}'

id = base64_encode(id)

local x = http.getz('https://api.atodo.fun/api/source/xinu?data=' .. id, headers)

if x then

 x = string.gsub(x, '\\', '')

local qualities = string.match(x,'qualities.-{(.-)}')

if qualities then

for qual, url in string.gmatch(qualities,'"(.-)":"(.-)"') do
  
  if url then
  
  t['view'] = 'list'
 
 table.insert(t, {title = qual .. 'p', mrl = url, image = '#self/movie.png'})
 
 end   
 end 
end
end



  
  elseif args.q == 'shizard' then

local headers = {
    ["Host"] = "bd.shizahd.pro",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


  
  local x = conn:load('https://kinogotv.cc/index.php?story=' .. urlencode(args.id1 .. ' ' .. '(' .. args.id2 .. ')') .. '&do=search&subaction=search') 
  
--    table.insert(t, {title = 'https://kinogotv.cc/index.php?story=' .. urlencode(args.id1 .. ' ' .. '(' .. args.id2 .. ')') .. '&do=search&subaction=search', mrl = 'https://kinogotv.cc/index.php?story=' .. urlencode(args.id1 .. ' ' .. '(' .. args.id2 .. ')') .. '&do=search&subaction=search'})
  
  
  local search = string.match(x,'<h2.-<a href="(http.-)"')
  
  if search then
 
 local x = conn:load(search)
 
 local iframe = string.match(x,'<li data%-src="http.-shizahd.-iframe/(.-)%?key')
 
 if iframe then
 
 local x = http.getz('https://bd.shizahd.pro/api/m/' .. iframe .. '/list.txt?key=c7068fd62304193a4163ad57', headers)
-- https://bd.shizahd.pro/api/m/0e8f855698ed975e/list.txt?key=c7068fd62304193a4163ad57
 
 --table.insert(t, {title = x, mrl = x})
  
  for total, slist, title in string.gmatch(x,'%{"title":"(.-)"%,%"file":"#2(.-)".-"title2":"(.-)"') do

slist = string.gsub(slist, '/shiza/', '')  
slist = string.gsub(slist, 'YWY1U', '')  

slist = string.gsub(slist, 'dWFKSVJs', '')  
slist = string.gsub(slist, 'EZR', '') 
slist = string.gsub(slist, 'SUl', '')  
slist = string.gsub(slist, 'SVd', '')  
slist = string.gsub(slist, 'kbjdx', '')  
slist = string.gsub(slist, 'OOEZB', '') 
slist = string.gsub(slist, 'S2N4UlN0', '')

slist = base64_decode(slist)
  
  local slist = slist .. ','
 -- table.insert(t, {title = slist, mrl = slist})
  
  
  for qual, url in string.gmatch(slist,'%[(.-)](http.-),') do
  
  t['view'] = 'list'
  
  table.insert(t, {title = '(' .. tolazy(qual) .. ') ' .. tolazy(title), mrl = url, image = '#self/movie.png'})
 end
end
end
end 
 
 if not search then
 
 local x = conn:load('https://kinogotv.cc/index.php?story=' .. urlencode(args.id1) .. '&do=search&subaction=search') 
 
 local search1 = string.match(x,'<h2.-<a href="(http.-)"')
  
  if search1 then
 
 local x = conn:load(search1)
 
 local iframe = string.match(x,'<li data%-src="http.-shizahd.-iframe/(.-)%?key')
 
 if iframe then
 
 local x = http.getz('https://bd.shizahd.pro/api/m/' .. iframe .. '/list.txt?key=c7068fd62304193a4163ad57', headers)
-- https://bd.shizahd.pro/api/m/0e8f855698ed975e/list.txt?key=c7068fd62304193a4163ad57
 
--table.insert(t, {title = 'https://bd.shizahd.pro/api/m/' .. iframe .. '/list.txt?key=c7068fd62304193a4163ad57', mrl = x})
 


  x = string.gsub(x, '{"title":"Сезон', '')  
    x = string.gsub(x, 'серия","folder"', '')  
    
     x = string.gsub(x, '"folder":%[{"title"', '')  
  
  for total, slist, title in string.gmatch(x,'{"title":"(.-)"%,"file":"#2(.-)".-"title2":"(.-)"') do


--total = string.gsub(total, '","folder":[{"title":"', '')

slist = string.gsub(slist, '/shiza/', '')  
slist = string.gsub(slist, 'YWY1U', '')  

slist = string.gsub(slist, 'dWFKSVJs', '')  
slist = string.gsub(slist, 'EZR', '') 
slist = string.gsub(slist, 'SUl', '')  
slist = string.gsub(slist, 'SVd', '')  
slist = string.gsub(slist, 'kbjdx', '')  
slist = string.gsub(slist, 'OOEZB', '') 
slist = string.gsub(slist, 'S2N4UlN0', '')

slist = base64_decode(slist)
  
local slist = slist .. ','
--  table.insert(t, {title = slist, mrl = slist})
  
  
  for qual, url in string.gmatch(slist,'%[(.-)](http.-),') do
  
  t['view'] = 'list'
  
  table.insert(t, {title = '(' .. tolazy(qual) .. ') ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url, image = '#self/movie.png'})
 end
end
end
end 
end


     
    elseif args.q == 'videohub' then
    
 
 --https://bd.shizahd.pro/api/m/12766632761962/hls.m3u8?s=0&e=0&v=&key=c7068fd62304193a4163ad57&q=
 
-- https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=386
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 
 
 local slist = string.match(x, '"isSerial":false(.-)trailers')
 
 if slist then
 
 
 
 
for id, total, total1 in string.gmatch(slist, '"vkId":"(.-)".-"voiceStudio":"(.-)".-"voiceType":"(.-)"') do
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = '#stream/q=cdnvideohubm&id=' .. id})
 

 
 
	
 local headers = {
    ["Host"] = "plapi.cdnvideohub.com",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


     
 local x = http.getz('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, headers)
 
-- x = string.gsub(x, '\\u0026', '&')
  -- x = string.gsub(x, '\\u002B', '+')
  
 local slist = string.match(x, '"sources"(.-)}')
 

   slist = string.gsub(slist, 'mpegFullHdUrl', '1080p')
   
   slist = string.gsub(slist, 'mpegHighUrl', '720p')
   
slist = string.gsub(slist, 'mpegMediumUrl', '480p')

slist = string.gsub(slist, 'mpegLowUrl', '360p')
   
   
   
   
    
    if slist then
    
    for title, url in string.gmatch(slist, '"(1080p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url, image = '#self/movie.png'})
 end
 
 for title, url in string.gmatch(slist, '"(720p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url, image = '#self/movie.png'})
 end
 
for title, url in string.gmatch(slist, '"(480p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url, image = '#self/movie.png'})
 end
 
 
for title, url in string.gmatch(slist, '"(360p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url, image = '#self/movie.png'})
 end
 
 end
 end
 end
 
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 local slist = string.match(x, '"isSerial":true(.-)trailers')
 
 if slist then
 
 

 for id, total, total1, season, episode in string.gmatch(slist, '"vkId":"(.-)".-"voiceStudio":"(.-)".-"voiceType":"(.-)".-"season":(.-),.-episode":(%d+)}') do
 
 t['view'] = 'list'
 
 table.insert(t, {title = 'Сезон :' .. season .. ' серия : ' .. episode  .. ' '.. total .. ' ' .. total1,  mrl = '#stream/q=videohubm&id=' .. id, image = '#self/movie.png'})
 end
 end
 


elseif args.q == 'videohubm' then
 
 local headers = {
    ["Host"] = "plapi.cdnvideohub.com",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


     
 local x = http.getz('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. args.id, headers)
 
-- x = string.gsub(x, '\\u0026', '&')
  -- x = string.gsub(x, '\\u002B', '+')
  
 local slist = string.match(x, '"sources"(.-)}')
 

   slist = string.gsub(slist, 'mpegFullHdUrl', '1080p')
   
   slist = string.gsub(slist, 'mpegHighUrl', '720p')
   
slist = string.gsub(slist, 'mpegMediumUrl', '480p')

slist = string.gsub(slist, 'mpegLowUrl', '360p')
   
   
   
   
    
    if slist then
    
    for title, url in string.gmatch(slist, '"(1080p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
 end
 
 for title, url in string.gmatch(slist, '"(720p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
 end
 
for title, url in string.gmatch(slist, '"(480p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
 end
 
 
for title, url in string.gmatch(slist, '"(360p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
 end
 
 end
    

    
    
    
    
    
     
 elseif args.q == 'cdnvideohub' then
 
 
  local x = conn:load('https://lam.maxvol.pro/lite/cdnvideohub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)





for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url = string.gsub(url, '\\u0026', '&')
   url = string.gsub(url, '\\u002B', '+')
  
  local x = conn:load(url)
  
  
  for  url1 in string.gmatch(x, '"method":"play","url":".-(/proxy.-)"') do
  
  url1 = string.gsub(url1, '\\u0026', '&')
  url1 = string.gsub(url1, '\\u002B', '+')
  
  
url1 = string.gsub(url1, '^(.-)', 'https://lam.maxvol.pro')


t['view'] = 'simple'

  table.insert(t, {title = total, mrl = url1})

end
end
  
  
  for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')
    url5 = string.gsub(url5, '\\u002B', '+')
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end




   
 elseif args.q == 'hdvb' then
      
  t['view'] = 'list'
  
  
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)

    
    local v = json.decode(x)

		for _, m in ipairs(v) do
  
  local translator = m['translator']
 local type = m['type']
local iframe = m['iframe_url']

local origin = string.match(iframe,'http.-(vid.-)/movie')


      
if origin then 


local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Referer"] = "https://" .. origin .. "/",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(iframe, headers)


local id, key = string.match(x, '"file":"%~(.-)".-"key":"(.-)"')

local href = string.match(x, '"href":"(.-)"')

if href then

id = string.gsub(id, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'

--https://vid1783002336.entouaedon.com/movie/d3d32b0257555ee658f1f6da50d11588/iframe

local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)

         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

--t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. translator, mrl = url3, image = '#self/movie.png'})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

--t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. translator, mrl = url3, image = '#self/movie.png'})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

--t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. translator, mrl = url3, image = '#self/movie.png'})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

--t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. translator, mrl = url3, image = '#self/movie.png'})

       end
       end
     
  end
  end
    
    
    
     
     local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
     
   --  table.insert(t, {title = 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3, mrl = '#stream/q=hdvbs&id1=' .. 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3})
     
     
local v = json.decode(x)

		for _, m in ipairs(v) do
  
  local translator = m['translator']
 local type = m['type']
local iframe = m['iframe_url']

local origin = string.match(iframe,'http.-(vid.-)/serial')


if origin then

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Referer"] = "https://" .. origin .. "/",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=177873309816283985; _ym_d=1778733098; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(iframe, headers)

x = string.gsub(x, '\\', '')

local id, key = string.match(x, '"file":"(.-)".-"key":"(.-)"')

if id then
if key then

local href = string.match(x, '"href":"(.-)"')

if href then

id = string.gsub(id, '^(.-)', 'https://vid11.' .. href)

local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)



for id1, text in string.gmatch(x, '"file":"%~(.-)".-("text2":".-")') do


text = string.gsub(text, '^(.-)', '{') .. '}'

local b = json.decode(text)

local text = b['text2']

--local text = string.match(x, '"file".-"text2":"(.-)"')


id1 = string.gsub(id1, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'


local x = http.postz(id1, headers1)



for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'list'
       table.insert(t, {title = '(360p) ' .. text, mrl = url3, image = '#self/movie.png'})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'list'
       table.insert(t, {title = '(480p) ' .. text, mrl = url3, image = '#self/movie.png'})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'list'
       table.insert(t, {title = '(720p) ' .. text, mrl = url3, image = '#self/movie.png'})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'list'
       table.insert(t, {title = '(1080p) ' .. text, mrl = url3, image = '#self/movie.png'})

       end
     
end
     
end
end
end
end
 end

     

elseif args.q == 'hdvbf' then
      
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


local v = json.decode(x)

		for _, m in ipairs(v) do
  
  local translator = m['translator']
 local type = m['type']
local iframe = m['iframe_url']

local origin = string.match(iframe,'http.-(vid.-)/movie')


      
if origin then 
 
      url = string.gsub(iframe, '^(.-)', 'https://lam.maxvol.pro/lite/hdvb/video?iframe=')

--table.insert(t, {title = url, mrl = url})

local x = http.getz(url)


x = string.gsub(x, '\\', '')


local url2 = string.match(x,'method.-"play".-"url":"http.-(/proxy.-m3u8)"')
   
 
  
   local x = conn:load('https://lam.maxvol.pro' .. url2)

 
   x = string.gsub(x, '\\', '')
   

 
         for url3 in string.gmatch(x, 'RESOLUTION.-640.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'list'
       table.insert(t, {title = '(360p) ' .. translator, mrl = url3, image = '#self/movie.png'})

       end
       
         for url3 in string.gmatch(x, 'RESOLUTION.-858.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')

t['view'] = 'list'
       table.insert(t, {title = '(480p) ' .. translator, mrl = url3, image = '#self/movie.png'})

      
       end
        for url3 in string.gmatch(x, 'RESOLUTION.-1280.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
		 
t['view'] = 'list'
       table.insert(t, {title = '(720p) ' .. translator, mrl = url3, image = '#self/movie.png'})


       end
       
for url3 in string.gmatch(x, 'RESOLUTION.-1920.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'list'
       table.insert(t, {title = '(1080p) ' .. translator, mrl = url3, image = '#self/movie.png'})


       end
       end
     
  end
 -- end
    
    
    
    
    
     
     local x = conn:load('http://78.40.195.218:9118/lite/hdvb?kinopoisk_id=' .. args.id3)
     
     
  --   table.insert(t, {title = url, mrl = '#stream/q=hdvbs&id1=' .. url})
     
  -- table.insert(t, {title = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3, mrl = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3})


for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url2 = string.gsub(url2, '\\u0026', '&')
url2 = string.gsub(url2, '\\u002B', '+')


     local x = conn:load('http://78.40.195.218:9118' .. url2)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     
     local x = conn:load('http://78.40.195.218:9118' .. url4)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"http.-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do




     url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
    
       t['view'] = 'list'

    table.insert(t, {title = total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = 'http://78.40.195.218:9118' .. url6, image = '#self/movie.png'})
    end
end
end




    
        
--https://92d73433.obrut.show/embed/MjM/?kinopoisk_id=' .. args.id3


 
 
 elseif args.q == 'turbo1' then

--https://proxy4.rte.net.ru/http://beta2.l-vid.online:888/lite/videodb?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn
 
 
 
 local x = http.get('https://proxy4.rte.net.ru/http://beta.l-vid.online/lite/videodb?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2  .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

   
 x = string.gsub(x, '\\u0026', '&')
 

 
   for url, total in string.gmatch(x, 'videos__item videos__movie.-stream.-http.-(/lite.-)&.-videos__item%-title.->(.-)<') do
  
 
      local x = http.get('https://proxy4.rte.net.ru/http://beta.l-vid.online' .. url .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
  
  
   local slist = string.match(x, 'qualit.-{(.-)}')
   
   for  total1, url2 in string.gmatch(slist, '"(.-)":"http.-(/lite.-)"') do
      
    url2 = string.gsub(url2, '^(.-)', 'https://proxy4.rte.net.ru/http://beta2.l-vid.online:888')  .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'

   



--http://178.20.46.40:12600/lite/videodb/manifest.m3u8?
      
  --   total1 = string.gsub(total1, ':{"', '') 
      
       t['view'] = 'simple'

--table.insert(t, {title = url2, mrl = url2})




    table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
        for url3, total1  in string.gmatch(x, 'videos__item videos__season.-method.-link.-url.-http.-(/lite.-)&#.-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')

--table.insert(t, {title = 'http://beta.l-vid.online' .. url3 .. '&uid=bwygkgxn', mrl = url3})




      local x = http.getz('http://beta.l-vid.online' .. url3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

      for url4, total2  in string.gmatch(x, 'videos__button.-method.-link.-url.-http.-(/lite.-)&#.->(.-)<') do

url4 = string.gsub(url4, '\\u0026', '&')



     local x = http.getz('http://beta.l-vid.online' .. url4 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')


x = string.gsub(x, '\\u0026', '&')

      for url5, total3  in string.gmatch(x, 'videos__item videos__movie.-method.-stream.-http.-/lite.-http.-(http.-)%%22.-videos__item%-title.->(.-серия)<') do

     url5 = string.gsub(url5, '^(.-)', 'http://beta2.l-vid.online:888/lite/videodb/manifest.mp4?link=')  .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'
    

      t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' -'  .. total3 .. tolazy(total2), mrl = url5})

   
    end
end
end



 
 
 
 elseif args.q == 'kinobadi' then
 
 local x = http.get('https://kinobadi.in/player/player.php?kp_id=' .. args.id3)
 
 --table.insert(t, {title = 'https://kinobadi.in/player/player.php?kp_id=' .. args.id3, mrl = 'https://kinobadi.in/player/player.php?kp_id=' .. args.id3})
 

 x = string.gsub(x, '&quot;', '"')
 
 
 local movie = string.match(x,'<div class=.-dl%-player.-data%-sources.-movie.-voices.-:%[(.-)]')
 
-- table.insert(t, {title = movie, mrl = movie})
 
 if movie then
 
 --movie = urldecode(movie)
 
 for name, qual in string.gmatch(movie,'{"name":"(.-)".-"qualities":{(.-)}') do
 
 for total, url in string.gmatch(qual,'"(%d+p)":"(.-)"') do
 
 t['view'] = 'list'
 
 table.insert(t, {title = total .. ' ' .. name, mrl = url, image = '#self/movie.png'})

 end
 
 
  for url1 in string.gmatch(qual,'"240p":"(.-)"') do
 
 url1 = string.gsub(url1, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 t['view'] = 'list'

 
  table.insert(t, {title = '1080p' .. ' ' .. name, mrl = url1, image = '#self/movie.png'})

      end 
 end
 end
 
 
 
 local series = string.match(x,'<div class=.-dl%-player.-data%-sources.-series.-"seasons":%[(.-)]}"')


if series then

--table.insert(t, {title = series, mrl = series})
 
 for season, voices in string.gmatch(series,'{"num":(.-),"voices":%[(.-)]}]') do
 
 --table.insert(t, {title = voices, mrl = voices})
 
 
 for name, episodes in string.gmatch(voices,'{"name":"(.-)","episodes":%[(.-)]') do
 
 --table.insert(t, {title = voices, mrl = voices})
 
 
 
 for episode, qual in string.gmatch(episodes,'{"num":(.-),"qualities":{(.-)}') do

for total, url in string.gmatch(qual,'"(%d+p)":"(.-)"') do
 

 
 t['view'] = 'list'

 
 table.insert(t, {title = '(' .. total .. ')' .. ' Сезон: ' .. season .. ' серия: ' .. episode .. ' ' .. name, mrl = url, image = '#self/movie.png'})

      end 
end
end
end
end 
 
 
 
 
 
 
    
elseif args.q == 'turbo' then

--https://proxy4.rte.net.ru/


--https://go.zet-flix.online/iplayer/player.php?id=JTJGaXBsYXllciUyRnZpZGVvZGIucGhwJTNGa3AlM0QzODY=

--https://a7c5ea7c.obrut.show/embed/1EjM/kinopoisk/386/

local url = 'https://54243ba5.obrut.show/embed/AO/kinopoisk/' .. args.id3 .. '/'


local headerss = {
    ["Host"] = "54243ba5.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cookie"] = "wd_trust=AAAAAGnw-KMyM0U0OTMyRQFSZP9Ll3IMgg; XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}


local headers = {
    ["Host"] = "54243ba5.obrut.show",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Sec-Fetch-Storage-Access"] = "none",
["Connection"] = "keep-alive",
["Referer"] = "url",
["Cookie"] = "wd_approval=AA0xODUuMjI4LjEzMy43AAlpbnZpc2libGUAIDEzaDJoMV84ZGFhZjYxNTI3NzFfMDNlZDU2OTI1MDEyABBpbEM2TjZpM0dlbE1ENmtuAQwCdYyluMRV; _ym_uid=1790835438233754693; _ym_d=1790835438; _ym_isad=1",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "iframe",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "cross-site",
["Priority"] = "u=4"
}




local x = http.getz(url, headerss)




--url = url_for(x)

--url = urldecode(url)


x = string.gsub(x, '//ci9yL3I=', '')
 
x = string.gsub(x, '//by9vL28=', '')
 
x = string.gsub(x, '//dC90L3Q=', '')
 
x = string.gsub(x, '//Yi9iL2I=', '')

x = string.gsub(x, '//dS91L3U=', '')
	
					


local slist = string.match(x, 'new.-Player.-(eyJsYW5.-\"+)')
 
 
 if slist then
 
 slist = base64_decode(slist)
 
-- url = url_for(slist)

 --table.insert(t, {title = slist, mrl = '#stream/q=turbovideo&id=' .. slist})
 


 slist = string.gsub(slist, '{"title":"Season', '')

slist = string.gsub(slist, '{"title":"Episode', '')
 
 
 for title, title1, qual in string.gmatch(slist, '{("title":".-"),"t1":"(.-)%-.-"file":"(.-)"') do

title = string.gsub(title, '^(.-)', '{') .. '}'

local v = json.decode(title)

local title = v['title']

for total, url1 in string.gmatch(qual, '%[(%d+p)](http.-),') do


 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

--title = string.gsub(title, 'Season [%d+]', '')
--title = string.gsub(title, 'Episode [%d+]', '')



--title = string.gsub(title, '","folder":%[{"title":"', '')


 t['view'] = 'list'
 
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=turbovideo&id=' .. url1, image = '#self/movie.png'})
 
 end
 end 
 end

elseif args.q == 'turbovideo' then
  
  local headers = {
    ["Host"] = "54243ba5.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cookie"] = "wd_trust=AAAAAGnw-KMyM0U0OTMyRQFSZP9Ll3IMgg; XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}
  
  
  
 local x = http.getz(args.id, headers)
 
 --if x then
 

local url = string.match(x,'<meta http%-equiv="refresh".-url=.-(http.-)\'')
  
 -- for url in string.gmatch(x,'<meta http%-equiv="refresh".-url=.-(http.-m3u8)') do
  
  if url then
  
  t = {}
 table.insert(t, {mrl = url})
  
 --   print(url)
  --  return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}
 end
 
 
 elseif args.q == 'videodb1' then
  
--https://proxy4.rte.net.ru/

--http://31.129.234.181/lite/zetflixdb?id=1318447&imdb_id=tt16431404&kinopoisk_id=6553387&title=На вершине&original_title=Apex&serial=0&original_language=en&year=2026&source=cub&clarification=0&similar=false&rchtype=web&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0





local headers = {
    ["Host"] = "31.129.234.181",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/plain, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br"

}


    local x = http.getz('https://proxy4.rte.net.ru/http://31.129.234.181/lite/zetflixdb?kinopoisk_id=' .. args.id3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
   

   
   for  url2, total in string.gmatch(x, '"method".-"url":.-(http.-)".-class="videos__item%-title">(.-)<') do
 

      url2 = string.gsub(url2, '\\u0026', '&') 
     
     
      t['view'] = 'list'
    

 
    table.insert(t, {title = tolazy(total), mrl = url2, image = '#self/movie.png'})

      end 
    

      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
      
    
      url2 = string.gsub(url2, '\\u0026', '&') 
 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

    
      url3 = string.gsub(url3, '\\u0026', '&') 

       local x = http.getz(url3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

   
      for  url4, total2 in string.gmatch(x, '"method":"play".-"url".-(http.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    
      url4 = string.gsub(url4, '\\u0026', '&') 

      t['view'] = 'list'
 
 
   --  table.insert(t, {title = url4, mrl = url4})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4, image = '#self/movie.png'})

     end
     end
    end
  
  

    
    elseif args.q == 'videodb' then
  
 -- http://31.129.234.181/lite/videodb?href=https%3a%2f%2fkinogo.media%2f37869-chuzhoj.html
  
  
--  http://78.40.195.218:9118/lite/videodb?rjson=False&href=https%3a%2f%2fkinogo.media%2f37869-chuzhoj.html

--http://78.40.195.218:9118/lite/videodb?title=чужой&year=1979

--http://78.40.195.218:9118/lite/videodb?rjson=False&href=https%3a%2f%2fiframe.cloud%2fiframe%2f386

 
 -- local page = tonumber(args.page or 1)
  
--  local url = 'https://apn-latest.onrender.com/https://kinogo.media/search/' .. urlencode(args.id1) .. '/page/' .. tostring(page) .. '/'
	
	--	local x = conn:load(url)
		
	
		
       -- for image, title, id, total in string.gmatch(x, '<div class="short".-<img src=.-(/uploads.-)".-alt="(.-)".-data%-href="(http.-)".-class="sd%-line".-Год выхода:.->(.-)<') do
      


--id  = string.gsub(id, '^(.-)', 'http://78.40.195.218:9118/lite/videodb?rjson=False&href=')
--image  = string.gsub(image, '^(.-)', 'https://apn-latest.onrender.com/https://kinogo.media')

		--	table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=videodbz&id=' .. id, image = image})
	--	end
    
    
 --   local url = '#folder/page=' .. tostring(page + 1) .. '&q=videodb&id1=' .. args.id1
		--table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
    
    
   -- 	local url = '#folder/q=search&keyword=' .. urlencode(args.id1) .. '&page=' .. tostring(page + 1)
--		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
  
  
--  elseif args.q == 'videodbz' then
  
  
 local x = conn:load('https://x.vmestefilms.online/api/kinopoisk/?kp_id=' .. args.id3)
  
  
  
     local total = string.match(x, '"slug":.-"(.-)",')
  
  if total then
  
  local id = string.match(x, '"TURBO".-"id": (.-)}')

if id then
  
  
  
    local x = conn:load('http://78.40.195.218:9118/lite/videodb?rjson=False&href=https://x.vmestefilms.online/room/' .. id .. '/' .. total .. '/')
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-http.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://78.40.195.218:9118')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
    url2 = string.gsub(url2, '^(.-)', 'http://78.40.195.218:9118') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://78.40.195.218:9118') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-http.-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://78.40.195.218:9118')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end

end
end

--http://api.vokino.pro/v2/search?name=чужой&year=1979






   
elseif args.q == 'zetflixdb' then
  
  
local url = 'https://3a41cf05.obrut.show/embed/kzM?kinopoisk_id=' .. args.id3



   
local headers = {
    ["Host"] = "3a41cf05.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",

    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://3a41cf05.obrut.show/embed/kzM?kinopoisk_id=" .. args.id3 .. '"',
    ["Cookie"] = "XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}




local x = http.postz(url, headers)



--url = url_for(x)

--url = urldecode(url)


x = string.gsub(x, '//ci9yL3I=', '')
 
x = string.gsub(x, '//by9vL28=', '')
 
x = string.gsub(x, '//dC90L3Q=', '')
 
x = string.gsub(x, '//Yi9iL2I=', '')

x = string.gsub(x, '//dS91L3U=', '')
	
					


local slist = string.match(x, 'new.-Player.-(eyJsYW5.-\"+)')
 
 
 if slist then
 
 slist = base64_decode(slist)
 
-- url = url_for(slist)

 


 slist = string.gsub(slist, '{"title":"Season', '')

slist = string.gsub(slist, '{"title":"Episode', '')
 
 
 for title, title1, qual in string.gmatch(slist, '{("title":".-"),"t1":"(.-)%-.-"file":"(.-)"') do

title = string.gsub(title, '^(.-)', '{') .. '}'

local v = json.decode(title)

local title = v['title']

for total, url1 in string.gmatch(qual, '%[(%d+p)](http.-),') do


 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

--title = string.gsub(title, 'Season [%d+]', '')
--title = string.gsub(title, 'Episode [%d+]', '')



--title = string.gsub(title, '","folder":%[{"title":"', '')


 t['view'] = 'list'
 
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=zetflixvideo&id=' .. url1, image = '#self/movie.png'})
 
 end
 end 
 end

elseif args.q == 'zetflixvideo' then
  
  local headers = {
    ["Host"] = "3a41cf05.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",

    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = '"' .. args.id .. '"',
    ["Cookie"] = "XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}
  
  
  
 local x = http.getz(args.id, headers)
 

 --if x then
 

local url = string.match(x,'<meta http%-equiv="refresh".-url=.-(http.-)\'')
  
 -- for url in string.gmatch(x,'<meta http%-equiv="refresh".-url=.-(http.-m3u8)') do
 if url then
  
  t ={}
 table.insert(t, {mrl = url})
  
  --  print(url)
 --   return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}
 end






elseif args.q == 'vcdn' then

local x = conn:load('http://api.vokino.pro/v2/search?name=' .. urlencode(args.id1) .. '&year=' .. args.id2) 

local id = string.match(x, '"channels".-"details".-"id":"(.-)"') 


--http://api.vokino.pro/v2/online/videocdn/6593f8688914c04deae97e7c?token=windows_68988745062e9987f8b5b8502917b37d_1264491

local x = conn:load('http://api.vokino.pro/v2/online/videocdn/' .. id .. '?token=windows_68988745062e9987f8b5b8502917b37d_1264491')


for total, url in string.gmatch(x, '"title":"(.-)".-"stream_url":"(.-)"') do
  
      t['view'] = 'simple'
 
 
    table.insert(t, {title = total, mrl = url})
 
     end
     
   
 
 



   

   
   
--   http://z01.online/lite/filmix?title=чужой&year=1979
    
--https://vizhu.top/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
 -- https://lamp-movie.ru/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
  
--http://z01.online/lite/filmix?postid=173202
      
 
 
 elseif args.q == 'filmixred' then
 


local x = conn:load('http://smotret24.com/lite/fxapi?kinopoisk_id=' .. args.id3)
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

 
 if slist then
   
   local video = string.match(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"720p":"http.-(2160p).-mp4')
 
 if video then
 
 for total3, url4, url5, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)(_720.mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
    table.insert(t, {title =  '2160p ' .. tolazy(total2), mrl = url4 .. '_2160.mp4', image = '#self/movie.png'})
 
 end
 end
 end
 
    
 
if slist then
   
   local video = string.match(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"720p":"http.-(1440p).-mp4')
 
 if video then
 
 for url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"720p":"(http.-)_720.mp4.-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
    table.insert(t, {title =  '1440p ' .. tolazy(total2), mrl = url4 .. '_1440.mp4', image = '#self/movie.png'})
 
 end
 end
 end
 
 
 
if slist then
   
 
 for total3, url4, url5, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)(_720.mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
    table.insert(t, {title =  '1080p ' .. tolazy(total2), mrl = url4 .. '_1080.mp4', image = '#self/movie.png'})
 
 end
 end

 

 
 
if slist then
    for total3, url4, url5, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)(_720.mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
 --   table.insert(t, {title =  '(2160p) ' .. tolazy(total2), mrl = url4 .. '_2160.mp4', image = '#self/movie.png'})
    
 --   table.insert(t, {title =  '1440p ' .. tolazy(total2), mrl = url4 .. '_1440.mp4', image = '#self/movie.png'})
    
 --   table.insert(t, {title =  '1080p ' .. tolazy(total2), mrl = url4 .. '_1080.mp4', image = '#self/movie.png'})
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4 .. url5, image = '#self/movie.png'})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 

    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
   if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do
--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
    
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end

    
end
end


 
    elseif args.q == 'filmix' then

--https://api.filmix.tv/api-fx/list?search=горничная+2025

--local fxapi = 'http://wtch.ch/lite/fxapi?kinopoisk_id=386&title=чужой&year=1979'

--local x = conn:load('http://wtch.ch/lite/fxapi?kinopoisk_id=386&title=чужой&year=1979')


local v = conn:load('http://wtch.ch/lite/fxapi?postid=181496')


local hash = string.match(v, '<div class="videos__item videos__movie.-"play".-"quality".-"720p":"http.-/s/(.-)/')


if hash then



local search = conn:load('https://api.filmix.tv/api-fx/list?search=' .. urlencode(args.id1) .. '+' .. args.id2)

search = string.gsub(search, '\\', '')


local title, year, image, id = string.match(search, '"id":.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)".-url":"https://.-/.-/.-/(.-)%-') 

if id then
if image then

image = string.gsub(image, '\\', '')



t['view'] = 'list'


local api = conn:load('https://api.filmix.tv/api-fx/post/' .. id .. '/video-links')


--table.insert(t, {title = api, mrl = api, image = image})

api = string.gsub(api, '\\', '')


local video = string.match(api, '{"season":null(.-)"video"}]')


if video then


local video1 = string.match(video, '"files":%[(.-)"updated"') 

if video1 then

for url, url1, total in string.gmatch(video1,'url.-(http.-)(?hash=).-".-quality.-:(.-),') do


for title in string.gmatch(video1,'"voiceover":"(.-)"') do

t['view'] = 'list'
 

      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1 .. hash, image = image})
   
      end
end
end



local video2 = string.match(video, '"files".-"files":%[(.-)"updated"')

if video2 then




for url, url1, total in string.gmatch(video2,'url.-(http.-)(?hash=).-".-quality.-:(.-),') do

for title in string.gmatch(video2,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1 .. hash, image = image})
   
      end
end
 end
 
 
 
local video3 = string.match(video, '"files".-"files".-"files":%[(.-)"updated"') 


if video3 then

for url, url1, total in string.gmatch(video3,'url.-(http.-)(?hash=).-".-quality.-:(.-),') do

for title in string.gmatch(video3,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1 .. hash, image = image})
   
      end
end
 end
 
 
 local video4 = string.match(video, '"files".-"files".-"files".-"files":%[(.-)"updated"') 

if video4 then

for url, url1, total in string.gmatch(video4,'url.-(http.-)(?hash=).-".-quality.-:(.-),') do

for title in string.gmatch(video4,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1 .. hash, image = image})
   
      end
end
 end
 
 
local video5 = string.match(video, '"files".-"files".-"files".-"files".-"files":%[(.-)"updated"') 

if video5 then



for url, url1, total in string.gmatch(video5,'url.-(http.-)(?hash=).-".-quality.-:(.-),') do

for title in string.gmatch(video5,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1 .. hash, image = image})
   
      end
end
 end
end
 
 

       for url1, url2, url3, url4, url5, total in string.gmatch(api, '"url":"(http.-/hls/)(.-)(/s%d+)(e%d+)(_.-hash=).-quality":(.-),') do


    title1 = string.gsub(url3, '/s', 'Сезон ')
 
 title1 = string.gsub(title1, 'Сезон 0', 'Сезон ')
 
 
    title = string.gsub(url4, 'e', 'серия ')
    title = string.gsub(title, 'серия 0', 'серия ')
    
    title2 = string.gsub(url2, '(.-%d+-)', '')
    
      t['view'] = 'list'
      
      table.insert(t, {title = '(' .. total .. 'p) ' .. title1 .. ' ' .. title .. ' ' .. title2, mrl = url1 .. url2 .. url3 .. url4 .. url5 .. hash, image = image})
      

      end
end	
end
end  
 
 
 
 elseif args.q == 'kino4k' then
  
--http://wtch.ch/lite/fxapi?kinopoisk_id=386&title=чужой&year=1979
  
 -- https://get-balancer.akter-black.com/lite/filmix?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn
  
    
    -- local x = conn:load(args.id)
    
  --  local x = conn:load('https://get-balancer.akter-black.com/lite/fxapi?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
    
		local x = conn:load('http://wtch.ch/lite/fxapi?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  
 
 
 if slist then
   
   local video = string.match(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"720p":"http.-(2160p).-mp4')
 
 if video then
 
 for total3, url4, url5, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)(_720.mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
    table.insert(t, {title =  '2160p ' .. tolazy(total2), mrl = url4 .. '_2160.mp4', image = '#self/movie.png'})
 
 end
 end
 end
 
    
 
if slist then
   
   local video = string.match(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"720p":"http.-(1440p).-mp4')
 
 if video then
 
 for url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"720p":"(http.-)_720.mp4.-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
    table.insert(t, {title =  '1440p ' .. tolazy(total2), mrl = url4 .. '_1440.mp4', image = '#self/movie.png'})
 
 end
 end
 end
 
 
 
if slist then
   
 
 for total3, url4, url5, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)(_720.mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
    table.insert(t, {title =  '1080p ' .. tolazy(total2), mrl = url4 .. '_1080.mp4', image = '#self/movie.png'})
 
 end
 end

 

 
 
if slist then
    for total3, url4, url5, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)(_720.mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
 --   table.insert(t, {title =  '(2160p) ' .. tolazy(total2), mrl = url4 .. '_2160.mp4', image = '#self/movie.png'})
    
 --   table.insert(t, {title =  '1440p ' .. tolazy(total2), mrl = url4 .. '_1440.mp4', image = '#self/movie.png'})
    
 --   table.insert(t, {title =  '1080p ' .. tolazy(total2), mrl = url4 .. '_1080.mp4', image = '#self/movie.png'})
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4 .. url5, image = '#self/movie.png'})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 

    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
   if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do
--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
    
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end

    
end
end









--http://78.40.199.67:10630/cors/https://30bf3790.obrut.show/embed/AN?kinopoisk_id=386

--http://z01.online/lite/rezka?title=чужой+1979
--https://app.lovefilm.cc



elseif args.q == 'hdrezkatest1' then

--http://fxmlparsers.in.net/VilkaDB/?id=rezka&act=https%3A%2F%2Frezka.ag%2Ffilms%2Ffiction%2F80586-proekt-ave-mariya-2026-latest.html

--http://fxmlparsers.in.net/VilkaDB/?id=rezka&act=https://rezka.fi/films/fiction/80586-proekt-ave-mariya-2026-latest.html


--&ep=id%3D80586%26translator_id%3D59%26


	local url = 'https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-/(film.-)"') do

--http://78.40.199.67:10630

--http://78.40.195.218:9118/lite/rezka/?href=films/horror/1447-chuzhoy-1979-latest.html&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv

local x = conn:load('http://78.40.195.218:9118/lite/rezka/?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')


x = string.gsub(x, '\\u0026', '&')

for id, id1, title in string.gmatch(x, 'class=.-videos__movie.-"method".-"call".-"url".-http.-&id=(.-)&t=(.-)&.-class="videos__item%-title">(.-)<') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=hdrezkatestm&id=' .. id .. '&id1=' .. id1})

end
end
   
local url = 'https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		

for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-/(series.-)"') do


	local x = conn:load('http://78.40.195.218:9118/lite/rezka?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')




x = string.gsub(x, '\\u0026', '&')

for url in string.gmatch(x, '<div class=.-videos__season.-"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-)<') do

local x = conn:load('http://78.40.195.218:9118' .. url)

	x = string.gsub(x, '\\u0026', '&')
	
	for id, title in string.gmatch(x,'class="videos__button.-"method".-"link".-"url".-"http.-&href=series.-&id=.-&t=(.-)"}.->(.-)<') do
	
	
	for id1, id2, id3, title1 in string.gmatch(x,'<div class="videos__item videos__movie.-"method".-"call".-"url":"http.-&id=(.-)&.-&s=(.-)&e=(.-)".-class="videos__item%-title">(.-)<') do
	

	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=hdrezkatests&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

end
end
end
end




elseif args.q == 'voidboost' then



local headers = {
    ["Host"] = "rezka.metrpiva.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "*/*",
    ["Referer"] = "https://metrpiva.com/",
    ["Origin"] = "https://metrpiva.com",
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-site",
    ["Priority"] = "u=4"
}




	local url = 'https://rezka.metrpiva.com/info?id=' .. args.id3
		
			local x = http.getz(url, headers)



--table.insert(t, {title = x, mrl = '#stream/q=voidboostm&id=' .. x})

local slist = string.match(x,'"translators".-%[(.-)hasSeasons":false')

if slist then

for id, name in string.gmatch(slist, '{"id":"(.-)","name":"(.-)"') do


t['view'] = 'list'

table.insert(t, {title = tolazy(name), mrl = '#stream/q=voidboostm&id=' .. id .. '&id3=' .. args.id3, image = '#self/movie.png'})

end
end




local ids = string.match(x, 'translators".-"defaultTranslator":"(.-)","hasSeasons":false')

if ids then

local urls = 'https://rezka.metrpiva.com/movie-stream?id=' .. args.id3 .. '&translator_id=' .. ids
		
	local v = http.getz(urls, headers)

local slist = string.match(v,'stream(.-)}')

for quel, url1 in string.gmatch(slist,'%[(%d+p)](http.-m3u8)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel), mrl = url1, image = '#self/movie.png'})

end

for quel, url1 in string.gmatch(slist,'%[(%d+p)]http.-m3u8.-(http.-mp4)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel) .. ' (mp4)', mrl = url1, image = '#self/movie.png'})

end

end






--https://rezka.metrpiva.com/info?id=7225519

--https://rezka.metrpiva.com/movie-stream?id=7225519&translator_id=665




local url = 'https://rezka.metrpiva.com/info?id=' .. args.id3
		
			local x = http.getz(url, headers)

--table.insert(t, {title = url, mrl = '#stream/q=voidboostm&id=' .. url})


local slist = string.match(x,'"translators".-%[(.-)hasSeasons":true')

if slist then

for id, name in string.gmatch(slist, '{"id":"(.-)","name":"(.-)"') do

t['view'] = 'list'

table.insert(t, {title = tolazy(name), mrl = '#stream/q=voidboostn&id=' .. id .. '&id3=' .. args.id3, image = '#self/movie.png'})

end
end


elseif args.q == 'voidboostn' then

local headers = {
    ["Host"] = "rezka.metrpiva.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "*/*",
    ["Referer"] = "https://metrpiva.com/",
    ["Origin"] = "https://metrpiva.com",
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-site",
    ["Priority"] = "u=4"
}

local url1 = 'https://rezka.metrpiva.com/episodes?id=' .. args.id3 .. '&translator_id=' .. args.id



local x = http.getz(url1, headers)



local episod = string.match(x,'"episodes".-{(.-)}}')

for seasonid, episodes in string.gmatch(episod,'"(%d+)":%[(.-)]') do


for episodeid, episodename in string.gmatch(episodes,'{"id":(.-),"title":"(Серия.-)"') do

t['view'] = 'list'


table.insert(t, {title = 'Сезон ' .. seasonid  .. ' ' .. episodename, mrl = '#stream/q=voidboosts&id=' .. args.id .. '&id3=' .. args.id3 .. '&id4=' .. seasonid .. '&id5=' .. episodeid, image = '#self/movie.png'})

end
end



elseif args.q == 'voidboosts' then

local headers = {
    ["Host"] = "rezka.metrpiva.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "*/*",
    ["Referer"] = "https://metrpiva.com/",
    ["Origin"] = "https://metrpiva.com",
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-site",
    ["Priority"] = "u=4"
}


--https://rezka.metrpiva.com/episode-stream?id=4308326&translator_id=111&s=1&e=1

local url = 'https://rezka.metrpiva.com/episode-stream?id=' .. args.id3 .. '&translator_id=' .. args.id .. '&s=' .. args.id4 .. '&e=' .. args.id5
		
	local x = http.getz(url, headers)

local slist = string.match(x,'stream(.-)}')

for quel, url1 in string.gmatch(x,'%[(%d+p)](http.-m3u8)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel), mrl = url1, image = '#self/movie.png'})

end

for quel, url1 in string.gmatch(x,'%[(%d+p)]http.-m3u8.-(http.-mp4)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel) .. ' (mp4)', mrl = url1, image = '#self/movie.png'})

end


elseif args.q == 'voidboostm' then

local headers = {
    ["Host"] = "rezka.metrpiva.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "*/*",
    ["Referer"] = "https://metrpiva.com/",
    ["Origin"] = "https://metrpiva.com",
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-site",
    ["Priority"] = "u=4"
}


local url = 'https://rezka.metrpiva.com/movie-stream?id=' .. args.id3 .. '&translator_id=' .. args.id
		
	local x = http.getz(url, headers)

local slist = string.match(x,'stream(.-)}')

for quel, url1 in string.gmatch(slist,'%[(%d+p)](http.-m3u8)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel), mrl = url1, image = '#self/movie.png'})

end

for quel, url1 in string.gmatch(slist,'%[(%d+p)]http.-m3u8.-(http.-mp4)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel) .. ' (mp4)', mrl = url1, image = '#self/movie.png'})

end







elseif args.q == 'hdrezkatest' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'list'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=hdrezkatestm&id=' .. id .. '&id1=' .. id1, image = '#self/movie.png'})

end
end



local headersv = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}


local headersv1 = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "device_fp=9f9139a533bc817f940b4ee8a95b90fb; _ym_uid=1783765420480304829; _ym_d=1783765420; _clck=lzs41b%5E2%5Eg7n%5E0%5E2383; adrdel=1783765433965; adrcid=AvUrk8BPUn0AXVkexSk3JgQ; acs_3=%7B%22hash%22%3A%2278168166d1d84ba31a91bed5b79968efe721107d%22%2C%22nst%22%3A1783851876598%2C%22sl%22%3A%7B%22224%22%3A1783765476598%2C%221228%22%3A1783765476598%7D%7D; PHPSESSID=225nrdd5b82hvum033cft7l9p6",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}



local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do
	--	local x = http.getz('https://kinopub.me' .. args.id, headersv)
		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}
		
		local x = http.postz('https://fly.metrpiva.com/https://kinopub.me' .. '/ajax/get_cdn_series/', headersv, params)			
					

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})




url = url_for('get_movie', {file = x['url'], t = t['name']})


url = urldecode(url)

for quali, url1 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url1, image = '#self/movie.png'})

end
end
	end	
end
   
   
   
 
   
local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'list'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=hdrezkatests&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = '#self/movie.png'})

end
end
end
end
end

local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
--local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')

local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'list'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=hdrezkatests&id=' .. tid .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = '#self/movie.png'})

end
end
end
end

end
 


      elseif args.q == 'hdrezkatests' then
   
   
   local headers = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}
   

					local params = http.encode{
		id = args.id1,
		translator_id = args.id,
		season = args.id2,
		episode = args.id3,
		action = 'get_stream'
					}
					
					local x = http.postz('https://fly.metrpiva.com/https://kinopub.me' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})


	url = url_for('get_stream', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url3, image = '#self/movie.png'})

end      
   
   
   
    
    	elseif args.q == 'hdrezkatestm' then

local headers = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}
   
	
					local params = http.encode{
						id = args.id,
						translator_id = args.id1,
						action = 'get_movie'
					}
					
					local x = http.postz('https://fly.metrpiva.com/https://kinopub.me' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})




local x = json.decode(x)

	url = url_for('get_movie', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url3, image = '#self/movie.png'})

end



elseif args.q == 'fxmlrezka' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'list'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=fxmlrezkam&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. url, image = '#self/movie.png'})

end
end


local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}


local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. url .. '&m=1&ep=id%3D' .. id .. '%26translator_id%3D' .. tid .. '%26action%3Dget_movie')

--table.insert(t, {title = 'http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. url .. '&m=1&ep=id%3D' .. id .. '%26translator_id%3D' .. tid .. '%26action%3Dget_movie', mrl = 'http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. url .. '&m=1&ep=id%3D' .. id .. '%26translator_id%3D' .. tid .. '%26action%3Dget_movie'})


--url = url_for('get_movie', {file = x['url'], t = t['name']})


x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'list'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1, image = '#self/movie.png'})

end
end
	end	
end
   



local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'list'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=rezkas&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url, image = '#self/movie.png'})

end
end
end
end
end

local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
--local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')

local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'list'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=fxmlrezkas&id=' .. tid .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url, image = '#self/movie.png'})

end
end
end
end

end
 


      elseif args.q == 'fxmlrezkas' then
   
 
--http://fxmlparsers.in.net/http://www.rezka.ag/?act=https%3A%2F%2Frezka.ag%2Fseries%2Fdrama%2F91279-naslednica-2004.html&tid=59&m=1&ep=id%3D91279%26translator_id%3D59%26season%3D1%26episode%3D31%26action%3Dget_stream  
  
local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id4 .. '&m=1&ep=id%3D' .. args.id1 .. '%26translator_id%3D' .. args.id .. '%26season%3D' .. args.id2 .. '%26episode%3D' .. args.id3 .. '%26action%3Dget_stream')

--table.insert(t, {title = 'http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id4 .. '&m=1&ep=id%3D' .. args.id1 .. '%26translator_id%3D' .. args.id .. '%26season%3D' .. args.id2 .. '%26episode%3D' .. args.id3 .. '%26action%3Dget_stream', mrl = 'http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id4 .. '&m=1&ep=id%3D' .. args.id1 .. '%26translator_id%3D' .. args.id .. '%26season%3D' .. args.id2 .. '%26episode%3D' .. args.id3 .. '%26action%3Dget_stream'})




x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'list'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1, image = '#self/movie.png'})

end



elseif args.q == 'fxmlrezkam' then



local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id2 .. '&m=1&ep=id%3D' .. args.id .. '%26translator_id%3D' .. args.id1 .. '%26action%3Dget_movie')



x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'list'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1, image = '#self/movie.png'})

end



					
 

 
 










elseif args.q == 'rezka' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'list'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezkam&id=' .. id .. '&id1=' .. id1, image = '#self/movie.png'})

end
end





local headers = {
    ["Host"] = "hdrzk.org",
    ["%{http_code}"] = "max-time 10",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
["Cookie"] = "cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
   ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://hdrzk.org/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}





local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do
	--	local x = http.getz('https://kinopub.me' .. args.id, headersv)
		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}
		
		local x = http.postz('https://hdrzk.org' .. '/ajax/get_cdn_series/', headers, params)			
					

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})




url = url_for('get_movie', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url1 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url1, image = '#self/movie.png'})

end
end
	end	
end
   
   
   
 
   
local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'list'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=rezkas&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url, image = '#self/movie.png'})

end
end
end
end
end

local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
--local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')

local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'list'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=rezkas&id=' .. tid .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url, image = '#self/movie.png'})

end
end
end
end

end
 


      elseif args.q == 'rezkas' then
   
   
   local headers = {
    ["Host"] = "hdrzk.org",
    ["%{http_code}"] = "max-time 10",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
["Cookie"] = "techaro.lol-anubis-cookie-verification=019f8838-f797-7300-b45c-75710e4cb40c; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMTlmODgzOC1mNzk3LTczMDAtYjQ1Yy03NTcxMGU0Y2I0MGMiLCJleHAiOjE3ODcyODg4OTksImlhdCI6MTc4NDY5Njg5OSwibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NDY5NjgzOSwicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImUzMTEwYTFiZTdkZWZhNGNlYWZkYWFlZjczN2MxMGZmNWRlOWZjZjdiYTRjNmJkZWY3YTdkZDU5YThlYmRjY2EifQ.09wb9nbPOOqztqPGqz6YQP11Tj_capHS-14qndonPH9a4BEA6eCBL8FAr51QysAgck5prBPSvPNntuA0_GqjCA; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
   ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://hdrzk.org/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}



local headerss = {
    ["Host"] = "hdrzk.org",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
   ["Cookie"] = "dle_user_id=2927296; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; dle_newpm=0; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d"
}






					local params = http.encode{
		id = args.id1,
		translator_id = args.id,
		season = args.id2,
		episode = args.id3,
		action = 'get_stream'
					}
					
					local x = http.postz('https://hdrzk.org' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})


	url = url_for('get_stream', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url3, image = '#self/movie.png'})

end      
   
 
local x = conn:load('http://78.40.195.218:9118/lite/pizdatoehd/movie?href=' .. args.id4 .. '&t=' .. args.id .. '&s=' .. args.id2 .. '&e=' .. args.id3)
  
  
local slist = string.match(x,'"quality":{(.-)}')

if slist then

 for qual, url in string.gmatch(slist,'"(%d+p)":".-(/proxy.-)"') do
 
   
url = string.gsub(url, '^(.-)', 'http://78.40.195.218:9118')
   
   
t['view'] = 'list'

    table.insert(t, {title = tolazy(qual), mrl = url, image = '#self/movie.png'})

     end
 end
 
 
 
   
   
    
    	elseif args.q == 'rezkam' then

local headers = {
    ["Host"] = "hdrzk.org",
    ["%{http_code}"] = "max-time 10",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
["Cookie"] = "cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
   ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://hdrzk.org/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}




	
					local params = http.encode{
						id = args.id,
						translator_id = args.id1,
						action = 'get_movie'
					}
					
					local x = http.postz('https://hdrzk.org' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})




local x = json.decode(x)


	url = url_for('get_movie', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url3, image = '#self/movie.png'})

end




--https://kinopub.me/

     elseif args.q == 'hdrezka222' then

  --http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=чужой:+земля-2025&box_mac=acace24b8434

--local url = 'http://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load('https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href=.-//.-/(.-)"') do
   
 
-- http://78.40.195.218:9118/lite/rezka/?href=series/horror/79810-ono-dobro-pozhalovat-v-derri-2025-latest.html&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv
 
 --http://31.129.234.181/lite/pizdatoehd?href=series/horror/79810-ono-dobro-pozhalovat-v-derri-2025-latest.html&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv
 
-- http://78.40.195.218:9118/lite/pizdatoehd?href=films/horror/1447-chuzhoy-1979-latest.html
 
      local x = conn:load('http://78.40.195.218:9118/lite/pizdatoehd?href=' .. '/' .. url)


 x = string.gsub(x, '\\u0026', '&')

for id, title in string.gmatch(x, 'class=.-videos__movie.-"method".-"url.-voice=(.-html).-class="videos__item%-title">(.-)<') do

id = urldecode(id)
 
 
 
 
     --     for id, title in string.gmatch(x,'data%-translator_id.-href="(.-)">(.-)</a>') do
     t['view'] = 'simple'
  
  

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. id) .. '&box_mac=acace24b8434')
    

  
  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title =tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
  end
  
  local x = conn:load('http://78.40.195.218:9118/lite/pizdatoehd?href=' .. '/' .. url)


 x = string.gsub(x, '\\u0026', '&')
 
  for url3, id1, total in string.gmatch(x, 'class="videos__button.-"method".-"url".-href=(.-html).-&t=(.-)".->(.-)<') do
 
 url3 = urldecode(url3)
  
         
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. url3) .. '&box_mac=acace24b8434')
  
  
         
for title1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=.-&translate=.-&season=(.-)&episode=(.-)]]') do
   
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(total), mrl = '#stream/q=rezkis&id=' .. url3 .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
        
end
 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. url) .. '&box_mac=acace24b8434')
    

      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end

    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
  
t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    end
   
    
elseif args.q == 'rezkis' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. args.id) .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end
elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end






     elseif args.q == 'rezka222' then

--https://evkh.lol/lite/rhsprem?kinopoisk_id=464475&title=франкенштейн&year=2025

--https://lampa.remagick.ru/lite/rhsprem

    		local x = conn:load('https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '+' .. args.id2)
    
  --table.insert(t, {title = 'https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '+' .. args.id2, mrl = 'https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
  
       local url = string.match(x, '<div class="videos__line".-method.-"url".-href=(.-)"') 
       
    local slist = string.match(x, '"quality"(.-)}')
      
    if slist then
   
   for  total1, url3 in string.gmatch(slist, '"(%d+p)":"(http.-mp4)') do
  
    --  url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'simple'

   table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
    end
  
 -- https://lampa.remagick.ru/lite/rhsprem?href=films%2fhorror%2f82897-prishlite-pomosch-2026.html
  
  
  
  
  local x = conn:load('https://lampa.remagick.ru/lite/rhsprem?href=' .. url)
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
      -- t['view'] = 'simple'
   
      local x = conn:load(url2)

  local slist = string.match(x, '"quality"(.-)}')
      
      
   
   for  total1, url3 in string.gmatch(slist, '"(%d+p)":"(http.-mp4)') do
  
   --   url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'list'

    table.insert(t, {title = '(' .. total1 .. ')' .. total, mrl = url3})

     end  
 end
     




   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      



      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rez' then

   local x = conn:load('https://lampa.remagick.ru/lite/rhsprem/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
  
  
  
--https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=4760854&title=%D0%9A%D0%BE%D1%80%D0%BE%D0%BB%D1%8C+%D0%A2%D0%B0%D0%BB%D1%81%D1%8B&year=2025&serial=1

        elseif args.q == 'kinobase' then

--http://31.129.234.181:80/lite/kinobase?href=film/244146-na-vershine&t=&s=1&uid=guest

   local x = conn:load('https://kinobase.org/search?query=' .. urlencode(args.id1) .. '+' .. args.id2)
   
 for title in string.gmatch(x, '<div class="poster".-<a href="/(.-)"') do
        
   
    url = string.gsub(title, '^(.-)', 'https://lam.akter-black.com/lite/kinobase?href=') .. '&t=&s=1'
    

     local x = conn:load(url .. '&uid=guest')
   

      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
   --   local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(%d+p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com')
     t['view'] = 'list'

url2 = string.gsub(url2, '\\u002B', '+')

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2, image = '#self/movie.png'})
    end
     end  
  

  
     for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
      local x = conn:load(url)
   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com')
    
       
      local x = conn:load(url2 .. '&uid=guest')

      
      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
    
url3 = string.gsub(url3, '\\u002B', '+')

    
         
    url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')
    
       t['view'] = 'list'



    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3, image = '#self/movie.png'})

    end   
    end
    end
   
end




   elseif args.q == 'kinotop' then


   
local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=search&search=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&box_mac=acace24b8434')
   
       for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do
 
       local x = conn:load(url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')
  
  
     for total1, url2  in string.gmatch(x, '<channel.-<title><!%[CDATA%[(%d+p)]]></title.-<stream_url><!%[CDATA%[(http.-)]]') do
    
    
     t['view'] = 'simple'
      table.insert(t, {title = total1, mrl = url2})

       end
     end
   

for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[http.-(&media=.-)]]') do


       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=watch' .. url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')


     for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = (total3) .. (total4), mrl = url3})

end
   
   
  for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-сезон)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
        local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = total2 .. (total3) .. (total4), mrl = url3})

end
end
     end
      
      

elseif args.q == 'jac' then

    

   local x = conn:load('https://lam.akter-black.com/lite/jac?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
   
       t['view'] = 'simple'
    table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     
     


		local x = conn:load('https://lam.akter-black.com/lite/jac?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
  
  
  
  
  
       t['view'] = 'simple'
     table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     


--https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=570402&title=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB&year=2025
     
--  https://lam.maxvol.pro/lite/pidtor/serial/548bae27dca47ab2805465cc12ab1d9a89d15426?tr=
     
     
     
     
     
     elseif args.q == 'result' then
      args.id = args.id:lower() 
      
      local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end
   
   
   
    elseif args.q == 'pidtor' then
  
  
  local x = conn:load('https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
 -- table.insert(t, {title = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})

      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-?tr=).-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'list'

   table.insert(t, {title = 'pidtor :' .. tolazy(total), mrl = url2, image = '#self/movie.png'})

       
    end
     
  
  
  local x = conn:load('https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
  
--https://lam.akter-black.com/lite/pidtor?kinopoisk_id=&title=чужой&serial=1

--https://lam.akter-black.com/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=

--https://lam.maxvol.pro/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=




for url2, title in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')

      local x = conn:load(url2)
    

    
      for url3, total  in string.gmatch(x, '"method":"link".-"url":"http.-/lite/pidtor/serial/(.-)?tr=.-class="videos__item%-title videos__season%-title">(.-)</div>') do


--url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')

     url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'list'
     table.insert(t, {title = title .. ' ' ..  total,mrl = '#stream/q=result&id=' .. url3, image = '#self/movie.png'})
     end
     
   end
 
 
 
-- https://jacred.stream/api/v1.0/torrents?search=чужой&relased=1979
 
 --elseif args.q == 'jacred' then

--local x = conn:load('https://jac.red/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
 

 
elseif args.q == 'jacred' then

--https://jac.red/api/v1/search?query=чужой&relased=1979

local x = conn:load('https://jac.red/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)

--local x = conn:load('https://ru.jacred.stream/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
 
--https://jacred.stream/api/v1.0/torrents?search=kp386&limit=2

x = string.gsub(x, '\\u0026', '"')	
 

for title, magnet in string.gmatch(x, '"title":"(.-)".-"magnet":".-xt=urn:btih:(.-)"') do

title = string.gsub(title, '^(.-)', '{"title":"') .. '"}'

local v = json.decode(title)

local title = v['title']
		
	
	t['view'] = 'list'
	
	table.insert(t, {title = title, mrl = '#stream/q=jacreds&id=' .. magnet, image = '#self/movie.png'})

end


   

--https://torr1.akter-black.com/stream/Spider-Man%20Brand%20New%20Day%202026%201080p_nnm-club.mkv?link=7c30776fd2af7a74cd56ded216ddf1e0c9d65775&index=1&play
 
 -- https://lam.akter-black.com/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u 
 -- https://ts.maxvol.pro/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u
--  https://tv.alcopa.cc/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u 
  
 -- https://lam.akter-black.com/ts/stream?link=eed372084d7f2e8fc830851a8e59688e2c722b37&m3u

--https://torr1.akter-black.com/stream/Rokki.2.1979.XviD.BDRip.Kinozal.TV.avi?link=734f3bbf403daeff23023d2c2858acf28b705414&index=1
 
 elseif args.q == 'jacreds' then

     args.id = args.id:lower() 

--https://torr1.akter-black.com/stream?link=1954f40ef5b496b41f67b856e562723cea1c0df3&m3u

local x = conn:load('https://tv.alcopa.cc/ts/stream?link=' .. args.id .. '&m3u')
 
 --table.insert(t, {title = 'https://torr1.akter-black.com/stream?link=' .. args.id .. '&m3u', mrl = x, image = image})
 
 for title, url in string.gmatch(x,'EXTINF:.-,(.-)\nhttp.-(/ts.-)\n') do
 
-- url = urldecode(url)
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = 'https://lam.akter-black.com' .. url, image = '#self/movie.png'})
   
-- table.insert(t, {title = title, mrl = 'https://torr1.akter-black.com/stream' .. url})
		end
 
 
 
 
 elseif args.q == 'potok' then
 
-- https://api.potok.rip/api/media/search?query=чужой+1979&language=ru
 
 --local url = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru'
 
 local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru')
 
 for id, title, year, media in string.gmatch(x,'"id":(.-),"title":"(.-)".-"subtitle":"(.-)".-"mediaType":"(.-)"') do
 

table.insert(t, {title = id .. ' ' .. title .. ' ' .. year .. ' ' .. media, mrl = id .. ' ' .. title .. ' ' .. year .. ' ' .. media})
 
 
 
 --local url1 = 'https://search.potok.rip/api/v1/torrents/search'


local url1 = 'https://tv.alcopa.cc/api/v2.0/indexers/all/results?title=' .. title .. '&title_original=&year=' .. year .. '&is_serial=1'

local x = conn:load(url1)
 
 local x = json.decode(x)

		for _, v in ipairs(x['Results']) do

 
 

local url2 = 'https://torrent.potok.rip/api/torrents'


local headers = {
    ["Host"] = "torrent.potok.rip",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://potok.rip/",
     ["Content-Type"] = "application/json",
    ["Content-Length"] = "252",
    ["Origin"] = "https://potok.rip"}
  
  
 --   ["Connection"] = "keep-alive",
 --   ["Sec-Fetch-Dest"] = "empty",
 --   ["Sec-Fetch-Mode"] = "cors",
 --   ["Sec-Fetch-Site"] = "same-site",
 --   ["Priority"] = "u=4"
--}
    




local params = '{"title":"' .. v['Title'] .. '","link":"' .. v['Details'] .. '","magnetUri":"' .. v['MagnetUri'] .. '","mediaType":"' .. media .. '","tmdbId":' .. id .. '}'
 
 
 table.insert(t, {title = params, mrl = params})
 
local x = http.postz(url2, headers, params)
 
 
 url = url_for(x)     
 url = urldecode(url)     
  

  --    t['view'] = 'simple'
      
      table.insert(t, {title = url, mrl = url})
 
 end
 end
 
 
-- https://torrent.potok.rip/api/torrents/7c94aadc67067059d44b34b670d1e84bbd751977/files/1/metadata


--https://torrent.potok.rip/api/torrents/feed30a9b86e8e98f063149d21d2200a88e30f2f/files/1/hls/master.m3u8





 
 
 
 
 elseif args.q == 'torrs' then
 
 local url = 'https://tv.alcopa.cc/ts/torrents'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/json",
    ["Content-Length"] = "1578",
    ["Origin"] = "https://tv.alcopa.cc",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1785248696908035379; _ym_d=1785248696; _ym_isad=2; _ym_visorc=w; lampac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; alpac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; _lampac_auth=8126ef1f-0a68-4b87-be2b-732e679461cc",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}
 
 local params = '{"action":"add","link":"magnet:?xt=urn:btih:9a060fb9626117a6f283f0be3e2ca62a30ab881f&dn=Disclosure.Day.2026.1080p.WEB-DL.DDP5.1.H.264.mkv&tr=udp%3a%2f%2fopentor.net%3a6969&tr=http%3a%2f%2fbt.searchtor.to%2f00da7f34fc14674f374452da7ba4ebc8%2fannounce&tr=http%3a%2f%2fbt02.nnm-club.cc%3a2710%2f00da7f34fc14674f374452da7ba4ebc8%2fannounce&tr=http%3a%2f%2fipv6.bt.searchtor.to%2f00da7f34fc14674f374452da7ba4ebc8%2fannounce&tr=http%3a%2f%2fbt02.ipv6.nnm-club.cc%3a2710%2f00da7f34fc14674f374452da7ba4ebc8%2fannounce&tr=http%3a%2f%2ftracker.grepler.com%3a6969%2fannounce&tr=udp%3a%2f%2ftracker.dler.com%3a6969%2fannounce&tr=http%3a%2f%2fh4.trakx.nibba.trade%3a80%2fannounce&tr=udp%3a%2f%2fopen.stealth.si%3a80%2fannounce&tr=udp%3a%2f%2ftracker.bitsearch.to%3a1337%2fannounce&tr=udp%3a%2f%2fexodus.desync.com%3a6969%2fannounce&tr=udp%3a%2f%2ftracker-udp.gbitt.info%3a80%2fannounce&tr=udp%3a%2f%2ftracker.torrent.eu.org%3a451%2fannounce&tr=http%3a%2f%2ftracker.mywaifu.best%3a6969%2fannounce&tr=udp%3a%2f%2fevan.im%3a6969%2fannounce&tr=udp%3a%2f%2fbittorrent-tracker.e-n-c-r-y-p-t.net%3a1337%2fannounce&tr=udp%3a%2f%2fmartin-gebhardt.eu%3a25%2fannounce&tr=https%3a%2f%2ftr.nyacat.pw%3a443%2fannounce&tr=udp%3a%2f%2ftracker.opentorrent.top%3a6969%2fannounce&tr=udp%3a%2f%2fns575949.ip-51-222-82.net%3a6969%2fannounce&tr=udp%3a%2f%2ftracker.corpscorp.online%3a80%2fannounce&tr=http%3a%2f%2fretracker.local%2fannounce&tr=udp%3a%2f%2ftorrent.by%3a2710&tr=udp%3a%2f%2ftracker.torrent.eu.org%3a451","title":"День разоблачения / Disclosure Day (2026) WEB-DL","save_to_db":false}'
 
 local x = http.postz(url, headers, params)
 
 url = url_for(x)
 url = urldecode(url)
 
 table.insert(t, {title = url, mrl = url})
 
 
 elseif args.q == 'torrsuuu' then

local x = conn:load('http://jac.red/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
 


 x = string.gsub(x, '",', '\\u0026')	
 
	
 
  x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
     x = string.gsub(x, '\\u041A', 'К')
       x = string.gsub(x, '\\u043A', 'к')  
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  x = string.gsub(x, '\\u041B', 'Л')
       x = string.gsub(x, '\\u041b', 'Л')
    x = string.gsub(x, '\\u043B', 'л')
       x = string.gsub(x, '\\u043b', 'л')
     
     x = string.gsub(x, '\\u041C', 'М')
       x = string.gsub(x, '\\u043C', 'м')
       x = string.gsub(x, '\\u041D', 'Н')
       x = string.gsub(x, '\\u043D', 'н')
       x = string.gsub(x, '\\u041E', 'О')
     
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
    x = string.gsub(x, '\\u043E', 'о')
       x = string.gsub(x, '\\u043e', 'о')
    
    x = string.gsub(x, '\\u041F', 'П')
       x = string.gsub(x, '\\u043F', 'п')
     
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
          x = string.gsub(x, '\\u042A', 'Ъ')
        x = string.gsub(x, '\\u044A', 'ъ')
        x = string.gsub(x, '\\u042B', 'Ы')
        x = string.gsub(x, '\\u044B', 'ы')
        x = string.gsub(x, '\\u042C', 'Ь')
        x = string.gsub(x, '\\u044C', 'ь')
        x = string.gsub(x, '\\u042D', 'Э')
        x = string.gsub(x, '\\u044D', 'э')
        x = string.gsub(x, '\\u042E', 'Ю')
        x = string.gsub(x, '\\u044E', 'ю')
        x = string.gsub(x, '\\u042F', 'Я')
     
     x = string.gsub(x, '\\u044F', 'я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')

 
 for id, title, total, total1, total2 in string.gmatch(x,'{"tracker".-"magnet:?.-btih:(.-)\\u0026.-name":"(.-)\\u0026.-"relased":(.-),.-"quality":(.-),"voices":%[(.-)]') do
 
total2 = string.gsub(total2, '\\u0026', '",')
 

   
  -- t['view'] = 'simple'
   
--   table.insert(t, {title = title, mrl = '#stream/q=results&id=' .. id, image = image})
--		end


--elseif args.q == 'results' then
		
      id = id:lower() 

local url = 'https://webtor.io/ru/' .. id

local x = conn:load(url)

local resource, item = string.match(x,'<form class="stream".-<input type="hidden" name="resource%-id" value="(.-)".-<input type="hidden" name="item%-id" value="(.-)"')

if resource then
if item then


local url1 = 'https://webtor.io/ru/stream-video'
    	
    local headers = {
    ["Host"] = "webtor.io",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",  
    ["Referer"] = "https://webtor.io/ru/" .. id,
    ["rid"] = "anti-csrf",
    ["st-auth-mode"] = "cookie",

    ["x-layout"] = '{{ template "main" . }}',
    ["x-requested-with"] = "XMLHttpRequest",
    ["x-return-url"] = "/ru/" .. id,

    ["Content-Type"] = "multipart/form-data; boundary=----geckoformboundary2351d75989feaaab29367cec52302dcf",
    ["Content-Length"] = "361",
    ["Origin"] = "https://webtor.io",
    ["Alt-Used"] = "webtor.io",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "INGRESSCOOKIE=1783322851.769.27.209027|30f4c3c8c430593554a9c611add2fe8e; lang=ru; session=MTc4MzMyMjg1MHxOd3dBTkVRMlZsUTJRa3hPVFZaRVMwZEVTVVZJUTFWTE5FdFdWVVJJVGxoTldrdEVSMDgzVWxCRlYwUldTMDFNUVRSQlJFMVZWRkU9fPERPIXqmqLFj16BsJtUxltomSQSS0wlLyfTCUZWLaiP; cf_clearance=IZ5E5g50hgggo5cblyd1j13Dpts.9.q2.nhqFz0QAq4-1783355644-1.2.1.1-h58djc.A7pYEgfhr7kqY_8_iLmTcC7KTbpkwY2l13LrwMieOY8DV9kY.DBMlnwH6rV6nDjIfq6KHnb9hWAMPAvmgBVpXxf80h2wS1.DtLTFXHnCQhbE.oxk3BHJrgfXBNUutCZDwvYe1QWn7rhDf0wRkPKejVEbMmoLZ8sSYxQGt1f83SgyDkijSi7gS6CYYkcCRiPDvSYDHeBUGHYVRzjIU_PXL8jZcW9VBZyDQ1MlXz1.U3hkiRWXeMVyu1.89wzJqQysW7od6jFV3Ad2lyjnzbH0YT58mmIsczGq6MYrQs9yuUTNWRSiMnVbR5XC_TZDHcxu5Qg0Pss8hJXDAqA; st-last-access-token-update=1783322917853",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

 --   ["x-csrf-token"] = "LkveJ0cYcZ_APYAGsiXRnr1w7Cw=",

 --   ["x-session-id"] = "D6VT6BLNMVDKGDIEHCUK4KVUDHNXMZKDGO7RPEWDVKMLA4ADMUTQ",




local params = [[
------geckoformboundary2351d75989feaaab29367cec52302dcf
Content-Disposition: form-data; name="resource-id"

resource
------geckoformboundary2351d75989feaaab29367cec52302dcf
Content-Disposition: form-data; name="item-id"

item
------geckoformboundary2351d75989feaaab29367cec52302dcf--
]]



--table.insert(t, {title = url, mrl = url})

local x = http.postz(url1, headers, params)

--local url1 = string.match(x,'>source.torrent.-href="(.-)"')      
 url = url_for(x)     
 url = urldecode(url)     
  
      x = string.gsub(x, '\\', '')
      


 --   local url1 string.match(x, '"mp4":%["(.-mp4)"') 
  
  if url then
  
   --   url1 = string.gsub(url, '^(.-)', 'https://abra--5e4bd525.api.cosmic-crab.buzz/')
  --    t['view'] = 'simple'
      
      table.insert(t, {title = url, mrl = url})
  end
  end
 end
 end
 
  
  
  
  
 
      elseif args.q == 'awmzone' then

--https://lampa.plus



local headers = {
    ["Host"] = "lampa.plus",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6IkRHakdrTGkySDVEaVNRWE1hOUdCWEE9PSIsInZhbHVlIjoid1VGNlpvRGt0N3dENTZXQkxOMllwdHZlMDZzRTlwRDV1aWc5Q2JJUDRhbk1rSzR5dDZuMGhIaS9OSFdQcFhLWHk0ZnBxZDk2R1B6S2hvc2phK29JbSt4TElabGxPdXlPSEgwUEJoQ2daS3BGd0FzdjFPNEFEOERPUVBZZVFxMjkiLCJtYWMiOiIxYjc5YWIxNzk2YzZhODUzMTk3MjA3ODlhMGZlNWFiM2NlNjkzYmVlNzAzZmIwNTcxODFhNmUzZTcyYzBiMDdlIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlFMZEFSVWhwTWpxNUpkSGNCSDdYT1E9PSIsInZhbHVlIjoiNkxHdWhoWE1KOGYyQzBSazZvNldVOGlQb1pta3dOalJtLzBjcktVTFBFTVJCNEwxbXNQUmdPbE9OMHJXejUrdFhmSS9GSk0rOUkzVG8ydHhxU21uRDNzSnh4ekNUeUJGaHV1MGVRUzhFQllzdzVwS3FyRTNQbk1xZXdQd0tpQUYiLCJtYWMiOiI4ZDQ0NjFmMGJmYmJjZDdmOGFhOTUyMzQxYzQzNzAzOGFlZDMwYWQzMjU2NDhhZDM4OTMyYzU4Mzc3YTQ5OTkxIiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none"
}
 
-- https://www4.kinovod10.top/mary/spotlight?search=
 
  local search = 'https://lampa.plus/mary/spotlight?search=' .. urlencode(args.id1)
  
--  https://lampa.plus/36040688-mumiia.html
  
--  local x = conn:load(search)

local x = http.getz(search, headers)

if x then

local x = json.decode(x)

		for _, v in ipairs(x) do
			local link = 'https://lampa.plus' .. v['link']
			
if link then

local x = conn:load(link)

x = string.gsub(x, '\\', '')

local id, title = string.match(x,'"embedUrl":"http.-embed%-players/(.-)".-<h1.->(.-)<')

if id then

t['view'] = 'list'

  table.insert(t, {title = title, mrl = '#stream/q=awmzonepl&id=' .. 'https://lampa.plus/embed-player/' .. id, image = '#self/movie.png'})
  
  end
end
end
end







local headers = {
    ["Host"] = "turboserial.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6IkRHakdrTGkySDVEaVNRWE1hOUdCWEE9PSIsInZhbHVlIjoid1VGNlpvRGt0N3dENTZXQkxOMllwdHZlMDZzRTlwRDV1aWc5Q2JJUDRhbk1rSzR5dDZuMGhIaS9OSFdQcFhLWHk0ZnBxZDk2R1B6S2hvc2phK29JbSt4TElabGxPdXlPSEgwUEJoQ2daS3BGd0FzdjFPNEFEOERPUVBZZVFxMjkiLCJtYWMiOiIxYjc5YWIxNzk2YzZhODUzMTk3MjA3ODlhMGZlNWFiM2NlNjkzYmVlNzAzZmIwNTcxODFhNmUzZTcyYzBiMDdlIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlFMZEFSVWhwTWpxNUpkSGNCSDdYT1E9PSIsInZhbHVlIjoiNkxHdWhoWE1KOGYyQzBSazZvNldVOGlQb1pta3dOalJtLzBjcktVTFBFTVJCNEwxbXNQUmdPbE9OMHJXejUrdFhmSS9GSk0rOUkzVG8ydHhxU21uRDNzSnh4ekNUeUJGaHV1MGVRUzhFQllzdzVwS3FyRTNQbk1xZXdQd0tpQUYiLCJtYWMiOiI4ZDQ0NjFmMGJmYmJjZDdmOGFhOTUyMzQxYzQzNzAzOGFlZDMwYWQzMjU2NDhhZDM4OTMyYzU4Mzc3YTQ5OTkxIiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none"
}
 
 
  local search = 'https://turboserial.com/mary/spotlight?search=' .. urlencode(args.id1)
  
  
  
  local x = http.getz(search, headers)

--local x = conn:load(search)

if x then

local x = json.decode(x)

		for _, v in ipairs(x) do
			local link = 'https://turboserial.com' .. v['link']
			
if link then

local x = conn:load(link)



x = string.gsub(x, '\\', '')
 
local id, title = string.match(x,'"embedUrl":"http.-embed%-players/(.-)".-<h1.->(.-)</h1>')

if id then

t['view'] = 'list'

  table.insert(t, {title = title, mrl = '#stream/q=awmzonepl&id=' .. 'https://turboserial.com/embed-player/' .. id, image = '#self/movie.png'})
  
  end
end
end
end


--https://kinogotv.one/36456621-proekt-konec-sveta.html






elseif args.q == 'awmzonepl' then

local url = args.id

local headerss = {
   ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6ImJIZEJtYTVWZWJ0U3N3cHlGKzAxVlE9PSIsInZhbHVlIjoiOVNRNFRPWjZXZmpob01WZk5sSkJGTTNPNk9PN0NaZ2w4dVhIYVpVaklFWURXVFRTTjl5aDA3aE92N2VzMVJZV09HNGhiemNzRUtzcHJ1S1JwWmhIS1RMNTVNejh2RmxzMmZROWdwSDhXc01xTSttV2MyVHBwcmFuczNybTlieXAiLCJtYWMiOiJkOTE3NzUyYzUyNGNhNmVhMDJkMWE2YTZhZDA1NjEzMjA3MWVhNzk1Yjc3YjVmNWY4ZWYyZTc2OWEwNzRhZmVhIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6InVDdE9UWE5lQjJjUVgzbmNPMWZML0E9PSIsInZhbHVlIjoicE04emNaeGJiSXVMQXppNmIva1RjYkcrZ3FDSkZKLzBYbkM3RFczTzBBUkNEUUx2K0tEMjhzUjQ4cXByVE1JZmJNbFRkYnZJbkdmTWVHM2I3RTd6czMzZGN1YVhLVnF5L3Y5cDAwTGNvN1BYNTZYVFBrRW9hU0d4YVh3K21QQnAiLCJtYWMiOiI4MjBiNmJhM2RkNTBjYmY5ZTFlNmU1NTA3N2JkMzNhMDMzZjcxMGFkZTA2OWE5YWZlZjE2NTRhODhhYWZiZjI1IiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
["Priority"] = "u=0, i"
}

local headers = {
["Pragma"] = "no-cache",
["Cache-Control"] = "no-cache",
["sec-ch-ua"] = '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
["sec-ch-ua-mobile"] = "?0",
["sec-ch-ua-platform"] = "Windows",
["DNT"] = "1",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,uk-UA;q=0.8,uk;q=0.7,en-US;q=0.6,en;q=0.5",
["Priority"] = "u=1, i",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-origin",
["Sec-Fetch-Storage-Access"] = "active",
["Referer"] = iframe
}
 
  local x = conn:load(url)

--local x = http.getz(url, headerss)


  
  local slist = string.match(x,'Playerjs.-atob.-&#039;(.-)&#039;%)+')
  
  if slist then
  

  
  slist = base64_decode(slist)
  

local slist1 = string.match(slist,'"file":"#2(.-)\"+')

slist1 = string.gsub(slist1, '\\', '') 

slist1 = string.gsub(slist1, '//', '') 

slist1 = string.gsub(slist1, 'cG9zb3Npa2xvdW4=', '')

slist1 = string.gsub(slist1,'ZHZhZG9sYm9lYmE=', '')

--slist1 = string.gsub(slist1,'Qtn', '')

slist1 = string.gsub(slist1,'YmliYWlib2Jh', '')


slist1 = base64_decode(slist1)

slist1 = urldecode(slist1)


for title, url1, url2, url3 in string.gmatch(slist1,'{(.-)}(http.-)(/movie.-)(/hls.m3u8)') do

if url2 then

local m3u = conn:load(url1 .. url2 .. url3)

if m3u then

m3u = string.gsub(m3u, './', ',./') 

m3u = string.gsub(m3u, 'stream', '/stream') 
 
for qual, url4 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'list'

table.insert(t, {title = '(' .. tolazy(qual) .. 'p) ' .. tolazy(title), mrl = url1 .. url2 .. url4, image = '#self/movie.png'})
  
  end
end
 end
 end
 
 
 
 for season, episode, slist2 in string.gmatch(slist,'{"id":"S(.-)E(.-)".-"file":"#2(.-)\"+') do

slist2 = string.gsub(slist2, '\\', '') 

slist2 = string.gsub(slist2, '//', '') 

slist2 = string.gsub(slist2, 'cG9zb3Npa2xvdW4=', '')

slist2 = string.gsub(slist2,'ZHZhZG9sYm9lYmE=', '')

slist1 = string.gsub(slist1,'YmliYWlib2Jh', '')



slist2 = base64_decode(slist2)

slist2 = urldecode(slist2)
 
 
 for title, url2 in string.gmatch(slist2,'{(.-)}(http.-m3u8)') do


--local m3u = conn:load(url2 .. url3)

--if m3u then

--m3u = string.gsub(m3u, './', ',./') 

--m3u = string.gsub(m3u, 'stream', '/stream') 
 
--for qual, url4 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'list'

  table.insert(t, {title = 'Сезон ' .. season .. ' Серия ' .. episode .. ' ' .. tolazy(title), mrl = url2, image = '#self/movie.png'})
  
  end
 end
-- end
-- end
    
 end   
  
       

elseif args.q == 'anwap' then
  
  

  
  local x = conn:load('https://m.anwap.media/films/search/?slv=' .. urlencode(args.id1) .. '&vid=1&toch=on')

  
local slist=string.match(x, '</form>.-div class="save">По.-id="cn"(.-)"menuniz"')
  

  if slist then
    for url, title, year in string.gmatch(x, '<div class="my_razdel film".-href="(.-)".-alt="(.-)".-class="in year">(.-)<') do

     local x = conn:load('https://m.anwap.media' .. url)



local slist1=string.match(x,'"file":"#2(.-)"')


slist1 = string.gsub(slist1, '//', '')
        slist1 = string.gsub(slist1, 'WXQ2cmpGZA==', '')
slist1 = string.gsub(slist1, 'RmtpVTdoRw==', '')

slist1 = string.gsub(slist1, 'RXJTdzNBc2k=', '')

slist1 = string.gsub(slist1, 'UlRkM1M2NUZn', '')

    slist1 = base64_decode(slist1)
    
local url1 = string.match(slist1, '(http.-m3u8)') 
   
      t['view'] = 'list'
        table.insert(t, {title = tolazy(title) .. ' (' .. year .. ')', mrl = url1, image = '#self/movie.png'})
	
		end
		end


local x = conn:load('https://m.anwap.media/serials/search/?t=on' .. '&word=' .. urlencode(args.id1) .. '&vid=1') 


   local slist=string.match(x, '</form><div class="save">По.-id="cn"(.-)"menuniz"')

	if slist then

       for url, title, year in string.gmatch(slist, '<div class="my_razdel film".-<a href="(.-)".-alt="(.-)".-class="in year">(.-)<') do

    
    local x = conn:load('https://m.anwap.media' .. url)

       local slist1=string.match(x, '<ul class="tl2">(.-)</ul>')


		if slist1 then
			for url1, title1 in string.gmatch(slist1, '<li><a href="(/serials/s.-)">(.-)<') do
       
       t['view'] = 'list'
      
       table.insert(t, {title = tolazy(title) .. ' (' .. year .. ') ' .. title1, mrl = '#stream/q=sezond&id=' .. url1, image = '#self/movie.png'})
        
        end
		end
		end	
end


    elseif args.q == 'sezond' then
  
   local x = conn:load('https://m.anwap.media' .. args.id)

 
 local ser = string.match(x,'<div class="blm".-<a href="(/serials/down/.-)"')
 
 local x = conn:load('https://m.anwap.media' .. ser)
 
 
   local slist=string.match(x,'"file":"#2(.-)"')

slist = string.gsub(slist, '//', '')
        slist = string.gsub(slist, 'WXQ2cmpGZA==', '')
slist = string.gsub(slist, 'RmtpVTdoRw==', '')

slist = string.gsub(slist, 'RXJTdzNBc2k=', '')

slist = string.gsub(slist, 'UlRkM1M2NUZn', '')

    
    slist = base64_decode(slist)
    
local url1 = string.match(slist,'(http.-txt)') 

  local x = conn:load(url1)

  
  
			for title, url in string.gmatch(x, '"title":"(.-)".-"file":"(http.-m3u8)') do
      

        t['view'] = 'list'
        table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
	
		end






elseif args.q == 'collaps' then
  
  --https://mylam.ru/proxy/3a7512fee8b40a505a857c5fa4ad764d.m3u8
  
  
  local x = conn:load('https://mylam.ru/lite/collaps?kinopoisk_id=' .. args.id3)

for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '^(.-)', 'https://mylam.ru')
    
      t['view'] = 'list'

   table.insert(t, {title = tolazy(total), mrl = url2, image = '#self/movie.png'})

    end

   
    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://mylam.ru')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'https://mylam.ru')
    
       t['view'] = 'list'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3, image = '#self/movie.png'})

       
    end

end




      local x = conn:load('https://api.bhcesh.me/franchise/details?token=d39edcf2b6219b6421bffe15dde9f1b3&kinopoisk_id=' .. args.id3)
   
   
   for title in string.gmatch(x, '"iframe_url":"http.-/embed/.-/(.-)"') do
   

      

url = string.gsub(title, '^(.-)', 'https://mylam.ru/lite/collaps?orid=')
     local x = conn:load(url)

   
   
   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'https://mylam.ru')
      t['view'] = 'list'

   table.insert(t, {title = tolazy(total), mrl = url2, image = '#self/movie.png'})

     end  
  

     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/collaps.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://mylam.ru')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'https://mylam.ru')
    
       t['view'] = 'list'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3, image = '#self/movie.png'})

       
    end
end
end



elseif args.q == 'collaps2' then

 t['view'] = 'list'
-- t['image'] = 'https://mir-s3-cdn-cf.behance.net/projects/max_808/74ce85146344181.Y3JvcCw5NjEsNzUxLDAsMTIz.png'







local x = conn:load('https://api.bhcesh.me/franchise/details?token=d39edcf2b6219b6421bffe15dde9f1b3&kinopoisk_id=' .. args.id3)

 
   local iframe = string.match(x,'"id".-"iframe_url":".-(/embed.-)"')



--https://api.femd.ws/embed/movie/87442?oneSound=WinMedia&sharing=false&host=kinotik.top

local x = conn:load('https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top')

--table.insert(t, {title = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top', mrl = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top'})

x = string.gsub(x, '\\u0026', '&')

    x = string.gsub(x, '\\"', '')


local down = string.match(x,'download:.-"(http.-)"')


local hls = string.match(x,'hls:.-"(http.-)"')


local title = string.match(x,'hls.-audio:.-%["(.-)"') 



if title then

local x = conn:load(hls)

local total = string.match(x, '#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total then

--t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title), mrl = down .. '&audio=' .. total, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title), mrl = down .. '&video=v2&audio=' .. total, image = '#self/movie.png'})

end
end


local title1 = string.match(x,'hls.-audio:.-%[".-".-"(.-)"') 

if title1 then

local x = conn:load(hls)

local total1 = string.match(x, 'm3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total1 then

--t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title1), mrl = down .. '&audio=' .. total1, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title1), mrl = down .. '&video=v2&audio=' .. total1, image = '#self/movie.png'})



end
end




local title2 = string.match(x,'hls:.-audio:.-%[".-".-".-".-"(.-)"') 

if title2 then

local x = conn:load(hls)

local total2 = string.match(x, 'm3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total2 then

--t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title2), mrl = down .. '&audio=' .. total2, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title2), mrl = down .. '&video=v2&audio=' .. total2, image = '#self/movie.png'})


end
end




local title3 = string.match(x,'hls:.-audio:.-%[".-".-".-".-".-".-"(.-)"')

if title3 then

local x = conn:load(hls)

local total3 = string.match(x, 'm3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total3 then

table.insert(t, {title = '720p ' .. tolazy(title3), mrl = down .. '&audio=' .. total3, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title3), mrl = down .. '&video=v2&audio=' .. total3, image = '#self/movie.png'})


end
end


local title4 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-"(.-)"') 

if title4 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total4 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total4 then

table.insert(t, {title = '720p ' .. tolazy(title4), mrl = down .. '&audio=' .. total4, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title4), mrl = down .. '&video=v2&audio=' .. total4, image = '#self/movie.png'})
 
  end
   end


local title5 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title5 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total5 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total5 then

table.insert(t, {title = '720p ' .. tolazy(title5), mrl = down .. '&audio=' .. total5, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title5), mrl = down .. '&video=v2&audio=' .. total5, image = '#self/movie.png'})

  end
   end


local title6 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title6 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total6 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total6 then

table.insert(t, {title = '720p ' .. tolazy(title6), mrl = down .. '&audio=' .. total6, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title6), mrl = down .. '&video=v2&audio=' .. total6, image = '#self/movie.png'})

  end
   end

local title7 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title7 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total7 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total7 then

table.insert(t, {title = '720p ' .. tolazy(title7), mrl = down .. '&audio=' .. total7, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title7), mrl = down .. '&video=v2&audio=' .. total7, image = '#self/movie.png'})

  end
   end

local title8 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title8 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total8 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total8 then

table.insert(t, {title = '720p ' .. tolazy(title8), mrl = down .. '&audio=' .. total8, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title8), mrl = down .. '&video=v2&audio=' .. total8, image = '#self/movie.png'})

  end
   end
   
local x = conn:load('https://api.bhcesh.me/franchise/details?token=d39edcf2b6219b6421bffe15dde9f1b3&kinopoisk_id=' .. args.id3)

 
   local iframe = string.match(x,'"id".-"iframe_url":".-(/embed.-)"')



--https://api.femd.ws/embed/movie/87442?oneSound=WinMedia&sharing=false&host=kinotik.top

local x = conn:load('https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top')

--table.insert(t, {title = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top', mrl = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top'})

x = string.gsub(x, '\\u0026', '&')

    x = string.gsub(x, '\\"', '')


local season = string.match(x,'seasons:%[(.-)]}]')

if season then

for total, url in string.gmatch(season, '"duration".-"title":"(.-)".-"download":"(http.-)"') do

	
--	t['view'] = 'simple'
	
table.insert(t, {title = tolazy(total), mrl = url, image = '#self/movie.png'})

  end
 end
 


elseif args.q == 'collaps-dash' then
  
 

  local x = conn:load('http://178.20.46.40:12600/lite/collaps-dash?kinopoisk_id=' .. args.id3)



   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end


elseif args.q == 'kinotochka' then
  
 

--https://kinovibe.vip/embed/8003

 local url = 'https://kinovibe.cc/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3
--https://kinovibe.co/embed/kinopoisk/386/


  
-- local url = 'https://kinovibe.cc/?do=search&mode=advanced&subaction=search&story=' .. urlencode(args.id1)

		
		local x = conn:load(url)
		
       
			x = string.gsub(x, '\\', '')
			
  
 -- https://kinovibe.vip/27131-persi-dzhekson-i-olimpiycy-2-sezon-2025.html
 
 
  
  local url1 = string.match(x,'"url":"(http.-)"')
  
 -- elseif args.q == 'kinotochkav' then
  
  

    local x = conn:load(url1)

local url, url1 = string.match(x, 'Playerjs.-file:"(http.-video_mp4)(.-mp4)')

			
t['view'] = 'list'

 table.insert(t, {title = 'Смотреть', mrl = url .. url1, image = '#self/movie.png'})



for url in string.gmatch(x, 'Playerjs.-file:"(http.-_480.mp4)') do

			
t['view'] = 'list'

 table.insert(t, {title = '480p', mrl = url, image = '#self/movie.png'})


url = string.gsub(url, '_480.mp4', '_720.mp4')
			
t['view'] = 'list'
 
 table.insert(t, {title = '720p', mrl = url, image = '#self/movie.png'})



end
    



 for url in string.gmatch(x, 'Playerjs.-file:"(http.-txt)"') do

   local x = conn:load(url)

--table.insert(t, {title = url, mrl = url})

--x = string.gsub(x, '[480,720]', '')


for total, title, url1 in string.gmatch(x,'"comment":"(.-Серия).-(%[.-])".-"file":"(http.-/s%d+e%d+)%_.-"') do



t['view'] = 'list'
  
  table.insert(t, {title =  '(' .. '480' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_480.mp4', image = '#self/movie.png'})


table.insert(t, {title = '(' .. '720' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_720.mp4', image = '#self/movie.png'})



end




local x = conn:load(url)

  for title, url2, url3, url4 in string.gmatch(x,'"comment":".-(%[.-])".-"file":"(http.-/s)(%d+)e(%d+)%.mp4"') do
  
  t['view'] = 'list'


table.insert(t, {title = 'Сезон ' .. url3.. ' ' .. 'серия ' .. url4 .. title, mrl = url2 .. url3 .. 'e' .. url4 .. '.mp4', image = '#self/movie.png'})


end
end

--https://beta.mitsu.tv/api/lite/kinoflix?iframe=https://videodb.stream/play/a11e592462863b6c0086d568b8207109?type=movie&id=348

--https://nexsw.stull.xyz/lite/kinoflix?link=/movie/49738/avatar-fire-and-ash&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl

--https://juija.manhan.one/lite/kinoflix?id=49738&title=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%9F%D0%B5%D0%BF%D0%B5%D0%BB&year=2025&account_email=rsmail@ukr.net


--http://31.129.234.181:80/lite/kinoflix?kinopoisk_id=570402&title=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%9F%D0%B5%D0%BF%D0%B5%D0%BB&year=2025&uid=guest

--https://kinoflix.tv/movie/49738/avatar-fire-and-ash

--https://api.themoviedb.org/search/movie?api_key=4ef0d7355d9ffb5151e987764708ce96&query=Чужой



elseif args.q == 'kinoflix' then



 local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru')
 
-- table.insert(t, {title = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru', mrl = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru'})

--https://videodb.cloud/embed/splayer.php?type=serial&id=
 
 for id, title, year in string.gmatch(x,'%[{"id":(.-),"title":"(.-)".-"subtitle":"(.-)".-"mediaType":"movie"') do
 
 if id then

 local x = conn:load('https://videodb.cloud/embed/player.php?type=movie&id=' .. id .. '&lang=ru')

--table.insert(t, {title = 'https://videodb.cloud/embed/player.php?type=movie&id=' .. id, mrl = 'https://videodb.cloud/embed/player.php?type=movie&id=' .. id})

--local file = string.match(x,'"file":"(.-)"')

if x then

for qual, url in string.gmatch(x,'"file".-%[(.-)]{Русский}(http.-);') do


url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=')

t['view'] = 'list'

 
 table.insert(t, {title = title .. ' (' .. year .. ')', mrl = url, image = '#self/movie.png'})
 

--local x = conn:load('https://videodb.stream/file/play?type=movie&id=1212763&name=slug&lang=ru&p=l.playlist'

end

--local iframe = string.match(x,'<iframe.-src="(http.-txt)"')

-- local x = conn:load(iframe)

--local playlist = string.match(x,'file: "(http.-playlist)"')

--local x = conn:load(playlist)

local headers = {
["Pragma"] = "no-cache",
["Cache-Control"] = "no-cache",
["sec-ch-ua"] = '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
["sec-ch-ua-mobile"] = "?0",
["sec-ch-ua-platform"] = "Windows",
["DNT"] = "1",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,uk-UA;q=0.8,uk;q=0.7,en-US;q=0.6,en;q=0.5",
["Priority"] = "u=1, i",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-origin",
["Sec-Fetch-Storage-Access"] = "active",
["Referer"] = iframe
}




--local txt = string.match(x,'"file":"(http.-txt)"')

--local x = http.getz('https://api.potok.rip/api/proxy?url=' .. txt, headers)

--table.insert(t, {title = x, mrl = x})

--table.insert(t, {title = 'https://api.potok.rip/api/proxy?url=' .. txt, mrl = 'https://api.potok.rip/api/proxy?url=' .. txt})

--for url in string.gmatch(x,'#EXT%-X%-MEDIA.-NAME="Russian.-LANGUAGE="ru".-URI="(/m3/.-)"') do

--url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=https://videodb.stream') 
--.. '#.m3u8'

--local x = http.getz('https://videodb.stream' .. url, headers)

--table.insert(t, {title = x, mrl = x})

--end

--for qual, url in string.gmatch(x,'#EXT%-X%-STREAM%-INF.-RESOLUTION=.-x(.-),.-AUDIO.-(/m3/.-)\n') do

--url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=https://videodb.stream') .. '#.m3u8'

--local x = http.getz('https://videodb.stream' .. url, headers)

--table.insert(t, {title = x, mrl = x})


--table.insert(t, {title = qual .. 'p', mrl = url})

--end


end
end
end

--/embed/splayer.php?type=serial&id=${query.tmdbId}


 local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru')
 
-- table.insert(t, {title = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru', mrl = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru'})

--https://videodb.cloud/embed/splayer.php?type=serial&id=
 
 local id = string.match(x,'%[{"id":(.-),"title":".-".-"subtitle":".-".-"mediaType":"tv"')
 
 if id then

 local x = conn:load('https://videodb.cloud/embed/splayer.php?type=serial&id=' .. id)
 
 --table.insert(t, {title = 'https://videodb.cloud/embed/splayer.php?type=serial&id=' .. id, mrl = 'https://videodb.cloud/embed/splayer.php?type=serial&id=' .. id})
 
 if x then
 
 -- for season, folder in string.gmatch(x,'title":"(Сезон.-)".-"folder":%[(.-)%]%},') do 
  
  for seria, url, url1, url2 in string.gmatch(x,'"title":"(Серия.-)".-"file".-{Русский}(http.-/SE)(.-)(/.-);') do
 
 
 url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=') .. url1 .. url2

t['view'] = 'list'

 
 table.insert(t, {title = 'Сезон ' .. url1 .. ' ' .. seria, mrl = url, image = '#self/movie.png'})
 
end
end
 end
-- end
-- end
 
 

--https://beta.mitsu.tv/api/lite/kinoflix?kinopoisk_id=5463793&title=%D0%97%D0%BB%D0%BE%D0%B2%D0%B5%D1%89%D0%B8%D0%B5+%D0%BC%D0%B5%D1%80%D1%82%D0%B2%D0%B5%D1%86%D1%8B%3A+%D0%9F%D0%B5%D0%BA%D0%BB%D0%BE&year=2026

local x = conn:load('https://beta.mitsu.tv/api/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
 
 --local x = conn:load('https://lam5.akter-black.com/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')
 
 
 x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '\\u002B', '+')
x = string.gsub(x, '&quot;', '"')
 
 
--table.insert(t, {title = 'https://beta.mitsu.tv/api/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lam5.akter-black.com/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m'})

for url, title in string.gmatch(x, 'videos__item videos__movie.-method.-play.-url.-(http.-m3u8).-videos__item%-title.->(.-)<') do

t['view'] = 'list'

 table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})

end






for url, year, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"link".-"url".-(http.-)".-"year":(.-),.-videos__season%-title">(.-)<') do

if year then

 
    local x1 = conn:load(url)
  if x1 then  
    
x1 = string.gsub(x1, '&quot;', '"')
x1 = string.gsub(x1, '\\u0026', '&')
 x1 = string.gsub(x1, '\\u002B', '+')

for url1, total in string.gmatch(x1, '<div class="videos__item videos__movie.-"method".-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'list'

 table.insert(t, {title = title .. ' (' .. year .. ')', mrl = url1, image = '#self/movie.png'})

end
end
end
end

--local x = conn:load('https://lam5.akter-black.com/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')
 
-- x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '&quot;', '"')

for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"link".-url.-(http.-)".-videos__season%-title.->(Сезон.-)<') do


--table.insert(t, {title = url, mrl = url})


local x1 = conn:load(url)

if x1 then

 x1 = string.gsub(x1, '&quot;', '"')
x1 = string.gsub(x1, '\\u0026', '&')
 x1 = string.gsub(x1, '\\u002B', '+')

for url1, total in string.gmatch(x1, '<div class="videos__item videos__movie.-"method".-"play".-"url".-(http.-)".-class="videos__item%-title.->(Серия.-)<') do

t['view'] = 'list'

 table.insert(t, {title = title .. ' ' .. total, mrl = url1, image = '#self/movie.png'})

end
end
end




for total, url, title in string.gmatch(x, 'quality.-{"(.-)":"(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end

for total, url, title in string.gmatch(x, 'quality.-/proxy.-,"(.-)":"(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end


for total, url, title in string.gmatch(x, 'quality.-/proxy.-/proxy.-,"(.-)":"(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'list'

 table.insert(t, {title = total .. ' ' .. title, mrl = url, image = '#self/movie.png'})

end

--end






elseif args.q == 'vibix' then


local x = conn:load('http://nnmtv.pw/fork/portal/kinozal.php')

local fork = string.match(x, 'search_on.-"playlist_url".-(http.-)/fxml')

fork = string.gsub(fork, '\\', '')

local x = conn:load(fork .. '/lite/vibix?kinopoisk_id=' .. args.id3 .. '&uid=guest')



 if x then
 
 x = string.gsub(x, '\\u0026', '&')

 
 
 for quality, title in string.gmatch(x, 'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
  for qual, url in string.gmatch(quality, '"(%d+p)":.-http.-(/lite.-)"') do
    

  t['view'] = 'list'


 table.insert(t, {title = qual .. ' ' .. title, mrl = fork .. url, image = '#self/movie.png'})

end
end
end  


 
 local x = conn:load(fork .. '/lite/vibix?kinopoisk_id=' .. args.id3 .. '&uid=guest')
  if x then
  
    for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)<') do

 
local x = conn:load(fork .. url .. '&uid=guest')
 
 
 x = string.gsub(x, '\\u0026', '&')
 
for quality, title1 in string.gmatch(x, 'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
  for qual, url1 in string.gmatch(quality, '"(%d+p)":.-http.-(/lite.-)"') do
    

  t['view'] = 'list'

 table.insert(t, {title = qual .. ' ' .. title .. ' ' .. title1, mrl = fork .. url1, image = '#self/movie.png'})

  end
 end
 end
 end




elseif args.q == 'vibixy' then

--https://api.manhan.one/lite/vibix/video.m3u8?id=yOZH8-aITUVYstxy5YL4epTadJ889APSj_wBORMUqjprhZS0bE07NhlCFw62uAKTNhlWfcLZVy9noUwHe-muutsdkGvDPujwY9yB14ut4UjHLayS0NUVwFcuauA5-kNik6dhZOnLGrX1R34qPs9CXj2COLPaxEgHtsL7jMt1wRz_5SjmFEM12ZRAbS27yH_7&account_email=rsmail@ukr.net
 
 local x = conn:load('https://api.manhan.one/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
--local x = conn:load('https://lam10.akter-black.com/lite/vibix?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&uid=hobqwt4m')


 if x then
 
 x = string.gsub(x, '\\u0026', '&')
-- x = string.gsub(x, '0&referer', '1&referer')
 
-- x = string.gsub(x, '&account', '?kp=' .. args.id3 .. '&domain=kinobaza.vercel.app&parent_domain=kinobaza.vercel.app&account')
 
 
 for quality, title in string.gmatch(x, 'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
  for qual, url in string.gmatch(quality, '"(%d+p)":.-(http.-)"') do
    

  t['view'] = 'list'


 table.insert(t, {title = qual .. ' ' .. title, mrl = url, image = '#self/movie.png'})

end
end
end  

local x = conn:load('https://api.manhan.one/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
 --local x = conn:load('https://lam10.akter-black.com/lite/vibix?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&uid=hobqwt4m')
  if x then
  
    for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do


 local x = conn:load(url .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
--local x = conn:load(url .. '&uid=hobqwt4m')
 
 
 x = string.gsub(x, '\\u0026', '&')
 
for quality, title1 in string.gmatch(x, 'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
  for qual, url1 in string.gmatch(quality, '"(%d+p)":.-(http.-)"') do
    

  t['view'] = 'list'

 table.insert(t, {title = qual .. ' ' .. title .. ' ' .. title1, mrl = url1, image = '#self/movie.png'})

  end
 end
 end
 end
  




elseif args.q == 'alloha' then

local seri = 'https://apivb.com/api/filter.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3

local c = http.get(seri)

local type = string.match(c, '"type":"(movie)"')

if type then

local api = 'https://api.alloha.tv/?token=de19b0b4e75ce15a9be8e63c0f5858&kp=' .. args.id3

--table.insert(t, {title = api, mrl = api})


local x = http.get(api)

local kp, image, episodes = string.match(x, '"id_kp":(.-),.-"poster":"(http.-)".-"translation_iframe":{(.-)}}')

image = string.gsub(image, '\\', '')

if episodes then


for voice, tokmov, tr in string.gmatch(episodes, '{"name":"(.-)".-"iframe":"http.-token_movie=(.-)&translation=(.-)&') do

voice = string.gsub(voice, '^(.-)', '{"name":"') .. '"}'

local v = json.decode(voice)

local voice = v['name']


--local url1 = 'https://kinozentv.com/api/alloha-tree/' .. args.id

--table.insert(t, {title = url1, mrl = url1})



--local x = http.getz(url1)


--local kp, kind, episodes = string.match(x, '"kp_id":(.-),.-"kind":"(movie)".-"episodes":%[(.-)]}]')

--if kind then

--for voice, tokmov, tr in string.gmatch(episodes, '{"voice":"(.-)".-"iframe.-http.-token_movie=(.-)&.-translation=(.-)"') do

--for qual, tokmov, tr in string.gmatch(qualities, '{"quality":"(%d+p)".-"iframe.-http.-token_movie=(.-)&.-translation=(.-)"') do


--local url2 = 'https://kinozentv.com/api/alloha-playback/start/' .. args.id .. '?move_id=' .. id .. '&q=' .. qual

local url2 = 'https://tv.alcopa.cc/lite/alloha/stream.m3u8?kinopoisk_id=' .. kp .. '&token_movie=' .. tokmov .. '&t=' .. tr .. '&q=auto'



	t['view'] = 'list'
	

table.insert(t, {title = voice, mrl = url2, image = image})


end
end
end

local seri = 'https://apivb.com/api/filter.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3

local c = http.get(seri)

local type = string.match(c, '"type":"(serial)"')

if type then

local api = 'https://api.alloha.tv/?token=de19b0b4e75ce15a9be8e63c0f5858&kp=' .. args.id3

--table.insert(t, {title = api, mrl = api})


local x = http.get(api)

local kp, image, seasons = string.match(x, '"id_kp":(.-),.-"poster":"(http.-)".-"seasons"(.-)"translation_iframe"')

--table.insert(t, {title = seasons, mrl = seasons})


image = string.gsub(image, '\\', '')


if seasons then

for voice, tokmov, tr, sez, epi in string.gmatch(seasons, '{"translation":"(.-)".-"iframe".-http.-token_movie=(.-)&translation=(.-)&season=(.-)&episode=(.-)&') do

voice = string.gsub(voice, '^(.-)', '{"name":"') .. '"}'

local v = json.decode(voice)

local voice = v['name']

--for voice, tokmov, sez, epi, tr in string.gmatch(episodes, '{"voice":"(.-)".-"iframe.-http.-token_movie=(.-)&.-&season=(.-)&episode=(.-)&translation=(.-)"') do


local url2 = 'https://tv.alcopa.cc/lite/alloha/stream.m3u8?kinopoisk_id=' .. kp .. '&token_movie=' .. tokmov .. '&s=' .. sez .. '&e=' .. epi .. '&t=' .. tr .. '&q=auto'



	t['view'] = 'list'
	

table.insert(t, {title = 'Сезон '.. sez .. ' серия ' .. epi .. ' ' .. voice, mrl = url2, image = image})

end
end
end


  
 
 
 --https://kinozenhd.com/search?q=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9

elseif args.q == 'kinozen' then

--local url = 'https://kinozenhd.com/search?q=' .. urlencode(args.id1)

local url = 'https://kinozentv.com/api/graphql'

local headers = {
    ["Host"] = "kinozentv.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "application/json",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://kinozentv.com/",
    ["content-type"] = "application/json",
    ["x-apollo-operation-name"] = "QuickSearch",
    ["Content-Length"] = "",
    ["Origin"] = "https://kinozentv.com",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1785557337$o2$g1$t1785558906$j60$l0$h0; _ga=GA1.1.731350005.1785517557; _ym_uid=1785517560813624399; _ym_d=1785517560; _ym_isad=2; kz_rec_session=9d3debe8-dda6-43dd-a6b5-24c1a0f28386; _ym_visorc=w; _pow=0558d2ba6d620b6a18151fc646ffd44cd3d38fee1b4b1487; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTczODQsImV4cCI6MTc4NTY0Mzc4NH0.vM0PjntrT2TxdzGymyFirilB7TIW1s7ZqS9ML9LfI7jwZoP2wToi2LzyyK5j_r6_; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiM2YwMGI5ZGItNzUzNS00NzBhLWJkOTItMTBkNzQwOTcwNWU5IiwiaWF0IjoxNzg1NTU3Mzg0LCJleHAiOjE3ODgxNDkzODR9.cuIsJ6Gv9QvDxn2Kc_h2uLqFWgh0wVnpBNHSSPoXSrQZ61_Par6yWTcUvgz8gJAqQYLr4YzUEKZ47NnBox1kFQ",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}


local params = [[{"query":"query QuickSearch($q: String!) {\n searchMovies(\n query: $q\n limit: 12\n ) {\n slug_url\n type\n\n title {\n russian\n original\n }\n\n poster {\n poster_kp\n local_kp\n }\n\n year\n\n rating {\n kinopoisk {\n value\n }\n }\n\n actors {\n person {\n id\n name\n originalName\n\n poster {\n poster_kp\n local_kp\n }\n }\n }\n }\n\n searchPersons(\n query: $q\n limit: 4\n ) {\n id\n name\n originalName\n\n poster {\n poster_kp\n local_kp\n }\n\n movieCount\n }\n }","variables":{"q":"]] .. args.id1 .. [["},"operationName":"QuickSearch"}]]




local x = http.postz(url, headers, params)


--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})


 for id, type, name, year in string.gmatch(x, '{"slug_url":"(.-)".-"type":"(.-)".-"russian":"(.-)".-"year":(.-),') do

	
	t['view'] = 'simple'
	
	table.insert(t, {title = name .. ' ' .. year, mrl = '#stream/q=kinozentv&id=' .. id .. '&id1=' .. type})

table.insert(t, {title = 'Vibix ' .. name .. ' ' .. year, mrl = '#stream/q=kinozentvib&id=' .. id .. '&id1=' .. type})

end

elseif args.q == 'kinozentvib' then



local headerss = {
    ["Host"] = "kinozenhd.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://kinozenhd.com/" .. args.id1 .. "/" .. args.id,
    ["Content-Type"] = "application/json",
    ["Origin"] = "https://kinozenhd.com",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1787369344$o2$g0$t1787369344$j60$l0$h0; _ga=GA1.1.2092185324.1786808761; _ym_uid=1786808762143794613; _ym_d=1786808762; _ym_isad=2; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4",
    ["Content-Length"] = "0"
}


    local headers = {
    ["Host"] = "kinozenhd.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",

    ["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1785557337$o2$g1$t1785558906$j60$l0$h0; _ga=GA1.1.731350005.1785517557; _ym_uid=1785517560813624399; _ym_d=1785517560; _ym_isad=2; kz_rec_session=9d3debe8-dda6-43dd-a6b5-24c1a0f28386; _ym_visorc=w; _pow=0558d2ba6d620b6a18151fc646ffd44cd3d38fee1b4b1487; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTczODQsImV4cCI6MTc4NTY0Mzc4NH0.vM0PjntrT2TxdzGymyFirilB7TIW1s7ZqS9ML9LfI7jwZoP2wToi2LzyyK5j_r6_; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiM2YwMGI5ZGItNzUzNS00NzBhLWJkOTItMTBkNzQwOTcwNWU5IiwiaWF0IjoxNzg1NTU3Mzg0LCJleHAiOjE3ODgxNDkzODR9.cuIsJ6Gv9QvDxn2Kc_h2uLqFWgh0wVnpBNHSSPoXSrQZ61_Par6yWTcUvgz8gJAqQYLr4YzUEKZ47NnBox1kFQ"
}


--https://proxy4.rte.net.ru/

--local cold = 'https://kinozenhd.com/api/cold-prefetch/' .. args.id
--.. '?force=1&reason=hls_manifest'

table.insert(t, {title = 'https://kinozenhd.com/api/cold-prefetch/' .. args.id, mrl = 'https://kinozenhd.com/api/cold-prefetch/' .. args.id})

local x = http.postz('https://kinozenhd.com/api/cold-prefetch/' .. args.id, headers)

--if x then

--local media = 'https://kinozenhd.com/api/media-tree/' .. args.id

--local x = http.getz(media, headers)

--url = url_for()

--url = urldecode(url)

table.insert(t, {title = x, mrl = x})

--table.insert(t, {title = media, mrl = media})

--end



elseif args.q == 'kinozentv' then








local headers = {
["Pragma"] = "no-cache",
["Cache-Control"] = "no-cache",
["sec-ch-ua"] = '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
["sec-ch-ua-mobile"] = "?0",
["sec-ch-ua-platform"] = "Windows",
["DNT"] = "1",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,uk-UA;q=0.8,uk;q=0.7,en-US;q=0.6,en;q=0.5",
["Priority"] = "u=1, i",
    ["Cookie"] = "_ym_uid=1785518434798914300; _ym_d=1785518434; _ym_isad=2; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTQ5OTUsImV4cCI6MTc4NTY0MTM5NX0.uEmKY2reEyjfq7sAsnPIKS3BcYiouMaoMCRtj4NR6hUOLy1lJFr3l9VPXP1VvGCk; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiMjI4NWNkZWItODljZS00NDIxLWJmNjEtZWRhMjQzOGQwNGMzIiwiaWF0IjoxNzg1NTU0OTk1LCJleHAiOjE3ODgxNDY5OTV9.SrqdAB7uXNHNZjY3xUkI4b2u5bzTVlNyvCapakcapvv1tNdMBpNqNa_UhAFw2cjGzGY5P6c3XdKqRmnxR5UAYA; kz_rec_session=37cd0eb3-3199-4128-b24a-262910f4fbe9; _pow=ea40524e6453a3660e1857eedecad8ab5bab81313999c261; _ym_visorc=w",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-origin",
["Sec-Fetch-Storage-Access"] = "active",
["Referer"] = "https://kinozentv.com/" .. args.id1 .. "/" .. args.id
}


    
local headerss = {
    ["Host"] = "kinozentv.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Referer"] = "https://kinozentv.com/" .. args.id1 .. "/" .. args.id,
["Authorization"] = "Bearer eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU5MTQ1NTQsImV4cCI6MTc4NjAwMDk1NH0.Vn1M5xXzSmJYSNIYYnMCsmnZL5NxCCkeYaXNu4hrIhnhrE7wryE-wmv0EYKmMQpt",

["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1785914549$o5$g1$t1785914574$j35$l0$h0; _ga=GA1.1.731350005.1785517557; _ym_uid=1785517560813624399; _ym_d=1785517560; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiM2YwMGI5ZGItNzUzNS00NzBhLWJkOTItMTBkNzQwOTcwNWU5IiwiaWF0IjoxNzg1NTU3Mzg0LCJleHAiOjE3ODgxNDkzODR9.cuIsJ6Gv9QvDxn2Kc_h2uLqFWgh0wVnpBNHSSPoXSrQZ61_Par6yWTcUvgz8gJAqQYLr4YzUEKZ47NnBox1kFQ; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU5MTQ1NTQsImV4cCI6MTc4NjAwMDk1NH0.Vn1M5xXzSmJYSNIYYnMCsmnZL5NxCCkeYaXNu4hrIhnhrE7wryE-wmv0EYKmMQpt; _ym_isad=2; kz_rec_session=e2c2ed68-0aac-4c6f-aeaf-acd25785bba1; _ym_visorc=w; _pow=7f221a6bcaceaaca2d001a87d8aebf32fd5229aa532c3f6b"
}

local url1 = 'https://kinozentv.com/api/alloha-tree/' .. args.id

local x = http.getz(url1, headerss)


local episodes = string.match(x, '{"kind":"movie","episodes":%[(.-)]}]')

for voice, qualities in string.gmatch(episodes, '{"voice":"(.-)".-"qualities":%[(.-)]') do

for qual, id in string.gmatch(qualities, '{"quality":"(%d+p)".-"move_id":"(.-)"') do




local url2 = 'https://kinozentv.com/api/alloha-playback/start/' .. args.id .. '?move_id=' .. id .. '&q=' .. qual

--https://api.potok.rip/api/proxy?url=https://kinozentv.com/api/alloha-playback/start/54736-film-chuzhoy-1979?move_id=alloha:m:t62&q=1080p

local x = http.getz(url2, headerss)

--	t['view'] = 'simple'
	
--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url2, mrl = '#stream/q=kinozentvm&id=' .. args.id .. '&id1=' .. id .. '&id2=' .. qual})


table.insert(t, {title = x, mrl = x})

end
end

elseif args.q == 'kinozentvm' then

local headers = {
    ["Host"] = "kinozentv.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://kinozentv.com/" .. args.id1 .. "/" .. args.id,
    ["Connection"] = "keep-alive",
        ["authorization"] = "Bearer eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTQ5OTUsImV4cCI6MTc4NTY0MTM5NX0.uEmKY2reEyjfq7sAsnPIKS3BcYiouMaoMCRtj4NR6hUOLy1lJFr3l9VPXP1VvGCk",
    ["Cookie"] = "_ym_uid=1785518434798914300; _ym_d=1785518434; _ym_isad=2; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTQ5OTUsImV4cCI6MTc4NTY0MTM5NX0.uEmKY2reEyjfq7sAsnPIKS3BcYiouMaoMCRtj4NR6hUOLy1lJFr3l9VPXP1VvGCk; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiMjI4NWNkZWItODljZS00NDIxLWJmNjEtZWRhMjQzOGQwNGMzIiwiaWF0IjoxNzg1NTU0OTk1LCJleHAiOjE3ODgxNDY5OTV9.SrqdAB7uXNHNZjY3xUkI4b2u5bzTVlNyvCapakcapvv1tNdMBpNqNa_UhAFw2cjGzGY5P6c3XdKqRmnxR5UAYA; kz_rec_session=37cd0eb3-3199-4128-b24a-262910f4fbe9; _pow=ea40524e6453a3660e1857eedecad8ab5bab81313999c261; _ym_visorc=w",
["Content-Type"] = "application/json",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4",
   ["Pragma"] = "no-cache",
   ["Cache-Control"] = "no-cache"
}

local graphql = 'https://kinozentv.com/api/graphql'


local params = [[{"query":"mutation RecordWatchProgress(\n $slug: NonEmptyString!\n $progressSec: Int!\n $durationSec: Int\n $seasonNumber: Int\n $episodeNumber: Int\n ) {\n recordWatchProgress(\n slug: $slug\n progressSec: $progressSec\n durationSec: $durationSec\n seasonNumber: $seasonNumber\n episodeNumber: $episodeNumber\n )\n }","variables":{"slug":"]] .. args.id .. [[","progressSec":30,"durationSec":6975,"seasonNumber":null,"episodeNumber":null},"operationName":"RecordWatchProgress"}]]




local x = http.postz(graphql, headers, params)


local url = 'https://kinozentv.com/api/alloha-playback/start/' .. args.id .. '?move_id=' .. args.id1 .. '&q=' .. args.id2

local x = http.getz(url, headers)

local url1 = string.match(x,'(/media.-m3u8)')

local x = http.getz('https://kinozentv.com' .. url1, headers)


--url = url_for(x)

--url = urldecode(url)

table.insert(t, {title = 'https://kinozenhd.com' .. url1, mrl = 'https://kinozenhd.com' .. url1})

local url2 = string.match(x,'(/media/alloha/object/.-)\n')

--local x = conn:load('https://kinozentv.com' .. url2)





--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})



local x = http.getz('https://kinozentv.com' .. url2, headers)

local url3 = string.match(x,'(/media/alloha/object/.-)"') 

local x = http.getz('https://kinozenhd.com' .. url3, headers)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})
--t['view'] = 'simple'



--table.insert(t, {title = 'https://kinozenhd.com' .. url1, mrl = 'https://kinozenhd.com' .. url1})

--table.insert(t, {title = 'https://kinozenhd.com' .. url2, mrl = 'https://kinozenhd.com' .. url2})

table.insert(t, {title = 'https://kinozentv.com' .. url3, mrl = 'https://kinozentv.com' .. url3})


elseif args.q == 'vibexx' then
 
 
 local x = conn:load('https://lampa.li/lite/vibix?kinopoisk_id=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 --table.insert(t, {title = 'https://lampa.li/lite/vibix?kinopoisk_id=' .. args.id3 .. '&uid=bwygkgxn', mrl = 'https://lampa.li/lite/vibix?kinopoisk_id=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'})
 
 --x = string.gsub(x, '&quot;', '"')

 
 for stream, title in string.gmatch(x,'<div class="videos__item videos__movie.-method.-streamquality(.-)].-videos__item%-title.->(.-)<') do
 
 
 
 for qual, url in string.gmatch(stream, 'quality.-(%d+p).-url.-(http.-)&#') do
 
 t['view'] = 'list'

 table.insert(t, {title = '(' .. qual .. ') ' .. title, mrl = url, image = '#self/movie.png'})

end
end

x = string.gsub(x, '\\u0026', '&')

for season, title in string.gmatch(x,'<div class="videos__item videos__season.-method.-link.-(http.-)&#.-videos__season%-title">(.-)<') do

local x = conn:load(season .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

for stream, title1 in string.gmatch(x,'<div class="videos__item videos__movie.-method.-streamquality(.-)].-videos__item%-title.->(.-)<') do
 
 
 
 for qual, url in string.gmatch(stream, 'quality.-(%d+p).-url.-(http.-)&#') do
 
 t['view'] = 'list'

 table.insert(t, {title = '(' .. qual .. ') ' .. title .. ' ' .. title1, mrl = url, image = '#self/movie.png'})

end
end
end






elseif args.q == 'fovea' then


local x = conn:load('https://api.alloha.tv/?token=de19b0b4e75ce15a9be8e63c0f5858&kp=' .. args.id3)

local imdb, tmdb = string.match(x, '"id_imdb":"(.-)".-"id_tmdb":(.-),')


if imdb then
if tmdb then

local x = conn:load('https://api.bwa.ad/lite/peregon?tmdb_id=' .. tmdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&serial=0&year=' .. args.id2 .. '&uid=LwlUto9l&nws_id=89b5d318b8effe81598e651c4f9d028e&rchtype=cors&dev4k=0&dalt=2')

--table.insert(t, {title = 'https://api.bwa.ad/lite/peregon?tmdb_id=' .. tmdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&serial=0&year=' .. args.id2 .. '&uid=LwlUto9l&nws_id=89b5d318b8effe81598e651c4f9d028e&rchtype=cors&dev4k=0&dalt=2', mrl = 'https://api.bwa.ad/lite/peregon?tmdb_id=' .. tmdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&serial=0&year=' .. args.id2 .. '&uid=LwlUto9l&nws_id=89b5d318b8effe81598e651c4f9d028e&rchtype=cors&dev4k=0&dalt=2', image = '#self/movie.png'})

--local pgt1, url1, voice1 = string.match(x, '"pgt":"(.-)".-"url":"(.-)".-"voice":"(.-)"')

local pgt, url, voice = string.match(x, '"pgt":"(.-)".-"url":"(.-)".-"voice":"(.-)"') 

if url then

local stream = string.match(url, 'http.-/stream/(.-)%.')

stream = base64_decode(stream)


local pkg, floor = string.match(stream, 'pkg=(.-)&floor=(universal)')

--if aud then
--t['view'] = 'list'

--table.insert(t, {title = floor .. ' ' .. voice, mrl = '#stream/q=foveam&id=' .. pkg .. '&id1=' .. floor .. '&id2=' .. pgt .. '&id3=' .. aud})


--elseif args.q == 'foveam' then


--pkg=movie-1368337-j14123-c0-v5&floor=universal"


local api = 'https://api.bwa.ad/pg/play'



local headers = {
["Host"] = "api.bwa.ad",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["content-type"] = "application/json",
["x-dk"] = "31a853b59516de4b82de17347400a33f9a2d81372afa6501cc9bbc4fffa3f62a",
["Content-Length"] = "",
["Origin"] = "http://lampa.mx",
["Connection"] = "keep-alive",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site",
["Priority"] = "u=4",
["TE"] = "trailers"
}

local params = '{"pkg":"' .. pkg .. '","floor":"' .. floor .. '","t":"' .. pgt .. '","s":""}'

local x = http.postz(api, headers, params)

if x then

t['view'] = 'list'

local master, master1 = string.match(x, '"master":"(.-)(master.-m3u8)"')

if master1 then


--table.insert(t, {title = master .. master1 .. '?a=' .. aud, mrl = master .. master1 .. '?a=' .. aud, image = '#self/movie.png'})


local x = conn:load(master .. master1)

for name, audi in string.gmatch(x, 'EXT%-X%-MEDIA:TYPE=AUDIO.-NAME="(.-)".-URI="r/a%-(.-)%-.-/index') do

table.insert(t, {title = name, mrl = master .. master1 .. '?a=' .. audi, image = '#self/movie.png'})

end

for qual, vid in string.gmatch(x, 'EXT%-X%-STREAM%-INF.-RESOLUTION=.-x(.-),.-(r/.-m3u8)') do

table.insert(t, {title = qual .. ' ' .. voice, mrl = master .. vid, image = '#self/movie.png'})

end
end
end
end
end
end


local x = conn:load('https://api.alloha.tv/?token=de19b0b4e75ce15a9be8e63c0f5858&kp=' .. args.id3)

x = string.gsub(x, 'amp;', '')

local tmdb = string.match(x, '"id_tmdb":(.-),')


if tmdb then

--{"iframe":"https:\/\/mars.stravers.live\/?token_movie=6c7e28d8c6176071307ebedbf73e39&season=4&token=de19b0b4e75ce15a9be8e63c0f5858","season":4,

for season, episodes in string.gmatch(x, '"season":(.-),"episodes":{(.-)}}}}}') do

--for episode in string.gmatch(episodes, '{"iframe":"http.-&episode=(.-)&') do

--if episode then

t['view'] = 'list'

local title = 'Сезон ' .. season
--.. ' серия ' .. episode

--table.insert(t, {title = title,  mrl = '#stream/q=foveas&id=' .. tmdb .. '&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3 .. '&id4=' .. season .. '&id5=' .. episode, image = '#self/movie.png'})


table.insert(t, {title = title,  mrl = '#stream/q=foveas&id=' .. tmdb .. '&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3 .. '&id4=' .. season, image = '#self/movie.png'})
--end
--end
end
end
 
elseif args.q == 'foveas' then

--local x = conn:load('https://api.bwa.ad/lite/peregon?tmdb_id=' .. tmdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&serial=1&year=' .. args.id2 .. '&uid=LwlUto9l&nws_id=89b5d318b8effe81598e651c4f9d028e&rchtype=cors&dev4k=0&dalt=2&season=' .. season .. '&episode=' .. episode)

local x = conn:load('https://api.bwa.ad/lite/peregon?tmdb_id=' .. args.id .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&serial=1&year=' .. args.id2 .. '&uid=LwlUto9l&nws_id=89b5d318b8effe81598e651c4f9d028e&rchtype=cors&dev4k=0&dalt=2&season=' .. args.id4)
--.. '&episode=' .. args.id5)



x = string.gsub(x, '],"src_seasons"', '"],"src_seasons"')



local episodes = string.match(x, '"episodes":%[(.-),"src_seasons"')

episodes = string.gsub(episodes, '^(.-)', '"')



episodes = string.gsub(episodes, ',', '","')



for episode in string.gmatch(episodes, '"(.-)"') do

if episode then

local x = conn:load('https://api.bwa.ad/lite/peregon?tmdb_id=' .. args.id .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&serial=1&year=' .. args.id2 .. '&uid=LwlUto9l&nws_id=89b5d318b8effe81598e651c4f9d028e&rchtype=cors&dev4k=0&dalt=2&season=' .. args.id4 .. '&episode=' .. episode)



for pgt, url, voice in string.gmatch(x, '"pgt":"(.-)".-"url":"(.-)".-"voice":"(.-)"') do

if url then

local stream = string.match(url, 'http.-/stream/(.-)%.')

stream = base64_decode(stream)


local pkg, floor, aud = string.match(stream, 'pkg=(.-)&floor=(universal)&a=(.-)"')

if aud then


local api = 'https://api.bwa.ad/pg/play'



local headers = {
["Host"] = "api.bwa.ad",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["content-type"] = "application/json",
["x-dk"] = "31a853b59516de4b82de17347400a33f9a2d81372afa6501cc9bbc4fffa3f62a",
["Content-Length"] = "",
["Origin"] = "http://lampa.mx",
["Connection"] = "keep-alive",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site",
["Priority"] = "u=4",
["TE"] = "trailers"
}

local params = '{"pkg":"' .. pkg .. '","floor":"' .. floor .. '","t":"' .. pgt .. '","s":""}'

local x = http.postz(api, headers, params)

if x then

t['view'] = 'list'

local master, master1 = string.match(x, '"master":"(.-)(master.-m3u8)"')

if master1 then

local title = 'Сезон ' .. args.id4 .. ' серия ' .. episode .. ' ' .. voice

--local title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. voice

table.insert(t, {title = title, mrl = master .. master1 .. '?a=' .. aud, image = '#self/movie.png'})


end
end
end
end
end
end
end






 --https://kinozenhd.com/search?q=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9

elseif args.q == 'videx' then

--https://kinozen4k.com

--https://kinozenhd.com/serial/949533-serial-kerri-2026

--local url = 'https://kinozenhd.com/search?q=' .. urlencode(args.id1)

local url = 'https://kinozenhd.com/api/graphql'

local headers = {
    ["Host"] = "kinozenhd.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "application/json",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://kinozenhd.com/",
    ["content-type"] = "application/json",
    ["x-apollo-operation-name"] = "QuickSearch",
    ["Origin"] = "https://kinozenhd.com",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1785557337$o2$g1$t1785558906$j60$l0$h0; _ga=GA1.1.731350005.1785517557; _ym_uid=1785517560813624399; _ym_d=1785517560; _ym_isad=2; kz_rec_session=9d3debe8-dda6-43dd-a6b5-24c1a0f28386; _ym_visorc=w; _pow=0558d2ba6d620b6a18151fc646ffd44cd3d38fee1b4b1487; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTczODQsImV4cCI6MTc4NTY0Mzc4NH0.vM0PjntrT2TxdzGymyFirilB7TIW1s7ZqS9ML9LfI7jwZoP2wToi2LzyyK5j_r6_; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiM2YwMGI5ZGItNzUzNS00NzBhLWJkOTItMTBkNzQwOTcwNWU5IiwiaWF0IjoxNzg1NTU3Mzg0LCJleHAiOjE3ODgxNDkzODR9.cuIsJ6Gv9QvDxn2Kc_h2uLqFWgh0wVnpBNHSSPoXSrQZ61_Par6yWTcUvgz8gJAqQYLr4YzUEKZ47NnBox1kFQ",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}


local params = [[{"query":"query QuickSearch($q: String!) {\n searchMovies(\n query: $q\n limit: 12\n ) {\n slug_url\n type\n\n title {\n russian\n original\n }\n\n poster {\n poster_kp\n local_kp\n }\n\n year\n\n rating {\n kinopoisk {\n value\n }\n }\n\n actors {\n person {\n id\n name\n originalName\n\n poster {\n poster_kp\n local_kp\n }\n }\n }\n }\n\n searchPersons(\n query: $q\n limit: 4\n ) {\n id\n name\n originalName\n\n poster {\n poster_kp\n local_kp\n }\n\n movieCount\n }\n }","variables":{"q":"]] .. args.id1 .. [["},"operationName":"QuickSearch"}]]




local x = http.post(url, headers, params)


--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = x, mrl = x})


 for id, type, name, image, year in string.gmatch(x, '{"slug_url":"(.-)".-"type":"(.-)".-"russian":"(.-)".-"local_kp":"(.-)".-"year":(.-),') do

if image then

image = string.gsub(image, '^(.-)', 'https://kinozenhd.com')
end

year = string.gsub(year, 'null', '')

	t['view'] = 'list'
	
--	table.insert(t, {title = name .. ' ' .. year, mrl = '#stream/q=kinozentv&id=' .. id .. '&id1=' .. type})

table.insert(t, {title = name .. ' ' .. year, mrl = '#stream/q=kinozentvibix&id=' .. id .. '&id1=' .. type .. '&id2=' .. image, image = image})



end





elseif args.q == 'kinozentvibix' then



--https://kinozentv.com/api/cold-prefetch/54736-film-chuzhoy-1979?force=1&reason=hls_manifest

local cold = 'https://kinozenhd.com/api/cold-prefetch/' .. args.id

local params = 'force=1&reason=hls_manifest'



local headers = {
    ["Host"] = "kinozenhd.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0",
    ["Accept"] = "*/*",
    ["Accept-Encoding"] = "deflate, gzip",
    ["Content-Type"] = "application/json",
    ["Cookie"] = "_ym_d=1786808929; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiODcxODVkMTItMzg1NS00OGM4LWJiZGEtMGVmNWRkOTQ1YzczIiwiaWF0IjoxNzkyMDYzMjY1LCJleHAiOjE3OTQ2NTUyNjV9.xDsbKtZA8OIuC2UkKziOev3I_nGTbSV3Se1hFjSvSz2WZIBLR5L6EYYVCafOVE7WBwGJDN1GUoaZyX60VrEzmA; _ym_isad=2; _pow=d87e0b2e1fcf9c01cd94ad28f6dc85902ff292f84132bc06; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3OTIwNjMyNjUsImV4cCI6MTc5MjE0OTY2NX0.IC0MfJQflnirq14mJKB9x4Kl6QTjVhmvk7qhpZwuXqJkE10kl5jIKw_5R0Cll79s; kz_rec_session=83f847aa-a741-4d2c-8553-91413f3169f9", ["Content-Length"] = "0"

}




local v = http.post(cold, headers, params)
    


local headers1 = {
    ["Host"] = "kinozenhd.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:157.0) Gecko/20100101 Firefox/157.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://kinozenhd.com/" .. args.id1 .. "/" .. args.id,
    ["Content-Type"] = "application/json",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1792040123$o8$g1$t1792040319$j60$l0$h0; _ga=GA1.1.2092185324.1786808761; _ym_uid=1786808762143794613; _ym_d=1786808762; _ym_isad=2; kz_rec_session=c5f3e79e-b243-4f16-b986-88f042c52863; _pow=6f808ab649528b966d20df6f3adf383c1c9d741d8d98b7aa; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3OTIwNDAxNzUsImV4cCI6MTc5MjEyNjU3NX0.2ZNSzuCpGkoiy8rsZYyHp7Nc1qMKnSDjpSywRz-5YyWbUoM2WYPabSpAqr0bqHol; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiNjRjMzk3NDQtNzI0Zi00OWM2LWIxNmUtMzBlYmUwN2I3YmEyIiwiaWF0IjoxNzkyMDQwMTc1LCJleHAiOjE3OTQ2MzIxNzV9.IrMs9oktfgRto4NQV0E2Ktm74QoTp5sDYUhHdHFx63IxdvtxUMZFkXqrOP113AunHPKnRzGoCO_Cc-4u1qN8zg",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache",
}



local media = 'https://kinozenhd.com/api/media-tree/' .. args.id

local x = http.getz(media, headers1)



local kp, type, episodes = string.match(x, '"kp_id":(.-),.-"kind":"(movie)".-"episodes":%[{(.-)source')

if kp then

for voice, prov, id, qualities in string.gmatch(episodes, '{"voice":"(.-)","provider":"(vibix)","move_id":"(.-)","qualities":%[(.-)]') do



for qual in string.gmatch(qualities, '"(.-)"') do

--https://kinozenhd.com/api/tv-m3u8/55119-film-f1-2025?provider=vibix&move_id=196617&q=1080p

--https://mavio.online/watch?kpId=5003510&playerId=163187

t['view'] = 'list'



table.insert(t, {title = qual .. ' ' .. voice, mrl = 'https://api.potok.rip/api/proxy?url=https://kinozenhd.com/api/tv-m3u8/' .. args.id .. '?provider=' .. prov .. '&movie_id=' .. id .. '&q=' .. qual, image = args.id2})



end
end
end




local kp, type, episodes = string.match(x, '"kp_id":(.-),.-"kind":"(series)".-"episodes":%[{(.-)source')

if kp then

--table.insert(t, {title = episodes, mrl = episodes})


for season, episode, voices in string.gmatch(episodes, '"season_n":(.-),"episode_n":(.-),.-"voices":%[(.-)}]}') do

for voice, prov, id, qualities in string.gmatch(voices, '{"voice":"(.-)","provider":"(vibix)","move_id":"(.-)","qualities":%[(.-)]') do

for qual in string.gmatch(qualities, '"(.-)"') do

--{"voice":"ColdFilm","provider":"vibix","move_id":"358234","qualities":["1080p","720p","480p","4k"]

t['view'] = 'list'

table.insert(t, {title = qual .. ' Сезон ' .. season .. ' серия ' .. episode .. ' ' .. voice, mrl = 'https://api.potok.rip/api/proxy?url=https://kinozenhd.com/api/tv-m3u8/' .. args.id .. '?provider=' .. prov .. '&movie_id=' .. id .. '&q=' .. qual, image = args.id2})

end
end
end
end






elseif args.q == 'videxzzz' then
 


local x = conn:load('https://api.alloha.tv/?token=de19b0b4e75ce15a9be8e63c0f5858&kp=' .. args.id3)

local imdb, tmdb = string.match(x, '"id_imdb":"(.-)".-"id_tmdb":(.-),')


if imdb then
if tmdb then


lampa = string.gsub(tmdb,'^(.-)','http://lampa.mx/?card=') .. '&media=movie&source=tmdb'


lampa = base64.encode(lampa)

lampa = urlencode(lampa)


local headerss = {
    ["Host"] = "api.lampa.stream",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "cf_clearance=OOYmoeM_PmBabhVZv4KVB83PiYN1Y5CDwZtIV3oi7kM-1778248424-1.2.1.1-N2lBdTioGB78gQ3NncjNIZLg4QgREKKpt084eRzADwLxOhYjJDCIDAon1uTPQC8w0o.4Hn9IbG0PJk251yXQpX4NqFoLtOf0A968CvEXsU0HFkwbNkn3jDgpyMl7MBPfYkHjS3RdRKe_XRdXKaxIH8ZcHGr0QsIzLsoan8IPVQTb_D3gEnSd06eyjA0cPqF3L7Zm6X32zuHBnT6Q15DvO3kjqbLboPz48ZnDuwKPl2KOl3cwrC9o01YKn964e1_iPWyCXVoEpZvxNmbJVWFwwNs7Ab.P2qsOjWOVA6Oh7TvMqUqCg.QQNV0bbBpBnOg.88px9FWPJcShpAsYkvSuOA",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1"
}




local headers = {["Host"] = "api.lampa.stream",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
      ["Referer"] = "http://api.lampa.stream/",
      ["Cookie"] = "cf_clearance=OOYmoeM_PmBabhVZv4KVB83PiYN1Y5CDwZtIV3oi7kM-1778248424-1.2.1.1-N2lBdTioGB78gQ3NncjNIZLg4QgREKKpt084eRzADwLxOhYjJDCIDAon1uTPQC8w0o.4Hn9IbG0PJk251yXQpX4NqFoLtOf0A968CvEXsU0HFkwbNkn3jDgpyMl7MBPfYkHjS3RdRKe_XRdXKaxIH8ZcHGr0QsIzLsoan8IPVQTb_D3gEnSd06eyjA0cPqF3L7Zm6X32zuHBnT6Q15DvO3kjqbLboPz48ZnDuwKPl2KOl3cwrC9o01YKn964e1_iPWyCXVoEpZvxNmbJVWFwwNs7Ab.P2qsOjWOVA6Oh7TvMqUqCg.QQNV0bbBpBnOg.88px9FWPJcShpAsYkvSuOA",
    ["Content-Type"] = "application/json; charset=utf-8",
    Connection = "close",
    Server = "cloudflare",
    ["Server-Timing"] = {
        'cfCacheStatus;desc="MISS"',
        "cfEdge;dur=9,cfOrigin;dur=31"
    },
    ["Vary"] = "Accept-Encoding",

    ["X-Powered-By"] = "modss",
    ["X-RateLimit-Limit"] = 40,
    ["X-RateLimit-Remaining"] = 38,
    ["X-RateLimit-Reset"] = 1778251762,
    ["X-Response-Time"] = "5.85ms",
    ["Access-Control-Allow-Headers"] = "*",
    ["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS",
    ["Content-Encoding"] = "gzip",
    ["Cache-Control"] = "max-age=86400",
    ["cf-cache-status"] = "MISS",
    ["CF-RAY"] = "9f8944c5dddf6d26-FRA"
}


--args.id1 = string.gsub(args.id1, ' ', '%%20')


--https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/807031/tt16431404/dW5kZWZpbmVk/aHR0cDovL2xhbXBhLm14Lz9jYXJkPTEzMTg0NDcmbWVkaWE9bW92aWUmc291cmNlPXRtZGI%3D?ips=2a0d:5600:9:3003:f35c:e2d8:1376:a2ad&uid=7b40eb0595118e5649d10dcda_1db58ea969d1843cbaa506a8&ip=185.228.133.239&title=На%20вершине

--https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/386/tt0078748/dW5kZWZpbmVk==/aHR0cDovL2xhbXBhLm14Lz9jYXJkPQ==?ip=185.228.133.239&title=чужой

--https://proxy4.rte.net.ru/

         local movie = 'https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/' .. args.id3 .. '/' .. imdb .. '/dW5kZWZpbmVk/' .. lampa .. '?ip=185.228.133.239&title=' .. urlencode(args.id1)



local x = conn:load(movie)



local slist = string.match(x,'"folder":%[(.-)],"duration"')


if slist then

for qual, title in string.gmatch(slist, 'method.-play.-"qualitys":{(.-)}.-"voice_name":"(.-)"') do

for total, url1 in string.gmatch(qual, '"(%d+p)":"(.-)"') do
  

  t['view'] = 'list'


--'https://proxy4.rte.net.ru/' .. 

 table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = 'https://proxy4.rte.net.ru/' .. url1, image = '#self/movie.png'})

end
end
end


lampa = string.gsub(tmdb,'^(.-)','http://lampa.mx/?card=') .. '&media=tv&source=tmdb'

lampa = base64.encode(lampa)

lampa = urlencode(lampa)


local tv = 'https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/' .. args.id3 .. '/' .. imdb .. '/dW5kZWZpbmVk/' .. lampa .. '?ip=185.228.133.239&title=' .. urlencode(args.id1)

local x = conn:load(tv)

for qual, season, episod, title in string.gmatch(x, '"method":"play","title":"Серия.-"qualitys":{(.-)}.-vast_msg.-,"season":"(.-)","episode":(.-),"voice_name":"(.-)"') do

for  total, url1 in string.gmatch(qual, '"(%d+p)":"(.-)"') do
  

  t['view'] = 'list'


--'https://proxy4.rte.net.ru/' .. 

 table.insert(t, {title = '(' .. total .. ') Сезон-' .. season .. ' серия-' .. episod .. ' ' .. title, mrl = 'https://proxy4.rte.net.ru/' .. url1, image = '#self/movie.png'})

end
end
end
end





elseif args.q == 'vibix1' then
  
  
  
--  https://reyohoho-old.onrender.com/#386
  
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  
 -- for url in string.gmatch(x, '(<option player.-</option>)') do
  
  
 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed/.-)"') do
 
 
 
--  embedCode=https://graphicslab.io/sdk/v2/rendex-sdk.min.js
 
 --https://cors.fx666.workers.dev:8443/http://91.142.72.69:9833/lite/vibix?title=чужой&year=1979 
 
 --http://fork.tutkino.fun/xml/cdn/iframe.php?link=https://667983605.videoframe2.com/embed/4539
 
 
 --http://fork.tutkino.fun/xml/cdn/iframe.php?link=https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed/4539
 
-- https://juija.manhan.one/lite/vibix/video.m3u8?play=true&url=&referer=https://667983605.videoframe2.com/api/v1/embed/4539&account_email=daniulov.d@yandex.ru&uid=zqos1vw0&nws_id=s7vl7ckpsmoejlwykybs3th4tky6f5ny
 
 --https://672431256.videoframe2.com/api/v1/embed-kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz&embedCode=https://graphicslab.io/sdk/v2/rendex-sdk.min.js


--https://m.kinobadi.im/pleer_4/pleer.php?id=/api/v1/embed/39378?domain=kino-arhiv.ucoz.club&iframe_url=https%3A%2F%2Friver-3-329.kinescopecdn.net%2F669681541%2Fembed-kp%2F5939991%3Fnc%3D491766&nc=491766

--https://m.kinobadi.im/pleer_4/pleer.php?id=/embed/4539


--https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-1-2110.kinescopecdn.net/hls/4000/4539/4539_1080p.mp4/index.m3u8

--https://river-1-2110.kinescopecdn.net/667983605/hls/4000/4539/4539_1080p.mp4/index.m3u8

--https://river-1-2110.kinescopecdn.net/hls/4000/4539/4539_1080p.mp4/index.m3u8?expires=1771002013&sign=0e528aa9c454fb4e67c4b1b887b60c49&ts=1770915600


--https://185.188.183.182/iptv/kinotochka/lesenkinolite46.php?link=https://river-3-329.kinescopecdn.net/667983605/embed/4539&nc=491748


--http://fork.tutkino.fun/xml/cdn/iframe.php?link=https://river-3-329.kinescopecdn.net/667983605/embed/4539&nc=491748

--https://cors.fx666.workers.dev:8443/https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed/4539&nc=491748
 
 --https://cors.fx666.workers.dev:8443/https://667983605.videoframe2.com/api/v1/embed-kp/386?domain=gokino.su&p=cUQROp1WbVlcWowHVUBTdwjIGg1VDF0EUoSDNUDAcczDXQQVSQVTWwTVKQ1GcthCh42SGZAHAUREgsVK&v=1
 
-- https://cors.fx666.workers.dev:8443/https://667983605.videoframe2.com/api/v1/embed/?domain=gokino.su&p=cUQROp1WbVlcWowHVUBTdwjIGg1VDF0EUoSDNUDAcczDXQQVSQVTWwTVKQ1GcthCh42SGZAHAUREgsVK&v=1
 
 
 --http://185.188.183.182/iptv/kinotochka/lesenkinolite46.php?link=https://river-3-329.kinescopecdn.net/667983605/embed/4539&page=postmd5
 
 
 
-- https://apn-latest.onrender.com/https://672431256.videoframe2.com/api/v1/embed/4539/vibixinscode.html
 
 
-- https://apn-latest.onrender.com/https://river-3-329.kinescopecdn.net/667983605/embed/4539/vibixinscode.html
 
-- https://672431256.videoframe2.com/api/v1/embed/4539/vibixinscode.html
 
 --https://672431256.videoframe2.com/embed/4539/vibixinscode.html
 
 --https://apn-latest.onrender.com/https://river-3-329.kinescopecdn.net/667983605/embed/4539
 --https://667983605.videoframe2.com/api/v1/ad-tags?domain=gokino.su&iframe_url=https%3A%2F%2F667983605.videoframe2.com%2Fembed%2F4539&nc=491705&_=5i6gi5rpqqx
 
 --https://apn-latest.onrender.com/https://672431256.videoframe2.com/api/v1/embed-kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz
 
 --https://672431256.videoframe2.com/api/v1/embed-kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz
 
 
-- https://672431256.videoframe2.com/api/v1/embed/4539?domain=reyohoho.gitlab.io&iframe_url=https://672431256.videoframe2.com/embed/4539&nc=491719

--https://neomovies.site/api/player/vibix/embed/?src=https://672431256.videoframe2.com/embed/4539&nc=491719

 
 --https://kinescope.io/embed/46wjDpcANy2CqZFg8r86Ug/720p
 
 --https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed/UUQRLlFVXYSDzUTHb92Qa1VVMkgDEsTUDQ1GcthCh42SGZAHAUREgsVK
 
 
 
 --https://672431256.videoframe2.com/api/v1/embed-serials/5523?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com/embed-serials/5523
  
--https://river-3-329.kinescopecdn.net/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed-kp/386?nc=491717&nc=491717
 

 
 
-- http://river-3-329.kinescopecdn.net/api/v1/embed/39378?domain=kino-arhiv.ucoz.club&iframe_url=https%3A%2F%2Friver-3-329.kinescopecdn.net%2F669681541%2Fembed-kp%2F5939991%3Fnc%3D491766&nc=491766
 
 
 
 --https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://667983605.videoframe2.com/embed/4539
 
-- &p=UUQRLlFVXYSDzUTHb92Qa1VVMkgDEsTUDQ1GcthCh42SGZAHAUREgsVK&v=1
 
 
 
 --https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https%3A%2F%2F667983605.videoframe2.com%2Fembed%2F4539&sig=2e46e50a334f897b7bdb7c65a9778b114114114114114114114114114114c396cec89dc8c5d29a9712dc6c8c5f4c5f4c5f493c894969ffffcaace969cc994c6d2101d5f29895fccb&ts=1771349966&nonce=k9mwi91jvte&nc=492041
 
 
 
 local x = conn:load('https://667983605.videoframe2.com/api/v1' .. url .. '?domain=gokino.su&iframe_url=https://667983605.videoframe2.com' .. url)
 
 table.insert(t, {title = 'https://667983605.videoframe2.com/api/v1' .. url .. '?domain=gokino.su&iframe_url=https://667983605.videoframe2.com' .. url, mrl = 'https://667983605.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://667983605.videoframe2.com' .. url})
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slis = string.gsub(slist, ',', '"')
 slist = string.gsub(slist, ';', '"')
 
for total, title, url in string.gmatch(slist, '%[(480p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
	
t['view'] = 'simple'
 
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 
 
for total, title, url in string.gmatch(slist, '%[(720p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"%{.-}http.-"({.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 


for total, title, url in string.gmatch(slist, '%[(1080p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end

end
    end
  
  
  
  
  
  
  
   
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  

 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed%-serials.-)"') do
 

 local x = conn:load('https://667983605.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://667983605.videoframe2.com' .. url)
  
 -- table.insert(t, {title = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url, mrl = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url})
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slist = string.gsub(slist, ',', '"')
-- slist = string.gsub(slist, ';', '"')
slist = string.gsub(slist, ']{', '"name":')
slist = string.gsub(slist, ';{', '"name1":')

-- for total1 in string.gmatch(slist, '"title":"(Сезон.-)"') do
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
    end
  end





--http://178.20.46.40:12600

--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979

--https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=386

--http://178.20.46.40:12600/lite/mirage/video?id_file=911588&token_movie=a6ef0986c7558c5792c3ad19d43611

--http://78.40.199.67:10630/lite/mirage/video?id_file=1265937&token_movie=9de4740ef5b4ff67555ff296494e31&q=1080p



--http://78.40.199.67:10630/proxy/6f687b82601c0dd158c9e0e926e86dba.m3u8



--http://78.40.199.67:10630/lite/mirage/stream.m3u8?id=1265937&q=1080p

--https://lampa.oksibutch.ru/lite/mirage/stream.m3u8?id=1265937&q=1080p


elseif args.q == 'veoveo' then
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
   
--table.insert(t, {title = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1), mrl = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1)})
      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'list'

   table.insert(t, {title = 'veoveo :' .. tolazy(total), mrl = url2, image = '#self/movie.png'})

       
    end
     
--  local x = conn:load('http://178.20.46.40:12600/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
 
 

 
 
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do
     
   --  url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600') 
     
     
     local x = conn:load(url2)

--table.insert(t, {title = url2, mrl = url2})

for  url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'list'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total4), mrl = url3, image = '#self/movie.png'})

      end 
      end


elseif args.q == 'kinopub' then
 
-- http://fxmlparsers.in.net/https://kino.pub/?code=z2ibsw9dywo0n01eeibym950w1afbtz6&act=enter
 
 
-- https://ab-ze.xyz/api/hls/alloha?type=film&kp=386&access_token=&quality=&translation=Дублированный
 
 --https://cors.bwa.workers.dev/http://fork.pet/search/result?field=title&search=%D0%93%D1%80%D0%B5%D1%88%D0%BD%D0%B8%D0%BA%D0%B8%26year%3D2025&access_token=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
-- http://go.forkplay.me?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&code=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
--  http://fxmlparsers.in.net/https://kino.pub/?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&code=9ymeff8cft97lcdjswbuww9ri9of2bh1
  
--https://cors.bwa.workers.dev/https://api.srvkp.com/v1/items/search?q=чужой&year=1979&field=title&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6
  
 -- http://parsers.appfxml.com/https://kino.pub/?cat=search&search=Чужой&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6
  
  
 --http://parsers.appfxml.com/https://kino.pub/?cat=view&id=118846&code=9ymeff8cft97lcdjswbuww9ri9of2bh1



 --https://api.pushbr.com/v1/watching?id=118846&access_token=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
 
 --https://app.service-kp.com/v1/items/search?q=чужой&year=1979&field=title&access_token=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
 --https://api.srvkp.com/v1/items/search?q=чужой&year=1979&field=title&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6
 
--http://fxmlparsers.in.net/https://kino.pub/?cat=search&search=%D0%93%D1%80%D0%B5%D1%88%D0%BD%D0%B8%D0%BA%D0%B8%26year%3D2025&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6

-- http://fxmlparsers.in.net/https://kino.pub/?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9%26year%3D1979&code=z2ibsw9dywo0n01eeibym950w1afbtz6
 
 
 --http://parsers.appfxml.com/https://kino.pub/?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9%26year%3D1979&code=9ymeff8cft97lcdjswbuww9ri9of2bh1
 

 --40163b66e658
--64517E3AF296
--st4014293570
--2732f8ed9573
 
 --http://fork.pet/library/list?title=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&year=1979&type=movie&type=serial&box_mac=st4014293570
 
--local x = conn:load('http://parsers.appfxml.com/https://kino.pub/?cat=search&search=' .. urlencode(args.id1 .. '&year=') .. args.id2 .. '&code=9ymeff8cft97lcdjswbuww9ri9of2bh1')

  local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=movie' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

--table.insert(t, {title = url1 .. '&box_mac=acace24b8434', mrl = url1 .. '&box_mac=acace24b8434'})


for url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[Воспроизвести]].-<playlist_url><!%[CDATA%[(http.-)]]') do


      local x = conn:load(url2 .. '&box_mac=acace24b8434')

 for title, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title), mrl = url3})
   
   end
   end
 end




 
 local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=serial' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

 
 
   
   for title, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   local x = conn:load(url2 .. '&box_mac=acace24b8434')
   
  for title1, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url><!%[CDATA%[(http.-)]]') do
  
  local x = conn:load(url3 .. '&box_mac=acace24b8434')
  
   for title2, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title) .. ' ' .. tolazy(title1) .. ' (' .. tolazy(title2) .. ')', mrl = url4})
   end
   end
   end
   
end
   

elseif args.q == 'kinopubtv' then
 
--https://beta.l-vid.online/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn

--https://akter-black.com/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0

--https://apn10.akter-black.com/https://api.srvkp.com/manifest/hls4/aWQ9Mjc0Nzc3NjsxNTAwNDA1OTY3OzM3MzQxODI2OzExNDMyNjU7MTc4MTk2MzMzNSZoPXFmTXRkWV80bEpsNFZSUEhwQ1N6eXcmZT0xNzgyMDQ5NzM1/1143265.m3u8?loc=ru


local url = 'https://lampa.li/lite/kinopub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
  
  x = string.gsub(x, '\\u0026', '&')


  for qual, total in string.gmatch(x, '<div class="videos__item videos__movie.-quality.-{(.-)}.-class="videos__item%-title">(.-)</div>') do
  
  --local slist = string.match(x, 'quality.-{(.-)}')
      
   for  total1, url2 in string.gmatch(qual,'(%d+p).-http.-(/proxy.-m3u8)') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
   url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     
      t['view'] = 'list'


   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total), mrl = url2, image = '#self/movie.png'})

       
    end
    end
 
 
 for  url2, total2 in string.gmatch(x, 'class=.-videos__item videos__season.-method.-url.-(http.-)&#.-videos__season%-title.->(.-сезон)<') do
 
 
 url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 

     
     local x = conn:load(url2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 x = string.gsub(x, '\\u0026', '&')
     x = string.gsub(x, '\\u002B', '+')
 
 
    for id, id1, id2, id3, total3 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-postid=(.-)&title=(.-)&.-&s=(.-)&t=(.-)&.->(.-)</div>') do


   t['view'] = 'list'

    

table.insert(t, {title = tolazy(total2) .. ' ' .. tolazy(total3), mrl = '#stream/q=kinopubs&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = '#self/movie.png'})


      end 
      end

    
    elseif args.q == 'kinopubs' then
   
   local x = conn:load('https://lampa.li/lite/kinopub?rjson=False&postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&s=' .. args.id2 .. '&t=' .. args.id3 .. '&codec=aac' .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   


    for qual, total in string.gmatch(x, '<div class="videos__item videos.-quality.-{(.-)}.-class="videos__item%-title">(.-)</div>') do
  
 -- local x = string.match(x, 'quality.-{(.-)}')
   
   for  total1, url2 in string.gmatch(qual,'(%d+p).-http.-(/proxy.-m3u8)') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
      url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     


      t['view'] = 'list'


   table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2, image = '#self/movie.png'})

       
    end
    end




--https://lamp-movie.ru/lite/kinopub?title=чужой-1979




elseif args.q == 'filmix2' then

  -- https://nexsw.stull.xyz/lite/filmix?kinopoisk_id=386&title=чужой&year=1979&account_email=daniulov.d@yandex.ru 




local x = conn:load('https://akter-black.com/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
--.. '&account_email=daniulov.d@yandex.ru')


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://nexsw.stull.xyz')
  
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
    
    --     for  total3, url4, total2 in string.gmatch(x, '"(.-p)":"http.-mp4.-(http.-mp4).-class="videos__item%-title">(.-)<') do
-- total3 = string.gsub(total3, ',"', '')
 --   t['view'] = 'simple'
--    table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
    
--end
-- end


    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
 
    
    if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
   
  if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
 
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
   
end
end
   
   
   
   
 --  https://rutube.ru/api/search/video/?content_type=video&duration=movie&query=чужой&years=1979
   
   elseif args.q == 'rutube' then


--http://78.40.195.218:9118/lite/rutubemovie?title=чужой&year=1979

		local x = conn:load('https://rutube.ru/api/search/video/?content_type=video&duration=movie&query=' .. urlencode(args.id1 .. ' ' .. args.id2))
  
  

   
   for id, title in string.gmatch(x, '{"id":"(.-)","action_reason".-"title":"(.-)"') do
   
 --  if title == args.id1 then
  
 t['view'] = 'list'

   table.insert(t, {title = title, mrl = '#stream/q=rutubes&id=' .. id, image = '#self/movie.png'})
    end
-- end
 
 elseif args.q == 'rutubes' then
 
 local x = conn:load('http://kb-team.club/msx/kinofeed/viewtube.php?id=' .. args.id)
 
       x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
	
 
 

 
-- http://kb-team.club/msx/kinofeed/viewtube.php?id=37d5799de2cf4fcc86515fa9461bd296
   
   
   for url, title in string.gmatch(x, '"action":"video.-(http.-)".-"playerLabel":"(.-)"') do
  
  url = string.gsub(url, '\\', '')
  
   
   t['view'] = 'list'
   
   table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
    end
   
   elseif args.q == 'vkmovie' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lam.akter-black.com/lite/vkmovie?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

--table.insert(t, {title = 'https://lam10.akter-black.com/lite/vkmovie?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = x, image = '#self/movie.png'})

for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
     

     url4 = string.gsub(url4, '^(.-)', 'https://lam.akter-black.com')
      url4 = string.gsub(url4, '\\u002B', '+')
       t['view'] = 'list'

   table.insert(t, {title = '(' .. total3 .. ') ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
    end
     end  


elseif args.q == 'remux' then



local x = conn:load('https://lampa.li/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

--if x then

--table.insert(t, {title = 'https://lampa.li/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn', mrl = 'http://beta.l-vid.online/lite/zona?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn'})


for url, total in string.gmatch(x, '<div class="videos__item videos__movie.-method.-stream.-(http.-)&.-videos__item%-title.->(.-)<') do

url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
t['view'] = 'list'
 
 --table.insert(t, {title = 'http://z01.online' .. url, mrl = 'http://z01.online' .. url})

table.insert(t, {title = tolazy(total), mrl = url, image = '#self/movie.png'})


     end  

--http://z01.online/lite/remux/movie?linkid=8cTT/gvBR4Km3N&quality=1080p&title=%D0%9F%D0%B5%D1%80%D0%B2%D1%8B%D0%B9+%D0%BC%D1%81%D1%82%D0%B8%D1%82%D0%B5%D0%BB%D1%8C&original_title=


--http://z01.online/lite/remux/movie?linkid=R9zZ/s1tzUV1ZS&quality=1080p&title=%d0%9f%d0%b5%d1%80%d0%b2%d1%8b%d0%b9+%d0%bc%d1%81%d1%82%d0%b8%d1%82%d0%b5%d0%bb%d1%8c%3a+%d0%9f%d1%80%d0%be%d1%82%d0%b8%d0%b2%d0%be%d1%81%d1%82%d0%be%d1%8f%d0%bd%d0%b8%d0%b5&original_title=Captain+America%3a+Civil+War&uid=bwygkgxn

		local x = conn:load('https://z01.online/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

--table.insert(t, {title = 'http://z01.online/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://z01.online/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})

      for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"link".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')
      
      

    --   url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
   
   
   
for  url3, total1 in string.gmatch(x, '<div class="videos__item videos.-"method".-"call".-"url".-(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url3 = string.gsub(url3, '\\u0026', '&')
      url3 = string.gsub(url3, '\\u002B', '+')
      
 
 
 local x = conn:load(url3)
 
       for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url4 = string.gsub(url4, '\\u0026', '&')
      url4 = string.gsub(url4, '\\u002B', '+')   
       t['view'] = 'list'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url4, image = '#self/movie.png'})

     end  
    end
end

local x = conn:load('http://z01.online/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
   
     for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"call".-"url".-(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
 
 
 local x = conn:load(url)
 
       for url2 in string.gmatch(x, '"play".-"url".-"(http.-)"') do

   url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')   
       t['view'] = 'list'
 
 table.insert(t, {title = tolazy(total), mrl = url2, image = '#self/movie.png'})

     end  
    end


   

	
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
		return video(args.url, args)
	end
	return t
end