-- anwap plugin

require('support')
--require('video')
--require('parser')
require('client')

local video = require('video')
local parser = require('parser')





local HOME = 'https://tv.anwap.today'
--local HOME = 'https://m.anwap.love'
local HOME_SLASH = HOME .. '/'

local conn = client.new()

--conn['encoding'] = 'utf-8'
conn['encoding'] = 'UTF-8'
local conn1 = client.new()
conn1['encoding'] = 'utf-8'

conn['root'] = HOME_SLASH

     
   --  local url = {'https://kinobox.tv/api/players?kinopoisk='}



--HOME = 'https://m.anwap.bio'
--HOME = 'https://m.anwap.tube'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from anwap plugin')
	return 1
end

function onUnLoad()
	print('Bye from anwap plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
    table.insert(t['menu'], {title = 'Поиск сериалов', mrl = '#folder/q=/serials/search', image = '#self/search.png'})
	
	
	-- #stream/page=2

	-- #stream/genre=/films/r3-
	-- #stream/genre=/films/p-
	-- #stream/genre=/serial/page/
	-- #stream/genre=/films/top
	-- #stream/genre=/serials/top
	-- #stream/genre=/films/collection/11
	
	-- #stream/genre=/films/collection/67
	
	
	if not args.q then
		local page = tonumber(args.page or 1)
		

		local genre = args.genre or '/'
        local url = HOME .. genre .. 'films/p-' .. tostring(page)

    local x = conn:load(url)
    
    
for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
         url = string.gsub(url, '^(.-)', HOME)
         
         
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
     
     
     
     
     
    
       
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       
  
  
--https://tv.anwap.today/films/top
  
--  local x = conn:load(HOME .. '/films/top')
  
   --   x = string.match(x, '<ul class="perehod">(.-)</ul>')
	--	for id, title in string.gmatch(x, '<a.-href="(/films/).-">(.-)</a>') do
		
	
   --   table.insert(t, {title = 'ФИЛЬМЫ :' .. title, mrl = '#stream/q=top&id=' .. id})
      
    --  end
      
      
  
 -- local x = conn:load(HOME .. '/serials/top')
  
   --   x = string.match(x, '<ul class="perehod">(.-)</ul>')
	--	for id, title in string.gmatch(x, '<a.-href="(/serials/.-)">(.-)</a>') do
		
	
   --   table.insert(t, {title = 'СЕРИАЛЫ :' .. title, mrl = '#stream/q=top&id=' .. id})
      
   --   end
      
      
      
table.insert(t, {title = 'ВСЕ ФИЛЬМЫ', mrl = '#stream/q=films&id=' .. '/films/', image = HOME .. '/style/img/films.png?w=0'})


  table.insert(t, {title = 'ФИЛЬМЫ : по жанрам', mrl = '#stream/q=genre&id=' .. '/films/genre', image = HOME  .. '/style/img/kategorii.png?w=0'})
  
       table.insert(t, {title = 'ФИЛЬМЫ : подборка', mrl = '#stream/q=collections&id=' .. '/films/collections', image = HOME  .. '/style/img/dop.png?w=0'})
       
     table.insert(t, {title = 'ФИЛЬМЫ : по годам', mrl = '#stream/q=years&id=' .. '/films/years', image = HOME .. '/style/img/raspisan.png?w=0'})
    
    table.insert(t, {title = 'ФИЛЬМЫ : по странам', mrl = '#stream/q=countries&id=' .. '/films/countries', image = HOME .. '/style/img/raspisan.png?w=0'})
    
    table.insert(t, {title = 'ВСЕ СЕРИАЛЫ', mrl = '#stream/q=serials&id=' .. '/serials/', image = HOME .. '/style/img/films.png?w=0'})
    
    
     table.insert(t, {title = 'СЕРИАЛЫ : по жанрам', mrl = '#stream/q=genre&id=' .. '/serials/genre', image = HOME  .. '/style/img/kategorii.png?w=0'})
     
       table.insert(t, {title = 'СЕРИАЛЫ : подборка', mrl = '#stream/q=collections&id=' .. '/serials/collections', image = HOME  .. '/style/img/dop.png?w=0'})

      table.insert(t, {title = 'СЕРИАЛЫ : по годам', mrl = '#stream/q=years&id=' .. '/serials/years', image = HOME .. '/style/img/raspisan.png?w=0'})

      table.insert(t, {title = 'СЕРИАЛЫ : по странам', mrl = '#stream/q=countries&id=' .. '/serials/countries', image = HOME .. '/style/img/raspisan.png?w=0'})
 
 
 

        
        
        
        
     --   table.insert(t, {title = 'СЕРИАЛЫ : Тор за сегодня', mrl = '#stream/genre=' .. '/serials/top'})
       
  --     table.insert(t, {title = 'СЕРИАЛЫ : Тор ANWAP', mrl = '#stream/genre=' .. '/serials/top/like'})
       
   --    table.insert(t, {title = 'СЕРИАЛЫ : Тор КиноПоиск', mrl = '#stream/genre=' .. '/serials/top/kp'})


     --  table.insert(t, {title = 'СЕРИАЛЫ : Тор imdb', mrl = '#stream/genre=' .. '/serials/top/imdb'})
        
        
		
	--	https://tv.anwap.today/films/top
        
        
        

        
        
        
elseif args.q == 'films' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. 'p-' .. tostring(page))


     --   x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
        url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=films&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
       


elseif args.q == 'serials' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. 'p-' .. tostring(page))


     --   x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
        url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=serials&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
       


--https://tv.anwap.today/films/search/?slv=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8&vid=1&page=2
--https://m.anwap.tube/serials/search/?word=%D0%BF%D0%B8&vid=1



elseif args.q == 'countries' then

    
    local x = conn:load(HOME .. args.id)

   
		x = string.match(x, '"zag2".-class="zag2">(.-)"menuniz"')
		for url, title in string.gmatch(x, '<a href="(.-)".-<strong>(.-)</strong>') do
     t['view'] = 'simple'
		
			table.insert(t, {title = title, mrl = '#stream/q=genrez&id=' .. url})
		end




elseif args.q == 'genre' then

    
    local x = conn:load(HOME .. args.id)
   
   t['view'] = 'grid_large'
        x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)</h2>') do
         image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genrez&id=' .. url, image = image})
		end
        
        
elseif args.q == 'genrez' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '-' .. tostring(page))


    --    x = string.match(x, '<div class="zag2"(.-)Показать')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film.-<a href="(/.-)".-src="(.-)".-alt="(.-)"') do
         url = string.gsub(url, '^(.-)', HOME)
         
         
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=genrez&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
        
        
        

elseif args.q == 'collections' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '/' .. tostring(page))

t['view'] = 'grid_large'
        x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)</h2>') do
         image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=collection&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=collections&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
       



elseif args.q == 'collection' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '/' .. tostring(page))


     --   x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
        url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=collection&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
       



elseif args.q == 'years' then
    
    local x = conn:load(HOME .. args.id)
t['view'] = 'simple'

         x = string.match(x, '"zag2".-<div class="zag2">(.-)</div>')
         for url,  title in string.gmatch(x, '<a href="(/.-)".-<strong>(.-)</strong>') do
	--		url = string.gsub(url, '^(.-)', HOME)
			
            --image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=year&id=' .. url, image = image})
		end
        


   elseif args.q == 'year' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '/' .. tostring(page))


      --  x = string.match(x, '<div class="zag2"(.-)Показать')
        for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
         url = string.gsub(url, '^(.-)', HOME)
         
         
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&q=year&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		


elseif args.q == 'sezon' then

local page = tonumber(args.page or 1)
    
    local x = conn:load(HOME .. args.id .. '-' .. tostring(page))
		

      -- local slist=string.match(x, '<ul class="tl">(.-)</ul>')


	--	if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/down.-)">(.-)</a>') do
       print(url)
	  -- 	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=sezond&id=' .. url})
		end 
	
	
			
	local url = '#stream/page=' .. tostring(page + 1) .. '&q=sezon&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


  
    elseif args.q == 'sezond' then
  
   local x = conn:load(HOME .. args.id)
  
  
  
  local slist=string.match(x, 'tlsiconkoi.-<ul class="tlsiconkoi">(.-)</ul>')


		if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/load.-)".-Скачать(.-)<span') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = 'Смотреть' .. tolazy(title), mrl = url})
	
		end
		end	

elseif args.q == 'podborka' then

      local x = conn:load(HOME .. args.id)
	
	local x=string.match(x, 'Актеры:(.-)<div class="clear"')

			for url, title in string.gmatch(x, '<a href="(.-)" class="in f sound">(.-)</a>') do
 
t['view'] = 'simple'
	table.insert(t, {title = title, mrl = '#stream/q=collection&id=' .. url})
  end




elseif args.q == 'popular' then
      
      local x = conn:load(args.id)
   
    --  x = string.match(x, '<div class="popular".-Похожие(.-)Рекомендуем')
	
	
	for url, total, image, title in string.gmatch(x, '<div class="section_item".-<a href="(.-)".-class="godv">(.-)<.-<img src="(.-)".-alt="(.-)"') do


	url = string.gsub(url, '^(.-)', HOME)
			
    image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		



     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/films/search/?slv=' .. urlencode(args.keyword) .. '&vid=1' .. '&page=' .. tostring(page)


		local x = conn:load(url)
		
                 for url, image,  title in string.gmatch(x, '<div class="clear".-<a href="(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', HOME)
			
           image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})


    elseif args.q == '/serials/search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/serials/search/?word=' .. urlencode(args.keyword) .. '&vid=1' .. '&page=' .. tostring(page)


		local x = conn:load(url)
		
                 for url, image,  title in string.gmatch(x, '<div class="clear".-<a href="(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', HOME)
			
            image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})




	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
        t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x, '<div class="filmopis screen3".-<p>(.-)</p>')
			t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="filmopis screen".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			
			
			
	    	t['annotation'] = parse_array(x, {'(Год:</td>.-)</a>', '(Страна:</td>.-)</td>',
			'(Жанр:</td>.-)</td>',
			'(Актеры:</td>.-)</td>'})
			
			
			
			
        local slist=string.match(x, '<ul class="tl2">(.-)</ul>')


		if slist then
			for url, title in string.gmatch(x, '<a href="(/films/load.-)">Скачать(.-)<.-</a>') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
      
        table.insert(t, {title = 'Смотреть' .. tolazy(title), mrl = url})
	
		end
		end	



        local slist=string.match(x, '<ul class="tl2">(.-)"popular"')


		if slist then
			for url, title in string.gmatch(x, '<li><a href="(/serials/s.-)">(.-)</a></li>') do

      
       table.insert(t, {title = tolazy(title), mrl = '#stream/q=sezon&id=' .. url})
        
        
		end
		end	

--https://tv.anwap.today/serials/s6022

   
	
        
for url in string.gmatch(x, '<meta property="og:url" content="(http.-)"') do
  
--local x = conn:load(args.id)
    
   table.insert(t, {title = 'Похожие', mrl = '#stream/q=popular&id=' .. url})
  
   end
 
 
 
  for id in string.gmatch(x, '<meta property="og:url" content="https://.-(/.-)"') do
   
 table.insert(t, {title = 'В подборках', mrl = '#stream/q=podborka&id=' .. id})
  end
 
 
   
        
		


  
  
       	

	
     for title, title1 in string.gmatch(x, 'class=.-ball.-<h1.-alt.->(.-)</.-Год:.-class=.-year.->(.-)</') do
   
   title = string.gsub(title, 'Скачать сериал ', '')
   title = string.gsub(title, 'Скачать фильм ', '')

 --   title = urlencode(title)
      
   --   title = string.gsub(title, '+', '%%20')

    --     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

   --  local x = conn1:load(url)

  --  for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
    
    
    
   
table.insert(t, {title = 'Источники', mrl = '#stream/q=video&id1=' .. title .. '&id2='.. title1, image = image})
       end
  
-- end
     
  
  
  
  

        
  
    elseif args.q == 'video' then


local x = conn1:load('http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=' .. urlencode(args.id1) .. ',' .. args.id2)

      for id3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do

       t['view'] = 'simple'


    table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. id3, image = image})
        
    table.insert(t, {title = 'Alloha', mrl = '#stream/q=mirage&id3=' .. id3})
  
  table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=vdbmovies&id3=' .. id3})
  
table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. id3})
 
 table.insert(t, {title = 'Videodb', mrl = '#stream/q=videodb&id3=' .. id3})

  table.insert(t, {title = 'Videocdn', mrl = '#stream/q=videocdn&id3=' .. id3})

 table.insert(t, {title = 'Lumex', mrl = '#stream/q=lumex&id3=' .. id3})
  
   table.insert(t, {title = 'Filmix', mrl = '#stream/q=filmix&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. id3})
   
table.insert(t, {title = 'Filmix2', mrl = '#stream/q=filmix2&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  id3})
  
  
  
  
table.insert(t, {title = 'Getstv', mrl = '#stream/q=getstv&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  id3})
  
table.insert(t, {title = 'Kinotochka', mrl = '#stream/q=kinotochka&id3=' .. id3})
   
   table.insert(t, {title = 'Kinopub', mrl = '#stream/q=kinopub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  id3})
   
      table.insert(t, {title = 'Rezka', mrl = '#stream/q=rezka&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. id3})
 
  
  
  
  
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=' .. urlencode(args.id1) .. '-' .. args.id2 .. '&box_mac=acace24b8434')


 --   local slist = string.match(x, 'Мультфильмы.-</playlist_url>(.-)</playlist_url>')
    
  --  if slist then
    
 --   for url in string.gmatch(slist,'<channel>.-<title><!%[CDATA.-<playlist_url><!%[CDATA%[http.-&stream=(.-)]]') do
 
   --  url = base64_decode(url)
  
  
  -- table.insert(t, {title = 'Hdrezka', mrl = '#stream/q=hdrezka&id=' .. url})
 --  end
--   end
   
   table.insert(t, {title = 'Kinobase', mrl = '#stream/q=kinobase&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. id3})
 
   table.insert(t, {title = 'Vkmovie', mrl = '#stream/q=vkmovie&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. id3})
 
table.insert(t, {title = 'Remux', mrl = '#stream/q=remux&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. id3})
 
 
   table.insert(t, {title = 'Jac', mrl = '#stream/q=jac&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. id3})
   
   table.insert(t, {title = 'Pidtor', mrl = '#stream/q=pidtor&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. id3})
   table.insert(t, {title = 'Collaps', mrl = '#stream/q=collaps&id3=' .. id3})
   
table.insert(t, {title = 'Vibix', mrl = '#stream/q=vibix&id3=' .. id3})
   
table.insert(t, {title = 'Veoveo', mrl = '#stream/q=veoveo&id3=' .. id3})


end








elseif args.q == 'getstv' then
    
   
--https://evkh.lol/lite/getstv?kinopoisk_id=386&title=Чужой&year=1979
    
      local x = conn:load('https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
   --   url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

     local x = conn:load(url1)
   
 

 
     local slist = string.match(x, '"quality"(.-)}')
      

   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-mp4)') do

    total1 = string.gsub(total1, ',"', '') 

      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

      end 
    end

    
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-"stream".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end


   elseif args.q == 'videocdn' then
    
--https://lamp-movie.ru
--http://lam.maxvol.pro
    
   local x = conn:load('https://lamp-movie.ru/lite/lumex?kinopoisk_id=' .. args.id3)
    
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
   
   url2 = string.gsub(url2, '\\u0026', '&')
   
-- table.insert(t, {title = url2, mrl = url2})
   
   local x = conn:load(url2)
   
   for total1, url3 in string.gmatch(x, 'RESOLUTION=(.-)http.-(/proxy.-m3u8)') do
   
url3 = string.gsub(url3, '\\u002B', '+')
   url3 = string.gsub(url3, '\\u0026', '&')
   
       t['view'] = 'simple'
   
   url3 = string.gsub(url3, '^(.-)', 'https://lamp-movie.ru')
   
   table.insert(t, {title = total .. ' ' .. total1, mrl = url3})
   
   end
   end
   
   
   for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
        --   url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
    --   url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
    

    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    url4 = string.gsub(url4, '\\u002B', '+')
         url4 = string.gsub(url4, '\\u0026', '&')
    
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end
end
end

   

elseif args.q == 'kinotochka' then


local x = conn:load('https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3)



for url in string.gmatch(x, '"embed":"(http.-)"') do

url = string.gsub(url, '\\', '')

--table.insert(t, {title = url, mrl = url})


    local x = conn:load(url)

t['view'] = 'simple'

local slist = string.match(x, 'file:(.-)"poster"')

if slist then


--file:"https://svd13.kvb.cool/video_mp4/films/1979/Alien/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVlSH97aQZyUg::/Alien1979_480.mp4


--Playerjs({id:"playerjshd", file:"https://s15.kvb.cool/video_mp4/films/2025/Xeno/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVlSH97awNyUQ::/Xeno2025.mp4,", "poster

for url1, url2, url3, url4, url5 in string.gmatch(slist, '(http.-_)(.-_)(.-/)(.-)(.mp4)') do


table.insert(t, {title = url4, mrl = url1 .. url2 .. url3 .. url4 .. url5})

     end 
    end
end

    local x = conn:load('https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3)

--table.insert(t, {title = 'https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3, mrl = 'https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3})


    for title, url in string.gmatch(x, '"url".-http.--.--.--(.-sezon).-"embed":"(http.-)"') do

    url = string.gsub(url, '\\', '')

      local x = conn:load(url)

--table.insert(t, {title = title .. url, mrl = url})



for url1 in string.gmatch(x, 'file.-(http.-txt)') do

local x = conn:load(url1)



for total, total1, url2 in string.gmatch(x, '"comment":"(.-)<br>(.-)".-file.-(http.-.mp4)"') do

url2 = string.gsub(url2, '_%[480,720]', '_720')



table.insert(t, {title = title .. total .. ' ' .. total1, mrl = url2})


     end 
    end
end





    elseif args.q == 'zetflix' then
    
    
      local x = conn:load('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. args.id3)
   
   for  total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-hidxlglk.-class="videos__item%-title">(.-)</div>') do
  
  
     local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-m3u8)"') do
      
      url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')

      
      
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
        for url2, url3, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-zetflix)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = http.getz(url2 .. url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = http.getz(url4)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
      t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end




elseif args.q == 'mirage' then
    
    
--https://evkh.lol/lite/vokino?rjson=False&kinopoisk_id=386&title=&original_title=&balancer=alloha

   
local x = conn:load('http://peppega.ru/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do

      url4 = string.gsub(url4, '^(.-)', 'http://peppega.ru') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do

      url5 = string.gsub(url5, '^(.-)', 'http://peppega.ru') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end

    
  elseif args.q == 'alloha' then
 
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=' .. args.id3 .. '&box_mac=acace24b8434')

    
    
  
    --   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
    t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end
--end

    

    
    elseif args.q == 'vdbmovies' then
      
      local x = conn:load('https://lam.maxvol.pro/lite/vdbmovies?kinopoisk_id=' .. args.id3)




for total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-/proxy.-mp4.-class="videos__item%-title">(.-)</div>') do
  
  
  
      local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)"') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
            url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     


      t['view'] = 'simple'


   table.insert(t, {title = 'vdbmovies' .. ':'.. tolazy(total1) .. ( total), mrl = url2})

       
    end
    end
    

    
  
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    

      local x = conn:load(url2)

     
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
  
         url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
    
       
    
     local x = conn:load(url3)
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
  
            url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end




    elseif args.q == 'hdvb' then
      
      local x = conn:load('https://lam.akter-black.com/lite/hdvb?kinopoisk_id=' .. args.id3)
      
      for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   
      local x = conn:load(url2 .. url3)

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/360/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '360p ' .. tolazy(total2), mrl = url4})

end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/480/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '480p ' .. tolazy(total2), mrl = url4})
end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/720/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '720p ' .. tolazy(total2), mrl = url4})
end

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '1080p ' .. tolazy(total2), mrl = url4})

      end 
   
      end
      

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=' .. args.id3 .. '&box_mac=acace24b8434')

--url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
   --   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end



    
    elseif args.q == 'videodb' then
    
    local x = conn:load('http://178.20.46.40:12600/lite/videodb?kinopoisk_id=' .. args.id3)
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite/videodb.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite/videodb.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://178.20.46.40:12600')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end




    elseif args.q == 'lumex' then
    
    
   local x = conn:load('http://178.20.46.40:12600/lite/lumex?kinopoisk_id=' .. args.id3)
    
    
   --  local x = conn:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
--  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p)lumex :' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '3600/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p)lumex :' .. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p)lumex :' .. tolazy(total), mrl = url3})
       
    end
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
    

    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
    
     local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"http.-(http.-mp4)') do
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url5})

       
    end
end
end
end
    

     elseif args.q == 'filmix' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lamp-movie.ru/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
		--.. '&year=' .. args.id2)
   
   
   
for url, total1, image, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-"year":(.-),.-"img":.-(/proxy.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   
url = string.gsub(url, '\\u0026', '&')
   
   image = string.gsub(image, '\\u002B', '+')
   
   image = string.gsub(image, '^(.-)', 'https://lamp-movie.ru')
   
    table.insert(t, {title = total .. ' ' .. total1, mrl = '#stream/q=filmixx&id=' .. url, image = image})
end
    
    elseif args.q == 'filmixx' then

     local x = conn:load(args.id)

  for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"(http.-mp4)') do
 
 total3 = string.gsub(total3, ',"', '')
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
    end
end
 
 
 
   

     
  --   local x = conn:load('http://peppega.ru/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play.-class="videos__item%-title">(.-)</div>') do

   --  url5 = string.gsub(url5, '\\u0026', '&')
   -- url5 = string.gsub(url5, '^(.-)', 'http://peppega.ru')
   
   
     local x = string.match(x, '"quality":{(.-)}')
      for  total4, url5 in string.gmatch(x, '"(.-p)":"(http.-mp4)') do
 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

       
    end
end
end
end







     elseif args.q == 'hdrezka' then

  --http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=чужой:+земля-2025&box_mac=acace24b8434


   
      local x = conn:load(args.id)


          for id, title in string.gmatch(x,'data%-translator_id.-href="(.-)">(.-)</a>') do
     t['view'] = 'simple'
  
  

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title =tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
         
         
for title1, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
        
end
 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end

    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    
elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end





     elseif args.q == 'rezka' then


	
		local x = conn:load('https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
 -- table.insert(t, {title = 'https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
  
       
    local slist = string.match(x, '"quality"(.-)}')
      
     if slist then
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"http.-(/proxy.-m3u8)"') do
  
      url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
     end
  
  
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
       t['view'] = 'simple'
   
      local x = conn:load(url2)

  local slist = string.match(x, '"quality"(.-)}')
      
      
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"http.-(/proxy.-m3u8)"') do
  
      url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')' .. total, mrl = url3})

     end  
 end
     




   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      



      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rez' then

   local x = conn:load('https://lampa.persh1n.ru/lite/rezka/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
  
--https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=4760854&title=%D0%9A%D0%BE%D1%80%D0%BE%D0%BB%D1%8C+%D0%A2%D0%B0%D0%BB%D1%81%D1%8B&year=2025&serial=1

    elseif args.q == 'kinobase' then

--https://lampa.persh1n.ru/lite/rezka?kinopoisk_id=386&title=чужой&year=1979
   
   
		local x = conn:load('https://lampa.persh1n.ru/lite/kinobase?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&t=&s=1')
     
  
  
  
   --    for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
   --   local x = conn:load(url)

      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
     t['view'] = 'simple'

url2 = string.gsub(url2, '\\u002B', '+')

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2})
    end
     end  
  --  end

--https://lampa.persh1n.ru/lite/kinobase?title=%d0%b1%d1%83%d0%bc%d0%b0%d0%b6%d0%bd%d1%8b%d0%b9+%d0%b4%d0%be%d0%bc&year=2017&s=1
  
     for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
      local x = conn:load(url)
   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
    
       
    
      local x = conn:load(url2)

      
       

      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
    
url3 = string.gsub(url3, '\\u002B', '+')

    
         
    url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
    
       t['view'] = 'simple'



    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3})

    end   
    end
    end
   


elseif args.q == 'jac' then

    

   local x = conn:load('https://lam.akter-black.com/lite/jac?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
   
       t['view'] = 'simple'
    table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     
     


		local x = conn:load('https://lam.akter-black.com/lite/jac?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
  
  
  
  
  
       t['view'] = 'simple'
     table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     



     
     
     
     elseif args.q == 'result' then
      args.id = args.id:lower() 
      
      local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end
   
   
   
    elseif args.q == 'pidtor' then
  
  
  local x = conn:load('https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
  

      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-?tr=).-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
  local x = conn:load('https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
  


--https://lam.akter-black.com/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=






for url2, title in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')

      local x = conn:load(url2)
    

    
      for url3, total  in string.gmatch(x, '"method":"link".-"url":"http.-/lite/pidtor/serial/(.-)?tr=.-class="videos__item%-title videos__season%-title">(.-)</div>') do


--url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')

     url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'
     table.insert(t, {title = title .. ' ' ..  total,mrl = '#stream/q=result&id=' .. url3,image = image})
     end
     
   end
       



elseif args.q == 'collaps' then
  
  
  local x = conn:load('http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=' .. args.id3)



   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



elseif args.q == 'vibix' then
  
  
  local x = conn:load('https://lampa.persh1n.ru/lite/vibix?kinopoisk_id=' .. args.id3)

      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total1) .. total2, mrl = url3})

       
    end

end

--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979



local x = conn:load('https://kinobadi.bid/hd_pars/pleer_on.php?url&kp=' .. args.id3)

--<iframe class="iframe-movie2"  loading="lazy" src="/pleer_4/pleer.php?id=/embed/4539"
		for url  in string.gmatch(x, '<iframe.-src="(/pleer_4.-)"') do
	
		url = string.gsub(url, '^(.-)', 'https://kinobadi.bid')
 
 
	    
		local x = conn:load(url)


        for title in string.gmatch(x, '"title":"(.-)"') do


        local x = string.match(x, '"file":(.-)}')


		
		
         for total, url  in string.gmatch(x, '%[(.-)](http.-mp4)') do
		t['view'] = 'simple'
        table.insert(t, {title = total .. ' ' .. title, mrl = url})
        end
        end
	end






elseif args.q == 'veoveo' then
  
  
  local x = conn:load('https://lamp-movie.ru/lite/veoveo?kinopoisk_id=' .. args.id3)

      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'veoveo :' .. tolazy(total), mrl = url2})

       
    end
     
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)

for total3, url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-media="" s=.-e="(.-)".-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total3) .. ' серия' .. tolazy(total4), mrl = url3})

      end 
      end


elseif args.q == 'kinopub' then
  
  
--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979
   

  local x = conn:load('https://lamp-movie.ru/lite/kinopub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
  

      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'kinopub :' .. tolazy(total), mrl = url2})

       
    end
     
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)

for total3, url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-media="" s=.-e="(.-)".-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'kinopub :' .. tolazy(total2) .. tolazy(total3) .. ' серия' .. tolazy(total4), mrl = url3})

      end 
      end

     
     
     local x = conn:load('http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=' .. urlencode(args.id1) .. '+' .. args.id2 .. '+')
  


     for url2 in string.gmatch(x, '<playlist_name>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn:load(url2)
    


    
    for total, url3, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA(.-)]>.-<playlist_url><!%[CDATA%[(http.-namee=).-(&perewod.-)]]></playlist_url>') do
	
	    local x = conn:load(url3 .. url4)
	   
	   
	     for total1, url5 in string.gmatch(x, '<channel.-<title>.-(1080)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end

for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(720)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end

for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(480)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end


for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(360)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end

     end
	    end




elseif args.q == 'filmix2' then

    

   local x = conn:load('http://peppega.ru/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=filmix')
    

--http://peppega.ru/lite/vokino?kinopoisk_id=386&balancer=filmix

--http://peppega.ru/lite/vokino?kinopoisk_id=4308326&balancer=filmix
     for url4, total3 in string.gmatch(x, '<div class="videos__button.-"method":"link","url":"(http.-)".->(.-])<') do

     local x = conn:load(url4)
    
    for url5, total4 in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"http.-(/proxy.-mp4)".-class="videos__item%-title">(.-)</div>') do 
    
    url5 = string.gsub(url5, '^(.-)', 'http://peppega.ru') 
    
    t['view'] = 'simple'


table.insert(t, {title = total4 .. ' ' .. total3, mrl = url5})


end
end








     for url4, total5  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url4)

      for url5, total6  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url5)


      for url6, total7  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url":".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       url6 = string.gsub(url6, '^(.-)', 'http://peppega.ru') 
    
    t['view'] = 'simple'

    table.insert(t, {title = total5 .. ' '  .. tolazy(total6) .. total7, mrl = url6})

       
    end

end
end

   
   elseif args.q == 'vkmovie' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lam.maxvol.pro/lite/vkmovie?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
     

     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro')
      url4 = string.gsub(url4, '\\u002B', '+')
       t['view'] = 'simple'

   table.insert(t, {title = '(' .. total3 .. ') ' .. tolazy(total2), mrl = url4})
    end
     end  

  
elseif args.q == 'remux' then


--https://lam.akter-black.com/lite/remux?kinopoisk_id=386&title=чужой&year=1979

		local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



      for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')
      
      

    --   url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
   
   
   
for  url3, total1 in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url3 = string.gsub(url3, '\\u0026', '&')
      url3 = string.gsub(url3, '\\u002B', '+')
      
 
 
 local x = conn:load(url3)
 
       for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url4 = string.gsub(url4, '\\u0026', '&')
      url4 = string.gsub(url4, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url4})

     end  
    end
end

local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
   
     for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
 
 
 local x = conn:load(url)
 
       for url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total), mrl = url2})

     end  
    end

   

	
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
		return video(args.url, args)
	end
	return t
end