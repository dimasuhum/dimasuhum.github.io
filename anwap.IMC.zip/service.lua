-- anwap plugin

require('support')
--require('video')
--require('parser')
require('client')

local video = require('video')
local parser = require('parser')







--https://kinobadi.mom/hd_pars/pleer_on.php?url&kp=

--https://672412766.videoframe1.com/embed/4457



--local HOME = 'https://m.anwap.tube'
local HOME = 'https://m.anwap.love'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'UTF-8'
local conn1 = client.new()
conn1['encoding'] = 'utf-8'

conn['root'] = HOME_SLASH

     
   --  local url = {'https://kinobox.tv/api/players?kinopoisk='}



--HOME = 'https://m.anwap.bio'
--HOME = 'https://m.anwap.tube'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from anwap plugin')
	return 1
end

function onUnLoad()
	print('Bye from anwap plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
    table.insert(t['menu'], {title = 'Поиск сериалов', mrl = '#folder/q=/serials/search', image = '#self/search.png'})
	
	
	-- #stream/page=2

	-- #stream/genre=/films/r3-
	-- #stream/genre=/films/p-
	-- #stream/genre=/serial/page/
	-- #stream/genre=/films/top
	-- #stream/genre=/serials/top
	-- #stream/genre=/films/collection/11
	
	-- #stream/genre=/films/collection/67
	
	
	if not args.q then
		local page = tonumber(args.page or 1)
		
--		local genre = args.genre or '/'
		
		local genre = args.genre or '/films/p'
        local url = HOME .. genre .. '-' .. tostring(page)
  
         if genre == '/films/collections' then
			url = HOME .. genre .. '/' .. tostring(page)
		end
		if genre == '/serials/collections' then
			url = HOME .. genre .. '/' .. tostring(page)
		end
        if genre == '' then
			url = HOME .. genre .. '/' .. tostring(page)
		end
      

		
        if genre == '/serials/' then
			url = HOME .. genre .. 'p-' .. tostring(page)
		end
		
		
         print(url)
    --	local x = http.get(url)
         local x = conn:load(url)
    	
        --x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
        

        
        
         for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', HOME)
			
            --image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
        for url, title in string.gmatch(x, '<a href="(/serials/down.-)">(.-серия)</a>') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end 
		
 --   <div class="list_gallery"> 
 
         if genre == '/films/collections' then
        local url = HOME .. genre .. '/' .. tostring(page)
      
        local x = conn:load(url)
        x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)</h2>') do
         image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
        end
       
       if genre == '/serials/collections' then
        local url = HOME .. genre .. '/' .. tostring(page)
      
        local x = conn:load(url)
        x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)</h2>') do
         image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
        end

        if genre == args.genre or '' then
        local url = HOME .. genre .. '/' .. tostring(page)
      
        local x = conn:load(url)
  
        
         for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', HOME)
			
            --image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        end
        
       if genre ==  '/films/years' then
        local url = HOME .. genre
        --.. '/' .. tostring(page)
      
        local x = conn:load(url)
    --     x = string.match(x, '<div class="zag2">(.-)</div>')
         for url,  title in string.gmatch(x, '<a href="(/films/god.-)".-<strong>(.-)</strong>') do
	--		url = string.gsub(url, '^(.-)', HOME)
			
            --image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre' .. url, image = image})
		end
        end  

	
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       
       
       

       
       table.insert(t, {title = 'ФИЛЬМЫ : подборка', mrl = '#stream/genre=' .. '/films/collections'})
       
       table.insert(t, {title = 'СЕРИАЛЫ : подборка', mrl = '#stream/genre=' .. '/serials/collections'})
       
       table.insert(t, {title = 'ФИЛЬМЫ : по годам', mrl = '#stream/genre=' .. '/films/years'})


      table.insert(t, {title = 'СЕРИАЛЫ : по годам', mrl = '#stream/genre=' .. '/serials/years'})
 
 
       
        local x = conn:load(HOME .. '/films/genre')
        --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
        
        

        
		x = string.match(x, '<div class="list_gallery">(.-)</div>')
		for genre, title in string.gmatch(x, '<a href="(.-)".-<h2>(.-)<.-</a>') do
			table.insert(t, {title = 'ФИЛЬМЫ' .. ':' .. title, mrl = '#stream/genre=' .. genre})
		end
		
		
        local x = conn:load(HOME .. '/films/countries')
        --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
		--x = string.match(x, '<div class="zag2">(.-)</div>')
		for genre, title in string.gmatch(x, '<a href="(/films/.-)".-<strong>(.-)</strong>') do
			table.insert(t, {title ='ФИЛЬМЫ' .. ':' .. title, mrl = '#stream/genre=' .. genre})
		end
		
        table.insert(t, {title = 'ВСЕ СЕРИАЛЫ', mrl = '#stream/genre=' .. '/serials/'})
        
     --   table.insert(t, {title = 'СЕРИАЛЫ : Тор за сегодня', mrl = '#stream/genre=' .. '/serials/top'})
       
  --     table.insert(t, {title = 'СЕРИАЛЫ : Тор ANWAP', mrl = '#stream/genre=' .. '/serials/top/like'})
       
   --    table.insert(t, {title = 'СЕРИАЛЫ : Тор КиноПоиск', mrl = '#stream/genre=' .. '/serials/top/kp'})


     --  table.insert(t, {title = 'СЕРИАЛЫ : Тор imdb', mrl = '#stream/genre=' .. '/serials/top/imdb'})
        
        local x = conn:load(HOME .. '/serials/genre')
        --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
x = string.match(x, '<div class="list_gallery">(.-)</div>')
		for genre, title in string.gmatch(x, '<a href="(.-)".-<h2>(.-)<.-</a>') do			table.insert(t, {title = 'СЕРИАЛЫ' .. ':' .. title, mrl = '#stream/genre=' .. genre})
		end
		
		
		
		
        local x = conn:load(HOME .. '/serials/countries')
        --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
		--x = string.match(x, '<div class="zag2">(.-)</div>')
		for genre, title in string.gmatch(x, '<a href="(/serials/.-)".-<strong>(.-)</strong>') do
			table.insert(t, {title ='СЕРИАЛЫ' .. ':' .. title, mrl = '#stream/genre=' .. genre})
		end


--https://m.anwap.tube/films/search/?slv=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8&vid=1&page=2
--https://m.anwap.tube/serials/search/?word=%D0%BF%D0%B8&vid=1


     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/films/search/?slv=' .. urlencode(args.keyword) .. '&vid=1' .. '&page=' .. tostring(page)


		local x = conn:load(url)
		
                 for url, image,  title in string.gmatch(x, '<div class="clear".-<a href="(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', HOME)
			
           image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})


    elseif args.q == '/serials/search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/serials/search/?word=' .. urlencode(args.keyword) .. '&vid=1' .. '&page=' .. tostring(page)


		local x = conn:load(url)
		
                 for url, image,  title in string.gmatch(x, '<div class="clear".-<a href="(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', HOME)
			
            image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})




	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
        t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x, '<div class="filmopis screen3".-<p>(.-)</p>')
			t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="filmopis screen".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			
			
			
	    	t['annotation'] = parse_array(x, {'(Оригинал:</td>.-)</td>', 
			'(Год:</td>.-)</a>',
			'(Качество:</td>.-)</a>',
			'(Перевод:</td>.-)</td>',
			'(Время:</td>.-)</td>',
			'(Страна:</td>.-)</td>',
			'(Жанр:</td>.-)</td>',
			'(Режиссер:</td>.-)</td>','(Актеры:</td>.-)</td>','(Премьера :</span>.-)</li>'})
			
			
			
			
        local slist=string.match(x, '<ul class="tl2">(.-)</ul>')


		if slist then
			for url, title in string.gmatch(x, '<a href="(/films/load.-)">Скачать(.-)<.-</a>') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
      
        table.insert(t, {title = 'Смотреть' .. tolazy(title), mrl = url})
	
		end
		end	

        local slist=string.match(x, '<ul class="tl2">(.-)<a href="/serials/search"')


		if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/s.-)">(.-Сезон).-</a>') do
    --   print(url)
--	   	url = string.gsub(url, '^(.-)', HOME)
      
   --     table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
        
        table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url})
		end
		end	



    --    x = string.match(x, '<ul class="tl2">(.-)</ul>')
   --     for url, title in string.gmatch(x, '<a href="(/films/load.-)">Скачать(.-)<.-</a>') do
     --      print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
  --        url = url

   -- 	table.insert(t, {title = 'Смотреть' .. tolazy(title), mrl = url})
--		end 


--<a href="/serials/s4339">11 Сезон(3 из 23)(идет показ)<span class="cb">+1</span><span class="c1">+1</span></a>
		
   --    x = string.match(x, '<ul class="tl2">(.-)<a href="/serials/search"')
    --    for url, title in string.gmatch(x, '<a href=.-(/serials/s.-)\'>(.-Сезон).-</a>') do
     --     print(url)
--		   url = string.gsub(url, '^/', HOME_SLASH)
     --     url = url

   -- 	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
--		end 
		
	
	
	
       local slist=string.match(x, '<ul class="tl">(.-)</ul>')


		if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/down.-)">(.-серия)</a>') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end 
	
		end
			
	
	
        


        local slist=string.match(x, '<ul class="tlsiconkoi">(.-)</ul>')


		if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/load.-)".-> Скачать(.-)<.-</a>') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = 'Смотреть' .. tolazy(title), mrl = url})
	
		end
		end	

      --   x = string.match(x, '<ul class="tlsiconkoi">(.-)</ul>')
    --    for url, title in string.gmatch(x, '<a href="(/serials/load.-)".-> Скачать(.-)<.-</a>') do
      --     print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
    --      url = url

  --  	table.insert(t, {title = 'Смотреть' .. title, mrl = url})
--		end 



--local url = {}

--url.OpenWindow = function()
    --stuff
--end

--return url


     
     

      






--"source":"Hdvb","iframeUrl":"https://vid1737418632.fotpro135alto.com/movie/07473c720d56f064241dd4c43b011d6a/iframe"

--"iframeUrl":"https://vid1737418632.fotpro135alto.com/movie/07473c720d56f064241dd4c43b011d6a/iframe"

--"iframeUrl":"https://vid1737418632.fotpro135alto.com/movie/8d003bb5aaa177d16e72afcd60b1db8e/iframe"


  
  
  
    



	    
       for title in string.gmatch(x, '<meta charset=.-<title>Скачать фильм(.-)г') do
       
   
      title = urlencode(title)

       url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')
  
         local x = http.get(url)
     
       for url  in string.gmatch(x, '"fxml".-playlist_url.-?id=info&cid=(.-)"') do
     
        url = string.gsub(url, '^(.-)', 'https://kinobadi.mom/hd_pars/pleer_on.php?url&kp=')
  
  		
		local x = http.get(url)

	
		for url2  in string.gmatch(x, '<iframe.-src="/pleer_4.-(/embed/.-)"') do

	
		url = string.gsub(url2, '^(.-)', 'https://672431256.videoframe1.com')
	

   
       table.insert(t, {title = 'Vibix', mrl = '#stream/q=content&id=' .. url})
	
	
	end
	end
	end

	

		
		for title in string.gmatch(x, '{"title":"(.-)"') do
		
         for total, url  in string.gmatch(x, 'MP4(.-)](http.-mp4)') do
         
		t['view'] = 'simple'
		
        table.insert(t, {title = title .. ' ' .. (total), mrl = url})
        end
        end

	
	
	
	
       for title in string.gmatch(x, '<meta charset=.-<title>Скачать сериал(.-)г') do
       
        title = urlencode(title)

       url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')


         local x = http.get(url)
     
       for url1  in string.gmatch(x, '"fxml".-playlist_url.-?id=info&cid=(.-)"') do
     
         url = string.gsub(url1, '^(.-)', 'https://kinobadi.mom/hd_pars/pleer_on.php?url&kp=')
     
        local x = http.getz(url)

      for url2  in string.gmatch(x, '<iframe.-src="/pleer_4.-(/embed.-)"') do


	
		url = string.gsub(url2, '^(.-)', 'https://672431256.videoframe1.com')

   
       table.insert(t, {title = 'Vibix', mrl = '#stream/q=content&id=' .. url})
	
       end
       end
       end
  
    
       for title in string.gmatch(x, '{"title":"(Сезон.-)"') do
   
       for total, total1, total2,  url in string.gmatch(x, '{"title":"(.-)".-{"title":"(.-)".-"file":"%[(.-p)](http.-mp4)') do
 
 
       total1 = string.gsub(total1, '{"title":', '')

       total2 = string.gsub(total2, '{"title":', '')

     
     
        t['view'] = 'simple'
  
      table.insert(t, {title = (total) .. ' ' .. (total1) .. ' ' .. (total2), mrl = url})
        end
       end
	
		
		
	
	
	
	
        
        
        
        for title in string.gmatch(x, '<meta charset=.-<title>Скачать.-(.-)г') do
       
   
       title = string.gsub(title, ' сериал', '')
        title = string.gsub(title, ' фильм', '')
  
       title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
        url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')
  

         local x = http.get(url)
     
       for total  in string.gmatch(x, '"fxml".-playlist_url.-?id=info&cid=(.-)"') do
       

        url = string.gsub(total, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
   
       table.insert(t, {title = 'Zagonka плеер', mrl = '#stream/q=content&id=' .. url})
       end
       end
    --    end
   --    local x = http.getz(url)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-(//video.zagonka.org/movies/.-})') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
			
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
		
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
    end    




	
	
	for title in string.gmatch(x, '<meta charset=.-<title>Скачать.-(.-)г') do
       
   
       title = string.gsub(title, ' сериал', '')
        title = string.gsub(title, ' фильм', '')
  
       title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
        url = string.gsub(title, '^(.-)', 'http://kinopub.me/search/?do=search&subaction=search&q=')
  

     
        local x = conn:load(url)
   --  	x = iconv(http.get(url), 'UTF-8', 'utf-8')
     	
	for url in string.gmatch(x, '<div class="b%-content__inline_item".-<a href="(.-)"') do
	
	 --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
     
	
	
    	local x = conn:load(url)
    	
    --   x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
       
	for url, url1, url2 in string.gmatch(x, '<meta property="og:type" content="video.(movie)".-<meta property="og:video" content="http://.-(/.-)".-class="b%-sidelinks__link show%-trailer" data%-id="(.-)"') do


     

        url = string.gsub(url2, '^(.-)','https://reyohoho.space:4435/get_hdruhd5/') .. '/' .. url .. '/rezka.ag' .. url1

         
--https://reyohoho.space:4435/get_hdruhd5/755/movie/rezka.ag/films/melodrama/755-titanik-1997.html

       table.insert(t, {title = 'Hdrezka', mrl = '#stream/q=content&id=' .. url})

		end
       end
       end




        for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(360p)](http.-.mp4)') do
        
        t['view'] = 'simple'




        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end

        for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(480p)](http.-.mp4)') do
        
        t['view'] = 'simple'

        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end


        for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(720p)](http.-.mp4)') do
        
        t['view'] = 'simple'

        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end


        for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(1080p)](http.-.mp4)') do
        
        t['view'] = 'simple'

        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end

      for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(1080p Ultra)](http.-.mp4)') do
        
        t['view'] = 'simple'

        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end

  
     for total1, url3, url4 in string.gmatch(x, '{\'title\': \'(.-)\', \'file\':.-\'redirectPlayer\': \'(http.-)(/get_movie.-.html)\'') do

       
       t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total1), mrl = '#stream/q=content&id=' .. url3 .. url4})

		end
	
	

      
      
      
      
      
      for title in string.gmatch(x, '<meta charset=.-<title>Скачать.-(.-)г') do
       
   
       title = string.gsub(title, ' сериал', '')
        title = string.gsub(title, ' фильм', '')
  
       title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
        url = string.gsub(title, '^(.-)', 'http://kinopub.me/search/?do=search&subaction=search&q=')
  

     
        local x = conn:load(url)
   --  	x = iconv(http.get(url), 'UTF-8', 'utf-8')
     	
	for url in string.gmatch(x, '<div class="b%-content__inline_item".-<a href="(.-)"') do
	
	 --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
     
	
	
    	local x = conn:load(url)
    	
	
	for url, url1, url2 in string.gmatch(x, '<meta property="og:type" content="video.-(series)".-<meta property="og:video" content="http://.-(/.-)".-class="b%-sidelinks__link show%-trailer" data%-id="(.-)"') do

        url = string.gsub(url2, '^(.-)','https://reyohoho.space:4435/get_hdruhd5/') .. '/' .. url .. '/rezka.ag' .. url1

         

       table.insert(t, {title = 'Hdrezka', mrl = '#stream/q=content&id=' .. url})

		end
        end
        end

   --   for title in string.gmatch(x, '{\'title\': \'(Сезон.-)\'') do
   --    for total1, url3, url4 in string.gmatch(x, '{\'title\': \'(Серия.-)\', \'file\':.-\'redirectPlayer\': \'(http.-)(/get_episode.-.html)\'') do
      
   --   t['view'] = 'simple'
      
  --    table.insert(t, {title = title .. tolazy(total1), mrl = '#stream/q=content&id=' .. url3 .. url4})
    
  --    end
 --    end
     
     
     for total, url in string.gmatch(x, '{\'title\': \'(.-)\', \'file\':.-\'redirectPlayer\': \'(https.-html)') do
  
       total = string.gsub(total, ', \'folder\': %[{\'title\'', '')
  
     total = string.gsub(total, '\'%, \'folder\': %[{\'title\'', '')
     
     total = string.gsub(total, '\'', '')
     
     total = string.gsub(total, '%, id', '')
     
     

       
       t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total), mrl = '#stream/q=content&id=' .. url})

		end
  --      end
	
		
		
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
		return video(args.url, args)
	end
	return t
end