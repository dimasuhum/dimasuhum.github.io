-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')

--https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=4008395



 --https://api.bhcesh.me/list?token=eedefb541aeba871dcfc756e6b31c02e

local HOME = 'https://api.bhcesh.me'
--local HOME = 'https://apicollaps.cc'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/country/СССР/
	-- #stream/genre=/country/Индия/
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/genre/боевик
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/url=/show/
    -- #stream/genre=/show/
	if not args.q then



--https://kinopoiskapiunofficial.tech/api/v2.2/films/386&apiKey=2a4a0808-81a3-40ae-b0d3-e11335ede616
--ApiKeyAuth (apiKey)	

--https://apicollaps.cc/list?token=eedefb541aeba871dcfc756e6b31c02e
--https://api.bhcesh.me/list?token=eedefb541aeba871dcfc756e6b31c02e

		local page = tonumber(args.page or 1)
	
			
		local genre = args.genre or '/list'
		
local offset = (page - 1) * 3 + 1
		
		for i = 1, 3 do
    
		
     
		
		

		local url = HOME .. genre
	--	if page > 1 then
			url = url .. '?page=' .. tostring(offset + i - 1) .. '&token=eedefb541aeba871dcfc756e6b31c02e&type=film'
	-- 	end
		
--https://apicollaps.cc/list?full=true&token=eedefb541aeba871dcfc756e6b31c02e&type=film

	
        local x = conn:load(url)
		
       for title, total, id, image in string.gmatch(x, '"name":"(.-)","type":.-"year":(.-),.-"kinopoisk_id":"(.-)".-"poster":"(.-)"') do


--url = string.gsub(id, '^(.-)', 'https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=')

     --   table.insert(t, {title=url, mrl = '#stream/q=content&id=' .. id, image = image})
			table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
   end
   
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		
		

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
   --    table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&type=film'})
		

--table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&type=cartoon'})




		local x = conn:load('https://api.bhcesh.me/genre?token=eedefb541aeba871dcfc756e6b31c02e&page=1')
		
		
    	for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
        
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
    
    local x = conn:load('https://api.bhcesh.me/genre?token=eedefb541aeba871dcfc756e6b31c02e&page=2')
		
	
    	for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end




    local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=1')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end

     local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=2')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
     
     
local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=3')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
     
local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=4')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
     
     
local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=5')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
     
         
			
     elseif args.q == 'genre' then


    local page = tonumber(args.page or 1)

    local x = conn:load(HOME .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&genre_id=' .. args.id .. '&page=' .. tostring(page))

   
       for title, total, id, image in string.gmatch(x, '"id".-"name":"(.-)".-"year":(.-),.-"kinopoisk_id":"(.-)".-"poster":"(.-)"') do
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
   
   local x = conn:load(HOME .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&collection_id=' .. args.id .. '&page=' .. tostring(page))

   
       for title, total, id, image in string.gmatch(x, '"id".-"name":"(.-)".-"year":(.-),.-"kinopoisk_id":"(.-)".-"poster":"(.-)"') do
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
        
	local url = '#stream/q=genre&id=' .. args.id .. '&page=' .. tostring(page + 1)
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	
	
			
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&name=' .. urlencode(args.keyword) .. '&page=' .. tostring(page)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
  
   
       for title, total, id, image in string.gmatch(x, '"id".-"name":"(.-)".-"year":(.-),.-"kinopoisk_id":"(.-)".-"poster":"(.-)"') do

		--	image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
		
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
		local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id)
    --	local x = http.getz(args.id)
		
       -- x = string.gsub(x, 'onclick', '')
       
       
--http://stvplay.mooo.com:81/collaps.php?cat=?&id=75569
       
       
     for id in string.gmatch(x, '"id":(.-),') do  
      
      local c = conn:load('http://stvplay.mooo.com:81/collaps.php?cat=?&id=' .. id)
      
	
 c = string.gsub(c, '</table>', 'Описание : ')
	
	
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)смотреть онлайн</h1>')
		
		

				t['description'] = parse_match(c, '(Описание : <p>.-)</p>')
		
--		t['description'] = parse_match(x, '"description":"(.-)"')
			t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="FullstoryFormLeft".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			

--"genre":{"26":"Ужасы","11":"Фантастика","13":"Триллер","10":"Зарубежный"}
	
	--	x = string.gsub(x, '"genre":{".-":"', 'Жанр :')
	





--	'(Слоган</b>:.-)</span>',

			
	    	t['annotation'] = parse_array(c, {

			'(Страна</b>:.-)</span>',
		
			'(Коллекция</b>:.-)</span>',
			'(Актеры</b>:.-)</span>',
			'(Бюджет:</h4>.-)</p>'})
   
   end
   
   
--local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id)
   
   
   

   
   for title in string.gmatch(x, '"iframe_url":"http.-/embed/.-/(.-)"') do
   

 --  http://z01.online/lite/collaps?orid=2999 

url = string.gsub(title, '^(.-)', 'http://31.129.234.181/lite/collaps?orid=')
     local x = conn:load(url)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
   --   t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

     end  
  

     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/collaps.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://31.129.234.181')
    
    --   t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end
end
end




    for title, title1, title3  in string.gmatch(x, '"id".-"name":"(.-)".-"year":(.-),.-"kinopoisk_id":"(.-)"') do   
      

   --   url1 = string.gsub(title3, '^(.-)', '/lite/hdvb?kinopoisk_id=') 
 
    table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. title3, image = image})
       
     end
     
       



local iframe = string.match(x,'"id".-"iframe_url":".-(/embed.-)"')
   
 --  for title3  in string.gmatch(x, '"kinopoisk_id":"(.-)"') do   
      
   table.insert(t, {title = 'плеер', mrl = '#stream/q=collaps&id=' .. iframe, image = image})
       
 --    end
  
  
     
    elseif args.q == 'collaps' then
    

--local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)

 
 --  local iframe = string.match(x,'"id".-"iframe_url":".-(/embed.-)"')



--https://api.femd.ws/embed/movie/87442?oneSound=WinMedia&sharing=false&host=kinotik.top

local x = conn:load('https://api.femd.ws' .. args.id .. '?sharing=false&host=kinotik.top')


--table.insert(t, {title = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top', mrl = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top'})

x = string.gsub(x, '\\u0026', '&')

    x = string.gsub(x, '\\"', '')


local down = string.match(x,'download:.-"(http.-)"')


local hls = string.match(x,'hls:.-"(http.-)"')


local title = string.match(x,'hls.-audio:.-%["(.-)"') 



if title then

local x = conn:load(hls)

local total = string.match(x, '#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total then

t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title), mrl = down .. '&audio=' .. total})

table.insert(t, {title = '480p ' .. tolazy(title), mrl = down .. '&video=v2&audio=' .. total})

end
end


local title1 = string.match(x,'hls.-audio:.-%[".-".-"(.-)"') 

if title1 then

local x = conn:load(hls)

local total1 = string.match(x, 'm3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total1 then

t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title1), mrl = down .. '&audio=' .. total1})

table.insert(t, {title = '480p ' .. tolazy(title1), mrl = down .. '&video=v2&audio=' .. total1})



end
end




local title2 = string.match(x,'hls:.-audio:.-%[".-".-".-".-"(.-)"') 

if title2 then

local x = conn:load(hls)

local total2 = string.match(x, 'm3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total2 then

t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title2), mrl = down .. '&audio=' .. total2})

table.insert(t, {title = '480p ' .. tolazy(title2), mrl = down .. '&video=v2&audio=' .. total2})


end
end




local title3 = string.match(x,'hls:.-audio:.-%[".-".-".-".-".-".-"(.-)"')

if title3 then

local x = conn:load(hls)

local total3 = string.match(x, 'm3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total3 then

table.insert(t, {title = '720p ' .. tolazy(title3), mrl = down .. '&audio=' .. total3})

table.insert(t, {title = '480p ' .. tolazy(title3), mrl = down .. '&video=v2&audio=' .. total3})


end
end


local title4 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-"(.-)"') 

if title4 then

local x = conn:load(hls)

t['view'] = 'simple'

local total4 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total4 then

table.insert(t, {title = '720p ' .. tolazy(title4), mrl = down .. '&audio=' .. total4})

table.insert(t, {title = '480p ' .. tolazy(title4), mrl = down .. '&video=v2&audio=' .. total4})
 
  end
   end


local title5 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title5 then

local x = conn:load(hls)

t['view'] = 'simple'

local total5 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total5 then

table.insert(t, {title = '720p ' .. tolazy(title5), mrl = down .. '&audio=' .. total5})

table.insert(t, {title = '480p ' .. tolazy(title5), mrl = down .. '&video=v2&audio=' .. total5})

  end
   end


local title6 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title6 then

local x = conn:load(hls)

t['view'] = 'simple'

local total6 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total6 then

table.insert(t, {title = '720p ' .. tolazy(title6), mrl = down .. '&audio=' .. total6})

table.insert(t, {title = '480p ' .. tolazy(title6), mrl = down .. '&video=v2&audio=' .. total6})

  end
   end

local title7 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title7 then

local x = conn:load(hls)

t['view'] = 'simple'

local total7 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total7 then

table.insert(t, {title = '720p ' .. tolazy(title7), mrl = down .. '&audio=' .. total7})

table.insert(t, {title = '480p ' .. tolazy(title7), mrl = down .. '&video=v2&audio=' .. total7})

  end
   end

local title8 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title8 then

local x = conn:load(hls)

t['view'] = 'simple'

local total8 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total8 then

table.insert(t, {title = '720p ' .. tolazy(title8), mrl = down .. '&audio=' .. total8})

table.insert(t, {title = '480p ' .. tolazy(title8), mrl = down .. '&video=v2&audio=' .. total8})

  end
   end
   
--local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)

 
  -- local iframe = string.match(x,'"id".-"iframe_url":".-(/embed.-)"')



--https://api.femd.ws/embed/movie/87442?oneSound=WinMedia&sharing=false&host=kinotik.top

local x = conn:load('https://api.femd.ws' .. args.id .. '?sharing=false&host=kinotik.top')

--table.insert(t, {title = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top', mrl = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top'})

x = string.gsub(x, '\\u0026', '&')

    x = string.gsub(x, '\\"', '')



local season = string.match(x,'seasons:%[(.-)]}]')

if season then
for total, url in string.gmatch(season, '"duration".-"title":"(.-)".-"download":"(http.-)"') do

	
	t['view'] = 'simple'
	
table.insert(t, {title = tolazy(total), mrl = url})

  end
end    

    elseif args.q == 'hdvb' then
      
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

      for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"http.-(vid.-)(/movie.-)"') do
      
      
if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)


local id, key = string.match(x, '"file":"%~(.-)".-"key":"(.-)"')

local href = string.match(x, '"href":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'



local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)

         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. title, mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. title, mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. title, mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. title, mrl = url3})

       end
       end
 end
 end
     
    
    
    
    
    
     
     local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
     
    -- table.insert(t, {title = 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3, mrl = '#stream/q=hdvbs&id1=' .. 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3})
     
     
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

     
     
     
  --   table.insert(t, {title = url, mrl = '#stream/q=hdvbs&id1=' .. url})
     
   
    --  for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') do
      
      local origin, url = string.match(x, '"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') 

if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=177873309816283985; _ym_d=1778733098; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)

x = string.gsub(x, '\\', '')

local id, key = string.match(x, '"file":"(.-)".-"key":"(.-)"')

if id then
if key then


local href = string.match(x, '"href":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.' .. href)

local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')







for id1, text in string.gmatch(x, '"file":"%~(.-)".-"text2":"(.-)"') do

--local text = string.match(x, '"file".-"text2":"(.-)"')


id1 = string.gsub(id1, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'


local x = http.postz(id1, headers1)



for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. text, mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. text, mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. text, mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. text, mrl = url3})

       end
     
end
     
end
end
end
end
  
  

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end