-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')

--https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=4008395



 --https://api.bhcesh.me/list?token=eedefb541aeba871dcfc756e6b31c02e

local HOME = 'https://api.bhcesh.me'
--local HOME = 'https://apicollaps.cc'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/country/СССР/
	-- #stream/genre=/country/Индия/
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/genre/боевик
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/url=/show/
    -- #stream/genre=/show/
	if not args.q then



--https://kinopoiskapiunofficial.tech/api/v2.2/films/386&apiKey=2a4a0808-81a3-40ae-b0d3-e11335ede616
--ApiKeyAuth (apiKey)	

--https://apicollaps.cc/list?token=eedefb541aeba871dcfc756e6b31c02e
--https://api.bhcesh.me/list?token=eedefb541aeba871dcfc756e6b31c02e

		local page = tonumber(args.page or 1)
		local genre = args.genre or '/list'
		local url = HOME .. genre
	--	if page > 1 then
			url = url .. '?page=' .. tostring(page) .. '&token=eedefb541aeba871dcfc756e6b31c02e&type=film'
	-- 	end
		
--https://apicollaps.cc/list?full=true&token=eedefb541aeba871dcfc756e6b31c02e&type=film

	
        local x = conn:load(url)
		
       for title, total, id, image in string.gmatch(x, '"name":"(.-)","type":.-"year":(.-),.-"kinopoisk_id":"(.-)".-"poster":"(.-)"') do


--url = string.gsub(id, '^(.-)', 'https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=')

     --   table.insert(t, {title=url, mrl = '#stream/q=content&id=' .. id, image = image})
			table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
   
   
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		
		

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
   --    table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&type=film'})
		

--table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&type=cartoon'})




		local x = conn:load('https://api.bhcesh.me/genre?token=eedefb541aeba871dcfc756e6b31c02e&page=1')
		
		
    	for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
        
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
    
    local x = conn:load('https://api.bhcesh.me/genre?token=eedefb541aeba871dcfc756e6b31c02e&page=2')
		
	
    	for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end




    local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=1')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end

     local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=2')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
     
     
local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=3')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
     
local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=4')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
     
     
local x = conn:load('https://api.bhcesh.me/collection?token=eedefb541aeba871dcfc756e6b31c02e&page=5')

    for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"}') do
    
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=genre&id=' .. id})
		end
     
         
			
     elseif args.q == 'genre' then


    local page = tonumber(args.page or 1)

    local x = conn:load(HOME .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&genre_id=' .. args.id .. '&page=' .. tostring(page))

   
       for title, total, id, image in string.gmatch(x, '"id".-"name":"(.-)".-"year":(.-),.-"kinopoisk_id":"(.-)".-"poster":"(.-)"') do
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
   
   local x = conn:load(HOME .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&collection_id=' .. args.id .. '&page=' .. tostring(page))

   
       for title, total, id, image in string.gmatch(x, '"id".-"name":"(.-)".-"year":(.-),.-"kinopoisk_id":"(.-)".-"poster":"(.-)"') do
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
        
	local url = '#stream/q=genre&id=' .. args.id .. '&page=' .. tostring(page + 1)
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	
	
			
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/list?token=eedefb541aeba871dcfc756e6b31c02e&name=' .. urlencode(args.keyword) .. '&page=' .. tostring(page)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
  
   
       for title, total, id, image in string.gmatch(x, '"id".-"name":"(.-)".-"year":(.-),.-"kinopoisk_id":"(.-)".-"poster":"(.-)"') do

		--	image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
		
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
		local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id)
    --	local x = http.getz(args.id)
		
       -- x = string.gsub(x, 'onclick', '')
       
       
--http://stvplay.mooo.com:81/collaps.php?cat=?&id=75569
       
       
     for id in string.gmatch(x, '"id":(.-),') do  
      
      local c = conn:load('http://stvplay.mooo.com:81/collaps.php?cat=?&id=' .. id)
      
	
 c = string.gsub(c, '</table>', 'Описание : ')
	
	
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)смотреть онлайн</h1>')
		
		

				t['description'] = parse_match(c, '(Описание : <p>.-)</p>')
		
--		t['description'] = parse_match(x, '"description":"(.-)"')
			t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="FullstoryFormLeft".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			

--"genre":{"26":"Ужасы","11":"Фантастика","13":"Триллер","10":"Зарубежный"}
	
	--	x = string.gsub(x, '"genre":{".-":"', 'Жанр :')
	





--	'(Слоган</b>:.-)</span>',

			
	    	t['annotation'] = parse_array(c, {

			'(Страна</b>:.-)</span>',
		
			'(Коллекция</b>:.-)</span>',
			'(Актеры</b>:.-)</span>',
			'(Бюджет:</h4>.-)</p>'})
   
   end
   
   
--local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id)
   
   
   

   
   for title in string.gmatch(x, '"iframe_url":"http.-/embed/.-/(.-)"') do
   

      

url = string.gsub(title, '^(.-)', 'http://178.20.46.40:12600/lite/collaps?orid=')
     local x = conn:load(url)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
   --   t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

     end  
  

     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/collaps.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
    --   t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end
end
end




    for title, title1, title3  in string.gmatch(x, '"id".-"name":"(.-)".-"year":(.-),.-"kinopoisk_id":"(.-)"') do   
      

   --   url1 = string.gsub(title3, '^(.-)', '/lite/hdvb?kinopoisk_id=') 
 
    table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. title3, image = image})
       
     end
     
       




   for title3  in string.gmatch(x, '"kinopoisk_id":"(.-)"') do   
      
   table.insert(t, {title = 'Alloha', mrl = '#stream/q=alloha&id=' .. title3, image = image})
       
     end
     
    elseif args.q == 'alloha' then
    
    --  local x = conn:load(args.id)
     
     
--url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
  
  
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=' .. args.id .. '&box_mac=acace24b8434')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
  
--table.insert(t,{title= url3,mrl = url3})
  
  
				table.insert(t,{title= tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, id1, id2, id3, id4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA.-&stream=(.-)&season=(.-)&translate=(.-)&ta=(.-)]]') do
  
  
  t['view'] = 'simple'
  
    
    table.insert(t,{title= tolazy(total) .. ' ' .. tolazy(total1),mrl = '#stream/q=allohas&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
    
    end
    end

    
elseif args.q == 'allohas' then
    
    
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&stream=' .. args.id1 .. '&season=' .. args.id2 .. '&translate=' .. args.id3 .. '&ta=' .. args.id4 .. '&box_mac=acace24b8434')
  
  

  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
    t['view'] = 'simple'
				table.insert(t,{title= tolazy(total3) .. ' ' .. (total2),mrl = url5})
			end
          end
    

    
    

    elseif args.q == 'hdvb' then
      
      local x = conn:load('http://178.20.46.40:12600/lite/hdvb?kinopoisk_id=' .. args.id3)
      
      for  url, total2 in string.gmatch(x, '"method":"call".-"url":"http.-(/lite.-)".-class="videos__item%-title">(.-)</div>') do
  
      url = string.gsub(url, '\\u0026', '&')
   url = string.gsub(url, '\\u002B', '+')


      local x = conn:load('http://178.20.46.40:12600' .. url)

    for  url2 in string.gmatch(x, '"play".-"url":"http.-(/proxy.-)"') do
 
 
 --https://cdn-400.fotpro135alto.com/stream2/cdn-400/f9522e399333a8b96e6d76b6e57ddace/MJTMsp1RshGTygnMNRUR2N2MSlnWXZEdMNDZzQWe5MDZzMmdZJTO1R2RWVHZDljekhkSsl1VwYnWtx2cihVT290VStWWyYUbZpWVxoVbVpnT6lENOpWUx4ERRNzTEtWNPRlRtpFVrFTTEVUP:1768243115:185.228.133.239:7a925e945c08c1c081924669c581c8f04f15477797657d0e9b7057e51eebf17d:ru/1080/index.m3u8
    
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
      t['view'] = 'simple'


    table.insert(t, {title = '1080p', mrl = url2})

      end 
   
      end
      

      
 
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url2 = string.gsub(url2, '\\u0026', '&')
url2 = string.gsub(url2, '\\u002B', '+')


     local x = conn:load('http://178.20.46.40:12600' .. url2)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     
     local x = conn:load('http://178.20.46.40:12600' .. url4)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"http.-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do




     url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = 'http://178.20.46.40:12600' .. url6})
    end
end
end

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end