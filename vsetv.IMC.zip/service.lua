-- onlinetv plugin

require('support')
require('video')
require('parser')

HOME = 'https://zigfreed.ru'

HOME_SLASH = HOME .. '/'

--http://www.teleguide.info/download/new3/jtv.zip;
--http://iptvx.one/epg/epg_lite.xml.gz;
--http://programtv.ru/xmltv.xml.gz;
--http://epg.it999.ru/edem.xml.gz;



TV_URL = 'http://iptvx.one/epg/epg_lite.xml.gz'


--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'

--TV_URL = 'http://myott.top/api/epg.xml.gz'

--TV_URL = 'http://epg.one/epg2.xml.gz'


--TV_URL = 'http://epg.it999.ru/edem.xml.gz'

--TV_URL = 'https://italo.drm-play.com/full.xml.gz'

--TV_URL = 'https://zigfreed.ru/Z!/epg.xml'

--TV_URL = 'http://epg.one/epg.xml.gz'



--TV_URL = 'https://zigfreed.ru/Z!/epg.xml'

TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

--PASS = '7777'

--local lockpass


function onLoad()
	print('Hello from onlinetv plugin')
	return 1
end

function onUnLoad()
	print('Bye from onlinetv plugin')
end

function onCreate(args)

--if not args.q and args.keyword then
--lockpass = args.keyword
--end

--if lockpass == PASS then
--else
--return {view="keyword",message="enter --access code"}
--end



	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

--table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	if not args.q then
	

local url = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist&page=1&limit=2000&genre=all&search='



local headers = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=pk3jievaefvcsna21kq4d9vsho; _ga_05VH9CY87B=GS2.1.s1788619031$o2$g1$t1788619820$j59$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}


 local x = http.getz(url, headers)


local cdn = string.match(x, 'class=.-"video%-btn ripple.-checkAndOpenModal%(.-,.-,.-, \'(.-)\', true')



local headers1 = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=pk3jievaefvcsna21kq4d9vsho; _ga_05VH9CY87B=GS2.1.s1788611788$o1$g1$t1788611969$j59$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; _ym_visorc=w; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}



local playlist = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist_settings'

local x = http.getz(playlist, headers1)

local m3u = string.match(x, '<h5.->Полный плейлист.-<a href="(http.-full.m3u)"')


local x = http.getz(m3u, headers1)



for group, id, logo, name, token in string.gmatch(x, '#EXTINF.-group%-title="(.-)" tvg%-id="(.-)" tvg%-name=".-" tvg%-logo="(.-)",(.-)http.-/tv/(.-)=') do

id = string.gsub(id, '-', '_')


local url1 = 'https://' .. cdn .. '/' .. id .. '/index.m3u8?token=' .. token

table.insert(t, {title = name, mrl = url1, image = logo})

end






--local x = http.getz(url1, headers1)

--local url2 = string.match(x, '(tracks.-)\n')

--if url2 then

--local video = 'https://cdn-auto.vse-tv.net/'  .. id .. '/' .. url2

--table.insert(t, {title = video, mrl = video})





	
	
--	end
-- end 


	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
	
	

	
		
		
		local headers1 = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=dvuqh70uqtu3i5pc9ude7qmqk1; _ga_05VH9CY87B=GS2.1.s1788611788$o1$g1$t1788611837$j11$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; _ym_visorc=w; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0, i"
}



local playlist = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist_settings'

local x = http.getz(playlist, headers1)

local m3u = string.match(x, '<h5.->Полный плейлист.-<a href="(http.-full.m3u)"')


local x = http.getz(m3u, headers1)



for group in string.gmatch(x, '#EXTINF.-group%-title="(.-)"') do

   table.insert(t, {title = group, mrl = '#stream/q=group&id=' .. group})

end



elseif args.q == 'group' then


local url = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist&page=1&limit=2000&genre=all&search='



local headers = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=pk3jievaefvcsna21kq4d9vsho; _ga_05VH9CY87B=GS2.1.s1788619031$o2$g1$t1788619820$j59$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}


 local x = http.getz(url, headers)


local cdn = string.match(x, 'class=.-"video%-btn ripple.-checkAndOpenModal%(.-,.-,.-, \'(.-)\', true')



local headers1 = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=pk3jievaefvcsna21kq4d9vsho; _ga_05VH9CY87B=GS2.1.s1788611788$o1$g1$t1788611969$j59$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; _ym_visorc=w; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}



local playlist = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist_settings'

local x = http.getz(playlist, headers1)

local m3u = string.match(x, '<h5.->Полный плейлист.-<a href="(http.-full.m3u)"')


local x = http.getz(m3u, headers1)


if group == 'group%-title=' .. '"' .. args.id .. '"' then

--if group then

for group, id, logo, name, token in string.gmatch(x, '#EXTINF.-group%-title="(.-)" tvg%-id="(.-)" tvg%-name=".-" tvg%-logo="(.-)",(.-)http.-/tv/(.-)=') do


--group = string.gsub(group, group, args.id)

id = string.gsub(id, '-', '_')


local url1 = 'https://' .. cdn .. '/' .. id .. '/index.m3u8?token=' .. token

table.insert(t, {title = name, mrl = url1, image = logo})

end
end





elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
     local url = 'http://live.guljaj.com/user/cab.php'
     
      	local params = 'sea=' .. urlencode(args.keyword) .. '&user=1133'

local headers = {
    ["Host"] = "live.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Content-Length"] = "",
    ["Origin"] = "http://live.guljaj.com",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://live.guljaj.com/user/cab.php",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; _ym_isad=2; mdd=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788619898%2C665940000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol-4PfTMYrAajF6CABHh5l2wmkMmQ-od0foZfHbe59lkNurTlDMXknCptH1cCDbvi-k2ZoW0_gz00YliZBM871QeYPAKM0FcmoiXdNuBF6HEwFQVFvqKZIbxSGQ6h89xd_hzTiexca8MQqXSm0bnvJFIG4cpeg%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
}


 local x = http.postz(url, headers, params)
     	
     	for title, idk, idc in string.gmatch(x, 'window.document.fidk.-return false.->(.-)</a>.-name=user.-<input type=hidden value=(.-)name=idk.-<input type=hidden value=(.-)name=idc') do
	
	
          
            local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(title)
			table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. idc .. '&id1=' .. idk, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})
			
	
		end
  




    elseif args.q == 'content' then
		
		local x = http.getz(args.id)

        for url in string.gmatch(x, 'document.-href="(/onlinetv/?.-)"') do
        url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = 'Активация tv', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
       for url in string.gmatch(x, 'document.-href="(/payment/?.-)"') do
        url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = 'Активация m3u', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		elseif args.q == 'channel' then
 

 
 local headers1 = {
    ["Host"] = "live.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Content-Length"] = "",
    ["Origin"] = "http://live.guljaj.com",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://live.guljaj.com/user/cab.php",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; _ym_isad=2; mdd=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788619898%2C665940000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol-4PfTMYrAajF6CABHh5l2wmkMmQ-od0foZfHbe59lkNurTlDMXknCptH1cCDbvi-k2ZoW0_gz00YliZBM871QeYPAKM0FcmoiXdNuBF6HEwFQVFvqKZIbxSGQ6h89xd_hzTiexca8MQqXSm0bnvJFIG4cpeg%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
}




 
 
 
--http://guljaj.com/live/ru/

--Host: guljaj.com
 
local url1 = 'http://live.guljaj.com/user/cab.php'




local params1 = 'user=1133&idc=' .. args.id .. '&idk=' .. args.id1 .. '&pl=2'

local x = http.postz(url1, headers1, params1)

local vid1 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if vid1 then
  
  return {view = 'playback', mrl = vid1, seekable = 'true', direct = 'true'}	
  
end







local videos = 'video_id=' .. args.id1

local headers = {
    ["Host"] = "guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://guljaj.com/live/ru/",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; _ym_isad=2; mdd=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788620346%2C241851000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; videos; FCNEC=%5B%5B%22AKsRol9KO22ZkG4zmQJgY8wwEmA0ZWHZXgx50IhPEXSlrpR0xZyxWImrfz6_UDtb_6_HlTbLY0wsSKOe1SnpmmrsqPVU4raPxJBNDs1zcg1czuLROQ5Q-fLQnmIt-gBXfpAhO4rNbE2_llMT_9eVZ2chE24JPlSYAg%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
}



--http://guljaj.com/live/ru/?id=6#goog_fullscreen_ad


-- local x = http.postz(url, headers, params)
 
 
 if not vid1 then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=1#goog_fullscreen_ad'
 
 local x = http.getz(url, headers)
 
 
 local video = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video then
  
  return {view = 'playback', mrl = video, seekable = 'true', direct = 'true'}	
  
--  table.insert(t, {title = video, mrl = video})
 end 
 end 
 
 if not open(video) then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=2#goog_fullscreen_ad'
 
 
 local x = http.getz(url, headers)
 
 
 local video1 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video1 then
  
  return {view = 'playback', mrl = video1, seekable = 'true', direct = 'true'}	
  
 end
 end
 
 
 if not open(video1) then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=3#goog_fullscreen_ad'
 
 
 local x = http.getz(url, headers)
 
 
 local video2 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video2 then
  
  return {view = 'playback', mrl = video2, seekable = 'true', direct = 'true'}	
  
 end
 end
 
 if not open(video2) then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=4#goog_fullscreen_ad'
 
 
 local x = http.getz(url, headers)
 
 
 local video3 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video3 then
  
  return {view = 'playback', mrl = video3, seekable = 'true', direct = 'true'}	
  
 end
 end
 
 if not open(video3) then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=4#goog_fullscreen_ad'
 
 
 local x = http.getz(url, headers)
 
 
 local video4 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video4 then
  
  return {view = 'playback', mrl = video4, seekable = 'true', direct = 'true'}	
  
 end
 end
		
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end