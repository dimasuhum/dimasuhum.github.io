-- onlinetv plugin

require('support')
require('video')
require('parser')

HOME = 'https://zigfreed.ru'

HOME_SLASH = HOME .. '/'

--https://vse-tv.net/tv-guide/2506-tv-rus-plus.html



--PASS = '7777'

--local lockpass


function onLoad()
	print('Hello from onlinetv plugin')
	return 1
end

function onUnLoad()
	print('Bye from onlinetv plugin')
end

function onCreate(args)

--if not args.q and args.keyword then
--lockpass = args.keyword
--end

--if lockpass == PASS then
--else
--return {view="keyword",message="enter --access code"}
--end



	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	if not args.q then
	

local url = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist&page=1&limit=2000&genre=all&search='



local headers = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=pk3jievaefvcsna21kq4d9vsho; _ga_05VH9CY87B=GS2.1.s1788619031$o2$g1$t1788619820$j59$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}


 local x = http.getz(url, headers)


local cdn = string.match(x, 'class=.-"video%-btn ripple.-checkAndOpenModal%(.-,.-,.-, \'(.-)\', true')



local headers1 = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=pk3jievaefvcsna21kq4d9vsho; _ga_05VH9CY87B=GS2.1.s1788611788$o1$g1$t1788611969$j59$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; _ym_visorc=w; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}



local playlist = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist_settings'

local x = http.getz(playlist, headers1)

local m3u = string.match(x, '<h5.->Полный плейлист.-<a href="(http.-full.m3u)"')


local x = http.getz(m3u, headers1)

x = string.gsub(x, x, '#')

for stream in string.gmatch(x, '(EXTINF.-)#') do

--table.insert(t, {title = stream})


for group, id, name, logo, names, token in string.gmatch(stream, 'group%-title="(.-)" tvg%-id="(.-)" tvg%-name="(.-)" tvg%-logo="(.-)",(.-)http.-/tv/(.-)=') do

id = string.gsub(id, '-', '_')


local url1 = 'https://' .. cdn .. '/' .. id .. '/index.m3u8?token=' .. token

TV_URL = 'https://vse-tv.net/tvguide/vse-tv.xml.gz'

--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'

TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(name)

		table.insert(t, {title = names, mrl = url1, group = group, name = name, image = logo, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})



end
end





--local x = http.getz(url1, headers1)

--local url2 = string.match(x, '(tracks.-)\n')

--if url2 then

--local video = 'https://cdn-auto.vse-tv.net/'  .. id .. '/' .. url2

--table.insert(t, {title = video, mrl = video})





	
	
--	end
-- end 


	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
	


local params = 'login_name=daniulov.d%40yandex.ru&login_password=dima1330&login=submit'

	
	local url = 'https://vse-tv.net/playlists.html'
		
		local headers = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["Origin"] = "https://vse-tv.net",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=dvuqh70uqtu3i5pc9ude7qmqk1; _ga_05VH9CY87B=GS2.1.s1788611788$o1$g1$t1788611837$j11$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; _ym_visorc=w; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0, i"
}


local x = http.postz(url, headers, params)


for group, name in string.gmatch(x, '<option value="(.-)">(.-)<') do

   table.insert(t, {title = name, mrl = '#stream/q=group&id=' .. group})

end



elseif args.q == 'group' then


	local page = tonumber(args.page or '1')
    
    
		
     local url = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist' .. '&page=' .. tostring(page) .. '&genre=' .. args.id .. '&search='



local headers = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=pk3jievaefvcsna21kq4d9vsho; _ga_05VH9CY87B=GS2.1.s1788619031$o2$g1$t1788619820$j59$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}


 local x = http.getz(url, headers)


for id, name, token, cdn, image in string.gmatch(x, 'class=.-"video%-btn ripple.-checkAndOpenModal%(\'(.-)\', \'(.-)\', \'(.-)\', \'(.-)\', true.-<img src=.-"(.-)"') do

title = string.gsub(name, '^(.-)', '{"name":"') .. '"}'

local v = json.decode(title)

local name = v['name']


image = string.gsub(image, '\\', '')

image = string.gsub(image, '^(.-)', 'https://vse-tv.net')





local url1 = 'https://' .. cdn .. '/' .. id .. '/index.m3u8?token=' .. token
	
  t['view'] = 'list'
 

 TV_URL = 'https://vse-tv.net/tvguide/vse-tv.xml.gz'
--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'


TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4
          
local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(name)

		table.insert(t, {title = name, mrl = url1, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO, image = image})
			
	
		end
  
local url = '#stream/page=' .. tostring(page + 1) .. '&q=group&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})





elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
	
	local page = tonumber(args.page or '1')
    
    
		
     local url = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist' .. '&page=' .. tostring(page) .. '&genre=all&search=' .. urlencode(args.keyword)



local headers = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "NETCLOUDCDN=pk3jievaefvcsna21kq4d9vsho; _ga_05VH9CY87B=GS2.1.s1788619031$o2$g1$t1788619820$j59$l0$h0; _ga=GA1.1.1455887954.1788611788; _ym_uid=1788611796413073323; _ym_d=1788611796; _ym_isad=2; vseTv_rfMirrorSeen=1; mdd=0; dle_user_id=40967; dle_password=6bbe9fd314c845cdfa99ea9a1b76f39c; dle_newpm=0; billing_plugins_bonus_day=1788694450; bonusBannerSeen=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}


 local x = http.getz(url, headers)


for id, name, token, cdn, image in string.gmatch(x, 'class=.-"video%-btn ripple.-checkAndOpenModal%(\'(.-)\', \'(.-)\', \'(.-)\', \'(.-)\', true.-<img src=.-"(.-)"') do

title = string.gsub(name, '^(.-)', '{"name":"') .. '"}'

local v = json.decode(title)

local name = v['name']


image = string.gsub(image, '\\', '')

image = string.gsub(image, '^(.-)', 'https://vse-tv.net')



	local url1 = 'https://' .. cdn .. '/' .. id .. '/index.m3u8?token=' .. token
	
t['view'] = 'list'
     
   

TV_URL = 'https://vse-tv.net/tvguide/vse-tv.xml.gz'

--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'


TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4
          
local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(name)

		table.insert(t, {title = name, mrl = url1, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO, image = image})
			
	
		end
  
local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})



    elseif args.q == 'content' then
		
		local x = http.getz(args.id)

        for url in string.gmatch(x, 'document.-href="(/onlinetv/?.-)"') do
        url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = 'Активация tv', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
       for url in string.gmatch(x, 'document.-href="(/payment/?.-)"') do
        url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = 'Активация m3u', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		elseif args.q == 'channel' then
 

 
 local headers1 = {
    ["Host"] = "live.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Content-Length"] = "",
    ["Origin"] = "http://live.guljaj.com",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://live.guljaj.com/user/cab.php",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; _ym_isad=2; mdd=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788619898%2C665940000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol-4PfTMYrAajF6CABHh5l2wmkMmQ-od0foZfHbe59lkNurTlDMXknCptH1cCDbvi-k2ZoW0_gz00YliZBM871QeYPAKM0FcmoiXdNuBF6HEwFQVFvqKZIbxSGQ6h89xd_hzTiexca8MQqXSm0bnvJFIG4cpeg%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
}




 
 
 
--http://guljaj.com/live/ru/

--Host: guljaj.com
 
local url1 = 'http://live.guljaj.com/user/cab.php'




local params1 = 'user=1133&idc=' .. args.id .. '&idk=' .. args.id1 .. '&pl=2'

local x = http.postz(url1, headers1, params1)

local vid1 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if vid1 then
  
  return {view = 'playback', mrl = vid1, seekable = 'true', direct = 'true'}	
  
end







local videos = 'video_id=' .. args.id1

local headers = {
    ["Host"] = "guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://guljaj.com/live/ru/",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; _ym_isad=2; mdd=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788620346%2C241851000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; videos; FCNEC=%5B%5B%22AKsRol9KO22ZkG4zmQJgY8wwEmA0ZWHZXgx50IhPEXSlrpR0xZyxWImrfz6_UDtb_6_HlTbLY0wsSKOe1SnpmmrsqPVU4raPxJBNDs1zcg1czuLROQ5Q-fLQnmIt-gBXfpAhO4rNbE2_llMT_9eVZ2chE24JPlSYAg%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
}



--http://guljaj.com/live/ru/?id=6#goog_fullscreen_ad


-- local x = http.postz(url, headers, params)
 
 
 if not vid1 then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=1#goog_fullscreen_ad'
 
 local x = http.getz(url, headers)
 
 
 local video = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video then
  
  return {view = 'playback', mrl = video, seekable = 'true', direct = 'true'}	
  
--  table.insert(t, {title = video, mrl = video})
 end 
 end 
 
 if not open(video) then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=2#goog_fullscreen_ad'
 
 
 local x = http.getz(url, headers)
 
 
 local video1 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video1 then
  
  return {view = 'playback', mrl = video1, seekable = 'true', direct = 'true'}	
  
 end
 end
 
 
 if not open(video1) then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=3#goog_fullscreen_ad'
 
 
 local x = http.getz(url, headers)
 
 
 local video2 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video2 then
  
  return {view = 'playback', mrl = video2, seekable = 'true', direct = 'true'}	
  
 end
 end
 
 if not open(video2) then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=4#goog_fullscreen_ad'
 
 
 local x = http.getz(url, headers)
 
 
 local video3 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video3 then
  
  return {view = 'playback', mrl = video3, seekable = 'true', direct = 'true'}	
  
 end
 end
 
 if not open(video3) then
 
 local url = 'http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=4#goog_fullscreen_ad'
 
 
 local x = http.getz(url, headers)
 
 
 local video4 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
  
  if video4 then
  
  return {view = 'playback', mrl = video4, seekable = 'true', direct = 'true'}	
  
 end
 end
		
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end