-- fast-film plugin

require('support')
require('video')
require('parser')

HOME = 'http://rutv.work'

HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid', type = 'folder'}
--	t['menu'] = {}
--	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
--	end

	if not args.q then
	--	local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
--		if page > 1 then
			url = url
			--.. '?page' .. tostring(page)
	--	end
		local x = http.getz(url)
         
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for url, image, title, total in string.gmatch(x, '<div class="telecan".-<a href="(.-)".-<img src="(.-)" alt="(.-)смотреть онлайн.-class="specific">(.-)<') do
          image = string.gsub(image, '^(.-)', HOME)
          url = string.gsub(url, '^(.-)', HOME)
          

			table.insert(t, {title = title .. '| ' .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
	--	local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
--		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		

	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)

		
         for url in string.gmatch(x, 'var player = new Playerjs.-file:.-"(.-)"') do
         
          
         url=http.urldecode(base64_decode(url))

        --    t['view'] = 'simple'
        
print(url)
			t = video(url, args)
			if t['view'] ~= 'error' then
				break
			end
				table.insert(t,{mrl = url})
        end  
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end