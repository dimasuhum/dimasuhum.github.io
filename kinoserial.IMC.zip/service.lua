-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate


local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'



local HOME = 'https://kinoserials.tv'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/country/СССР/
	-- #stream/genre=/country/Индия/
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/genre/боевик
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/url=/show/
    -- #stream/genre=/show/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/latest-updates/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/' .. tostring(page) .. '/'
		end
		
		
        
	--	local x = http.getz(url)
	
        local x = conn:load(url)
		
     
   
       for url, title, image in string.gmatch(x, '<div class="item.-<a href="(.-)" title="(.-)".-<img class="thumb" src="(.-)"') do

	--		url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
   
   
       
		
		
            for url, image, title in string.gmatch(x, '<a class="item" href="https://.-(/franchise/.-)".-<img class="thumb" src="(.-)" alt="(.-)"') do
     
     	table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
     	end

         for url, title, image in string.gmatch(x, '<a class="item" href="https://.-(/actors/.-)" title="(.-)".-<img src="(.-)"') do
     
     	table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
     	end





   --      for url, image, title in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/actors.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<') do


     --     for url, title in string.gmatch(x, '<div class="MiniPostName".-<a href=".-(/actors.-html)".-title="(.-)"') do

      --   t['view'] = 'simple'

	--		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
--		end

   
   

   
    		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		

         


      table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. '/films/'})

       table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serials/'})

		
       table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/multfilms/'})

       table.insert(t, {title = 'Мультсериалы', mrl = '#stream/genre=' .. '/multserials/'})
		
	table.insert(t, {title = 'Актеры', mrl = '#stream/genre=' .. '/actors/'})

       table.insert(t, {title = 'Франшизы', mrl = '#stream/genre=' .. '/franchise/'})
			
		local x = conn:load(HOME .. '/categories/')
		

	
	
		local x = string.match(x, '<div class="list%-categories">(.-)<div class="footer%-margin"')
		
         for genre, image, title in string.gmatch(x, '<a class="item" href="https://.-(/.-)".-<img class="thumb" src="(.-)" alt="(.-)"') do
        	
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
			end
			
			
--https://tv-2-kinoserial.net/search/%D0%A0%D0%BE%D0%BA%D0%BA%D0%B8/			
			
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/' .. urlencode(args.keyword)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
        for url, title, image in string.gmatch(x, '<div class="item.-<a href="(.-)" title="(.-)".-<img class="thumb" src="(.-)"') do


			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
		local x = conn:load(args.id)
    --	local x = http.getz(args.id)
		
       -- x = string.gsub(x, 'onclick', '')
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<h1>(.-)</h1>')
		t['description'] = parse_match(x, '<div class="item".-Описание:.-<em>(.-)</em>')
		--	t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="FullstoryFormLeft".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			

			
			
			
	    	t['annotation'] = parse_array(x, {
    	'h2>(Год выхода:.-)</h2>', '<h2>(Оригинальное название:.-)</h2>',
			'<div class="info%-content".->(.-)<span class="name"',
		
			'(Перевод:</h4>.-)</p>',
			'(Качество:</h4>.-)</p>',
			'(Время:</h4>.-)</p>',
			'(Бюджет:</h4>.-)</p>'})
   
  
   --  for title in string.gmatch(x, 'charset(.-)player.api') do
--    table.insert(t, {title = title, mrl = title})
		
	--	end





             for title in string.gmatch(x, '{"title": "(.-сезон)"') do
             
           for total, total1,  url in string.gmatch(x, '"title":"(.-серия)".-%[(480p)](http.-mp4)') do

			table.insert(t, {title = tolazy(title) .. ' ' .. (total) .. (total1), mrl = url})
		
		end
        end
             
             
             
                        for title in string.gmatch(x, 'new Playerjs.-"id":"serial.-"title".-"(.-сезон)"') do
             
           for total, total1,  url in string.gmatch(x, '"title":"(.-серия)".-%[(1080p)](http.-mp4)') do

			table.insert(t, {title = tolazy(title) .. ' ' .. (total) .. (total1), mrl = url})
		
		end
        end
  
    
    

  
  
         for title, url in string.gmatch(x, 'new Playerjs.-"id":"Video.-%[(480p)](http.-mp4)') do

			table.insert(t, {title = tolazy(title), mrl = url})
		
		end
  
  
        for title, url in string.gmatch(x, 'new Playerjs.-"id":"Video.-%[(1080p)](http.-mp4)') do

			table.insert(t, {title = tolazy(title), mrl = url})
		
		end
        
        
        

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end