-- hdrezka plugin

require('support')
require('video')
require('parser')
require('client')


local video = require('video')
local parser = require('parser')

local headers = {
	['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
	Connection = 'close'
}
--https://reyohoho.ru/?ip=37.1.201.40/http://kinopub.me/films/fiction/67469-borderlends-2024.html

--https://cors.nb557.workers.dev:8443/https://kinobase.org/user_data?page=movie&movie_id=234172&cuid=3ef6ea31dd1fb488e6aa1d1438d1151a&device=DESKTOP&_=1725387712094

--https://cors557.deno.dev/?ip=45.10.217.13/http://kinopub.me
--https://byzkhkgr.deploy.cx/?ip=45.10.217.13/http://kinopub.me
--https://iqslgbok.deploy.cx/?ip=45.10.217.13/http://kinopub.me/films/drama/73572-proklyatye-2024.html

--https://cors.nb557.workers.dev:8443/?ip=45.10.217.13/http://kinopub.me/films/drama/73572-proklyatye-2024.html
--185.228.133.191
--62.182.9.87
--https://cors.nb557.workers.dev:8443/?ip=45.10.217.13/http://kinopub.me
--local HOME = 'http://hdrezka.co'

--https://cors.nb557.workers.dev:8443/?ip=45.10.217.13/http://kinopub.me/films/best/2024/


local HOME = 'http://kinopub.me'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

--http://kinopub.me/films/horror/1447-chuzhoy-1979.html
--HOME = 'http://hdrezkagroup.org'
--HOME = 'http://hdrezka.tv'
--HOME = 'http://kinopub.me'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from hdrezka plugin')
	return 1
end

function onUnLoad()
	print('Bye from hdrezka plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
		table.insert(t['menu'], {title = '@string/search', url = url_for{q = 'search'}, icon = get_image('search.png')})
	
	-- #stream/page=2
	-- #stream/genre=/serialy-2020/page/
	-- #stream/genre=/collections/
	-- #stream/genre=/collections/filmy-pro-rozhdestvo-i-novyy-god/
	-- #stream/url=/serials/
	-- #stream/url=/serials/tureckie_serialy/
	-- #stream/url=/serials/brazilskie-serialy/
	-- #stream/url=/serials/indijskie_serialy/
	-- #stream/url=/serials/meksikanskie-serialy/
	-- #stream/url=/serials/ispanskie-serialy/
	-- #stream/url=/serials/doramy/
	-- #stream/url=/serials/novye_serialy/
    -- #stream/url=/filmy_online/filmy_2020_online_hd/
    -- #stream/url=/serials/amerikanskie-serialy/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
	

		
	if genre == '/?filter=popular' then
  --   local url = HOME .. genre
		if page > 1 then
			url = HOME .. '/page/' .. tostring(page) .. genre
		end
	end	
	if genre == '/?filter=watching' then
  --   local url = HOME .. genre
		if page > 1 then
			url = HOME .. '/page/' .. tostring(page) .. genre
		end
	end	
	
		
	if genre == '/?filter=last' then
  --   local url = HOME .. genre
		if page > 1 then
			url = HOME .. '/page/' .. tostring(page) .. genre
		end
	end	
	
		
--		local x = http.getz(url)
        local x = conn:load(url)
        --x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-data%-url="(http.-)".-<img src="(.-)".-class="b%-content__inline_item%-link".-href=.->(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^(.-)', 'https://cors.nb557.workers.dev:8443/?ip=45.10.217.13/')
	--	  image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
        for url, image, title in string.gmatch(x, '<div class="b%-content__collections_item" data%-url="http://.-(/.-)".-src="(.-)".-class="title">(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
			--image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
		
		end
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


        table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/new/'})
		table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections/'})
		

		table.insert(t, {title = 'Последние поступления', mrl = '#stream/genre=' .. '/?filter=last'})
		
		

		table.insert(t, {title = 'Популярные', mrl = '#stream/genre=' .. '/?filter=popular'})
		
       table.insert(t, {title = 'Сейчас смотрят', mrl = '#stream/genre=' .. '/?filter=watching'})



        local x = conn:load(HOME)
		
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, '<ul class="right">(.-)<a href="/animation/military/')
		for title, genre  in string.gmatch(x, '<a title="(.-)" href="(.-)"') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end
        local x = conn:load(HOME)
    	local x = string.match(x, '<div class="b%-topnav__sub_inner">(.-)</div>')
		for genre, title in string.gmatch(x, '<.-="(/films/.-)">(.-)</') do
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
   --     local x = http.getz(HOME)
  --  	local x = string.match(x, '<a class="b%-topnav__item%-link" href="/series/">(.-)</div>')
--		for genre, title in string.gmatch(x, '<.-="(/series/.-)">(.-)</') do
		--	table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
	--	end
        local x = conn:load(HOME)
    	local x = string.match(x, '<a class="b%-topnav__item%-link" href="/cartoons/">(.-)</div>')
        for genre, title in string.gmatch(x, '<.-="(/cartoons/.-)">(.-)</') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
         local x = conn:load(HOME)
        local x = string.match(x, '<a class="b%-topnav__item%-link" href="/animation/">(.-)</div>')
        for genre, title in string.gmatch(x, '<.-="(/animation/.-)">(.-)</') do
			table.insert(t, {title = 'АНИМЕ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	-- #stream/q=search&keyword=4400
--http://hdrezka.me/search/?do=search&subaction=search&q=%D0%9F%D0%BE&page=2
	
	
--http://hdrezka.co/search/?do=search&subaction=search&q=%D1%80%D0%BE%D0%BA%D0%BA

--1/1http://fxmlparsers.ru/http://kinopub.me//?id=search&search=%D0%BA%D0%B0%D0%BA%20%D0%BF%D1%80%D0%B8%D1%80%D1%83%D1%87%D0%B8%D1%82%D1%8C%20%D0


	-- #stream/q=search&keyword=4400
	elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
			
			local url = HOME .. '/search/?do=search&subaction=search&q=' .. urlencode(args.keyword)
			local x = conn:load(url)
			--local x = string.match(x, '<div class="b%-content__inline_items">(.+)')
		--	print(x)
			
			for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
				table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
			end
	--		end
			
	
	-- #self/q=content&id=http://hdrezka.co/series/action/43391-tysyacha-klykov-2021.html
	-- #self/q=content&id=http://hdrezka.co/films/documentary/42634-bondarchuk-battle-2021.html
	-- #self/q=content&id=http://hdrezka.co/series/detective/43638-chto-znaet-marianna-2021.html
	-- #self/q=content&id=http://hdrezka.co/series/fiction/43239-moguchie-reyndzhery-dikiy-mir-2002.html


	
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		
		
   --     local x = http.getz('https://cors.nb557.workers.dev:8443/?ip=45.10.217.13/' .. args.id)
		
		local x = conn:load(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
			t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="b%-post__description_text">(.-)</div>')
     --   t['poster'] = args.p
		t['poster'] = parse_match(x,'<img itemprop="image" src="(.-)"')
		if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(Дата выхода</h2>:</td>.-)</td>','(Жанр</h2>:</td>.-)</td>', '(Страна</h2>:</td>.-)</td>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
 
-- https://reyohoho.space:4435/get_hdruhd5/17109/series/series/thriller/17109-ochen-strannye-dela-2016.html
 
--https://reyohoho.space:4435/get_episode/17109/111_0/-1/-1/rezka.ag/series/thriller/17109-ochen-strannye-dela-2016.html

--var CDNplayerConfig = {'id': 'player', 'cuid': '17109_1_1', 'file': [{'title': 'Hdrezka studio', 'folder': [{'title': 'Сезон 1', 'folder': [{'title': 'Серия 1', 'file': '[




--https://reyohoho.space:4435/get_hdruhd5/755/movie/rezka.ag/films/melodrama/755-titanik-1997.html

--var CDNplayerConfig = {'id': 'player', 'cuid': '755', 'file': [{'title': 'Дубляж', 'file': \'%[360




--https://reyohoho.space:4435/get_movie3/755/56_0/rezka.ag/films/melodrama/755-titanik-1997.html


--https://reyohoho.space:4435/get_episode/25509/111_0/-1/-1/rezka.ag/series/thriller/25509-bumazhnyy-dom-2017.html

    
    
            for url, url1, url2 in string.gmatch(x, '<meta property="og:type" content="video.(movie)".-<meta property="og:video" content="http://.-(/.-)".-class="b%-sidelinks__link show%-trailer" data%-id="(.-)"') do

        url = string.gsub(url2, '^(.-)','https://reyohoho.space:4435/get_hdruhd5/') .. '/' .. url .. '/rezka.ag' .. url1

         
--https://reyohoho.space:4435/get_hdruhd5/755/movie/rezka.ag/films/melodrama/755-titanik-1997.html

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end

--https://reyohoho.space:4435/get_hdruhd5/755/movie/rezka.ag/films/melodrama/755-titanik-1997.html

--var CDNplayerConfig = {'id': 'player', 'cuid': '755', 'file': [{'title': 'Дубляж', 'file': '[360p]https://femeretes.org/e90dbad52df7b89d5031cf9c925f73c9:2024101103:TUZWcy9ia2xDVFphcDQzUW9QcXIrWnZiOUhZZkhNZEFDazVWQXhCYksyRTdpd3lLRU1iZ3ArY2dXSzFxVzlYMDZMRzB3U3JGdzZwd3M4T1BsekZCcHc9PQ==/8/1/2/4/5/9/zzy7j.mp4

        for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(360p)](http.-.mp4)') do
        
        t['view'] = 'simple'




        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end

        for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(480p)](http.-.mp4)') do
        
        t['view'] = 'simple'

        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end


        for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(720p)](http.-.mp4)') do
        
        t['view'] = 'simple'

        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end


        for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(1080p)](http.-.mp4)') do
        
        t['view'] = 'simple'

        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end

      for title, total, url in string.gmatch(x, 'var CDNplayerConfig = {.-player.-file.-%[{.-title.-: \'(.-)\',.-file.-%[(1080p Ultra)](http.-.mp4)') do
        
        t['view'] = 'simple'

        table.insert(t, {title = title .. ' ' .. (total), mrl = url})

		end

--https://reyohoho.serv00.net/#915196

--https://reyohoho.space:4435/get_hdruhd5/17109/series/rezka.ag/series/thriller/17109-ochen-strannye-dela-2016.html




--

--{'title': 'Сезон 1', 

--'folder': [{'title': 'Серия 1', 'file': '[360p](http.-.mp4),




--{\'title\': \'(Серия (.-)\', \'id\': \'next\', \'file\': \'(http.-)\',

     
     for total1, url3, url4 in string.gmatch(x, '{\'title\': \'(.-)\', \'file\':.-\'redirectPlayer\': \'(http.-)(/get_movie.-.html)\'') do

       
       t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total1), mrl = '#stream/q=content&id=' .. url3 .. url4})

		end
     --  end

  
  
        for url, url1, url2 in string.gmatch(x, '<meta property="og:type" content="video.-(series)".-<meta property="og:video" content="http://.-(/.-)".-class="b%-sidelinks__link show%-trailer" data%-id="(.-)"') do

        url = string.gsub(url2, '^(.-)','https://reyohoho.space:4435/get_hdruhd5/') .. '/' .. url .. '/rezka.ag' .. url1

         

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
  
  

      for title in string.gmatch(x, '{\'title\': \'(Сезон.-)\'') do
       for total1, url3, url4 in string.gmatch(x, '{\'title\': \'(Серия.-)\', \'file\':.-\'redirectPlayer\': \'(http.-)(/get_episode.-.html)\'') do

       
       t['view'] = 'simple'
      
      table.insert(t, {title = title .. tolazy(total1), mrl = '#stream/q=content&id=' .. url3 .. url4})

		end
        end
--https://reyohoho.space:4435/get_episode


       elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end