-- hdrezka plugin

require('support')
require('video')
require('parser')

local video = require('video')
local parser = require('parser')
local headers = {
	['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
	Connection = 'close'
}
--HOME = 'http://hdrezkagroup.org'
--HOME = 'http://hdrezka.tv'
HOME = 'http://hdrezka.co'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from hdrezka plugin')
	return 1
end

function onUnLoad()
	print('Bye from hdrezka plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	--	table.insert(t['menu'], {title = '@string/search', url = url_for{q = 'search'}, icon = get_image('search.png')})
	
	-- #stream/page=2
	-- #stream/genre=/serialy-2020/page/
	-- #stream/genre=/collections/
	-- #stream/genre=/collections/filmy-pro-rozhdestvo-i-novyy-god/
	-- #stream/url=/serials/
	-- #stream/url=/serials/tureckie_serialy/
	-- #stream/url=/serials/brazilskie-serialy/
	-- #stream/url=/serials/indijskie_serialy/
	-- #stream/url=/serials/meksikanskie-serialy/
	-- #stream/url=/serials/ispanskie-serialy/
	-- #stream/url=/serials/doramy/
	-- #stream/url=/serials/novye_serialy/
    -- #stream/url=/filmy_online/filmy_2020_online_hd/
    -- #stream/url=/serials/amerikanskie-serialy/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
		local x = http.getz(url)
         
        --x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for url, image, title, total in string.gmatch(x, '<div class="b%-content__inline_item%-cover".-<a href="(http://hdrezka.-)".-<img src="(.-)".-class="b%-content__inline_item%-link".-a href=".->(.-)<.-<div>(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
		  image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
        for url, image, title in string.gmatch(x, '<div class="b%-content__collections_item" data%-url="http://.-(/.-)".-src="(.-)".-class="title">(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
			--image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
		
		end
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


        table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/new/'})
		table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections/'})




        local x = http.getz(HOME)
		
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, '<ul class="right">(.-)<a href="/animation/military/')
		for title, genre  in string.gmatch(x, '<a title="(.-)" href="(.-)"') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end
        local x = http.getz(HOME)
    	local x = string.match(x, '<div class="b%-topnav__sub_inner">(.-)</div>')
		for genre, title in string.gmatch(x, '<.-="(/films/.-)">(.-)</') do
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
   --     local x = http.getz(HOME)
  --  	local x = string.match(x, '<a class="b%-topnav__item%-link" href="/series/">(.-)</div>')
--		for genre, title in string.gmatch(x, '<.-="(/series/.-)">(.-)</') do
		--	table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
	--	end
        local x = http.getz(HOME)
    	local x = string.match(x, '<a class="b%-topnav__item%-link" href="/cartoons/">(.-)</div>')
        for genre, title in string.gmatch(x, '<.-="(/cartoons/.-)">(.-)</') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
         local x = http.getz(HOME)
        local x = string.match(x, '<a class="b%-topnav__item%-link" href="/animation/">(.-)</div>')
        for genre, title in string.gmatch(x, '<.-="(/animation/.-)">(.-)</') do
			table.insert(t, {title = 'АНИМЕ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	-- #stream/q=search&keyword=4400
--http://hdrezka.me/search/?do=search&subaction=search&q=%D0%9F%D0%BE&page=2
	
	
--http://hdrezka.co/search/?do=search&subaction=search&q=%D1%80%D0%BE%D0%BA%D0%BA



	-- #stream/q=search&keyword=4400
	elseif args.q == 'search' then
		if args.keyword then
			
			local url = HOME .. '/search/?' .. http.encode{
				['do'] = 'search',
				subaction = 'search',
				q = args.keyword
			}
			local x = http.getz(url, headers)
			--local x = string.match(x, '<div class="b%-content__inline_items">(.+)')
			print(x)
			
			for id, icon, title in string.gmatch(x, '<div class="b%-content__inline_item".-href="(.-)".- src="(.-)".-alt="(.-)"') do
				table.insert(t, {
					title = title,
					url = url_for{q = 'content', id = id},
					icon = icon
				})
			end
			
			if #t == 0 then
				return {view = 'message', message = '@string/search_reply'}
			end
		else
			return {view = 'keyword', message = '@string/search_text'}
		end
	
	-- #self/q=content&id=http://hdrezka.co/series/action/43391-tysyacha-klykov-2021.html
	-- #self/q=content&id=http://hdrezka.co/films/documentary/42634-bondarchuk-battle-2021.html
	-- #self/q=content&id=http://hdrezka.co/series/detective/43638-chto-znaet-marianna-2021.html
	-- #self/q=content&id=http://hdrezka.co/series/fiction/43239-moguchie-reyndzhery-dikiy-mir-2002.html


	
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="b%-post__description_text">(.-)</div>')
     --   t['poster'] = args.p
		t['poster'] = parse_match(x,'<img itemprop="image" src="(.-)"')
		if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
        



                 local slist=string.match(x,'"id":"cdnplayer".-"streams.-#h(.-)"')
     --    print(url)
		 slist = string.gsub(slist, '\\/\\/_\\/\\/', '')
         slist = string.gsub(slist, 'QEBAQEAhIyMhXl5e', '')
         slist = string.gsub(slist, 'JCQjISFAIyFAIyM=', '')
         slist = string.gsub(slist, 'JCQhIUAkJEBeIUAjJCRA', '')
         slist = string.gsub(slist,'Xl5eIUAjIyEhIyM=', '')
         slist = string.gsub(slist,'IyMjI14hISMjIUBA', '')




         slist=http.urldecode(base64_decode(slist))
        
		if slist then
			for title, url in string.gmatch(slist, '(360p).-(http.-.mp4)') do
       --     t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if slist then
			for title, url in string.gmatch(slist, '(480p).-(http.-.mp4)') do
         --    t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if slist then
			for title, url in string.gmatch(slist, '(720p).-(http.-.mp4)') do
         --   t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if slist then
			for title, url in string.gmatch(slist, '(1080p)].-(http.-.mp4)') do
         --   t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if slist then
			for title, url in string.gmatch(slist, '(1080p Ultra).-(http.-.mp4)') do
       --     t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end



--http://hdrezka.tv/series/melodrama/47872-koroleva-serdec-1998.html#t:59-s:1-e:2

         local slist=string.match(x,'<div id="simple%-episodes%-tabs">(.-)"streams":"#h')

    --     slist = string.gsub(slist, '^(.-)','#t:')
         
       
         if slist then
			for url, url1, title in string.gmatch(slist, 'data%-season_id="(.-)" data%-episode_id="(.-)">(Серия.-)<') do
			
            for url2 in string.gmatch(slist, 'initCDNSeriesEvents.-, (.-),') do
         
            

         
    --     url = string.gsub(url, '^(.-)', args.id .. '#t:' .. url2 .. '-s:') .. '-e:' .. url1
         
        	table.insert(t, {title = args.id .. '#t:' .. url2 .. '-s:' .. url .. '-e:' .. url1, mrl = '#stream/q=content&id=' .. args.id .. '#t:' .. url2 .. '-s:' .. url .. '-e:' .. url1})
			end
			end
   		end	
         
         
     --    for url1 in string.gmatch(x, 'initCDNSeriesEvents.-, (.-),') do
    --      print(url1)
	--	 url1 = string.gsub(url1, '^(.-)', '#t:')

    --     for url, url1, title in string.gmatch(x, 'data%-season_id="(.-)" data%-episode_id="(.-)">(Серия.-)<') do
		 
   --     for url2 in string.gmatch(x, 'initCDNSeriesEvents.-, (.-),') do
		 
		 
		 
     --   table.insert(t, {title = args.id .. url1 .. '-s:' .. url2 .. '-e:' .. url3, mrl = '#stream/q=content&id=' .. args.id .. url1 .. '-s:' .. url2 .. '-e:' .. url3})
   --    table.insert(t, {title = args.id .. '#t:' .. url2 .. '-s:' .. url .. '-e:' .. url1, mrl = '#stream/q=content&id=' .. args.id .. '#t:' .. url2 .. '-s:' .. url .. '-e:' .. url1})
	--	end
   --     end

     
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end
