-- hdrezka plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--local video = require('video')
--local parser = require('parser')

local headers = {
	['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
	Connection = 'close'
}



--https://rezka.ag/search/?do=search&subaction=search&q=%2C+%D1%87%D1%83%D0%B6%D0%BE%D0%B9+%D0%B7%D0%B5%D0%BC%D0%BB%D1%8F-2025


local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'

--https://hdrezka1twwpb.org

--local HOME = 'http://kinopub.me'
local HOME = 'https://rezka.ag'
--local HOME = 'https://rezka.ac'


--https://lampa.persh1n.ru/lite/rezka?rjson=False&href=https://rezka.ag/series/fantasy/62784-murashki-2023.html


--https://lampa.persh1n.ru/lite/rezka?title=Рука качающая Колыбель&year=2025

--https://lampa.persh1n.ru/lite/rezka?rjson=False&href=https%3A%2F%2Frezka%2Eag%2Fseries%2Ffiction%2F80082%2Dchuzhoy%2Dzemlya%2D2025%2Dlatest%2Ehtml&id=80082&t=489

--local HOME = 'https://hdrezka1twwpb.org'
--local HOME = 'http://hdrezka0ddqyq.org'
--local HOME = 'http://hdrezka.co'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH
local conn1 = client.new()
conn1['encoding'] = 'UTF-8'

--HOME = 'http://hdrezkagroup.org'
--HOME = 'http://hdrezka.tv'
--HOME = 'http://kinopub.me'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from hdrezka plugin')
	return 1
end

function onUnLoad()
	print('Bye from hdrezka plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
		table.insert(t['menu'], {title = '@string/search', url = url_for{q = 'search'}, icon = get_image('search.png')})
    table.insert(t['menu'], {title = 'Лучшее', url = url_for{q = 'best'}, image = '#self/list.png'})


--https://rezka.ag/films/best/fantasy/2020/	
	-- #stream/page=2
	-- #stream/genre=/serialy-2020/page/
	-- #stream/genre=/collections/
	-- #stream/genre=/collections/filmy-pro-rozhdestvo-i-novyy-god/
	-- #stream/url=/serials/
	-- #stream/url=/serials/tureckie_serialy/
	-- #stream/url=/serials/brazilskie-serialy/
	-- #stream/url=/serials/indijskie_serialy/
	-- #stream/url=/serials/meksikanskie-serialy/
	-- #stream/url=/serials/ispanskie-serialy/
	-- #stream/url=/serials/doramy/
	-- #stream/url=/serials/novye_serialy/
    -- #stream/url=/filmy_online/filmy_2020_online_hd/
    -- #stream/url=/serials/amerikanskie-serialy/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

        local x = conn:load(url)
        --x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
        
       
       
    --   t['filter'] = {}
--if args.q ~= 'filter' then
--t['view'] = 'simple'

 --  table.insert(t, {title = 'последние', mrl = '#stream/q=filter&genre=' .. genre .. '&id=' .. '?filter=last', image = '#self/list.png'})
        
        
        table.insert(t, {title = 'популярные', mrl = '#stream/q=filter&genre=' .. genre .. '&id=' .. '?filter=popular', image = '#self/setting.png'})
        
        
        table.insert(t, {title = 'сейчас смотрят', mrl = '#stream/q=filter&genre=' .. genre .. '&id=' .. '?filter=watching', image = '#self/setting.png'})
        
--table.insert(t, {title = 'в ожидание', mrl = '#stream/q=filter&genre=' .. genre .. '&id=' .. '?filter=soon', image = '#self/list.png'})
        

       
      --   end
--https://rezka.ag/?filter=watching
        
        
		for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-data%-url="(http.-)".-<img src="(.-)".-class="b%-content__inline_item%-link".-href=.->(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
	--	  image = string.gsub(image, '^/', HOME_SLASH)
	
     t['view'] = 'grid_poster'
	
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end




		
        for url, image, title in string.gmatch(x, '<div class="b%-content__collections_item" data%-url="http.-(/collections.-)".-src="(.-)".-class="title">(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
			--image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
		
		end
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'



table.insert(t, {title = 'Лучшие фильмы', mrl = '#stream/q=bestf', image = '#self/setting.png'})

table.insert(t, {title = 'Лучшие сериалы', mrl = '#stream/q=bests', image = '#self/setting.png'})

table.insert(t, {title = 'Лучшие мультфильмы', mrl = '#stream/q=bestm', image = '#self/setting.png'})


table.insert(t, {title = 'Лучшее аниме', mrl = '#stream/q=besta', image = '#self/setting.png'})




        table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/new/', image = '#self/film.png'})
		table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections/', image = '#self/setting.png'})


--https://rezka.ag/collections/







        local x = conn:load(HOME)
		
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, '<ul class="right">(.-)<a href="/animation/military/')
		for title, genre  in string.gmatch(x, '<a title="(.-)" href="(.-)"') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/film.png'})
			
end
		
		
        local x = conn:load(HOME)
    	local x = string.match(x, '<div class="b%-topnav__sub_inner">(.-)</div>')
		for genre, title in string.gmatch(x, '<.-="(/films/.-)">(.-)</') do
	
	
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/film.png'})
			
			
		end
        local x = conn:load(HOME)
    	local x = string.match(x, '<a class="b%-topnav__item%-link" href="/series/">(.-)</div>')
		for genre, title in string.gmatch(x, '<.-="(/series/.-)">(.-)</') do
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end
        local x = conn:load(HOME)
    	local x = string.match(x, '<a class="b%-topnav__item%-link" href="/cartoons/">(.-)</div>')
        for genre, title in string.gmatch(x, '<.-="(/cartoons/.-)">(.-)</') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end
         local x = conn:load(HOME)
        local x = string.match(x, '<a class="b%-topnav__item%-link" href="/animation/">(.-)</div>')
        for genre, title in string.gmatch(x, '<.-="(/animation/.-)">(.-)</') do
			table.insert(t, {title = 'АНИМЕ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	-- #stream/q=search&keyword=4400
--http://hdrezka.me/search/?do=search&subaction=search&q=%D0%9F%D0%BE&page=2
	
	
--http://hdrezka.co/search/?do=search&subaction=search&q=%D1%80%D0%BE%D0%BA%D0%BA

--1/1http://fxmlparsers.ru/http://kinopub.me//?id=search&search=%D0%BA%D0%B0%D0%BA%20%D0%BF%D1%80%D0%B8%D1%80%D1%83%D1%87%D0%B8%D1%82%D1%8C%20%D0



--https://rezka.ag/films/best/fantasy/2020/	
   elseif args.q == 'best' then


table.insert(t, {title = 'Лучшие фильмы', mrl = '#stream/q=bestf', image = '#self/setting.png'})

table.insert(t, {title = 'Лучшие сериалы', mrl = '#stream/q=bests', image = '#self/setting.png'})

table.insert(t, {title = 'Лучшие мультфильмы', mrl = '#stream/q=bestm', image = '#self/setting.png'})


table.insert(t, {title = 'Лучшее аниме', mrl = '#stream/q=besta', image = '#self/setting.png'})

    elseif args.q == 'bestf' then

     local x = conn:load(HOME)
   
     t['view'] = 'simple'
   
   	local slist = string.match(x, '<div class="b%-topnav__findbest_select">(.-)</div>')
	
		for genre, title in string.gmatch(slist, '<.-="(/films/.-)">(.-)</') do
 	
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/q=bestfg&id=' .. genre,image = '#self/film.png'})
		end	

		

   elseif args.q == 'bestfg' then

     local x = conn:load(HOME .. args.id)
   
       t['view'] = 'simple'
  
     for title1 in string.gmatch(x, '<title>(.-)- смотреть онлайн') do
     local slist = string.match(x, '<select class="select%-year"(.-)</select>')
	
   for genre1, title2 in string.gmatch(slist, '<option value="(.-)">(.-)</option>') do
  
      genre = string.gsub(genre1, '^(.-)', args.id) .. '/'
	genre = string.gsub(genre, '/0/', '/')
	
    
   table.insert(t, {title = 'ФИЛЬМЫ:' .. tolazy(title1) .. ' ' .. title2, mrl = '#stream/q=bestv&id=' .. genre,image = '#self/film.png'})
		end	
		end
   
   
   
   
   
   
elseif args.q == 'bests' then

     local x = conn:load(HOME)
   
     t['view'] = 'simple'
   
   	local slist = string.match(x, 'Найти лучшие сериалы.-<div class="b%-topnav__findbest_select">(.-)</div>')
	
		for genre, title in string.gmatch(slist, '<option value="(/series/.-)">(.-)</') do
 	
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/q=bestsg&id=' .. genre,image = '#self/film.png'})
		end	

		

   elseif args.q == 'bestsg' then

     local x = conn:load(HOME .. args.id)
   
       t['view'] = 'simple'
  
     for title1 in string.gmatch(x, '<title>(.-)- смотреть онлайн') do
     local slist = string.match(x, '<select class="select%-year"(.-)</select>')
	
   for genre1, title2 in string.gmatch(slist, '<option value="(.-)">(.-)</option>') do
  
      genre = string.gsub(genre1, '^(.-)', args.id) .. '/'
	genre = string.gsub(genre, '/0/', '/')
	
    
   table.insert(t, {title = 'СЕРИАЛЫ:' .. tolazy(title1) .. ' ' .. title2, mrl = '#stream/q=bestv&id=' .. genre,image = '#self/film.png'})
		end	
		end
   
   
   
   
elseif args.q == 'bestm' then

     local x = conn:load(HOME)
   
     t['view'] = 'simple'
   
   	local slist = string.match(x, 'Найти лучшие мультфильмы.-<div class="b%-topnav__findbest_select">(.-)</div>')
	
		for genre, title in string.gmatch(slist, '<.-="(/cartoons/.-)">(.-)</') do
 	
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/q=bestmg&id=' .. genre,image = '#self/film.png'})
		end	

		

   elseif args.q == 'bestmg' then

     local x = conn:load(HOME .. args.id)
   
       t['view'] = 'simple'
  
     for title1 in string.gmatch(x, '<title>(.-)- смотреть онлайн') do
     local slist = string.match(x, '<select class="select%-year"(.-)</select>')
	
   for genre1, title2 in string.gmatch(slist, '<option value="(.-)">(.-)</option>') do
  
      genre = string.gsub(genre1, '^(.-)', args.id) .. '/'
	genre = string.gsub(genre, '/0/', '/')
	
    
   table.insert(t, {title = 'МУЛЬТФИЛЬМЫ:' .. tolazy(title1) .. ' ' .. title2, mrl = '#stream/q=bestv&id=' .. genre,image = '#self/film.png'})
		end	
		end





elseif args.q == 'besta' then

     local x = conn:load(HOME)
   
     t['view'] = 'simple'
   
   	local slist = string.match(x, 'Найти лучшее аниме.-<div class="b%-topnav__findbest_select">(.-)</div>')
	
		for genre, title in string.gmatch(slist, '<.-="(/animation/.-)">(.-)</') do
 	
			table.insert(t, {title = 'АНИМЕ : ' .. tolazy(title), mrl = '#stream/q=bestag&id=' .. genre,image = '#self/film.png'})
		end	

		

   elseif args.q == 'bestag' then

     local x = conn:load(HOME .. args.id)
   
       t['view'] = 'simple'
  
     for title1 in string.gmatch(x, '<title>(.-)- смотреть онлайн') do
     local slist = string.match(x, '<select class="select%-year"(.-)</select>')
	
   for genre1, title2 in string.gmatch(slist, '<option value="(.-)">(.-)</option>') do
  
      genre = string.gsub(genre1, '^(.-)', args.id) .. '/'
	genre = string.gsub(genre, '/0/', '/')
	
    
   table.insert(t, {title = 'АНИМЕ:' .. tolazy(title1) .. ' ' .. title2, mrl = '#stream/q=bestv&id=' .. genre,image = '#self/film.png'})
		end	
		end
   
   
   
   elseif args.q == 'bestv' then

local page = tonumber(args.page or 1)
		
			

        local x = conn:load(HOME .. args.id .. 'page/' .. tostring(page) .. '/')
        
		for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-data%-url="(http.-)".-<img src="(.-)".-class="b%-content__inline_item%-link".-href=.->(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
	--	  image = string.gsub(image, '^/', HOME_SLASH)
	
     t['view'] = 'grid_poster'
	
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=bestv&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


     elseif args.q == 'filter' then

   local page = tonumber(args.page or 1)

     local genre = args.genre
		local url = HOME .. genre
	--	if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/' .. args.id
	--	end
   
       local x = conn:load(url)


table.insert(t, {title = 'последние', mrl = '#stream/q=filter&genre=' .. args.genre .. '&id=' .. '?filter=last', image = '#self/list.png'})
        
        
        table.insert(t, {title = 'популярные', mrl = '#stream/q=filter&genre=' .. args.genre .. '&id=' .. '?filter=popular', image = '#self/list.png'})
        
        
        table.insert(t, {title = 'сейчас смотрят', mrl = '#stream/q=filter&genre=' .. args.genre .. '&id=' .. '?filter=watching', image = '#self/list.png'})

        --local x = conn:load(HOME .. '/page/' .. tostring(page) .. '/' .. args.id)

for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-data%-url="(http.-)".-<img src="(.-)".-class="b%-content__inline_item%-link".-href=.->(.-)<') do

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		local url = '#folder/page=' .. tostring(page + 1) .. '&q=filter&genre=' .. args.genre .. '&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})



	-- #stream/q=search&keyword=4400
	elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
			
			local url = HOME .. '/search/?do=search&subaction=search&q=' .. urlencode(args.keyword)
			local x = conn:load(url)
			--local x = string.match(x, '<div class="b%-content__inline_items">(.+)')
		--	print(x)
			
			for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
				table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
			end
	--		end
			
	
	-- #self/q=content&id=http://hdrezka.co/series/action/43391-tysyacha-klykov-2021.html
	-- #self/q=content&id=http://hdrezka.co/films/documentary/42634-bondarchuk-battle-2021.html
	-- #self/q=content&id=http://hdrezka.co/series/detective/43638-chto-znaet-marianna-2021.html
	-- #self/q=content&id=http://hdrezka.co/series/fiction/43239-moguchie-reyndzhery-dikiy-mir-2002.html

     elseif args.q == 'podbor' then
     
     local x = conn:load(args.id)
      
      t['view'] = 'simple'
     
    for genre, title in string.gmatch(x, '<a href="http.-(/collections/.-)">(.-)</a>') do 
 
table.insert(t, {title = title, mrl = '#stream/genre=' .. genre, image = '#self/list.png'})
 
 end
 
   elseif args.q == 'actor' then
     
     local x = conn:load(args.id)
     
    for image, genre, title in string.gmatch(x, '<span class="person%-name%-item".-data%-photo="(http.-)".-<a href=".-http.-(/person/.-)".-<span.->(.-)</span>') do
   --  t['view'] = 'simple'
      table.insert(t, {title = title, mrl = '#stream/q=actors&id=' .. genre, image = image})
 
 end
 
 
 
      elseif args.q == 'actors' then
       
       local x = conn:load(HOME .. args.id)

      for  image, genre, title, total in string.gmatch(x, '<div class="b%-content__inline_item.-<img src="(.-)".-class="b%-content__inline_item%-link".-<a href="(.-)">(.-)</a>.-class="misc">(.-)</div>') do
  
     table.insert(t, {title = title .. ' '.. total, mrl = '#stream/q=content&id=' .. genre, image = image})
     end
	
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="b%-post__description_text">(.-)</div>')
     --   t['poster'] = args.p
		t['poster'] = parse_match(x,'<img itemprop="image" src="(.-)"')
		if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(Дата выхода</h2>:</td>.-)</td>','(Жанр</h2>:</td>.-)</td>', '(Страна</h2>:</td>.-)</td>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
  
  
  
  
--<meta property="og:video" content="http://kinopub.me/films/drama/77735-razbitye-serdca-2024.html"
  
  --https://lampa.persh1n.ru/lite/rezka?rjson=False&title=&original_title=&clarification=0&year=&href=https://rezka.ag/series/drama/28673-prizraki-doma-na-holme-2018.html
  
  
  
  for id in string.gmatch(x, '<meta property="og:video" content="(http.-)"') do 
   

   
   table.insert(t, {title = 'Плеер1', mrl = '#stream/q=smotr&id=' .. id, image = image})
   
--  table.insert(t, {title = 'Плеер1', mrl = '#stream/q=smotr1&id=' .. id, image = image})
  
table.insert(t, {title = 'Плеер2', mrl = '#stream/q=smotr2&id=' .. id, image = image})
  
  --    end
end



 for id in string.gmatch(x, '<meta property="og:video" content="(http.-)"') do 
   
   table.insert(t, {title = 'В подборках', mrl = '#stream/q=podbor&id=' .. id, image = image})
         end
         
   for id in string.gmatch(x, '<meta property="og:video" content="(http.-)"') do 
   
   table.insert(t, {title = 'В ролях', mrl = '#stream/q=actor&id=' .. id, image = image})
         end
 
 

 
 
   for id1, id2 in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%)') do
    id1 = urlencode(id1)
     
      id1 = string.gsub(id1, '+', '%%20')
     url = string.gsub(id1, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. id1

     local x = conn:load(url)

  --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
   
    for id3 in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do

table.insert(t, {title = 'Источники', mrl = '#stream/q=video&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
end
end
 
   
   elseif args.q == 'smotr1' then
   
 
 local x = conn:load(args.id)


          for id, title in string.gmatch(x,'data%-translator_id.-href="(.-)">(.-)</a>') do
     t['view'] = 'simple'
  
  

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title =tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
         
         
for title1, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
        
end
 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end


     
  
  


   

         
    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    
elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end
    
    
    
       
  --   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
    

    
    
  
  
    
   
   
        elseif args.q == 'smotr' then
    
    
      
      local x = conn:load('https://lampa.persh1n.ru/lite/rezka?rjson=False&title=&original_title=&clarification=0&year=&href=' .. urlencode(args.id))
  
  
  
  
local slist = string.match(x, '"quality"(.-)}')
      
     if slist then
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"http.-(/proxy.-m3u8)"') do
  
      url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
     end
  
  
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
     --  t['view'] = 'simple'
   
      local x = conn:load(url2)

local slist = string.match(x, '"quality"(.-)}')
      if slist then
      
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"http.-(/proxy.-m3u8)"') do
  
      url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
  
  url3 = string.gsub(url3, '\\u0026', '&')
     url3 = string.gsub(url3, '\\u002B', '+')


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ') ' .. tolazy(total), mrl = url3})

     end  
     end
     
end


   local x = conn:load('https://lampa.persh1n.ru/lite/rezka?rjson=False&title=&original_title=&clarification=0&year=&href=' .. urlencode(args.id))

   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      



      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rez' then

   local x = conn:load('https://lampa.persh1n.ru/lite/rezka/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end











elseif args.q == 'smotr2' then
    
    
   
   local x = conn:load('https://evkh.lol/lite/rhsprem?rjson=False&title=&original_title=&clarification=0&year=&href=' .. urlencode(args.id))
   
   
   
for  url, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
   
   url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')
     --  t['view'] = 'simple'
   
      local x = conn:load(url)
      
  
  local slist = string.match(x, '"quality"(.-)vast')
      
     if slist then
   slist = string.gsub(slist, ',"', '')
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"(http.-mp4)') do
  
     -- url3 = string.gsub(url3, '^(.-)', 'https://evkh.lol/lite/rhsprem')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')' .. total, mrl = url3})

     end  
     end
  end
  
  
  
  
  
  
      
  
 --table.insert(t, {title = 'https://evkh.lol/lite/rhsprem?rjson=False&title=&original_title=&clarification=0&year=&href=' .. urlencode(args.id), mrl = 'https://evkh.lol/lite/rhsprem?rjson=False&title=&original_title=&clarification=0&year=&href=' .. urlencode(args.id)})
  
  
--https://api.cyxym.net/kino/v1?player_link&kinopoisk_id=386
  
  
local slist = string.match(x, '"quality"(.-)translate')
      
     if slist then
   slist = string.gsub(slist, ',"', '')
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"(http.-mp4)') do
  
     -- url3 = string.gsub(url3, '^(.-)', 'https://evkh.lol/lite/rhsprem')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
     end
  
  
  
local slist = string.match(x, '"quality"(.-)translate')
      
     if slist then
   slist = string.gsub(slist, ',"', '')
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"(http.-m3u8)') do
  
     -- url3 = string.gsub(url3, '^(.-)', 'https://evkh.lol/lite/rhsprem')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
     end
  
  
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
     --  t['view'] = 'simple'
   
      local x = conn:load(url2)

local slist = string.match(x, '"quality"(.-)}')
      
      if slist then
   slist = string.gsub(slist, ',"', '')
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"(http.-m3u8)') do
  
     -- url3 = string.gsub(url3, '^(.-)', 'https://evkh.lol/lite/rhsprem')
  
  url3 = string.gsub(url3, '\\u0026', '&')
     url3 = string.gsub(url3, '\\u002B', '+')


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ') ' .. tolazy(total), mrl = url3})

     end  
     end
     end



   local x = conn:load('https://evkh.lol/lite/rhsprem?rjson=False&title=&original_title=&clarification=0&year=&href=' .. urlencode(args.id))

   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez1&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      

--stream":"https://evkh.lol/lite/rhsprem/movie.m3u8?title=&original_title=&id=80082&t=238&s=1&e=1&play=true

      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'
--table.insert(t, {title = url2, mrl = url2})

   table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rez1' then

   local x = conn:load('https://evkh.lol/lite/rhsprem/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end






    elseif args.q == 'video' then

       t['view'] = 'simple'


    table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3, image = image})
        
    table.insert(t, {title = 'Alloha', mrl = '#stream/q=alloha&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=vdbmovies&id3=' .. args.id3})
  
table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. args.id3})
 
 table.insert(t, {title = 'Videodb', mrl = '#stream/q=videodb&id3=' .. args.id3})
  
table.insert(t, {title = 'Videocdn', mrl = '#stream/q=videocdn&id3=' .. args.id3})
  
 table.insert(t, {title = 'Lumex', mrl = '#stream/q=lumex&id3=' .. args.id3})
  
   table.insert(t, {title = 'Filmix', mrl = '#stream/q=filmix&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
table.insert(t, {title = 'Filmix2', mrl = '#stream/q=filmix2&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Kinopub', mrl = '#stream/q=kinopub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Rezka', mrl = '#stream/q=rezka&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
  
   
table.insert(t, {title = 'Getstv', mrl = '#stream/q=getstv&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
table.insert(t, {title = 'Kinotochka', mrl = '#stream/q=kinotochka&id3=' .. args.id3})
  
  
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=' .. urlencode(args.id1) .. '-' .. args.id2 .. '&box_mac=acace24b8434')


  --  local slist = string.match(x, 'Мультфильмы.-</playlist_url>(.-)</playlist_url>')
    
    
   -- if slist then
  --  for url in string.gmatch(slist,'<channel>.-<title><!%[CDATA.-<playlist_url><!%[CDATA%[http.-&stream=(.-)]]') do
 
   --  url = base64_decode(url)
  
  
  -- table.insert(t, {title = 'Hdrezka', mrl = '#stream/q=hdrezka&id=' .. url})
  -- end
 --  end
   table.insert(t, {title = 'Kinobase', mrl = '#stream/q=kinobase&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
   table.insert(t, {title = 'Vkmovie', mrl = '#stream/q=vkmovie&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
table.insert(t, {title = 'Remux', mrl = '#stream/q=remux&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
 
   table.insert(t, {title = 'Jac', mrl = '#stream/q=jac&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Pidtor', mrl = '#stream/q=pidtor&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   table.insert(t, {title = 'Collaps', mrl = '#stream/q=collaps&id3=' .. args.id3})
   
table.insert(t, {title = 'Vibix', mrl = '#stream/q=vibix&id3=' .. args.id3})
   
table.insert(t, {title = 'Veoveo', mrl = '#stream/q=veoveo&id3=' .. args.id3})







elseif args.q == 'getstv' then
    
   
--https://evkh.lol/lite/getstv?kinopoisk_id=386&title=Чужой&year=1979
    
      local x = conn:load('http://z01.online/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
   --   url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

     local x = conn:load(url1)
   
 

 
     local slist = string.match(x, 'quality(.-)}')
      
if slist then

   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

    total1 = string.gsub(total1, ',"', '') 
total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

      end 
    end

    end

    
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-"stream".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end


   elseif args.q == 'videocdn' then
    
--https://lamp-movie.ru
--http://lam.maxvol.pro
    
   local x = conn:load('https://lamp-movie.ru/lite/lumex?kinopoisk_id=' .. args.id3) 
   
   --.. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3, mrl = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
      url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

  --   local x = conn:load(url1)
   
 

 
  --   local slist = string.match(x, 'quality(.-)}')
      
--if slist then

--   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

 --   total1 = string.gsub(total1, ',"', '') 
--total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url1})

      end 
    end

    end
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end



   

elseif args.q == 'kinotochka' then


local x = conn:load('https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3)



for url in string.gmatch(x, '"embed":"(http.-)"') do

url = string.gsub(url, '\\', '')

--table.insert(t, {title = url, mrl = url})


    local x = conn:load(url)

t['view'] = 'simple'

local slist = string.match(x, 'file:(.-)"poster"')

if slist then


--file:"https://svd13.kvb.cool/video_mp4/films/1979/Alien/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVlSH97aQZyUg::/Alien1979_480.mp4


--Playerjs({id:"playerjshd", file:"https://s15.kvb.cool/video_mp4/films/2025/Xeno/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVlSH97awNyUQ::/Xeno2025.mp4,", "poster

for url1, url2, url3, url4, url5 in string.gmatch(slist, '(http.-_)(.-_)(.-/)(.-)(.mp4)') do


table.insert(t, {title = url4, mrl = url1 .. url2 .. url3 .. url4 .. url5})

     end 
    end
end

    local x = conn:load('https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3)

--table.insert(t, {title = 'https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3, mrl = 'https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3})


    for title, url in string.gmatch(x, '"url".-http.--.--.--(.-sezon).-"embed":"(http.-)"') do

    url = string.gsub(url, '\\', '')

      local x = conn:load(url)

--table.insert(t, {title = title .. url, mrl = url})



for url1 in string.gmatch(x, 'file.-(http.-txt)') do

local x = conn:load(url1)



for total, total1, url2 in string.gmatch(x, '"comment":"(.-)<br>(.-)".-file.-(http.-.mp4)"') do

url2 = string.gsub(url2, '_%[480,720]', '_720')



table.insert(t, {title = title .. total .. ' ' .. total1, mrl = url2})


     end 
    end
end





    elseif args.q == 'zetflix' then
    
    
      local x = conn:load('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. args.id3)
   
   for  total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-hidxlglk.-class="videos__item%-title">(.-)</div>') do
  
  
     local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-m3u8)"') do
      
      url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')

      
      
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
        for url2, url3, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-zetflix)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = http.getz(url2 .. url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = http.getz(url4)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
      t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end





    
  elseif args.q == 'alloha' then
 
    local x = conn:load('http://peppega.ru/lite/vokino?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do

      url4 = string.gsub(url4, '^(.-)', 'http://peppega.ru') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do

      url5 = string.gsub(url5, '^(.-)', 'http://peppega.ru') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
    

    
    elseif args.q == 'vdbmovies' then
      
      local x = conn:load('https://lam.maxvol.pro/lite/vdbmovies?kinopoisk_id=' .. args.id3)




for total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-/proxy.-mp4.-class="videos__item%-title">(.-)</div>') do
  
  
  
      local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)"') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
            url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     


      t['view'] = 'simple'


   table.insert(t, {title = 'vdbmovies' .. ':'.. tolazy(total1) .. ( total), mrl = url2})

       
    end
    end
    

    
  
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    

      local x = conn:load(url2)

     
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
  
         url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
    
       
    
     local x = conn:load(url3)
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
  
            url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end




    elseif args.q == 'hdvb' then
      
      local x = conn:load('https://lam.akter-black.com/lite/hdvb?kinopoisk_id=' .. args.id3)
      
      for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   
      local x = conn:load(url2 .. url3)

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/360/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '360p ' .. tolazy(total2), mrl = url4})

end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/480/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '480p ' .. tolazy(total2), mrl = url4})
end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/720/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '720p ' .. tolazy(total2), mrl = url4})
end

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '1080p ' .. tolazy(total2), mrl = url4})

      end 
   
      end
      

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=' .. args.id3 .. '&box_mac=acace24b8434')

--url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
   --   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end



    
    elseif args.q == 'videodb' then
    
    local x = conn:load('http://178.20.46.40:12600/lite/videodb?kinopoisk_id=' .. args.id3)
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite/videodb.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite/videodb.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://178.20.46.40:12600')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end




    elseif args.q == 'lumex' then
    
    
   local x = conn:load('https://lamp-movie.ru/lite/lumex?kinopoisk_id=' .. args.id3)
    
    
   --  local x = conn:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
--  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p)lumex :' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '3600/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p)lumex :' .. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p)lumex :' .. tolazy(total), mrl = url3})
       
    end
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
   --    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
    

    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
    
     local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"http.-(http.-mp4)') do
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url5})

       
    end
end
end
end
    

     elseif args.q == 'filmix' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lamp-movie.ru/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
		--.. '&year=' .. args.id2)
   
   
   
for url, total1, image, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-"year":(.-),.-"img":.-(/proxy.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   
url = string.gsub(url, '\\u0026', '&')
   
   image = string.gsub(image, '\\u002B', '+')
   
   image = string.gsub(image, '^(.-)', 'https://lamp-movie.ru')
   
    table.insert(t, {title = total .. ' ' .. total1, mrl = '#stream/q=filmixx&id=' .. url, image = image})
end
    
    elseif args.q == 'filmixx' then

     local x = conn:load(args.id)

  for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"(http.-mp4)') do
 
 total3 = string.gsub(total3, ',"', '')
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
    end
end
 
 
 
   

     
  --   local x = conn:load('http://peppega.ru/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play.-class="videos__item%-title">(.-)</div>') do

   --  url5 = string.gsub(url5, '\\u0026', '&')
   -- url5 = string.gsub(url5, '^(.-)', 'http://peppega.ru')
   
   
     local x = string.match(x, '"quality":{(.-)}')
      for  total4, url5 in string.gmatch(x, '"(.-p)":"(http.-mp4)') do
 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

       
    end
end
end
end




   elseif args.q == 'hdrezka' then

  --http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=чужой:+земля-2025&box_mac=acace24b8434


   
      local x = conn:load(args.id)


          for id, title in string.gmatch(x,'data%-translator_id.-href="(.-)">(.-)</a>') do
     t['view'] = 'simple'
  
  

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title =tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
         
         
for title1, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
        
end
 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end

    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    
elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end





     elseif args.q == 'rezka' then


	
		local x = conn:load('https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
 -- table.insert(t, {title = 'https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
  
       
    local slist = string.match(x, '"quality"(.-)}')
      
     if slist then
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"http.-(/proxy.-m3u8)"') do
  
      url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
     end
  
  
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
       t['view'] = 'simple'
   
      local x = conn:load(url2)

  local slist = string.match(x, '"quality"(.-)}')
      
      
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"http.-(/proxy.-m3u8)"') do
  
      url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')' .. total, mrl = url3})

     end  
 end
     




   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      



      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rez' then

   local x = conn:load('https://lampa.persh1n.ru/lite/rezka/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
  
  
  
--https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=4760854&title=%D0%9A%D0%BE%D1%80%D0%BE%D0%BB%D1%8C+%D0%A2%D0%B0%D0%BB%D1%81%D1%8B&year=2025&serial=1

    elseif args.q == 'kinobase' then

--https://lampa.persh1n.ru/lite/rezka?kinopoisk_id=386&title=чужой&year=1979
   
   
		local x = conn:load('https://lampa.persh1n.ru/lite/kinobase?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&t=&s=1')
     
  
  
  
   --    for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
   --   local x = conn:load(url)

      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
     t['view'] = 'simple'

url2 = string.gsub(url2, '\\u002B', '+')

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2})
    end
     end  
  --  end

--https://lampa.persh1n.ru/lite/kinobase?title=%d0%b1%d1%83%d0%bc%d0%b0%d0%b6%d0%bd%d1%8b%d0%b9+%d0%b4%d0%be%d0%bc&year=2017&s=1
  
     for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
      local x = conn:load(url)
   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
    
       
    
      local x = conn:load(url2)

      
       

      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
    
url3 = string.gsub(url3, '\\u002B', '+')

    
         
    url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
    
       t['view'] = 'simple'



    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3})

    end   
    end
    end
   


elseif args.q == 'jac' then

    

   local x = conn:load('https://lam.akter-black.com/lite/jac?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
   
       t['view'] = 'simple'
    table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     
     


		local x = conn:load('https://lam.akter-black.com/lite/jac?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
  
  
  
  
  
       t['view'] = 'simple'
     table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     



     
     
     
     elseif args.q == 'result' then
      args.id = args.id:lower() 
      
      local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end
   
   
   
    elseif args.q == 'pidtor' then
  
  
  local x = conn:load('https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
  

      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-?tr=).-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
  local x = conn:load('https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
  


--https://lam.akter-black.com/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=






for url2, title in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')

      local x = conn:load(url2)
    

    
      for url3, total  in string.gmatch(x, '"method":"link".-"url":"http.-/lite/pidtor/serial/(.-)?tr=.-class="videos__item%-title videos__season%-title">(.-)</div>') do


--url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')

     url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'
     table.insert(t, {title = title .. ' ' ..  total,mrl = '#stream/q=result&id=' .. url3,image = image})
     end
     
   end
       



elseif args.q == 'collaps' then
  
  
  local x = conn:load('http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=' .. args.id3)



   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



elseif args.q == 'vibix' then
  
  
  local x = conn:load('https://lampa.persh1n.ru/lite/vibix?kinopoisk_id=' .. args.id3)

      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total1) .. total2, mrl = url3})

       
    end

end

--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979



local x = conn:load('https://kinobadi.bid/hd_pars/pleer_on.php?url&kp=' .. args.id3)

--<iframe class="iframe-movie2"  loading="lazy" src="/pleer_4/pleer.php?id=/embed/4539"
		for url  in string.gmatch(x, '<iframe.-src="(/pleer_4.-)"') do
	
		url = string.gsub(url, '^(.-)', 'https://kinobadi.bid')
 
 
	    
		local x = conn:load(url)


        for title in string.gmatch(x, '"title":"(.-)"') do


        local x = string.match(x, '"file":(.-)}')


		
		
         for total, url  in string.gmatch(x, '%[(.-)](http.-mp4)') do
		t['view'] = 'simple'
        table.insert(t, {title = total .. ' ' .. title, mrl = url})
        end
        end
	end






elseif args.q == 'veoveo' then
  
  
  local x = conn:load('https://lamp-movie.ru/lite/veoveo?kinopoisk_id=' .. args.id3)

      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'veoveo :' .. tolazy(total), mrl = url2})

       
    end
     
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)

for total3, url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-media="" s=.-e="(.-)".-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total3) .. ' серия' .. tolazy(total4), mrl = url3})

      end 
      end


elseif args.q == 'kinopub' then
  
  
--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979
   

  local x = conn:load('https://lamp-movie.ru/lite/kinopub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
  

      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'kinopub :' .. tolazy(total), mrl = url2})

       
    end
     
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)

for total3, url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-media="" s=.-e="(.-)".-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'kinopub :' .. tolazy(total2) .. tolazy(total3) .. ' серия' .. tolazy(total4), mrl = url3})

      end 
      end

     
     
     local x = conn:load('http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=' .. urlencode(args.id1) .. '+' .. args.id2 .. '+')
  


     for url2 in string.gmatch(x, '<playlist_name>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn:load(url2)
    


    
    for total, url3, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA(.-)]>.-<playlist_url><!%[CDATA%[(http.-namee=).-(&perewod.-)]]></playlist_url>') do
	
	    local x = conn:load(url3 .. url4)
	   
	   
	     for total1, url5 in string.gmatch(x, '<channel.-<title>.-(1080)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end

for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(720)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end

for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(480)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end


for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(360)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end

     end
	    end




elseif args.q == 'filmix2' then

    

   local x = conn:load('http://peppega.ru/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=filmix')
    

--http://peppega.ru/lite/vokino?kinopoisk_id=386&balancer=filmix

--http://peppega.ru/lite/vokino?kinopoisk_id=4308326&balancer=filmix
     for url4, total3 in string.gmatch(x, '<div class="videos__button.-"method":"link","url":"(http.-)".->(.-])<') do

     local x = conn:load(url4)
    
    for url5, total4 in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"http.-(/proxy.-mp4)".-class="videos__item%-title">(.-)</div>') do 
    
    url5 = string.gsub(url5, '^(.-)', 'http://peppega.ru') 
    
    t['view'] = 'simple'


table.insert(t, {title = total4 .. ' ' .. total3, mrl = url5})


end
end








     for url4, total5  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url4)

      for url5, total6  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url5)


      for url6, total7  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url":".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       url6 = string.gsub(url6, '^(.-)', 'http://peppega.ru') 
    
    t['view'] = 'simple'

    table.insert(t, {title = total5 .. ' '  .. tolazy(total6) .. total7, mrl = url6})

       
    end

end
end

   
   elseif args.q == 'vkmovie' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lam.maxvol.pro/lite/vkmovie?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
     

     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro')
      url4 = string.gsub(url4, '\\u002B', '+')
       t['view'] = 'simple'

   table.insert(t, {title = '(' .. total3 .. ') ' .. tolazy(total2), mrl = url4})
    end
     end  

  
elseif args.q == 'remux' then


--https://lam.akter-black.com/lite/remux?kinopoisk_id=386&title=чужой&year=1979

		local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



      for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')
      
      

    --   url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
   
   
   
for  url3, total1 in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url3 = string.gsub(url3, '\\u0026', '&')
      url3 = string.gsub(url3, '\\u002B', '+')
      
 
 
 local x = conn:load(url3)
 
       for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url4 = string.gsub(url4, '\\u0026', '&')
      url4 = string.gsub(url4, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url4})

     end  
    end
end

local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
   
     for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
 
 
 local x = conn:load(url)
 
       for url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total), mrl = url2})

     end  
    end
    
     


  



        


	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end