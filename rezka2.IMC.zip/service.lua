-- hdrezka plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--local video = require('video')
--local parser = require('parser')

local headersx = {
	['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
	Connection = 'close'
}



	
--local HOME = 'https://rezka.fi'






--local HOME = 'https://kinopub.me'
local HOME = 'https://rezka.fi'

--local HOME = 'http://lamp.ac'

--https://lampa.persh1n.ru/lite/rezka?rjson=False&href=https://rezka.ag/series/fantasy/62784-murashki-2023.html


--https://lampa.persh1n.ru/lite/rezka?title=Рука качающая Колыбель&year=2025

--https://lampa.persh1n.ru/lite/rezka?rjson=False&href=https%3A%2F%2Frezka%2Eag%2Fseries%2Ffiction%2F80082%2Dchuzhoy%2Dzemlya%2D2025%2Dlatest%2Ehtml&id=80082&t=489

--local HOME = 'https://hdrezka1twwpb.org'
--local HOME = 'http://hdrezka0ddqyq.org'
--local HOME = 'http://hdrezka.co'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH
local conn1 = client.new()
conn1['encoding'] = 'UTF-8'

local conn2 = client.new()
conn2['encoding'] = 'windows-1251'


--HOME = 'http://hdrezkagroup.org'
--HOME = 'http://hdrezka.tv'
--HOME = 'http://kinopub.me'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from hdrezka plugin')
	return 1
end

function onUnLoad()
	print('Bye from hdrezka plugin')
end

function onCreate(args)


	


	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
		table.insert(t['menu'], {title = '@string/search', url = url_for{q = 'search'}, icon = get_image('search.png')})
    table.insert(t['menu'], {title = 'Лучшее', url = url_for{q = 'best'}, image = '#self/list.png'})







	
	
--	local title = string.match(x, '(true)')

--	table.insert(t, {title = title, mrl = '#folder/q', image = '#self/list.png'})





--https://rezka.ag/films/best/fantasy/2020/	
	-- #stream/page=2
	-- #stream/genre=/serialy-2020/page/
	-- #stream/genre=/collections/
	-- #stream/genre=/collections/filmy-pro-rozhdestvo-i-novyy-god/
	-- #stream/url=/serials/
	-- #stream/url=/serials/tureckie_serialy/
	-- #stream/url=/serials/brazilskie-serialy/
	-- #stream/url=/serials/indijskie_serialy/
	-- #stream/url=/serials/meksikanskie-serialy/
	-- #stream/url=/serials/ispanskie-serialy/
	-- #stream/url=/serials/doramy/
	-- #stream/url=/serials/novye_serialy/
    -- #stream/url=/filmy_online/filmy_2020_online_hd/
    -- #stream/url=/serials/amerikanskie-serialy/
	
	
    if not args.q then

	local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
	
	

	
	
	
	
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

        local x = http.getz(url, headers)
        --x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
        
       
       
    --   t['filter'] = {}
--if args.q ~= 'filter' then
--t['view'] = 'simple'

  table.insert(t, {title = 'последние', mrl = '#stream/q=filter&genre=' .. genre .. '&id=' .. '?filter=last', image = '#self/setting.png'})
        
        
        table.insert(t, {title = 'популярные', mrl = '#stream/q=filter&genre=' .. genre .. '&id=' .. '?filter=popular', image = '#self/setting.png'})
        
        
        table.insert(t, {title = 'сейчас смотрят', mrl = '#stream/q=filter&genre=' .. genre .. '&id=' .. '?filter=watching', image = '#self/setting.png'})
        
--table.insert(t, {title = 'в ожидание', mrl = '#stream/q=filter&genre=' .. genre .. '&id=' .. '?filter=soon', image = '#self/list.png'})
        

       
      --   end
--https://rezka.ag/?filter=watching
--http://lamp.ac/https://rezka.ag/?filter=watching
        
		for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-data%-url="(http.-)".-<img src="(.-)".-class="b%-content__inline_item%-link".-href=.->(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
	--	  image = string.gsub(image, '^/', HOME_SLASH)
	
     t['view'] = 'grid_poster'
	
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end




		
        for url, image, title in string.gmatch(x, '<div class="b%-content__collections_item" data%-url="http.-(/collections.-)".-src="(.-)".-class="title">(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
			--image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
		
		end
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	


table.insert(t, {title = 'Лучшие фильмы', mrl = '#stream/q=bestf', image = '#self/setting.png'})

table.insert(t, {title = 'Лучшие сериалы', mrl = '#stream/q=bests', image = '#self/setting.png'})

table.insert(t, {title = 'Лучшие мультфильмы', mrl = '#stream/q=bestm', image = '#self/setting.png'})


table.insert(t, {title = 'Лучшее аниме', mrl = '#stream/q=besta', image = '#self/setting.png'})




        table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/new/', image = '#self/film.png'})
		table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections/', image = '#self/setting.png'})


--https://rezka.ag/collections/







        local x = http.getz(HOME, headers)
		
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, '<ul class="right">(.-)<a href="/animation/military/')
		for title, genre  in string.gmatch(x, '<a title="(.-)" href="(.-)"') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/film.png'})
			
end
		
		
        local x = http.getz(HOME, headers)
    	local x = string.match(x, '<div class="b%-topnav__sub_inner">(.-)</div>')
		for genre, title in string.gmatch(x, '<.-="(/films/.-)">(.-)</') do
	
	
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre, image = '#self/film.png'})
			
			
		end
        local x = http.getz(HOME, headers)
    	local x = string.match(x, '<a class="b%-topnav__item%-link" href="/series/">(.-)</div>')
		for genre, title in string.gmatch(x, '<.-="(/series/.-)">(.-)</') do
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end
        local x = http.getz(HOME, headers)
    	local x = string.match(x, '<a class="b%-topnav__item%-link" href="/cartoons/">(.-)</div>')
        for genre, title in string.gmatch(x, '<.-="(/cartoons/.-)">(.-)</') do
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end
         local x = http.getz(HOME, headers)
        local x = string.match(x, '<a class="b%-topnav__item%-link" href="/animation/">(.-)</div>')
        for genre, title in string.gmatch(x, '<.-="(/animation/.-)">(.-)</') do
			table.insert(t, {title = 'АНИМЕ : ' .. tolazy(title), mrl = '#stream/genre=' .. genre,image = '#self/film.png'})
		end
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	-- #stream/q=search&keyword=4400
--http://hdrezka.me/search/?do=search&subaction=search&q=%D0%9F%D0%BE&page=2
	
	
--http://hdrezka.co/search/?do=search&subaction=search&q=%D1%80%D0%BE%D0%BA%D0%BA

--1/1http://fxmlparsers.ru/http://kinopub.me//?id=search&search=%D0%BA%D0%B0%D0%BA%20%D0%BF%D1%80%D0%B8%D1%80%D1%83%D1%87%D0%B8%D1%82%D1%8C%20%D0



--https://rezka.ag/films/best/fantasy/2020/	
   elseif args.q == 'best' then


table.insert(t, {title = 'Лучшие фильмы', mrl = '#stream/q=bestf', image = '#self/setting.png'})

table.insert(t, {title = 'Лучшие сериалы', mrl = '#stream/q=bests', image = '#self/setting.png'})

table.insert(t, {title = 'Лучшие мультфильмы', mrl = '#stream/q=bestm', image = '#self/setting.png'})


table.insert(t, {title = 'Лучшее аниме', mrl = '#stream/q=besta', image = '#self/setting.png'})

    elseif args.q == 'bestf' then


local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




     local x = http.getz(HOME, headers)
   
     t['view'] = 'simple'
   
   	local slist = string.match(x, '<div class="b%-topnav__findbest_select">(.-)</div>')
	
		for genre, title in string.gmatch(slist, '<.-="(/films/.-)">(.-)</') do
 	
			table.insert(t, {title = 'ФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/q=bestfg&id=' .. genre,image = '#self/film.png'})
		end	

		

   elseif args.q == 'bestfg' then

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	



     local x = http.getz(HOME .. args.id, headers)
   
       t['view'] = 'simple'
  
     for title1 in string.gmatch(x, '<title>(.-)- смотреть онлайн') do
     local slist = string.match(x, '<select class="select%-year"(.-)</select>')
	
   for genre1, title2 in string.gmatch(slist, '<option value="(.-)">(.-)</option>') do
  
      genre = string.gsub(genre1, '^(.-)', args.id) .. '/'
	genre = string.gsub(genre, '/0/', '/')
	
    
   table.insert(t, {title = 'ФИЛЬМЫ:' .. tolazy(title1) .. ' ' .. title2, mrl = '#stream/q=bestv&id=' .. genre,image = '#self/film.png'})
		end	
		end
   
   
   
   
   
   
elseif args.q == 'bests' then


local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	


     local x = http.getz(HOME, headers)
   
     t['view'] = 'simple'
   
   	local slist = string.match(x, 'Найти лучшие сериалы.-<div class="b%-topnav__findbest_select">(.-)</div>')
	
		for genre, title in string.gmatch(slist, '<option value="(/series/.-)">(.-)</') do
 	
			table.insert(t, {title = 'СЕРИАЛЫ : ' .. tolazy(title), mrl = '#stream/q=bestsg&id=' .. genre,image = '#self/film.png'})
		end	

		

   elseif args.q == 'bestsg' then


local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	


     local x = http.getz(HOME .. args.id, headers)
   
       t['view'] = 'simple'
  
     for title1 in string.gmatch(x, '<title>(.-)- смотреть онлайн') do
     local slist = string.match(x, '<select class="select%-year"(.-)</select>')
	
   for genre1, title2 in string.gmatch(slist, '<option value="(.-)">(.-)</option>') do
  
      genre = string.gsub(genre1, '^(.-)', args.id) .. '/'
	genre = string.gsub(genre, '/0/', '/')
	
    
   table.insert(t, {title = 'СЕРИАЛЫ:' .. tolazy(title1) .. ' ' .. title2, mrl = '#stream/q=bestv&id=' .. genre,image = '#self/film.png'})
		end	
		end
   
   
   
   
elseif args.q == 'bestm' then

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	



     local x = http.getz(HOME, headers)
   
     t['view'] = 'simple'
   
   	local slist = string.match(x, 'Найти лучшие мультфильмы.-<div class="b%-topnav__findbest_select">(.-)</div>')
	
		for genre, title in string.gmatch(slist, '<.-="(/cartoons/.-)">(.-)</') do
 	
			table.insert(t, {title = 'МУЛЬТФИЛЬМЫ : ' .. tolazy(title), mrl = '#stream/q=bestmg&id=' .. genre,image = '#self/film.png'})
		end	

		

   elseif args.q == 'bestmg' then


local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	


     local x = http.getz(HOME .. args.id, headers)
   
       t['view'] = 'simple'
  
     for title1 in string.gmatch(x, '<title>(.-)- смотреть онлайн') do
     local slist = string.match(x, '<select class="select%-year"(.-)</select>')
	
   for genre1, title2 in string.gmatch(slist, '<option value="(.-)">(.-)</option>') do
  
      genre = string.gsub(genre1, '^(.-)', args.id) .. '/'
	genre = string.gsub(genre, '/0/', '/')
	
    
   table.insert(t, {title = 'МУЛЬТФИЛЬМЫ:' .. tolazy(title1) .. ' ' .. title2, mrl = '#stream/q=bestv&id=' .. genre,image = '#self/film.png'})
		end	
		end





elseif args.q == 'besta' then

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	



     local x = http.getz(HOME, headers)
   
     t['view'] = 'simple'
   
   	local slist = string.match(x, 'Найти лучшее аниме.-<div class="b%-topnav__findbest_select">(.-)</div>')
	
		for genre, title in string.gmatch(slist, '<.-="(/animation/.-)">(.-)</') do
 	
			table.insert(t, {title = 'АНИМЕ : ' .. tolazy(title), mrl = '#stream/q=bestag&id=' .. genre,image = '#self/film.png'})
		end	

		

   elseif args.q == 'bestag' then

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	



local x = http.getz(HOME .. args.id, headers)
   
       t['view'] = 'simple'
  
     for title1 in string.gmatch(x, '<title>(.-)- смотреть онлайн') do
     local slist = string.match(x, '<select class="select%-year"(.-)</select>')
	
   for genre1, title2 in string.gmatch(slist, '<option value="(.-)">(.-)</option>') do
  
      genre = string.gsub(genre1, '^(.-)', args.id) .. '/'
	genre = string.gsub(genre, '/0/', '/')
	
    
   table.insert(t, {title = 'АНИМЕ:' .. tolazy(title1) .. ' ' .. title2, mrl = '#stream/q=bestv&id=' .. genre,image = '#self/film.png'})
		end	
		end
   
   
   
   elseif args.q == 'bestv' then


local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	



local page = tonumber(args.page or 1)
		
			

     local x = http.getz(HOME .. args.id .. 'page/' .. tostring(page) .. '/', headers)
        
		for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-data%-url="(http.-)".-<img src="(.-)".-class="b%-content__inline_item%-link".-href=.->(.-)<') do
       --   print(url)
	--	   url = string.gsub(url, '^/', HOME_SLASH)
	--	  image = string.gsub(image, '^/', HOME_SLASH)
	
     t['view'] = 'grid_poster'
	
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=bestv&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


     elseif args.q == 'filter' then


local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

local page = tonumber(args.page or 1)



local genre = args.genre
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/' .. args.id
		end
   
       local x = http.getz(url .. args.id, headers)


   
     

table.insert(t, {title = 'последние', mrl = '#stream/q=filter&genre=' .. args.genre .. '&id=' .. '?filter=last', image = '#self/list.png'})
        
        
        table.insert(t, {title = 'популярные', mrl = '#stream/q=filter&genre=' .. args.genre .. '&id=' .. '?filter=popular', image = '#self/list.png'})
        
        
        table.insert(t, {title = 'сейчас смотрят', mrl = '#stream/q=filter&genre=' .. args.genre .. '&id=' .. '?filter=watching', image = '#self/list.png'})

        --local x = conn:load(HOME .. '/page/' .. tostring(page) .. '/' .. args.id)

for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-data%-url="(http.-)".-<img src="(.-)".-class="b%-content__inline_item%-link".-href=.->(.-)<') do

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		local url = '#folder/page=' .. tostring(page + 1) .. '&q=filter&genre=' .. args.genre .. '&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})



	-- #stream/q=search&keyword=4400
	elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword


local page = tonumber(args.page or 1)

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	


			
			local url = HOME .. '/search/?do=search&subaction=search&q=' .. urlencode(args.keyword) .. '&page=' .. tostring(page)
			local x = http.getz(url, headers)
			--local x = string.match(x, '<div class="b%-content__inline_items">(.+)')
		--	print(x)
			
			for url, image, title in string.gmatch(x, '<div class="b%-content__inline_item".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
				table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
			end
	--		end


local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})

			
	
	-- #self/q=content&id=http://hdrezka.co/series/action/43391-tysyacha-klykov-2021.html
	-- #self/q=content&id=http://hdrezka.co/films/documentary/42634-bondarchuk-battle-2021.html
	-- #self/q=content&id=http://hdrezka.co/series/detective/43638-chto-znaet-marianna-2021.html
	-- #self/q=content&id=http://hdrezka.co/series/fiction/43239-moguchie-reyndzhery-dikiy-mir-2002.html

     elseif args.q == 'podbor' then
   
local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
   
     
     local x = http.getz(args.id, headers)
      
      t['view'] = 'simple'
     
    for genre, title in string.gmatch(x, '<a href="http.-(/collections/.-)">(.-)</a>') do 
 
table.insert(t, {title = title, mrl = '#stream/genre=' .. genre, image = '#self/list.png'})
 
 end
 
   elseif args.q == 'actor' then
  
local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
  
  
     
     local x = http.getz(args.id, headers)
     
    for image, genre, title in string.gmatch(x, '<span class="person%-name%-item".-data%-photo="(http.-)".-<a href=".-http.-(/person/.-)".-<span.->(.-)</span>') do
   --  t['view'] = 'simple'
      table.insert(t, {title = title, mrl = '#stream/q=actors&id=' .. genre, image = image})
 
 end
 
 
 
      elseif args.q == 'actors' then
  
  
local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
       
       local x = http.getz(HOME .. args.id, headers)

      for  image, genre, title, total in string.gmatch(x, '<div class="b%-content__inline_item.-<img src="(.-)".-class="b%-content__inline_item%-link".-<a href="(.-)">(.-)</a>.-class="misc">(.-)</div>') do
  
     table.insert(t, {title = title .. ' '.. total, mrl = '#stream/q=content&id=' .. genre, image = image})
     end
	
	elseif args.q == 'content' then
	
	local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
	
		t['view'] = 'annotation'
		local x = http.getz(args.id, headers)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="b%-post__description_text">(.-)</div>')
     --   t['poster'] = args.p
		t['poster'] = parse_match(x,'<img itemprop="image" src="(.-)"')
		if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(Дата выхода</h2>:</td>.-)</td>','(Жанр</h2>:</td>.-)</td>', '(Страна</h2>:</td>.-)</td>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
  
  
  
  
--<meta property="og:video" content="http://kinopub.me/films/drama/77735-razbitye-serdca-2024.html"
  
  --https://lampa.persh1n.ru/lite/rezka?rjson=False&title=&original_title=&clarification=0&year=&href=https://rezka.ag/series/drama/28673-prizraki-doma-na-holme-2018.html
  
  for id in string.gmatch(x, '<meta property="og:video" content="http.-//.-(/.-)"') do 
  
  table.insert(t, {title = 'Смотреть', mrl = '#stream/q=smotr2&id=' .. id, image = image})
  end
  
  
  for id in string.gmatch(x, '<meta property="og:video" content="https://.-/(.-)"') do 
   
   table.insert(t, {title = 'Плеер', mrl = '#stream/q=smotr&id=' .. id, image = image})
   
   end
   
   for id in string.gmatch(x, '<meta property="og:video" content="http.-//.-(/.-)"') do 
  table.insert(t, {title = 'Плеер1', mrl = '#stream/q=smotr3&id=' .. id, image = image})
  
end



 for id in string.gmatch(x, '<meta property="og:video" content="(http.-)"') do 
   
   table.insert(t, {title = 'В подборках', mrl = '#stream/q=podbor&id=' .. id, image = image})
         end
         
   for id in string.gmatch(x, '<meta property="og:video" content="(http.-)"') do 
   
   table.insert(t, {title = 'В ролях', mrl = '#stream/q=actor&id=' .. id, image = image})
         end
 
 

 
 
   for id1, id2 in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%)') do
    id1 = urlencode(id1)
     
      id1 = string.gsub(id1, '+', '%%20')
     url = string.gsub(id1, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. id1

     local x = conn:load(url)

  --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
   
    for id3 in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do

table.insert(t, {title = 'Источники', mrl = '#stream/q=video&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
end
end
 
 
 
 
 
 
 
 
   
   elseif args.q == 'smotr1' then
 
 
local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
   
 
 local headerss = {
    ["Host"] = "kinopub.me",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Origin"] = "https://kinopub.me",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://kinopub.me/",
    ["Cookie"] = "PHPSESSID=3k1irc24d5vkhlq0o8tgkreu98; dle_user_taken=1; dle_user_token=9fa1c21c1cce7e5a08ff3af2359d0a95; _ym_uid=177849923871001680; _ym_d=1778499238; _ym_isad=2; _clck=1v54x0m%5E2%5Eg5y%5E0%5E2322; _clsk=1ctr31s%5E1778499240957%5E1%5E0%5Eq.clarity.ms%2Fcollect",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}
	
 
 
 
 
 local x = http.getz('https://kinopub.me' .. args.id, headers)


          for id, title in string.gmatch(x,'data%-translator_id.-href=".-//.-(/.-)">(.-)</a>') do
          

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode('https://kinopub.me' .. id)) .. '&box_mac=acace24b8434')
   
   

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
         
         
for title1, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=.-&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=rezkis&id=' .. args.id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
   end     

 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me' .. args.id) .. '&box_mac=acace24b8434')
    
 
  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end

    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    
  -- end 
    
elseif args.q == 'rezkis' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end

elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end

    
    
  
  
    
   
   
           
        elseif args.q == 'smotr' then
  
  
  
  local x = conn:load('https://gpbx.me/lite/rezka?href=' .. '/' .. args.id .. '&uid=pwmtv0qw')
  
--table.insert(t, {title = 'https://gpbx.me/lite/rezka?href=' .. '/' .. args.id .. '&uid=pwmtv0qw', mrl = 'https://gpbx.me/lite/rezka?href=' .. '/' .. args.id .. '&uid=pwmtv0qw'})
  
  x = string.gsub(x, '\\u0026', '&')
    x = string.gsub(x, '\\u002B', '+')
 
 
 for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)<') do
  

 
  t['view'] = 'simple'
  table.insert(t, {title = total, mrl = url2})
  end
 
 



local x = conn:load('https://gpbx.me/lite/rezka?href=' .. '/' .. args.id .. '&uid=pwmtv0qw')
  
  
--table.insert(t, {title = 'https://gpbx.me/lite/rezka?href=' .. '/' .. args.id .. '&uid=pwmtv0qw', mrl = 'https://gpbx.me/lite/rezka?href=' .. '/' .. args.id .. '&uid=pwmtv0qw'})

for  id3, id4,  total3 in string.gmatch(x, 'videos__button.-method.-link.-url.-http.-&href=(.-html).-&t=(.-)".->(.-)</div>') do


for id5, total  in string.gmatch(x, 'videos__season.-method.-link.-url.-http.-&s=(.-)".-videos__item%-title videos__season%-title.->(.-)<') do
     
      -- url = string.gsub(url, '\\u0026', '&')
--url = string.gsub(url, '\\u002B', '+')
   


t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})

end
end

   
   

     
        elseif args.q == 'rez' then

--https://gpbx.me/lite/rezka?href=' .. '/' .. args.id .. '&uid=pwmtv0qw'


   local x = conn:load('https://gpbx.me/lite/rezka?href=' .. args.id3 .. '&t=' .. args.id4 .. '&s=' .. args.id5 .. '&uid=pwmtv0qw')
  
  
  

  for  id3, id4, total3 in string.gmatch(x, 'videos__button.-method.-link.-url.-http.-&href=(.-html).-&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. args.id5})
end
      


   for url, total  in string.gmatch(x, 'videos__item videos.-method.-call.-stream.-(http.-)".-class="videos__item%-title.->(Серия.-)</div') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
--url = string.gsub(url, '^(.-)', 'http://78.40.195.218:9118')
   
   


t['view'] = 'simple'

    table.insert(t, {title = tolazy(total), mrl = url})

     end











elseif args.q == 'smotr2' then
    
local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
	
	
	
	
	
	
	local x = http.getz('https://rezka.fi' .. args.id, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'simple'

--table.insert(t, {title = id .. ' ' .. id1 .. ' ' .. tolazy(title), mrl = '#stream/q=smotr2m&id=' .. id .. '&id1=' .. id1})

table.insert(t, {title = tolazy(title), mrl = '#stream/q=smotr2m&id=' .. id .. '&id1=' .. id1})

end
end

local headersv = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMWEwMmQ5Ny01ZjBjLTdkNzktYWE0Ny1jN2IyMTlhMjhjYzYiLCJleHAiOjE3OTAwNjMzMDMsImlhdCI6MTc4NzQ3MTMwMywibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NzQ3MTI0MywicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImM0N2FlYTAwZTk4ZmE0NDgxYjYzNDNkOGU5MzA3OGNhMDk4NGExNDNkZTAzMzc2Mjk5MGEzMDllODE3Y2EzM2MifQ.o1PwWN46k-3u0CFAeinX6oB6QvP7vP1ClpMucxGxQJpXMWot3xfK9IgnILeZE1l0lew1YlHbwyLZUQlbL5-3Bw; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}



local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')


local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'simple'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=smotr2s&id=' .. tid .. '&id1=' .. id .. '&id2=' .. id2 .. '&id3=' .. id3})


end
end

local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}
		
		local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headersv, params)			
					

local x = json.decode(x)


url = url_for('get_movie', {file = x['url'], t = t['name']})



--url = base64_decode(url)

url = urldecode(url)

for quali, url1 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url1})

end
end
	end	

   
   
local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
   
   
local x = http.getz('https://rezka.fi' .. args.id, headers)




local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=smotr2s&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})




end
end
end
end
end


 

      elseif args.q == 'smotr2s' then
   
   
   local headerss = {
["Host"] = "hdrzk.org",
 ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
 ["X-Requested-With"] = "XMLHttpRequest",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5"
}
	
	
local headersv = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMWEwMmQ5Ny01ZjBjLTdkNzktYWE0Ny1jN2IyMTlhMjhjYzYiLCJleHAiOjE3OTAwNjMzMDMsImlhdCI6MTc4NzQ3MTMwMywibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NzQ3MTI0MywicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImM0N2FlYTAwZTk4ZmE0NDgxYjYzNDNkOGU5MzA3OGNhMDk4NGExNDNkZTAzMzc2Mjk5MGEzMDllODE3Y2EzM2MifQ.o1PwWN46k-3u0CFAeinX6oB6QvP7vP1ClpMucxGxQJpXMWot3xfK9IgnILeZE1l0lew1YlHbwyLZUQlbL5-3Bw; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}
	
    
    local headersx = {['X-Requested-With'] = 'XMLHttpRequest'}

					local params = http.encode{
		id = args.id1,
		translator_id = args.id,
		season = args.id2,
		episode = args.id3,
		action = 'get_stream'
					}
					
					local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headersv, params)

--table.insert(t, {title = x, mrl = x})

local x = json.decode(x)

--url = url_for(x)

--table.insert(t, {title = url, mrl = url})

	url = url_for('get_stream', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do




t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url3})


end      
   
   
   
    
    	elseif args.q == 'smotr2m' then
    
local headerss = {
["Host"] = "hdrzk.org",
 ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
 ["X-Requested-With"] = "XMLHttpRequest",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5"
}
	
local headersv = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMWEwMmQ5Ny01ZjBjLTdkNzktYWE0Ny1jN2IyMTlhMjhjYzYiLCJleHAiOjE3OTAwNjMzMDMsImlhdCI6MTc4NzQ3MTMwMywibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NzQ3MTI0MywicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImM0N2FlYTAwZTk4ZmE0NDgxYjYzNDNkOGU5MzA3OGNhMDk4NGExNDNkZTAzMzc2Mjk5MGEzMDllODE3Y2EzM2MifQ.o1PwWN46k-3u0CFAeinX6oB6QvP7vP1ClpMucxGxQJpXMWot3xfK9IgnILeZE1l0lew1YlHbwyLZUQlbL5-3Bw; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}


	
					local params = http.encode{
						id = args.id,
						translator_id = args.id1,
						action = 'get_movie'
					}
					
					local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headersv, params)

--table.insert(t, {title = x, mrl = x})




local x = json.decode(x)

--url = url_for('get_movie', {file = x})

	url = url_for('get_movie', {file = x['url'], t = t['name']})



--url = string.gsub(url, '%%3D', '=')

--url = string.gsub(url, '#self/file=%%23h', '')


--url = string.gsub(url, '//_--//JCQjISFAIyFAIyM=', '')
--url = string.gsub(url, '//_--//Xl5eIUAjIyEhIyM=', '')
--url = string.gsub(url, '//_--//IyMjI14hISMjIUBA', '')

--url = string.gsub(url, '//_--//QEBAQEAhIyMhXl5e', '')
--url = string.gsub(url, '//_--//JCQhIUAkJEBeIUAjJCRA', '')

url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do

quali = string.gsub(quali, '<span class="pjs%-prem%-quality">', '')

quali = string.gsub(quali, '<img src="https://st.hdrezka.ac/templates/hdrezka/images/prem%-icon.svg" alt=""></span>', '')

quali = string.gsub(quali, '<img src="https://static.hdrezka.ac/templates/hdrezka/images/prem-icon.svg" alt=""></span>', '')


quali = string.gsub(quali, '<img src="http://static.rezka.cloud/templates/hdrezka/images/prem-icon.svg" alt=""></span>', '')

t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url3})

end





elseif args.q == 'smotr3' then
    
local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
	
	
	
	
	
	
	local x = http.getz('https://rezka.fi' .. args.id, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'simple'



table.insert(t, {title = tolazy(title), mrl = '#stream/q=smotr3m&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. args.id})

end
end




local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')


local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'simple'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=smotr3s&id=' .. tid .. '&id1=' .. id .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. args.id})


end
end

local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id .. '&m=1&ep=id%3D' .. id .. '%26translator_id%3D' .. tid .. '%26action%3Dget_movie')


--url = url_for('get_movie', {file = x['url'], t = t['name']})


x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1})

end
end
--	end	
end

   
   
local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
   
   
local x = http.getz('https://rezka.fi' .. args.id, headers)




local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=smotr3s&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. args.id})




end
end
end
end
end


      elseif args.q == 'smotr3s' then
   
   
   local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id4 .. '&m=1&ep=id%3D' .. args.id1 .. '%26translator_id%3D' .. args.id .. '%26season%3D' .. args.id2 .. '%26episode%3D' .. args.id3 .. '%26action%3Dget_stream')

x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1})

end 
   
   
   
    
    	elseif args.q == 'smotr3m' then
    
local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id2 .. '&m=1&ep=id%3D' .. args.id .. '%26translator_id%3D' .. args.id1 .. '%26action%3Dget_movie')

x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1})

end





    elseif args.q == 'video' then

       t['view'] = 'simple'



  --  table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3, image = image})

     


  
  
  table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 table.insert(t, {title = 'HdvbF', mrl = '#stream/q=hdvbf&id3=' .. args.id3})
  
table.insert(t, {title = 'Zagonka', mrl = '#stream/q=zagonka&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})


table.insert(t, {title = 'Kinobadi', mrl = '#stream/q=kinobadi&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})


table.insert(t, {title = 'TurboDB', mrl = '#stream/q=turbo&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})

--  table.insert(t, {title = 'Hdvb2', mrl = '#stream/q=hdvb2&id3=' .. args.id3})
  
  
 -- table.insert(t, {title = 'Flixcdn-mp4', mrl = '#stream/q=flixcdnm&id3=' .. args.id3, image = image})
  
  table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id3=' .. args.id3, image = image})
  
       table.insert(t, {title = 'Collaps', mrl = '#stream/q=collaps&id3=' .. args.id3})

table.insert(t, {title = 'Collaps2', mrl = '#stream/q=collaps2&id3=' .. args.id3})



 -- table.insert(t, {title = 'Collaps-dash', mrl = '#stream/q=collaps-dash&id3=' .. args.id3})
  
       
       table.insert(t, {title = 'Kino4k', mrl = '#stream/q=kino4k&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
   table.insert(t, {title = 'Filmix', mrl = '#stream/q=filmix&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
--table.insert(t, {title = 'Filmix2', mrl = '#stream/q=filmix2&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
-- table.insert(t, {title = 'Kinofit', mrl = '#stream/q=kinofit&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 
 
 
 --  table.insert(t, {title = 'Lumex', mrl = '#stream/q=lumex&id3=' .. args.id3})
   
   table.insert(t, {title = 'Videocdn', mrl = '#stream/q=videocdn&id3=' .. args.id3})
 
   
   
--   table.insert(t, {title = 'Kinopub', mrl = '#stream/q=kinopub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  table.insert(t, {title = 'Kinoportal', mrl = '#stream/q=filmixred&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3})
       
       
table.insert(t, {title = 'Mirkino', mrl = '#stream/q=mirkino&id1=' .. args.id1 .. '&id2=' .. args.id2, image = image})
       
       
table.insert(t, {title = '24kino', mrl = '#stream/q=24kino&id1=' .. args.id1 .. '&id2=' .. args.id2, image = image})
       
     
  table.insert(t, {title = 'Aladdin', mrl = '#stream/q=spectre&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Paladin', mrl = '#stream/q=phantom&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
       
--    table.insert(t, {title = 'Alloha', mrl = '#stream/q=alloha&id3=' .. args.id3})
 
 -- table.insert(t, {title = 'Mirage', mrl = '#stream/q=mirage&id3=' .. args.id3})

  
  
  table.insert(t, {title = 'Mirage', mrl = '#stream/q=mirage&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
--table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})


  
table.insert(t, {title = 'ZetflixDB', mrl = '#stream/q=zetflixdb&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})

--table.insert(t, {title = 'Turbo', mrl = '#stream/q=videodb1&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 --table.insert(t, {title = 'Videodb', mrl = '#stream/q=videodb&id3=' .. args.id3})



table.insert(t, {title = 'Seasonvar', mrl = '#stream/q=seasonvar&id1=' .. args.id1, image = image})
  
 
  
  
--  table.insert(t, {title = 'Cdnmovies', mrl = '#stream/q=cdnmovies&id3=' .. args.id3})


--  table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=vdbmovies&id3=' .. args.id3})
  

  
  table.insert(t, {title = 'Videx', mrl = '#stream/q=videx&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 table.insert(t, {title = 'Vibix', mrl = '#stream/q=vibix&id3=' .. args.id3})
 
 --  table.insert(t, {title = 'ViBex', mrl = '#stream/q=vibex&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
 table.insert(t, {title = 'Fanserial', mrl = '#stream/q=fanserial&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 
 
  
   table.insert(t, {title = 'Krasview', mrl = '#stream/q=krasview&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
    table.insert(t, {title = 'Awmzone', mrl = '#stream/q=awmzone&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = image})
    
    table.insert(t, {title = 'Anwap', mrl = '#stream/q=anwap&id1=' .. args.id1 .. '&id5=' .. '1' .. '&id6=' .. 'on'})
    
  
table.insert(t, {title = 'Voidboost', mrl = '#stream/q=voidboost&id3=' .. args.id3})
  
      table.insert(t, {title = 'HDRezka', mrl = '#stream/q=hdrezkatest&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
      
   
   table.insert(t, {title = 'Rezka', mrl = '#stream/q=rezka&id1=' .. args.id1 .. '&id2=' .. args.id2})
   


table.insert(t, {title = 'Fxmlrezka', mrl = '#stream/q=fxmlrezka&id1=' .. args.id1 .. '&id2=' .. args.id2}) 


   table.insert(t, {title = 'Kinobase', mrl = '#stream/q=kinobase&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})


table.insert(t, {title = 'Kinoflix', mrl = '#stream/q=kinoflix&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})


--table.insert(t, {title = 'Kinoserials', mrl = '#stream/q=videoseed2&id3=' ..  args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})

 
table.insert(t, {title = 'Videohub', mrl = '#stream/q=videohub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  table.insert(t, {title = 'Kinogo', mrl = '#stream/q=kinogox&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
 
 table.insert(t, {title = 'Videoseed', mrl = '#stream/q=videoseed&id3=' ..  args.id3})
 
 
   table.insert(t, {title = 'Vkmovie', mrl = '#stream/q=vkmovie&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
table.insert(t, {title = 'Remux', mrl = '#stream/q=remux&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  
table.insert(t, {title = 'Jacred', mrl = '#stream/q=jacred&id1=' .. args.id1 .. '&id2=' .. args.id2, image = image})
  
  
   
   
 --  table.insert(t, {title = 'Jac', mrl = '#stream/q=jac&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Pidtor', mrl = '#stream/q=pidtor&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
--   table.insert(t, {title = 'Torrs', mrl = '#stream/q=torrs&id1=' .. args.id1 .. '&id2=' .. args.id2, image = image})
   
   

   
   table.insert(t, {title = 'Kinotochka', mrl = '#stream/q=kinotochka&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   

   
   
   
   table.insert(t, {title = 'Veo', mrl = '#stream/q=veo&id3=' .. args.id3, image = image})
   
   
table.insert(t, {title = 'Veoveo', mrl = '#stream/q=veoveo&id3=' .. args.id3 .. '&id1=' .. args.id1})

--table.insert(t, {title = 'Rapidcdn', mrl = '#stream/q=rapidcdn&id1=' .. args.id1 .. '&id2=' .. args.id2})




table.insert(t, {title = 'Xkino', mrl = '#stream/q=xkino&id1=' .. args.id1})

--https://storage.videoseedcdn.com/movies/bd691b21ee132554ba429035fcd60e94f9ccaae8/04a52eaa9575c08e155647bda7b47423:2026011806/1080.mp4:hls:manifest.m3u8

--https://tv-1-kinoserial.net/api_player.php?kp_id=386&token=fbdcf2438c4f9f0ed76121801807891a

--https://storage.videoseedcdn.com/movies/aec50961c21ef09d0040260875ff6627d9728a49/bfd76f0b07fdcc385574bcc1bbc18767:2026011806/1080.mp4:hls:manifest.m3u8

--https://tv-1-videoseedcdn.com/embed/26728/?token=fbdcf2438c4f9f0ed76121801807891a

--https://videoseed.tv/apiv2.php?item=movie&token=5333b968b6a054766ee984eee92d202d&kp=386

--https://videoseed.tv/apiv2.php?item=movie&token=fbdcf2438c4f9f0ed76121801807891a&kp=386
 
-- https://api.videoseed.tv/embed/32489/?token=fbdcf2438c4f9f0ed76121801807891a
 
 
--https://api.videoseed.tv/apiv2.php?item=movie&token=fbdcf2438c4f9f0ed76121801807891a&kp=386
 
 
 
 
-- https://api.rstprgapipt.com/balancer-api/iframe?kp=1338024&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI
 
 
 
-- https://lamp-movie.ru/proxy/ZHIM6TGAty9DENCUXI0WgbWABkCG8d5eYFt9ugGnaifV6o6r4JSbogF6tULIbPy8ubQ2zoTCK7p91ZFpyLN2Z7YbW7aoURb34AcmP8Rj2V237gA+0RssGh+FWHxl56EabeEQbhVAsos4xLa2TRcCY5fayg05xD6Ujjcn9TIBhmKLnGKR\u002BOq5SdPykrmA/9dQRUwcv6hGPPC4RohGLKfc9+k/BdPpgiYpind0xbQrLLKuyLhGqI3IqW+ZG4ei4LUygJ1bCikGN41iVikFBHYLX/PnD9XLxbU+/CgZXJ9fkgHyKt6qW29Obzzc3Hd4DIhFYCM9Yz5oP4ccX/7nlQ/1qo2gh9oVSUYqevvoK7E6SnU=.m3u8
 
 
 --https://evkh.lol
 
-- https://lam.maxvol.pro/lite/kinogo?kinopoisk_id=386&title=чужой&year=1979
 
--http://lampac.egorpomidor.site
 
 -- http://93.183.95.219:11378/lite/kinogo?href=56119-strazhi-galaktiki-chast-3-2023.html
 
--https://lampa.persh1n.ru/lite/kinogo?href=56119-strazhi-galaktiki-chast-3-2023.html

--https://lampa.persh1n.ru/lite/kinogo?rjson=False&title=%D0%A1%D1%82%D1%80%D0%B0%D0%B6%D0%B8+%D0%93%D0%B0%D0%BB%D0%B0%D0%BA%D1%82%D0%B8%D0%BA%D0%B8+%D0%A7%D0%B0%D1%81%D1%82%D1%8C+3+&serial=1&year=2025


--https://lampa.persh1n.ru/lite/kinogo?rjson=False&title=%D0%A1%D1%82%D1%80%D0%B0%D0%B6%D0%B8+%D0%93%D0%B0%D0%BB%D0%B0%D0%BA%D1%82%D0%B8%D0%BA%D0%B8%2E+%D0%A7%D0%B0%D1%81%D1%82%D1%8C+3&serial=1&original_language=ru&year=2023





    elseif args.q == 'flixcdn' then

 
 
 local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local')


for id, translation in string.gmatch(x,'"id":(.-),"is_serial":false.-"translations":%[(.-)].-"type":"movie"') do

for trans, title in string.gmatch(translation,'{"id":(.-),"title":"(.-)"') do

local player = 'https://tarantino.factorios.live/api/player/files'



local headers = {
    ["Host"] = "tarantino.factorios.live",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  ["Cookie"] = "_ga_ECHML7LBXL=GS2.1.s1778775911$o1$g0$t1778775911$j60$l0$h0; _ga=GA1.1.1864259193.1778775912"
}

local params = '{"id":' .. id.. ',"season_number":null,"translation":' .. trans .. '}'

local x = http.postz(player, headers, params)

local file = string.match(x,'{"file":"(.-)}') 

for qual, url in string.gmatch(file,'%[(.-)](.-m3u8)') do



 t['view'] = 'simple'

table.insert(t, {title = qual .. 'p ' .. title, mrl = url})

   end
end
end
 

  local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local')


--table.insert(t, {title = 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local', mrl = 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local'})
  
  
   for id, seasons, translations in string.gmatch(x,'id":(.-),"is_serial":true.-"seasons_episodes":{(.-)}.-"translations":%[(.-)]') do
  
  seasons = string.gsub(seasons, '%[', '["') 
seasons = string.gsub(seasons, ']', '"]') 
seasons = string.gsub(seasons, ',', '","') 
  
  
  for season, episodes in string.gmatch(seasons,'"(.-)":%[(.-)]') do
  
  for episode in string.gmatch(episodes,'"(.-)"') do
  
  for trans, title in string.gmatch(translations,'"id":(.-),"title":"(.-)"') do
  
   
   season = string.gsub(season, ',""', '') 
   

   t['view'] = 'simple'  
 
  
 table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = '#stream/q=flixcdns&id=' .. id .. '&id1=' .. trans .. '&id2=' .. season .. '&id3=' .. episode})
 
 
 
 end
 end
 end
 end
 
    
    elseif args.q == 'flixcdns' then  
  
  

    local player = 'https://tarantino.factorios.live/api/player/files'



local headers = {
    ["Host"] = "tarantino.factorios.live",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  ["Cookie"] = "_ga_ECHML7LBXL=GS2.1.s1778775911$o1$g0$t1778775911$j60$l0$h0; _ga=GA1.1.1864259193.1778775912"
}

local params = '{"id":' .. args.id .. ',"season_number":' .. args.id2 .. ',"episode_number":' .. args.id3 .. ',"translation":' .. args.id1 .. '}'

local x = http.postz(player, headers, params)

local file = string.match(x,'{"file":"(.-)}') 

for qual, url in string.gmatch(file,'%[(.-)](.-m3u8)') do



 t['view'] = 'simple'

table.insert(t, {title = qual .. 'p', mrl = url})

   end






--  https://player0.flixcdn.space/show/kinopoisk/386?domain=piratka.tv&autoplay=1&extrans=1&translation=


elseif args.q == 'krasview' then



    local x = conn1:load('https://krasview.ru/movie?mode=search&ajax&query=' .. urlencode(args.id1) .. '+' .. args.id2)

--table.insert(t, {title = 'https://krasview.ru/movie?mode=vector-search&ajax&query=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://krasview.ru/movie?mode=search&ajax&query=' .. urlencode(args.id1) .. ',' .. args.id2})


   for url, total in string.gmatch(x, '<li id=.-<a href=.-(http.-)\'.-alt=\'(.-)\'>') do


--table.insert(t, {title = url, mrl = url})

  
  local headers = {
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
  
  
  
      local x = http.getz(url, headers)



    for id in string.gmatch(x, '<ul class=.-video%-gallery.-itemscope itemtype=.-id=\'v%-(.-)\'') do

t['view'] = 'simple'

table.insert(t, {title = total, mrl = '#stream/q=krasviewvideo&id=' .. id})

end
end






--https://sersoap.ru/series/Game_of_Thrones/?page=2

    local x = conn1:load('https://krasview.ru/series?mode=search&ajax&query=' .. urlencode(args.id1))
    --.. ',' .. args.id2)


    for url, total in string.gmatch(x, '<li id=.-<a href=\'(http.-)\'.-alt=\'(.-)\'') do
         t['view'] = 'simple'
 
    table.insert(t, {title = tolazy(total), mrl = '#stream/q=krasviews&id=' .. url})
    end
 
   elseif args.q == 'krasviews' then

local page = tonumber(args.page or 1)

      local x = conn1:load(args.id .. '?page=' .. tostring(page))



   for id, title in string.gmatch(x, '<li itemprop=\'itemListElement\' itemscope itemtype=.-id=\'v%-(.-)\'.-alt=\'(.-)\'') do

t['view'] = 'simple'

table.insert(t, {title = title, mrl = '#stream/q=krasviewvideo&id=' .. id})


end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=krasviews&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})





elseif args.q == 'krasviewvideo' then

local headers = {
    ["Host"] = "zedfilm.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://zedfilm.ru/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
     args.id = string.gsub(args.id, '^(.-)', 'https://zedfilm.ru/') 
 
 --  table.insert(t, {title = args.id, mrl = args.id})
   
     local x = http.getz(args.id, headers)
 
 local slist = string.match(x, 'video_Init.-\'(.-)\'') 
 
 
    slist = base64_decode(slist)
   
  --local url  = string.match(slist, '"url":"(http.-).mp.-"') 
 --  for url in string.gmatch(slist, '"url":"(http.-).mp.-"') do
   
for url in string.gmatch(slist, '"url.-:"(https://media.-).mp.-"') do
    
      url = string.gsub(url, 'media', 'm')
     -- url = string.gsub(url, '^(.-)', '.mp4')
      
      if url then
    print(url2)
    return {view = 'playback', mrl = url .. '.mp4', seekable = 'true', direct = 'true'}
-- end
      
 
end
end






--https://m4.krasview.ru/video/07022833dea865d/eb9e2b471a474eb-1080.mp4

  --http://93.183.95.219:11378




elseif args.q == 'kinogox' then

--https://kinogo2026.com/

--https://kinonix.net

local x = conn:load('https://kinogo2026.com/index.php?story=' .. urlencode(args.id1 .. ' ' .. args.id2) .. '&do=search&subaction=search')


local search = string.match(x, '<h2.-href.-(http.-html)') 

if search then



 local x = conn:load(search)
 


local headers2 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Sec-Fetch-Storage-Access"] = "none",
    ["Connection"] = "keep-alive",
    ["Referer"] = search,
    ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb; device_fp=dc5352f6d0c470ed5624bc225b261ecc",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}

 
 
 local url2 = string.match(x,'(//cinemar.cc/embed/.-)"')
 

 
if url2 then
 
--  https://proxy4.rte.net.ru/
  
 local embed = 'https:' .. url2
 

 local x = http.getz(embed, headers2)


local player = string.match(x,'Cinemar%((.-)%)+')

if player then


 local url3 = string.match(player,'"file":"#.-(W3sia.-)%"+')

 
 url3 = urldecode(url3)

 
url3 = string.gsub(url3,'#pZCf1azIuc3J0LF','')

 url3 = string.gsub(url3,'#0JnMVRf1ae84I6IjV','')
 
 url3 = string.gsub(url3,'#NjU0f1aeWVlVLQVZW','')

 
url3 = base64_decode(url3)
 


 url3 = string.gsub(url3, '\\u0410', 'А')
      url3 = string.gsub(url3, '\\u0430', 'а')
       
       url3 = string.gsub(url3, '\\u0411', 'Б')
       url3 = string.gsub(url3, '\\u0431', 'б')  
       url3 = string.gsub(url3, '\\u0412', 'В')
      url3 = string.gsub(url3, '\\u0432', 'в')
       url3 = string.gsub(url3, '\\u0413', 'Г')
       url3 = string.gsub(url3, '\\u0433', 'г')  
      url3 = string.gsub(url3, '\\u0414', 'Д')
      url3 = string.gsub(url3, '\\u0434', 'д')
       url3 = string.gsub(url3, '\\u0415', 'Е')
       url3 = string.gsub(url3, '\\u0435', 'е')  
      url3 = string.gsub(url3, '\\u0401', 'Ё')
      url3 = string.gsub(url3, '\\u0451', 'ё')
       url3 = string.gsub(url3, '\\u0416', 'Ж')
       url3 = string.gsub(url3, '\\u0436', 'ж')  
       url3 = string.gsub(url3, '\\u0417', 'З')
      url3 = string.gsub(url3, '\\u0437', 'з')
       url3 = string.gsub(url3, '\\u0418', 'И')
       url3 = string.gsub(url3, '\\u0438', 'и')  
       url3 = string.gsub(url3, '\\u0419', 'Й')
      url3 = string.gsub(url3, '\\u0439', 'й')
       url3 = string.gsub(url3, '\\u041a', 'К')
       url3 = string.gsub(url3, '\\u043a', 'к')  
       url3 = string.gsub(url3, '\\u041b', 'Л')
       url3 = string.gsub(url3, '\\u043b', 'л')
       url3 = string.gsub(url3, '\\u041c', 'М')
       url3 = string.gsub(url3, '\\u043c', 'м')
       url3 = string.gsub(url3, '\\u041d', 'Н')
       url3 = string.gsub(url3, '\\u043d', 'н')
       url3 = string.gsub(url3, '\\u041e', 'О')
       url3 = string.gsub(url3, '\\u043e', 'о')
       url3 = string.gsub(url3, '\\u041f', 'П')
       url3 = string.gsub(url3, '\\u043f', 'п')
       url3 = string.gsub(url3, '\\u0420', 'Р')
       url3 = string.gsub(url3, '\\u0440', 'р')
       url3 = string.gsub(url3, '\\u0421', 'С')
       url3 = string.gsub(url3, '\\u0441', 'с')
       url3 = string.gsub(url3, '\\u0422', 'Т')
       url3 = string.gsub(url3, '\\u0442', 'т')
       url3 = string.gsub(url3, '\\u0423', 'У')
       url3 = string.gsub(url3, '\\u0443', 'у')
       url3 = string.gsub(url3, '\\u0424', 'Ф')
        url3 = string.gsub(url3, '\\u0444', 'ф')
        url3 = string.gsub(url3, '\\u0425', 'Х')
        url3 = string.gsub(url3, '\\u0445', 'х')
        url3 = string.gsub(url3, '\\u0426', 'Ц')
        url3 = string.gsub(url3, '\\u0446', 'ц')
        url3 = string.gsub(url3, '\\u0427', 'Ч')
        url3 = string.gsub(url3, '\\u0447', 'ч')
        url3 = string.gsub(url3, '\\u0428', 'Ш')
        url3 = string.gsub(url3, '\\u0448', 'ш')
        url3 = string.gsub(url3, '\\u0429', 'Щ')
        url3 = string.gsub(url3, '\\u0449', 'щ')
        url3 = string.gsub(url3, '\\u042a', 'Ъ')
        url3 = string.gsub(url3, '\\u044a', 'ъ')
        url3 = string.gsub(url3, '\\u042b', 'Ы')
        url3 = string.gsub(url3, '\\u044b', 'ы')
        url3 = string.gsub(url3, '\\u042c', 'Ь')
        url3 = string.gsub(url3, '\\u044c', 'ь')
        url3 = string.gsub(url3, '\\u042d', 'Э')
        url3 = string.gsub(url3, '\\u044d', 'э')
        url3 = string.gsub(url3, '\\u042e', 'Ю')
        url3 = string.gsub(url3, '\\u044e', 'ю')
        url3 = string.gsub(url3, '\\u042f', 'Я')
        url3 = string.gsub(url3, '\\u044f', 'я')
        url3 = string.gsub(url3, '\\u00ab', '<<')
        url3 = string.gsub(url3, '\\u00bb', '>>')
        url3 = string.gsub(url3, '\\u2014', '-')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/ua.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\"%[', '')



url3 = string.gsub(url3, '\\u00a0', ' ')
 
 url3 = string.gsub(url3,'\\','')

url3 = string.gsub(url3, '<img src="/flags/us.png" alt=""%[', '')

 url3 = string.gsub(url3,'"title":"Сезон','')
url3 = string.gsub(url3,'"title":"Серия','')
 

for title, data in string.gmatch(url3, '{"id":".-".-"title":"(.-)","title2":.-"data":(".-")') do

if data then

local list = 'https://cinemar.cc/api/playlist/load'


local headers3 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/json",
  ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb",
    ["Content-Length"] = "266",
    ["Origin"] = "https://cinemar.cc",
    ["Connection"] = "keep-alive",
    ["Referer"] = embed,
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local data = data

local x = http.postz(list, headers3, data)

if x then


 t['view'] = 'simple'
 
 
 local file = string.match(x,'"file":"(.-)/hls.m3u8"')

 if file then
 
 local m3u = conn:load(file .. '/hls.m3u8')

if m3u then

m3u = string.gsub(m3u, './', ',./') 

m3u = string.gsub(m3u, 'stream', '/stream') 
 
for qual, file2 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'simple'

table.insert(t, {title = '(' .. tolazy(qual) .. 'p) ' .. tolazy(title), mrl = file .. file2})
 
end
 end
 end
 end
 end
 

for title, title1, data1 in string.gmatch(url3,'{"id":".-".-"title":"(.-)","title2":"(.-ерия)".-"data":"(.-)"') do
 
 if title1 then
 

table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=kinogoxs&id=' .. data1 .. '&id1=' .. embed})


end
end  
end
end
end
end








 
if not search then

local x =  conn:load('https://hdrezka.inc/index.php?story=' .. urlencode(args.id1 .. ' ' .. args.id2) .. '&do=search&subaction=search')


--if x then

local search1 = string.match(x,'<h2.-href.-(http.-html)') 
 
 if search1 then
 
 local x = conn:load(search1)
 

 
 local headers2 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Sec-Fetch-Storage-Access"] = "none",
    ["Connection"] = "keep-alive",
    ["Referer"] = search1,
    ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb; device_fp=dc5352f6d0c470ed5624bc225b261ecc",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}

 
 
 local url2 = string.match(x,'(//cinemar.cc/embed/.-)"')
 

 
if url2 then
 
--  https://proxy4.rte.net.ru/
  
 local embed = 'https:' .. url2
 

 local x = http.getz(embed, headers2)


local player = string.match(x,'Cinemar%((.-)%)+')

if player then


 local url3 = string.match(player,'"file":"#.-(W3sia.-)%"+')

 
 url3 = urldecode(url3)

 
url3 = string.gsub(url3,'#pZCf1azIuc3J0LF','')

 url3 = string.gsub(url3,'#0JnMVRf1ae84I6IjV','')
 
 url3 = string.gsub(url3,'#NjU0f1aeWVlVLQVZW','')

 
url3 = base64_decode(url3)
 


 url3 = string.gsub(url3, '\\u0410', 'А')
      url3 = string.gsub(url3, '\\u0430', 'а')
       
       url3 = string.gsub(url3, '\\u0411', 'Б')
       url3 = string.gsub(url3, '\\u0431', 'б')  
       url3 = string.gsub(url3, '\\u0412', 'В')
      url3 = string.gsub(url3, '\\u0432', 'в')
       url3 = string.gsub(url3, '\\u0413', 'Г')
       url3 = string.gsub(url3, '\\u0433', 'г')  
      url3 = string.gsub(url3, '\\u0414', 'Д')
      url3 = string.gsub(url3, '\\u0434', 'д')
       url3 = string.gsub(url3, '\\u0415', 'Е')
       url3 = string.gsub(url3, '\\u0435', 'е')  
      url3 = string.gsub(url3, '\\u0401', 'Ё')
      url3 = string.gsub(url3, '\\u0451', 'ё')
       url3 = string.gsub(url3, '\\u0416', 'Ж')
       url3 = string.gsub(url3, '\\u0436', 'ж')  
       url3 = string.gsub(url3, '\\u0417', 'З')
      url3 = string.gsub(url3, '\\u0437', 'з')
       url3 = string.gsub(url3, '\\u0418', 'И')
       url3 = string.gsub(url3, '\\u0438', 'и')  
       url3 = string.gsub(url3, '\\u0419', 'Й')
      url3 = string.gsub(url3, '\\u0439', 'й')
       url3 = string.gsub(url3, '\\u041a', 'К')
       url3 = string.gsub(url3, '\\u043a', 'к')  
       url3 = string.gsub(url3, '\\u041b', 'Л')
       url3 = string.gsub(url3, '\\u043b', 'л')
       url3 = string.gsub(url3, '\\u041c', 'М')
       url3 = string.gsub(url3, '\\u043c', 'м')
       url3 = string.gsub(url3, '\\u041d', 'Н')
       url3 = string.gsub(url3, '\\u043d', 'н')
       url3 = string.gsub(url3, '\\u041e', 'О')
       url3 = string.gsub(url3, '\\u043e', 'о')
       url3 = string.gsub(url3, '\\u041f', 'П')
       url3 = string.gsub(url3, '\\u043f', 'п')
       url3 = string.gsub(url3, '\\u0420', 'Р')
       url3 = string.gsub(url3, '\\u0440', 'р')
       url3 = string.gsub(url3, '\\u0421', 'С')
       url3 = string.gsub(url3, '\\u0441', 'с')
       url3 = string.gsub(url3, '\\u0422', 'Т')
       url3 = string.gsub(url3, '\\u0442', 'т')
       url3 = string.gsub(url3, '\\u0423', 'У')
       url3 = string.gsub(url3, '\\u0443', 'у')
       url3 = string.gsub(url3, '\\u0424', 'Ф')
        url3 = string.gsub(url3, '\\u0444', 'ф')
        url3 = string.gsub(url3, '\\u0425', 'Х')
        url3 = string.gsub(url3, '\\u0445', 'х')
        url3 = string.gsub(url3, '\\u0426', 'Ц')
        url3 = string.gsub(url3, '\\u0446', 'ц')
        url3 = string.gsub(url3, '\\u0427', 'Ч')
        url3 = string.gsub(url3, '\\u0447', 'ч')
        url3 = string.gsub(url3, '\\u0428', 'Ш')
        url3 = string.gsub(url3, '\\u0448', 'ш')
        url3 = string.gsub(url3, '\\u0429', 'Щ')
        url3 = string.gsub(url3, '\\u0449', 'щ')
        url3 = string.gsub(url3, '\\u042a', 'Ъ')
        url3 = string.gsub(url3, '\\u044a', 'ъ')
        url3 = string.gsub(url3, '\\u042b', 'Ы')
        url3 = string.gsub(url3, '\\u044b', 'ы')
        url3 = string.gsub(url3, '\\u042c', 'Ь')
        url3 = string.gsub(url3, '\\u044c', 'ь')
        url3 = string.gsub(url3, '\\u042d', 'Э')
        url3 = string.gsub(url3, '\\u044d', 'э')
        url3 = string.gsub(url3, '\\u042e', 'Ю')
        url3 = string.gsub(url3, '\\u044e', 'ю')
        url3 = string.gsub(url3, '\\u042f', 'Я')
        url3 = string.gsub(url3, '\\u044f', 'я')
        url3 = string.gsub(url3, '\\u00ab', '<<')
        url3 = string.gsub(url3, '\\u00bb', '>>')
        url3 = string.gsub(url3, '\\u2014', '-')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/ua.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\"%[', '')

url3 = string.gsub(url3, '\\u00a0', ' ')
 
 url3 = string.gsub(url3,'\\','')
 
 url3 = string.gsub(url3,'"title":"Сезон','')
url3 = string.gsub(url3,'"title":"Серия','')
 

for title, data in string.gmatch(url3, '{"id":".-".-"title":"(.-)","title2":.-"data":(".-")') do

if data then

local list = 'https://cinemar.cc/api/playlist/load'


local headers3 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/json",
  ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb",
    ["Content-Length"] = "266",
    ["Origin"] = "https://cinemar.cc",
    ["Connection"] = "keep-alive",
    ["Referer"] = embed,
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local data = data

local x = http.postz(list, headers3, data)

if x then


 t['view'] = 'simple'
 
 
 local file = string.match(x,'"file":"(.-)/hls.m3u8"')

 if file then
 
 local m3u = conn:load(file .. '/hls.m3u8')

if m3u then

m3u = string.gsub(m3u, './', ',./') 

m3u = string.gsub(m3u, 'stream', '/stream') 
 
for qual, file2 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'simple'

table.insert(t, {title = '(' .. tolazy(qual) .. 'p) ' .. tolazy(title), mrl = file .. file2})
 
end
 end
 end
 end
end 
 

for title, title1, data1 in string.gmatch(url3,'{"id":".-".-"title":"(.-)","title2":"(.-ерия)".-"data":"(.-)"') do
 
 if title1 then
 

table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=kinogoxs&id=' .. data1 .. '&id1=' .. embed})


end
end  
end
end
end
end


end

 
 
 elseif args.q == 'kinogoxs' then

args.id = string.gsub(args.id, ' ', '+') 
args.id1 = string.gsub(args.id1, ' ', '+') 

 local list1 = 'https://cinemar.cc/api/playlist/load'


local headers4 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/json",
    ["Content-Length"] = "",
    ["Origin"] = "https://cinemar.cc",
    ["Connection"] = "keep-alive",
    ["Referer"] = args.id1,
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}
 
 local data1 = '"' .. args.id .. '"'

--table.insert(t, {title = args.id1, mrl = data1})
 
local x = http.postz(list1, headers4, data1)
 
 
 if x then
 
 local file = string.match(x,'"file":"(.-)/hls.m3u8"')

 if file then
 
 local m3u = conn:load(file .. '/hls.m3u8')

if m3u then

m3u = string.gsub(m3u, './', ',./') 

m3u = string.gsub(m3u, 'stream', '/stream') 
 
for qual, file2 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'simple'

table.insert(t, {title = '(' .. tolazy(qual) .. 'p)', mrl = file .. file2})
 
 
 end
end
end
end
 
 




 
  elseif args.q == 'kinogo' then
 
 local x = conn:load('http://lampac.egorpomidor.site/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
 --table.insert(t, {title = 'http://lampac.egorpomidor.site/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'http://lampac.egorpomidor.site/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
 
    for url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"http.-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
  
  
      
      
 url = string.gsub(url, '\\u0026', '&')
     url = string.gsub(url, '\\u002B', '+')
  
            url = string.gsub(url, '^(.-)', 'http://lampac.egorpomidor.site') 
     


      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total), mrl = url})

       
    end
 --   end
 
 
 
 for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
      --  url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    

      local x = conn:load(url2)

  -- x = string.gsub(x, '< img', '')
   --  x = string.gsub(x, '<img', '')
   --  x = string.gsub(x, '">', '')
  
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do
         
  
         url3 = string.gsub(url3, '\\u0026', '&')
 
     -- url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
    
       
    
     local x = conn:load(url3)
     
    -- x = string.gsub(x, '<img', '')
  --   x = string.gsub(x, '">', '')
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
  
            url4 = string.gsub(url4, '^(.-)', 'http://lampac.egorpomidor.site') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end
 
 
-- https://a7c5ea7c.obrut.show/embed/1EjM/content/MTM4EjM?domain=gokino.su
 
 
--https://gokino.su/vv-player.php?path=/&movie_id=14981

 elseif args.q == 'veo' then

    local x = conn:load('https://api.rstprgapipt.com/balancer-api/iframe?kp=' .. args.id3 .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI')
 
  
 
   for id in string.gmatch(x, 'MOVIE_ID=(.-);') do
 


 local x = conn:load('https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI')
 
-- https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=14981&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI
 
 local slist = string.match(x, '"order":0.-"season".-"order":0(.-)}]}]')
 
 if slist then
 
 for url1, title in string.gmatch(slist, '"filepath":"(http.-)".-"title":"(.-)"') do
 
 t['view'] = 'simple'

   table.insert(t, {title = '(1080p)' .. title, mrl = url1})
end
end


 
 
 
 for total, total1, url1, title in string.gmatch(x, '"order":(.-),"season":.-"order":(.-)}.-"filepath":"(http.-)".-"title":"(.-)"') do
 
 --if total > 0 then
 
 t['view'] = 'simple'

 --= string.gsub(x, '0 сезон 0 серия', '')


   table.insert(t, {title = total1 .. ' ' .. 'сезон ' .. total .. ' серия ' .. title, mrl = url1})
-- end
 end

end
 
 
-- https://storage.videoseedcdn.com/movies/aec50961c21ef09d0040260875ff6627d9728a49/bfd76f0b07fdcc385574bcc1bbc18767:2026011806/1080.mp4:hls:manifest.m3u8
 
 

 
 elseif args.q == 'videoseed2' then
 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
   for url in string.gmatch(x, 'status.-"iframe":"http.-(/embed.-)"') do



   
   local headers = {
    ["Host"] = "kinoserials.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://kinoserials.tv/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 
 

   
 local x = http.getz('https://kinoserials.tv' .. url, headers)
 
 
 local slist = string.match(x, '"#2(.-\"+)') 
 
 if slist then
 
 slist = string.gsub(slist, '|||', '')
 
 slist = string.gsub(slist, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 slist = string.gsub(slist, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 slist = string.gsub(slist, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
slist = string.gsub(slist, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

slist = string.gsub(slist, 'N3IzYXcyRWF0MD', '')

slist = string.gsub(slist, 'NBaUNHQTI2ME9CcWc', '')
 
slist = string.gsub(slist, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    


slist = http.urldecode(base64_decode(slist))


slist = string.gsub(slist, ';{', '"{')



for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   

   
 t['view'] = 'simple'


table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})
end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   

   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end
 end
end
 
 

 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')
	
	
x = string.gsub(x, 'tv%-1%-', '')

x = string.gsub(x, '%- %d сезон"', '')


        
 for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"http.-(/embed.-)"') do
 

   
   t['view'] = 'simple'
   
 table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds2&id=' .. id})
 
 end

elseif args.q == 'videoseeds2' then

local headers = {
    ["Host"] = "kinoserials.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://kinoserials.tv/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}


local x = http.getz('https://kinoserials.tv' .. args.id)



local x = string.match(x, '#2(.-\"+)')
 
 if x then
 
 x = string.gsub(x, '|||', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    x =http.urldecode(base64_decode(x))


x = string.gsub(x, ';{', '"{')


 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   

   
 t['view'] = 'simple'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   

 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end
 end








 
 elseif args.q == 'videoseed' then

local url = 'https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3


  local headers = {
    ["Host"] = "api.videoseed.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

      local x = http.get(url, headers)
 

 
    for url in string.gmatch(x, 'status.-"iframe":"(http.-)"') do

  url = string.gsub(url, '\\', '')

--tv-3-kinolot.net

local headers = {

    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["Cookie"] = "PHPSESSID=0f872a7617175500ab7b29ec4dbba1b4;kt_rt_token=6091e1d0bf421f73804d2f0dcc2bf1cf;kt_ips=159.69.148.100",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache",
["Vary"] = "Accept-Encoding",
["Content-Encoding"] = "gzip"
}

   
  
     local x = http.getz(url, headers)
 

   
    local slist = string.match(x, '#2(.-)\"+') 
 
 
 
 if slist then
 
 
 slist = string.gsub(slist, '|||', '')
 
 
slist = string.gsub(slist, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 slist = string.gsub(slist, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 slist = string.gsub(slist, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
slist = string.gsub(slist, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

slist = string.gsub(slist, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 slist = string.gsub(slist, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 slist = string.gsub(slist, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 slist = string.gsub(slist, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
slist = string.gsub(slist, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

slist = string.gsub(slist, 'N3IzYXcyRWF0MD', '')

slist = string.gsub(slist, 'NBaUNHQTI2ME9CcWc', '')
 
slist = string.gsub(slist, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')


    slist = base64_decode(slist)

slist = string.gsub(slist, ';{', '"{')

--table.insert(t, {title = x, mrl = x})


--local slist = string.match(x, '"file":"(.-)"') 
 

   for total, url1 in string.gmatch(slist,'"{(.-)}.-(http.-m3u8)') do
  
  
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end

end
end


local url = 'https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3



    local headers = {
    ["Host"] = "api.videoseed.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

      local x = http.get(url, headers)
 

 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')
	
	
--x = string.gsub(x, 'tv%-1%-', '')

x = string.gsub(x, '%- %d сезон"', '')




 for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"(http.-)"') do
 

   
   t['view'] = 'simple'
   
 table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds&id=' .. id})
 
 end
 
 elseif args.q == 'videoseeds' then

local headers = {
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

 local x = http.getz(args.id, headers)


 
    local x = string.match(x, '#2(.-)\"+') 
 
 if x then
 
 
 
 x = string.gsub(x, '|||', '')
 
x = string.gsub(x, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 x = string.gsub(x, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 x = string.gsub(x, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
x = string.gsub(x, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

x = string.gsub(x, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

--http.urlencode(
    x =http.urldecode(base64_decode(x))

x = string.gsub(x, ';{', '"{')

  -- local slist = string.match(x, '"file":"(.-)"')


 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
  
  
  
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end
end

 
 
 
 
 --https://movie.kinodostuptut.com/search?filters={"yearRange":[1979]}&q=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%2C
 
 elseif args.q == 'rapidcdn' then
  
  
   local x = conn:load('https://movie.kinodostuptut.com/search?filters={"yearRange":[' .. args.id2 .. ']}&q=' .. urlencode(args.id1))
 
  t['view'] = 'simple'

      
      for url, image, title, total in string.gmatch(x, '<a class="group relative block.-href="(.-)".-<img.-src="(.-)".-<span class="text%-sm.->(.-)</span>.-class="text%-xs.->(.-)</span>') do
      
    url = string.gsub(url, '^(.-)', 'https://movie.kinodostuptut.com')
    
    table.insert(t, {title = tolazy(title) .. ',' .. total, mrl = '#stream/q=rapidcdns&id=' .. url, image = image})

     end 
 
 

      elseif args.q == 'rapidcdns' then
    
   -- Хищник: Планета смерти | сезон 0 | эпизод 0 в хорошем качестве без регистрации, смс и vpn\
    
      local x = conn:load(args.id)

      for url, title in string.gmatch(x, '"m3u8MasterFilePath.-"(http.-)\\".-{.-"title.-":.-"Смотреть сериал (.-)в хорошем') do
     
     
     title = string.gsub(title, '| сезон 0 | эпизод 0', '')
     
     t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = url})

     end 
 
   
   
   
   
   
   
elseif args.q == '24kino' then


local headers = {
["Host"] = "api-web-systema.platform24.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
["Accept"] = "application/json, text/plain, */*",
["Accept-Language"] = "ru-ru",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-Type"] = "application/json",
["Content-Length"] = "52",
["Origin"] = "https://tv.cyxym.net",
["Connection"] = "keep-alive",
["Referer"] = "https://tv.cyxym.net/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site"
}

local params = '{"device_id":"c99fe352-7718-4879-b92a-c6e3f61c9ccd"}'


   local url = 'https://api-web-systema.platform24.tv/v2/auth/device'

        local x = http.postz(url, headers, params)

      local token = string.match(x, '"access_token":"(.-)"')

	if token then

local url = 'https://api-web-systema.platform24.tv/v2/rows/1154861723594598690?access_token=' .. token .. '&channels_version=2&format=json&limit=100&offset=0&text=' .. urlencode(args.id1 .. ' ' .. args.id2)

if url then

 local x = conn:load(url)

--table.insert(t, {title = url, mrl = url, image = image})


local id, title, year = string.match(x,'"contents".-%[{"id":"(.-)".-"title":"(.-)".-"year":"(.-)"')

if id then

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id .. '?access_token=' .. token .. '&format=json')


local id1, libs = string.match(x,'"graphic_title".-"id":"(.-)".-"libraries":%[{"id":(.-)}')

local x = conn:load('https://api-web-systema.platform24.tv/v2/libraries/' .. libs .. '/contents/' .. id1 .. '/stream?access_token=' .. token .. '&channels_version=2&format=json&ts=0&type=hls')


local play = string.match(x,'"hls":"(.-)"')   
  if play then

t['view'] = 'simple'

table.insert(t, {title = title .. ' (' .. year .. ')', mrl = play, image = image})

end
end
end



local url1 = 'https://api-web-systema.platform24.tv/v2/rows/1154861723663302975?offset=0&limit=100&channels_version=2&format=json&access_token=' .. token .. '&text=' .. urlencode(args.id1 .. ' ' .. args.id2)

if url1 then


local x = conn:load(url1)

--table.insert(t, {title = url1, mrl = url1, image = image})

local id, title, year = string.match(x,'"contents".-%[{"id":"(.-)".-"title":"(.-)".-"year":"(.-)"')

if id then

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id .. '?access_token=' .. token .. '&format=json')



local seasons = string.match(x,'"contents":%[(.-)]')
  
  
  for id1, season in string.gmatch(seasons,'{"id":"(.-)".-"title":"(.-)"') do

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id1 .. '?access_token=' .. token .. '&format=json')

local episodes = string.match(x,'"contents":%[(.-)]')
  
  
  for id2, series in string.gmatch(episodes,'{"id":"(.-)".-"content_type".-"series":(.-),') do

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id2 .. '?access_token=' .. token .. '&format=json')

  local id3, libs = string.match(x,'"graphic_title".-"id":"(.-)".-"libraries":%[{"id":(.-)}')

local x = conn:load('https://api-web-systema.platform24.tv/v2/libraries/' .. libs .. '/contents/' .. id3 .. '/stream?access_token=' .. token .. '&channels_version=2&format=json&ts=0&type=hls')


local play = string.match(x,'"hls":"(.-)"')   
  if play then

t['view'] = 'simple'

table.insert(t, {title = season .. ' серия ' .. series .. ' ' .. title .. ' (' .. year .. ')', mrl = play, image = image})


end
end
end
end
end

end

   
   
   
   


elseif args.q == 'mirkino' then


local url = 'https://ru.mir-kino.pp.ru/Items?userId=75280f7de0a64771b9dd63c4b23b814d&isMissing=false&limit=800&recursive=true&searchTerm=' .. urlencode(args.id1) .. '&ProductionYear=' .. args.id2 .. '&fields=PrimaryImageAspectRatio&fields=CanDelete&fields=MediaSourceCount&includeItemTypes=Movie&includeItemTypes=Series&includeItemTypes=Episode&includeItemTypes=Playlist&includeItemTypes=MusicAlbum&includeItemTypes=Audio&includeItemTypes=TvChannel&includeItemTypes=PhotoAlbum&includeItemTypes=Photo&includeItemTypes=AudioBook&includeItemTypes=Book&includeItemTypes=BoxSet&imageTypeLimit=1&enableTotalRecordCount=false'


local headers = {
    ["Host"] = "ru.mir-kino.pp.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    ["Accept"] = "application/json, text/plain, */*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Authorization"] = 'MediaBrowser Client="Jellyfin%20Web", Device="Firefox", DeviceId="TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6MTUyLjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvMTUyLjB8MTc4NDEwMDMxMDg1OQ11", Version="10.11.10", Token="7325db2c854d4d0aadea155da54f2d58"',
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local x = http.getz(url, headers)

for name, item, year in string.gmatch(x,'"Name":"(.-)".-"Type":"Movie".-"ItemId":"(.-)".-"ProductionYear":(.-),') do

if item then

local x = http.getz('https://ru.mir-kino.pp.ru/Items/' .. item, headers)

for id, qual in string.gmatch(x,'{"Protocol":"File","Id":"(.-)".-"Name":"(%d+p)"') do

t['view'] = 'simple'


table.insert(t, {title = qual .. ' ' .. name .. ' (' .. year .. ')', mrl = 'https://ru.mir-kino.pp.ru/Videos/' .. id .. '/stream?api_key=7325db2c854d4d0aadea155da54f2d58&Static=true', image = image})

end
end
end

local url = 'https://ru.mir-kino.pp.ru/Items?userId=75280f7de0a64771b9dd63c4b23b814d&isMissing=false&limit=800&recursive=true&searchTerm=' .. urlencode(args.id1) .. '&ProductionYear=' .. args.id2 .. '&fields=PrimaryImageAspectRatio&fields=CanDelete&fields=MediaSourceCount&includeItemTypes=Movie&includeItemTypes=Series&includeItemTypes=Episode&includeItemTypes=Playlist&includeItemTypes=MusicAlbum&includeItemTypes=Audio&includeItemTypes=TvChannel&includeItemTypes=PhotoAlbum&includeItemTypes=Photo&includeItemTypes=AudioBook&includeItemTypes=Book&includeItemTypes=BoxSet&imageTypeLimit=1&enableTotalRecordCount=false'


local headers = {
    ["Host"] = "ru.mir-kino.pp.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    ["Accept"] = "application/json, text/plain, */*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Authorization"] = 'MediaBrowser Client="Jellyfin%20Web", Device="Firefox", DeviceId="TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6MTUyLjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvMTUyLjB8MTc4NDEwMDMxMDg1OQ11", Version="10.11.10", Token="7325db2c854d4d0aadea155da54f2d58"',
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}



local x = http.getz(url, headers)

for name, item in string.gmatch(x,'"Name":"(.-)".-"Type":"Playlist".-"ItemId":"(.-)"') do

if item then


local x = http.getz('https://ru.mir-kino.pp.ru/Playlists/' .. item .. '/Items?Fields=PrimaryImageAspectRatio,MediaSourceCount,Chapters,Trickplay&EnableImageTypes=Primary,Backdrop,Banner,Thumb', headers)



for name1, item1, year in string.gmatch(x,'{"Name":"(.-)".-"Type":"Movie".-"ItemId":"(.-)".-"ProductionYear":(.-),') do

if item1 then

  local x = http.getz('https://ru.mir-kino.pp.ru/Items/' .. item1, headers)



for id, qual in string.gmatch(x,'{"Protocol":"File","Id":"(.-)".-"Name":"(%d+p)"') do

t['view'] = 'simple'


table.insert(t, {title = qual .. ' ' .. name1 .. ' (' .. year .. ')', mrl = 'https://ru.mir-kino.pp.ru/Videos/' .. id .. '/stream?api_key=7325db2c854d4d0aadea155da54f2d58&Static=true', image = image})

end
end
end
end
end

 local x = http.getz(url, headers)


local id, series, item = string.match(x,'"Items".-"Name".-"Id":"(.-)".-"Type":"(Series)".-"ItemId":"(.-)"') 

if item then


local x = http.getz('https://ru.mir-kino.pp.ru/Shows/' .. id .. '/Seasons?userId=75280f7de0a64771b9dd63c4b23b814d&Fields=ItemCounts,PrimaryImageAspectRatio,CanDelete,MediaSourceCount', headers)



for name, id1, season in string.gmatch(x,'"Name":"(Сезон.-)".-"Id":"(.-)".-"SeriesId":"(.-)"') do

if season then

local x = http.getz('https://ru.mir-kino.pp.ru/Shows/' .. season .. '/Episodes?seasonId=' .. id1 .. '&userId=75280f7de0a64771b9dd63c4b23b814d&Fields=ItemCounts,PrimaryImageAspectRatio,CanDelete,MediaSourceCount,Overview', headers)



for nameser, id2 in string.gmatch(x,'"Name":"(.-)".-"Id":"(.-)"') do


local x = http.getz('https://ru.mir-kino.pp.ru/Items/' .. id2 .. '?userId=75280f7de0a64771b9dd63c4b23b814d', headers)


local episode, item = string.match(x,'{"Name":".-".-/episode/(.-)".-"ItemId":"(.-)"')

t['view'] = 'simple'



table.insert(t, {title = name .. ' ' .. 'серия ' .. episode .. ' ' .. nameser, mrl = 'https://ru.mir-kino.pp.ru/Videos/' .. item .. '/stream?api_key=7325db2c854d4d0aadea155da54f2d58&Static=true', image = image})

end
end
end
end





elseif args.q == 'kinoflix' then



 local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru')
 
-- table.insert(t, {title = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru', mrl = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru'})

--https://videodb.cloud/embed/splayer.php?type=serial&id=
 
 for id, title, year in string.gmatch(x,'%[{"id":(.-),"title":"(.-)".-"subtitle":"(.-)".-"mediaType":"movie"') do
 
 if id then

 local x = conn:load('https://videodb.cloud/embed/player.php?type=movie&id=' .. id .. '&lang=ru')

--table.insert(t, {title = 'https://videodb.cloud/embed/player.php?type=movie&id=' .. id, mrl = 'https://videodb.cloud/embed/player.php?type=movie&id=' .. id})

--local file = string.match(x,'"file":"(.-)"')

if x then

for qual, url in string.gmatch(x,'"file".-%[(.-)]{Русский}(http.-);') do


url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=')

t['view'] = 'simple'

 
 table.insert(t, {title = title .. ' (' .. year .. ')', mrl = url})
 

--local x = conn:load('https://videodb.stream/file/play?type=movie&id=1212763&name=slug&lang=ru&p=l.playlist'

end

--local iframe = string.match(x,'<iframe.-src="(http.-txt)"')

-- local x = conn:load(iframe)

--local playlist = string.match(x,'file: "(http.-playlist)"')

--local x = conn:load(playlist)

local headers = {
["Pragma"] = "no-cache",
["Cache-Control"] = "no-cache",
["sec-ch-ua"] = '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
["sec-ch-ua-mobile"] = "?0",
["sec-ch-ua-platform"] = "Windows",
["DNT"] = "1",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,uk-UA;q=0.8,uk;q=0.7,en-US;q=0.6,en;q=0.5",
["Priority"] = "u=1, i",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-origin",
["Sec-Fetch-Storage-Access"] = "active",
["Referer"] = iframe
}




--local txt = string.match(x,'"file":"(http.-txt)"')

--local x = http.getz('https://api.potok.rip/api/proxy?url=' .. txt, headers)

--table.insert(t, {title = x, mrl = x})

--table.insert(t, {title = 'https://api.potok.rip/api/proxy?url=' .. txt, mrl = 'https://api.potok.rip/api/proxy?url=' .. txt})

--for url in string.gmatch(x,'#EXT%-X%-MEDIA.-NAME="Russian.-LANGUAGE="ru".-URI="(/m3/.-)"') do

--url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=https://videodb.stream') 
--.. '#.m3u8'

--local x = http.getz('https://videodb.stream' .. url, headers)

--table.insert(t, {title = x, mrl = x})

--end

--for qual, url in string.gmatch(x,'#EXT%-X%-STREAM%-INF.-RESOLUTION=.-x(.-),.-AUDIO.-(/m3/.-)\n') do

--url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=https://videodb.stream') .. '#.m3u8'

--local x = http.getz('https://videodb.stream' .. url, headers)

--table.insert(t, {title = x, mrl = x})


--table.insert(t, {title = qual .. 'p', mrl = url})

--end


end
end
end

--/embed/splayer.php?type=serial&id=${query.tmdbId}


 local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru')
 
-- table.insert(t, {title = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru', mrl = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru'})

--https://videodb.cloud/embed/splayer.php?type=serial&id=
 
 local id = string.match(x,'%[{"id":(.-),"title":".-".-"subtitle":".-".-"mediaType":"tv"')
 
 if id then

 local x = conn:load('https://videodb.cloud/embed/splayer.php?type=serial&id=' .. id)
 
 --table.insert(t, {title = 'https://videodb.cloud/embed/splayer.php?type=serial&id=' .. id, mrl = 'https://videodb.cloud/embed/splayer.php?type=serial&id=' .. id})
 
 if x then
 
 -- for season, folder in string.gmatch(x,'title":"(Сезон.-)".-"folder":%[(.-)%]%},') do 
  
  for seria, url, url1, url2 in string.gmatch(x,'"title":"(Серия.-)".-"file".-{Русский}(http.-/SE)(.-)(/.-);') do
 
 
 url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=') .. url1 .. url2

t['view'] = 'simple'

 
 table.insert(t, {title = 'Сезон ' .. url1 .. ' ' .. seria, mrl = url})
 
end
end
 end
-- end
-- end
 
 

--https://beta.mitsu.tv/api/lite/kinoflix?kinopoisk_id=5463793&title=%D0%97%D0%BB%D0%BE%D0%B2%D0%B5%D1%89%D0%B8%D0%B5+%D0%BC%D0%B5%D1%80%D1%82%D0%B2%D0%B5%D1%86%D1%8B%3A+%D0%9F%D0%B5%D0%BA%D0%BB%D0%BE&year=2026

local x = conn:load('https://beta.mitsu.tv/api/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
 
 --local x = conn:load('https://lam5.akter-black.com/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')
 
 
 x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '\\u002B', '+')
x = string.gsub(x, '&quot;', '"')
 
 
--table.insert(t, {title = 'https://beta.mitsu.tv/api/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lam5.akter-black.com/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m'})

for url, title in string.gmatch(x, 'videos__item videos__movie.-method.-play.-url.-(http.-m3u8).-videos__item%-title.->(.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = title, mrl = url})

end






for url, year, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"link".-"url".-(http.-)".-"year":(.-),.-videos__season%-title">(.-)<') do

if year then

 
    local x1 = conn:load(url)
  if x1 then  
    
x1 = string.gsub(x1, '&quot;', '"')
x1 = string.gsub(x1, '\\u0026', '&')
 x1 = string.gsub(x1, '\\u002B', '+')

for url1, total in string.gmatch(x1, '<div class="videos__item videos__movie.-"method".-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = title .. ' (' .. year .. ')', mrl = url1})

end
end
end
end

--local x = conn:load('https://lam5.akter-black.com/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')
 
-- x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '&quot;', '"')

for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"link".-url.-(http.-)".-videos__season%-title.->(Сезон.-)<') do


--table.insert(t, {title = url, mrl = url})


local x1 = conn:load(url)

if x1 then

 x1 = string.gsub(x1, '&quot;', '"')
x1 = string.gsub(x1, '\\u0026', '&')
 x1 = string.gsub(x1, '\\u002B', '+')

for url1, total in string.gmatch(x1, '<div class="videos__item videos__movie.-"method".-"play".-"url".-(http.-)".-class="videos__item%-title.->(Серия.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = title .. ' ' .. total, mrl = url1})

end
end
end




for total, url, title in string.gmatch(x, 'quality.-{"(.-)":"(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end

for total, url, title in string.gmatch(x, 'quality.-/proxy.-,"(.-)":"(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end


for total, url, title in string.gmatch(x, 'quality.-/proxy.-/proxy.-,"(.-)":"(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end




   
elseif args.q == 'xkino' then
  
 -- https://ru.kinozona.net/poisk.php
--form=do=search&subaction=search&story=чужой
  
 -- local url = 'https://ru.kinozona.net/poisk.php?form=do%3Dsearch%26subaction%3Dsearch%26story%3D' .. urlencode(args.id1)
  
  local url = 'https://videomob.su/poisk.php'
  
--local url = 'https://ru.kinozona.net/poisk.php'
  
  local headers = {
    ["Host"] = "videomob.su",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Content-Length"] = "",
    ["Origin"] = "https://videomob.su",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://videomob.su/",
    ["Cookie"] = "PHPSESSID=kt614shanjhqpcb4qgqfuv7t0l; _ym_uid=1778172366407960634; _ym_d=1778172366; _ym_isad=2; vid=YOax6UDdZMBIbGlG; domain_sid=FP3g3yrURwKO2N-PHJz5S%3A1778172907526; adrdel=1778172387500; adrdel=1778172387500; adrcid=A61RKDqR0L5sDSPiVXIiXNg; adrcid=A61RKDqR0L5sDSPiVXIiXNg; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; ecf7d0dc55_delayCount=10; ecf7d0dc55_blockTimer=1; u_ecf7d0dc55=1; _ohmybid_cmf=2; adtech_uid=7956247a-a163-46a4-943d-af979def0958%3Akinozona.net; top100_id=t1.7627570.775262879.1778172521116; t3_sid_7627570=s1.389385681.1778172521120.1778172911440.1.20.8.1..",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

  local form = 'form=do%3Dsearch%26subaction%3Dsearch%26story%3D' .. urlencode(args.id1)
  
      local x = http.postz(url, headers, form)
      
  
for urls, title in string.gmatch(x,'<a href="(.-)">(.-)<span') do
 
 urls = string.gsub(urls, '^(.-)', 'https://videomob.su')
 
  t['view'] = 'simple'
  
  
   table.insert(t, {title = title, mrl = '#stream/q=xkinos&id=' .. urls})

   end  
  
  
  elseif args.q == 'xkinos' then
    
    
      local x = conn:load(args.id)
  
    
  local id = string.match(x,'<div class="trailer".-torLoad%(\'(.-)\'')
  
  local se = string.match(x,'function torLoad%(id.-se = (.-)%)')
 
 
 
 
  local tor = string.match(x,'function torLoad.-load.-(tor.-php)')
   
   local poster = string.match(x,'function torLoad.-load.-tor.-php.-poster:"(.-)"')
   
  --  load("/tor_series.php"
    
  local url = 'https://videomob.su/' .. tor




local headers = {
    ["Host"] = "videomob.su",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Content-Length"] = "",
    ["Origin"] = "https://videomob.su",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://videomob.su/",
    ["Cookie"] = "PHPSESSID=kt614shanjhqpcb4qgqfuv7t0l; _ym_uid=1778172366407960634; _ym_d=1778172366; _ym_isad=2; vid=YOax6UDdZMBIbGlG; domain_sid=FP3g3yrURwKO2N-PHJz5S%3A1778172907526; adrdel=1778172387500; adrdel=1778172387500; adrcid=A61RKDqR0L5sDSPiVXIiXNg; adrcid=A61RKDqR0L5sDSPiVXIiXNg; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; ecf7d0dc55_delayCount=10; ecf7d0dc55_blockTimer=1; u_ecf7d0dc55=1; _ohmybid_cmf=2; adtech_uid=7956247a-a163-46a4-943d-af979def0958%3Akinozona.net; top100_id=t1.7627570.775262879.1778172521116; t3_sid_7627570=s1.389385681.1778172521120.1778172911440.1.20.8.1..",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

  local params = 'id=' .. id .. '&se=' .. se .. '&poster=' .. poster
  
      local x = http.postz(url, headers, params)

--table.insert(t, {title = url, mrl = url, image = image})   


local video = string.match(x,'<video src="(http.-)"')
 
 if video then
 
 print(video)
    return {view = 'playback', mrl = video, seekable = 'true', direct = 'true'}
 
 --table.insert(t, {title = video, mrl = video, image = image})
 
 end
 
   
   for video, title in string.gmatch(x,'(https://s.-)\'>(.-)<') do
   
 --   url = url_for(x)
--url = urldecode(url)
 
 --table.insert(t, {title = url, mrl = url, image = image})   
  
t['view'] = 'simple'
  
 -- if video then
--    print(video)
 --   return {view = 'playback', mrl = video, seekable = 'true', direct = 'true'}
--end

  table.insert(t, {title = title, mrl = video, image = image})   
  
  end
  
  
  
  
 -- http://seasonvar.ru/?mode=search&query
  
  
  elseif args.q == 'seasonvar' then
    
   

    
      local x = conn:load('http://seasonvar.ru/?mode=search&query=' .. urlencode(args.id1))
  
  
 -- local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
     --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'http:')
        
        t['view'] = 'simple'
		
			

  
  
  local x = conn:load('http://seasonvar.ru' .. url)
 
 
 local slist = string.match(x, '<ul class="tabs%-result">(.-)</ul>')
      
if slist then

   for url2, total in string.gmatch(slist, '<a href="(.-)".-Сериал (.-)<') do
   
  table.insert(t, {title = tolazy(total), mrl = '#stream/q=seasonvars&id=' .. url2, image = image})
		
		end
end
end



   
   elseif args.q == 'seasonvars' then
   
   local x = conn:load('http://seasonvar.ru' .. args.id)
        
      --  local x = conn:load(url2)
 
 for id1, total1 in string.gmatch(x,'"(/playls2.-)".-data%-translate%-percent=.->(.-)</li>') do
 
 
    --    for id1 in string.gmatch(x,'player = new Playerjs.-var pl.-"(/playls2.-)"') do
            
    local x = conn:load('http://seasonvar.ru' .. id1)
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id2 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id2 = string.gsub(id2, '\\/\\/b2xvbG8=', '') 
      
      id2=http.urldecode(base64_decode(id2))
       id2 = string.gsub(id2, '^(.-)', 'http:') 
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title1) .. ' ' .. total1, mrl = id2})
            end  
	end
  
 
local x = conn:load('http://seasonvar.ru' .. args.id)
        
 
 local id2 = string.match(x,'var pl.-(/playls2.-)"')

            local x = conn:load('http://seasonvar.ru' .. id2)
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id3 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id3 = string.gsub(id3, '\\/\\/b2xvbG8=', '') 
      
      id3=http.urldecode(base64_decode(id3))
       id3 = string.gsub(id3, '^(.-)', 'http:') 
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title1), mrl = id3})
            end  
            
            
            
    
elseif args.q == 'zetflixdb' then
  
  
--http://31.129.234.181:80/lite/zetflix?kinopoisk_id=386&title=чужой&year=1979&uid=guest
 
-- https://beta.mitsu.tv/api/lite/phantom?kinopoisk_id=386&title=чужой&year=1979
 
    local x = http.get('https://beta.mitsu.tv/api/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
    
   for quality, title in string.gmatch(x, 'method.-url.-"quality":{(.-)}.-videos__item%-title.->(.-)<') do

    for total, url in string.gmatch(quality, '"(%d+p)":"http.-(/proxy.-)"') do


 
 --url = string.gsub(url, '.m3u8', '')
 
    url = string.gsub(url, '\\u0026', '')
    url = string.gsub(url, '^(.-)', 'https://beta.mitsu.tv/api')
    --'&uid=guest'
     
      t['view'] = 'simple'
    
    
   -- table.insert(t, {title = url, mrl = url})
    
    table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = url})
     end 
 
 end  
    
   
    
    

local x = http.get('https://beta.mitsu.tv/api/lite/zetflix?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   


      for  url2, total in string.gmatch(x, 'class="videos__item videos__season.-"method".-"link".-"url".-(http.-)".-class="videos__item%-title videos__season%-title">(.-)<') do
 
url2 = string.gsub(url2, '\\u0026', '&') 
 url2 = string.gsub(url2, '\\u002B', '+') 
 
 

       local x = http.get(url2)
  
     x = string.gsub(x, '\\u0026', '&') 
x = string.gsub(x, '\\u002B', '+') 
   
--   table.insert(t, {title = url2, mrl = url2})  




   for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do


url3 = string.gsub(url3, '\\u0026', '&') 
url3 = string.gsub(url3, '\\u002B', '+') 


       local x = http.get(url3)

   x = string.gsub(x, '\\u0026', '&') 
x = string.gsub(x, '\\u002B', '+') 
     
  --  table.insert(t, {title = url3, mrl = url3})

      for id, id1, id2, id3, total2 in string.gmatch(x, 'class="videos__item videos__movie.-"method".-"call".-"url".-http.-kinopoisk_id=(.-)&.-&s=(.-)&e=(.-)&t=(.-)".-class="videos__item%-title.->(.-)<') do
  

      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = '#stream/q=zetflixdbs&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

     end
     end
    end

elseif args.q == 'zetflixdbs' then

local x = http.getz('https://beta.mitsu.tv/api/lite/zetflix/video?serial=1&kinopoisk_id=' .. args.id .. '&s=' .. args.id1 .. '&e=' .. args.id2 .. '&t=' .. urlencode(args.id3))



local slist = string.match(x, 'quality(.-)}')
      
if slist then

   for  total, url2 in string.gmatch(slist, '"(%d+p)":"http.-(/proxy.-)"') do

  url2 = string.gsub(url2, '^(.-)', 'https://beta.mitsu.tv/api') 
--total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

      end 
    end




  
  
  
    
    elseif args.q == 'zetflix' then
    
 --  https://beta.l-vid.online/lite/videodb?kinopoisk_id=386&title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&year=1979&token=a46f8a8a-8878-4fa5-8554-8296ba62260d

--https://beta.l-vid.online/online/js/a46f8a8a-8878-4fa5-8554-8296ba62260d


--https://beta.l-vid.online/online/js/8126ef1f-0a68-4b87-be2b-732e679461cc



 --   http://beta2.l-vid.online:888/lite/videodb?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn
    
    local headers = {['X-Requested-With'] = 'XMLHttpRequest'}
    
    
    
      local x = http.get('http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

   
 x = string.gsub(x, '\\u0026', '&')
 

 
   for url, total in string.gmatch(x, 'videos__item videos__movie.-stream.-http.-(/lite.-)&.-videos__item%-title.->(.-)<') do
  
 
      local x = http.get('http://beta.l-vid.online' .. url .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
  
  
   local slist = string.match(x, 'qualit.-{(.-)}')
   
   for  total1, url2 in string.gmatch(slist, '"(.-)":"http.-(/lite.-)"') do
      
    url2 = string.gsub(url2, '^(.-)', 'http://beta2.l-vid.online:888')



--http://178.20.46.40:12600/lite/videodb/manifest.m3u8?
      
  --   total1 = string.gsub(total1, ':{"', '') 
      
       t['view'] = 'simple'



    table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
  
 -- http://beta2.l-vid.online:888/lite/zetflix/manifest.m3u8?link=https%3A%2F%2Fcdn-54243ba5.obrut.show%2Fstream%2FAO%2FMHc0RHa%2FQbvNmLuR2YyVGc1RmclBXdz5ie%2F4U3Mt5CdzVmZp5WYtpzcshmO0AXbuADO08SMxYTM0AjNyAjM6MGO5MGOlR2YjJmYwImNyADZjNDM0cTYjVDN1MzN0gDNvUjNmVGOkJmZwYTMzgDNmJDMjRzY1QGN5AjN0gDM1QTOiRDNkdDMjNzLzVWayV2c2R3L
  

   
  local x = http.get('http://beta.l-vid.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

--table.insert(t, {title = 'http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn', mrl = 'http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn'})
   
   x = string.gsub(x, '\\u0026', '&')

   
        for url3, total1  in string.gmatch(x, 'videos__item videos__season.-method.-link.-url.-http.-&s=(.-)&.-videos__item%-title videos__season%-title.->(.-)<') do


   local x = http.get('http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&s=' .. url3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')



    --  local x = http.getz('http://beta.l-vid.online' .. url3 .. '&uid=bwygkgxn')

      for url4, total2  in string.gmatch(x, 'videos__button.-method.-link.-url.-http.-(/lite.-)&#.->(.-)<') do

url4 = string.gsub(url4, '\\u0026', '&')



     local x = http.getz('http://beta.l-vid.online' .. url4 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')


x = string.gsub(x, '\\u0026', '&')

      for url5, total3  in string.gmatch(x, 'videos__item videos__movie.-method.-stream.-http.-/lite.-http.-(http.-)%%22.-videos__item%-title.->(.-серия)<') do

     url5 = string.gsub(url5, '^(.-)', 'http://beta2.l-vid.online:888/lite/zetflix/manifest.m3u8?link=')
    

      t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' -'  .. total3 .. tolazy(total2), mrl = url5})

   
    end
end
end



elseif args.q == 'getstv' then
    
   
   
   
   
--https://evkh.lol
--http://z01.online/lite/getstv?kinopoisk_id=386&title=Чужой&year=1979
    
      local x = conn:load('http://z01.online/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
     url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

     local x = conn:load(url1)
   
 

 
     local slist = string.match(x, 'quality(.-)}')
      
if slist then

   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

    total1 = string.gsub(total1, ',"', '') 
    total1 = string.gsub(total1, '1080p":"/error.mp4"', '')
    
    
    
    
total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

      end 
    end

    end
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-"stream".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end

    
    
elseif args.q == 'mirage1' then
    

   
local x = conn:load('https://evkh.lol/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do

url4 = string.gsub(url4, '\\u0026', '&')
url4 = string.gsub(url4, '\\u002B', '+')



      url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do


url5 = string.gsub(url5, '\\u0026', '&')
url5 = string.gsub(url5, '\\u002B', '+')

      url5 = string.gsub(url5, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
    

     
     
elseif args.q == 'mirage' then
    
  
--https://akter-black.com/lite/alloha?id=1304313&imdb_id=tt32612507&kinopoisk_id=6785084&title=%D0%9C%D1%83%D0%BC%D0%B8%D1%8F&original_title=Lee%20Cronin%27s%20The%20Mummy&serial=0&original_language=en&year=2026&source=tmdb&clarification=0&similar=false&rchtype=web&uid=hobqwt4m
    
     local x = conn:load('https://akter-black.com/lite/alloha?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')



 --  x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"url":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

 local x = conn:load(url .. '&uid=hobqwt4m')
 
-- local x = conn:load(url)
 
 local slist = string.match(x,'quality.-{(.-)}')
 
 if slist then
 
 for qual, url1 in string.gmatch(slist, '"(%d+p)".-(http.-m3u8)') do
   
 
     t['view'] = 'simple'


    table.insert(t, {title = '(' .. qual .. ') ' .. total, mrl = url1})

 end
    end
   end 
 
 
-- local x = conn:load('https://akter-black.com/lite/alloha?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')
 
 
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3 .. '&uid=hobqwt4m')


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4 .. '&uid=hobqwt4m')

--table.insert(t, {title = url4, mrl = url4})

x = string.gsub(x, '\\u0026', '&')

     for id, id1, id2, id3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"url":"http.-?t=(.-)&s=(.-)&e=(.-)&token_movie=(.-)&orid.-class="videos__item%-title">(.-)</div>') do

   
    t['view'] = 'simple'



--https://akter-black.com/lite/alloha/video?t=234&s=1&e=2&token_movie=352d33e54cf583160797cae895ff80&orid





table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = '#stream/q=mirages&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2  .. '&id3=' ..  id3})

end
end
end
     
     elseif args.q == 'mirages' then
     
     local x = conn:load('https://akter-black.com/lite/alloha/video?t=' .. args.id .. '&s=' .. args.id1 .. '&e=' .. args.id2 .. '&token_movie=' .. args.id3 .. '&uid=hobqwt4m')
    
    local slist = string.match(x,'quality.-{(.-)}')
 
 if slist then
 
 for qual, url1 in string.gmatch(slist, '"(%d+p)".-(http.-m3u8)') do
   
 
     t['view'] = 'simple'


    table.insert(t, {title = '(' .. qual .. ')', mrl = url1})

 end
    end 
     
     
    elseif args.q == 'mirage1' then
    
  
 -- https://vizhu.top
--  https://lampa.persh1n.ru
  
--  http://93.183.95.219:11378
    
  --  https://lam.maxvol.pro/lite/mirage?kinopoisk_id=386&title=чужой&year=1979
    
     local x = conn:load('https://mylam.ru/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



  -- x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

      t['view'] = 'simple'


    table.insert(t, {title = total, mrl = url})

 
    end
    
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')

url5 = string.gsub(url5, '\\u002B', '+') 
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
     
--http://online7.skaz.tv/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025

  --  http://z01.online/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025 
 
 
 
 
 
 
  
 elseif args.q == 'paladin' then
  
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

     local url = 'https://beta.l-vid.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
   if x then
   
--   for url1, total in string.gmatch(x, 'method.-url.-(http.-)&#.-videos__item%-title.->(.-)<') do
  
  x = string.gsub(x, '\\u0026', '&')

for id, id1, total in string.gmatch(x, 'method.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do



      t['view'] = 'simple'

 table.insert(t, {title = total, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
 
 -- table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

      end 
   
   
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-(http.-)&.-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')

--url3 = string.gsub(url3, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


       local x = conn:load(url3)

    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&.->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')

 -- url4 = string.gsub(url4, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


     local x = conn:load(url4)
    
    x = string.gsub(x, '\\u0026', '&')
    

   for id, id1, total2 in string.gmatch(x, 'method.-stream.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do
 

  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
  

end
end
end
end     
      
 elseif args.q == 'paladins' then
    
local headers = {
    ["Host"] = "beta2.l-vid.online:888",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cache-Control"] = "no-cache"
}

local x = http.getz('http://beta2.l-vid.online:888/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d', headers)

      local slist = string.match(x, '"quality"(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":"(http.-)"') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
   url6 = string.gsub(url6, '\\u002B', '+')

--  url6 = string.gsub(url6, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = url6})

end
end
 
 
 
 
elseif args.q == 'spectre' then
 
 -- https://lam.akter-black.com/lite/spectre/video?id_file=911588&token_movie=a6ef0986c7558c5792c3ad19d43611&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
 
-- https://beta.mitsu.tv/api/lite/phantom?kinopoisk_id=386&title=чужой&year=1979
  
 -- http://31.129.234.181/lite/phantom/?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

  
  local url = 'https://beta.mitsu.tv/api/lite/phantom?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2

local x = conn:load(url)
  
  if x then
  
   
   for url1, total in string.gmatch(x, 'method.-url.-http.-(/lite.-)".-videos__item%-title.->(.-)<') do
  
   
        url1 = string.gsub(url1, '\\u0026', '&')

  
     local x = conn:load('https://beta.mitsu.tv/api' .. url1)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

 

   local slist = string.match(x, 'quality(.-)}')
      
      
   if slist then
   for  total1, url2 in string.gmatch(slist, '"(%d+p)".-http.-(/proxy.-m3u8)') do
  
   url2 = string.gsub(url2, '^(.-)', 'https://beta.mitsu.tv/api')   
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
      t['view'] = 'simple'

 
  table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})
 

      end 
    end
    end
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-http.-(/lite.-)".-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')



       local x = http.get('https://beta.mitsu.tv/api' .. url3)
       --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-(/lite.-)".->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')


     local x = http.get('https://beta.mitsu.tv/api' .. url4)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
    
    x = string.gsub(x, '\\u0026', '&')
    
--table.insert(t, {title = 'http://94.249.239.39' .. url4, mrl = 'http://94.249.239.39' .. url4})



  
  
   for id, id1, total2 in string.gmatch(x, 'method.-call.-url.-http.-id_file=(.-)&token_movie=(.-)".-videos__item%-title.->(.-)<') do
 
-- url5 = string.gsub(url5, '\\u0026', '&')
    
 --  url5 = string.gsub(url5, '\\u002B', '+')
 
   
  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=spectres&id=' .. id .. '&id1=' .. id1})
  
 -- table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=spectres&id=' .. id .. '&id1=' .. id1  .. '&id2=' .. id2 .. '&id3=' .. id3})
  


end
end
end
 end    
      
 elseif args.q == 'spectres' then
    
     
 --http://94.249.239.39/lite/mirage/video?t=34&s=1&e=1&token_movie=de9688cf5cb8bd7dd2876e9a61ed19
 
 
     local x = conn:load('https://beta.mitsu.tv/api/lite/phantom/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


--local x = http.get('http://94.249.239.39/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
--.. '&uid=bwygkgxn')

if x then


      local slist = string.match(x, 'quality.-{(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":.-http.-(/proxy.-m3u8)') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
  

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = 'https://beta.mitsu.tv/api' .. url6})
--.. '&uid=bwygkgxn'})

end
end
end
 
 
 
 
 elseif args.q == 'phantom' then
  
 -- http://31.129.234.181/lite/phantom/?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

  
  local url = 'http://31.129.234.181/lite/phantom?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0'


local x = http.get(url)
  
  if x then
  
   
   for url1, total in string.gmatch(x, 'method.-url.-http.-(/lite.-)".-videos__item%-title.->(.-)<') do
  
   
        url1 = string.gsub(url1, '\\u0026', '&')

  
     local x = conn:load('http://31.129.234.181' .. url1 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

 

   local slist = string.match(x, 'quality(.-)}')
      
      
   if slist then
   for  total1, url2 in string.gmatch(slist, '"(%d+p)".-http.-(/proxy.-m3u8)') do
  
   url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')   
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
      t['view'] = 'simple'

 
  table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})
 

      end 
    end
    end
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-http.-(/lite.-)".-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')



       local x = http.get('http://31.129.234.181' .. url3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-(/lite.-)".->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')


     local x = http.get('http://31.129.234.181' .. url4 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
    
    x = string.gsub(x, '\\u0026', '&')
    
--table.insert(t, {title = 'http://94.249.239.39' .. url4, mrl = 'http://94.249.239.39' .. url4})



  
  
   for id, id1, total2 in string.gmatch(x, 'method.-call.-url.-http.-id_file=(.-)&token_movie=(.-)".-videos__item%-title.->(.-)<') do
 
-- url5 = string.gsub(url5, '\\u0026', '&')
    
 --  url5 = string.gsub(url5, '\\u002B', '+')
 
   
  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=phantoms&id=' .. id .. '&id1=' .. id1})
  
 -- table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladinnsss&id=' .. id .. '&id1=' .. id1  .. '&id2=' .. id2 .. '&id3=' .. id3})
  


end
end
end
 end    
      
 elseif args.q == 'phantoms' then
    
     
 --http://94.249.239.39/lite/mirage/video?t=34&s=1&e=1&token_movie=de9688cf5cb8bd7dd2876e9a61ed19
 
 
     local x = conn:load('http://31.129.234.181/lite/phantom/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


--local x = http.get('http://94.249.239.39/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
--.. '&uid=bwygkgxn')

if x then


      local slist = string.match(x, 'quality.-{(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":.-http.-(/proxy.-m3u8)') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
  

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = 'http://31.129.234.181' .. url6})
--.. '&uid=bwygkgxn'})

end
end
end
 
 
 
   
    elseif args.q == 'videohub' then
    
 
 
-- https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=386
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 
 
 local slist = string.match(x, '"isSerial":false(.-)trailers')
 
 if slist then
 
 
 
 
for id, total, total1 in string.gmatch(slist, '"vkId":"(.-)".-"voiceStudio":"(.-)".-"voiceType":"(.-)"') do
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = '#stream/q=cdnvideohubm&id=' .. id})
 

 
 
	
 local headers = {
    ["Host"] = "plapi.cdnvideohub.com",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


     
 local x = http.getz('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, headers)
 
-- x = string.gsub(x, '\\u0026', '&')
  -- x = string.gsub(x, '\\u002B', '+')
  
 local slist = string.match(x, '"sources"(.-)}')
 

   slist = string.gsub(slist, 'mpegFullHdUrl', '1080p')
   
   slist = string.gsub(slist, 'mpegHighUrl', '720p')
   
slist = string.gsub(slist, 'mpegMediumUrl', '480p')

slist = string.gsub(slist, 'mpegLowUrl', '360p')
   
   
   
   
    
    if slist then
    
    for title, url in string.gmatch(slist, '"(1080p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url})
 end
 
 for title, url in string.gmatch(slist, '"(720p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url})
 end
 
for title, url in string.gmatch(slist, '"(480p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url})
 end
 
 
for title, url in string.gmatch(slist, '"(360p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url})
 end
 
 end
 end
 end
 
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 local slist = string.match(x, '"isSerial":true(.-)trailers')
 
 if slist then
 
 

 for id, total, total1, season, episode in string.gmatch(slist, '"vkId":"(.-)".-"voiceStudio":"(.-)".-"voiceType":"(.-)".-"season":(.-),.-episode":(%d+)}') do
 
 t['view'] = 'simple'
 
 table.insert(t, {title = 'Сезон :' .. season .. ' серия : ' .. episode  .. ' '.. total .. ' ' .. total1,  mrl = '#stream/q=videohubm&id=' .. id})
 end
 end
 


elseif args.q == 'videohubm' then
 
 local headers = {
    ["Host"] = "plapi.cdnvideohub.com",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


     
 local x = http.getz('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. args.id, headers)
 
-- x = string.gsub(x, '\\u0026', '&')
  -- x = string.gsub(x, '\\u002B', '+')
  
 local slist = string.match(x, '"sources"(.-)}')
 

   slist = string.gsub(slist, 'mpegFullHdUrl', '1080p')
   
   slist = string.gsub(slist, 'mpegHighUrl', '720p')
   
slist = string.gsub(slist, 'mpegMediumUrl', '480p')

slist = string.gsub(slist, 'mpegLowUrl', '360p')
   
   
   
   
    
    if slist then
    
    for title, url in string.gmatch(slist, '"(1080p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = title, mrl = url})
 end
 
 for title, url in string.gmatch(slist, '"(720p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = title, mrl = url})
 end
 
for title, url in string.gmatch(slist, '"(480p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = title, mrl = url})
 end
 
 
for title, url in string.gmatch(slist, '"(360p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'simple'
 
table.insert(t, {title = title, mrl = url})
 end
 
 end
 
 
     
    elseif args.q == 'cdnvideohub' then
    
 
 
-- https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=386
 
-- local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3, mrl = 'https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3})
 
-- "titleName":"Чужой","isSerial":false,"items"

--"vkId":"7554357484052","voiceStudio":"","voiceType":""}

-- "vkId":"11917742136012","voiceStudio":"Jaskier","voiceType":"Многоголосый"
 
-- for title in string.gmatch(x, '"titleName":"(.-)","isSerial":false') do
 
-- for id, total, total1 in string.gmatch(x, '"vkId":"(.-)","voiceStudio":"(.-)","voiceType":"(.-)"') do
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = '#stream/q=cdnvideohubm&id=' .. id})
 
-- end
 --end
 
 
 

     
-- https://plapi.cdnvideohub.com/api/v1/player/sv/video/11917742136012
 
 --table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id})
 
-- end
-- end
 
 
 
  local x = conn:load('https://lam.maxvol.pro/lite/cdnvideohub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)





for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url = string.gsub(url, '\\u0026', '&')
   url = string.gsub(url, '\\u002B', '+')
  
  local x = conn:load(url)
  
  
  for  url1 in string.gmatch(x, '"method":"play","url":".-(/proxy.-)"') do
  
  url1 = string.gsub(url1, '\\u0026', '&')
  url1 = string.gsub(url1, '\\u002B', '+')
  
  
url1 = string.gsub(url1, '^(.-)', 'https://lam.maxvol.pro')


t['view'] = 'simple'

  table.insert(t, {title = total, mrl = url1})

end
end
  
  
  for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')
    url5 = string.gsub(url5, '\\u002B', '+')
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end

elseif args.q == 'cdnvideohubm' then
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. args.id)
 
 local slist = string.match(x, '"sources"(.-)}')
    
    if slist then
    
     for total1, url2 in string.gmatch(slist, '"(.-Url)":"(http.-)"') do



  url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = string.gsub(url2, '\\u002B', '+')  
     
     url2 = string.gsub(url2, 'GECKO', 'CHROME_ANDROID')
     

     
      t['view'] = 'simple'

   table.insert(t, {title = url2, mrl = url2})
    end
    end
    
--  https://vd299.okcdn.ru/?expires=1768797038930&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=5&sig=oiqy4nM5q6Y&ct=0&urls=185.226.55.24&clientType=46&zs=41&id=10216803469855
   
 -- https://vd299.okcdn.ru/?expires=1768798368123&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=5&sig=blL2z7YgIDE&ct=0&urls=45.136.22.28&clientType=46&zs=41&id=10216803469855
   
   
    
  --https://vd299.okcdn.ru/?expires=1768798513604&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=2&sig=CKjpvCr3_h0&ct=0&urls=45.136.22.28&clientType=46&zs=41&id=10216803469855
 
 
 --http://vd299.okcdn.ru/?expires=1768797559897&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=5&sig=k-en2-mOVts&ct=0&urls=45.136.22.28&clientType=46&zs=41&id=10216803469855
  
 -- http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=386&box_mac=acace24b8434
  
  
  --http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&stream=11634d91da3c2975c8557c6890fe6a&audio=0&box_mac=acace24b8434
    
    
    
  elseif args.q == 'alloha' then
 
 local data = 'http://kb-team.club/msx/msxFork.php?plugin=' .. base64_encode('plugin&bid=alloha-aloha&act=view&id=' .. args.id3) .. '&device=acace24b8434'
 
 --http://kb-team.club/msx/msxFork.php?plugin=cGx1Z2luJmJpZD1hbGxvaGEtYWxvaGEmYWN0PXZpZXcmaWQ9Mzg2&device=acace24b8434
 
 
 
    local x = conn:load(data)

--table.insert(t,{title = data,mrl = data})
    
    if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 
 
    local x = string.match(x,'"label":".-Просмотр"(.-)]') 
    
    for total, url in string.gmatch(x, '{"label":"(.-)".-"action".-content.-(http.-)"') do
  
  url = string.gsub(url, '\\', '') 
     
  
       local x = conn:load(url)
   
  -- table.insert(t,{title= url,mrl = url})
    
    
   
   for total1, url1 in string.gmatch(x, '"playerLabel":"(.-)".-video.-(http.-)"') do
   
   url1 = string.gsub(url1, '\\', '') 
   url1 = urldecode(url1)
   
  
  t['view'] = 'simple'
  
     table.insert(t,{title= tolazy(total) .. ' ' .. '(' .. total1 .. 'p)',mrl = url1})
    
    end
    end
end
    

local x = conn:load(data)

--table.insert(t,{title = data,mrl = data})



for title, url2 in string.gmatch(x,'{"label":"\\u0421.-(%d+)",.-action".-content.-(http.-)"') do
      
      url2 = string.gsub(url2, '\\', '')
  
  
      
   local x = conn:load(url2)
  
   
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')

--Выберите Сезон и Серию

--local x = string.match(x,'Выберите Сезон и Серию(.-)]') 

for title1, url3 in string.gmatch(x,'label":"(.-)".-"action".-content.-http.-plugin=(.-)&') do

   
url3 = string.gsub(url3, '\\', '')

t['view'] = 'simple'

table.insert(t, {title = 'сезон ' .. title .. ' ' .. tolazy(title1), mrl = '#stream/q=allohaz&id=' .. url3})

   end
  end
   
       
  elseif args.q == 'allohaz' then
 
   
  local x = conn:load('http://kb-team.club/msx/msxFork.php?view&plugin=' .. args.id .. '&device=acace24b8434')
  
--local x = conn:load(url3)
  
  for title2, url4 in string.gmatch(x,'"playerLabel":".-(%d+)".-video.-(http.-)",') do
  url4 = string.gsub(url4, '\\', '')
        
   local x = conn:load(url4)

 
    for url5 in string.gmatch(x,'url.-(http.-)"') do 
   
url5 = string.gsub(url5, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = ' серия ' .. title2, mrl = url5})

      end 
      end
    
    
    
    
  elseif args.q == 'alloha1' then
 
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=' .. args.id3 .. '&box_mac=acace24b8434')

    
    
  
    --   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, id1, id2, id3, id4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA.-&stream=(.-)&season=(.-)&translate=(.-)&ta=(.-)]]') do
  
  
  t['view'] = 'simple'
  
    
    table.insert(t,{title= tolazy(total) .. ' ' .. tolazy(total1),mrl = '#stream/q=allohas&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
    
    end
    end

    



    

local x = conn:load('https://evkh.lol/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do


url4 = string.gsub(url4, '\\u002B', '+') 
     
      url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do

url5 = string.gsub(url5, '\\u002B', '+') 


      url5 = string.gsub(url5, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end




elseif args.q == 'allohas' then
    
    
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&stream=' .. args.id1 .. '&season=' .. args.id2 .. '&translate=' .. args.id3 .. '&ta=' .. args.id4 .. '&box_mac=acace24b8434')
  
  

  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
    t['view'] = 'simple'
				table.insert(t,{title= tolazy(total3) .. ' ' .. (total2),mrl = url5})
			end
          end
    
    



--http://78.40.199.67:10630/proxy/O3hSoc5CijVra2vCgfLNLB/PmRc+hqhKQgIOtzJlZSEN/U78WLhH33d7PTzmOoNEDwNxZZPw/cCL2DPw8vwZ+AtWC4MYaTNCqweYtblqcNLYD84RO+a9J2fQBoSstZ6c38UCxMq/hdkhO3eN06Bby6mor91qcMJXtoj7oQMvQb4LCGTqcuao/k4kE+O4e5YUbcSaRf6wbvMr+xw/pxPJLRjH3XBJVkyFY+94Tn8pggp22Td/Cka0vh7ih0qoejU+TjFZIFz8s/7BYVPvw5Tv8b+OOh3cAe7fQCrhzls/hqQ=.mp4
  

elseif args.q == 'cdnmovies' then
      
      local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?kinopoisk_id=' .. args.id3)


 local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630')
    
    

      local x = conn:load(url2)

     
      for id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-&kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=cdnmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})
  
  
  end
  end


 
     elseif args.q == 'cdnmoviess' then
 
 
     local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?' .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end





--https://lamp-movie.ru
    
    elseif args.q == 'vdbmovies' then
      
      local x = conn:load('https://lam.maxvol.pro/lite/vdbmovies?kinopoisk_id=' .. args.id3)


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    
    

      local x = conn:load(url2)

     
      for id4, id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"(http.-)&.-kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=vdbmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
  
  
  end
  end


 
     elseif args.q == 'vdbmoviess' then
 
 
     local x = conn:load(args.id4 .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


--https://lam.akter-black.com/lite/hdvb?imdb_id=tt29927663

--http://93.183.95.219:11378

elseif args.q == 'hdvb' then
      
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

      for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"http.-(vid.-)(/movie.-)"') do
      
      
if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Referer"] = "https://" .. origin .. "/",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)


local id, key = string.match(x, '"file":"%~(.-)".-"key":"(.-)"')

local href = string.match(x, '"href":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'



local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)

         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. title, mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. title, mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. title, mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. title, mrl = url3})

       end
       end
 end
 end
     
    
    
    
    
    
     
     local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
     
    -- table.insert(t, {title = 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3, mrl = '#stream/q=hdvbs&id1=' .. 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3})
     
     
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

     
     
     
  --   table.insert(t, {title = url, mrl = '#stream/q=hdvbs&id1=' .. url})
     
   
    --  for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') do
      
      local origin, url = string.match(x, '"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') 

if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Referer"] = "https://" .. origin .. "/",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=177873309816283985; _ym_d=1778733098; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)

x = string.gsub(x, '\\', '')

local id, key = string.match(x, '"file":"(.-)".-"key":"(.-)"')

if id then
if key then


local href = string.match(x, '"href":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.' .. href)

local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')







for id1, text in string.gmatch(x, '"file":"%~(.-)".-"text2":"(.-)"') do

--local text = string.match(x, '"file".-"text2":"(.-)"')


id1 = string.gsub(id1, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'


local x = http.postz(id1, headers1)



for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. text, mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. text, mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. text, mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. text, mrl = url3})

       end
     
end
     
end
end
end
end
    
  
 
 
elseif args.q == 'hdvbf' then
      
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

      for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"http.-(vid.-)(/movie.-)"') do
      
if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

-- https://lam.maxvol.pro/proxy/5ae371e16655f3ef2bae8d4a28d56b8d.m3u8

-- http://78.40.195.218:9118/lite/hdvb/serial?iframe=https%3a%2f%2fvid1733431681.entouaedon.com%2fserial%2f4e6eb80724f81b2fc89bf9c3f8507021e1f9a9dba4c9d493288c81a9f86943a3%2fiframe&t=BaibaKo&s=1&e=1
 
      url = string.gsub(url, '^(.-)', 'https://lam.maxvol.pro/lite/hdvb/video?iframe=' .. 'https://' .. origin)

--table.insert(t, {title = url, mrl = url})

local x = http.getz(url)


x = string.gsub(x, '\\', '')


local url2 = string.match(x,'method.-"play".-"url":"http.-(/proxy.-m3u8)"')
   
 
  
   local x = conn:load('https://lam.maxvol.pro' .. url2)

 
   x = string.gsub(x, '\\', '')
   

 
         for url3 in string.gmatch(x, 'RESOLUTION.-640.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. title, mrl = url3})

       end
       
         for url3 in string.gmatch(x, 'RESOLUTION.-858.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. title, mrl = url3})

      
       end
        for url3 in string.gmatch(x, 'RESOLUTION.-1280.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
		 
t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. title, mrl = url3})


       end
       
for url3 in string.gmatch(x, 'RESOLUTION.-1920.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. title, mrl = url3})


       end
       end
     
  end
  end
    
    
    
    
    
     
     local x = conn:load('http://78.40.195.218:9118/lite/hdvb?kinopoisk_id=' .. args.id3)
     
     
  --   table.insert(t, {title = url, mrl = '#stream/q=hdvbs&id1=' .. url})
     
  -- table.insert(t, {title = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3, mrl = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3})


for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url2 = string.gsub(url2, '\\u0026', '&')
url2 = string.gsub(url2, '\\u002B', '+')


     local x = conn:load('http://78.40.195.218:9118' .. url2)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     
     local x = conn:load('http://78.40.195.218:9118' .. url4)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"http.-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do




     url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
    
       t['view'] = 'simple'

    table.insert(t, {title = total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = 'http://78.40.195.218:9118' .. url6})
    end
end
end


 
 
  
  
 
 
elseif args.q == 'zagonka' then
 


--args.id1 = string.gsub(args.id1, ':', '') 
args.id1 = string.gsub(args.id1, ' ', '%%20') 
		
 -- args.id1 = urlencode(args.id1)
 
-- args.id1 = string.gsub(args.id1, '+', '%%20') 
   
       local url = 'http://abc.zagonkop.gb.net/engine/ajax/xsearch/f.php?q=' .. args.id1
       --.. '%%20' .. args.id2

--table.insert(t, {title = url, mrl = url})	

local headers = {    
      ["host"] = "abc.zagonkop.gb.net",
      ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0",
       ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive"
}



local x = http.getz(url, headers)


local x = json.decode(x)

		for _, v in ipairs(x) do
		--	local url = 'http://rutube.ru/video/' .. v['id'] .. '/'
	
	t['view'] = 'simple'
	
	table.insert(t, {title = v['text'], mrl = '#stream/q=zagonkaz&id1=' .. v['id'] .. '&id=' .. v['url']})

end






--for ids, urls in string.gmatch(x, '{"id":"(.-)".-url.-(/.-)"') do

--{"id":"(.-)","text":"(.-)","url":"\/135628-ubivat-nado-vovremja-1998-onlayn.html"

--local ids, urls = string.match(x, '{"id":"(.-)".-url.-(/.-)"')

--urls = string.gsub(urls, '^(.-)', 'http://abc.zagonkop.gb.net') 

 
--t['view'] = 'simple'

--table.insert(t, {title = urldecode(args.id1) .. '(' .. args.id2 .. ')', mrl = '#stream/q=zagonkaz&id=' .. urls .. '&id1=' .. ids .. '&id2=' .. args.id2})

--end


elseif args.q == 'zagonkaz' then

  local url1 = 'http://abc.zagonkop.gb.net/embed/' .. args.id1


--http://abc.zagonkop.gb.net/embed/kp-5499518


local headersz = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = 'http://abc.zagonkop.gb.net' .. args.id,
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}



  local x = http.getz(url1, headersz)


--local id = string.match(x, 'data%-id="(.-)"')

--table.insert(t, {title = id, mrl = id})


x = string.gsub(x, 'ZYzNM', '')
        x = string.gsub(x, 'ZUzls', '')
x = string.gsub(x, 'ZUzVw', '')

x = string.gsub(x, 'ZUTB5', '')

x = string.gsub(x, 'ZaTdV', '')


local x = string.match(x, 'Playerjs%(\'#2(.-)\'%)+') 
   
  if x then      
    
    
    x = base64_decode(x)
     
 x = string.gsub(x, '{v1}', '.mp4')   

 
 
 for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')
 
 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(1080p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/720.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(720p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(480p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/360.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(360p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end
 
for tr, voise in string.gmatch(x, 'class=\'in_tr\'>(.-)<br>.-folder(.-)}]') do

for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
  end
end

for tr, voise in string.gmatch(x, 'class=\'in_tr\'>(.-)<br>.-folder(.-)}]') do

for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do


 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
 end 
 end



for voise in string.gmatch(x, '<div id=\'_not\'.-folder(.-)}]') do


for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия', mrl = url3})
  
  end
end


for voise in string.gmatch(x, '<div id=\'_not\'.-folder(.-)}]') do


for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

 table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия', mrl = url3})
  
  end
end



 
 end
  

 
 
 
 
 
 elseif args.q == 'kinobadi' then
 
 local x = http.get('https://kinobadi.in/player/player.php?kp_id=' .. args.id3)
 
 --table.insert(t, {title = 'https://kinobadi.in/player/player.php?kp_id=' .. args.id3, mrl = 'https://kinobadi.in/player/player.php?kp_id=' .. args.id3})
 

 x = string.gsub(x, '&quot;', '"')
 
 
 local movie = string.match(x,'<div class=.-dl%-player.-data%-sources.-movie.-voices.-:%[(.-)]')
 
-- table.insert(t, {title = movie, mrl = movie})
 
 if movie then
 
 --movie = urldecode(movie)
 
 for name, qual in string.gmatch(movie,'{"name":"(.-)".-"qualities":{(.-)}') do
 
 for total, url in string.gmatch(qual,'"(%d+p)":"(.-)"') do
 
 t['view'] = 'simple'
 
 table.insert(t, {title = total .. ' ' .. name, mrl = url})

 end
 
 
  for url1 in string.gmatch(qual,'"240p":"(.-)"') do
 
 url1 = string.gsub(url1, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 t['view'] = 'simple'

 
  table.insert(t, {title = '1080p' .. ' ' .. name, mrl = url1})

      end 
 end
 end
 
 
 
 local series = string.match(x,'<div class=.-dl%-player.-data%-sources.-series.-"seasons":%[(.-)]}"')


if series then

--table.insert(t, {title = series, mrl = series})
 
 for season, voices in string.gmatch(series,'{"num":(.-),"voices":%[(.-)]}]') do
 
 --table.insert(t, {title = voices, mrl = voices})
 
 
 for name, episodes in string.gmatch(voices,'{"name":"(.-)","episodes":%[(.-)]') do
 
 --table.insert(t, {title = voices, mrl = voices})
 
 
 
 for episode, qual in string.gmatch(episodes,'{"num":(.-),"qualities":{(.-)}') do

for total, url in string.gmatch(qual,'"(%d+p)":"(.-)"') do
 

 
 t['view'] = 'simple'

 
 table.insert(t, {title = '(' .. total .. ')' .. ' Сезон: ' .. season .. ' серия: ' .. episode .. ' ' .. name, mrl = url})

      end 
end
end
end
end 
 
 
 
 
 
 
     
elseif args.q == 'turbo' then

--https://proxy4.rte.net.ru/


--https://go.zet-flix.online/iplayer/player.php?id=JTJGaXBsYXllciUyRnZpZGVvZGIucGhwJTNGa3AlM0QzODY=

local url = 'https://54243ba5.obrut.show/embed/AO/kinopoisk/' .. args.id3 .. '/'


local headers = {
    ["Host"] = "54243ba5.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cookie"] = "wd_trust=AAAAAGnw-KMyM0U0OTMyRQFSZP9Ll3IMgg; XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}







local x = http.getz(url, headers)




--url = url_for(x)

--url = urldecode(url)


x = string.gsub(x, '//ci9yL3I=', '')
 
x = string.gsub(x, '//by9vL28=', '')
 
x = string.gsub(x, '//dC90L3Q=', '')
 
x = string.gsub(x, '//Yi9iL2I=', '')

x = string.gsub(x, '//dS91L3U=', '')
	
					


local slist = string.match(x, 'new.-Player.-(eyJsYW5.-\"+)')
 
 
 if slist then
 
 slist = base64_decode(slist)
 
slist = string.gsub(slist, '\\u0410', 'А')
      slist = string.gsub(slist, '\\u0430', 'а')
      slist = string.gsub(slist, '\\u0411', 'Б')
       slist = string.gsub(slist, '\\u0431', 'б')
       slist = string.gsub(slist, '\\u0412', 'В')
      slist = string.gsub(slist, '\\u0432', 'в')
       slist = string.gsub(slist, '\\u0413', 'Г')
       slist = string.gsub(slist, '\\u0433', 'г')      slist = string.gsub(slist, '\\u0414', 'Д')
      slist = string.gsub(slist, '\\u0434', 'д')
       slist = string.gsub(slist, '\\u0415', 'Е')
       slist = string.gsub(slist, '\\u0435', 'е')      slist = string.gsub(slist, '\\u0401', 'Ё')
      slist = string.gsub(slist, '\\u0451', 'ё')
       slist = string.gsub(slist, '\\u0416', 'Ж')
       slist = string.gsub(slist, '\\u0436', 'ж')
       slist = string.gsub(slist, '\\u0417', 'З')
      slist = string.gsub(slist, '\\u0437', 'з')
       slist = string.gsub(slist, '\\u0418', 'И')
       slist = string.gsub(slist, '\\u0438', 'и')     slist = string.gsub(slist, '\\u0419', 'Й')
      slist = string.gsub(slist, '\\u0439', 'й')
       slist = string.gsub(slist, '\\u041a', 'К')
       slist = string.gsub(slist, '\\u043a', 'к')
       slist = string.gsub(slist, '\\u041b', 'Л')
       slist = string.gsub(slist, '\\u043b', 'л')
       slist = string.gsub(slist, '\\u041c', 'М')
       slist = string.gsub(slist, '\\u043c', 'м')
       slist = string.gsub(slist, '\\u041d', 'Н')
       slist = string.gsub(slist, '\\u043d', 'н')
       slist = string.gsub(slist, '\\u041e', 'О')
       slist = string.gsub(slist, '\\u043e', 'о')
       slist = string.gsub(slist, '\\u041f', 'П')
       slist = string.gsub(slist, '\\u043f', 'п')
    slist = string.gsub(slist, '\\u0420', 'Р')
    slist = string.gsub(slist, '\\u0440', 'р')
    slist = string.gsub(slist, '\\u0421', 'С')
    slist = string.gsub(slist, '\\u0441', 'с')
    slist = string.gsub(slist, '\\u0422', 'Т')
    slist = string.gsub(slist, '\\u0442', 'т')
    slist = string.gsub(slist, '\\u0423', 'У')
    slist = string.gsub(slist, '\\u0443', 'у')
    slist = string.gsub(slist, '\\u0424', 'Ф')
    slist = string.gsub(slist, '\\u0444', 'ф')
    slist = string.gsub(slist, '\\u0425', 'Х')
    slist = string.gsub(slist, '\\u0445', 'х')
    slist = string.gsub(slist, '\\u0426', 'Ц')
    slist = string.gsub(slist, '\\u0446', 'ц')
    slist = string.gsub(slist, '\\u0427', 'Ч')
    slist = string.gsub(slist, '\\u0447', 'ч')
    slist = string.gsub(slist, '\\u0428', 'Ш')
    slist = string.gsub(slist, '\\u0448', 'ш')
    slist = string.gsub(slist, '\\u0429', 'Щ')
    slist = string.gsub(slist, '\\u0449', 'щ')
    slist = string.gsub(slist, '\\u042a', 'Ъ')
    slist = string.gsub(slist, '\\u044a', 'ъ')
    slist = string.gsub(slist, '\\u042b', 'Ы')
    slist = string.gsub(slist, '\\u044b', 'ы')
    slist = string.gsub(slist, '\\u042c', 'Ь')
    slist = string.gsub(slist, '\\u044c', 'ь')
    slist = string.gsub(slist, '\\u042d', 'Э')
    slist = string.gsub(slist, '\\u044d', 'э')
    slist = string.gsub(slist, '\\u042e', 'Ю')
    slist = string.gsub(slist, '\\u044e', 'ю')
    slist = string.gsub(slist, '\\u042f', 'Я')
    slist = string.gsub(slist, '\\u044f', 'я')
    slist = string.gsub(slist, '\\u00ab', '<<')
    slist = string.gsub(slist, '\\u00bb', '>>')
    slist = string.gsub(slist, '\\u2014', '-')
 
 
 for title, title1, qual in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-"file":"(.-)"') do

for total, url1 in string.gmatch(qual, '%[(%d+p)](http.-),') do


 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

title = string.gsub(title, 'Season [%d+]', '')
title = string.gsub(title, 'Episode [%d+]', '')



title = string.gsub(title, '","folder":%[{"title":"', '')


 t['view'] = 'simple'
 
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=turbovideo&id=' .. url1})
 
 end
 end 
 end

elseif args.q == 'turbovideo' then
  
  local headers = {
    ["Host"] = "54243ba5.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cookie"] = "wd_trust=AAAAAGnw-KMyM0U0OTMyRQFSZP9Ll3IMgg; XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}
  
  
  
 local x = http.getz(args.id, headers)
 
 --if x then
 

local url = string.match(x,'<meta http%-equiv="refresh".-url=.-(http.-m3u8)')
  
 -- for url in string.gmatch(x,'<meta http%-equiv="refresh".-url=.-(http.-m3u8)') do
  
-- table.insert(t, {title = 'Смотреть', mrl = url})
  if url then
    print(url)
    return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}
 end

  
 
 
 
 
 
 elseif args.q == 'videodb1' then
  
  
    local x = conn:load('https://proxy4.rte.net.ru/http://31.129.234.181/lite/zetflixdb?kinopoisk_id=' .. args.id3 .. '&uid=guest')
   

   
   for  url2, total in string.gmatch(x, '"method".-"url":.-(http.-)".-class="videos__item%-title">(.-)<') do
 

      url2 = string.gsub(url2, '\\u0026', '&') 
     
     
      t['view'] = 'simple'
    

 
    table.insert(t, {title = tolazy(total), mrl = url2})

      end 
    

      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
      
    
      url2 = string.gsub(url2, '\\u0026', '&') 
 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

    
      url3 = string.gsub(url3, '\\u0026', '&') 

       local x = http.getz(url3 .. '&uid=guest')

   
      for  url4, total2 in string.gmatch(x, '"method":"play".-"url".-(http.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    
      url4 = string.gsub(url4, '\\u0026', '&') 

      t['view'] = 'simple'
 
 
   --  table.insert(t, {title = url4, mrl = url4})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4})

     end
     end
    end
 
 
 
 
  elseif args.q == 'videodb' then
  
  
 local x = conn:load('https://x.vmestefilms.online/api/kinopoisk/?kp_id=' .. args.id3)
  
     local total = string.match(x, '"slug":.-"(.-)",')
  if total then
  
  local id = string.match(x, '"TURBO".-"id": (.-)}')

if id then
  
    local x = conn:load('http://78.40.195.218:9118/lite/videodb?rjson=False&href=https://x.vmestefilms.online/room/' .. id .. '/' .. total .. '/')
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-http.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://78.40.195.218:9118')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
    url2 = string.gsub(url2, '^(.-)', 'http://78.40.195.218:9118') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://78.40.195.218:9118') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-http.-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://78.40.195.218:9118')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
end
end


  
    elseif args.q == 'videodb1' then
    
    local x = conn:load('https://lam.maxvol.pro/lite/videodb?kinopoisk_id=' .. args.id3)
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(http.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
   --  url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
    -- url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

    --  url3 = string.gsub(url3, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(http.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
   -- url4 = string.gsub(url4, '^(.-)', 'http://lam.maxvol.pro')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end


   elseif args.q == 'videocdn' then
 
 
 
 
local x = conn:load('http://kb-team.club/msx/kinozal/videocdn.php?act=watch&vid=' .. args.id3 .. '&device=') 


if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 
 

 
 for title, url1 in string.gmatch(x,'"playerLabel":"(.-)".-video.-(http.-)"') do



url1 = string.gsub(url1, '\\', '')

 t['view'] = 'simple'

   table.insert(t, {title = title, mrl = url1})

      end 
 
      
      
     for url2 in string.gmatch(x,'"label".-"action":"panel.-(http.-)"') do
      
      url2 = string.gsub(url2, '\\', '')
  
  
      
   local x = conn:load(url2)
  
   
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')


for title1, url3 in string.gmatch(x,'"playerLabel":"(.-)".-"action":"player:show".-"action.-video.-(http.-)"') do


   
url3 = string.gsub(url3, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = tolazy(title1), mrl = url3})

      end 
  
  
  for title2, url3 in string.gmatch(x,'"label":".-uddfa(.-)".-"action":"panel:(http.-)"') do
  url3 = string.gsub(url3, '\\', '')
        
   local x = conn:load(url3)
  
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
  
  
--  table.insert(t, {title = url, mrl = url})
  
 
    for title3, url4 in string.gmatch(x,'"playerLabel":"(.-)".-"action":"player:show".-video.-(http.-)"') do 
   
url4 = string.gsub(url4, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = title2 .. ' ' .. tolazy(title3), mrl = url4})

      end 
      end
   end
     
 end
 
 
 
-- https://lampa.ip917.ru/lite/lumex/video.m3u8?playlist=%2fvalidate%2fU2FsdGVkX1-HWJXR-68d4L5FZ5G8XZbankXomi3bA2NSRN28LPBPtpORtthxOnUsx0Lg3KqSB6Kfg3EJql4hhh7YMO-Pp2SLx9TnO-tBp5myBFbjXKKEuKfrYZ2wVwdb45iSZaB5Cok7fK_Cb4QprlmNkOfV5hLruFWpJtTVIuGIf3Dk65SDRFcyJOHKPXleu07ieysuHAkAZEDcjDZUECF4FIdxBkqkYwP6CPUt4x8&csrf=636ebee3ad5caa58ecd60717b4c38dc7&max_quality=1080&uid=2hlekqiu   
--https://lamp-movie.ru
--http://lam.maxvol.pro
--http://89.110.96.198:12267/lite/lumex?kinopoisk_id=386
    
 --   http://z01.online/lite/vdbmovies?kinopoisk_id=386
    
 --   http://z01.online/lite/lumex?kinopoisk_id=386
 
 --http://z01.online/lite/videocdn?kinopoisk_id=4910542
    
--   local x = conn:load('http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3) 
   local x = conn:load('https://lam.maxvol.pro/lite/lumex?kinopoisk_id=' .. args.id3) 
   
   --.. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3, mrl = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":.-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
      url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

  --   local x = conn:load(url1)
   
 

 
 --    local slist = string.match(x, 'quality(.-)}')
      
--if slist then

--   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

  --  total1 = string.gsub(total1, ',"', '') 
--total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url1})

      end 
--    end

  --  end
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end


   
   
    elseif args.q == 'lumex' then
    
  --  http://lam.maxvol.pro
 --   http://178.20.46.40:12600

--http://lam.maxvol.pro/lite/lumex?kinopoisk_id=4910542

   local x = conn:load('https://lam.maxvol.pro/lite/lumex?kinopoisk_id=' .. args.id3)
   -- https://lam.akter-black.com
    
   --  local x = conn:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
--  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

 --  table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p) ' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
 
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
      
url3 = string.gsub(url3, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p) '.. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '480.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p) ' .. tolazy(total), mrl = url3})
       
    end
    
   local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '360/index')
      url3 = string.gsub(url3, '360.mp4', '360.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '360.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(360p) ' .. tolazy(total), mrl = url3})
       
    end 
    
local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '240/index')
      url3 = string.gsub(url3, '360.mp4', '240.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '240.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(240p) ' .. tolazy(total), mrl = url3})
       
    end
    
    
    
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
       --   url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end
  end
  
  

 elseif args.q == 'lumexs' then
    
     local x = conn:load('https://lam.maxvol.pro/lite/lumex?content_id=' .. args.id1 .. '&kinopoisk_id=' .. args.id2 .. '&clarification=' .. args.id3 .. '&s=' .. args.id4 .. '&t=' .. args.id5)



for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = 'Сезон ' .. args.id4 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end






      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
 
 
 
 local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '1080/index')
      url5 = string.gsub(url5, '360.mp4', '1080.mp4')
      
     url5 = string.gsub(url5, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8') 
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(1080p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
 

     local x = conn:load(url4)
  
  for url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
  
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(720p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
   
   local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '480/index')
      url5 = string.gsub(url5, '360.mp4', '480.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '480.mp4:hls:manifest.m3u8')
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(480p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
  
end

   
   
--   http://178.20.46.40:12600/lite/filmix?title=чужой&year=1979
    
--https://vizhu.top/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
 -- https://lamp-movie.ru/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
  
--http://z01.online/lite/filmix?postid=173202
      
      elseif args.q == 'filmix' then

local x = conn:load('https://api.filmix.tv/api-fx/list?search=' .. urlencode(args.id1) .. '+' .. args.id2)

x = string.gsub(x, '\\', '')



local id = string.match(x,'"id":.-"title":".-".-"year":.-,.-"poster":".-".-url":"https://.-/.-/.-/(.-)%-') 

if id then

local x = conn:load('https://api.filmix.tv/api-fx/post/' .. id .. '/video-links')



x = string.gsub(x, '\\', '')

--x = string.gsub(x, '"http.-.mp4"', '')


local video = string.match(x, '{"season":null(.-)"video"}]')



if video then

local video1 = string.match(video, '"files":%[(.-)"updated"') do

if video1 then

for url, url1, total in string.gmatch(video1,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video1,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
end
end


local video2 = string.match(video, '"files".-"files":%[(.-)"updated"') do

if video2 then


for url, url1, total in string.gmatch(video2,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video2,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end
 
 
local video3 = string.match(video, '"files".-"files".-"files":%[(.-)"updated"') do


if video3 then

for url, url1, total in string.gmatch(video3,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video3,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end
 
 local video4 = string.match(video, '"files".-"files".-"files".-"files":%[(.-)"updated"') do

if video4 then

for url, url1, total in string.gmatch(video4,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video4,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end
 
local video5 = string.match(video, '"files".-"files".-"files".-"files".-"files":%[(.-)"updated"') do

if video5 then

for url, url1, total in string.gmatch(video5,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video5,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end

 
 end




--x = string.gsub(x, '"http.-.mp4"', '')

       for url1, url2, url3, url4, url5, total in string.gmatch(x,'"url":"(http.-/hls/)(.-)(/s%d+)(e%d+)(_.-)".-quality":(.-),') do


			

    title1 = string.gsub(url3, '/s', 'Сезон ')
    title = string.gsub(url4, 'e', 'серия  ')
    
    title2 = string.gsub(url2, '(.-%d)', '')
    
      t['view'] = 'simple'
      
      table.insert(t, {title = '(' .. total .. 'p)' .. title1 .. ' ' .. title .. ' ' .. title2, mrl = url1 .. url2 .. url3 .. url4 .. url5, image = image})
      

      end
	
end



   
    elseif args.q == 'kino4k' then
  
--http://wtch.ch/lite/fxapi
  
  
  
 -- https://akter-black.com/lite/filmix?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn
  
    
    -- local x = conn:load(args.id)
    
    local x = conn:load('https://get-balancer.akter-black.com/lite/fxapi?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
    
	--	local x = conn:load('http://wtch.ch/lite/fxapi?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
 
 
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 

    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
   if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do
--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
    
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end

    
end
end





--https://lamp-movie.ru


--http://178.20.46.40:12600/lite/filmix?title=чужой+1979

elseif args.q == 'kinofit' then

local x = conn:load('http://178.20.46.40:12600/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2)

for id in string.gmatch(x,'<div class="videos__line".-"method":"link".-"url":"http.-postid=(.-)\\u0026') do


id = string.gsub(id, '^(.-)', 'item/')
         
         id=base64_encode(id)
 

 
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')


  
     for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = (total1) .. ' ' .. tolazy(total), mrl = url2})
    
        end
        end
        
  
      




     local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')



      for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
  
       total = string.gsub(total, '<!%[CDATA%[', '')
       total = string.gsub(total, ']]>', '')
       
     local x = conn:load(url1 .. '&box_mac=acace24b8434')

    
    for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-сезон).-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
       total1 = string.gsub(total1, ']]> <![CDATA[', '')
       total1 = string.gsub(total1, ']]>', '')
   
        local x = conn:load(url2 .. '&box_mac=acace24b8434')
   

     
     for total2, total3, url3 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<playlist_url><!%[CDATA%[http.-&goto=(.-)&.-]]') do
    
 --     total2 = string.gsub(total2, '<!%[CDATA%[', '')
   --   total2 = string.gsub(total2, ']]>', '')
 
 
 t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total2) .. ' ' .. tolazy(total), mrl = '#stream/q=kinofits&id=' .. url3})
 
 end
 end
 end
 end
 
 
 elseif args.q == 'kinofits' then

local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. args.id .. '&viewseason' .. '&box_mac=acace24b8434')
 
 
      
  --    local x = conn:load(url3 .. '&box_mac=acace24b8434')
 
     
     
     for total4, url4 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]].-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do
    
       total4 = string.gsub(total4, '<!%[CDATA%[', '')
      total4 = string.gsub(total4, ']]>', '')
    
    
    
      t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total4), mrl = url4})
    
        end
      






elseif args.q == 'voidboost' then


	local url = 'https://rezka.metrpiva.com/info?id=' .. args.id3
		
			local x = conn:load(url)


--table.insert(t, {title = url, mrl = '#stream/q=voidboostm&id=' .. url})

local slist = string.match(x,'"translators".-%[(.-)hasSeasons":false')

if slist then

for id, name in string.gmatch(slist, '{"id":"(.-)","name":"(.-)"') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(name), mrl = '#stream/q=voidboostm&id=' .. id .. '&id3=' .. args.id3})

end
end



local url = 'https://rezka.metrpiva.com/info?id=' .. args.id3
		
			local x = conn:load(url)

--table.insert(t, {title = url, mrl = '#stream/q=voidboostm&id=' .. url})


local slist = string.match(x,'"translators".-%[(.-)hasSeasons":true')

if slist then

for id, name in string.gmatch(slist, '{"id":"(.-)","name":"(.-)"') do

t['view'] = 'simple'

table.insert(t, {title = tolazy(name), mrl = '#stream/q=voidboostn&id=' .. id .. '&id3=' .. args.id3})

end
end


elseif args.q == 'voidboostn' then

local url1 = 'https://rezka.metrpiva.com/episodes?id=' .. args.id3 .. '&translator_id=' .. args.id



local x = conn:load(url1)



local episod = string.match(x,'"episodes".-{(.-)}}')

for seasonid, episodes in string.gmatch(episod,'"(%d+)":%[(.-)]') do


for episodeid, episodename in string.gmatch(episodes,'{"id":(.-),"title":"(Серия.-)"') do

t['view'] = 'simple'


table.insert(t, {title = 'Сезон ' .. seasonid  .. ' ' .. episodename, mrl = '#stream/q=voidboosts&id=' .. args.id .. '&id3=' .. args.id3 .. '&id4=' .. seasonid .. '&id5=' .. episodeid})

end
end



elseif args.q == 'voidboosts' then


--https://rezka.metrpiva.com/episode-stream?id=4308326&translator_id=111&s=1&e=1

local url = 'https://rezka.metrpiva.com/episode-stream?id=' .. args.id3 .. '&translator_id=' .. args.id .. '&s=' .. args.id4 .. '&e=' .. args.id5
		
	local x = conn:load(url)

local slist = string.match(x,'stream(.-)}')

for quel, url1 in string.gmatch(x,'%[(%d+p)](http.-m3u8)') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(quel), mrl = url1})

end

for quel, url1 in string.gmatch(x,'%[(%d+p)]http.-m3u8.-(http.-mp4)') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(quel) .. ' (mp4)', mrl = url1})

end


elseif args.q == 'voidboostm' then



local url = 'https://rezka.metrpiva.com/movie-stream?id=' .. args.id3 .. '&translator_id=' .. args.id
		
	local x = conn:load(url)

local slist = string.match(x,'stream(.-)}')

for quel, url1 in string.gmatch(x,'%[(%d+p)](http.-m3u8)') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(quel), mrl = url1})

end

for quel, url1 in string.gmatch(x,'%[(%d+p)]http.-m3u8.-(http.-mp4)') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(quel) .. ' (mp4)', mrl = url1})

end






elseif args.q == 'hdrezkatest' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=hdrezkatestm&id=' .. id .. '&id1=' .. id1})

end
end



local headersv = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMWEwMmQ5Ny01ZjBjLTdkNzktYWE0Ny1jN2IyMTlhMjhjYzYiLCJleHAiOjE3OTAwNjMzMDMsImlhdCI6MTc4NzQ3MTMwMywibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NzQ3MTI0MywicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImM0N2FlYTAwZTk4ZmE0NDgxYjYzNDNkOGU5MzA3OGNhMDk4NGExNDNkZTAzMzc2Mjk5MGEzMDllODE3Y2EzM2MifQ.o1PwWN46k-3u0CFAeinX6oB6QvP7vP1ClpMucxGxQJpXMWot3xfK9IgnILeZE1l0lew1YlHbwyLZUQlbL5-3Bw; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}




local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do
	--	local x = http.getz('https://kinopub.me' .. args.id, headersv)
		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}
		
		local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headersv, params)			
					

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})




url = url_for('get_movie', {file = x['url'], t = t['name']})


url = urldecode(url)

for quali, url1 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url1})

end
end
	end	
end
   
   
   
 
   
local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=hdrezkatests&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

end
end
end
end
end

local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
--local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')

local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'simple'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=hdrezkatests&id=' .. tid .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

end
end
end
end

end
 


      elseif args.q == 'hdrezkatests' then
   
   
   local headers = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMWEwMmQ5Ny01ZjBjLTdkNzktYWE0Ny1jN2IyMTlhMjhjYzYiLCJleHAiOjE3OTAwNjMzMDMsImlhdCI6MTc4NzQ3MTMwMywibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NzQ3MTI0MywicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImM0N2FlYTAwZTk4ZmE0NDgxYjYzNDNkOGU5MzA3OGNhMDk4NGExNDNkZTAzMzc2Mjk5MGEzMDllODE3Y2EzM2MifQ.o1PwWN46k-3u0CFAeinX6oB6QvP7vP1ClpMucxGxQJpXMWot3xfK9IgnILeZE1l0lew1YlHbwyLZUQlbL5-3Bw; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}
   

					local params = http.encode{
		id = args.id1,
		translator_id = args.id,
		season = args.id2,
		episode = args.id3,
		action = 'get_stream'
					}
					
					local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})


	url = url_for('get_stream', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url3})

end      
   
   
   
    
    	elseif args.q == 'hdrezkatestm' then

local headers = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMWEwMmQ5Ny01ZjBjLTdkNzktYWE0Ny1jN2IyMTlhMjhjYzYiLCJleHAiOjE3OTAwNjMzMDMsImlhdCI6MTc4NzQ3MTMwMywibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NzQ3MTI0MywicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImM0N2FlYTAwZTk4ZmE0NDgxYjYzNDNkOGU5MzA3OGNhMDk4NGExNDNkZTAzMzc2Mjk5MGEzMDllODE3Y2EzM2MifQ.o1PwWN46k-3u0CFAeinX6oB6QvP7vP1ClpMucxGxQJpXMWot3xfK9IgnILeZE1l0lew1YlHbwyLZUQlbL5-3Bw; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}
   
	
					local params = http.encode{
						id = args.id,
						translator_id = args.id1,
						action = 'get_movie'
					}
					
					local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})




local x = json.decode(x)

	url = url_for('get_movie', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url3})

end





elseif args.q == 'fxmlrezka' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=fxmlrezkam&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. url})

end
end


local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}


local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. url .. '&m=1&ep=id%3D' .. id .. '%26translator_id%3D' .. tid .. '%26action%3Dget_movie')


--url = url_for('get_movie', {file = x['url'], t = t['name']})


x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1})

end
end
	end	
end
   



local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=rezkas&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url})

end
end
end
end
end

local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
--local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')

local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'simple'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=fxmlrezkas&id=' .. tid .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url})

end
end
end
end

end
 


      elseif args.q == 'fxmlrezkas' then
   
 
--http://fxmlparsers.in.net/http://www.rezka.ag/?act=https%3A%2F%2Frezka.ag%2Fseries%2Fdrama%2F91279-naslednica-2004.html&tid=59&m=1&ep=id%3D91279%26translator_id%3D59%26season%3D1%26episode%3D31%26action%3Dget_stream  
  
local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id4 .. '&m=1&ep=id%3D' .. args.id1 .. '%26translator_id%3D' .. args.id .. '%26season%3D' .. args.id2 .. '%26episode%3D' .. args.id3 .. '%26action%3Dget_stream')

x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1})

end



elseif args.q == 'fxmlrezkam' then


local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id2 .. '&m=1&ep=id%3D' .. args.id .. '%26translator_id%3D' .. args.id1 .. '%26action%3Dget_movie')

x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1})

end









elseif args.q == 'rezka' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezkam&id=' .. id .. '&id1=' .. id1})

end
end





local headers = {
    ["Host"] = "hdrzk.org",
    ["%{http_code}"] = "max-time 10",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
["Cookie"] = "cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
   ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://hdrzk.org/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}





local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do
	--	local x = http.getz('https://kinopub.me' .. args.id, headersv)
		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}
		
		local x = http.postz('https://hdrzk.org' .. '/ajax/get_cdn_series/', headers, params)			
					

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})




url = url_for('get_movie', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url1 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do


t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url1})

end
end
	end	
end
   
   
   
 
   
local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=rezkas&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url})

end
end
end
end
end

local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
--local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')

local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'simple'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=rezkas&id=' .. tid .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url})

end
end
end
end

end
 


      elseif args.q == 'rezkas' then
   
   
   local headers = {
    ["Host"] = "hdrzk.org",
    ["%{http_code}"] = "max-time 10",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
["Cookie"] = "techaro.lol-anubis-cookie-verification=019f8838-f797-7300-b45c-75710e4cb40c; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMTlmODgzOC1mNzk3LTczMDAtYjQ1Yy03NTcxMGU0Y2I0MGMiLCJleHAiOjE3ODcyODg4OTksImlhdCI6MTc4NDY5Njg5OSwibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NDY5NjgzOSwicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImUzMTEwYTFiZTdkZWZhNGNlYWZkYWFlZjczN2MxMGZmNWRlOWZjZjdiYTRjNmJkZWY3YTdkZDU5YThlYmRjY2EifQ.09wb9nbPOOqztqPGqz6YQP11Tj_capHS-14qndonPH9a4BEA6eCBL8FAr51QysAgck5prBPSvPNntuA0_GqjCA; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
   ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://hdrzk.org/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}



local headerss = {
    ["Host"] = "hdrzk.org",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
   ["Cookie"] = "dle_user_id=2927296; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; dle_newpm=0; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d"
}






					local params = http.encode{
		id = args.id1,
		translator_id = args.id,
		season = args.id2,
		episode = args.id3,
		action = 'get_stream'
					}
					
					local x = http.postz('https://hdrzk.org' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})


	url = url_for('get_stream', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url3})

end      
   
   
local x = conn:load('http://78.40.195.218:9118/lite/pizdatoehd/movie?href=' .. args.id4 .. '&t=' .. args.id .. '&s=' .. args.id2 .. '&e=' .. args.id3)
  
  
local slist = string.match(x,'"quality":{(.-)}')

if slist then

 for qual, url in string.gmatch(slist,'"(%d+p)":".-(/proxy.-)"') do
 
   
url = string.gsub(url, '^(.-)', 'http://78.40.195.218:9118')
   
   
t['view'] = 'simple'

    table.insert(t, {title = tolazy(qual), mrl = url})

     end
 end
 
    
    	elseif args.q == 'rezkam' then

local headers = {
    ["Host"] = "hdrzk.org",
    ["%{http_code}"] = "max-time 10",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
["Cookie"] = "cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
   ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://hdrzk.org/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}




	
					local params = http.encode{
						id = args.id,
						translator_id = args.id1,
						action = 'get_movie'
					}
					
					local x = http.postz('https://hdrzk.org' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})




local x = json.decode(x)


	url = url_for('get_movie', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(quali), mrl = url3})

end






elseif args.q == 'hdrezka' then

  --http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=чужой:+земля-2025&box_mac=acace24b8434

--local url = 'http://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load('https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href=".-//.-(/.-)"') do
   
    local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	
   
   
   
      local x = http.getz(HOME .. url, headers)


          for id, title in string.gmatch(x,'data%-translator_id.-href="(.-)">(.-)</a>') do
     t['view'] = 'simple'
  
  

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
         
         
for title1, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=.-&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=rezkis&id=' .. args.id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
        
end
 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(url)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end

    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    
   end 
    
elseif args.q == 'rezkis' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end

elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end







     elseif args.q == 'rezka222' then

--https://evkh.lol/lite/rhsprem?kinopoisk_id=464475&title=франкенштейн&year=2025



  --   local x = conn:load('http://z01.online/lite/rhsprem?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)


--for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do


--url = string.gsub(url, '\\u0026', '&')
  --  url = string.gsub(url, '\\u002B', '+')
    
     --  t['view'] = 'simple'

--table.insert(t, {title = '(1080p) ' .. total, mrl = url})

   --  end  
	
		local x = conn:load('http://z01.online/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
 -- table.insert(t, {title = 'https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
  
       
    local slist = string.match(x, '"quality"(.-)}')
      
     if slist then
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"(http.-m3u8)"') do
  
    --  url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
     end
  
  
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
       t['view'] = 'simple'
   
      local x = conn:load(url2)

  local slist = string.match(x, '"quality"(.-)}')
      
      
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"(http.-m3u8)"') do
  
   --   url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')' .. total, mrl = url3})

     end  
 end
     




   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rezik&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      



      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rezik' then

   local x = conn:load('http://z01.online/lite/rezka/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
  
--https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=4760854&title=%D0%9A%D0%BE%D1%80%D0%BE%D0%BB%D1%8C+%D0%A2%D0%B0%D0%BB%D1%81%D1%8B&year=2025&serial=1

        elseif args.q == 'kinobase' then

--http://31.129.234.181:80/lite/kinobase?href=film/244146-na-vershine&t=&s=1&uid=guest

   local x = conn:load('https://kinobase.org/search?query=' .. urlencode(args.id1) .. '+' .. args.id2)
   
 for title in string.gmatch(x, '<div class="poster".-<a href="/(.-)"') do
        
   
    url = string.gsub(title, '^(.-)', 'https://lam.akter-black.com/lite/kinobase?href=') .. '&t=&s=1'
    

     local x = conn:load(url .. '&uid=guest')
   

      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
   --   local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(%d+p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com')
     t['view'] = 'simple'

url2 = string.gsub(url2, '\\u002B', '+')

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2})
    end
     end  
  

  
     for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
      local x = conn:load(url)
   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com')
    
       
      local x = conn:load(url2 .. '&uid=guest')

      
      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
    
url3 = string.gsub(url3, '\\u002B', '+')

    
         
    url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')
    
       t['view'] = 'simple'



    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3})

    end   
    end
    end
   
end


   elseif args.q == 'kinotop' then


   
local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=search&search=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&box_mac=acace24b8434')
   
       for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do
 
       local x = conn:load(url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')
  
  
     for total1, url2  in string.gmatch(x, '<channel.-<title><!%[CDATA%[(%d+p)]]></title.-<stream_url><!%[CDATA%[(http.-)]]') do
    
    
     t['view'] = 'simple'
      table.insert(t, {title = total1, mrl = url2})

       end
     end
   

for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[http.-(&media=.-)]]') do


       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=watch' .. url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')


     for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = (total3) .. (total4), mrl = url3})

end
   
   
  for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-сезон)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
        local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = total2 .. (total3) .. (total4), mrl = url3})

end
end
     end
      

elseif args.q == 'jac' then

    

   local x = conn:load('https://lam.akter-black.com/lite/jac?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
   
       t['view'] = 'simple'
    table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     
     


		local x = conn:load('https://lam.akter-black.com/lite/jac?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
  
  
  
  
  
       t['view'] = 'simple'
     table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     


--https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=570402&title=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB&year=2025
     
--  https://lam.maxvol.pro/lite/pidtor/serial/548bae27dca47ab2805465cc12ab1d9a89d15426?tr=
     
     
     
     
     
     elseif args.q == 'result' then
      args.id = args.id:lower() 
      
      local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end
   
   
   
    elseif args.q == 'pidtor' then
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
 -- table.insert(t, {title = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})

      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-?tr=).-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
  


--https://lam.akter-black.com/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=






for url2, title in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')

      local x = conn:load(url2)
    

    
      for url3, total  in string.gmatch(x, '"method":"link".-"url":"http.-/lite/pidtor/serial/(.-)?tr=.-class="videos__item%-title videos__season%-title">(.-)</div>') do


--url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')

     url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'
     table.insert(t, {title = title .. ' ' ..  total,mrl = '#stream/q=result&id=' .. url3,image = image})
     end
     
   end
 
 
 
 
 
 
 elseif args.q == 'jacred' then

local x = conn:load('https://jacred.stream/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
 
--https://jacred.stream/api/v1.0/torrents?search=kp386&limit=2


local x = json.decode(x)

		for _, v in ipairs(x) do
		--	local url = 'http://rutube.ru/video/' .. v['id'] .. '/'
	
	t['view'] = 'simple'
	
	table.insert(t, {title = v['title'], mrl = '#stream/q=jacreds&id=' .. v['magnet']})

end


   

--https://torr1.akter-black.com/stream/Spider-Man%20Brand%20New%20Day%202026%201080p_nnm-club.mkv?link=7c30776fd2af7a74cd56ded216ddf1e0c9d65775&index=1&play
 
 -- https://lam.akter-black.com/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u 
 -- https://ts.maxvol.pro/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u
--  https://tv.alcopa.cc/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u 
  

 
 elseif args.q == 'jacreds' then

  --   args.id = args.id:lower() 

local x = conn:load('https://torr1.akter-black.com/stream?link=' .. urlencode(args.id) .. '&m3u')
 
-- table.insert(t, {title = x, mrl = x, image = image})
 
 for title, url in string.gmatch(x,'EXTINF:.-,(.-)\n(http.-)\n') do
 
-- url = urldecode(url)
 t['view'] = 'simple'
 
table.insert(t, {title = title, mrl = url})
   
-- table.insert(t, {title = title, mrl = 'https://torr1.akter-black.com/stream' .. url})
		end
 
 
 
 
 elseif args.q == 'torrs' then

local x = conn:load('http://torrs.ru/search?query=' .. urlencode(args.id1) .. '(' .. args.id2 .. ')')
   
 --  table.insert(t, {title = 'http://torrs.ru/search?query=' .. urldecode(args.id) .. '(' .. args.id1 .. ')', mrl = '#stream/q=result&id=' .. 'http://torrs.ru/search?query=' .. urldecode(args.id) .. '(' .. args.id1 .. ')', image = image})
   
	--	local x = conn:load(url)
		x = string.gsub(x, '",', '\\u0026')	
    --    x = string.gsub(x, '&', '\\u0026')	
		
    for title, total in string.gmatch(x,'"size".-"title":"(.-)\\u0026.-"magnet":"magnet:?.-btih:(.-)\\u0026') do
      
--title = string.gsub(title, '\\u0026','&')
     -- total = string.gsub(total, '\\u0026','&')
   t['view'] = 'simple'
   
   table.insert(t, {title = title, mrl = '#stream/q=results&id=' .. total, image = image})
		end


elseif args.q == 'results' then
		
      args.id = args.id:lower() 

local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      
      
      
      
      
      --	 https://lam.akter-black.com/lite/pidtor/serial/7d2dd45792a2695ff0cc88cde4af51cd5189dfb4?tr=	
--https://lam.akter-black.com/lite/jac?serial=1&title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%20%D0%B7%D0%B5%D0%BC%D0%BB%D1%8F


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   end
 
 
 
 
 
 
      elseif args.q == 'awmzone' then

--https://lampa.plus



local headers = {
    ["Host"] = "lampa.plus",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6IkRHakdrTGkySDVEaVNRWE1hOUdCWEE9PSIsInZhbHVlIjoid1VGNlpvRGt0N3dENTZXQkxOMllwdHZlMDZzRTlwRDV1aWc5Q2JJUDRhbk1rSzR5dDZuMGhIaS9OSFdQcFhLWHk0ZnBxZDk2R1B6S2hvc2phK29JbSt4TElabGxPdXlPSEgwUEJoQ2daS3BGd0FzdjFPNEFEOERPUVBZZVFxMjkiLCJtYWMiOiIxYjc5YWIxNzk2YzZhODUzMTk3MjA3ODlhMGZlNWFiM2NlNjkzYmVlNzAzZmIwNTcxODFhNmUzZTcyYzBiMDdlIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlFMZEFSVWhwTWpxNUpkSGNCSDdYT1E9PSIsInZhbHVlIjoiNkxHdWhoWE1KOGYyQzBSazZvNldVOGlQb1pta3dOalJtLzBjcktVTFBFTVJCNEwxbXNQUmdPbE9OMHJXejUrdFhmSS9GSk0rOUkzVG8ydHhxU21uRDNzSnh4ekNUeUJGaHV1MGVRUzhFQllzdzVwS3FyRTNQbk1xZXdQd0tpQUYiLCJtYWMiOiI4ZDQ0NjFmMGJmYmJjZDdmOGFhOTUyMzQxYzQzNzAzOGFlZDMwYWQzMjU2NDhhZDM4OTMyYzU4Mzc3YTQ5OTkxIiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none"
}
 
 
  local search = 'https://lampa.plus/mary/spotlight?search=' .. urlencode(args.id1)
  
--  https://lampa.plus/36040688-mumiia.html
  
--  local x = conn:load(search)

local x = http.getz(search, headers)

if x then

local x = json.decode(x)

		for _, v in ipairs(x) do
			local link = 'https://lampa.plus' .. v['link']
			
if link then

local x = conn:load(link)

x = string.gsub(x, '\\', '')

local id, title = string.match(x,'"embedUrl":"http.-embed%-players/(.-)".-<h1.->(.-)<')

if id then

t['view'] = 'simple'

  table.insert(t, {title = title, mrl = '#stream/q=awmzonepl&id=' .. 'https://lampa.plus/embed-player/' .. id})
  
  end
end
end
end







local headers = {
    ["Host"] = "turboserial.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6IkRHakdrTGkySDVEaVNRWE1hOUdCWEE9PSIsInZhbHVlIjoid1VGNlpvRGt0N3dENTZXQkxOMllwdHZlMDZzRTlwRDV1aWc5Q2JJUDRhbk1rSzR5dDZuMGhIaS9OSFdQcFhLWHk0ZnBxZDk2R1B6S2hvc2phK29JbSt4TElabGxPdXlPSEgwUEJoQ2daS3BGd0FzdjFPNEFEOERPUVBZZVFxMjkiLCJtYWMiOiIxYjc5YWIxNzk2YzZhODUzMTk3MjA3ODlhMGZlNWFiM2NlNjkzYmVlNzAzZmIwNTcxODFhNmUzZTcyYzBiMDdlIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlFMZEFSVWhwTWpxNUpkSGNCSDdYT1E9PSIsInZhbHVlIjoiNkxHdWhoWE1KOGYyQzBSazZvNldVOGlQb1pta3dOalJtLzBjcktVTFBFTVJCNEwxbXNQUmdPbE9OMHJXejUrdFhmSS9GSk0rOUkzVG8ydHhxU21uRDNzSnh4ekNUeUJGaHV1MGVRUzhFQllzdzVwS3FyRTNQbk1xZXdQd0tpQUYiLCJtYWMiOiI4ZDQ0NjFmMGJmYmJjZDdmOGFhOTUyMzQxYzQzNzAzOGFlZDMwYWQzMjU2NDhhZDM4OTMyYzU4Mzc3YTQ5OTkxIiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none"
}
 
 
  local search = 'https://turboserial.com/mary/spotlight?search=' .. urlencode(args.id1)
  
  
  
  local x = http.getz(search, headers)

--local x = conn:load(search)

if x then

local x = json.decode(x)

		for _, v in ipairs(x) do
			local link = 'https://turboserial.com' .. v['link']
			
if link then

local x = conn:load(link)



x = string.gsub(x, '\\', '')
 
local id, title = string.match(x,'"embedUrl":"http.-embed%-players/(.-)".-<h1.->(.-)</h1>')

if id then

t['view'] = 'simple'

  table.insert(t, {title = title, mrl = '#stream/q=awmzonepl&id=' .. 'https://turboserial.com/embed-player/' .. id})
  
  end
end
end
end


elseif args.q == 'awmzonepl' then

local url = args.id

local headers = {
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6ImJIZEJtYTVWZWJ0U3N3cHlGKzAxVlE9PSIsInZhbHVlIjoiOVNRNFRPWjZXZmpob01WZk5sSkJGTTNPNk9PN0NaZ2w4dVhIYVpVaklFWURXVFRTTjl5aDA3aE92N2VzMVJZV09HNGhiemNzRUtzcHJ1S1JwWmhIS1RMNTVNejh2RmxzMmZROWdwSDhXc01xTSttV2MyVHBwcmFuczNybTlieXAiLCJtYWMiOiJkOTE3NzUyYzUyNGNhNmVhMDJkMWE2YTZhZDA1NjEzMjA3MWVhNzk1Yjc3YjVmNWY4ZWYyZTc2OWEwNzRhZmVhIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6InVDdE9UWE5lQjJjUVgzbmNPMWZML0E9PSIsInZhbHVlIjoicE04emNaeGJiSXVMQXppNmIva1RjYkcrZ3FDSkZKLzBYbkM3RFczTzBBUkNEUUx2K0tEMjhzUjQ4cXByVE1JZmJNbFRkYnZJbkdmTWVHM2I3RTd6czMzZGN1YVhLVnF5L3Y5cDAwTGNvN1BYNTZYVFBrRW9hU0d4YVh3K21QQnAiLCJtYWMiOiI4MjBiNmJhM2RkNTBjYmY5ZTFlNmU1NTA3N2JkMzNhMDMzZjcxMGFkZTA2OWE5YWZlZjE2NTRhODhhYWZiZjI1IiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
["Priority"] = "u=0, i"
}

 
  local x = conn:load(url)

  
  local slist = string.match(x,'Playerjs.-atob.-&#039;(.-)&#039;%)+')
  
  if slist then
  

  
  slist = base64_decode(slist)
  

local slist1 = string.match(slist,'"file":"#2(.-)\"+')

slist1 = string.gsub(slist1, '\\', '') 

slist1 = string.gsub(slist1, '//', '') 

slist1 = string.gsub(slist1, 'cG9zb3Npa2xvdW4=', '')

slist1 = string.gsub(slist1,'ZHZhZG9sYm9lYmE=', '')

--slist1 = string.gsub(slist1,'Qtn', '')

slist1 = string.gsub(slist1,'YmliYWlib2Jh', '')


slist1 = base64_decode(slist1)

slist1 = urldecode(slist1)


for title, url1, url2, url3 in string.gmatch(slist1,'{(.-)}(http.-)(/movie.-)(/hls.m3u8)') do


local m3u = conn:load(url1 .. url2 .. url3)

if m3u then

m3u = string.gsub(m3u, './', ',./') 

m3u = string.gsub(m3u, 'stream', '/stream') 
 
for qual, url4 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'simple'

table.insert(t, {title = '(' .. tolazy(qual) .. 'p) ' .. tolazy(title), mrl = url1 .. url2 .. url4})
  
  end
end
 end
 
 for season, episode, slist2 in string.gmatch(slist,'{"id":"S(.-)E(.-)".-"file":"#2(.-)\"+') do

slist2 = string.gsub(slist2, '\\', '') 

slist2 = string.gsub(slist2, '//', '') 

slist2 = string.gsub(slist2, 'cG9zb3Npa2xvdW4=', '')

slist2 = string.gsub(slist2,'ZHZhZG9sYm9lYmE=', '')

slist1 = string.gsub(slist1,'YmliYWlib2Jh', '')



slist2 = base64_decode(slist2)

slist2 = urldecode(slist2)
 
 
 for title, url2 in string.gmatch(slist2,'{(.-)}(http.-m3u8)') do


--local m3u = conn:load(url2 .. url3)

--if m3u then

--m3u = string.gsub(m3u, './', ',./') 

--m3u = string.gsub(m3u, 'stream', '/stream') 
 
--for qual, url4 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'simple'

  table.insert(t, {title = 'Сезон ' .. season .. ' Серия ' .. episode .. ' ' .. tolazy(title), mrl = url2})
  
  end
 end
-- end
-- end
    
 end   
       


elseif args.q == 'anwap' then
  
  

  
  local x = conn:load('https://tv.anwap.today/films/search/?slv=' .. urlencode(args.id1) .. '&vid=1&toch=on')

  
local slist=string.match(x, '</form>.-div class="save">По.-id="cn"(.-)"menuniz"')
  

  if slist then
    for url, title, year in string.gmatch(x, '<div class="my_razdel film".-href="(.-)".-alt="(.-)".-class="in year">(.-)<') do

     local x = conn:load('https://tv.anwap.today' .. url)



local slist1=string.match(x,'"file":"#2(.-)"')


slist1 = string.gsub(slist1, '//', '')
        slist1 = string.gsub(slist1, 'WXQ2cmpGZA==', '')
slist1 = string.gsub(slist1, 'RmtpVTdoRw==', '')

slist1 = string.gsub(slist1, 'RXJTdzNBc2k=', '')

slist1 = string.gsub(slist1, 'UlRkM1M2NUZn', '')

    slist1 = base64_decode(slist1)
    
local url1 = string.match(slist1, '(http.-m3u8)') 
   
      t['view'] = 'simple'
        table.insert(t, {title = tolazy(title) .. ' (' .. year .. ')', mrl = url1})
	
		end
		end


local x = conn:load('https://tv.anwap.today/serials/search/?t=on' .. '&word=' .. urlencode(args.id1) .. '&vid=1') 


   local slist=string.match(x, '</form><div class="save">По.-id="cn"(.-)"menuniz"')

	if slist then

       for url, title, year in string.gmatch(slist, '<div class="my_razdel film".-<a href="(.-)".-alt="(.-)".-class="in year">(.-)<') do

    
    local x = conn:load('https://tv.anwap.today' .. url)

       local slist1=string.match(x, '<ul class="tl2">(.-)</ul>')


		if slist1 then
			for url1, title1 in string.gmatch(slist1, '<li><a href="(/serials/s.-)">(.-)<') do
       
       t['view'] = 'simple'
      
       table.insert(t, {title = tolazy(title) .. ' (' .. year .. ') ' .. title1, mrl = '#stream/q=sezond&id=' .. url1})
        
        end
		end
		end	
end


    elseif args.q == 'sezond' then
  
   local x = conn:load('https://tv.anwap.today' .. args.id)

 
 local ser = string.match(x,'<div class="blm".-<a href="(/serials/down/.-)"')
 
 local x = conn:load('https://tv.anwap.today' .. ser)
 
 
   local slist=string.match(x,'"file":"#2(.-)"')

slist = string.gsub(slist, '//', '')
        slist = string.gsub(slist, 'WXQ2cmpGZA==', '')
slist = string.gsub(slist, 'RmtpVTdoRw==', '')

slist = string.gsub(slist, 'RXJTdzNBc2k=', '')

slist = string.gsub(slist, 'UlRkM1M2NUZn', '')

    
    slist = base64_decode(slist)
    
local url1 = string.match(slist,'(http.-txt)') 

  local x = conn:load(url1)

  
  
			for title, url in string.gmatch(x, '"title":"(.-)".-"file":"(http.-m3u8)') do
      

        t['view'] = 'simple'
        table.insert(t, {title = title, mrl = url})
	
		end






elseif args.q == 'collaps' then
  
  
  local x = conn:load('http://31.129.234.181/lite/collaps?kinopoisk_id=' .. args.id3)

for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
    
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})


       
    end

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://31.129.234.181')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end





      local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)
   
   
   for title in string.gmatch(x, '"iframe_url":"http.-/embed/.-/(.-)"') do
   

      

url = string.gsub(title, '^(.-)', 'http://31.129.234.181/lite/collaps?orid=')
     local x = conn:load(url)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

     end  
  

     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/collaps.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://31.129.234.181')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end
end
end





elseif args.q == 'collaps2' then


local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)

 
   local iframe = string.match(x,'"id".-"iframe_url":".-(/embed.-)"')



--https://api.femd.ws/embed/movie/87442?oneSound=WinMedia&sharing=false&host=kinotik.top

local x = conn:load('https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top')

--table.insert(t, {title = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top', mrl = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top'})

x = string.gsub(x, '\\u0026', '&')

    x = string.gsub(x, '\\"', '')


local down = string.match(x,'download:.-"(http.-)"')


local hls = string.match(x,'hls:.-"(http.-)"')


local title = string.match(x,'hls.-audio:.-%["(.-)"') 



if title then

local x = conn:load(hls)

local total = string.match(x, '#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total then

t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title), mrl = down .. '&audio=' .. total})

table.insert(t, {title = '480p ' .. tolazy(title), mrl = down .. '&video=v2&audio=' .. total})

end
end


local title1 = string.match(x,'hls.-audio:.-%[".-".-"(.-)"') 

if title1 then

local x = conn:load(hls)

local total1 = string.match(x, 'm3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total1 then

t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title1), mrl = down .. '&audio=' .. total1})

table.insert(t, {title = '480p ' .. tolazy(title1), mrl = down .. '&video=v2&audio=' .. total1})



end
end




local title2 = string.match(x,'hls:.-audio:.-%[".-".-".-".-"(.-)"') 

if title2 then

local x = conn:load(hls)

local total2 = string.match(x, 'm3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total2 then

t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title2), mrl = down .. '&audio=' .. total2})

table.insert(t, {title = '480p ' .. tolazy(title2), mrl = down .. '&video=v2&audio=' .. total2})


end
end




local title3 = string.match(x,'hls:.-audio:.-%[".-".-".-".-".-".-"(.-)"')

if title3 then

local x = conn:load(hls)

local total3 = string.match(x, 'm3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total3 then

table.insert(t, {title = '720p ' .. tolazy(title3), mrl = down .. '&audio=' .. total3})

table.insert(t, {title = '480p ' .. tolazy(title3), mrl = down .. '&video=v2&audio=' .. total3})


end
end


local title4 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-"(.-)"') 

if title4 then

local x = conn:load(hls)

t['view'] = 'simple'

local total4 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total4 then

table.insert(t, {title = '720p ' .. tolazy(title4), mrl = down .. '&audio=' .. total4})

table.insert(t, {title = '480p ' .. tolazy(title4), mrl = down .. '&video=v2&audio=' .. total4})
 
  end
   end


local title5 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title5 then

local x = conn:load(hls)

t['view'] = 'simple'

local total5 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total5 then

table.insert(t, {title = '720p ' .. tolazy(title5), mrl = down .. '&audio=' .. total5})

table.insert(t, {title = '480p ' .. tolazy(title5), mrl = down .. '&video=v2&audio=' .. total5})

  end
   end


local title6 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title6 then

local x = conn:load(hls)

t['view'] = 'simple'

local total6 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total6 then

table.insert(t, {title = '720p ' .. tolazy(title6), mrl = down .. '&audio=' .. total6})

table.insert(t, {title = '480p ' .. tolazy(title6), mrl = down .. '&video=v2&audio=' .. total6})

  end
   end

local title7 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title7 then

local x = conn:load(hls)

t['view'] = 'simple'

local total7 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total7 then

table.insert(t, {title = '720p ' .. tolazy(title7), mrl = down .. '&audio=' .. total7})

table.insert(t, {title = '480p ' .. tolazy(title7), mrl = down .. '&video=v2&audio=' .. total7})

  end
   end

local title8 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title8 then

local x = conn:load(hls)

t['view'] = 'simple'

local total8 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total8 then

table.insert(t, {title = '720p ' .. tolazy(title8), mrl = down .. '&audio=' .. total8})

table.insert(t, {title = '480p ' .. tolazy(title8), mrl = down .. '&video=v2&audio=' .. total8})

  end
   end
   
local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)

 
   local iframe = string.match(x,'"id".-"iframe_url":".-(/embed.-)"')



--https://api.femd.ws/embed/movie/87442?oneSound=WinMedia&sharing=false&host=kinotik.top

local x = conn:load('https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top')

--table.insert(t, {title = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top', mrl = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top'})

x = string.gsub(x, '\\u0026', '&')

    x = string.gsub(x, '\\"', '')


local season = string.match(x,'seasons:%[(.-)]}]')

if season then

for total, url in string.gmatch(season, '"duration".-"title":"(.-)".-"download":"(http.-)"') do

	
	t['view'] = 'simple'
	
table.insert(t, {title = tolazy(total), mrl = url})

  end
 end
 


elseif args.q == 'collaps-dash' then
  
 

  local x = conn:load('http://178.20.46.40:12600/lite/collaps-dash?kinopoisk_id=' .. args.id3)



   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



elseif args.q == 'kinotochka' then
  
 

--https://kinovibe.vip/embed/8003

 local url = 'https://kinovibe.cc/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3
--https://kinovibe.co/embed/kinopoisk/386/


  
-- local url = 'https://kinovibe.cc/?do=search&mode=advanced&subaction=search&story=' .. urlencode(args.id1)

		
		local x = conn:load(url)
		
       
			x = string.gsub(x, '\\', '')
			
  
 -- https://kinovibe.vip/27131-persi-dzhekson-i-olimpiycy-2-sezon-2025.html
 
 
  
  local url1 = string.match(x,'"url":"(http.-)"')
  
 -- elseif args.q == 'kinotochkav' then
  
  

    local x = conn:load(url1)

local url, url1 = string.match(x, 'Playerjs.-file:"(http.-video_mp4)(.-mp4)')

			
t['view'] = 'simple'

 table.insert(t, {title = 'Смотреть', mrl = url .. url1})



for url in string.gmatch(x, 'Playerjs.-file:"(http.-_480.mp4)') do

			
t['view'] = 'simple'

 table.insert(t, {title = '480p', mrl = url})


url = string.gsub(url, '_480.mp4', '_720.mp4')
			
t['view'] = 'simple'
 
 table.insert(t, {title = '720p', mrl = url})



end
    




 for url in string.gmatch(x, 'Playerjs.-file:"(http.-txt)"') do

   local x = conn:load(url)

--table.insert(t, {title = url, mrl = url})

--x = string.gsub(x, '[480,720]', '')


for total, title, url1 in string.gmatch(x,'"comment":"(.-Серия).-(%[.-])".-"file":"(http.-/s%d+e%d+)%_.-"') do



t['view'] = 'simple'
  
  table.insert(t, {title =  '(' .. '480' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_480.mp4'})


table.insert(t, {title = '(' .. '720' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_720.mp4'})



end




local x = conn:load(url)

  for title, url2, url3, url4 in string.gmatch(x,'"comment":".-(%[.-])".-"file":"(http.-/s)(%d+)e(%d+)%.mp4"') do
  
  t['view'] = 'simple'


table.insert(t, {title = 'Сезон ' .. url3.. ' ' .. 'серия ' .. url4 .. title, mrl = url2 .. url3 .. 'e' .. url4 .. '.mp4'})


end
end





elseif args.q == 'fanserial' then

 
 
--local url = 'https://1fanserials.org/index.php?do=search'
 
 local url = 'https://1fanserials.org/?do=search&subaction=search&story=' .. urlencode(args.id1)

 local headers = {
    ["Host"] = "1fanserials.org",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://1fanserials.org/",
    ["Connection"] = "keep-alive",
    ["Content-Type"] = "application/x-www-form-urlencoded",
["Content-Length"] = "",
    ["Cookie"] = "__ddg8_=1fmsm0vHdmBHUNd2; __ddg10_=1785251191; __ddg9_=185.228.133.239; __ddg1_=yKoRO1EMPs6rMsq5RYxZ; PHPSESSID=1a21b2ffc6e416654a5282bb064269d3; _ym_uid=1785251045348708012; _ym_d=1785251045; _ym_isad=2; _ym_visorc=b; adrfpip=nAbe16msPTPn; _ohmybid_cmf=2; domain_sid=APwDrHvXKAJ6iYZlPJ69p%3A1785251239326; _sltm=8d703f70f587d25c492c5c2b66042230~0; _sltb=0; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0, i"
}
 
 
local params = 'do=search&subaction=search&search_start=0&full_search=1&result_from=1&story=' .. args.id1 .. '&all_word_seach=1&titleonly=3&searchuser=&replyless=0&replylimit=0&searchdate=0&beforeafter=after&sortby=title&resorder=asc&showposts=0&catlist%5B%5D=10'

 
 local x = http.getz(url, headers)
 
 
  
for url in string.gmatch(x,'<h2.-href=.-(http.-html)') do


 
local x = http.getz(url, headers) 
 
 
  local movie = string.match(x,'itemprop="item.-href="/films/"(.-)"post"')
  
  if movie then
                
 for title, total, kp, key in string.gmatch(movie,'<h1.->(.-)</h1>.-Год.-class="field%-text.->(.-)<.-<iframe.-src=.-/movies/(.-)%?key=(.-)"') do

if kp then
if key then

t['view'] = 'simple'

table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=fanserialsm&id=' .. kp .. '&id1=' .. key})

--table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=fanserialsm&id=' .. url .. '&id3=' .. args.id3})
 
 end
 end
 end
end 
end 
 
 
 
local headers = {['X-Requested-With'] = 'XMLHttpRequest'
, ['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3',
['Server'] = 'ddos-guard',
['Connection'] = 'keep-alive',
['Keep-Alive'] = 'timeout=60',
['Set-Cookie'] = '__ddg8_=M1eAeJegjCoESH2r; Domain=.opravar.online; Path=/; Expires=Thu, 05-Mar-2026 17:45:45 GMT',
['Set-Cookie'] = '__ddg10_=1772731545; Domain=.opravar.online; Path=/; Expires=Thu, 05-Mar-2026 17:45:45 GMT',
['Set-Cookie'] = '__ddg9_=185.228.133.239; Domain=.opravar.online; Path=/; Expires=Thu, 05-Mar-2026 17:45:45 GMT',
['Content-Security-Policy'] = 'upgrade-insecure-requests;',
['Set-Cookie'] = '__ddg1_=m8GVy1LFbHMztg4oE7BK; Domain=.opravar.online; HttpOnly; Path=/; Expires=Fri, 05-Mar-2027 17:25:45 GMT',
['Content-Type'] = 'text/html; charset=UTF-8',
['Set-Cookie'] = 'PHPSESSID=rueknm41suikcuankk6rtun7cj; path=/; Secure; SameSite=None; secure',
['Expires'] = 'Thu, 19 Nov 1981 08:52:00 GMT',
['Cache-Control'] = 'no-store, no-cache, must-revalidate',
['Pragma'] = 'no-cache',
['P3P'] = 'CP="IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT"',
['Transfer-Encoding'] = 'chunked'}
 
 
 
 
 
 
 local x = conn:load('https://lomont.site/gt/' .. args.id3 .. '?&alloff=true', headers)


if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 


local data = string.match(x,'<div id="inputData"(.-)<div id="vPreloader"') 

if data then

for video, season, episode, title, voice in string.gmatch(data,'"video_id":(.-),"season":(.-),"episode":(.-),"voice_name":"(.-)","voice_id":(.-),') do


--local x = conn:load('https://lomont.site/player/responce.php?video_id=' .. video)
--.. '&season=' .. season .. '&episode=' .. episode .. '&voice=' .. voice)

--x = string.gsub(x, '\\', '')

--local url = string.match(x,'"src".-(http.-m3u8)"')

--t['view'] = 'simple'

--table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = url})

t['view'] = 'simple'


table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = '#stream/q=fanserials&id3=' .. args.id3 .. '&id=' .. video .. '&id1=' .. season .. '&id2=' .. episode .. '&id4=' .. voice .. '&id5=' .. title})


end
end
end



 elseif args.q == 'fanserials' then

local x = conn:load('https://lomont.site/player/responce.php?video_id=' .. args.id .. '&season=' .. args.id1 .. '&episode=' .. args.id2 .. '&voice=' .. args.id4 .. '&alloff=true', headers)
  --   print(x)


if x then

local url = string.match(x,'"src".-(http.-m3u8)"')

url = string.gsub(url, '\\', '')
  
 
      t['view'] = 'simple'

return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}

--table.insert(t, {title = 'Сезон ' .. args.id1 .. ' серия ' .. args.id2 .. ' ' .. args.id5, mrl = url})

end





elseif args.q == 'fanserialsm' then
   
local headers = {
    ["Host"] = "1fanserials.org",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://1fanserials.org/films/",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "__ddg8_=1fmsm0vHdmBHUNd2; __ddg10_=1785251191; __ddg9_=185.228.133.239; __ddg1_=yKoRO1EMPs6rMsq5RYxZ; PHPSESSID=1a21b2ffc6e416654a5282bb064269d3; _ym_uid=1785251045348708012; _ym_d=1785251045; _ym_isad=2; _ym_visorc=b; adrfpip=nAbe16msPTPn; _ohmybid_cmf=2; domain_sid=APwDrHvXKAJ6iYZlPJ69p%3A1785251239326; _sltm=8d703f70f587d25c492c5c2b66042230~0; _sltb=0; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0, i"
}


 
-- local x = http.getz(args.id, headers) 
 
 
-- local key = string.match(x,'<iframe.-src="/.-/.-key=(.-)"')
 
 --if key then
 
local headers1 = {
    ["Host"] = "1fanserials.org",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://1fanserials.org/movies/" .. args.id .. "?key=" .. args.id1,
    ["Connection"] = "keep-alive",
    ["Cookie"] = "__ddg8_=vWS2jN5TY7k1hQmR; __ddg10_=1785251259; __ddg9_=185.228.133.239; __ddg1_=yKoRO1EMPs6rMsq5RYxZ; PHPSESSID=1a21b2ffc6e416654a5282bb064269d3; _ym_uid=1785251045348708012; _ym_d=1785251045; _ym_isad=2; _ym_visorc=b; adrfpip=nAbe16msPTPn; _ohmybid_cmf=2; domain_sid=APwDrHvXKAJ6iYZlPJ69p%3A1785251239326; _sltm=8d703f70f587d25c492c5c2b66042230~0; _sltb=0; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}

 local x = http.getz('https://1fanserials.org/film.php?kp=' .. args.id ..'&key=' .. args.id1, headers1) 
 
 
 
 if x then
 
 for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(1080p)' .. tolazy(title), mrl = url})

end
 
   for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '720.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(title), mrl = url})

end
 
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '480.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(title), mrl = url})

end
 
 
 for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '360.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(title), mrl = url})

end
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '240.mp4:hls:manifest')


   
   
 t['view'] = 'simple'

table.insert(t, {title = '(240p)' .. tolazy(title), mrl = url})

end
end 
 





  elseif args.q == 'fancdn' then
 
 --https://lam.maxvol.pro/lite/fancdn?kinopoisk_id=386
 
 local x = conn:load('http://z01.online/lite/fancdn?kinopoisk_id=' .. args.id3)

-- table.insert(t, {title = 'http://178.20.46.40:12600/lite/fancdn?kinopoisk_id=' .. args.id3, mrl = 'http://178.20.46.40:12600/lite/fancdn?kinopoisk_id=' .. args.id3})

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
  
        --  url = string.gsub(url, '^(.-)', 'https://lam.maxvol.pro') 
     
url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
 
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls.m3u8', '480.mp4:hls:manifest.m3u8')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end






elseif args.q == 'videxx' then



local x = conn:load('http://31.129.234.181/lite/vibix/?kinopoisk_id=' .. args.id3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
 

 if x then
 
 x = string.gsub(x, '\\u0026', '&')

 
 for qual, title in string.gmatch(x,'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
   for total, url in string.gmatch(qual, '"(%d+p)":.-http.-(/lite.-)"') do
   
   
    url = string.gsub(url, '^(.-)', 'http://31.129.234.181')
 
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end
end
end
 
 
 
  
local x = conn:load('http://31.129.234.181/lite/vibix/?kinopoisk_id=' .. args.id3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
 

 if x then

x = string.gsub(x, '\\u0026', '&')


for url, season in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"url":"http.-(/lite.-)".-videos__season%-title.->(.-)<') do

url = string.gsub(url, '^(.-)', 'http://31.129.234.181')

 local x = conn:load(url .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
 
x = string.gsub(x, '\\u0026', '&')

for qual, episod in string.gmatch(x,'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do

for total, url1 in string.gmatch(qual,'"(%d+p)":.-http.-(/lite.-)"') do
   
   
    url1 = string.gsub(url1, '^(.-)', 'http://31.129.234.181')
 
  t['view'] = 'simple'


 table.insert(t, {title = total .. ' ' .. season .. ' ' .. episod, mrl = url1})

end
end
end
end



elseif args.q == 'vibix' then

--https://api.manhan.one/lite/vibix/video.m3u8?id=yOZH8-aITUVYstxy5YL4epTadJ889APSj_wBORMUqjprhZS0bE07NhlCFw62uAKTNhlWfcLZVy9noUwHe-muutsdkGvDPujwY9yB14ut4UjHLayS0NUVwFcuauA5-kNik6dhZOnLGrX1R34qPs9CXj2COLPaxEgHtsL7jMt1wRz_5SjmFEM12ZRAbS27yH_7&account_email=rsmail@ukr.net
 
 local x = conn:load('https://api.manhan.one/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
--local x = conn:load('https://lam10.akter-black.com/lite/vibix?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&uid=hobqwt4m')


 if x then
 
 x = string.gsub(x, '\\u0026', '&')
-- x = string.gsub(x, '0&referer', '1&referer')
 
-- x = string.gsub(x, '&account', '?kp=' .. args.id3 .. '&domain=kinobaza.vercel.app&parent_domain=kinobaza.vercel.app&account')
 
 
 for quality, title in string.gmatch(x, 'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
  for qual, url in string.gmatch(quality, '"(%d+p)":.-(http.-)"') do
    

  t['view'] = 'simple'


 table.insert(t, {title = qual .. ' ' .. title, mrl = url})

end
end
end  

local x = conn:load('https://api.manhan.one/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
 --local x = conn:load('https://lam10.akter-black.com/lite/vibix?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&uid=hobqwt4m')
  if x then
  
    for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do


 local x = conn:load(url .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
--local x = conn:load(url .. '&uid=hobqwt4m')
 
 
 x = string.gsub(x, '\\u0026', '&')
 
for quality, title1 in string.gmatch(x, 'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
  for qual, url1 in string.gmatch(quality, '"(%d+p)":.-(http.-)"') do
    

  t['view'] = 'simple'

 table.insert(t, {title = qual .. ' ' .. title .. ' ' .. title1, mrl = url1})

  end
 end
 end
 end
  
  





elseif args.q == 'vibex' then
 
 
 local x = conn:load('https://lampa.li/lite/vibix?kinopoisk_id=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 --table.insert(t, {title = 'https://lampa.li/lite/vibix?kinopoisk_id=' .. args.id3 .. '&uid=bwygkgxn', mrl = 'https://lampa.li/lite/vibix?kinopoisk_id=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'})
 
 --x = string.gsub(x, '&quot;', '"')

 
 for stream, title in string.gmatch(x,'<div class="videos__item videos__movie.-method.-streamquality(.-)].-videos__item%-title.->(.-)<') do
 
 
 
 for qual, url in string.gmatch(stream, 'quality.-(%d+p).-url.-(http.-)&#') do
 
 t['view'] = 'simple'

 table.insert(t, {title = '(' .. qual .. ') ' .. title, mrl = url})

end
end

x = string.gsub(x, '\\u0026', '&')

for season, title in string.gmatch(x,'<div class="videos__item videos__season.-method.-link.-(http.-)&#.-videos__season%-title">(.-)<') do

local x = conn:load(season .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

for stream, title1 in string.gmatch(x,'<div class="videos__item videos__movie.-method.-streamquality(.-)].-videos__item%-title.->(.-)<') do
 
 
 
 for qual, url in string.gmatch(stream, 'quality.-(%d+p).-url.-(http.-)&#') do
 
 t['view'] = 'simple'

 table.insert(t, {title = '(' .. qual .. ') ' .. title .. ' ' .. title1, mrl = url})

end
end
end







elseif args.q == 'videx' then
 
 --local x = conn:load('http://fxmlparsers.in.net/VilkaDB/?id=search&search=' .. urlencode(args.id1) .. '&descitem%20year=' .. args.id2)


local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru')


for id, media in string.gmatch(x,'%[{"id":(.-),.-"mediaType":"(.-)"') do




--for id, media, date in string.gmatch(x, '"fxml".-{"logo.-"playlist_url":"http.-&tid=(.-)&media_type=(.-)".-descitem year.->(.-)<') do



lampa = string.gsub(id,'^(.-)','http://lampa.mx/?card=') .. '&media=' .. media .. '&source=tmdb'

--table.insert(t, {title = id2, mrl = id2})


lampa = base64.encode(lampa)

lampa = urlencode(lampa)
--http://lampa.mx/?card=202555&media=movie&source=tmdb




--local x = conn:load('https://kinobd.net/api/films/search/kp_id?q=' .. args.id3 .. '&page=1')

local x = conn:load('https://apitmdb.cubnotrip.top/3/' .. media .. '/' .. id.. '?append_to_response=content_ratings,release_dates,external_ids,keywords,alternative_titles&api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru&page=1&email=')




--table.insert(t, {title = 'https://www.imdb.com/find/?q=' .. urlencode(args.id1) .. '+' .. args.id2, mrl = 'https://www.imdb.com/find/?q=' .. urlencode(args.id1) .. '+' .. args.id2})


--local x = conn:load('https://api.manhan.one/externalids?kinopoisk_id=' .. args.id3)
  

--  local imdb = string.match(x, 'data%-testid="inline%-watched%-button%-(.-)"')
  
   
 local imdb = string.match(x, '"imdb_id":"(.-)"')

if imdb then

local headerss = {
    ["Host"] = "api.lampa.stream",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "cf_clearance=OOYmoeM_PmBabhVZv4KVB83PiYN1Y5CDwZtIV3oi7kM-1778248424-1.2.1.1-N2lBdTioGB78gQ3NncjNIZLg4QgREKKpt084eRzADwLxOhYjJDCIDAon1uTPQC8w0o.4Hn9IbG0PJk251yXQpX4NqFoLtOf0A968CvEXsU0HFkwbNkn3jDgpyMl7MBPfYkHjS3RdRKe_XRdXKaxIH8ZcHGr0QsIzLsoan8IPVQTb_D3gEnSd06eyjA0cPqF3L7Zm6X32zuHBnT6Q15DvO3kjqbLboPz48ZnDuwKPl2KOl3cwrC9o01YKn964e1_iPWyCXVoEpZvxNmbJVWFwwNs7Ab.P2qsOjWOVA6Oh7TvMqUqCg.QQNV0bbBpBnOg.88px9FWPJcShpAsYkvSuOA",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1"
}




local headers = {["Host"] = "api.lampa.stream",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
      ["Referer"] = "http://api.lampa.stream/",
      ["Cookie"] = "cf_clearance=OOYmoeM_PmBabhVZv4KVB83PiYN1Y5CDwZtIV3oi7kM-1778248424-1.2.1.1-N2lBdTioGB78gQ3NncjNIZLg4QgREKKpt084eRzADwLxOhYjJDCIDAon1uTPQC8w0o.4Hn9IbG0PJk251yXQpX4NqFoLtOf0A968CvEXsU0HFkwbNkn3jDgpyMl7MBPfYkHjS3RdRKe_XRdXKaxIH8ZcHGr0QsIzLsoan8IPVQTb_D3gEnSd06eyjA0cPqF3L7Zm6X32zuHBnT6Q15DvO3kjqbLboPz48ZnDuwKPl2KOl3cwrC9o01YKn964e1_iPWyCXVoEpZvxNmbJVWFwwNs7Ab.P2qsOjWOVA6Oh7TvMqUqCg.QQNV0bbBpBnOg.88px9FWPJcShpAsYkvSuOA",
    ["Content-Type"] = "application/json; charset=utf-8",
    Connection = "close",
    Server = "cloudflare",
    ["Server-Timing"] = {
        'cfCacheStatus;desc="MISS"',
        "cfEdge;dur=9,cfOrigin;dur=31"
    },
    ["Vary"] = "Accept-Encoding",

    ["X-Powered-By"] = "modss",
    ["X-RateLimit-Limit"] = 40,
    ["X-RateLimit-Remaining"] = 38,
    ["X-RateLimit-Reset"] = 1778251762,
    ["X-Response-Time"] = "5.85ms",
    ["Access-Control-Allow-Headers"] = "*",
    ["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS",
    ["Content-Encoding"] = "gzip",
    ["Cache-Control"] = "max-age=86400",
    ["cf-cache-status"] = "MISS",
    ["CF-RAY"] = "9f8944c5dddf6d26-FRA"
}


--args.id1 = string.gsub(args.id1, ' ', '%%20')


--https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/807031/tt16431404/dW5kZWZpbmVk/aHR0cDovL2xhbXBhLm14Lz9jYXJkPTEzMTg0NDcmbWVkaWE9bW92aWUmc291cmNlPXRtZGI%3D?ips=2a0d:5600:9:3003:f35c:e2d8:1376:a2ad&uid=7b40eb0595118e5649d10dcda_1db58ea969d1843cbaa506a8&ip=185.228.133.239&title=На%20вершине

--https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/386/tt0078748/dW5kZWZpbmVk==/aHR0cDovL2xhbXBhLm14Lz9jYXJkPQ==?ip=185.228.133.239&title=чужой

--https://proxy4.rte.net.ru/

local url = 'https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/' .. args.id3 .. '/' .. imdb .. '/dW5kZWZpbmVk/' .. lampa .. '?ip=185.228.133.239&title=' .. urlencode(args.id1)



--local x = http.getz(url, headers)

local x = conn:load(url)



local slist = string.match(x,'"folder":%[(.-)],"duration"')

if slist then

for qual, title in string.gmatch(slist, 'method.-play.-"qualitys":{(.-)}.-"vast_msg":".-","voice_name":"(.-)"') do

for  total, url1 in string.gmatch(qual, '"(%d+p)":"(.-)"') do
  

  t['view'] = 'simple'


--'https://proxy4.rte.net.ru/' .. 

 table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = 'https://proxy4.rte.net.ru/' .. url1})

end
end
end




for qual, season, episod, title in string.gmatch(x, '"method":"play","title":"Серия.-"qualitys":{(.-)}.-"vast_msg":".-","season":"(.-)","episode":(.-),"voice_name":"(.-)"') do

for  total, url1 in string.gmatch(qual, '"(%d+p)":"(.-)"') do
  

  t['view'] = 'simple'


--'https://proxy4.rte.net.ru/' .. 

 table.insert(t, {title = '(' .. total .. ') Сезон-' .. season .. ' серия-' .. episod .. ' ' .. title, mrl = 'https://proxy4.rte.net.ru/' .. url1})

end
end
end
end




for qual, season, episod, title in string.gmatch(x, '"method":"play","title":"Серия.-"qualitys":{(.-)}.-"vast_msg":".-","season":"(.-)","episode":(.-),"voice_name":"(.-)"') do

for  total, url1 in string.gmatch(qual, '"(%d+p)":"(.-)"') do
  

  t['view'] = 'simple'


--'https://proxy4.rte.net.ru/' .. 

 table.insert(t, {title = '(' .. total .. ') Сезон-' .. season .. ' серия-' .. episod .. ' ' .. title, mrl = 'https://proxy4.rte.net.ru/' .. url1})

end
end
end
end

elseif args.q == 'vibix1' then
  
  
  
--  https://reyohoho-old.onrender.com/#386
  
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  
 -- for url in string.gmatch(x, '(<option player.-</option>)') do
  
  
 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed/.-)"') do
 
 
 
 --https://672431256.videoframe2.com/api/v1/embed-serials/5523?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com/embed-serials/5523
  
--https://672431256.videoframe2.com/api/v1/embed/215500?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com/embed/215500 
 
 local x = conn:load('https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url)
 
 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slis = string.gsub(slist, ',', '"')
 slist = string.gsub(slist, ';', '"')
 
for total, title, url in string.gmatch(slist, '%[(480p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
	
t['view'] = 'simple'
 
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 
 
for total, title, url in string.gmatch(slist, '%[(720p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"%{.-}http.-"({.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 


for total, title, url in string.gmatch(slist, '%[(1080p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end

end
    end
  
  
  
  
  
  
  
   
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  

 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed%-serials.-)"') do
 

 local x = conn:load('https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url)
  
 -- table.insert(t, {title = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url, mrl = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url})
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slist = string.gsub(slist, ',', '"')
-- slist = string.gsub(slist, ';', '"')
slist = string.gsub(slist, ']{', '"name":')
slist = string.gsub(slist, ';{', '"name1":')

-- for total1 in string.gmatch(slist, '"title":"(Сезон.-)"') do
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
    end
  end





--http://178.20.46.40:12600

--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979

--https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=386

elseif args.q == 'veoveo' then
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
   
--table.insert(t, {title = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1), mrl = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1)})
      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'veoveo :' .. tolazy(total), mrl = url2})

       
    end
     
--  local x = conn:load('http://178.20.46.40:12600/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
 
 

 
 
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do
     
   --  url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600') 
     
     
     local x = conn:load(url2)

--table.insert(t, {title = url2, mrl = url2})

for  url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total4), mrl = url3})

      end 
      end


elseif args.q == 'kinopub' then
  
  
 
local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=movie' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

for url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[Воспроизвести]].-<playlist_url><!%[CDATA%[(http.-)]]') do


      local x = conn:load(url2 .. '&box_mac=acace24b8434')

 for title, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title), mrl = url3})
   
   end
   end
 end




 
 local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=serial' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

 
 
   
   for title, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   local x = conn:load(url2 .. '&box_mac=acace24b8434')
   
  for title1, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url><!%[CDATA%[(http.-)]]') do
  
  local x = conn:load(url3 .. '&box_mac=acace24b8434')
  
   for title2, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title) .. ' ' .. tolazy(title1) .. ' (' .. tolazy(title2) .. ')', mrl = url4})
   end
   end
   end
   
end
   





elseif args.q == 'filmixred' then
 
 local url = 'https://lampa.li/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2

  

local x = conn:load(url .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
--  table.insert(t, {title = url .. '&uid=bwygkgxn', mrl = url .. '&uid=bwygkgxn'})
  
  x = string.gsub(x, '\\u0026', '&')



local search = string.match(x, '<div class="videos__line".-method.-url.-(http.-)&#')

local x = conn:load(search .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

x = string.gsub(x, '\\u0026', '&')

  for qual, total in string.gmatch(x, '<div class="videos__item videos__movie.-quality.-{(.-)}.-class="videos__item%-title">(.-)</div>') do
  
  --local slist = string.match(x, 'quality.-{(.-)}')
      
   for  total1, url2 in string.gmatch(qual,'(%d+p).-(http.-)&#') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
  -- url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     
      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total), mrl = url2})

       
    end
    end
 
 
 for  url2, total2 in string.gmatch(x, 'class=.-videos__item videos__season.-method.-url.-(http.-)&#.-videos__season%-title.->(.-)<') do
 
 
 url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 

     
     local x = conn:load(url2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 
-- table.insert(t, {title = url2 .. '&uid=bwygkgxn', mrl = url2 .. '&uid=bwygkgxn'})
 
 
 
 x = string.gsub(x, '\\u0026', '&')
     x = string.gsub(x, '\\u002B', '+')
 
-- table.insert(t, {title = x, mrl = '#stream/q=filmixreds&id=' .. x})


   for id, id1, id2, id3, total3 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-postid=(.-)&title=(.-)&.-&s=(.-)&t=(.-)&.->(.-)</div>') do


   t['view'] = 'simple'

    

table.insert(t, {title = tolazy(total2) .. ' ' .. tolazy(total3), mrl = '#stream/q=filmixreds&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})


      end 
      end

    
    elseif args.q == 'filmixreds' then
   
   local x = conn:load('https://lampa.li/lite/filmix?rjson=False&postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&s=' .. args.id2 .. '&t=' .. args.id3 .. '&codec=aac' .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   


    for qual, total in string.gmatch(x, '<div class="videos__item videos.-streamqualit(.-)}].-class="videos__item%-title">(.-)</div>') do
  
 -- local x = string.match(x, 'quality.-{(.-)}')
   
   for  total1, url2 in string.gmatch(qual,'(%d+p).-(http.-)&#') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
   --   url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     


      t['view'] = 'simple'


   table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

       
    end
    end






elseif args.q == 'kinopubtv' then
 
--https://beta.l-vid.online/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn


local url = 'https://lampa.li/lite/kinopub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
  
  x = string.gsub(x, '\\u0026', '&')


  for  total in string.gmatch(x, '<div class="videos__item videos__movie.-class="videos__item%-title">(.-)</div>') do
  
  local slist = string.match(x, 'quality.-{(.-)}')
      
      
   
   for  total1, url2 in string.gmatch(slist, '(%d+p).-http.-(/proxy.-m3u8)') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
   url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     


      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total), mrl = url2})

       
    end
    end
 
 
 for  url2, total2 in string.gmatch(x, 'class=.-videos__item videos__season.-method.-url.-(http.-)&#.-videos__season%-title.->(.-сезон)<') do
 
 
 url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 

     
     local x = conn:load(url2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 x = string.gsub(x, '\\u0026', '&')
     x = string.gsub(x, '\\u002B', '+')
 
 
    for id, id1, id2, id3, total3 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-postid=(.-)&title=(.-)&.-&s=(.-)&t=(.-)&.->(.-)</div>') do


   t['view'] = 'simple'

    

table.insert(t, {title = tolazy(total2) .. ' ' .. tolazy(total3), mrl = '#stream/q=kinopubs&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})


      end 
      end

    
    elseif args.q == 'kinopubs' then
   
   local x = conn:load('https://lampa.li/lite/kinopub?rjson=False&postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&s=' .. args.id2 .. '&t=' .. args.id3 .. '&codec=aac' .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   


    for  total in string.gmatch(x, '<div class="videos__item videos.-class="videos__item%-title">(.-)</div>') do
  
  local x = string.match(x, 'quality.-{(.-)}')
      
      
   
   for  total1, url2 in string.gmatch(x, '(%d+p).-http.-(/proxy.-m3u8)') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
      url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     


      t['view'] = 'simple'


   table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

       
    end
    end



--https://lamp-movie.ru/lite/kinopub?title=чужой-1979




elseif args.q == 'filmix2' then

    

local x = conn:load('https://evkh.lol/lite/filmixtv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
  url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
  url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
 
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
    
    --     for  total3, url4, total2 in string.gmatch(x, '"(.-p)":"http.-mp4.-(http.-mp4).-class="videos__item%-title">(.-)<') do
-- total3 = string.gsub(total3, ',"', '')
 --   t['view'] = 'simple'
--    table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
    
--end
-- end


    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
 
    
    if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
   
  if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
 
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
 
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
 
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
 
 
url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
   
end
end
   
   elseif args.q == 'vkmovie' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lam.maxvol.pro/lite/vkmovie?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
     

     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro')
      url4 = string.gsub(url4, '\\u002B', '+')
       t['view'] = 'simple'

   table.insert(t, {title = '(' .. total3 .. ') ' .. tolazy(total2), mrl = url4})
    end
     end  


elseif args.q == 'remux' then


--https://lam.akter-black.com/lite/remux?kinopoisk_id=386&title=чужой&year=1979

		local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



      for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')
      
      

    --   url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
   
   
   
for  url3, total1 in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url3 = string.gsub(url3, '\\u0026', '&')
      url3 = string.gsub(url3, '\\u002B', '+')
      
 
 
 local x = conn:load(url3)
 
       for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url4 = string.gsub(url4, '\\u0026', '&')
      url4 = string.gsub(url4, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url4})

     end  
    end
end

local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
   
     for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
 
 
 local x = conn:load(url)
 
       for url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total), mrl = url2})

     end  
    end


        


	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end