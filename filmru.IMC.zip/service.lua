-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate




local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local HOME = 'https://www.film.ru'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

--https://www.film.ru/compilation

function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/country/СССР/
	-- #stream/genre=/compilation/genre/306
	-- #stream/genre=/compilation/filmy-pro-paukov-uzhasy
	-- #stream/genre=/compilation/samye-strashnye-filmy-uzhasov-za-poslednie-10-let
	
--https://www.film.ru/compilation/filmy-pro-paukov-uzhasy
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/genre/боевик
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/url=/show/
    -- #stream/genre=/show/
	if not args.q then
		local page = tonumber(args.page or 1)

  --    local genre = args.genre or '/compilation/filmy-pro-paukov-uzhasy'
		local genre = args.genre or '/soon'

--="/compilation/vse-filmy-dueyna-skaly-dzhonsona-ot-luchshego-k-hudshemu/page/1/nojs

		local url = HOME .. genre
		if page > 1 then
			url = url .. '/nojs?page=' .. tostring(page)
         else
				url = url .. '/page/' .. tostring(page)
		--	end
			
        end
        
     
	
        local x = conn:load(url)

 --  for title  in string.gmatch(x, 'href=.-(/.-)"') do		
 
 --   for title  in string.gmatch(x, '<meta property="og:title"(.-)PlayerjsYandexConfig') do
    --<div id="abuse_win"') do
 
 
 

 
   
        for url, title, image  in string.gmatch(x, 'redesign_afisha_movie".-href=.-(/.-)".-<img alt="(.-)".-src=.-(/.-)"') do
   
    
                                      
                                      
			image = string.gsub(image, '^(.-)', HOME)
			
--		title = urlencode(title)
     
  --    title = string.gsub(title, '+', '%%20')
			
           url = string.gsub(url, '^(.-)', HOME)
        
        

    --    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. title, image = image})
        
        table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
        
   --   table.insert(t, {title = tolazy(title) .. ' ' .. tolazy(total), mrl = '#stream/q=content&id=' .. url, image = image})
		end
   
   
 --  for title in string.gmatch(x, 'charset(.-)window.location.href') do
   
 --  table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. title})
     
   --    end   
if genre == '/compilation' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
       end
       
	
       local x = conn:load(url)                          
                                     
      local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
        
		for url, title, image  in string.gmatch(x, '<a href="(/compilation/.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
       end

--https://www.film.ru/compilation/mcompilation/49816506
  
--https://www.film.ru/compilation/  mcompilation/50313795
  
  
  
          if genre == '/compilation/mcompilation/49816506' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
       end
       
	
       local x = conn:load(url)                          
                                     
      local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
        
		for url, title, image  in string.gmatch(x, '<a href="(/compilation/.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
       end
  
  
  
          if genre == '/compilation/mcompilation/50313795' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
       end
       
	
       local x = conn:load(url)                          
                                     
      local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
        
		for url, title, image  in string.gmatch(x, '<a href="(/compilation/.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
       end

          if genre == '/compilation/mcompilation/49840314' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
       end
       
	
       local x = conn:load(url)                          
                                     
      local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
        
		for url, title, image  in string.gmatch(x, '<a href="(/compilation/.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
       end

          if genre == '/compilation/mcompilation/49830486' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
       end
       
	
       local x = conn:load(url)                          
                                     
      local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
        
		for url, title, image  in string.gmatch(x, '<a href="(/compilation/.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
       end

          if genre == '/compilation/mcompilation/49821365' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
       end
       
	
       local x = conn:load(url)                          
                                     
      local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
        
		for url, title, image  in string.gmatch(x, '<a href="(/compilation/.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
       end

          if genre == '/compilation/mcompilation/49811178' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
       end
       
	
       local x = conn:load(url)                          
                                     
      local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
        
		for url, title, image  in string.gmatch(x, '<a href="(/compilation/.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
       end






    if genre == '/compilation/genre/306' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
--	for url, title, image  in string.gmatch(x, 'href="(/.-)".-<img alt="(.-)".-src="(/.-)"') do
	
    for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
	
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end


if genre == '/compilation/genre/2419' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end


if genre == '/compilation/genre/281' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end

   
   if genre == '/compilation/genre/282' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end

   if genre == '/compilation/genre/283' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
   
   
   if genre == '/compilation/genre/284' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
   
   
      if genre == '/compilation/genre/285' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
   
         if genre == '/compilation/genre/286' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
   
   
      if genre == '/compilation/genre/287' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
   
   
   
      if genre == '/compilation/genre/288' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
   
   
      if genre == '/compilation/genre/289' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
      
      
            if genre == '/compilation/genre/290' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
   
   
      if genre == '/compilation/genre/291' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
                                                 if genre == '/compilation/genre/292' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end
                                                                                                                                           if genre == '/compilation/genre/293' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end                                  
                                                                                                   if genre == '/compilation/genre/294' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end                                                                                                                   
                    if genre == '/compilation/genre/295' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end                                                                                                                                                         
             if genre == '/compilation/genre/296' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end                                    
             if genre == '/compilation/genre/297' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end                                    
             if genre == '/compilation/genre/298' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end                                    
             if genre == '/compilation/genre/299' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end                                    
     
                  if genre == '/compilation/genre/300' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end          
     
             if genre == '/compilation/genre/301' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end          
     
                      if genre == '/compilation/genre/302' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end                                                 
             if genre == '/compilation/genre/303' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end          
             if genre == '/compilation/genre/304' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end          
                                                
             if genre == '/compilation/genre/305' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end          
                                               
                    if genre == '/compilation/genre/307' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end                                                  
             if genre == '/compilation/genre/308' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page)
      end
       local x = conn:load(url)         
     local x = string.match(x, '<div class="wrapper_movies_compilations".->(.-)</div>')
	for url, title, image  in string.gmatch(x, '<a href="(/compilation.-)".-<img alt="(.-)".-src="(/.-)"') do
         image = string.gsub(image, '^(.-)', HOME)
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
      end          
                                               

    	
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		



      local x = conn:load(HOME)
		
--chapter0">Что посмотретьchapter4">Журнал		
		local x = string.match(x, 'Рекламный отдел(.-)Журнал')

		
         for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
        --	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end

    
    local x = conn:load(HOME .. '/compilation')
		
		
		local x = string.match(x, 'active">Жанры(.-)</div')
		
         for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
        --	genre=http.urldecode(urlencode(genre))
--urlencode
--			table.insert(t, {title = HOME .. genre, mrl = '#stream/genre=' .. genre})
			
			
table.insert(t, {title = 'Коллекции :' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		
 --  https://www.film.ru/compilation/filmy-pro-paukov-uzhasy 
    
--https://www.film.ru/a-z/

         local x = conn:load(HOME .. '/a-z/movies')
  
      local x = string.match(x, 'active.->Все годы(.-)Рейтинг film.ru')
 
     for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
        --	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = 'Фильмы :' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
  
               local x = conn:load(HOME .. '/a-z/serials')
  
      local x = string.match(x, 'active.->Все годы(.-)Рейтинг film.ru')
 
     for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
        --	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = 'Сериалы :' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
      
      
      
 --https://www.film.ru/search/result/movies/%D1%80%D0%BE%D0%BA%D0%BA%D0%B8/rel/1/nojs
		
--https://www.film.ru/search/result?text=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8&type=all

--https://www.film.ru/compilation

		
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/result/movies/' .. urldecode(args.keyword)
		--.. '/rel/' .. tostring(page)


		local x = conn:load(url)

--next_page_link
	local x = string.match(x, 'По релевантности(.-)next_page_link')
		
        for url, title, image in string.gmatch(x, '<a.-href="(/.-)".-<img alt="(.-)".-src="(/.-)"') do

			image = string.gsub(image, '^(.-)', HOME)
			
            url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urldecode(args.keyword) .. '/rel/' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
		local x = conn:load(args.id)
    --	local x = http.getz(args.id)
		
       -- x = string.gsub(x, 'onclick', '')
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<h1>(.-)%(.-</h1>')
		t['description'] = parse_match(x, '<div class="wrapper_movies_text".-<p>(.-)</p>')
		--	t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="FullstoryFormLeft".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			

			
			
			
	    	t['annotation'] = parse_array(x, {
			'<div class="wrapper_movies_top_info".-<span>(.-)</div>',
			'<h2>(.-)</div>',
			'(Страна:</h4>.-)</p>',
			'(Жанр:</h4>.-)</p>',
			'(Перевод:</h4>.-)</p>',
			'(Качество:</h4>.-)</p>',
			'(Время:</h4>.-)</p>',
			'(Бюджет:</h4>.-)</p>'})
   
 --<meta property="og:title" content="Репетиция (2022-...)

  --  for title, title1 in string.gmatch(x, '<h1>(.-)<br>.->(.-)<') do
   
   --     for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do




    for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do


      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
  
     url = string.gsub(title, '^(.-)', 'https://apicollaps.cc/list?token=eedefb541aeba871dcfc756e6b31c02e&name=') .. '&year=' .. title1
--  table.insert(t, {title = url, mrl = url})
    
    
      local x = conn:load(url)


     for title3 in string.gmatch(x, '"id":(.-),') do

    url1 = string.gsub(title3, '^(.-)', 'https://mylam.ru/lite/collaps?orid=')
-- table.insert(t, {title = url1, mrl = url1})
     local x = conn:load(url1)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'https://mylam.ru')
   --   t['view'] = 'simple'

   table.insert(t, {title = 'Collaps : ' .. tolazy(total), mrl = url2})

     end  
  --  end


   
    
  --   local x = conn:load(url)
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/collaps.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://mylam.ru')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'https://mylam.ru')
    
    --   t['view'] = 'simple'

    table.insert(t, {title =  'Collaps : ' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end
    end
end
end
   
   





    for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do


--http://movixhd.online/lite/mirage?title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&original_title=Alien&clarification=0&year=1979

    title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
  
     
     
    
    url1 = string.gsub(title, '^(.-)', 'http://93.183.92.183:9118/lite/mirage?title=') .. '&year=' .. title1 .. '&uid=m7alois3'
 
  -- table.insert(t, {title = 'Mirage', mrl = '#stream/q=content&id=' .. url1, image = image})
  --   end
     --  end
    local x = conn:load(url1)
     
     for  url2, url3,  total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
  
      url3 = string.gsub(url3, '\\u0026', '&')

    
       local x = conn:load(url2 .. url3)
    
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
    
       url4 = string.gsub(url4, '^(.-)', 'http://93.183.92.183:9118')
    
    --   t['view'] = 'simple'

    table.insert(t, {title = tolazy(total2) .. '(' .. tolazy(total3) .. ')', mrl = url4})

      end 
      end
     
  

      
       for url2, total  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
       url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       
     url2 = string.gsub(url2, '\\u0026', '&')
     
   --  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)


      for url3, url4, total1, total2  in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-voice_name":"(.-)".-class="videos__item%-title">(.-серия)</div>') do

       url3 = string.gsub(url3, '^(.-)', 'http://93.183.92.183:9118')
       
     url4 = string.gsub(url4, '\\u0026', '&')
      local x = conn:load(url3 .. url4)
     local x = string.match(x, '"quality"(.-)}')
      for  total3, url5 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
   
     url5 = string.gsub(url5, '^(.-)', 'http://93.183.92.183:9118')
    
         total1 = string.gsub(total1, '\\u041D\\u0435 \\u0442\\u0440\\u0435\\u0431\\u0443\\u0435\\u0442\\u0441\\u044F', 'Не требуется')
        
        
        total1 = string.gsub(total1, '\\u0414\\u0443\\u0431\\u043B\\u0438\\u0440\\u043E\\u0432\\u0430\\u043D\\u043D\\u044B\\u0439', 'Дублированный')
    total1 = string.gsub(total1, '\\u0414\\u0443\\u0431\\u043B\\u044F\\u0436', 'Дубляж')
    

    
    
         
    --   t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total2) .. '(' .. total3 .. ')' .. '(' .. total1 .. ')', mrl = url5})

    end
end
end
 end    

   











--for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do

    for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do

       title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
       url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)



    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do



     url1 = string.gsub(title3, '^(.-)', 'https://mylam.ru/lite/vdbmovies?kinopoisk_id=') .. '&uid=m7alois3'

    table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=content&id=' .. url1, image = image})
    
    end
    end
  --  local x = conn:load(url1)

       for total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-/proxy.-mp4.-class="videos__item%-title">(.-)</div>') do
  
  
  
      local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url1 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)"') do
      
  
  
     url1 = string.gsub(url1, '\\u0026', '&')
    url1 = string.gsub(url1, '^(.-)', 'https://mylam.ru')


      t['view'] = 'simple'


   table.insert(t, {title = 'vdbmovies' .. ':'.. tolazy(total) .. ( total1), mrl = url1})

       
    end
    end
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

    --     url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'https://mylam.ru')
    

      local x = conn:load(url2)

     
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
  
     --    url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'https://mylam.ru')
    
       
    
     local x = conn:load(url3)
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'https://mylam.ru')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end
  
     









     for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do

    --  for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do

       title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
       url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)



    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do


   url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=') 

    
      table.insert(t, {title = 'Zetflix', mrl = '#stream/q=content&id=' .. url1, image = image})
    
    end
    end
    
    --   local x = conn:load(url1)
   
   
   for  total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-hidxlglk.-class="videos__item%-title">(.-)</div>') do
  
  
     local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-m3u8)"') do
      
      url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')

      
      
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
    
    
        for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"http.-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
  
      url4 = string.gsub(url4, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end
end
end





  --  for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do

     for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do

       title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
       url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)



    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do




   url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/lumex?kinopoisk_id=') 
       --.. '&uid=m7alois3'
 
   table.insert(t, {title = 'Lumex', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
         end
   -- local x = conn:load(url1)
    
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
 -- table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p)lumex :' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '3600/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p)lumex :' .. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p)lumex :' .. tolazy(total), mrl = url3})
       
    end
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
    
     local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"http.-(http.-mp4)') do
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url5})

       
    end
end
end
end
    






   -- for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do







      for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do


       title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
  url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)



    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do


     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 
 
    table.insert(t, {title = 'Hdvb', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
     end
     
       for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   
      local x = conn:load(url2 .. url3)

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :' .. tolazy(total2), mrl = url4})

      end 
      end
      

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end
 



    for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do


         title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')

url1 = string.gsub(title, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=') .. '+' .. title1 .. '+'

table.insert(t, {title = 'Kinopub', mrl = '#stream/q=content&id=' .. url1, image = image})

   --   table.insert(t, {title = url1, mrl = '#stream/q=content&id=' .. url1, image = image})
	  end
	  
--  local x = conn1:load(url1)

     for url2 in string.gmatch(x, '<playlist_name>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn:load(url2)
    
    
    

    
    for total, url3, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-])]].-<playlist_url><!%[CDATA%[(http://185.188.183.182.-) %[.-(&perewod.-)]]></playlist_url>') do
	
	    local x = conn:load(url3 .. url4)
	   
	   
	     for total1, url5 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. total, mrl = url5, image = image})
     end
	    end
    end




  --   for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do

  --else
 --    for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-) %(.-, (.-),.-%)') do

  -- else
--   for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%-.-%)') do




     for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do


         title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
   url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)

--table.insert(t, {title = url, mrl = url})

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
   
   
     url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
      local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
 --  table.insert(t, {title = url1, mrl = url1})
     
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end
   end
   end
  --  end
--    end
    
    
   --   for title, title1 in string.gmatch(x, '<h1>(.-)<br>.->(.-)<') do
    
  
      for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do
  
   -- for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do
  --  for title, title1 in string.gmatch(x, '<h1>(.-)<.-<span>(.-)</span>') do
         title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
   url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1
     local x = conn:load(url)



    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
   
      url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
    --   t['view'] = 'simple'
				table.insert(t,{title= tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
   end
   end
   



   --  for title, title1 in string.gmatch(x, '<h1>(.-)<br>.->(.-)<') do

  
  
  
  
  
  
  
  
  
     
    
   for title, total in string.gmatch(x, '<h1>(.-)<.-<span>(.-)<') do
  --   for title, total in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do
 
      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
--    url = string.gsub(title, '^(.-)', 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=1&query=') .. '&year=' .. title1 .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
 
  --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
 --   local x = conn:load(url)
     
      
  --  for title3, title4, title5 in string.gmatch(x, 'docs.-{"id":(.-),"name":"(.-)".-"year":(.-),') do

     url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    
       local x = conn:load(url)

        for total in string.gmatch(x,'%[{"size.-trackerName.-kinozal.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        

       url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      

        local x = conn:load(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     --    t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
       --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
       -- t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	


     local x = conn:load(url)
     
      for total in string.gmatch(x,'%[{"size.-trackerName.-nnmclub.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        
      url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      

        local x = conn:load(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     
   --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
      --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
      --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	
    end





	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end