-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate


local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local HOME = 'https://w140.zona.plus'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/country/СССР/
	-- #stream/genre=/country/Индия/
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/movies/filter/genre-uzhasy
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/url=/show/
    -- #stream/genre=/show/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/movies/filter/sort-date'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		
		
        
	--	local x = http.getz(url)
	
        local x = conn:load(url)
		
     
   
       for image, url, title, total in string.gmatch(x, '<li class="results%-item%-wrap".-itemprop="image" content="(.-)".-itemprop="url" href="(/.-)" title="(.-)"') do


			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
   
   
          



         
 	
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
   --    table.insert(t, {title = 'Актёры', mrl = '#stream/genre=' .. '/actors/'})
		
	--	local x = conn:load(HOME)
		
		
--		local x = string.match(x, 'Категории.-<ul id="six" class="submenu">(.-)</ul>')
  --  	for genre, title in string.gmatch(x, '<li><a href="(.-)">(.-)<') do
      --  	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/updates/movies'})
--		end
--https://w140.zona.plus/tvseries

         local x = conn:load(HOME .. '/movies')
		
		
--		local x = string.match(x, '<div class="js%-filters".-label="Жанры".->(.-)<.-label="Рейтинг"')
  

		
         for genre, title in string.gmatch(x, '<option value="(.-)".->(.-)</option>') do
        --	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = 'Фильмы' .. ': ' .. tolazy(title), mrl = '#stream/genre=' .. '/movies/filter/' .. genre})
			end
	   local x = conn:load(HOME .. '/tvseries')
		
		
--		local x = string.match(x, '<div class="js%-filters".-label="Жанры".->(.-)<.-label="Рейтинг"')
  

		
         for genre, title in string.gmatch(x, '<option value="(.-)".->(.-)</option>') do
        --	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = 'Сериалы' .. ': ' .. tolazy(title), mrl = '#stream/genre=' .. '/tvseries/filter/' .. genre})
			end        		

			
			
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/' .. urlencode(args.keyword)
		--.. '?page=' .. tostring(page)


		local x = conn:load(url)
		
        for image, url, title, total in string.gmatch(x, '<li class="results%-item%-wrap".-itemprop="image" content="(.-)".-itemprop="url" href="(/.-)" title="(.-)"') do


			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '?page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
	--	local x = conn:load(args.id)
    	local x = http.getz(args.id)
		
       -- x = string.gsub(x, 'onclick', '')
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)смотреть онлайн</h1>')
		t['description'] = parse_match(x, '<div class="entity%-desc%-description" itemprop="description">(.-)</div>')
		--	t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="FullstoryFormLeft".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			

			
			
			
	    	t['annotation'] = parse_array(x, {
			'(Оригинальное название:</h4>.-)</p>',
			'(Год</dt>.-)</dd>',
			'(Страна</dt>.-)</dd>',
			'(Жанры</dt>.-)</dd>',
			'(Перевод:</h4>.-)</p>',
			'(Качество:</h4>.-)</p>',
			'(Время:</h4>.-)</p>',
			'(Бюджет:</h4>.-)</p>'})
      
      
       for  url  in string.gmatch(x, '<div class="entity%-title%-wrap" data%-id="(.-)"') do
   
 --    url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=') 
        url = string.gsub(url, '^(.-)', 'https://filmos.net/ChangeCDN_20.php?kinopoisk_id=') .. '&iframeurl='
    
    --     print(url)
  --       table.insert(t, {title = 'vibix плеер', mrl = '#stream/q=content&id=' .. url})

  --     end
       local x = http.getz(url)
       
         for url, url1  in string.gmatch(x, '<iframe src=.-"(http.-)(videoframe.-)"') do
         url = string.gsub(url, '\\', '')
   
         url1 = string.gsub(url1, '\\', '')
   
         
         table.insert(t, {title = 'vibix плеер', mrl = '#stream/q=content&id=' .. url .. url1})
          end
          end
          
          
    --    for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   
  --     print(url)
     --   local x = http.getz('https://kinobox.tv/api/players?kinopoisk=' .. url .. '&sources=vibix')
        
   --    url = string.gsub(url, '^(.-)', 'https://kinobox.tv/api/players?kinopoisk=') .. '&sources=vibix'
      
     --  table.insert(t, {title = 'vibix плеер', mrl = '#stream/q=content&id=' .. url})

     --  end
      
     --    local x = http.getz(url)

  --     local x = http.getz('https://kinobox.tv/api/players?kinopoisk=' .. url .. '&sources=vibix')
      --  x = iconv(x, 'utf-8', 'UTF-8')
  
  
    --   for url in string.gmatch(x, '{"id".-(http.-)"') do
   
  --     table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
      -- end
      -- end
       
       
    --   local x = http.getz(url)
    --   x = iconv(x, 'utf-8', 'UTF-8')
       for title in string.gmatch(x, '{"title":"(.-)"') do
       for total, url in string.gmatch(x, '%[MP4(.-)](http.-.mp4)') do
   
   
      t['view'] = 'simple'
  
      table.insert(t, {title = title .. ' ' .. (total), mrl = url})
     end
      end
   
    --    local x = http.getz(url)
        

        
        for total, total1, total2,  url in string.gmatch(x, '{"title":"(.-)".-{"title":"(.-)".-"file":"%[(.-p)](http.-mp4)') do
 
 
       total1 = string.gsub(total1, '{"title":', '')
   --    total1 = string.gsub(total1, ',"file":"%[', '')
       total2 = string.gsub(total2, '{"title":', '')
   --    total2 = string.gsub(total2, ',"file":"%[', '')
       
     
     
        t['view'] = 'simple'
  
      table.insert(t, {title = (total) .. ' ' .. (total1) .. ' ' .. (total2), mrl = url})
        end
      
 
 
 
 
 
 
      
      
      for  url  in string.gmatch(x, '<div class="entity%-title%-wrap" data%-id="(.-)"') do
      
      url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=') 
        table.insert(t, {title = 'Videoseed плеер', mrl = '#stream/q=content&id=' .. url})

       end
    
         for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
    
         url = string.gsub(url, '^(.-)', 'https://tv-2-kinoserial.net/api.php?kp_id=')


  
        local x = conn:load(url)
        
       for total, url in string.gmatch(x, 'var player = new Playerjs.-id:"Video.-file.-%[(480p)](http.-mp4)') do
       t['view'] = 'simple'
      table.insert(t, {title = total, mrl = url})
     
       end
     
       for total, url in string.gmatch(x, 'var player = new Playerjs.-id:"Video.-file.-%[(1080p)](http.-mp4)') do
      
      t['view'] = 'simple'
      table.insert(t, {title = total, mrl = url})
     
       end
       
 

   
       
   --    for title in string.gmatch(x, '{"title": "(.-сезон)"') do

       for total, total1, url in string.gmatch(x, '{"title.-"(.-серия)".-%[(480p)](http.-mp4)') do
      
      
      total = string.gsub(total, '", "folder":%[{"title":"', '')
       total = string.gsub(total, ': "', '')
       total = string.gsub(total, ':"', '')
      t['view'] = 'simple'
      table.insert(t, {title = (total) .. ' ' .. (total1), mrl = url})
     
     end
  --   end
 
 
      --  for title in string.gmatch(x, '{"title": "(.-сезон)"') do

       for total, total1, url in string.gmatch(x, '{"title.-"(.-серия)".-%[(1080p)](http.-mp4)') do
      
       total = string.gsub(total, '", "folder":%[{"title":"', '')
      total = string.gsub(total, ': "', '')
      total = string.gsub(total, ':"', '')
       t['view'] = 'simple'
       table.insert(t, {title = (total) .. ' ' .. (total1), mrl = url})
     
  --   end
     end
     end
     
     
     
 
  
  
  
  
  
  
     
         for  url  in string.gmatch(x, '<div class="entity%-title%-wrap" data%-id="(.-)"') do
 
       url = string.gsub(url, '^(.-)', 'https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=')
    --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
       local x = http.getz(url)
   

   
       for title, url  in string.gmatch(x, 'url.-http.-kinovibe.co.-%-(.-).html.-embed.-(http.-)"') do
   
       url = string.gsub(url, '\\', '')
   
       title = string.gsub(title, 'series', '')
         
    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})

       end
       end
   

        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
         
        t['view'] = 'simple'
         
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
     
         t['view'] = 'simple'
     
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
         t['view'] = 'simple'
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end



		
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-id:"playerjshd".-file:"(.-txt)"') do
         -- print(url)
      --    t['view'] = 'grid'
       --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' ..  url})
    --table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})
--		end

       local x = http.getz(url)



           for title, url in string.gmatch(x, '"comment":"(.-)".-file.-(https://s.-mp4)"') do
			print(url)  

          url = string.gsub(url, '_[480,720]', '')
          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title), mrl = url})
        end



		for title, url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do

          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title) .. ' (480p)'  , mrl = url .. url1 .. '_480.mp4'})
   

        end
	
	
          for title,  url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do
		--	print(url)  

      --    url = string.gsub(url, '(.-)', url) .. '_720.mp4'
          t['view'] = 'grid'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title) .. ' (720p)', mrl = url .. url1 .. '_720.mp4'})
   
   --     table.insert(t, {title = tolazy(title) .. (total), mrl = url})
        end
	
      end



   
   
  
   
   
   
          for  url  in string.gmatch(x, '<div class="entity%-title%-wrap" data%-id="(.-)"') do
  
    url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=') 
        table.insert(t, {title = 'cdnvideohub плеер', mrl = '#stream/q=content&id=' .. url})

        end
  
         
          for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
  
       url = string.gsub(url, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=23&kid=')
 
 
     --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
 
  --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})

  --     end
  
--player = new Playerjs.-id:.-playerjs.-
        
        local x = http.getz(url)
        
        for title, url in string.gmatch(x, 'player = new Playerjs.-id:.-playerjs.-\'title\'.-\'(.-)\'.-\'file\'.-(http.-)\'') do
  
  
     url = string.gsub(url, '\\', '')
        url = string.gsub(url, 'u0026', '&')
     
      url = string.gsub(url, '_IPHONE', '')
     
     
            t['view'] = 'simple'
        table.insert(t, {title = title, mrl = url})
       end
       
   
  
     --   local x = http.getz(url)
        
    --    for title in string.gmatch(x, '\'title.-(Season.-)\'') do

        for  total, url in string.gmatch(x, '\'title\'.-(Серия.-)\'.-\'file.-(http.-)\'') do
                                
        url = string.gsub(url, '\\', '')
         url = string.gsub(url, 'u0026', '&')
         url = string.gsub(url, '_IPHONE', '')
         
            t['view'] = 'simple'
       table.insert(t, {title = (total), mrl = url})
       end
   --    end             
  
       end
  
  
  
   
       for  url  in string.gmatch(x, '<div class="entity%-title%-wrap" data%-id="(.-)"') do
    
        print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'zagonka плеер', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-(//video.zagonka.org/movies/.-})') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
			
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
		
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end
      



        for  url  in string.gmatch(x, '<div class="entity%-title%-wrap" data%-id="(.-)"') do
       print(url)
       
    --    url = string.gsub(url, '^(.-)', 'https://videocdn.svetacdn.in/IAF0wWTdNYZm?kp_id=')
        --.. '&domain=kinobd.net'
       
		 url = string.gsub(url, '^(.-)', 'https://videocdn.tv/api/short?api_token=bVycnMuy5Dfe0IkzXt87eeVa9EtIkUl5&kinopoisk_id=')
       
        local x = http.getz(url)
      for  url  in string.gmatch(x, '"iframe_src":"(.-)"') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})

   --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})

		end
   end
    
  

  
  
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(360p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
        
        
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
        
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       
       
        for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(480p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
  
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
  
  
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
  
      for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(720p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
  
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(1080p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
  
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
	
		
       for title, url  in string.gmatch(x, 'movie.-%[(360p)](-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
     	 for title, url  in string.gmatch(x, 'movie.-%[(480p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
	for title, url  in string.gmatch(x, 'movie.-%[(720p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
		
        for title, url  in string.gmatch(x, 'movie.-%[(1080p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
		

        
        

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end