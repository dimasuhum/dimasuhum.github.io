-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--https://api.embess.ws/embed/movie/486

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; alpac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; _lampac_auth=a46f8a8a-8878-4fa5-8554-8296ba62260d; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}


local HOME = 'http://kb-team.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH








PASS = '7777'

local lockpass



function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)

--if not args.q and args.keyword then
--lockpass = args.keyword
--end

--if lockpass == PASS then
--else
--return {view="keyword",message="enter access code"}
--end


	local t = {view = 'grid', type = 'folder'}
		t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end




	if not args.q then


local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}



local headers1 = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}





    local url = 'http://webiptv.zelez.ru/'




		local x = http.getz(url, headers)


for id, logo, name in string.gmatch(x, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. urlencode(id), image = logo})

end


--url = url_for(x)
--url = urldecode(url)
	--	table.insert(t, {title = url, mrl = url, image = image})


--local x = json.decode(x)

	--	for _, v in ipairs(x['channels']) do
		--	local url1 = 'https://tv.alcopa.cc/api/iptv/play?channel_id=' .. v['id']
	
	--t['view'] = 'simple'
	
	




          

	
	
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 
  table.insert(t, {title = 'Общие', mrl = '#stream/q=channelsob', image = image})
 
 
table.insert(t, {title = 'Кино', mrl = '#stream/q=channelski', image = image})

table.insert(t, {title = 'Музыка', mrl = '#stream/q=channelsmy', image = image})

table.insert(t, {title = 'Познавательные', mrl = '#stream/q=channelspo', image = image})



table.insert(t, {title = 'Спорт', mrl = '#stream/q=channelssp', image = image})


table.insert(t, {title = 'Развлекательные', mrl = '#stream/q=channelsra', image = image})


table.insert(t, {title = 'Детские', mrl = '#stream/q=channelsde', image = image})

table.insert(t, {title = 'Другие', mrl = '#stream/q=channelsdr', image = image})



table.insert(t, {title = 'HD', mrl = '#stream/q=channelshd', image = image})


table.insert(t, {title = 'HD Orig', mrl = '#stream/q=channelshdo', image = image})


table.insert(t, {title = '4K', mrl = '#stream/q=channels4k', image = image})



  
  
  
    elseif args.q == 'channelsob' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->новости(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end



elseif args.q == 'channelski' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->кино(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end


elseif args.q == 'channelsmy' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->музыка(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end



elseif args.q == 'channelspo' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->познавательные(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end


elseif args.q == 'channelssp' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->спорт(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end




elseif args.q == 'channelsra' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->развлекательные(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end



elseif args.q == 'channelsde' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->детские(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end



elseif args.q == 'channelsdr' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->другие(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end



elseif args.q == 'channelshd' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->HD<(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end


elseif args.q == 'channelshdo' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->HD Orig(.-)<a class="uk%-accordion%-title"')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end



elseif args.q == 'channels4k' then

local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.9",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local url = 'http://webiptv.zelez.ru/'


	local x = http.getz(url, headers)


 local slist = string.match(x, '<a class="uk%-accordion%-title".->4K(.-)</ul>')

for id, logo, name in string.gmatch(slist, '<button class="uk%-button uk%-button%-text" onclick="playChannel%(\'(.-)\'.-<img src="(.-)".->(.-)</button>') do


	if logo == '/static/images/ico.png' then
	logo = 'http://webiptv.zelez.ru' .. logo
	end


table.insert(t, {title = tolazy(name), mrl = '#stream/q=channel&id=' .. id, image = logo})

end




elseif args.q == 'channel' then

 

   local headers = {
    ["Host"] = "webiptv.zelez.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",

   ["X-Requested-With"] = "XMLHttpRequest",
    ["Sec-GPC"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://webiptv.zelez.ru/",
    ["Priority"] = "u=0",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

  --  ["Accept-Language"] = "en-US,en;q=0.9",
 --   ["Accept-Encoding"] = "gzip, deflate",



args.id = urlencode(args.id)

args.id = string.gsub(args.id, '+', '%%20')

args.id = string.gsub(args.id, '%%2B', '+')

local url = 'http://webiptv.zelez.ru/channel?' .. args.id

--table.insert(t, {title = url, mrl = url})

	local x = http.getz(url, headers)




local title, id = string.match(x, '"title".-(".-").-"url".-http.-iptv/.-/(.-)/index.m3u8"')

if id then

--"http://c3921155.edmonst.net/iptv/42L7TCH8YYKLBRHNPV52HBRN/9221/index.m3u8"}

--http://315e5a5d.ottrast.com/iptv/3W9W7XEYC22NBD/11006/index.m3u8
 
-- local video = 'https://api.potok.rip/api/proxy?url=http://315e5a5d.ottrast.com/iptv/3W9W7XEYC22NBD/' .. video .. '/index.m3u8'



title = string.gsub(title, '^(.-)', '{"title":') .. '}'

local v = json.decode(title)

local title = v['title']


t = {}
table.insert(t, {title = title, mrl = 'https://api.potok.rip/api/proxy?url=http://315e5a5d.ottrast.com/iptv/3W9W7XEYC22NBD/' .. id .. '/index.m3u8'})

end

  --    if url2 then
--    print(url2)
 --  return {view = 'playback', mrl = url2, seekable = 'true', direct = 'true'}
    



local headers1 = {
    ["Host"] = "free.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; _ym_isad=2; mdd=0; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788925305%2C471559000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol_XeKwl0DSp258QPcaYvHkrMNQO5H7ugoE6Jda6I6Mu5YOUtFCktLci-rSn59X-9H8O2g-5rmnA4ES0iFfHT5dZCMJNpsHZPKTAbyKbqJnSCCswurRcJ5VlppbSnjORfIUzxoiO9bVVfpksmWrcx97u7csVeQ%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
    }
    
 

        
 
 
 --local page = tonumber(args.page or '1')
    
--local offset = (page - 1) * 10 + 1
		
	--	for i = 1, 10 do
 
 --http://free.guljaj.com/online/?id=&idk=1846&pot=2
 
-- local url1 = 'http://free.guljaj.com/online/?idk=18&pot=' .. tostring(offset + i - 1) .. '#goog_fullscreen_ad'
 

 
 --local x = http.getz(url1, headers1)
 


--local video = string.match(x, 'Playerjs.-file:.-(http.-m3u8)')
 
 --local vid, vid1, vid2 = string.match(x, 'Playerjs.-file:.-(http.-)(iptv/.-/).-(/index.m3u8)')
 
 
-- video = vid .. vid1 .. id .. vid2
 
--t['view'] = 'list'




-- local x = http.getz(video, headers)



--local ts = string.match(x,'#EXTINF.-http.-.(ts?)')

--if ts then

--t = {}

-- table.insert(t, {title = title, mrl = 'https://api.potok.rip/api/proxy?url=' .. video, image = logo})	
 
 --end

--end
--end




	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
--end
	end
	return t
end