-- joyfilm plugin

require('support')
require('video')
require('parser')

--https://kinorkn.com/video/film/NeGovori24TS.mp4/index.m3u8?h=Jdi9btgATYQiRchYmPyndA&e=1725972140


--HOME = 'https://joyfilm.club'
--urlencode

--HOME = 'https://i6.joyfilm.top'
HOME = 'https://ru.kinola.life'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from joyfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from joyfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2

	-- #stream/genre=serials/updated?page=
	-- #stream/genre=/persons
	-- #stream/genre=/anime/
	-- #stream/genre=/collections
	-- #stream/genre=cartoons/
	-- #stream/genre=/franchises
	-- #stream/genre=best/
	-- #stream/genre=/best/luchshie-filmy-2019-goda?page=
	-- #stream/genre=/?type=&genre=%D0%91%D0%BB%D0%BE%D0%BA%D0%B1%D0%B0%D1%81%D1%82%D0%B5%D1%80&year_from=&year_to=&rating_from=&rating_to=&country=&sortby=date#catalog&page=
	-- #stream/genre=/kinopremery-i-novinki?page=
	-- #stream/genre=/catalog/films/2020/

	-- #stream/genre=/serials/updated?page=
	-- #stream/genre=/serials/?sortby=hits#catalog&page=
	-- #stream/genre=/serials/?genre=%D0%9C%D0%B5%D0%BB%D0%BE%D0%B4%D1%80%D0%B0%D0%BC%D0%B0&year_from=&year_to=&rating_from=&rating_to=&country=&sortby=date#catalog&page=
	-- #stream/genre=/serials/?page=
    -- #stream/genre=/serials/?genre=%D0%B4%D1%80%D0%B0%D0%BC%D0%B0&year_from=&year_to=&rating_from=&rating_to=&countries=&sortby=date#catalog

	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		

      if genre == '/collections' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		end
  
      

		
		local x = http.getz(url)
		
		print(url)
   --  local x = string.match(x, '<div class="catalog catalog%-main rows"(.-)<nav>')
		for url, image, title in string.gmatch(x,'<div class="catalog%-main%-item".-<a href="(http.-)".-<img.-src="(http.-orig)".-<h2 class="film%-item%-title">(.-)</h2>') do
            
--	url = string.gsub(url, '^(.-)', HOME)
		table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end
		 
	
	
	
	
    if genre == '/franchises' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
    	local x = http.getz(url)
    	local x = string.match(x, '<link rel="canonical" href="http.-/franchises".-<nav>(.-)<nav>')


	for genre, image, title in string.gmatch(x,'<a href=".-(/franchises.-)" class="collection%-list%-item".-<img data%-src="(.-)".-alt="(.-)"') do
	
    url = string.gsub(url, 'https://ru.kinola.life', '')
		 
		 table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end
		 end
		 
		 
      for image, url, title in string.gmatch(x,'<div class="collection%-item".-<img data%-src="(.-)".-<h2 class="h4 collection%-item%-title".-<a href="(.-)">(.-)</a>') do
		 
		 table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end	 
		 
		 
		 
	for url, image, title in string.gmatch(x,'<div class="catalog%-full%-item".-<a href="(http.-)".-<img.-src="(http.-)".-<h2 class="film%-item%-title">(.-)</h2>') do
            
--	url = string.gsub(url, '^(.-)', HOME)
		table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end	 
		 

		
		
		

      
      
 --   if genre == '/collections' then
     --   local url = HOME .. genre
--		if page > 1 then
	--		url = url .. '?page=' .. tostring(page)
		
    --     local x = http.getz(url)
 
 --    local x = string.match(x, '<div class="collection%-list rows">(.-)<nav>')


		 for url, image, title in string.gmatch(x,'class="collection%-list rows.-<a href=".-(/collections.-)".-src="(.-)".-alt="(.-)"') do

			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
--end
	--	end


		 
  
  
      
   --     local x = http.getz(HOME .. '/persons' .. '?page=' .. tostring(page))
  
    
  
  
  --  if genre == '/persons' then
  --     local url = HOME .. genre
	--	if page > 1 then
	--		url = url .. '?page=' .. tostring(page)
	--    end
   --     local x = http.getz(url)
   --.. '/persons' .. '?page=' .. tostring(page))
  
   --   local x = string.match(x, '<link rel="canonical" href="http.-/persons".-<nav>(.-)<nav>')
   
   
  --    for genre, title in string.gmatch(x, '<div class="catalog%-main%-item".-<a href="http.-(/persons.-)".-<h2.->(.-)</h2>') do
    
     --   t['view'] = 'simple'
    --if image and not string.find(image, '://') then
--		image = 'https:' .. image
	--		end
	--		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
	--	end
    --	end



                    

    if genre == '/best' then
       local url = HOME .. genre
	--	if page > 1 then
			url = url 
			--.. '?page=' .. tostring(page)
	 --   end
        local x = http.getz(url)
  
          local x = string.match(x, '<div class="best%-row".-Лучшие фильмы.->(.-)</div>')
		 for url, total in string.gmatch(x,'<a href=".-(/best.-)".-<span>(.-)</span>') do

           t['view'] = 'simple'			table.insert(t, {title = 'Лучшие фильмы :' .. total, mrl = '#stream/genre=' .. url})
		end
		end

    if genre == '/best' then
       local url = HOME .. genre
	--	if page > 1 then
			url = url 
			--.. '?page=' .. tostring(page)
	 --   end
        local x = http.getz(url)
  
          local x = string.match(x, '<div class="best%-row".-Лучшие сериалы.->(.-)</div>')
		 for url, total in string.gmatch(x,'<a href=".-(/best.-)".-<span>(.-)</span>') do

           t['view'] = 'simple'			table.insert(t, {title = 'Лучшие сериалы :' .. total, mrl = '#stream/genre=' .. url})
		end
		end

if genre == '/best' then
       local url = HOME .. genre
	--	if page > 1 then
			url = url 
			--.. '?page=' .. tostring(page)
	 --   end
        local x = http.getz(url)
  
          local x = string.match(x, '<div class="best%-row".-Лучшие мультфильмы.->(.-)</div>')
		 for url, total in string.gmatch(x,'<a href=".-(/best.-)".-<span>(.-)</span>') do

           t['view'] = 'simple'			table.insert(t, {title = 'Лучшие мультфильмы :' .. total, mrl = '#stream/genre=' .. url})
		end
		end

		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


         
		
		table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/novelties'})
        table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. '/films'})
        table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serials'})
        table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/cartoons/'})
        table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/anime'})
        table.insert(t, {title = 'ТВ-шоу', mrl = '#stream/genre=' .. '/tv-show'})
   --    table.insert(t, {title = 'Актеры', mrl = '#stream/genre=' .. '/persons'})
       table.insert(t, {title = 'Кинофраншизы', mrl = '#stream/genre=' .. '/franchises'})
    --    table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections'})
		table.insert(t, {title = 'Лучшие', mrl = '#stream/genre=' .. '/best'})
     
     
     
     
        local x = http.getz(HOME)
      
                        
                            
 
 
        local x = string.match(x, '<ul class="top%-menu">(.-)</ul>')
       
        for genre, title in string.gmatch(x, '<a.-href=".-(/films.-)".->(.-)</a>') do
				table.insert(t, {title = 'ФИЛЬМЫ :' ..  tolazy(title), mrl = '#stream/genre=' .. genre})
		end
      
        local x = http.getz(HOME)
        local x = string.match(x, '<span class="top%-menu%-title">Сериалы(.-)</ul>')
       
        for genre, title in string.gmatch(x, '<a.-href=".-(/serials.-)".->(.-)</a>') do
				table.insert(t, {title = 'СЕРИАЛЫ :' ..  tolazy(title), mrl = '#stream/genre=' .. genre})
		end
       
            local x = http.getz(HOME)
          local x = string.match(x, '<span class="top%-menu%-title">Мультфильмы(.-)</ul>')
       
        for genre, title in string.gmatch(x, '<a.-href=".-(/cartoons.-)".->(.-)</a>') do
				table.insert(t, {title = 'МУЛЬТФИЛЬМЫ :' ..  tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		
           local x = http.getz(HOME)
           local x = string.match(x, '<span class="top%-menu%-title">Аниме(.-)</ul>')
       
        for genre, title in string.gmatch(x, '<a.-href=".-(/anime.-)".->(.-)</a>') do
				table.insert(t, {title = 'АНИМЕ :' ..  tolazy(title), mrl = '#stream/genre=' .. genre})
		end
        
        
	
	
	
	local x = http.getz(HOME .. '/collections?page=1')
--https://ru.kinola.life/collections?page=1
		
	local x = string.match(x, '<div class="collection%-list rows">(.-)<nav>')


		 for genre, image, title in string.gmatch(x,'<a href=".-(/collections.-)".-src="(.-)".-alt="(.-)"') do

			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre, image = image})
		end

	local x = http.getz(HOME .. '/collections?page=2')
--https://ru.kinola.life/collections?page=1
		
	local x = string.match(x, '<div class="collection%-list rows">(.-)<nav>')


		 for genre, image, title in string.gmatch(x,'<a href=".-(/collections.-)".-src="(.-)".-alt="(.-)"') do

			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end	
	
	
	
      local x = http.getz(HOME .. '/collections?page=3')
--https://ru.kinola.life/collections?page=1
		
	local x = string.match(x, '<div class="collection%-list rows">(.-)<nav>')


		 for genre, image, title in string.gmatch(x,'<a href=".-(/collections.-)".-src="(.-)".-alt="(.-)"') do

			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end
		
local x = http.getz(HOME .. '/collections?page=4')
--https://ru.kinola.life/collections?page=1
		
	local x = string.match(x, '<div class="collection%-list rows">(.-)<nav>')


		 for genre, image, title in string.gmatch(x,'<a href=".-(/collections.-)".-src="(.-)".-alt="(.-)"') do

			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end
	



	
	local x = http.getz(HOME .. '/best')
--https://ru.kinola.life/collections?page=1
		
	local x = string.match(x, '<div class="best%-row".-<h3>Лучшие фильмы</h3>(.-)</div>')


		 for genre, title in string.gmatch(x,'<a href="http.-(/best.-)".-<span>(.-)</span>') do

			table.insert(t, {title = 'Лучшие фильмы : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		
	local x = http.getz(HOME .. '/best')
--https://ru.kinola.life/collections?page=1
		
	local x = string.match(x, '<div class="best%-row".-<h3>Лучшие сериалы</h3>(.-)</div>')


		 for genre, title in string.gmatch(x,'<a href="http.-(/best.-)".-<span>(.-)</span>') do

			table.insert(t, {title = 'Лучшие сериалы : ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end	
		
--https://joyfilm.club/search?filter=1&query=%D0%A0%D0%BE%D0%B9&page=2
  
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search?filter=1&query=' .. urlencode(args.keyword) 
		--.. '&page=' .. tostring(page)
        if page > 1 then
			url = url .. '&page=' .. tostring(page)
		end

		local x = http.getz(url)
		
        for url, image, title in string.gmatch(x,'<div class="catalog%-main%-item".-href="(.-)".-src="(.-)".-class="film%-item%-title">(.-)<') do
            
	--	url = string.gsub(url, '^(.-)', 'https://api1645725968.delivembd.ws/embed/kp/')
	
      --  url = string.gsub(url, '^/', HOME)
	
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
  
  
  
        
	-- #stream/q=content&id=/catalog/vremya-priklyucheniy-dalyokie-zemli-2020-smotret-onlayn-1316565

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
		--print(x)
   --    local x = json.decode(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1 class="film%-title h2">(.-)смотреть</h1>')
		t['description'] = parse_match(x,'<meta itemprop="description" content="(.-)"')
        
        
		
		
		t['poster'] = parse_match(x,'<div class="film%-item%-image".-<img.-data%-src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
'(Страна</td>.-)</td>',  '(Жанр</td>.-)</td>', '(Актеры</td>.-)</div>'
		})

  
--https://api.alloha.tv/?token=04941a9a3ca3ac16e2b4327347bbc1&name=Чужой&year=1979
  
  
        
        
        
        
  for title3 in string.gmatch(x, '<iframe.-src="https://api.-/kp/(.-)"') do
  
url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=') 


    table.insert(t, {title = 'Zetflix', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
   
   
   for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total), mrl = url2})

       
    end
    
    
 --   local x = conn:load(url1)
        for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = http.getz(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = http.getz(url3)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end
  
  
  
  
  
  for title3 in string.gmatch(x, '<iframe.-src="https://api.-/kp/(.-)"') do
      
     url1 = string.gsub(title3, '^(.-)', 'http://movixhd.online/lite/videodb?kinopoisk_id=')
     --.. '&title=' .. title .. '&year=' .. title1 
  
  table.insert(t, {title = 'Videodb', mrl = '#stream/q=content&id=' .. url1, image = image})
		end
    
   --   local x = conn:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://movixhd.online')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://movixhd.online') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://movixhd.online') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://movixhd.online')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
  
  
  
  
       for title3 in string.gmatch(x, '<iframe.-src="https://api.-/kp/(.-)"') do

      url1 = string.gsub(title3, '^(.-)', 'http://93.183.92.183:9118/lite/mirage?kinopoisk_id=') .. '&uid=m7alois3'
    
--http://147.45.77.28:9118/lite/mirage?kinopoisk_id=386&uid=m7alois3
 
    
     local x = http.getz(url1)
     
     for  url2, url3,  total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
  
      url3 = string.gsub(url3, '\\u0026', '&')

    
       local x = http.getz(url2 .. url3)
    
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
    
       url4 = string.gsub(url4, '^(.-)', 'http://93.183.92.183:9118')
    
   --    t['view'] = 'simple'

    table.insert(t, {title = tolazy(total2) .. '(' .. tolazy(total3) .. ')', mrl = url4})

      end 
      end
     
  

      
       for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
       url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       
     url2 = string.gsub(url2, '\\u0026', '&')
     
   --  table.insert(t, {title = url2, mrl = url2})
     
      local x = http.getz(url2)


      for url3, url4, total1, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"url":"http.-(/lite/mirage)(.-)".-voice_name":"(.-)".-class="videos__item%-title">(.-серия)</div>') do

       url3 = string.gsub(url3, '^(.-)', 'http://93.183.92.183:9118')
       
     url4 = string.gsub(url4, '\\u0026', '&')
      local x = http.getz(url3 .. url4)
     local x = string.match(x, '"quality"(.-)}')
      for  total3, url5 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
   
     url5 = string.gsub(url5, '^(.-)', 'http://93.183.92.183:9118')
    
  --     t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total2) .. '(' .. total3 .. ')' .. '(' .. total1 .. ')', mrl = url5})

    end
end
end
 
  end  




		
	elseif args.q == 'play' then
	--	return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
       return video(args.url, args)
	end
--	end
	return t
end