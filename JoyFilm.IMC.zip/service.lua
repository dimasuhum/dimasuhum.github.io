-- joyfilm plugin

require('support')
require('video')
require('parser')

--HOME = 'https://joyfilm.club'

HOME = 'https://i2.joyfilm.top'
--HOME = 'https://jf7.joyfilm24.xyz'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from joyfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from joyfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2

	-- #stream/genre=serials/updated?page=

	-- #stream/genre=/anime/
	-- #stream/genre=/collection/
	-- #stream/genre=/cartoons/

	-- #stream/genre=/best/
	-- #stream/genre=/best/luchshie-filmy-2019-goda?page=
	-- #stream/genre=/?type=&genre=%D0%91%D0%BB%D0%BE%D0%BA%D0%B1%D0%B0%D1%81%D1%82%D0%B5%D1%80&year_from=&year_to=&rating_from=&rating_to=&country=&sortby=date#catalog&page=
	-- #stream/genre=/kinopremery-i-novinki?page=
	-- #stream/genre=/catalog/films/2020/

	-- #stream/genre=/serials/updated?page=
	-- #stream/genre=/serials/?sortby=hits#catalog&page=
	-- #stream/genre=/serials/?genre=%D0%9C%D0%B5%D0%BB%D0%BE%D0%B4%D1%80%D0%B0%D0%BC%D0%B0&year_from=&year_to=&rating_from=&rating_to=&country=&sortby=date#catalog&page=
	-- #stream/genre=/serials/?page=
    -- #stream/genre=/serials/?genre=%D0%B4%D1%80%D0%B0%D0%BC%D0%B0&year_from=&year_to=&rating_from=&rating_to=&countries=&sortby=date#catalog

	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		local x = http.getz(url)
		for url, image, title in string.gmatch(x,'<div class="catalog%-main%-item".-href="/(.-)".-data%-src="(.-)".-class="film%-item%-title">(.-)<') do
            
		url = string.gsub(url, '^(.-)', 'https://api1645725968.delivembd.ws/embed/kp/')
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		 
       for url, image, title in string.gmatch(x,'<div class="collection%-item%-image%-wrapper".-href="/(.-)".-data%-src="(.-)".-collection%-item%-title".-href.->(.-)<') do
      --     url = string.gsub(url, '^(.-)', HOME)
		url = string.gsub(url, '^(.-)', 'https://api1645725968.delivembd.ws/embed/kp/')
			--image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
    	 for url, image, title in string.gmatch(x,'<div class="catalog%-full%-item".-href="/(.-)".-data%-src="(.-)".-class="film%-item%-title">(.-)<') do 
        --   url = string.gsub(url, '^(.-)', HOME_SLASH)
           url = string.gsub(url, '^(.-)', 'https://api1645725968.delivembd.ws/embed/kp/')
			--image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    --    if genre == '/selection/' then
        for id, image, title in string.gmatch(x,'<div class="collection%-list rows".-<a href="(selection.-)".-data%-src="(.-)" alt="(.-)"') do
           -- url = string.gsub(url, '^/', HOME_SLASH) 
		
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. '/' .. id, image = image})
		end
	--	end
   --     if genre == '/selection/' then
        for id, image, title in string.gmatch(x,'class="collection%-list%-item%-title".-<a href="(selection.-)".-data%-src="(.-)" alt="(.-)"') do
           -- url = string.gsub(url, '^/', HOME_SLASH) 
		
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. '/' .. id, image = image})
		end
	--	end
     --    if genre == '/collection/' then
		 for id, image, title in string.gmatch(x,'<div class="collection%-list rows".-<a href="(collection.-)" class="collection%-list%-item".-data%-src="(.-)".-<span>(.-)</span>') do
           -- url = string.gsub(url, '^/', HOME_SLASH) 
		
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=/' .. id, image = image})
		end
	--	end
	--	if genre == '/collection/' then
		 for id, image, title in string.gmatch(x,'class="collection%-list%-item%-title".-<a href="(collection.-)" class="collection%-list%-item".-data%-src="(.-)".-<span>(.-)</span>') do
           -- url = string.gsub(url, '^/', HOME_SLASH) 
		
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=/' .. id, image = image})
		end
	--	end
     --   if genre == '/person/' then
        for id, image, title in string.gmatch(x, '<div class="catalog%-main%-item".-<a href="(person.-)".-src=.-(//.-)".-class="film%-item%-title">(.-)<') do
           -- url = string.gsub(url, '^/', HOME_SLASH) 
		
			image = string.gsub(image, '^(.-)', 'https:')
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. '/' .. id, image = image})
		end
	--	end
	--    if genre == '/best' then
		 for id, title in string.gmatch(x,'<a href="(/best/.-)".-<span>(.-)</span') do
           -- url = string.gsub(url, '^/', HOME_SLASH) 
		
		--	image = string.gsub(image, '^//', 'https://')
           t['view'] = 'simple'
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. id})
		end
	--	end
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
		
		table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/kinopremery-i-novinki'})
        table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. '/films/'})
        table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serials/'})
        table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/cartoons/'})
        table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/anime/'})
        table.insert(t, {title = 'ТВ-шоу', mrl = '#stream/genre=' .. '/tv-show'})
        table.insert(t, {title = 'Актеры', mrl = '#stream/genre=' .. '/person/'})
        table.insert(t, {title = 'Кинофраншизы', mrl = '#stream/genre=' .. '/selection/'})
        table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collection/'})
		table.insert(t, {title = 'Лучшие', mrl = '#stream/genre=' .. '/best'})
        local x = http.getz(HOME)
      
     --   local x = string.match(x, '<ul class="top%-menu%-2">(.-)</ul>')
       
        for genre, title in string.gmatch(x, '<a href="(films/.-/)".->(.-)</a>') do
				table.insert(t, {title = 'ФИЛЬМЫ :' ..  tolazy(title), mrl = '#stream/genre=/' .. genre})
		end
      --  local x = http.getz(HOME)
    --    local x = string.match(x, '<ul class="top%-menu%-2">(.-)</ul>')
       
        for genre, title in string.gmatch(x, '<a href="(serials/.-/)".->(.-)</a>') do
				table.insert(t, {title = 'СЕРИАЛЫ :' ..  tolazy(title), mrl = '#stream/genre=/' .. genre})
		end
       --     local x = http.getz(HOME)
    --       local x = string.match(x, '<ul class="top%-menu%-2">(.-)</ul>')
       
        for genre, title in string.gmatch(x, '<a href="(cartoons/.-/)".->(.-)</a>') do
				table.insert(t, {title = 'МУЛЬТФИЛЬМЫ :' ..  tolazy(title), mrl = '#stream/genre=/' .. genre})
		end
		
         --  local x = http.getz(HOME)
      --     local x = string.match(x, '<ul class="top%-menu%-2">(.-)</ul>')
       
        for genre, title in string.gmatch(x, '<a href="(anime/.-/)".->(.-)</a>') do
				table.insert(t, {title = 'АНИМЕ :' ..  tolazy(title), mrl = '#stream/genre=/' .. genre})
		end
        
        
	
		
		
		
		
--https://joyfilm.club/search?filter=1&query=%D0%A0%D0%BE%D0%B9&page=2
  
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search?filter=1&query=' .. urlencode(args.keyword) 
		--.. '&page=' .. tostring(page)
        if page > 1 then
			url = url .. '&page=' .. tostring(page)
		end

		local x = http.getz(url)
		
        for url, image, title in string.gmatch(x,'<div class="catalog%-main%-item".-href="/(.-)".-src="(.-)".-class="film%-item%-title">(.-)<') do
            
		url = string.gsub(url, '^(.-)', 'https://api1645725968.delivembd.ws/embed/kp/')
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
  
  
  
        
	-- #stream/q=content&id=/catalog/vremya-priklyucheniy-dalyokie-zemli-2020-smotret-onlayn-1316565

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1 class="film%-title h2">(.-)</h1>')
		t['description'] = parse_match(x,'<p class="m%-0">(.-)</p>')
		t['poster'] = parse_match(x,'<div class="film%-item%-image".-<img.-data%-src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
'(Дата выхода</td>.-)</td>',  '(Жанр</td>.-)</td>', '(Режиссеры</td>.-)</div>', '(Актеры</td>.-)</div>', '(Страна</td>.-)</td>', 
			'(Продолжительность:</u>.-)<br', '(Перевод:</u>.-)<br', '(В ролях:</u>.-)<br'
		})

        for title, url in string.gmatch(x, 'title: "(.-)".-hls: "(https://.-m3u8)"') do
        --	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end

     	for url, title in string.gmatch(x, '"hls":"(https.-m3u8)".-"title":"(.-)"') do

			print(url)
        t['view'] = 'simple'
      --  t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end	
       for title, url, total in string.gmatch(x, '"episode".-"hlsList".-"(.-)".-(https.-)".-"title".-"(.-)"') do

			print(url)
        t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb='})
        end
		
		for title, url, total in string.gmatch(x, '"episode".-"hlsList".-,"(.-)".-(https.-)".-"title".-"(.-)"') do
			print(url)
         t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb='})
        end

        
         
			
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-,"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end
		
	elseif args.q == 'play' then
	--	return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
       return video(args.url, args)
	end
--	end
	return t
end