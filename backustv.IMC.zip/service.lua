-- backustv plugin

require('support')
require('video')
require('parser')

HOME = 'https://backustv.ru'

HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from backustv plugin')
	return 1
end

function onUnLoad()
	print('Bye from backustv plugin')
end

function onCreate(args)
	local t = {view = 'grid_large', type = 'folder'}
--	t['menu'] = {}

	 -- table.insert(t['menu'], {title = 'BACKUSTV',mrl = '#stream/q=content&id=' .. 'https://backustv.ru/guides/original.xml', image = 'https://backustv.ru/test/logo1.png'})
--	 end 
 --   if args.q ~= 'genres' then
--	  table.insert(t['menu'], {title = 'BACKUSTV Dark',mrl = '#stream/q=content&id=' .. 'https://backustv.ru/guides/dark.xml', image = 'https://backustv.ru/test/logo2.png'})

	if not args.q then
      --  local url = 'https://stream.backustv.ru/live/btv/index.m3u8'

       local genre = args.genre or '/js/app~d0ae3f07.4295e1e4.js'
     	local url = HOME .. genre


			url = url 
		local x = http.getz(url)

        for title, image, url in string.gmatch(x, 'id:.-title:"(.-)".-image:"(.-png).-stream:.-(https://.-m3u8)"') do

          image = string.gsub(image, '^(.-)', 'https:')

         table.insert(t, {title = title, mrl = url, image = image})
        
		end
	
	

        
		
    --    for title, image, url in string.gmatch(x, '{id:".-title:"(Dark)".-image:"(https.-png).-stream:.-(https://.-m3u8)"') do

     --    table.insert(t, {title = title, mrl = url, image = image})
        
--		end
		
    --    for title, image, url in string.gmatch(x, '{id:.-title:"(Music)",image:"(https.-png)",stream:"(https://.-m3u8)",guide:"/guides/btv3.json"}],
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'

        local x = http.getz(HOME)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
     -- local x = string.match(x, 'каналы.-<ul class="submenu">(.-)</ul>')
        for title, total in string.gmatch(x, 'FileName="D:(.-).mkv.-Time="(.-)"') do
        
            title = string.gsub(title, '\\BACKUSTV\\КИНО\\', '')
			table.insert(t, {title = title .. ' ' .. (total)})
		end

	-- #stream/q=content&id=http://tv.tivix.co/24-cartoon-network.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		
          local x = http.getz(HOME .. '/js/app~d0ae3f07.3fc0a884.js')
        for title, image, url in string.gmatch(x, '{id:".-title:"(Original)".-image:"(https.-png).-stream:.-(https://.-m3u8).-,guide:".-xml"') do


     --   image = string.gsub(image, '^(.-)', HOME .. '/')
       --  t['view'] = 'simple'
         table.insert(t, {title = 'Смотреть' .. ' ' .. title, mrl = url, image = image})
        
		end
		
        for title, image, url in string.gmatch(x, '{id:".-title:"(Dark)".-image:"(https.-png).-stream:.-(https://.-m3u8).-,guide:".-xml"') do


     --   image = string.gsub(image, '^(.-)', HOME .. '/')
       --  t['view'] = 'simple'
         table.insert(t, {title = 'Смотреть' .. ' ' .. title, mrl = url, image = image})
        
         local x = http.getz(args.id)
         for title, total in string.gmatch(x, 'FileName="D:(.-).mkv.-Time="(.-)"') do
        
            title = string.gsub(title, '\\BACKUSTV\\КИНО\\', '')
           t['view'] = 'simple'
			table.insert(t, {title = title .. ' ' .. (total)})
		end
        
        
        
        
		end
	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end