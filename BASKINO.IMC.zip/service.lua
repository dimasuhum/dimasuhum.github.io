-- baskino plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate


local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'



local HOME = 'https://baskino.film'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



--https://voidboost.net/embed/tt17371078,5085015
--HOME = 'http://baskino.me'
--HOME = 'https://baskino.film'
--HOME_SLASH = HOME .. '/'


function onLoad()
	print('Hello from baskino plugin')
	return 1
end

function onUnLoad()
	print('Bye from baskino plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	
	-- #stream/page=2

	if not args.q then
		local page = tonumber(args.page or 1)
         
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		

      --  local x = http.getz(url)
        
       local x = conn:load(url)
        
      --  x = iconv(http.get(url), 'utf-8//IGNORE', 'UTF-8')
      --  x = iconv(http.get(url), 'windows-1251', 'UTF-8')		
        for url,  image, title  in string.gmatch(x, '<div class="postcover".-<a href="(.-)".-src="(.-)".-alt="(.-)"') do
		--	url = string.gsub(url, '^(.-)', 'https:')
        image = string.gsub(image, '^/', HOME_SLASH)
			
			
		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
		
          for  image, url,  title  in string.gmatch(x, '<div class="line".-<img src="(.-)".-<a href="http://.-(/.-)">(.-)<') do
		--	url = string.gsub(url, '^(.-)', 'https:')
        image = string.gsub(image, '^/', HOME_SLASH)
			
			
		  table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
		end
		
        for url, title, total  in string.gmatch(x, '<a href="http://baskino.-(/actors/.-)">(.-)<.->(.-)<') do
		--	url = string.gsub(url, '^(.-)', 'https:')
        image = string.gsub(image, '^/', HOME_SLASH)
			
          t['view'] = 'simple'
		  table.insert(t, {title = tolazy(title) .. total, mrl = '#stream/genre=' .. url, image = image})
		end


		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


        table.insert(t, {title = 'Фильмы по Категориям', mrl = '#stream/genre=' .. '/filmy-po-kategoriyam.html'})
        table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/new/'})
		table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serial/'})
      --  table.insert(t, {title = 'TOP 250', mrl = '#stream/genre=' .. '/top/'})
		table.insert(t, {title = 'Актеры', mrl = '#stream/genre=' .. '/actors/'})
     --   table.insert(t, {title = 'Збірки фільмів', mrl = '#stream/genre=' .. '/collections.html'})
     --   table.insert(t, {title = 'Вимкнути світло', mrl = '#stream/genre=' .. '/index.php?action_skin_change=yes&skin_name=dark'})
        
      
       --   local x = http.getz(HOME)

          local x = conn:load(HOME)


        local x = string.match(x, '<ul class="sf%-menu">(.-)</ul>')
        for gente, title in string.gmatch(x, '<a href="(/films.-)">(.-)</a>') do
			table.insert(t, {title = 'ФИЛЬМЫ :' .. tolazy(title), mrl = '#stream/genre=' .. gente})
		end
  
  
--http://baskino.me/index.php?story=рок&do=search&subaction=search
--  https://baskino.film/index.php?story=Рокки&do=search&subaction=search
  
        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)


	--	local x = http.getz(url)
		
        local x = conn:load(url)
		
		
		
        for url,  image, title  in string.gmatch(x, '<div class="postcover".-<a href="(.-)".-<img.-src=.-(/.-jpg).-alt="(.-)"') do
      --   url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
        
	-- #stream/q=content&id=https://films-2020.ru/1610-britanija-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	--	local x = http.getz(args.id)
        local x = conn:load(args.id)
		
		
		
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
          t['ref'] = args.id
	
         -- x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1>(.-)</h1>')
		t['description'] = parse_match(x, '<div class="description".-style="display:inline.->(.-)<br>')
			t['poster'] = args.p

		--	t['poster'] = parse_match(x,' <div class="fposter".-src="(.-)"')
	--	if t['poster'] then
		--	t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
		
			
	    	t['annotation'] = parse_array(x, { 
	    	'(Оригинальное название:</td>.-)</td>',  '(Год:</td>.-)</a>', '(Страна:</td>.-)</td>', '(Слоган:</td>.-)</td>', '(Режиссер:</td>.-)</a>', '(Жанр:</td>.-)</td>', '(В главных ролях:</td>.-)</td>',

})


--https://cors.nb557.workers.dev:8443/
--https://cors557.deno.dev/
      

       for url  in string.gmatch(x, '<td itemprop="name">(.-)</td>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    

    
    
         local x = http.getz(url)
         for url in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
  


	 print(url)
	
    	url = string.gsub(url, '^(.-)', 'https://cdnmovies-stream.online/kinopoisk/') .. '/iframe?domain=kinobd.net'
    	
    	

			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
			
		end
        end
        
        
      --   local x = http.getz(url)
         
         for url in string.gmatch(x, 'player.-#2(.-)"') do
       
       
         print(url)

         url = string.gsub(url, '\\/\\/Ni14UVdNaDdlcnRMcDh0X005aHVVRGsxTTBWcllK', '')
         url = string.gsub(url, '\\/\\/d05wMndCVE5jUFJRdlRDMF9DcHhDc3FfOFQxdTlR', '')
         url = string.gsub(url, '\\/\\/bWQtT2QyRzlSV09nU2E1SG9CU1NiV3JDeUlxUXlZ', '')
         url = string.gsub(url,'\\/\\/a3p1T1lRcUJfUVNPTC14ek5fS3oza2tna0hoSGl0', '')
         url = string.gsub(url,'VfR0xFc1h4bnBVNExqamQwUmVZLVZI', '')
         url = string.gsub(url,'\\/\\/UnlUd3RmMT', '')




         url=http.urldecode(base64_decode(url))
  


        
        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(240p)](http.-.m3u8)') do
			

           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
      
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')

				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        
		        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(360p)](http.-.m3u8)') do
			
title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')

            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
			
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(480p)](http.-.m3u8)') do
			
			
title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')

			
           --  title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(720p)](http.-.m3u8)') do
			
title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')

			
			
			
         --    title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(1080p)](http.-.m3u8)') do
			
title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')

			
			
			
         --    title = tolazy(title)
            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        end












       for url  in string.gmatch(x, '<td itemprop="name">(.-)</td>') do
       
      --  for url  in string.gmatch(x, '<h1.->(.-)</h1>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
          local x = http.getz(url)
          for url  in string.gmatch(x, '{"current_page".-"kinopoisk_id":(.-),') do
    
    
    --    for url  in string.gmatch(x, 'var kinopoisk_id.-= (.-);') do
       print(url)
       

		 url = string.gsub(url, '^(.-)', 'https://videocdn.tv/api/short?api_token=bVycnMuy5Dfe0IkzXt87eeVa9EtIkUl5&kinopoisk_id=')
       
        local x = http.getz(url)
      for  url  in string.gmatch(x, '"iframe_src":"(.-)"') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})

   --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})

		end
   end
    end
  

  
  
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(360p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       
       
        for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(480p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
  
      for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(720p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(1080p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
	
		
       for title, url  in string.gmatch(x, 'movie.-%[(360p)](-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
     	 for title, url  in string.gmatch(x, 'movie.-%[(480p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
	for title, url  in string.gmatch(x, 'movie.-%[(720p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
		
        for title, url  in string.gmatch(x, 'movie.-%[(1080p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end



     --  <iframe data-src="https://vid1712769373.vb24131crasosnemesis.com/movie/a59d40a4769ec7677688f52ef5bea9fe/iframe"


--http://divantv.zz.mu/kinomovie/collaps.master.m3u.php?kp_id=

--http://divantv.zz.mu/kinomovie/voidboost.net.php?Urlpage=https://voidboost.net/embed/tt26491631


          for url in string.gmatch(x, '<iframe src="(https://voidboost.-)"') do
        
    --    url = string.gsub(url, '^(.-)', 'http://divantv.zz.mu/kinomovie/voidboost.net.php?Urlpage=')
        
        table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end
		

    
    
    
    
    
           local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do

            
          local slist=string.match(x, '<select name="season".->(.-)</select>')
          
           if slist then
          
             for url1, title in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
             

             
            local slist=string.match(x, '<select name="episode".->(.-)</select>')
            
           if slist then
            for url2, total in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do
         

          t['view'] = 'simple'
        	table.insert(t, {title = title .. ':' .. (total) .. ' (' .. total1 .. ')', mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
			end
			end
   	    	end	
   	    	end
            end	
   	    	end
    
    
--https://voidboost.net/movie/149fa08a44c989e65e37289b4c796736/iframe?h=baskino.me

          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
             
             
          t['view'] = 'simple'
        	table.insert(t, {title = total1, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/movie/' .. url3 .. '/iframe?'})
             
            end
            end
    
          
	--		for url1, title in string.gmatch(x, '<option value="(.-)".->(Сезон.-)</option>') do
	--		end
     --     local x = string.match(x, '<select name="episode".->(.-)</select>')
			
     --      for url2, total in string.gmatch(x, '<option value="(.-)".->(Серия.-)</option>') do
	--	   end
            
         
    --      local x = string.match(x, '<select name="translator.->Перевод.->(.-)</div>')
      --      for url3, total1 in string.gmatch(x, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
    
         
         
       -- 	table.insert(t, {title = 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
	--		end

   		
   		
       for url  in string.gmatch(x, 'var CDNplayerConfig.-file.-#2(.-)\'') do
     --    print(url)
		 url = string.gsub(url, '//_//', '')
         url = string.gsub(url, 'Xl4jQEAhIUAjISQ=', '')
         url = string.gsub(url, 'JCQkIyMjIyEhISEhISE=', '')
         url = string.gsub(url, 'QCFeXiFAI0BAJCQkJCQ=', '')
         




         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, url in string.gmatch(url, '(360p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if url then
			for title, url in string.gmatch(url, '(480p).-(http.-.mp4)') do
             t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
				
               table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(720p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p)].-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p Ultra).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end
			end
			
			
         
			
			
	elseif args.q == 'play' then
	--	return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
       return video(args.url, args)
	end

	return t
end