-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate




local HOME = 'https://1.mediamaniya.site'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH





function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)




	local t = {view = 'grid', type = 'folder'}
		t['menu'] = {}
	if args.q ~= 'genres' then
--		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

--https://varline.store/api/matchlist?is_complete=false&skip=0&limit=100


	if not args.q then

--https://1.mediamaniya.site/tv/?page6

   local url = HOME .. '/tv/?page1'

        local x = conn:load(url)

	if x then
	
    for id, image, title  in string.gmatch(x, '<div id="entryID.-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do

   id  = string.gsub(id, '^(.-)', HOME)
	image  = string.gsub(image, '^(.-)', HOME)
	
	table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. id, image = image})

end
end

local url = HOME .. '/tv/?page2'

        local x = conn:load(url)

	if x then
	
    for id, image, title  in string.gmatch(x, '<div id="entryID.-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do

   id  = string.gsub(id, '^(.-)', HOME)
	image  = string.gsub(image, '^(.-)', HOME)
   
table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. id, image = image})

end
end
          
local url = HOME .. '/tv/?page3'

        local x = conn:load(url)

	if x then
	
    for id, image, title  in string.gmatch(x, '<div id="entryID.-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do

   id  = string.gsub(id, '^(.-)', HOME)
	image  = string.gsub(image, '^(.-)', HOME)
   
table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. id, image = image})

end
end


local url = HOME .. '/tv/?page4'

        local x = conn:load(url)

	if x then
	
    for id, image, title  in string.gmatch(x, '<div id="entryID.-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do

   id  = string.gsub(id, '^(.-)', HOME)
	image  = string.gsub(image, '^(.-)', HOME)
   
table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. id, image = image})

end
end

	
local url = HOME .. '/tv/?page5'

        local x = conn:load(url)

	if x then
	
    for id, image, title  in string.gmatch(x, '<div id="entryID.-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do

   id  = string.gsub(id, '^(.-)', HOME)
	image  = string.gsub(image, '^(.-)', HOME)
   
table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. id, image = image})

end
end
	
local url = HOME .. '/tv/?page6'

        local x = conn:load(url)

	if x then
	
    for id, image, title  in string.gmatch(x, '<div id="entryID.-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do

   id  = string.gsub(id, '^(.-)', HOME)
	image  = string.gsub(image, '^(.-)', HOME)
 
   table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. id, image = image})

end
end
	
	
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 
-- table.insert(t, {title = 'Общие', mrl = '#stream/q=channels&id=' .. 'Общие', image = image})
 
 
 
table.insert(t, {title = 'Кино', mrl = '#stream/q=channels&id=' .. 'кино', image = image})

table.insert(t, {title = 'Спорт', mrl = '#stream/q=channels&id=' .. 'спорт', image = image})

table.insert(t, {title = 'Познавательные', mrl = '#stream/q=channels&id=' .. 'познавательные', image = image})

table.insert(t, {title = 'Развлекательные', mrl = '#stream/q=channels&id=' .. 'развлекательные', image = image})

table.insert(t, {title = 'Музыка', mrl = '#stream/q=channels&id=' .. 'музыка', image = image})

table.insert(t, {title = 'Детские', mrl = '#stream/q=channels&id=' .. 'детские', image = image})

table.insert(t, {title = 'Новости', mrl = '#stream/q=channels&id=' .. 'новости', image = image})

table.insert(t, {title = 'Россия', mrl = '#stream/q=channels&id=' .. 'россия', image = image})

table.insert(t, {title = 'Украина', mrl = '#stream/q=channels&id=' .. 'українські', image = image})

table.insert(t, {title = 'Беларусь', mrl = '#stream/q=channels&id=' .. 'беларускія', image = image})

table.insert(t, {title = 'HD', mrl = '#stream/q=channels&id=' .. 'HD', image = image})


table.insert(t, {title = 'HD Orig', mrl = '#stream/q=channels&id=' .. 'HD Orig', image = image})

--table.insert(t, {title = 'UHD', mrl = '#stream/q=channels&id=' .. 'UHD', image = image})

table.insert(t, {title = '4K', mrl = '#stream/q=channels&id=' .. '4K', image = image})

table.insert(t, {title = 'Другие', mrl = '#stream/q=channels&id=' .. 'другие', image = image})

table.insert(t, {title = 'Взрослые', mrl = '#stream/q=channels&id=' .. 'взрослые', image = image})

    elseif args.q == 'channels' then

--local url = 'https://tv.alcopa.cc' .. args.id

 local url = 'https://tv.alcopa.cc/api/iptv/channels?playlist_id=all&group=' .. urlencode(args.id) .. '&page=1&limit=100000'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; alpac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; _lampac_auth=a46f8a8a-8878-4fa5-8554-8296ba62260d; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}

		local x = http.getz(url, headers)


--local x = json.decode(x)

	--	for _, v in ipairs(x['channels']) do
	
	for id, name, image in string.gmatch(x,'{"id":"(.-)","name":"(.-)".-"logo":"(.-)"') do
	--		local x = json.decode(x)

--		for _, v in ipairs(x['channels']) do
			local url1 = 'https://tv.alcopa.cc/api/iptv/play?channel_id=' .. id
	
	--t['view'] = 'simple'
	
	table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. url1, image = image})

end

--m3u+https://1.mediamaniya.site/tv-channels/MAIN/1_Kanal/online.html?autoplay=1

--https://zabava-htlive.cdn.ngenix.net/hls/CH_1TVSD/variant.m3u8

--<iframe src="/tv-channels/MAIN/1_Kanal/online.html?autoplay=1"



--var player = new Playerjs({id:"player", file:"https://bstelevision.com/proxy.php?url=141.95.55.143/CH3821/index.m3u8 or https://zabava-htlive.cdn.ngenix.net/hls/CH_NTV/variant.m3u8 

--var player = new Playerjs({id:"player", file:"https://bstelevision.com/proxy.php?url=http://pl.online24.pm/play/2025/F6E1DD42544DD10/video.m3u8 or https://cors.campware.io/ukr2.ukrainske.tv/2025/video.m3u8 or

--https://bstelevision.com/proxy.php?url=http://pl.online24.pm/play/2025/F6E1DD42544DD10/video.m3u8

elseif args.q == 'channel' then

 local x = conn:load(args.id)
 
 local iframe = string.match(x, '<iframe.-(/tv-channels/MAIN/1_Kanal/.-)"')
 
 if iframe then
 
 url = string.gsub(iframe, iframe, 'https://ok.ru/videoembed/1115050286838?autoplay=1')
 
 
--local url = 'https://ok.ru/videoembed/1115050286838?autoplay=1'

if url then

 local headers = {
    ["Host"] = "ok.ru",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36"
}
   
   local x = http.getz(url, headers)
   
local file = string.match(x,'hlsMaster.-(http.-)"')

if file then

local video1 = file

    return {view = 'playback', mrl = video1, seekable = 'true', direct = 'true'}	

end
end  
end  
  
  
  
  
 
 local iframe1 = string.match(x, '<iframe.-(/tv-channels/MAIN/Russia_1.-)"')
 
 if iframe1 then
 
url = string.gsub(iframe1, iframe1, 'https://zabava-htlive.cdn.ngenix.net/hls/CH_RUSSIA1/variant.m3u8')
 

if url then

local video2 = url

    return {view = 'playback', mrl = video2, seekable = 'true', direct = 'true'}	

end
end  
 
 
 
 
 local file = string.match(x,'Playerjs.-file:.-http.-(stream.-m3u8)')
   
   if file then
    --    t['view'] = 'simple'
local video2 = 'http://' .. file


    return {view = 'playback', mrl = video2, seekable = 'true', direct = 'true'}	

end
 
 
 
  
  if not video2 then
  
  local file = string.match(x,'Playerjs.-file:.-(zabava.-m3u8)')
   
   if file then
  
  local video3 = 'http://' .. file
   
   return {view = 'playback', mrl = video3, seekable = 'true', direct = 'true'}	

end
end


if not video3 then

local file = string.match(x,'Playerjs.-file:.-(https://s70378.-m3u8)')
   
   if file then
 
 local video4 = file 
   
   return {view = 'playback', mrl = video4, seekable = 'true', direct = 'true'}	

end
end

if not video4 then

   local file = string.match(x,'Playerjs.-file:.-https://bstelevision.com.-url=(.-m3u8)')
   
   
   if file then
  
  local video5 = file
   
   return {view = 'playback', mrl = video5, seekable = 'true', direct = 'true'}	

end
  end 
 
if not video5 then


local file = string.match(x,'Playerjs.-file.-(https://ngtrk.-m3u8)')

if file then
    
    local video6 = file

    return {view = 'playback', mrl = video6, seekable = 'true', direct = 'true'}	

end
end

if not video6 then


local file = string.match(x,'Playerjs.-file.-"http.-(ukr2.-m3u8)')

if file then
local video7 = 'http://' .. file

    return {view = 'playback', mrl = video7, seekable = 'true', direct = 'true'}	

end
end


if not video7 then


--local x = conn:load(args.id)

local url = string.match(x, '<iframe.-src.-(https://ok.ru/videoembed/.-)"')

if url then

 local headers = {
    ["Host"] = "ok.ru",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36"
}
   
   local x = http.getz(url, headers)
   
local file = string.match(x,'hlsMaster.-(http.-)"')

if file then
local video8 = file

    return {view = 'playback', mrl = video8, seekable = 'true', direct = 'true'}	

end
end
end


	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
--end
	end
	return t
end