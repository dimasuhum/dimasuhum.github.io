-- kinoteatr.kg plugin

require('support')
require('video')
require('parser')

HOME = 'https://filmpro.tv'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinoteatr.kg plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinoteatr.kg plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/filmy-2023
	
       
	if not args.q then
    
		local page = tonumber(args.page or 1)
        local genre = args.genre or '/'
	--	local genre = args.genre or '/index.php/film/60fps'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		local x = http.getz(url)
		

	
		for url, title, image  in string.gmatch(x, '<div class="kino%-title".-<a href="(.-)" class="kino%-h">(.-)<.-<img src="(.-)"') do

            image = string.gsub(image, '^/', HOME_SLASH)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		

    	
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
	
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		



        
        
        
        
        local x = http.getz(HOME)
        

        local x = string.match(x, '<ul class="second%-menu clearfix".-Главная</a>(.-)</ul>')
		for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. '/'}) 
		end
        
        
        
       table.insert(t, {title = 'Драма', mrl = '#stream/genre=' .. '/dramy/'})
        
        table.insert(t, {title = 'Фэнтези', mrl = '#stream/genre=' .. '/fentezi/'})
        
        table.insert(t, {title = 'Военный', mrl = '#stream/genre=' .. '/voennye/'})
        
        table.insert(t, {title = 'Исторический', mrl = '#stream/genre=' .. '/istoriya/'}) 
   
        table.insert(t, {title = 'Детектив', mrl = '#stream/genre=' .. '/detektivy/'})
        
        table.insert(t, {title = 'Комедия', mrl = '#stream/genre=' .. '/komedii/'})
        
        table.insert(t, {title = 'Боевик', mrl = '#stream/genre=' .. '/boevik/'})
        
        table.insert(t, {title = 'Триллер', mrl = '#stream/genre=' .. '/trillery/'}) 
        
        
       table.insert(t, {title = 'Приключения', mrl = '#stream/genre=' .. '/priklucheniya/'})
        
        table.insert(t, {title = 'Мелодрама', mrl = '#stream/genre=' .. '/melodramy/'})
        
        table.insert(t, {title = 'Ужасы', mrl = '#stream/genre=' .. '/uzhasy/'})
        
        table.insert(t, {title = 'Криминал', mrl = '#stream/genre=' .. '/kriminal/'}) 
        
    
        table.insert(t, {title = 'Биография', mrl = '#stream/genre=' .. '/biografiya/'})
        
        table.insert(t, {title = 'Фантастика', mrl = '#stream/genre=' .. '/fantastika/'}) 
        
        
        
        
        local x = http.getz(HOME)
        
        table.insert(t, {title = '2024', mrl = '#stream/genre=' .. '/filmy-2024/'}) 

        local x = string.match(x, '<ul class="main%-menu clearfix">(.-)</ul>')
		for genre, title in string.gmatch(x, '<a href="(/.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. '/'}) 
		end
		

        
      
      
--https://filmpro.tv/index.php?story={searchTerms}&do=search&subaction=search

	
	
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)


		local x = http.getz(url)
		
        for url, image, title  in string.gmatch(x, '<a class="sres%-wrap clearfix" href="(.-)".-<img src="(.-)".-<h2>(.-)</h2>') do

            image = string.gsub(image, '^/', HOME_SLASH)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
	
	
		

	-- #stream/q=content&id=/28525-pereval-dyatlova.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h2 class="text%-center p%-3">(.-)/.-</h2>')
		t['description'] = parse_match(x,'<div class="kino%-desc full%-text clearfix">(.-)<br>')
         t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Год:</strong>.-)</p>','(Страна:</strong>.-)</span>','(Жанр:</strong>.-)</span>','(Актеры:</strong>.-)</span>'
		})
       -- x = string.gsub(x, 'Скачать', '')
    
    
    
      for url in string.gmatch(x, 'var player = new Playerjs.-id:"player".-file:"(/video/film/.-)"') do
    
    url = string.gsub(url, '^(.-)', 'https://kinorkn.com')

    
       table.insert(t, {title = 'Смотреть', mrl = url})
		end
     
     
 --    for title in string.gmatch(x, '{"title":"(.-сезон)","folder"') do
     
     for total, url in string.gmatch(x, '{"title":"(.-серия)","file":"(/video/serial.-)"') do
  
  
  
      total = string.gsub(total, '"folder":%[{"title":"', '')
      total = string.gsub(total, '"', '')
       url = string.gsub(url, '^(.-)', 'https://kinorkn.com')
  
     table.insert(t, {title = tolazy(total), mrl = url})
		end
  --   end
       
        for url in string.gmatch(x, '<iframe.-src="(https://www.youtube.com.-)"') do

          table.insert(t, {title = 'Трейлер', mrl = url})
		end
		
	elseif args.q == 'play' then
        
       -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)
	--end
	end
	return t
end