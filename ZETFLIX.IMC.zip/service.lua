-- zetflix plugin

require('support')
require('video')
require('parser')
require('client')



--http://fxmlparsers.in.net/VilkaDB/?id=tmdb&media_type=movie&tid=348&torr=Alien(1979)

--%D0%A7%D1%83%D0%B6%D0%BE%D0%B9

--http://fxmlparsers.in.net/http://videocdn.tv/?id=tmdb&media_type=movie&tid=426063&torr=%D0%9D%D0%BE%D1%81%D1%84%D0%B5%D1%80%D0%B0%D1%82%D1%83

--{"title":".-"stream_url".-"parser":"(.-)"

--http://148.72.155.49:9117

--http://fxmlparsers.in.net/http://videocdn.tv/?getfile=aHR0cDovLzE0OC43Mi4xNTUuNDk6OTExNy9kbC9tZWdhcGVlci8/amFja2V0dF9hcGlrZXk9MzlmbWp0ODR6dzdoM3k0NTllNWNsbm81NjFtajY1N3AmcGF0aD1RMlpFU2poQ1VqWmxlWGR4YTJoU1JIWk5RMWN0Tm1OMmRVVmtPRUpEUzNGU1ltSk9TMGx0ZVZsSE56VTNiVXBTVlVoS2FtY3pRbk4zYVVZMExXbE1iUzFSUTJadGRsODFMVFIxYUhwMlRqSjBjMUZqTkZKeVlVNHpZbXRSY0dwQ2IxQlFURk5hWXpoalF6ZHNVa05uTTFOQlNqQjVZbmhNVW5wSFJGWmpiSGxLYzJrM1ZFODNZbkJmWjNOYVQxUk1SV294V1V0bk5qaFpOREZOWlVsdVVFbElhMDV4Y1ZKbU0wMWZkRGxFYWtNJmZpbGU9JUQwJTlEJUQwJUJFJUQxJTgxJUQxJTg0JUQwJUI1JUQxJTgwJUQwJUIwJUQxJTgyJUQxJTgzK18rTm9zZmVyYXR1KygyMDI0KStXRUItREwrMTA4MHArJUQwJUJFJUQxJTgyK05ldy1UZWFtKyU3QytQKyU3QytIRFJlemthK1N0dWRpbw==


--http://148.72.155.49:9117/dl/megapeer/?jackett_apikey=39fmjt84zw7h3y459e5clno561mj657p&path=Q2ZESjhCUjZleXdxa2hSRHZNQ1ctNmN2dUVkOEJDS3FSYmJOS0lteVlHNzU3bUpSVUhKamczQnN3aUY0LWlMbS1RQ2Ztdl81LTR1aHp2TjJ0c1FjNFJyYU4zYmtRcGpCb1BQTFNaYzhjQzdsUkNnM1NBSjB5YnhMUnpHRFZjbHlKc2k3VE83YnBfZ3NaT1RMRWoxWUtnNjhZNDFNZUluUElIa05xcVJmM01fdDlEakM&file=%D0%9D%D0%BE%D1%81%D1%84%D0%B5%D1%80%D0%B0%D1%82%D1%83+_+Nosferatu+(2024)+WEB-DL+1080p+%D0%BE%D1%82+New-Team+%7C+P+%7C+HDRezka+Studio

--https://jacred.xyz/api/v1.0/torrents?search=Alien1979&apikey=39fmjt84zw7h3y459e5clno561mj657p&exact=true

--http://fxmlparsers.in.net/VilkaDB/?id=zetflix&act=https://zeflix.online/films/policejskij-iz-beverli-hillz-4/


--http://fxmlparsers.in.net/VilkaDB/?id=zetflix&act=https://zeflix.online/films/obeit/


--http://kb-team.club/?do=/plugin&bid=zetflix-zetflix&act=search&search=Ручная кладь&box_mac=b8bc5bf8dea3




HOME = 'https://hdzetflix.shop'
HOME_SLASH = HOME .. '/'
--HOME_SLASH1 = HOME1 .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

function onLoad()
	print('Hello from zetflix plugin')
	return 1
end

function onUnLoad()
	print('Bye from zetflix plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	   table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/gente=/muzykalnye_kanaly
	-- #stream/gente=/novostnye_kanaly
	-- #stream/genre=/razvlekatelnyye_kanaly
	-- #stream/genre=/sputnikovye_kanaly
	-- #stream/genre=/russkie_kanaly

	if not args.q then
		local page = tonumber(args.page or 1)
		
		local genre = args.genre or '/movies/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		
		if genre == '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/?get=movies' then
       if page > 1 then
			url = HOME .. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/page/' .. tostring(page) .. '/' .. '?get=movies'
		end
		end
		
		
      if genre == '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/?get=tv' then
       if page > 1 then
			url = HOME .. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/page/' .. tostring(page) .. '/' .. '?get=tv'
		end
		end
		
		
		
	--	local x = http.getz(url)
       local x = conn:load(url)
	
        for url, image,  title in string.gmatch(x, '<article.-id="post.-<a href="(.-)".-<img.-src="(.-)" alt="(.-)"') do

		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	--	end





    for url, image, title  in string.gmatch(x, '<article class="featured%-item".-<a href="https://.-(/.-)".-<img.-src="(.-)" alt="(.-)"') do
--        t['view'] = 'simple'
		  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end


   --     for url, image, title in string.gmatch(x, '<article.-id="selection".-<a.-(/network.-)".-<img src="(.-)".-class="data".-<h3>(.-)</h3>') do

	--	  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
	--	end

   --   for image, url, title  in string.gmatch(x, '<article.-id="selection".-<img src="(.-)".-class="data".-<h3><a.-(/tag.-)".->(.-)</a>') do

	--	  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
	

    
    
    
		



		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'





          local x = conn:load(HOME)
         local x = string.match(x, '<ul class="nav%-links"(.-)Новости кино')
		for genre, title in string.gmatch(x,'<a href="https://.-(/.-)".->(.-)</a>') do
	
			table.insert(t,{title = tolazy(title),mrl='#stream/genre='..genre})
		end
		



		table.insert(t,{title = 'Сериалы',mrl='#stream/genre='.. '/tvshows/'})

		table.insert(t,{title = 'Популярные (все)',mrl='#stream/genre='.. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/'})
		
		table.insert(t,{title = 'Популярные (фильмы)',mrl='#stream/genre='.. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/?get=movies'})
	table.insert(t,{title = 'Популярные (сериалы)',mrl='#stream/genre='.. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/?get=tv'})	

		

		local x = conn:load(HOME)
         local x = string.match(x, '<ul class="years%-list">(.-)</ul>')
         
		for genre, title in string.gmatch(x,'<a href="http.-(/release.-)">(.-)</a>') do
	
			table.insert(t,{title = tolazy(title),mrl='#stream/genre='..genre})
		end
	

    
		
--https://hdzetflix.shop/?s=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9	
	
      elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/?s=' .. urlencode(args.keyword)
		--.. tostring(page)


        if page > 1 then
			url = HOME .. '/page/' .. tostring(page) .. '/?s=' .. urlencode(args.keyword)
		end
		local x = conn:load(url)
	
	
         for url, image, title  in string.gmatch(x, '<div class="search%-result%-item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
		--	url = string.gsub(url, '^(.-)', HOME)
       --     image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
	
	
	
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	--	local x = http.getz(args.id)
        local x = conn:load(args.id)
		
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
      --    t['ref'] = args.id
	
     --     x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1>(.-)</h1>')
		t['description'] = parse_match(x,'<div class="description" itemprop="description".-<p>(.-)</p>')
			t['poster'] = args.p

		--	t['poster'] = parse_match(x,' <div class="fposter".-src="(.-)"')
	--	if t['poster'] then
		--	t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
		
			
	    	t['annotation'] = parse_array(x, {

'(Премьера:</span>.-)</i>', '(Страна:</b>.-)</i>', '(Жанр:</span>.-)</i>', '(В ролях:</span>.-)</i>',
			
})




    for title1, title in string.gmatch(x, '<meta property="og:title" content=".-%((.-)%).-class="alternative%-title.->(.-)<') do

      title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
      
title = string.gsub(title, '*', '')
     title = string.gsub(title, '%%26laquo', '')
     title = string.gsub(title, '%%26raquo', '')

     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. ',' .. title1

--table.insert(t, {title = url, mrl = url})

     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do


    url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=') 

    
       local x = conn:load(url1)
   
   
   for  total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-hidxlglk.-class="videos__item%-title">(.-)</div>') do
  
  
     local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-m3u8)"') do
      
      url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')

      
      
      
    --   t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
  --  local x = conn:load(url1)
        for url3, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for url5, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
    
  --     t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url5})

       
    end
   end
   end
end
end






    for title1, title in string.gmatch(x, '<meta property="og:title" content=".-%((.-)%).-class="alternative%-title.->(.-)<') do

      title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
     title = string.gsub(title, '%%26laquo', '')
     title = string.gsub(title, '%%26raquo', '')


      
     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. ',' .. title1


     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do


     url1 = string.gsub(title3, '^(.-)', 'http://93.183.92.183:9118/lite/mirage?kinopoisk_id=') .. '&uid=m7alois3'
    

 
   table.insert(t, {title = 'Mirage', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
      end
       
   -- local x = conn:load(url1)
     
     for  url2, url3,  total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
  
      url3 = string.gsub(url3, '\\u0026', '&')

    
       local x = conn:load(url2 .. url3)
    
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
    
       url4 = string.gsub(url4, '^(.-)', 'http://93.183.92.183:9118')
    
     t['view'] = 'simple'

    table.insert(t, {title = tolazy(total2) .. '(' .. tolazy(total3) .. ')', mrl = url4})

      end 
      end
     
  

      
       for url2, total  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
       url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       
     url2 = string.gsub(url2, '\\u0026', '&')
     
   --  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)


      for url3, url4, total1, total2  in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-voice_name":"(.-)".-class="videos__item%-title">(.-серия)</div>') do

       url3 = string.gsub(url3, '^(.-)', 'http://93.183.92.183:9118')
       
     url4 = string.gsub(url4, '\\u0026', '&')
      local x = conn:load(url3 .. url4)
     local x = string.match(x, '"quality"(.-)}')
      for  total3, url5 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
   
     url5 = string.gsub(url5, '^(.-)', 'http://93.183.92.183:9118')
    
      t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total2) .. '(' .. total3 .. ')' .. '(' .. total1 .. ')', mrl = url5})

    end
end
end








   for title1, title in string.gmatch(x, '<meta property="og:title" content=".-%((.-)%).-class="alternative%-title.->(.-)<') do

      title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
     title = string.gsub(title, '%%26laquo', '')
     title = string.gsub(title, '%%26raquo', '')



     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. ',' .. title1


     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do

url1 = string.gsub(title3, '^(.-)', 'http://movixhd.online/lite/videodb?kinopoisk_id=') 
    
    table.insert(t, {title = 'Videodb', mrl = '#stream/q=content&id=' .. url1, image = image})
    end
    end

  
    
   --   local x = conn:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://movixhd.online')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://movixhd.online') 
       local x = conn:load(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://movixhd.online') 
       local x = conn:load(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://movixhd.online')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
    






    


   




for total, title in string.gmatch(x, '<meta property="og:title" content=".-%((.-)%).-class="alternative%-title.->(.-)<') do

      title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
     title = string.gsub(title, '%%26laquo', '')
     title = string.gsub(title, '%%26raquo', '')


      url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    
      local x = conn:load(url)

        for total in string.gmatch(x,'%[{"size.-trackerName.-kinozal.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        

       url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      

        local x = conn:load(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     --    t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
       --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
       -- t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	


     local x = conn:load(url)
     
      for total in string.gmatch(x,'%[{"size.-trackerName.-nnmclub.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        
      url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      

        local x = conn:load(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     
   --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
      --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
      --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	
    end


    
		 
		 
		 
	elseif args.q == 'play' then
	--	return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
       return video(args.url, args)
	end
--	end
	return t
end