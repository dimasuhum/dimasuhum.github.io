-- zetflix plugin

require('support')
require('video')
require('parser')
require('client')


--http://fxmlparsers.in.net/VilkaDB/?id=zetflix&act=https://zeflix.online/films/policejskij-iz-beverli-hillz-4/


--http://fxmlparsers.in.net/VilkaDB/?id=zetflix&act=https://zeflix.online/films/obeit/

--HOME = 'https://hdi.zetfix.online'
HOME = 'https://zeflix.online'
HOME_SLASH = HOME .. '/'
--HOME_SLASH1 = HOME1 .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

function onLoad()
	print('Hello from zetflix plugin')
	return 1
end

function onUnLoad()
	print('Bye from zetflix plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	   table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/gente=/muzykalnye_kanaly
	-- #stream/gente=/novostnye_kanaly
	-- #stream/genre=/razvlekatelnyye_kanaly
	-- #stream/genre=/sputnikovye_kanaly
	-- #stream/genre=/russkie_kanaly

	if not args.q then
		local page = tonumber(args.page or 1)
		
		local genre = args.genre or '/films/new_netflix_films/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
       local x = conn:load(url)
	
        for url,image,  title in string.gmatch(x, '<div class="vi%-in".-<a.-href="(.-)".-<img src="(/.-jpg)".-class="vi%-title">(.-)<') do
		--	url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
			

		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end

		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


          local x = http.getz(HOME)
          local x = string.match(x, '<ul class="hidden%-ul visible">(.-)</ul')
		for genre, title in string.gmatch(x,'<a href="(/film.-)">(.-)</a>') do
			table.insert(t,{title = 'ФИЛЬМЫ' .. ' : ' .. tolazy(title),mrl='#stream/genre='..genre})
		end
		local x = http.getz(HOME)
          local x = string.match(x, '</span>Сериалы</a>.-<ul class="hidden%-ul visible">(.-)</ul')
		for genre, title in string.gmatch(x,'<a href="(/serials.-)">(.-)</a>') do
			table.insert(t,{title = 'СЕРИАЛЫ' .. ' : ' .. tolazy(title),mrl='#stream/genre='..genre})
		end

   -- 	table.insert(t,{title = 'SKAM',mrl='#stream/genre='.. '/skam/'})	
        table.insert(t,{title = 'Мультики',mrl='#stream/genre='.. '/cartoons/'})	
	-- #stream/q=content&id=https://films-2020.ru/1610-britanija-2020.html
	
	
--https://zetflix-online.zone/index.php?do=search&subaction=search&search_start=0&full_search=0&result_from=1&story=%D1%80%D0%BE%D0%BA	

--https://zetflix-online.zone/index.php?do=search&subaction=search&search_start=2&full_search=0&result_from=13&story=%D1%80%D0%BE%D0%BA

--https://zeflix.online/index.php?story=Мятежная&do=search&subaction=search	
	
	
	
      elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
	
	
         for url, image,  title in string.gmatch(x, '<a class="sres%-wrap clearfix" href="(.-)".-<img src="(.-jpg).-alt="(.-)"') do
	
		
          --      for url,image,  title in string.gmatch(x, '<div class="vi%-in".-<a.-href="(.-)".-<img src="(/.-jpg)".-class="vi%-title">(.-)<') do
		--	url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
	
	
	
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
      --    t['ref'] = args.id
	
     --     x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1>(.-)</h1>')
		t['description'] = parse_match(x,'<div id="serial%-kratko">(.-)</div>')
			t['poster'] = args.p

		--	t['poster'] = parse_match(x,' <div class="fposter".-src="(.-)"')
	--	if t['poster'] then
		--	t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
		
			
	    	t['annotation'] = parse_array(x, {

'(Страна:</span>.-)</li>', '(Сценарий:</span>.-)</li>', '(Режиссёр:</span>.-)</li>', '(Премьера:</span>.-)</li>', '(Время:</span>.-)</li>', '(Перевод:</span>.-)</li>', '(Актёры:</span>.-)</li>', 
			
})


 --width='1195' height='672' src="/iplayer/player.php?id=JTJGaXBsYXllciUyRnZpZGVvZGIucGhwJTNG
 
 --a3AlM0R0dDI3NDExMjcwJTI2cG9zdGVyJTNEaHR0cHMlM0ElMkYlMkZ6ZWZsaXgub25saW5lJTJGdXBsb2FkcyUyRnBvc3RzJTJGMjAyNC0wNSUyRjE3MTUzNTQzODRfY2gxLmpwZw==&poster=aHR0cHM6Ly96ZWZsaXgub25saW5lL3VwbG9hZHMvcG9zdHMvMjAyNC0wNS8xNzE1MzU0Mzg0X2NoMS5qcGc=" 




--src="/iplayer/player.php?id=JTJGaXBsYXllciUyRnZpZGVvZGIucGhwJTNG

--a3AlM0Q3ODQ1MTIlMjZwb3N0ZXIlM0RodHRwcyUzQSUyRiUyRnplZmxpeC5vbmxpbmUlMkZ1cGxvYWRzJTJGcG9zdHMlMkYyMDI0LTA1JTJGMTcxNjgxMjk5OF9wNC5qcGc=&poster=aHR0cHM6Ly96ZWZsaXgub25saW5lL3VwbG9hZHMvcG9zdHMvMjAyNC0wNS8xNzE2ODEyOTk4X3A0LmpwZw=="

--a3AlM0Q3ODQ1MTI


--https://reyohoho.space:4432/get_zetflix/kp=4477073&poster=

      for url in string.gmatch(x, 'og:video:iframe.-?id=(.-)HR') do
      


          url = string.gsub(url, 'JTJGaXBsYXllciUyRnZpZGVvZGIucGhwJTNG', '')
        url=http.urldecode(base64_decode(url))
         
         
 
 
         url = string.gsub(url, 'h', '')
 
       url = string.gsub(url, 'kp=', '')
 
      url = string.gsub(url, '&poster=', '') 
        
       -- for title  in string.gmatch(x, '<meta itemprop="itemReviewed" content="(.-)"') do

         print(url)
--https://kinobd.net/api/films/search/title?q=Полицейский из Беверли-Хиллз 4: Аксель Фоули
--5212124



      --  url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')

     --   url = string.gsub(title, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
       -- table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
    
     --  end
    
       -- local x =  http.getz(url)
        
         -- for url in string.gmatch(x, 'logo_30x30.-kinopoiskapiunofficial.tech.-kp_small.-/(.-).jpg') do
     --   for url in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
        
        url = string.gsub(url, '^(.-)', 'https://reyohoho.space:4432/get_zetflix/')
         
  --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    
       end
    --   end

      --  local x =  http.getz(url)
        
    
--{"title": "(.-)", "folder": %[{"comment":"(.-серия)","file".-%[(360p)](http.-.mp4)
    
     
     
--{"title": "(.-)", "file":.-%[(360p)](http. -.mp4)
      
        for title, total, url in string.gmatch(x, '{"title": "(.-)", "file":.-%[(360p)](http.-.m3u8)') do
            t['view'] = 'simple'
table.insert(t,{title=tolazy(title) .. ' ' ..   (total),mrl= url})
       end
       
       for title, total, url in string.gmatch(x, '{"title": "(.-)", "file":.-%[(480p)](http.-.m3u8)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. ' ' ..   (total),mrl= url})
       end
         
        for title, total, url in string.gmatch(x, '{"title": "(.-)", "file":.-%[(720p)](http.-.m3u8)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. ' ' ..   (total),mrl= url})
       end
       for title, total, url in string.gmatch(x, '{"title": "(.-)", "file":.-%[(1080p)](http.-.m3u8)') do
            t['view'] = 'simple'
			table.insert(t,{title=tolazy(title) .. ' ' ..   (total),mrl= url})
      
         end
         
         
       for title, total,  url in string.gmatch(x, '{"title": "(.-)", "file":.-%[(360p)](http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. ' ' ..   (total),mrl= url})
       end
       
        for title, total,  url in string.gmatch(x, '{"title": "(.-)", "file":.-%[(480p)](http.-.mp4)') do
            t['view'] = 'simple'
			table.insert(t,{title=tolazy(title) .. ' ' ..   (total),mrl= url})
       end
       
      for title, total,  url in string.gmatch(x, '{"title": "(.-)", "file":.-%[(720p)](http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. ' ' ..   (total),mrl= url})
       end
       
       for title, total,  url in string.gmatch(x, '{"title": "(.-)", "file":.-%[(1080p)](http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. ' ' ..   (total),mrl= url})
       end
    --   end


        for title, url in string.gmatch(x, 'var l5.-%[(360p)](http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
       end
       
       
         for title, url in string.gmatch(x, 'var l5.-%[(480p)](http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
       end




         for title, url in string.gmatch(x, 'var l5.-%[(720p)](http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
       end
       
       
       
         for title, url in string.gmatch(x, 'var l5.-%[(1080p)](http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
       end






        for url in string.gmatch(x, 'og:video:iframe.-?id=(.-)HR') do
      


          url = string.gsub(url, 'JTJGaXBsYXllciUyRnZpZGVvZGIucGhwJTNG', '')
        url=http.urldecode(base64_decode(url))
         
         
 
 
         url = string.gsub(url, 'h', '')
 
       url = string.gsub(url, 'kp=', '')
 
      url = string.gsub(url, '&poster=', '') 
        

  --     for title  in string.gmatch(x, '<meta itemprop="itemReviewed" content="(.-)"') do

    --     print(url)

   --     url = string.gsub(title, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
   
        url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=')
        table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    
    
        end
    
    

    --     for url in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
  

    --    url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=')
      --url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=') .. '&kinopoisk_id=' .. url1

   --   local x =  http.getz(url)
       
      
       
       for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(1080p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(720p).-(http.-mp4)') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(480p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(360p).-(http.-mp4)') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
--end

        
   
   
        for title  in string.gmatch(x, '<meta itemprop="itemReviewed" content="(.-)"') do

         print(url)

        url = string.gsub(title, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
   
   --     url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=')
        table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    
        end
    
    

         for url in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
  

        url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=')
      --url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=') .. '&kinopoisk_id=' .. url1

      local x =  http.getz(url)
       
      
       
       for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(1080p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(720p).-(http.-mp4)') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(480p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(360p).-(http.-mp4)') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      end
   
   
   
   
   
   
       for title  in string.gmatch(x, '<meta itemprop="itemReviewed" content="(.-)"') do

         print(url)

        url = string.gsub(title, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
   
        local x = http.getz(url)
 
          for url1  in string.gmatch(x, 'current_page".-"data":%[{"id".-kinopoisk_id":(.-),') do
       


	
        url = string.gsub(url1, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=22&kid=')
       
        local x = http.getz(url)



       for title, url3 in string.gmatch(x, '\'title\': \'(Season) (.-)\',') do


       url = string.gsub(url1, '^(.-)', 'https://reyohoho.space:4432/get_zetflix/') .. '&s=' .. url3
       
       


      table.insert(t, {title = title .. url3, mrl = '#stream/q=content&id=' .. url})
    
        end
       end
       end




          for total, total1, total2, url in string.gmatch(x, '{"title": "(.-)", "folder": %[{"comment":"(.-серия)","file".-%[(360p)](http.-.mp4)') do

       t['view'] = 'simple'

       table.insert(t, {title = total .. ' ' .. (total1) .. (total2), mrl =  url})
    
    	end
    	
        for total, total1, total2, url in string.gmatch(x, '{"title": "(.-)", "folder": %[{"comment":"(.-серия)","file".-%[(480p)](http.-.mp4)') do

       t['view'] = 'simple'

       table.insert(t, {title = total .. ' ' .. (total1) .. (total2), mrl =  url})
    
    	end
    


          for total, total1, total2, url in string.gmatch(x, '{"title": "(.-)", "folder": %[{"comment":"(.-серия)","file".-%[(720p)](http.-.mp4)') do

       t['view'] = 'simple'

       table.insert(t, {title = total .. ' ' .. (total1) .. (total2), mrl =  url})
    
    	end
    


          for total, total1, total2, url in string.gmatch(x, '{"title": "(.-)", "folder": %[{"comment":"(.-серия)","file".-%[(1080p)](http.-.mp4)') do

       t['view'] = 'simple'

       table.insert(t, {title = total .. ' ' .. (total1) .. (total2), mrl =  url})
    
    	end
    	
    	

   
      
      
      
        for total, total1, total2, url in string.gmatch(x, '{"title": "(.-)", "folder": %[{"comment":"(.-серия)","file".-%[(360p)](http.-.m3u8)') do

       t['view'] = 'simple'

       table.insert(t, {title = total .. ' ' .. (total1) .. (total2), mrl =  url})
    
    	end
    	
        for total, total1, total2, url in string.gmatch(x, '{"title": "(.-)", "folder": %[{"comment":"(.-серия)","file".-%[(480p)](http.-.m3u8)') do

       t['view'] = 'simple'

       table.insert(t, {title = total .. ' ' .. (total1) .. (total2), mrl =  url})
    
    	end
    


          for total, total1, total2, url in string.gmatch(x, '{"title": "(.-)", "folder": %[{"comment":"(.-серия)","file".-%[(720p)](http.-.m3u8)') do

       t['view'] = 'simple'

       table.insert(t, {title = total .. ' ' .. (total1) .. (total2), mrl =  url})
    
    	end
    


          for total, total1, total2, url in string.gmatch(x, '{"title": "(.-)", "folder": %[{"comment":"(.-серия)","file".-%[(1080p)](http.-.m3u8)') do

       t['view'] = 'simple'

       table.insert(t, {title = total .. ' ' .. (total1) .. (total2), mrl =  url})
    
    	end
   
  
  
  
  
   
        
        for url2  in string.gmatch(x, 'current_page".-"data":%[{"id.-"kinopoisk_id":(.-),') do
       

        url = string.gsub(url2, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=22&kid=')
       
        local x = http.getz(url)


       for title, url3 in string.gmatch(x, '\'title\': \'(Сезон) (.-)\',') do

     
      
      local x = http.getz('https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)


  
        for url5, total5  in string.gmatch(x, 'method":"link".-(&t=.-)".->(.-)</div>') do


       local x = http.getz('https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3 .. url5)



       for url4, total2  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do
       

       t['view'] = 'simple'
   
   

      table.insert(t, {title = title .. ' ' .. url3 .. (total2) .. (total5), mrl = url4})
    

	end
    end
    end
    end

       
   
       
           local x = http.getz('http://fxmlparsers.in.net/VilkaDB/?id=zetflix&act=' .. args.id)
       
    
       for title, total, url  in string.gmatch(x, '{"poster":.-"title":"(.-)".-"stream_url".-title.-(360p).-url.-(http.-.mp4)') do
    
    url = string.gsub(url, '\\\\\\', '')
    
    
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
    
    
    
    
    table.insert(t, {title = title .. (total), mrl = url})
    

	end
    
    
    
         
		 
	elseif args.q == 'play' then
	--	return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
       return video(args.url, args)
	end
--	end
	return t
end