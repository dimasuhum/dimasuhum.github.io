-- zetflix plugin

require('support')
require('video')
require('parser')
require('client')



--http://fxmlparsers.in.net/VilkaDB/?id=tmdb&media_type=movie&tid=348&torr=Alien(1979)

--%D0%A7%D1%83%D0%B6%D0%BE%D0%B9

--http://fxmlparsers.in.net/http://videocdn.tv/?id=tmdb&media_type=movie&tid=426063&torr=%D0%9D%D0%BE%D1%81%D1%84%D0%B5%D1%80%D0%B0%D1%82%D1%83

--{"title":".-"stream_url".-"parser":"(.-)"

--http://148.72.155.49:9117

--http://fxmlparsers.in.net/http://videocdn.tv/?getfile=aHR0cDovLzE0OC43Mi4xNTUuNDk6OTExNy9kbC9tZWdhcGVlci8/amFja2V0dF9hcGlrZXk9MzlmbWp0ODR6dzdoM3k0NTllNWNsbm81NjFtajY1N3AmcGF0aD1RMlpFU2poQ1VqWmxlWGR4YTJoU1JIWk5RMWN0Tm1OMmRVVmtPRUpEUzNGU1ltSk9TMGx0ZVZsSE56VTNiVXBTVlVoS2FtY3pRbk4zYVVZMExXbE1iUzFSUTJadGRsODFMVFIxYUhwMlRqSjBjMUZqTkZKeVlVNHpZbXRSY0dwQ2IxQlFURk5hWXpoalF6ZHNVa05uTTFOQlNqQjVZbmhNVW5wSFJGWmpiSGxLYzJrM1ZFODNZbkJmWjNOYVQxUk1SV294V1V0bk5qaFpOREZOWlVsdVVFbElhMDV4Y1ZKbU0wMWZkRGxFYWtNJmZpbGU9JUQwJTlEJUQwJUJFJUQxJTgxJUQxJTg0JUQwJUI1JUQxJTgwJUQwJUIwJUQxJTgyJUQxJTgzK18rTm9zZmVyYXR1KygyMDI0KStXRUItREwrMTA4MHArJUQwJUJFJUQxJTgyK05ldy1UZWFtKyU3QytQKyU3QytIRFJlemthK1N0dWRpbw==


--http://148.72.155.49:9117/dl/megapeer/?jackett_apikey=39fmjt84zw7h3y459e5clno561mj657p&path=Q2ZESjhCUjZleXdxa2hSRHZNQ1ctNmN2dUVkOEJDS3FSYmJOS0lteVlHNzU3bUpSVUhKamczQnN3aUY0LWlMbS1RQ2Ztdl81LTR1aHp2TjJ0c1FjNFJyYU4zYmtRcGpCb1BQTFNaYzhjQzdsUkNnM1NBSjB5YnhMUnpHRFZjbHlKc2k3VE83YnBfZ3NaT1RMRWoxWUtnNjhZNDFNZUluUElIa05xcVJmM01fdDlEakM&file=%D0%9D%D0%BE%D1%81%D1%84%D0%B5%D1%80%D0%B0%D1%82%D1%83+_+Nosferatu+(2024)+WEB-DL+1080p+%D0%BE%D1%82+New-Team+%7C+P+%7C+HDRezka+Studio

--https://jacred.xyz/api/v1.0/torrents?search=Alien1979&apikey=39fmjt84zw7h3y459e5clno561mj657p&exact=true

--http://fxmlparsers.in.net/VilkaDB/?id=zetflix&act=https://zeflix.online/films/policejskij-iz-beverli-hillz-4/


--http://fxmlparsers.in.net/VilkaDB/?id=zetflix&act=https://zeflix.online/films/obeit/


--http://kb-team.club/?do=/plugin&bid=zetflix-zetflix&act=search&search=Ручная кладь&box_mac=b8bc5bf8dea3




HOME = 'https://hdzetflix.com'
HOME_SLASH = HOME .. '/'
--HOME_SLASH1 = HOME1 .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

function onLoad()
	print('Hello from zetflix plugin')
	return 1
end

function onUnLoad()
	print('Bye from zetflix plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	   table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/gente=/muzykalnye_kanaly
	-- #stream/gente=/novostnye_kanaly
	-- #stream/genre=/razvlekatelnyye_kanaly
	-- #stream/genre=/sputnikovye_kanaly
	-- #stream/genre=/russkie_kanaly

	if not args.q then
		local page = tonumber(args.page or 1)
		
		local genre = args.genre or '/release/2024/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		
		if genre == '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/?get=movies' then
       if page > 1 then
			url = HOME .. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/page/' .. tostring(page) .. '/' .. '?get=movies'
		end
		end
		
		
      if genre == '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/?get=tv' then
       if page > 1 then
			url = HOME .. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/page/' .. tostring(page) .. '/' .. '?get=tv'
		end
		end
		
		
		
		local x = http.getz(url)
      -- local x = conn:load(url)
	
        for image,  url, title in string.gmatch(x, '<article id="post.-<img src="(.-)".-class="data".-<h3><a href="(.-)".->(.-)</a>') do

		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	--	end





    for url, title  in string.gmatch(x, '<article.-id="selection".-<a href="https://.-(/.-)" title="(.-)"') do
        t['view'] = 'simple'
		  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end


   --     for url, image, title in string.gmatch(x, '<article.-id="selection".-<a.-(/network.-)".-<img src="(.-)".-class="data".-<h3>(.-)</h3>') do

	--	  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
	--	end

   --   for image, url, title  in string.gmatch(x, '<article.-id="selection".-<img src="(.-)".-class="data".-<h3><a.-(/tag.-)".->(.-)</a>') do

	--	  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
	

    
		
	



		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'

          local x = http.getz(HOME)
     --    local x = string.match(x, '<div id="arch%-menu".->(.-)<a.-/?s=')
		for genre, title in string.gmatch(x,'<li class="menu%-item menu%-item%-type.-<a.-href="https://.-(/.-)".->(.-)</a>') do
	
			table.insert(t,{title = tolazy(title),mrl='#stream/genre='..genre})
		end
		
		table.insert(t,{title = 'Сериалы',mrl='#stream/genre='.. '/tvshows/'})

		table.insert(t,{title = 'Популярные (все)',mrl='#stream/genre='.. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/'})
		
		table.insert(t,{title = 'Популярные (фильмы)',mrl='#stream/genre='.. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/?get=movies'})
	table.insert(t,{title = 'Популярные (сериалы)',mrl='#stream/genre='.. '/%d0%bf%d0%be%d0%bf%d1%83%d0%bb%d1%8f%d1%80%d0%bd%d1%8b%d0%b5/?get=tv'})	

		
		
		
		for genre, title in string.gmatch(x,'<li class="cat%-item cat%-item.-<a href=".-(/release.-)">(.-)</a>') do
	
			table.insert(t,{title = tolazy(title),mrl='#stream/genre='..genre})
		end
		


     
		
		
--https://zetflixhd.com/page/2/?s=%D0%A0%D0%BE		
	
      elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/?s=' .. urlencode(args.keyword)
		--.. tostring(page)


        if page > 1 then
			url = HOME .. '/page/' .. tostring(page) .. '/?s=' .. urlencode(args.keyword)
		end
		local x = http.getz(url)
	
	
         for url, image, title  in string.gmatch(x, '<div class="sheader".-<a href="(.-)".-<img.-src="(.-)" alt="(.-)"') do
		--	url = string.gsub(url, '^(.-)', HOME)
       --     image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
	
	
	
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
       --  local x = conn:load(args.id)
		
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
      --    t['ref'] = args.id
	
     --     x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1>(.-)</h1>')
		t['description'] = parse_match(x,'<div itemprop="description".-<p>(.-)</p>')
			t['poster'] = args.p

		--	t['poster'] = parse_match(x,' <div class="fposter".-src="(.-)"')
	--	if t['poster'] then
		--	t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
		
			
	    	t['annotation'] = parse_array(x, {

'(Жанры:</b>.-)</div>' , '(Страна:</b>.-)</div>', '(В ролях:</b>.-)<div class="single_tabs"',
			
})




--https://kinobd.net/api/films/search/title?q=Speak No Evil


  
  
       for total, title in string.gmatch(x, '<meta property="og:title" content=".-%((.-)%).-<span itemprop="alternativeHeadline" id="alt">(.-)</span>') do

      title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
      title = string.gsub(title, '%%26laquo', '')
      title = string.gsub(title, '%%26raquo', '')


        url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '+'  .. '(' .. total .. ')'
  
  
  
   --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
	
         local x = http.get(url)
     
       for total  in string.gmatch(x, '"fxml".-playlist_url.-?id=info&cid=(.-)"') do
       
    
      url1 = string.gsub(total, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=')
      table.insert(t, {title = 'Источники', mrl = '#stream/q=content&id=' .. url1})
	
	
	end
	end
  
  
  
  
  
      for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?&kinopoisk_id=')
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end
     
     




      for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'https://lam.akter-black.com/lite/zetflix?&kinopoisk_id=')
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end
     



     for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'http://93.183.92.183:9118/lite/fancdn?&kinopoisk_id=')
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       t['view'] = 'simple'

   table.insert(t, {title = 'fancdn' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end
     
     
--https://lam.akter-black.com/lite/vibix?kinopoisk_id=386
     
     
     for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=')
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --  url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       t['view'] = 'simple'

   table.insert(t, {title = 'vibix' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end
 
--http://93.183.92.183:9118/lite/lumex?&kinopoisk_id=5942378&uid=m7alois3


     for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'http://93.183.92.183:9118/lite/lumex?&kinopoisk_id=') .. '&uid=m7alois3'
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/lite.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       t['view'] = 'simple'

   table.insert(t, {title = 'lumex' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end
     
     
for title  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
 
   
       url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')
   

        for total, url in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')
       
   

         for total1, url in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title='alloha' .. ':' .. tolazy(total) .. ' ' .. (total1),mrl = url})
			end
          end
          end
 
 
 
 
 
 
      for title  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
 
   
       url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')
       
        
    for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url4  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
      t['view'] = 'simple'
				table.insert(t,{title=tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url})
			end
          end
          end
         end
         end
     
     

     
        for title, total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),.-"year":"(.-)"') do
     
     --  title = json.decode(title)
    
      url = string.gsub(title, '^(.-)', 'https://api.embess.ws/embed/kp/')
 
      local x = http.get(url)
      
      for title1  in string.gmatch(x, '<meta name="robots".-<title>(.-)</title>') do
 
      title1 = urlencode(title1)
 
     url1 = string.gsub(title1, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=') .. '+' .. total .. '+'
	
 --   table.insert(t, {title = url1, mrl = url, image = image})
         
    	local x = http.get(url1)
      
    
    	for url2 in string.gmatch(x, '<playlist_url><!%[CDATA%[(http.-)]]') do
	
    	local x = http.get(url2)
	
     
     for total2, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
    --	table.insert(t, {title = url3, mrl = url3, image = image})
    	
	table.insert(t, {title = 'kinopub' .. ':' .. total2, mrl = url3, image = image})
         end
	     end
	end
     end
     
  
  
    
       for url  in string.gmatch(x, '{"current_page".-,"kinopoisk_id":(.-),') do
   

--hidxlglk.deploy.cx/lite/zetflix

         url = string.gsub(url, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=')



      --   url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=')

    --    url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=0&kinopoisk_id=')
        

      local x =  http.getz(url)
       
    
      
       
       for total, url, title in string.gmatch(x, '"method":"play","url".-(1080p).-(http.-)".-class="videos__item%-title">(.-)<') do
       
   --    local title = json.decode(title)
   --    print(title)
       
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
			
			
      for total, url, title in string.gmatch(x, '"method":"play","url".-(720p).-(http.-)".-class="videos__item%-title">(.-)<') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
   
      for total, url, title in string.gmatch(x, '"method":"play","url".-(480p).-(http.-)".-class="videos__item%-title">(.-)<') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for total, url, title in string.gmatch(x, '"method":"play","url".-(360p).-(http.-)".-class="videos__item%-title">(.-)<') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end
--end
        
        
          for url2  in string.gmatch(x, 'current_page".-"data":%[{"id.-"kinopoisk_id":(.-),') do
       

        url = string.gsub(url2, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=22&kid=')
       
     local x = http.getz(url)


       for title, url3 in string.gmatch(x, '\'title\': \'(Season) (.-)\',') do


        local x = http.getz('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)
  
  
     
      
   --   local x = http.getz('https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)


  
        for url5, total5  in string.gmatch(x, 'method":"link".-(&t=.-)".->(.-)</div>') do


       local x = http.getz('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3 .. url5)



       for url4, total2  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do

        total2 = string.gsub(total2, '\\u0441\\u0435\\u0440\\u0438\\u044F', 'серия')

       t['view'] = 'simple'
   
   

      table.insert(t, {title = title .. ' ' .. url3 .. (total2) .. (total5), mrl = url4})
    

	end
    end
    end
    end

       

       
       for title in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do

   --    for title, total  in string.gmatch(x, 'Оригинальное название:.-class="valor">(.-)<.-Дата выхода:.-class="valor">.-, (.-)</span>') do

    --    url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')

        url = string.gsub(title, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
     --   table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    
    --   end
       local x = http.getz(url)

       for url  in string.gmatch(x, '{"current_page".-,"kinopoisk_id":(.-),') do
   
       
       	 print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Zagonka плеер', mrl = '#stream/q=content&id=' .. url})

		end
        end
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-(//video.zagonka.org/movies/.-})') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
			
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
		
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
    
       
        
        
    end
   
   




         for title, total in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do

  
       title = urlencode(title)
     
      


     url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    

     
     table.insert(t, {title = 'Torrs', mrl = '#stream/q=content&id=' .. url, image = image})
         end




        for total in string.gmatch(x,'%[{"size.-trackerName.-kinozal.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        

       url = string.gsub(total, '^(.-)','http://torr.unknot.ru:8090/stream/?link=') .. '&m3u'
      

        local x = http.get(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
         t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
         t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
        t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	



      for total in string.gmatch(x,'%[{"size.-trackerName.-nnmclub.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        
      url = string.gsub(total, '^(.-)','http://torr.unknot.ru:8090/stream/?link=') .. '&m3u'
      

        local x = http.get(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     
     t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
        t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
        t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	



        
		 
		 
		 
	elseif args.q == 'play' then
	--	return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
       return video(args.url, args)
	end
--	end
	return t
end