-- fast-film plugin

require('support')
require('video')
require('parser')




HOME = 'https://www.myvideo.ge'


HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid', type = 'folder'}
--	t['menu'] = {}
--	if args.q ~= 'genres' then
--		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
--	end

	if not args.q then
	

		local genre = args.genre or '/mytvbox#&show_channels'
		local url = HOME .. genre

			url = url

		local x = http.getz(url)
         

		for  image, url,title in string.gmatch(x, '<tr class="not%-active".-<img.-data%-original="(v3_imgs/tv/tv_)(.-).png".-class="chanel%-name">(.-)<') do
    
--https://www.myvideo.ge/v3_imgs/tv/tv_imedi.png
    
          

        image = string.gsub(image, '^(.-)', HOME .. '/') .. url .. '.png'
   
   --    url = string.gsub(url, '^(.-)', 'http://www.myvideo.ge//ios//android.php?chan=')
        
         table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})

		
		end

        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz('http://www.myvideo.ge//ios//android.php?chan=' .. args.id)
        
        for url in string.gmatch(x, '(http.-)**"') do
		
         print(url)
		 url = string.gsub(url, '\\', '')
          print(url)
			t = video(url, args)
			if t['view'] ~= 'error' then
				break
			end
       table.insert(t, {mrl = url})

			
		end

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end