-- kinosimka plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://me.kinosimka4.org'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH









--HOME = 'https://kinosimka1.biz'
--HOME = 'https://kinosimka1.ws'
--https://m.kinosimka2.biz'
--HOME = 'https://n.kinosimka4.org'
--HOME = 'https://m.kinosimka3.com'
--HOME = 'https://n5.kinosimka3.be'
--HOME_SLASH = HOME .. '/'


function onLoad()
	print('Hello from kinosimka plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinosimka plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2

	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/lastnews'
        --local offset = (page - 1) * 3 + 1
		--for  i= 1, 1 do

			
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
        --x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
        
        if genre == '/collections/8-na-realnyh-sobytijah' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
		end
        
        
        
         local x = conn:load(url)
        
        
		for url, image, title in string.gmatch(x, '<div class="clearfix".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
		--	url = string.gsub(url, '^(.-)', HOME)
        --    image = string.gsub(image, '^(.-)', HOME) 
        
        
        
	--	for url, title,  image in string.gmatch(x, '<div class="title".-<a href="(.-)">(.-)</a>.-class="poster".-<img src="(.-)"') do
			--url = string.gsub(url, '^/', HOME_SLASH)
            image = string.gsub(image, '^/', HOME_SLASH) 
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
       for url, image, title in string.gmatch(x, '<div class="collections%-item".-<a href="https.-(/collections/.-)".-<img src="(.-)" alt="(.-)"') do
			--url = string.gsub(url, '^/', HOME_SLASH)
            image = string.gsub(image, '^(.-)', HOME) 
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre' .. url, image = image})
		end
        
        
        
		
        
        local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
	--	table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections/'})
--https://n.kinosimka4.org/collections/
         local x = conn:load(HOME .. '/genre.html')

         x = string.match(x, '<ul class="navjanr">(.-)</ul>')
	    for genre, title in string.gmatch(x, '<a href="(.-)".-<div>(.-)</div>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end 
		
       --  local x = conn:load(HOME)
        
		
         local x = conn:load(HOME .. '/years-country.html')
         
        x = string.match(x, '<ul class="navjanr">(.-)<div class="nav%-vf"')
	    for genre, title in string.gmatch(x, '<a href="(.-)".-<div>(.-)</div>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end  
		
		
		

	
	elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search' .. '#' .. tostring(page)

		
		local x = http.getz(url)
		
        for url, title,  image in string.gmatch(x, '<div class="shotanewsa".-<a href="(.-)">(.-)<.-<img src="(.-)"') do
		--	url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME) 
        
        
        
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '#' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
	-- #stream/q=content&id=/film-zvyozdnye-vrata-1994-hd
	
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	--	local x = http.getz(args.id)
		
         local x = conn:load(args.id)
        --x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div itemprop="description".-<p>(.-)</p>')
	--	<div class="f%-story bbstore".->(.-)</p>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div align="center".-src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Страна</div>.-)</div>', '(Выпущено:</span>.-)</li>', '(Жанр</div>.-)</div>'

		})

         for url in string.gmatch(x, 'var player = new Playerjs.-file.-url=(.-)"') do
         url = string.gsub(url, '%%3D', '')
         url=http.urldecode(base64_decode(url))
         table.insert(t, {title = 'Смотреть', mrl = url})
         end
        --x = string.gsub(x, 'Лучшие моменты', '')
		for url, title  in string.gmatch(x, '<div class="button%-fulls".-<a href="(/index.-)".-(Формат:.-)<') do
        print(url)
        url = string.gsub(url, '^(.-)', HOME)
       -- url = '#stream/q=play&url=' .. url
         table.insert(t, {title = title, mrl = url})

			--addvideo(t, url, t['name'], titles, id)
		  end
	--	end
         
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end