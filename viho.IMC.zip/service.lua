-- fast-film plugin

require('support')
require('video')
require('parser')



--HOME = 'https://tushkan.live'
HOME = 'https://viho.live'
--HOME1 = 'https://kadikama.online'

HOME_SLASH = HOME .. '/'
--HOME1_SLASH = HOME1 .. '/'
function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
       table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	if not args.q then
	
--http://smartportaltv.ru/0/index.php?url=https://groot.as.alloeclub.com/?token_movie=e9ad9ab8f0114cb9c4914a1db2c9d3&token=93e2a60705030f884212e5419c23e3&hidden=season,episode
	
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/film/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page_' .. tostring(page) .. '/'
		end
		
		if genre == '/new/?year=2023' then
     ---    local url = HOME .. genre
        if page > 1 then
			url = HOME .. genre .. '&page=' .. tostring(page)
		end
		end
		
		
		
		local x = http.getz(url)
         
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for  url, image, title  in string.gmatch(x, '<div class="col%-6 col%-sm%-4 col%-md%-3 col%-lg%-3 p%-3".-href="(/.-)".-<img.-src="(.-)" alt="(.-)"') do
   
--href="/film/view/145325-zakaznoe-ubiystvo-2022.html"
   
          
       url = string.gsub(url, '^(.-)', HOME)
      --  image = string.gsub(image, '^(.-)', HOME)
        
         table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--		table.insert(t, {title = title, mrl = '#stream/genre' .. url .. url1})
		
		end
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = http.getz(HOME)


--src="/img/logo.png

         table.insert(t, {title = 'Фильмы', mrl = '#folder/genre=' .. '/film/'})
    
        table.insert(t, {title = 'Сериалы', mrl = '#folder/genre=' .. '/serial/'})
        
        table.insert(t, {title = 'Мультфильмы', mrl = '#folder/genre=' .. '/multfilm/'})
    
        table.insert(t, {title = 'Аниме', mrl = '#folder/genre=' .. '/anime/'})
    
        table.insert(t, {title = 'ТВ передачи', mrl = '#folder/genre=' .. '/tvshow/'})
    
    
		local x = string.match(x, '<ul class="catalog%-year">(.-)</header>')
		for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. genre})
		end
   
   
         local x = http.getz(HOME .. '/video/')
   
        local x = string.match(x, '<select id="inputGenre".-name="genre".-Жанр.->(.-)</select>')
   
         for genre, title in string.gmatch(x, '<option value="(.-)">(.-)</option>') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. '/video/genre_' .. genre .. '/'})
		end
   
   
        local x = http.getz(HOME .. '/video/')
   
        local x = string.match(x, '<select id="inputCountry".-name="country".-Страна.->(.-)</select>')
   
         for genre, title in string.gmatch(x, '<option value="(.-)">(.-)</option>') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. '/video/country_' .. genre .. '/'})
		end
   
   
--https://viho.live/video/?name=%D0%A0%D0%BE%D0%BA%D0%BA%D0%B8

--https://viho.live/video/page_2/?name=%D0%A0%D0%BE

    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/video/' .. 'page_' .. tostring(page) .. '/' .. '?name=' .. urlencode(args.keyword)
		--.. tostring(page)


		local x = http.getz(url)
		
        for  url, image, title  in string.gmatch(x, '<div class="col%-6 col%-sm%-4 col%-md%-3 col%-lg%-3 p%-3".-href="(/.-)".-<img.-src="(.-)" alt="(.-)"') do
         url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end


	 	local url = '#folder/genre=' .. '/video/' .. 'page_' .. tostring(page + 1) .. '/' .. '?name=' .. urlencode(args.keyword)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			

        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
    --    x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="fdesc clr full%-text clearfix"><p>(.-)</p>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
		
--<iframe id="iframeVideoId" style="width: 100%;" frameborder="0" allowfullscreen="" scrolling="no" src="https://viho.live/embed/d614faebb0a74a4a35c2c5339d6f8978/"


--window.videoFilesEmdedCode = {"988939":"<iframe src=\"\/\/1221407734375553.svetacdn.in\/dG8Aslg6NTlE\/tv-series\/14185?nocontrol=1&season=1&episode=1\"

--url=https://api.getcodes.ws/embed/movie/63306?showMenu=false&sharing=false&season=1&episode=1


--/film/view/145325-zakaznoe-ubiystvo-2022.html"


        for url in string.gmatch(x, '<iframe id="iframeVideoId".-src="(.-)"') do


  --      local url = '#stream/q=content&id=' .. url
        --.. '&t=' .. urlencode(title)
	--		table.insert(t, {title = '@string/watch', mrl = url, image = image})
--		end
        table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end
  
--http://smartportaltv.ru/30/2.php?name=https://vid1676279003.vb17121coramclean.pw/serial/a8ff218ebfdcb9595a09086fa1364982cba3ea001681ae5df979bbc3dd73fa5c/iframe?nocontrol=1&s=1&e=1


--<iframe src=\"https:\/\/vid1676279003.vb17121coramclean.pw\/serial\/a8ff218ebfdcb9595a09086fa1364982cba3ea001681ae5df979bbc3dd73fa5c\/iframe?nocontrol=1&s=1&e=1\"
  

          for url in string.gmatch(x, 'window.videoFilesEmdedCode.-<iframe src=.-"https:.-/(vid1.-)"') do
		
		
         url = string.gsub(url, '\\', '')
         url = string.gsub(url, '^(.-)', 'https://')
         
         url = string.gsub(url, '^(.-)', 'http://smartportaltv.ru/30/2.php?name=')
         t['view'] = 'simple'
	
         table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end

--\/\/1221407734375553.svetacdn.in\/dG8Aslg6NTlE\/tv-series\/14175?nocontrol=1&season=1&episode=1\" width=\"100%\"

        for url in string.gmatch(x, 'window.videoFilesEmdedCode.-<iframe src=.-1221407734375553.-(svetacdn.-)"') do
		

--http://i90048wo.beget.tech/27/u7.php?name=https://9886534688564.svetacdn.in/VY8LiVJmmPwm/movie/8237


         url = string.gsub(url, '\\', '')
         url = string.gsub(url, '^(.-)', 'https://')
         
         url = string.gsub(url, '^(.-)', 'http://i90048wo.beget.tech/27/u7.php?name=https://9886534688564.')
         t['view'] = 'simple'
	
         table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end





       for url in string.gmatch(x, 'window.videoFilesEmdedCode.-<iframe src=.-(api.-)"') do
		
		
         url = string.gsub(url, '\\', '')
         url = string.gsub(url, '^(.-)', 'https://')
         
     --    url = string.gsub(url, '^(.-)', 'http://smartportaltv.ru/0/index.php?url=')
         t['view'] = 'simple'
	
         table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end


        for url in string.gmatch(x, 'window.videoFilesEmdedCode.-<iframe src=.-"https.-(groot.-)"') do
		
		
         url = string.gsub(url, '\\', '')
         url = string.gsub(url, '^(.-)', 'https://')
         
         url = string.gsub(url, '^(.-)', 'http://smartportaltv.ru/0/index.php?url=')
         t['view'] = 'simple'
	
         table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end




  
--<iframe src=\"https:\/\/vid1676279013.vb17121coramclean.pw\/serial\/3e9f4564daca443ee77e0375647a757c9f45870ff3a99896af64258b63eebcad\/iframe?nocontrol=1&s=1&e=1\"
  
  
  
         for title, url, total in string.gmatch(x, '<title.-CDATA(.-])].-<playlist_url.-(http.-)].-</br.-</br.-</br>(.-)</center>') do
         t['view'] = 'simple'
          table.insert(t, {title = tolazy(title) .. tolazy(total), mrl = '#stream/q=content&id=' .. url})
        end
  
  
  
         for title, url in string.gmatch(x, '<title>.-CDATA(.-)]>.-<stream_url.-(http.-m3u8)') do
  
          t['view'] = 'simple'
          table.insert(t, {title = title, mrl = url})
		end
     --   end
        
        
        
        
        
        
        for title, url in string.gmatch(x, 'title: "(.-)".-hls: "(https://.-m3u8)"') do
        --	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url .. '?chromecast'})
        end

     	for url, title in string.gmatch(x, '"hls":"(https.-m3u8)".-"title":"(.-)"') do

			print(url)
        t['view'] = 'simple'
      --  t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url .. '?chromecast'})
        end	
       for title, url, total in string.gmatch(x, '"episode".-"hlsList".-"(.-)".-(https.-)".-"title".-"(.-)"') do

			print(url)
        t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url .. '?chromecast'})
        end
		
		for title, url, total in string.gmatch(x, '"episode".-"hlsList".-,"(.-)".-(https.-)".-"title".-"(.-)"') do
			print(url)
         t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url .. '?chromecast'})
        end

        
         
			
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url .. '?chromecast'})
        end
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-,"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url .. '?chromecast'})
        end
        
        
        
        
        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end