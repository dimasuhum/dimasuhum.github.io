-- gidonline plugin

require('support')
require('video')
require('parser')
require('client')
--require('fxml')

--local fxml = onCreate





local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'



local HOME = 'https://gidonline.info'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

--HOME = 'https://gidonline.io'
--HOME = 'https://gidonline.vip'
--HOME = 'https://gidonline.eu'
--HOME = 'https://gidonlinekz.me'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from gidonline plugin')
	return 1
end

function onUnLoad()
	print('Bye from gidonline plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/gente=/muzykalnye_kanaly
	-- #stream/gente=/novostnye_kanaly
	-- #stream/genre=/razvlekatelnyye_kanaly
	-- #stream/genre=/sputnikovye_kanaly
	-- #stream/genre=/russkie_kanaly

	if not args.q then
		local page = tonumber(args.page or 1)
      --   local genre = args.genre or '/lastnews/'
         local genre = args.genre or ''
     	local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
       local x = conn:load(url)
		
      --  local x = conn:load(HOME)
   --   local x = http.getz(HOME .. '/lastnews')
      
        for url, title, image in string.gmatch(x, '<div class="mainlink".-<a.-href="(.-)".-title="(.-)" src=.-(/posts.-jpg)') do

        
       -- url = string.gsub(url, '^(.-)', HOME .. '/')
		image = string.gsub(image, '^(.-)', HOME)
        --    if image and not string.find(image, '://') then
	--			image = HOME .. image
		--	end
			
         
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	

	
		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
	--	table.insert(t,{title = url, mrl = url, image = '#self/next.png'})
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


  
        local x = conn:load(HOME)

        local x = string.match(x, '<ul.->(.-)</ul>')
        for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
          
         local x = conn:load(HOME)

        local x = string.match(x, '<ul.->(.-)</ul>')
        for genre, title in string.gmatch(x, '<a.-href="(.-)".->(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end


--https://gidonline.io/?s=%D1%80%D0%BE%D0%BA&submit=%D0%9F%D0%BE%D0%B8%D1%81%D0%BA

--https://gidonline.io/page/2/?s=%D1%80%D0%BE%D0%BA&submit=%D0%9F%D0%BE%D0%B8%D1%81%D0%BA


--https://gidonline.info/index.php?do=search&subaction=search&search_start=2&full_search=0&story=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8

    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?do=search&subaction=search' .. '&search_start=' .. tostring(page) .. '&full_search=0&story=' .. urlencode(args.keyword)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
        for url, title, image in string.gmatch(x, '<div class="mainlink".-<a.-href="(.-)".-title="(.-)" src=.-(/posts.-jpg)') do

        
       -- url = string.gsub(url, '^(.-)', HOME .. '/')
		image = string.gsub(image, '^(.-)', HOME)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})


	-- #stream/q=content&id=http://tv.tivix.co/24-cartoon-network.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
          t['ref'] = args.id
	
          --x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x, '</h1>(.-)<ul')
			t['poster'] = args.p
	--   t['poster'] = parse_match(x,'<img class="logo%-mobile scale%-with%-grid" src="(.-)"')
	--	if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
	    	t['annotation'] = parse_array(x, {
			'<ul class=.->(.-)<'})
			
  
  
  
  
     for title, url, url1 in string.gmatch(x, '{"comment":".-<i>(.-)</i>","file":"(.-)(/movies.-)"') do
  
        table.insert(t, {title = title, mrl = url .. url1})

		end
  
  
   --    for title in string.gmatch(x, '{"comment":"(.-)","playlist"') do
 
 
 
        for title, total, total1 , url, url1 in string.gmatch(x, '{"comment":"(.-)<b>(.-)<.-<small.->(.-cезон)</small.-"file":"(.-)(/tvseries/.-)"') do
 
 
 --      for total, total1, total2,  url, url1 in string.gmatch(x, '{"comment":"(.-)<b>(.-)</b>.-<small.->(.-cезон)</small>","file":"(.-)(/tvseries.-)"') do
   
   
     title = string.gsub(title, '","playlist":%[{"comment":"', '')
     
       total = string.gsub(total, '","playlist":%[{"comment":"', '')
    
       total1 = string.gsub(total1, '","playlist":%[{"comment":"', '')

  --    total2 = string.gsub(total1, '","playlist":%[{"comment":"', '')

   
       
       table.insert(t, {title = title .. ' ' .. tolazy(total) .. ' ' .. tolazy(total1), mrl = url .. url1})

		end
  --     end


        
          for title, total, total1 , url, url1 in string.gmatch(x, '{"comment":"(.-)<b>(.-)<.-<small.->(.-cезон)</small.-"file":"(.-)(/animetvseries/.-)"') do
 
 
 --      for total, total1, total2,  url, url1 in string.gmatch(x, '{"comment":"(.-)<b>(.-)</b>.-<small.->(.-cезон)</small>","file":"(.-)(/animetvseries.-)"') do
   
   
     title = string.gsub(title, '","playlist":%[{"comment":"', '')
     
       total = string.gsub(total, '","playlist":%[{"comment":"', '')
    
       total1 = string.gsub(total1, '","playlist":%[{"comment":"', '')

  --    total2 = string.gsub(total1, '","playlist":%[{"comment":"', '')

   
       
       table.insert(t, {title = title .. ' ' .. tolazy(total) .. ' ' .. tolazy(total1), mrl = url .. url1})

		end

		
	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end