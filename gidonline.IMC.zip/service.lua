-- gidonline plugin

require('support')
require('video')
require('parser')


HOME = 'https://gidonline.io'


HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from gidonline plugin')
	return 1
end

function onUnLoad()
	print('Bye from gidonline plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/gente=/muzykalnye_kanaly
	-- #stream/gente=/novostnye_kanaly
	-- #stream/genre=/razvlekatelnyye_kanaly
	-- #stream/genre=/sputnikovye_kanaly
	-- #stream/genre=/russkie_kanaly

	if not args.q then
		local page = tonumber(args.page or 1)
         local genre = args.genre or '/'
     	local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		local x = http.getz(url)
      --  x = iconv(x, 'windows-1251', 'UTF-8')
        for  url, image, title, total in string.gmatch(x, '<a class="mainlink" href="(.-)".-<img src="(.-)".-<span>(.-)<.-class="mqn.->(.-)<') do
        
       -- url = string.gsub(url, '^(.-)', HOME .. '/')
		image = string.gsub(image, '^/', HOME_SLASH)


		  table.insert(t, {title = tolazy(title) .. tolazy(total), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	

	
		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


        table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/new/'})
        table.insert(t, {title = 'Премьеры', mrl = '#stream/genre=' .. '/premiers/'})
        table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serials/'})
        table.insert(t, {title = 'Новогодние', mrl = '#stream/genre=' .. '/genre/christmas/'})

        local x = http.getz(HOME)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
      local x = string.match(x, 'Поиск.->(.-)</ul>')
        for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
          local x = http.getz(HOME)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
         local x = string.match(x, '<select class="ddmenu".->(.-)<div id="footer"')
         for genre, title in string.gmatch(x, '<option value="https://gidonline.io(.-)">(.-)</option>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end



--https://gidonline.io/?s=%D1%80%D0%BE%D0%BA&submit=%D0%9F%D0%BE%D0%B8%D1%81%D0%BA

--https://gidonline.io/page/2/?s=%D1%80%D0%BE%D0%BA&submit=%D0%9F%D0%BE%D0%B8%D1%81%D0%BA


    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/page/' .. tostring(page) .. '/' .. '?s=' .. urlencode(args.keyword)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = http.getz(url)
		
        for  url, image, title, total in string.gmatch(x, '<a class="mainlink" href="(.-)".-<img src="(.-)".-<span>(.-)<.-class="mqn.->(.-)<') do
        
       -- url = string.gsub(url, '^(.-)', HOME .. '/')
		image = string.gsub(image, '^/', HOME_SLASH)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})


	-- #stream/q=content&id=http://tv.tivix.co/24-cartoon-network.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
          t['ref'] = args.id
	
          --x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x, '<div class="infotext" itemprop="description".->(.-)<span class="gnv"')
			t['poster'] = args.p
	--   t['poster'] = parse_match(x,'<img class="logo%-mobile scale%-with%-grid" src="(.-)"')
	--	if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
	    	t['annotation'] = parse_array(x, {
			'(жанр</div>.-)</div>'})
			
        
        for url in string.gmatch(x, '<iframe id="cdn%-player".-src="(https://voidboost.-)"') do
			
      --     print(url) 
            
     --     url = string.gsub(url, '^(.-)', 'http://divantv.zz.mu/kinomovie/voidboost.net.php?Urlpage=')
       --  t['view'] = 'grid'
         table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url,})

		end
        local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do

            
          local slist=string.match(x, '<select name="season".->(.-)</select>')
          
           if slist then
          
             for url1, title in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
             

             
            local slist=string.match(x, '<select name="episode".->(.-)</select>')
            
           if slist then
            for url2, total in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do
         

          t['view'] = 'simple'
        	table.insert(t, {title = title .. ':' .. (total) .. ' (' .. total1 .. ')', mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
			end
			end
   	    	end	
   	    	end
            end	
   	    	end
    
    
--https://voidboost.net/movie/149fa08a44c989e65e37289b4c796736/iframe?h=baskino.me

          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
             
             
          t['view'] = 'simple'
        	table.insert(t, {title = total1, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/movie/' .. url3 .. '/iframe?'})
             
            end
            end
    
          
	--		for url1, title in string.gmatch(x, '<option value="(.-)".->(Сезон.-)</option>') do
	--		end
     --     local x = string.match(x, '<select name="episode".->(.-)</select>')
			
     --      for url2, total in string.gmatch(x, '<option value="(.-)".->(Серия.-)</option>') do
	--	   end
            
         
    --      local x = string.match(x, '<select name="translator.->Перевод.->(.-)</div>')
      --      for url3, total1 in string.gmatch(x, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
    
         
         
       -- 	table.insert(t, {title = 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
	--		end

   		
   		
       for url  in string.gmatch(x, 'var CDNplayerConfig.-file.-#2(.-)\'') do
     --    print(url)
		 url = string.gsub(url, '//_//', '')
         url = string.gsub(url, 'Xl4jQEAhIUAjISQ=', '')
         url = string.gsub(url, 'JCQkIyMjIyEhISEhISE=', '')
         url = string.gsub(url, 'QCFeXiFAI0BAJCQkJCQ=', '')
         




         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, url in string.gmatch(url, '(360p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if url then
			for title, url in string.gmatch(url, '(480p).-(http.-.mp4)') do
             t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
				
               table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(720p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p)].-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p Ultra).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end
			end
		
	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end