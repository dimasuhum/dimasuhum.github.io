-- kinotazz.ru plugin

require('support')
require('video')
require('parser')

--HOME = 'http://ki.kinotazz.ru'
--HOME = 'http://kinotazz.ru'
--HOME = 'https://kinotaz.site'
HOME = 'https://hd.kintez.com'
--HOME = 'https://kintas.site'
HOME_SLASH = HOME .. '/'


function onLoad()
	print('Hello from kinotazz.ru plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinotazz.ru plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/serialy-2020/page/
	-- #stream/genre=/collections/
	-- #stream/genre=/collections/filmy-pro-rozhdestvo-i-novyy-god/
	-- #stream/url=/serials/
	-- #stream/url=/serials/tureckie_serialy/
	-- #stream/url=/serials/brazilskie-serialy/
	-- #stream/url=/serials/indijskie_serialy/
	-- #stream/url=/serials/meksikanskie-serialy/
	-- #stream/url=/serials/ispanskie-serialy/
	-- #stream/url=/serials/doramy/
	-- #stream/url=/serials/novye_serialy/
    -- #stream/url=/filmy_online/filmy_2020_online_hd/
    -- #stream/url=/serials/amerikanskie-serialy/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or ''
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
		local x = http.getz(url)
		for url, title, image in string.gmatch(x, '<div class="th%-item".-href="(.-)" title="(.-)".-src="(.-)"') do
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
         for url, title, image  in string.gmatch(x, '<div class="collect%-box".-<a href="(.-)".-alt="(.-)".-class="collect%-img".-(/uploads.-)\'') do
			image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
		end
		
		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x = http.getz(HOME)
		local x = string.match(x, '<ul class="hd%-menu">(.-)</ul>')
		for id, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. id})
		end
        local x = http.getz(HOME)
		local x = string.match(x, '<nav class="side%-box to%-mob">(.-)</nav>')
		for id, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. id})
		end
       
--https://kinotazz.online/index.php?story={searchTerms}&do=search&subaction=search
       
        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')

    	local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'

    --    local x = http.post(url)
		
		local x = http.getz(url)
		
        for url, title, image in string.gmatch(x, '<div class="th%-item".-href="(.-)" title="(.-)".-src="(.-)"') do
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
       
        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
		--print(x)
		t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="m%-desc full%-text clearfix slice%-this slice slice%-masked">(.-)</div>')
		t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
    --elseif args.q == 'play' then
      -- local x = http.getz(args.url)
      -- x = string.gsub(x, '<li>Плеер 2</li><a href="(.-)"','') 
      -- local x = string.match(x, '<div class="player%-drop visible full%-text">(.-)</div>')
	--	for url in string.gmatch(x, '<iframe.-src="(https://vid.-)"') do
       -- print(url)

       --addvideo(t, url, t['name'])

	--		table.insert(t, {title = '@string/watch', mrl = url})
	--	end
		
        for url in string.gmatch(x, '<iframe.-src="(https://api.-)"') do

          -- print(url)

			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id='  .. url})
		end
		
        for title, url in string.gmatch(x, 'title: "(.-)".-hls: "(https://.-m3u8)"') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        end

     	for url, title in string.gmatch(x, '"hls":"(https.-m3u8)".-"title":"(.-)"') do

			print(url)
        t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        end	
    for title, url, total in string.gmatch(x, '"episode".-"hlsList".-"(.-)".-(https.-)".-"title".-"(.-)"') do

			print(url)
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        end
		
		for title, url, total in string.gmatch(x, '"episode".-"hlsList".-,"(.-)".-(https.-)".-"title".-"(.-)"') do
			print(url)
         t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        end

        
         
			
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        end
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-,"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
   --     t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        end
		
		
	elseif args.q == 'play' then
        
       -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)
	--end
	end
	return t
end