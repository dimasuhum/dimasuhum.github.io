-- kinotazz.ru plugin

require('support')
require('video')
require('parser')
require('client')






local HOME = 'https://vi.kinotac.net'

--local HOME = 'https://kinots.org'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

--HOME = 'https://kinots.org'

--HOME_SLASH = HOME .. '/'


--https:\/\/fazhzcddzec.matham.ws
   
 --   http://fxmlparsers.in.net/https://cdn.kinobase.org/?id=unws&u=https%3A%2F%2Fhye1eaipby4w.matham.ws%2F01_06_25%2F01%2F06%2F03%2FJ5MVWNJV%2FRODIPVC2.mp4%2Fmaster.m3u8%3Fha%3D2f24710b26aca59%26hc%3Db40a360cf40c9d5%26hi%3D2fc2e35a2a957ad%26ht%3Dde942250077b430%26hu%3D806aafcc751a1e6%26t%3D1738142332
    
--http://fxmlparsers.in.net/https://cdn.kinobase.org/?id=unws&u=https%3A%2F%2Fhye1eaipby4w.matham.ws%2F01_06_25%2F01%2F06%2F03%2FJ5MVWNJV%2FRODIPVC2.mp4%2Fmaster.m3u8%3Fha%3D2f24710b26aca59%26hc%3Db40a360cf40c9d5%26hi%3D2fc2e35a2a957ad%26ht%3Dd978f24bddda83e%26hu%3D64c384cf34d1250%26t%3D1738145083
    
    
--https://hye1eaipby4w.matham.ws/01_18_25/01/18/23/IR3NRKOP/QWNH3VKZ.mp4/master.m3u8?ha=51165b0cf7fad90&hc=b40a360cf40c9d5&hi=cab7381e39227ff&ht=0ab2ba639d18f2e&hu=64c384cf34d1250&t=1738140111

--https://fazhzcezbdi.showvid.ws/x-px/video-download?m=https://hye1eaipby4w.matham.ws/01_18_25/01/18/23/IR3NRKOP/QWNH3VKZ.mp4/master.m3u8?ha=2f24710b26aca59&hc=b40a360cf40c9d5&hi=2fc2e35a2a957ad&ht=838f706311be865&hu=64c384cf34d1250&t=1738142108

function onLoad()
	print('Hello from kinotazz.ru plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinotazz.ru plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/serialy-2020/page/
	-- #stream/genre=/collections/
	-- #stream/genre=/collections/filmy-pro-rozhdestvo-i-novyy-god/
	-- #stream/url=/serials/
	-- #stream/url=/serials/tureckie_serialy/
	-- #stream/url=/serials/brazilskie-serialy/
	-- #stream/url=/serials/indijskie_serialy/
	-- #stream/url=/serials/meksikanskie-serialy/
	-- #stream/url=/serials/ispanskie-serialy/
	-- #stream/url=/serials/doramy/
	-- #stream/url=/serials/novye_serialy/
    -- #stream/url=/filmy_online/filmy_2020_online_hd/
    -- #stream/url=/serials/amerikanskie-serialy/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or ''
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
		local x = http.getz(url)
		for url, title, image in string.gmatch(x, '<div class="th%-item".-href="(.-)" title="(.-)".-src="(.-)"') do
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
         for url, title, image  in string.gmatch(x, '<div class="collect%-box".-<a href="(.-)".-alt="(.-)".-class="collect%-img".-(/uploads.-)\'') do
			image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
		end
		
		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x = http.getz(HOME)
		local x = string.match(x, '<ul class="hd%-menu">(.-)</ul>')
		for id, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. id})
		end
        local x = http.getz(HOME)
		local x = string.match(x, '<nav class="side%-box to%-mob">(.-)</nav>')
		for id, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. id})
		end
       
--https://kinotazz.online/index.php?story={searchTerms}&do=search&subaction=search
       
        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')

    	local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'

    --    local x = http.post(url)
		
		local x = http.getz(url)
		
        for url, title, image in string.gmatch(x, '<div class="th%-item".-href="(.-)" title="(.-)".-src="(.-)"') do
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
       
        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
		--print(x)
		t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="descriptionnew" itemprop="description".-class="fsubtitle".-</h2>(.-)</div>')
		t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		

		
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр</div>.-)</div>', '(Страна</span>.-)</div>', '(Год</div>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
      
      
      
      
      
      for title3 in string.gmatch(x, '<iframe src="http.-api.-/.-/kp/(.-)"') do
      
      url1 = string.gsub(title3, '^(.-)', 'http://movixhd.online/lite/zetflix?kinopoisk_id=') 


    table.insert(t, {title = 'Zetflix', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
   
   
   for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total), mrl = url2})

       
    end
    
    
 --   local x = conn:load(url1)
        for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = http.getz(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = http.getz(url3)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end
  
  
  
  
  
  for title3 in string.gmatch(x, '<iframe src="http.-api.-/.-/kp/(.-)"') do
      
     url1 = string.gsub(title3, '^(.-)', 'http://movixhd.online/lite/videodb?kinopoisk_id=')
     --.. '&title=' .. title .. '&year=' .. title1 
  
  table.insert(t, {title = 'Videodb', mrl = '#stream/q=content&id=' .. url1, image = image})
		end
    
   --   local x = conn:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://movixhd.online')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://movixhd.online') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://movixhd.online') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://movixhd.online')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
  
      
      
      
      
      for title3 in string.gmatch(x, '<iframe src="http.-api.-/.-/kp/(.-)"') do
  
  
  url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
      local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end
    end
--end



  
       for title3 in string.gmatch(x, '<iframe src="http.-api.-/.-/kp/(.-)"') do

      url1 = string.gsub(title3, '^(.-)', 'http://93.183.92.183:9118/lite/mirage?kinopoisk_id=') .. '&uid=m7alois3'
    
--http://147.45.77.28:9118/lite/mirage?kinopoisk_id=386&uid=m7alois3
 
    
     local x = http.getz(url1)
     
     for  url2, url3,  total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
  
      url3 = string.gsub(url3, '\\u0026', '&')

    
       local x = http.getz(url2 .. url3)
    
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
    
       url4 = string.gsub(url4, '^(.-)', 'http://93.183.92.183:9118')
    
   --    t['view'] = 'simple'

    table.insert(t, {title = tolazy(total2) .. '(' .. tolazy(total3) .. ')', mrl = url4})

      end 
      end
     
  

      
       for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
       url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       
     url2 = string.gsub(url2, '\\u0026', '&')
     
   --  table.insert(t, {title = url2, mrl = url2})
     
      local x = http.getz(url2)


      for url3, url4, total1, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"url":"http.-(/lite/mirage)(.-)".-voice_name":"(.-)".-class="videos__item%-title">(.-серия)</div>') do

       url3 = string.gsub(url3, '^(.-)', 'http://93.183.92.183:9118')
       
     url4 = string.gsub(url4, '\\u0026', '&')
      local x = http.getz(url3 .. url4)
     local x = string.match(x, '"quality"(.-)}')
      for  total3, url5 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
   
     url5 = string.gsub(url5, '^(.-)', 'http://93.183.92.183:9118')
    
  --     t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total2) .. '(' .. total3 .. ')' .. '(' .. total1 .. ')', mrl = url5})

    end
end
end
 
  end  
		
	elseif args.q == 'play' then
        
       -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)
	--end
	end
	return t
end