-- tvshare plugin

require('support')
require('video')
require('parser')



TV_URL = 'https://iptvx.one/epg/epg.xml.gz, http://epg.it999.ru/edem.xml.gz'

TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4



HOME = 'http://tvshare.xyz'


HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from tvshare plugin')
	return 1
end

function onUnLoad()
	print('Bye from tvshare plugin')
end

function onCreate(args)



	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end


	if not args.q then

		local url = HOME .. '/settings_iptv/get_Server2.php?login=XMMNV9GLGD7QHV&server=2&group=Russia-Serials'
		
			url = url 

	
    	
		local x = http.getz(url)


		for title, url in string.gmatch(x, '#EXTINF.-,(.-)(http.-m3u8)') do

          local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(title)
			table.insert(t, {title = title, mrl = url, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})


		end


	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end