-- filmix plugin
-- © iconBIT 2020

require('video')
require('parser')
require('support')
require('client')
require('fxml')

local fxml = onCreate




local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'




local HOME = 'https://filmix.moe'
--local HOME = 'https://filmix.fm'
--local HOME = 'https://filmix.my'
local HOME_PATH = HOME .. '/'

local conn = client.new()
local conn1 = client.new()
conn['encoding'] = 'windows-1251'
conn1['encoding'] = 'utf-8'

conn['root'] = HOME_SLASH

--HOME = 'https://filmix.co'
--HOME = 'https://filmix.site'
--HOME = 'https://filmix.zone'
--HOME = 'https://filmix.today'
--HOME = 'https://filmix.ink'
--HOME = 'https://filmix.online'
--HOME = 'https://filmix.email'
--HOME = 'https://filmix.agency'
--HOME = 'https://filmix.casa'
--HOME = 'https://filmix.ltd'
--HOME = 'https://filmix.wiki'
--HOME = 'https://filmix.click'
--HOME = 'https://filmix.ac'
--HOME = 'http://filmix.vip:8080'
HOME_PATTERN = string.gsub(HOME, '%.', '%%.')
--HOME_PATH = HOME .. '/'
-- https://filmix.red/?box_mac=1234

FILMIXNET = ''

-- #stream/q=content&id=https://filmix.biz/multseries/animes/138925-igra-darvina-2020.html
-- file:///sdcard/filmix.IMC.zip?q=content&id=https://filmix.biz/multseries/animes/138925-igra-darvina-2020.html

print(HOME)
print(HOME_PATTERN)
print(HOME_PATH)

UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0'

function onLoad()
	print('Hello from filmix plugin')
	return 1
end

function onUnLoad()
	print('Bye from filmix plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder', menu = {}}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
--~ 
if args.q ~= 'years' then
--~ 	
table.insert(t['menu'],{title = '@string/years', mrl = '#folder/q=years', image = '#self/list.png'})
--~ 
end
	table.insert(t['menu'], {title = '@string/preferences', mrl = '#folder/q=setup', image = '#self/settings.png'})
	
	-- #self/page=2
	-- #stream/genre=/boevik/&page=2
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
	--	if page > 1 then
		
		if page > 1 then
			if genre == '/' then
				url = url .. 'pages/' .. tostring(page) .. '/'
			else
				url = url .. 'page/' .. tostring(page) .. '/'
			end
		end
     	if genre == '' then
        local url = HOME .. genre
        if page > 1 then
		url = url .. '/page/' .. tostring(page) .. '/'
        end
        end
		  
--https://filmix.my/playlists
	--	  if genre == '/playlists/' then
     --   local url = HOME .. genre
   --     if page > 1 then
--		url = url .. 'page/' .. tostring(page) .. '/'
    --    end
   --     end
		    
		print(url)
		local x = conn:load(url)
		--if x then io.open('/sdcard/page.txt', 'w+'):write(x):close() end
		
      
		
      for image, title,  url  in string.gmatch(x, '<article class="shortstory line".-<img src="(.-)".-alt="(.-)".-<a class="watch icon%-play" itemprop="url" href="(.-)"') do
		--	image = string.gsub(image, '^/', HOME_PATH)
	
		
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
		

		 for  image, url, title   in string.gmatch(x, '<article class="persone line shortstory".-<img src="(.-)".-<a href=".-(/person.-)">(.-)</a>') do
    --    t['view'] = 'simple'
		 table.insert(t, {title = title, mrl = '#stream/genre=' .. url, image = image})
		end
		
        
		
        for  image, url, title   in string.gmatch(x, '<article class="line shortstory  pl".-<img src="(.-)".-<h3 class="name".-<a href=".-(/playlist.-)">(.-)</a>') do
    --    t['view'] = 'simple'
		 table.insert(t, {title = title, mrl = '#stream/genre=' .. url, image = image})
		end
   
    	
		
         local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})

		
		

	-- #self/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
--https://filmix.zone/playlists
      table.insert(t, {title = 'Подборка', mrl = '#stream/genre=' .. '/playlists'})		
		local x = conn:load(HOME)
		for title, genres in string.gmatch(x, '<span class="menu%-title">(.-)</span>(.-)</div>') do
			print(title)
			if title ~= 'Тексты' then
				for id, genre in string.gmatch(genres, '<a href="' .. HOME_PATTERN .. '([^"]+).->(.-)</a>') do
					if genre ~= 'Плейлисты' and genre ~= 'По алфавиту' then
						table.insert(t, {title = title .. ': ' .. genre, mrl = '#stream/genre=' .. id})
					end
				end
			end
		end
	elseif args.q == 'years' then
		t['message'] = '@string/years'
		t['view'] = 'simple'
		local x = conn:load(HOME .. '/search')
		local min = string.match(x, 'data%-year%-min="(%d+)"')
		local max = string.match(x, 'data%-year%-max="(%d+)"')
		for i = tonumber(min), tonumber(max) do
			local year = tostring(i)
			table.insert(t, {title = year, mrl = '#stream/q=search&year=' .. year})
		end
	elseif args.q == 'search' then
		if not args.keyword and not args.year then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		if args.keyword then
			t['message'] = args.keyword
		else
			t['message'] = args.year
		end
--~ 		if FILMIXNET == '' then
--~ 			conn:load(HOME_PATH)
--~ 		end
		local page = tonumber(args.page or 1)
		local r = {}
		local headers = {}
		headers['User-Agent'] = UserAgent
		headers['Referer'] = HOME
		if FILMIXNET ~= '' then
			headers['Cookie'] = 'FILMIXNET=' .. FILMIXNET .. ';'
		end
		
		local url = HOME .. '/search/' .. (args.keyword or args.year)
		conn:load(url, headers, r)
		--r['set-cookie'] = string.gsub(r['set-cookie'], '[a-z_]+=deleted[^\n]+', '')
		FILMIXNET = string.match(r['set-cookie'] or '', 'FILMIXNET=(.-);') or FILMIXNET
		
		local data =
		{
			scf = 'fx',
			search_start = page,
			['do'] = 'search', subaction = 'search',
			years_ot = 1902, years_do = os.date('%Y'),
			kpi_ot = 1, kpi_do = 10,
			imdb_ot = 1, imdb_do = 10,
			sort_name = '', undefined = 'asc',
			sort_date = '', sort_favorite = '',
			simple = '1'
		}
		if args.keyword then
			data['story'] = args.keyword
		else
			data['years_ot'] = args.year
			data['years_do'] = args.year
		end
		data = http.encode(data)
		
		headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		headers['X-Requested-With'] = 'XMLHttpRequest'
		headers['Referer'] = url
		--headers['Cookie'] = r['set-cookie']
		headers['Cookie'] = 'FILMIXNET=' .. FILMIXNET .. ';'
		print(headers['Cookie'])
		
		local x = http.post(HOME .. '/engine/ajax/sphinx_search.php', headers, data, responses)
		--print(r['set-cookie'])
		--print(x)
		
		
     --  for title in string.gmatch(x, '<meta charset=(.-)var user_data') do
		
		for image, url, title in string.gmatch(x, '<div class="short">.-src="(.-)".-<a itemprop="url" href="(.-)".->(.-)</a>') do
		--	image = string.gsub(image, '^/', HOME_PATH)
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end
		local title = L'page' .. ' ' .. tostring(page + 1)
		local url
		if args.keyword then


       url = '#stream/q=search&page=' .. tostring(page + 1) .. '&keyword=' .. urlencode(args.keyword)

	--		url = '#stream/q=search&page=' .. tostring(page + 1) .. '&keyword=' .. urlencode(args.keyword)
		else
			url = '#stream/q=search&page=' .. tostring(page + 1) .. '&year=' .. urlencode(args.year)
		end
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})
			
  
        

	-- #stream/q=content&id=https://filmix.quest/multseries/animes/138925-igra-darvina-2020.html

    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
	--	local x = conn:load(args.id)
    	
		local r = {}
		local x = conn:load(args.id, r)
		t['name'] = parse_match(x, 'class="name" itemprop="name">(.-)</')
		t['description'] = parse_match(x, '<div class="full%-story">(.-)</div>')
		t['poster'] = parse_match(x, 'class="fullstory.-<img src="(.-)"')
		t['poster'] = string.gsub(t['poster'] or '', '^/', HOME_PATH)
		t['annotation'] = parse_array(x, {
			'(Режиссёр:.-)</div>', '(В ролях:.-)</div>', '(Сценарий:.-)</div>', '(Продюсер: .-)</div>',
			'(Жанр:.-)</div>', '(Страна:.-)</div>', '(Год:.-)</div>', '(Время:.-)</div>', '(Перевод:.-)</div>'
		})
		
for id in string.gmatch(x, 'film_id = (.-);') do

--table.insert(t, {title = 'Тест', mrl = '#stream/q=filmixmoe&id=' .. id, image = image})

table.insert(t, {title = 'Смотреть', mrl = '#stream/q=filmixlite&id=' .. id, image = image})
table.insert(t, {title = 'Плеер', mrl = '#stream/q=kino4k&id=' .. id, image = image})

--id = string.gsub(id, '^(.-)', 'item/')

--table.insert(t, {title = 'Плеер', mrl = '#stream/q=kinofit&id=' .. id, image = image})


end







  -- for title, title1 in string.gmatch(x, '<h1.->(.-)</h1>.-alt=".-,(.-)"') do


--for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-) смотреть.-, (.-)"') do

   --   title = urlencode(title)
      
   --   title = string.gsub(title, '+', '%%20')
--url = string.gsub(title, '^(.-)', 'https://api.bhcesh.me/list?token=eedefb541aeba871dcfc756e6b31c02e&name=') .. '&year=' .. title1



for id in string.gmatch(x, 'film_id = (.-);') do

id = string.gsub(id, '^(.-)', 'http://wtch.ch/lite/fxapi?postid=')

    local x = conn1:load(id)

--table.insert(t, {title = id, mrl = id})
    
    
    local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
  --  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
  --  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
  --  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
  --  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  

     
  --   local x = conn:load('http://peppega.ru/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn1:load('http://wtch.ch' .. url3)


--table.insert(t, {title = url3, mrl = '#stream/q=filmixz&id=' .. url3})

      for id, id1, id2, id3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)&postid=(.-)&.-&s=(.-)&t=(.-)".->(.-)</div>') do


--t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2, mrl = '#stream/q=filmixz&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})


end
end
end


   elseif args.q == 'filmixz' then


--https://lamp-movie.ru/lite/filmix?rjson=False&postid=169903&title=&original_title=&s=1&t=0

     local x = conn1:load('http://wtch.ch' .. args.id .. '&postid=' .. args.id1 .. '&title=&original_title=&s=' .. args.id2 .. '&t=' .. args.id3)



local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

     end  
    end
    
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
      t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

      end 
    end 
    
  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

     end  
    end  
   
local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

       end
    end 
  


elseif args.q == 'kinofit' then




--args.id = string.gsub(args.id, '^(.-)', 'item/')
         
   --      args.id=base64_encode(args.id)
 

 
       local x = conn1:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. base64_encode(args.id) .. '&box_mac=acace24b8434')


     
     
     for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn1:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = (total1) .. ' ' .. tolazy(total), mrl = url2})
    
        end
        end
        
  
      




     local x = conn1:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. base64_encode(args.id) .. '&box_mac=acace24b8434')


--table.insert(t, {title = 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. base64_encode(args.id) .. '&box_mac=acace24b8434', mrl = '#stream/q=kinofits&id=' .. 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. base64_encode(args.id) .. '&box_mac=acace24b8434'})

      for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  


  
       total = string.gsub(total, '<!%[CDATA%[', '')
       total = string.gsub(total, ']]>', '')
       
     local x = conn1:load(url1 .. '&box_mac=acace24b8434')




    
    for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-сезон).-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
       total1 = string.gsub(total1, ']]> <![CDATA[', '')
       total1 = string.gsub(total1, ']]>', '')
   
        local x = conn1:load(url2 .. '&box_mac=acace24b8434')
   

     
     for total2, total3, url3 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<playlist_url><!%[CDATA%[http.-&goto=(.-)&.-]]') do
    
 --     total2 = string.gsub(total2, '<!%[CDATA%[', '')
   --   total2 = string.gsub(total2, ']]>', '')
 
 
 t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total2) .. ' ' .. tolazy(total), mrl = '#stream/q=kinofits&id=' .. url3})
 
 end
 end
 end
-- end
 
 
 elseif args.q == 'kinofits' then

local x = conn1:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. args.id .. '&viewseason' .. '&box_mac=acace24b8434')
 
 
      
  --    local x = conn:load(url3 .. '&box_mac=acace24b8434')
 
     
     
     for total4, url4 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]].-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do
    
       total4 = string.gsub(total4, '<!%[CDATA%[', '')
      total4 = string.gsub(total4, ']]>', '')
    
    
    
      t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total4), mrl = url4})
    
        end



--https://api.filmix.tv/api-fx/post/3618/video-links

--https://api.filmix.tv/api-fx/list?search=Чужой+1979&limit=48
	  







--https://filmix.moe/play/172721


elseif args.q == 'filmixmoe' then

local url = 'https://filmix.moe/api/movies/player-data?t=1781801052233'
--&user_dev_apk=2.0.1&user_dev_id=&user_dev_name=Xiaomi&user_dev_os=11&user_dev_token=312d49d3a497a488609f411dc8005380&user_dev_vendor=Xiaomi'

--post_id=172721&showfull=true

local headers = {
    ["Host"] = "filmix.moe",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "application/json, text/javascript, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Content-Length"] = "",
    ["Origin"] = "https://filmix.moe",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://filmix.moe/play/" .. args.id,
    ["Cookie"] = "user_dev_token=312d49d3a497a488609f411dc8005380; x-a-key=sinatra; minotaurs=ERzKEXocdigkU8CFGW8AcvyD%2Bfex%2BwsHF9jgmSGxNY4%3D; FILMIXNET=edmrlnm15kr53rajg6cotj1i5o; _ga_GYLWSWSZ3C=GS2.1.s1781800986$o1$g1$t1781801052$j58$l0$h0; _ga=GA1.1.1474378574.1781800987; ishimura=722118a57e08fce7f1c48ffe0ead845106d7ccfc; alora=ERzKEXocdigkU8CFGW8AcvyD%2Bfex%2BwsHF9jgmSGxNY4%3D",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local params = '&post_id=' .. args.id .. '&showfull=true'


local x = http.postz(url, headers, params)




local slist = string.match(x,'"#2(.-)"')

slist = urldecode(slist)

silst = string.gsub(slist, ':<:SURhQnQwOEM5V2Y3bFlyMGVI', '')

silst = string.gsub(silst, ':<:bE5qSTlWNVUxZ01uc3h0NFFy', '')

silst = string.gsub(silst, ':<:bzl3UHQwaWk0MkdXZVM3TDdB', '')

silst = string.gsub(silst, ':<:Mm93S0RVb0d6c3VMTkV5aE54', '')

silst = string.gsub(silst, ':<:MTluMWlLQnI4OXVic2tTNXpU', '')

--url = string.gsub(url, '#2', '')


--url = url_for(slist)

--url = urldecode(url)

slist = base64_decode(slist)


for gual, url in string.gmatch(slist,'%[(%d+p)](.-mp4)') do


table.insert(t, {title = url, mrl = url})

end






elseif args.q == 'kino4k' then
  
--http://wtch.ch/lite/fxapi
  
  
  
 -- https://akter-black.com/lite/filmix?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn
  
    
    -- local x = conn:load(args.id)
    
    local x = conn1:load('https://get-balancer.akter-black.com/lite/fxapi?postid=' .. args.id)
   
   -- table.insert(t, {title = 'https://get-balancer.akter-black.com/lite/fxapi?post_id=' .. args.id, mrl = 'https://get-balancer.akter-black.com/lite/fxapi?post_id=' .. args.id})
    
    
	--	local x = conn:load('http://wtch.ch/lite/fxapi?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
 
 
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 

    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
   if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do
--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
    
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end

    
end
end





elseif args.q == 'filmixlite' then

      local x = conn1:load('https://api.filmix.tv/api-fx/post/' .. args.id .. '/video-links')



x = string.gsub(x, '\\', '')

--x = string.gsub(x, '"http.-.mp4"', '')


local video = string.match(x, '{"season":null(.-)"video"}]')



if video then

local video1 = string.match(video, '"files":%[(.-)"updated"') do

if video1 then

for url, url1, total in string.gmatch(video1,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video1,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
end
end


local video2 = string.match(video, '"files".-"files":%[(.-)"updated"') do

if video2 then


for url, url1, total in string.gmatch(video2,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video2,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
 end
 end
 
 
local video3 = string.match(video, '"files".-"files".-"files":%[(.-)"updated"') do


if video3 then

for url, url1, total in string.gmatch(video3,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video3,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
 end
 end
 
 local video4 = string.match(video, '"files".-"files".-"files".-"files":%[(.-)"updated"') do

if video4 then

for url, url1, total in string.gmatch(video4,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video4,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
 end
 end
 
local video5 = string.match(video, '"files".-"files".-"files".-"files".-"files":%[(.-)"updated"') do

if video5 then

for url, url1, total in string.gmatch(video5,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video5,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
 end
 end

 
 end




x = string.gsub(x, '"http.-.mp4"', '')

       for url1, url2, url3, url4, url5, total in string.gmatch(x,'"url":"(http.-/hls/)(.-)(/s%d+)(e%d+)(_.-)".-quality":(.-),') do


			

    title1 = string.gsub(url3, '/s', 'Сезон ')
    title = string.gsub(url4, 'e', 'серия  ')
    
    title2 = string.gsub(url2, '(.-%d)', '')
    
      t['view'] = 'list'
      
      table.insert(t, {title = '(' .. total .. 'p)' .. title1 .. ' ' .. title .. ' ' .. title2, mrl = url1 .. url2 .. url3 .. url4 .. url5, image = '#self/movie.png'})
      

      end
	

     

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end