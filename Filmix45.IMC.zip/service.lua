-- filmix plugin
-- © iconBIT 2020

require('video')
require('parser')
require('support')
require('client')
require('fxml')

local fxml = onCreate




local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'





local HOME = 'https://filmix.fm'
local HOME_PATH = HOME .. '/'

local conn = client.new()
local conn1 = client.new()
conn['encoding'] = 'windows-1251'
conn1['encoding'] = 'utf-8'

conn['root'] = HOME_SLASH

--HOME = 'https://filmix.co'
--HOME = 'https://filmix.site'
--HOME = 'https://filmix.zone'
--HOME = 'https://filmix.today'
--HOME = 'https://filmix.ink'
--HOME = 'https://filmix.online'
--HOME = 'https://filmix.email'
--HOME = 'https://filmix.agency'
--HOME = 'https://filmix.casa'
--HOME = 'https://filmix.ltd'
--HOME = 'https://filmix.wiki'
--HOME = 'https://filmix.click'
--HOME = 'https://filmix.ac'
--HOME = 'http://filmix.vip:8080'
HOME_PATTERN = string.gsub(HOME, '%.', '%%.')
--HOME_PATH = HOME .. '/'
-- https://filmix.red/?box_mac=1234

FILMIXNET = ''

-- #stream/q=content&id=https://filmix.biz/multseries/animes/138925-igra-darvina-2020.html
-- file:///sdcard/filmix.IMC.zip?q=content&id=https://filmix.biz/multseries/animes/138925-igra-darvina-2020.html

print(HOME)
print(HOME_PATTERN)
print(HOME_PATH)

UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0'

function onLoad()
	print('Hello from filmix plugin')
	return 1
end

function onUnLoad()
	print('Bye from filmix plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder', menu = {}}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
--~ 
if args.q ~= 'years' then
--~ 	
table.insert(t['menu'],{title = '@string/years', mrl = '#folder/q=years', image = '#self/list.png'})
--~ 
end
	table.insert(t['menu'], {title = '@string/preferences', mrl = '#folder/q=setup', image = '#self/settings.png'})
	
	-- #self/page=2
	-- #stream/genre=/boevik/&page=2
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
	--	if page > 1 then
		
		if page > 1 then
			if genre == '/' then
				url = url .. 'pages/' .. tostring(page) .. '/'
			else
				url = url .. 'page/' .. tostring(page) .. '/'
			end
		end
     	if genre == '' then
        local url = HOME .. genre
        if page > 1 then
		url = url .. 'page/' .. tostring(page) .. '/'
        end
        end
		    
		print(url)
		local x = conn:load(url)
		--if x then io.open('/sdcard/page.txt', 'w+'):write(x):close() end
		
      
		
      for image, title,  url  in string.gmatch(x, '<article class="shortstory line".-<img src="(.-)".-alt="(.-)".-<a class="watch icon%-play" itemprop="url" href="(.-)"') do
		--	image = string.gsub(image, '^/', HOME_PATH)
	
		
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
		

		 for  image, url, title   in string.gmatch(x, '<article class="persone line shortstory".-<img src="(.-)".-<a href=".-(/person.-)">(.-)</a>') do
    --    t['view'] = 'simple'
		 table.insert(t, {title = title, mrl = '#stream/genre=' .. url, image = image})
		end
		
        
		
        for  image, url, title   in string.gmatch(x, '<article class="line shortstory  pl".-<img src="(.-)".-<h3 class="name".-<a href=".-(/playlist.-)">(.-)</a>') do
    --    t['view'] = 'simple'
		 table.insert(t, {title = title, mrl = '#stream/genre=' .. url, image = image})
		end
   
    	
		
         local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})

		
		

			-- #self/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x = conn:load(HOME)
		


      table.insert(t, {title = 'Популярное' .. ': ', mrl = '#stream/genre=' .. '/popular/'})
      table.insert(t, {title = ' Сейчас смотрят' .. ': ', mrl = '#stream/genre=' .. '/viewing/'})

        table.insert(t, {title = 'Подборки' .. ': ' .. 'все', mrl = '#stream/genre=' .. '/playlists/'})
		
       table.insert(t, {title = 'Подборки' .. ': ' .. 'фильмы', mrl = '#stream/genre=' .. '/playlists/films/'})

       table.insert(t, {title = 'Подборки' .. ': ' .. 'сериалы', mrl = '#stream/genre=' .. '/playlists/serials/'})
       
       table.insert(t, {title = 'Подборки' .. ': ' .. 'мультфильмы', mrl = '#stream/genre=' .. '/playlists/multfilms/'})

	
    table.insert(t, {title = 'Актеры' .. ': ', mrl = '#stream/genre=' .. '/persons/'})
	
		table.insert(t, {title = 'Фильмы' .. ': ' .. '2024', mrl = '#stream/genre=' .. '/films/y2024/'})
		
       table.insert(t, {title = 'Фильмы' .. ': ' .. '2023', mrl = '#stream/genre=' .. '/films/y2023/'})
       table.insert(t, {title = 'Фильмы' .. ': ' .. '2022', mrl = '#stream/genre=' .. '/films/y2022/'})
		
		
		
		
		for title, genres in string.gmatch(x, '<span class="menu%-title">(.-)</span>(.-)</div>') do
			print(title)
			if title ~= 'Тексты' then
				for id, genre in string.gmatch(genres, '<a href="' .. HOME_PATTERN .. '([^"]+).->(.-)</a>') do
					if genre ~= 'Плейлисты' and genre ~= 'По алфавиту' then
						table.insert(t, {title = title .. ': ' .. genre, mrl = '#stream/genre=' .. id})
					end
				end
			end
		end
	elseif args.q == 'years' then
		t['message'] = '@string/years'
		t['view'] = 'simple'
		local x = conn:load(HOME .. '/search')
		local min = string.match(x, 'data%-year%-min="(%d+)"')
		local max = string.match(x, 'data%-year%-max="(%d+)"')
		for i = tonumber(min), tonumber(max) do
			local year = tostring(i)
			table.insert(t, {title = year, mrl = '#stream/q=search&year=' .. year})
		end
	elseif args.q == 'search' then
		if not args.keyword and not args.year then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		if args.keyword then
			t['message'] = args.keyword
		else
			t['message'] = args.year
		end
--~ 		if FILMIXNET == '' then
--~ 			conn:load(HOME_PATH)
--~ 		end
		local page = tonumber(args.page or 1)
		local r = {}
		local headers = {}
		headers['User-Agent'] = UserAgent
		headers['Referer'] = HOME
		if FILMIXNET ~= '' then
			headers['Cookie'] = 'FILMIXNET=' .. FILMIXNET .. ';'
		end
		
		local url = HOME .. '/search/' .. (args.keyword or args.year)
		conn:load(url, headers, r)
		--r['set-cookie'] = string.gsub(r['set-cookie'], '[a-z_]+=deleted[^\n]+', '')
		FILMIXNET = string.match(r['set-cookie'] or '', 'FILMIXNET=(.-);') or FILMIXNET
		
		local data =
		{
			scf = 'fx',
			search_start = page,
			['do'] = 'search', subaction = 'search',
			years_ot = 1902, years_do = os.date('%Y'),
			kpi_ot = 1, kpi_do = 10,
			imdb_ot = 1, imdb_do = 10,
			sort_name = '', undefined = 'asc',
			sort_date = '', sort_favorite = '',
			simple = '1'
		}
		if args.keyword then
			data['story'] = args.keyword
		else
			data['years_ot'] = args.year
			data['years_do'] = args.year
		end
		data = http.encode(data)
		
		headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		headers['X-Requested-With'] = 'XMLHttpRequest'
		headers['Referer'] = url
		--headers['Cookie'] = r['set-cookie']
		headers['Cookie'] = 'FILMIXNET=' .. FILMIXNET .. ';'
		print(headers['Cookie'])
		
		local x = http.post(HOME .. '/engine/ajax/sphinx_search.php', headers, data, responses)
		--print(r['set-cookie'])
		--print(x)
		for image, url, title in string.gmatch(x, '<div class="short">.-src="(.-)".-<a itemprop="url" href="(.-)".->(.-)</a>') do
			image = string.gsub(image, '^/', HOME_PATH)
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end
		local title = L'page' .. ' ' .. tostring(page + 1)
		local url
		if args.keyword then
			url = '#stream/q=search&page=' .. tostring(page + 1) .. '&keyword=' .. urlencode(args.keyword)
		else
			url = '#stream/q=search&page=' .. tostring(page + 1) .. '&year=' .. urlencode(args.year)
		end
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})
			
  
        

	-- #stream/q=content&id=https://filmix.quest/multseries/animes/138925-igra-darvina-2020.html

    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
	--	local x = conn:load(args.id)
    	
		local r = {}
		local x = conn:load(args.id, r)
		t['name'] = parse_match(x, 'class="name" itemprop="name">(.-)</')
		t['description'] = parse_match(x, '<div class="full%-story">(.-)</div>')
		t['poster'] = parse_match(x, 'class="fullstory.-<img src="(.-)"')
		t['poster'] = string.gsub(t['poster'] or '', '^/', HOME_PATH)
		t['annotation'] = parse_array(x, {
			'(Режиссёр:.-)</div>', '(В ролях:.-)</div>', '(Сценарий:.-)</div>', '(Продюсер: .-)</div>',
			'(Жанр:.-)</div>', '(Страна:.-)</div>', '(Год:.-)</div>', '(Время:.-)</div>', '(Перевод:.-)</div>'
		})
		
	
    	for url in string.gmatch(x, 'film_id = (.-);') do
	
    url = string.gsub(url, '^(.-)', 'https://api.filmix.tv/api-fx/post/') .. '/video-links'
	  
	  table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url, image = image})
     end
   
      --  local x = conn1:load('https://api.filmix.tv/api-fx/post/' .. url .. '/video-links')


     --    x = string.match(x, '"season":null,(.-)<div class="json%-formatter%-container')
   
        for url, title in string.gmatch(x,'quality.-:720.-url.-(http.-_480.mp4).-"voiceover":"(.-)",') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. '/'})
	--	end
      
   --   for title in string.gmatch(x, '"season":null,') do




   --   for url, title in string.gmatch(x, 'quality.-:720.-url.-(http.-_480.mp4).-"voiceover":"(.-)",') do
 
    --  for url, total in string.gmatch(x, '"url".-(http.-480.mp4).-voiceover.-"(.-)"') do
      
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
        
      

      
       url = string.gsub(url, '\\', '')
      
      t['view'] = 'simple'
      table.insert(t, {title = title, mrl = url, image = image})
   --   end
      end



      --"LostFilm".-"season":(.-),.-"episode":(.-),"

      for title in string.gmatch(x, '"(LostFilm)') do
      
      --.-"season":(.-),.-episode":(.-),') do

         for total in string.gmatch(x, '"season":(.-),') do


      for total1, url in string.gmatch(x, '"episode":(.-),.-"files.-_1080.mp4.-"url":"(http.-_480.mp4)","quality":480,"proPlus":false') do
 
      url = string.gsub(url, '\\', '')
      
      t['view'] = 'simple'
      table.insert(t, {title = title .. 'Сезон ' .. (total) .. 'серия ' .. (total1), mrl = url})
      end
      end
      end






    --     for url in string.gmatch(x, 'film_id = (.-);') do

 
   --      url = string.gsub(url, '^(.-)', 'http://filmixapp.cyou/api/v2/post/') .. '?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380'
         
         
     --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
         
	--		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url, image = image})
	--	end


   --   for title  in string.gmatch(x, 'class="name" itemprop="name">(.-)</') do

    --     print(url)
		 

     --    url = string.gsub(title, '^(.-)', 'http://xplay.bz/list?search=')
         
     --    local x = fxml({url = url})
    --    for url in string.gmatch(url, '"playlist_url":"(.-)"') do
        
 
       
   --     local x = fxml({url = url})
    --    for _, v in ipairs(x) do
 

    --	if string.find(v.mrl, '^#') then
    	
		--	v.mrl = v.mrl .. '&package=' .. urlencode(REPO .. 'xplay.IMC.zip')
	--	end
--		table.insert(t, v)
--	end
    --  end 





         for url, title in string.gmatch(x, '"trailer":%[{"link":"(.-)%[.-480.-](.-)","translation":"(.-)"') do
			url = string.gsub(url, '\\', '')
        --	url = string.gsub(url, '^', '')
           t['view'] = 'simple'
				table.insert(t, {title = 'трейлер', mrl = url .. '480' .. title}) 

		end


	
         for url, title in string.gmatch(x, '"movie":%[{"link":"(.-)%[.-720.-](.-)","translation":"(.-)"') do
			url = string.gsub(url, '\\', '')
        --	url = string.gsub(url, '^', '')
           t['view'] = 'simple'
				table.insert(t, {title = '720p', mrl = url .. '720' .. title}) 

		end
		
        for url, title in string.gmatch(x, '"movie":%[{"link":"(.-)%[.-480.-](.-)","translation":"(.-)"') do
			url = string.gsub(url, '\\', '')
        --	url = string.gsub(url, '^', '')
            t['view'] = 'simple'
				table.insert(t, {title = '480p', mrl = url .. '480' .. title}) 

		end
		
       for title, url in string.gmatch(x, ',"(.-)":{"link":"(https.-)","qualities":%[.-]') do
			url = string.gsub(url, '\\', '')
        	url = string.gsub(url, '%%s', '480')
        	
        	
        	
title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
        	
        	
            t['view'] = 'simple'
				table.insert(t, {title = tolazy(title) .. ' серия', mrl = url}) 

		end



        for url  in string.gmatch(x, '<h1.->(.-)</h1>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
        table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    
        end
    
    
    --     local x = http.getz(url)
         for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   

         url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
--		table.insert(t, {title = 'Zagonka плеер', mrl = '#stream/q=content&id=' .. url})

	--	end
     
     
        
     
       local x = http.getz(url)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-(//video.zagonka.org/movies/.-})') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
			
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
		
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
    end
       
        
        
    end


	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end

