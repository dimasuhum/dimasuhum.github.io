-- filmix plugin
-- © iconBIT 2020

require('video')
require('parser')
require('support')
require('client')
require('fxml')

local fxml = onCreate




local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'





local HOME = 'https://filmix.biz'
local HOME_PATH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'windows-1251'
conn['root'] = HOME_SLASH

--HOME = 'https://filmix.co'
--HOME = 'https://filmix.site'
--HOME = 'https://filmix.zone'
--HOME = 'https://filmix.today'
--HOME = 'https://filmix.ink'
--HOME = 'https://filmix.online'
--HOME = 'https://filmix.email'
--HOME = 'https://filmix.agency'
--HOME = 'https://filmix.casa'
--HOME = 'https://filmix.ltd'
--HOME = 'https://filmix.wiki'
--HOME = 'https://filmix.click'
--HOME = 'https://filmix.ac'
--HOME = 'http://filmix.vip:8080'
HOME_PATTERN = string.gsub(HOME, '%.', '%%.')
--HOME_PATH = HOME .. '/'
-- https://filmix.red/?box_mac=1234

FILMIXNET = ''

-- #stream/q=content&id=https://filmix.biz/multseries/animes/138925-igra-darvina-2020.html
-- file:///sdcard/filmix.IMC.zip?q=content&id=https://filmix.biz/multseries/animes/138925-igra-darvina-2020.html

print(HOME)
print(HOME_PATTERN)
print(HOME_PATH)

UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0'

function onLoad()
	print('Hello from filmix plugin')
	return 1
end

function onUnLoad()
	print('Bye from filmix plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder', menu = {}}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
--~ 
if args.q ~= 'years' then
--~ 	
table.insert(t['menu'],{title = '@string/years', mrl = '#folder/q=years', image = '#self/list.png'})
--~ 
end
	table.insert(t['menu'], {title = '@string/preferences', mrl = '#folder/q=setup', image = '#self/settings.png'})
	
	-- #self/page=2
	-- #stream/genre=/boevik/&page=2
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
	--	if page > 1 then
		
		if page > 1 then
			if genre == '/' then
				url = url .. 'pages/' .. tostring(page) .. '/'
			else
				url = url .. 'page/' .. tostring(page) .. '/'
			end
		end
     	if genre == '' then
        local url = HOME .. genre
        if page > 1 then
		url = url .. 'page/' .. tostring(page) .. '/'
        end
        end
		    
		print(url)
		local x = conn:load(url)
		--if x then io.open('/sdcard/page.txt', 'w+'):write(x):close() end
		
      
		
      for image, title,  url  in string.gmatch(x, '<article class="shortstory line".-<img src="(.-)".-alt="(.-)".-<a class="watch icon%-play" itemprop="url" href="(.-)"') do
		--	image = string.gsub(image, '^/', HOME_PATH)
	
		
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
		

		 for  image, url, title   in string.gmatch(x, '<article class="persone line shortstory".-<img src="(.-)".-<a href=".-(/person.-)">(.-)</a>') do
    --    t['view'] = 'simple'
		 table.insert(t, {title = title, mrl = '#stream/genre=' .. url, image = image})
		end
		
        
		
        for  image, url, title   in string.gmatch(x, '<article class="line shortstory  pl".-<img src="(.-)".-<h3 class="name".-<a href=".-(/playlist.-)">(.-)</a>') do
    --    t['view'] = 'simple'
		 table.insert(t, {title = title, mrl = '#stream/genre=' .. url, image = image})
		end
   
    	
		
         local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})

		
		

			-- #self/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x = conn:load(HOME)
		


      table.insert(t, {title = 'Популярное' .. ': ', mrl = '#stream/genre=' .. '/popular/'})
      table.insert(t, {title = ' Сейчас смотрят' .. ': ', mrl = '#stream/genre=' .. '/viewing/'})

        table.insert(t, {title = 'Подборки' .. ': ' .. 'все', mrl = '#stream/genre=' .. '/playlists/'})
		
       table.insert(t, {title = 'Подборки' .. ': ' .. 'фильмы', mrl = '#stream/genre=' .. '/playlists/films/'})

       table.insert(t, {title = 'Подборки' .. ': ' .. 'сериалы', mrl = '#stream/genre=' .. '/playlists/serials/'})
       
       table.insert(t, {title = 'Подборки' .. ': ' .. 'мультфильмы', mrl = '#stream/genre=' .. '/playlists/multfilms/'})

	
    table.insert(t, {title = 'Актеры' .. ': ', mrl = '#stream/genre=' .. '/persons/'})
	
		table.insert(t, {title = 'Фильмы' .. ': ' .. '2024', mrl = '#stream/genre=' .. '/films/y2024/'})
		
       table.insert(t, {title = 'Фильмы' .. ': ' .. '2023', mrl = '#stream/genre=' .. '/films/y2023/'})
       table.insert(t, {title = 'Фильмы' .. ': ' .. '2022', mrl = '#stream/genre=' .. '/films/y2022/'})
		
		
		
		
		for title, genres in string.gmatch(x, '<span class="menu%-title">(.-)</span>(.-)</div>') do
			print(title)
			if title ~= 'Тексты' then
				for id, genre in string.gmatch(genres, '<a href="' .. HOME_PATTERN .. '([^"]+).->(.-)</a>') do
					if genre ~= 'Плейлисты' and genre ~= 'По алфавиту' then
						table.insert(t, {title = title .. ': ' .. genre, mrl = '#stream/genre=' .. id})
					end
				end
			end
		end
	elseif args.q == 'years' then
		t['message'] = '@string/years'
		t['view'] = 'simple'
		local x = conn:load(HOME .. '/search')
		local min = string.match(x, 'data%-year%-min="(%d+)"')
		local max = string.match(x, 'data%-year%-max="(%d+)"')
		for i = tonumber(min), tonumber(max) do
			local year = tostring(i)
			table.insert(t, {title = year, mrl = '#stream/q=search&year=' .. year})
		end
	elseif args.q == 'search' then
		if not args.keyword and not args.year then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		if args.keyword then
			t['message'] = args.keyword
		else
			t['message'] = args.year
		end
--~ 		if FILMIXNET == '' then
--~ 			conn:load(HOME_PATH)
--~ 		end
		local page = tonumber(args.page or 1)
		local r = {}
		local headers = {}
		headers['User-Agent'] = UserAgent
		headers['Referer'] = HOME
		if FILMIXNET ~= '' then
			headers['Cookie'] = 'FILMIXNET=' .. FILMIXNET .. ';'
		end
		
		local url = HOME .. '/search/' .. (args.keyword or args.year)
		conn:load(url, headers, r)
		--r['set-cookie'] = string.gsub(r['set-cookie'], '[a-z_]+=deleted[^\n]+', '')
		FILMIXNET = string.match(r['set-cookie'] or '', 'FILMIXNET=(.-);') or FILMIXNET
		
		local data =
		{
			scf = 'fx',
			search_start = page,
			['do'] = 'search', subaction = 'search',
			years_ot = 1902, years_do = os.date('%Y'),
			kpi_ot = 1, kpi_do = 10,
			imdb_ot = 1, imdb_do = 10,
			sort_name = '', undefined = 'asc',
			sort_date = '', sort_favorite = '',
			simple = '1'
		}
		if args.keyword then
			data['story'] = args.keyword
		else
			data['years_ot'] = args.year
			data['years_do'] = args.year
		end
		data = http.encode(data)
		
		headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		headers['X-Requested-With'] = 'XMLHttpRequest'
		headers['Referer'] = url
		--headers['Cookie'] = r['set-cookie']
		headers['Cookie'] = 'FILMIXNET=' .. FILMIXNET .. ';'
		print(headers['Cookie'])
		
		local x = http.post(HOME .. '/engine/ajax/sphinx_search.php', headers, data, responses)
		--print(r['set-cookie'])
		--print(x)
		for image, url, title in string.gmatch(x, '<div class="short">.-src="(.-)".-<a itemprop="url" href="(.-)".->(.-)</a>') do
			image = string.gsub(image, '^/', HOME_PATH)
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end
		local title = L'page' .. ' ' .. tostring(page + 1)
		local url
		if args.keyword then
			url = '#stream/q=search&page=' .. tostring(page + 1) .. '&keyword=' .. urlencode(args.keyword)
		else
			url = '#stream/q=search&page=' .. tostring(page + 1) .. '&year=' .. urlencode(args.year)
		end
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})
			
  
        

	-- #stream/q=content&id=https://filmix.quest/multseries/animes/138925-igra-darvina-2020.html

    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
	--	local x = conn:load(args.id)
    	
		local r = {}
		local x = conn:load(args.id, r)
		t['name'] = parse_match(x, 'class="name" itemprop="name">(.-)</')
		t['description'] = parse_match(x, '<div class="full%-story">(.-)</div>')
		t['poster'] = parse_match(x, 'class="fullstory.-<img src="(.-)"')
		t['poster'] = string.gsub(t['poster'] or '', '^/', HOME_PATH)
		t['annotation'] = parse_array(x, {
			'(Режиссёр:.-)</div>', '(В ролях:.-)</div>', '(Сценарий:.-)</div>', '(Продюсер: .-)</div>',
			'(Жанр:.-)</div>', '(Страна:.-)</div>', '(Год:.-)</div>', '(Время:.-)</div>', '(Перевод:.-)</div>'
		})
		
	

         for url in string.gmatch(x, 'film_id = (.-);') do

 
         url = string.gsub(url, '^(.-)', 'http://filmixapp.cyou/api/v2/post/') .. '?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380'
         
			table.insert(t, {title = 'СМОТРЕТЬ', mrl = '#stream/q=content&id=' .. url, image = image})
		end


      for title  in string.gmatch(x, 'class="name" itemprop="name">(.-)</') do

         print(url)
		 

         url = string.gsub(title, '^(.-)', 'http://xplay.bz/list?search=')
         
     --    local x = fxml({url = url})
    --    for url in string.gmatch(url, '"playlist_url":"(.-)"') do
        
 
       
        local x = fxml({url = url})
        for _, v in ipairs(x) do
 

    	if string.find(v.mrl, '^#') then
    	
			v.mrl = v.mrl .. '&package=' .. urlencode(REPO .. 'xplay.IMC.zip')
		end
		table.insert(t, v)
	end
      end 





         for url, title in string.gmatch(x, '"trailer":%[{"link":"(.-)%[.-480.-](.-)","translation":"(.-)"') do
			url = string.gsub(url, '\\', '')
        --	url = string.gsub(url, '^', '')
           t['view'] = 'simple'
				table.insert(t, {title = 'трейлер', mrl = url .. '480' .. title}) 

		end


	
         for url, title in string.gmatch(x, '"movie":%[{"link":"(.-)%[.-720.-](.-)","translation":"(.-)"') do
			url = string.gsub(url, '\\', '')
        --	url = string.gsub(url, '^', '')
           t['view'] = 'simple'
				table.insert(t, {title = '720p', mrl = url .. '720' .. title}) 

		end
		
        for url, title in string.gmatch(x, '"movie":%[{"link":"(.-)%[.-480.-](.-)","translation":"(.-)"') do
			url = string.gsub(url, '\\', '')
        --	url = string.gsub(url, '^', '')
            t['view'] = 'simple'
				table.insert(t, {title = '480p', mrl = url .. '480' .. title}) 

		end
		
       for title, url in string.gmatch(x, '"(.-)":{"link":"(https.-)","qualities":%[.-]') do
			url = string.gsub(url, '\\', '')
        	url = string.gsub(url, '%%s', '480')
            t['view'] = 'simple'
				table.insert(t, {title = title .. ' серия', mrl = url}) 

		end

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end