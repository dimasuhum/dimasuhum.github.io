-- filmhd.newmulti-torrent.ru plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://3a9196768www.lafa.site'

--https://139c87b12www.lafa.site/film/

local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'windows-1251'
conn['root'] = HOME_SLASH


--HOME = 'https://3a9196768www.lafa.site'
--HOME_SLASH = HOME .. '/'


--https://3a9196768www.lafa.site/film/page/1/

function onLoad()
	print('Hello from filmhd.newmulti-torrent.ru plugin')
	return 1
end

function onUnLoad()
	print('Bye from filmhd.newmulti-torrent.ru plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=1
	-- #stream/page=2
	-- #stream/genre=/tag/2020-filmy/page/
	-- #stream/genre=/tag/2018/page/
	-- #stream/genre=/tag/2017/page/
	-- #stream/genre=/skachat-filmy-novinki-2019-v-horoshem-kachestve-cherez-torrent/page/

	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/torrentz/'
		
	--	https://139c87b12www.lafa.site/torrentz/page/1/
--https://139c87b12www.lafa.site/browse.php?search_podcateg=true&novinki=1&page=

		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
   
--#stream/page=3&genre=/browse.php?search_podcateg=true
   
         if genre == '/browse.php?search_podcateg=true&novinki=1' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. '&novinki=1&page=' .. tostring(page)
		end
        end
        -- local x = http.get(url)
         
         local x = conn:load(url)
         
     --   x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
    
    
    
         for  image, url, title  in string.gmatch(x, '<tr class="in_cinema".-<img class="latest_img lazy" data%-original="(/image.-)".-class="c_title".-<a href="(.-)".-alt="(.-)"') do
	
			url = string.gsub(url, '^/', HOME_SLASH)
            image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
	
    --    table.insert(t,{title = url, mrl = url, image = '#self/next.png'})
	
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
    elseif args.q == 'genres' then
		t['view']='simple'
		t['message']='@string/genres'
	
	
	
  --    table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/browse.php?search_podcateg=true&novinki=1'})
	
        local x = conn:load(HOME)

	   table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. '/film/'})

       table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serialy/'})

       table.insert(t, {title = 'Мульфильмы', mrl = '#stream/genre=' .. '/multfilm/'}) 
   
   
       local x = conn:load(HOME .. '/film/')
       for genre, title in string.gmatch(x, '<a class="menu_new_link" href="(/film.-)">(.-)</a>') do
    

    
    title = string.gsub(title, '&nbsp;', '')
        table.insert(t, {title = 'Фильмы' ..  ':' .. tolazy(title), mrl = '#stream/genre=' .. genre}) 
    	end
    
    
    
    local x = conn:load(HOME .. '/serialy/')
       for genre, title in string.gmatch(x, '<a class="menu_new_link" href="(/serialy.-)">(.-)</a>') do
    

    
    title = string.gsub(title, '&nbsp;', '')
        table.insert(t, {title = 'Сериалы' ..  ':' .. tolazy(title), mrl = '#stream/genre=' .. genre}) 
    	end
    
    

    
    
         local x = conn:load(HOME .. '/multfilm/')
       for genre, title in string.gmatch(x, '<a class="menu_new_link" href="(/multfilm.-)">(.-)</a>') do
    

    
    title = string.gsub(title, '&nbsp;', '')
        table.insert(t, {title = 'Мультфильмы' ..  ':' .. tolazy(title), mrl = '#stream/genre=' .. genre}) 
    	end
    

    
    
    	
--https://3a9196768www.lafa.site/torrentz/search/%D0%EE%EA%EA%E8/


   elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/torrentz/search/' .. urlencode(args.keyword) .. '/' --..  'page/' .. tostring(page) .. '/' 


		local x = conn:load(url)
		
        for  image, url, title  in string.gmatch(x, '<tr class="in_cinema".-<img class="latest_img lazy" data%-original="(/image.-)".-class="c_title".-<a href="(.-)".-alt="(.-)"') do
	
			url = string.gsub(url, '^/', HOME_SLASH)
            image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
  --  	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
	--	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})






	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
      --  x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
   --     t['name'] = parse_match(x,'<h1>(.-)скачать')
        
        t['name'] = parse_match(x,'<td class="rightrow norightborder notop"><span itemprop="name">(.-)</td>')
   

		t['description'] = parse_match(x, '<span itemprop="description" class="span_descr">(.-)</span>')
			t['poster'] = args.p
	    	t['annotation'] = parse_array(x, {'(Категория:</td>.-)</td>', 
			'(Страна:</td>.-)</td>',
			'(Год выпуска:</td>.-)</td>',
			'(В ролях:</td>.-)</td>',
})

   
 
              




   
   
   
   
   
        for total in string.gmatch(x, '<a.-rel="nofollow" href="magnet.-btih:(.-)&') do
        total = string.lower(total)
      
       url = string.gsub(total, '^(.-)','http://torr.unknot.ru:8090/stream/?link=') .. '&m3u'
      

        local x = http.get(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
      --   t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
      --   t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
    --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	

   
        
        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
		return video(args.url, args)
	end
	return t
end