-- kinodevice.net plugin

require('support')
require('video')
require('parser')

--HOME = 'https://kinomp4.biz'
HOME = 'https://mobikinchik.net'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinodevice.net plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinodevice.net plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	--table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2/
	-- #stream/genre=/history/page/
	-- #stream/genre=/erotic/page/

	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/films/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
       -- local x = http.getz(HOME .. '/')
        local x = http.getz(url)
       
         for  url, title, image in string.gmatch(x, '<div class="shortstory".-<a.-href="(.-)" title="Cкачать(.-)прямой ссылкой".-src="(.-)"') do
            --url = string.gsub(url, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
        local x = http.getz(HOME) 
       
        --local x = string.match(x, '<ul class="navbar%-nav navbar%-right">(.-)</ul>')
         --for genre, title in string.gmatch(x, '<a href="(/top100.html)".->(.-)</a>') do
			table.insert(t, {title = 'ТОП-100', mrl = '#stream/genre=' .. '/top100.html'})
		--end
		local x = http.getz(HOME) 
       
        local x = string.match(x, '<ul class="navbar%-nav navbar%-right">(.-)</ul>')
         for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
         local x = http.getz(HOME) 
       
        local x = string.match(x, '<ul class="nav%-list">(.-)</ul>')
         for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)

		--print(x)
		t['ref'] = args.id
        t['name'] = parse_match(x,'<h1.-</span>(.-)</h1>')
		t['description'] = parse_match(x, '<p itemprop="description".-</span>(.-)</p>')
			t['poster'] = args.p
	    	t['annotation'] = parse_array(x, {'(Качество: <small>.-)</small>', 
			'(Год, страна: <small>.-)</small>',
			'(Жанры: <small.->.-)</small>',
			'(Режиссер: <small.->.-)</small>',
			'(Актеры: <small.->.-)</small>',
			'(Перевод: <small>.-)</small>',
			'(Видео: <small>.-)</small>',
			'(Добавлено: <small.->.-)</small>','(Продолжительность:</span>.-)</li>','(Премьера :</span>.-)</li>'})
        --x = string.gsub(x, 'Смотреть онлайн', '')
        
  
          for url in string.gmatch(x, '<div class="vyrovnyat".-class="btn3 btn4" href="(.-mp4)"') do
           
	    --addvideo(t, url, t['name'])
		table.insert(t, {title = 'Смотреть', mrl = url})
		end 

       for url, title, image in string.gmatch(x, '<div class="shortstory2".-<a href="(.-html)" title="(.-)".-<img.-src="(.-jpg)"') do
        --   local url = '#stream/q=content&id=' .. url
	   --     print(url)
		--	t = video(url, args)
		--	if t['view'] ~= 'error' then
	--			break
		--	end
     --    table.insert(t, {title = title})
		table.insert(t, {title = title, mrl = '#stream/q=content&id=' ..  url, image = image})
		end  
        for url, title in string.gmatch(x, '<a.-href="(/go.php.-mp4)" title="Скачать(.-)"') do
           print(url)
		   url = string.gsub(url, '^(.-)', 'https://s1.mobkinchik.net')
	    --addvideo(t, url, t['name'])
		table.insert(t, {title = title, mrl = '#stream/q=content&id=' ..  url})
		end 
        
        for url, title in string.gmatch(x, '<a.-href="(/go3.php.-torrent)" title="Скачать(.-)"') do
           print(url)
		   url = string.gsub(url, '^(.-)', 'https://s1.mobkinchik.net')
	    --addvideo(t, url, t['name'])
		table.insert(t, {title = title, mrl = '#stream/q=content&id=' ..  url})
		end 
        for url in string.gmatch(x, '<div class="button%-1".-href="(.-)"') do
          -- print(url)
		--   url = string.gsub(url, '^(.-)', 'https://s1.kinomp4.biz/')
	    --addvideo(t, url, t['name'])
        t['view'] = 'grid'
		table.insert(t, {title = 'Смотреть', mrl = url})
		end 
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
		return video(args.url, args)
	end
	return t
end