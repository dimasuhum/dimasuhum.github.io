-- kadu plugin

require('support')
require('video')
require('parser')
require('client')


local HOME = 'https://oveg.ru'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'windows-1251'
conn['root'] = HOME_SLASH



--HOME = 'https://zloekino.su'
--HOME = 'https://krasview.ru'
--HOME = 'http://hlamer.ru'
--HOME = 'https://wseries.ru'
--HOME = 'https://oveg.ru'

--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kadu plugin')
	return 1
end

function onUnLoad()
	print('Bye from kadu plugin')
end

function onCreate(args)


	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	 --   table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/genre=/movie/tag/bdrip
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/movie'

		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end


        local x = conn:load(url)

        
		for url, title, image  in string.gmatch(x, '<li id=\'c.-<a href=.-(/movie.-)\' title=\'(.-)\'.-<img.-srcset=\'(http.-jpg)') do
	    	print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
       --    image = string.gsub(image, '^/', HOME_SLASH)
			
			
		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	
        for url, title, image  in string.gmatch(x, '<li id=\'c.-<a href=.-(/series.-)\' title=\'(.-)\'.-<img.-srcset=\'(http.-jpg)') do
	    	print(url)
	   	url = string.gsub(url, '^(.-)', HOME) .. '/?category=%-1'
       --    image = string.gsub(image, '^/', HOME_SLASH)
			
			
		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	
        for url, title, image  in string.gmatch(x, '<li id=\'c.-<a href=.-(/anime.-)\' title=\'(.-)\'.-<img.-srcset=\'(http.-jpg)') do
	    	print(url)
	   	url = string.gsub(url, '^(.-)', HOME) .. '/?category=%-1'
       --    image = string.gsub(image, '^/', HOME_SLASH)
			
			
		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	
--https://oveg.ru/series/Game_of_Thrones/?category=-1
	
	
	
	
        local x = conn:load(url)
        for url, title, image  in string.gmatch(x, '<li id=\'set.-<a href=.-(/set.-)\' title=\'(.-)\'.-<img.-srcset=.-(https.-jpg)') do
	    --	print(url)
	  -- 	url = string.gsub(url, '^(.-)', HOME)
           
			
			
		  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
	
	
	
		
       -- for url, image,   title in string.gmatch(x, '<div class="card%-body row text%-left".-<a href="(.-)".-data%-src="(.-)".-class="col%-md%-8".-<a href.->(.-)<') do
	--	print(url)
	--	url = string.gsub(url, '^/',HOME_SLASH)
          -- image = string.gsub(image, '^/', HOME_SLASH)
			
			
		--  table.insert(t, {title = tolazy(title), mrl = '#folder/genre' .. url, image = image})
	--	end
         
         
    --    for title,  url, total in string.gmatch(x, '<div class="playlist__heading"<a href=.->(.-)<.-class="strong" href="(.-)">(.-)<') do
	--	print(url)
	--	url = string.gsub(url, '^/',HOME_SLASH)
          -- image = string.gsub(image, '^/', HOME_SLASH)
			
			
	--	  table.insert(t, {title = tolazy(title) .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
         
		  
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


       table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/set'})		

         table.insert(t, {title = 'Фильмы :Топ по Кинопоиску', mrl = '#stream/genre=' .. '/movie/kinopoisk'})
         
         table.insert(t, {title = 'Фильмы :Последние', mrl = '#stream/genre=' .. '/movie/fresh'})
         table.insert(t, {title = 'Фильмы :Топ за всё время', mrl = '#stream/genre=' .. '/movie/top'})
         table.insert(t, {title = 'Фильмы :Обсуждаемые', mrl = '#stream/genre=' .. '/movie/discussions'})

         
         
         
         table.insert(t, {title = 'Сериалы :Топ по Кинопоиску', mrl = '#stream/genre=' .. '/series/kinopoisk'})
         
         table.insert(t, {title = 'Сериалы :Последние', mrl = '#stream/genre=' .. '/series/fresh'})
         table.insert(t, {title = 'Сериалы :Топ за всё время', mrl = '#stream/genre=' .. '/series/top'})
         table.insert(t, {title = 'Сериалы :Обсуждаемые', mrl = '#stream/genre=' .. '/series/discussions'})
    --     table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/anime'})

         
    --    local x=conn:load(HOME .. '/movie')
    --    local x = string.match(x, '<div class=\'tags\'>(.-)</div>')
        
        
      --  for genre, title in string.gmatch(x, '<a href=.-(/movie.-)\'.->(.-)</a>') do
	--		table.insert(t, {title = title, mrl = '#stream/genre=' .. HOME .. genre})
--		end
      
--https://oveg.ru/#search/kino/%D0%A0%D0%BE%D0%B9
--https://oveg.ru/#search/kino/?category=-2051
--https://oveg.ru/series/tag/%D0%A3%D0%B6%D0%B0%D1%81%D1%8B

    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/movie/tag/' .. urlencode(args.keyword) 
		--.. '?page=' .. tostring(page)
		--.. '&do=search&subaction=search'
		


		local x = conn:load(url)
	
	
     --    for url, image, title in string.gmatch(x, '<li id=\'c.-<a href=.-(/.-)\'.-<img.-srcset=.-(http.-jpg).->(.-)<span>') do
		
        for url, title, image in string.gmatch(x, '<li id=\'c.-<a href=.-(/.-)\'.-title=\'(.-)\'.-<img.-srcset=.-(https.-jpg)') do
         url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '?page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
      
      
      
      
         
	-- #stream/q=content&id=http://tv.tivix.co/24-cartoon-network.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	--	local x = http.getz(args.id)
		local x = conn:load(args.id)

		
     --    x = iconv(http.get(args.id), 'windows-1251', 'UTF-8')		
      --    t['ref'] = args.id
	
        --  x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1>(.-)</h1>')
		t['description'] = parse_match(x, 'itemprop="description">(.-)<br>')
		--	t['poster'] = args.p
		
--<div id='photo-container'><div><a href='https://image.krasview.ru/channel/66378/5b0621ea2750f96b_original.jpg' class='highslide'><img id='avatar' src='https://image.krasview.ru/channel/66378/5b0621ea2750f96b.jpg'
			t['poster'] = parse_match(x,' <img id=\'avatar\' src=.-(https.-jpg)')
	--	if t['poster'] then
		--	t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
		
			
	    	t['annotation'] = parse_array(x, {'(Год</b>:.-)</a>', '(Страна</b>:.-)</a>', '(Производство</b>:.-)</a>', '(Дата премьеры в мире</b>:.-)<br>', '(Режиссёр</b>:.-)</a>', '(Актер</b>:.-)<br>',})




--{"v_id":1096179, "duration":7087, "url":"https://media2.krasview.ru/video/1a04d1a450da904/1c962ce52883711.mpd", "url2":"https://media2.krasview.ru/video/1a04d1a450da904/1c962ce52883711.mp4", "audio":3, "i": 10, "channel":"Prorvatsya_v_NBA_2022","mode": "channel", "image":"https://image.krasview.ru/video/1a04d1a450da904/__2.jpg", "dash":1, "href":"/video/1096179", "forward": 1, "audio_info": {"0":"MVO (NewComers)","1":"Original","2":"MVO (Jaskier)"}, "tracks": [{"src":"\/\/media2.krasview.ru\/video\/1a04d1a450da904\/0.srt","label":"Russian","default":0}], "type": "application/dash+xml", "play": true, "embed": true}

			

       for url, title  in string.gmatch(x, '<div class=\'tree%-item\'.-<a href=\'(/movie.-)\'>(.-)</a>') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
      
          --  t['view'] = 'grid'

				table.insert(t,{title = tolazy(title),mrl = '#stream/q=content&id=' .. url})
	
		end


--<ul class=\'video%-gallery\'.-src=\'https://image.-/video/(.-)/.-jpg' srcset='https://image.krasview.ru/video/ef00589cb845618/360_3.jpg

        for url  in string.gmatch(x, '<ul class=\'video%-gallery\'.-src=\'https://image.-/video/(.-)/.-jpg') do
			
           print( url)
        url = string.gsub(url, '^(.-)', 'https://krasview.ru/embed/') .. '?play'
        table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end
          
          
      --  local x = http.getz(url)
          for  url in string.gmatch(x,'<script type="text/javascript".-video_Init.-\'(.-)\'') do




         url=http.urldecode(base64_decode(url))
        
     --  url = string.gsub(url, '"url2":"', '')
       url = string.gsub(url, 'media', 'm')

     --  url = string.gsub(url, '(/.-)'.mp4--, '')

       url = string.gsub(url, '.mpd', '.mp4')

--https://media2.krasview.ru/video/25273d9a27a2828/402a6c76e138eaf.mp4

	--	if url then
			for  url, title in string.gmatch(url, '(http.-mp4).-"url2".-"channel":"(.-)"') do
            t['view'] = 'grid'
        
          --   print(url)
		--	t = video(url, args)
		--	if t['view'] ~= 'error' then
			--	break
		--	end
				table.insert(t,{title=title,mrl= url})
	
		end
        end
--.-selected
     
         local slist=string.match(x, 'class=\'selected\'>(.-)</ul>')


		if slist then
			for  url, title in string.gmatch(x, '<li id=\'c.-<a href=.-(/series/.-)\'>(.-)</a>') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
      
          --  t['view'] = 'grid'
      --   table.insert(t,{title = url,mrl = '#stream/q=content&id=' .. url})
				table.insert(t,{title = tolazy(title),mrl = '#stream/q=content&id=' .. url})
	
		end
		end	
     
     
        
      --  local x = string.match(x, '<ul id=\'channel%-category%-line\'>(.-)</ul>')

    --  for  id, url, title in string.gmatch(x, '<li id=\'c%-(.-)\'.-<a href=.-(/series/.-)\'>(Сезон.-)</a></li>') do
      
	   -- 	print(url)
	--   	url = string.gsub(url, '^(.-)', HOME)
      
          --  t['view'] = 'grid'
      --   table.insert(t,{title = url,mrl = '#stream/q=content&id=' .. url})
	--			table.insert(t,{title = tolazy(title),mrl = '#stream/q=content&id=' .. url})
	
	--	end
   --    local x = string.match(x, '<ul id=\'video%-category.->(.-)<ul id=\'channel%-category%-line')
        for title, url, image,  total in string.gmatch(x, '<a itemprop=\'url\' title=\'(.-серия).-href=.-(/video.-)\'.-<img.-srcset=.-(https.-jpg).-class=\'text\' itemprop=\'name\'>.-серия(.-)<') do
        
	    	print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        
            t['view'] = 'grid'
				table.insert(t,{title = tolazy(title) .. tolazy(total),mrl = '#stream/q=content&id=' .. url, image = image})
    -- 	table.insert(t,{title = url,mrl = '#stream/q=content&id=' .. url, image = image})
	
		end
    
		
	elseif args.q == 'play' then
	--	return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
       return video(args.url, args)
--	end
	end
	return t
end