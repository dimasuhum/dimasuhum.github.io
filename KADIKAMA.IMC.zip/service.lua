-- kadikama plugin

require('support')
require('video')
require('parser')

HOME = 'https://kadikama.online'
HOME_SLASH = HOME .. '/'
--https://kadikama.online/engine/videodb/sources.php?hash=fc918a939cf1bd698a2ca1ce24b127a1513e5be3
function onLoad()
	print('Hello from kadikama plugin')
	return 1
end

function onUnLoad()
	print('Bye from kadikama plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/multfilmy-2020-goda/page/
	-- #stream/genre=/top-100-luchshih-multfilmov-2019-goda.html

	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/lastnews/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
       -- local x = http.getz(HOME .. '/')
        local x = http.getz(url)
        

         for url, image, title in string.gmatch(x, '<a href="(http.-)".-<img src="(.-)" alt="(.-)"') do
            image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x = http.getz(HOME)
		
       local x = string.match(x, '<nav class="header%-wrapper">(.-)</nav>')
         for genre, title in string.gmatch(x, '<a href="(/.-)".->(.-)</li>') do

        genre = string.gsub(genre, '/order=desc/sort=date/', '/sort=date/order=desc/')

			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. genre})
			
		end
		
--https://kadikama.online/search/%D0%92%D0%B8%D0%BD%D0%BD%D0%B8/
		
        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/' .. urlencode(args.keyword) 
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = http.getz(url)
		
        for url, image, title in string.gmatch(x, '<a href="(http.-)".-<img src="(.-)" alt="(.-)"') do
            image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
		
		
	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)

		--print(x)
	--	t['ref'] = args.id
        t['name'] = parse_match(x,'<h2 itemprop="name">(.-)</h2>')
		t['description'] = parse_match(x, '<div class="mov%-desc%-text full%-text clearfix".-<p>(.-)</p>')
			t['poster'] = args.p
	    	t['annotation'] = parse_array(x, {'(Страна:</div>.-)</li>', 
'(Жанр:</div>.-)</li>', 
'(Год:</div>.-)</li>'})
			



--http://sp-social.ru/kinopoisk/2.php?name=4370148
			
        --http://smartportaltv.ru/0/index.php?url=https://aboulia.thealloha.club/?kp=4370148&token=b8823fb7495df944e5944fb56c6778
        
        
--var videodb = {"kinopoisk":"790343"
   
         for url in string.gmatch(x, '<meta itemprop="video" content="(https://www.youtube.-)"') do
   
          table.insert(t, {title = 'Смотреть', mrl = url})

		end
        for url in string.gmatch(x, '<div class="tabs%-b video%-box".-<iframe.-src="(https://bummer.-)"') do
           print(url) 
        url = string.gsub(url, '^(.-)', 'http://smartportaltv.ru/0/index.php?url=')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
   
   
   
     
        for url in string.gmatch(x, 'videodb.-"kinopoisk":"(.-)"') do
           print(url) 
        url = string.gsub(url, '^(.-)', 'http://divantv.zz.mu/kinomovie/zombie.m3u.php?kp_id=')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
		
        for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end
   
   
   
   
   
     
        for url in string.gmatch(x, 'videodb.-"kinopoisk":"(.-)"') do
           print(url) 
		url = string.gsub(url, '^(.-)', 'http://sp-social.ru/kinopoisk/2.php?name=')
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
        
        for url in string.gmatch(x, 'videodb.-"kinopoisk":"(.-)"') do
           print(url) 
		url = string.gsub(url, '^(.-)', 'http://smartportaltv.ru/0/index.php?url=https://aboulia.thealloha.club/?kp=')
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end

        for title, url, total in string.gmatch(x, '<title.-CDATA(.-])].-<playlist_url.-(http.-)].-</br.-</br.-</br>(.-)</center>') do
         t['view'] = 'simple'
          table.insert(t, {title = tolazy(title) .. tolazy(total), mrl = '#stream/q=content&id=' .. url})
        end

       for title, url in string.gmatch(x, '<title.-CDATA(.-)]>.-<stream_url.-(http.-m3u8)') do
       
		t['view'] = 'simple'
        table.insert(t, {title = title, mrl = url})

		end
   
   
   
   
       for url in string.gmatch(x, 'videodb.-"kinopoisk":"(.-)"') do
		 print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-or (//video.zagonka.org/movies/.-mp4)') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
    end
   
        
        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
		return video(args.url, args)
	end
	return t
end