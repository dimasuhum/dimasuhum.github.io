-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')
--require('search')
local fxml = onCreate




local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'

mobileapi='https://api.ivi.ru/mobileapi/'

local HOME = 'https://www.ivi.ru'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

video_feed={}
preroll_feed={}

function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	

	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	
    
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/country/СССР/
	-- #stream/genre=/country/Индия/
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/genre/боевик
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/url=/show/
    -- #stream/genre=/show/
	if not args.q then
	
    --    feedmobile(t,'videos/?',{sort='new'})
	
	
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/new/movie-new'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page' .. tostring(page)
		end
		if genre == '/collections' then
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page' .. tostring(page)
		end
		end
        
	--	local x = http.getz(url)
	
        local x = conn:load(url)
		
   
   
       for url, title, image  in string.gmatch(x, '<li class="gallery__item gallery__item_virtual".-href="(/.-)".-<img class="nbl%-poster__image" alt="(.-)".-src="(.-)"') do

			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
   
   
        
         for url, image, title in string.gmatch(x, '<li class="selections__galleryItem".-<a href="(/.-)".-<img.-src="(.-)".-class="nbl%-slimPosterBlock__titleText">(.-)</span') do


     --     for url, title in string.gmatch(x, '<div class="MiniPostName".-<a href=".-(/actors.-html)".-title="(.-)"') do

      --   t['view'] = 'simple'

			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end

   
   

   
    		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})



    
    
--		local x= http.getz('https://api.ivi.ru/mobileapi/categories/?')
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
       table.insert(t, {title = 'Коллекция', mrl = '#stream/genre=' .. '/collections'})
	
		
	   	local x = conn:load(HOME .. '/movies')
		
		for genre, title in string.gmatch(x, '<a data%-testid="genre_gallery_item_title" href="(.-)".-test="genre_gallery_item_title">(.-)</div>') do
				table.insert(t, {title = 'Фильмы : ' .. title, mrl = '#stream/genre=' .. genre})
			end
	local x = conn:load(HOME .. '/series')
		
		for genre, title in string.gmatch(x, '<a data%-testid="genre_gallery_item_title" href="(.-)".-test="genre_gallery_item_title">(.-)</div>') do
				table.insert(t, {title = 'Сериалы : ' .. title, mrl = '#stream/genre=' .. genre})
			end	

		local x = conn:load(HOME .. '/animation')
		
		for genre, title in string.gmatch(x, '<a data%-testid="genre_gallery_item_title" href="(.-)".-test="genre_gallery_item_title">(.-)</div>') do
				table.insert(t, {title = 'Мультфильмы : ' .. title, mrl = '#stream/genre=' .. genre})
			end	
		
	--	local x = string.match(x, '<ul class="mobileNavigation__list media">(.-)</ul>')
     	
        
        
        
--https://www.ivi.ru/search?q={search_term_string}
         
-- https://www.ivi.ru/?ivi_search=%D0%BF%D0%B8%D1%80
 
--https://api.ivi.ru/mobileapi/search/v7/?query=кошмар
 
 --https://api2.ivi.ru/mobileapi/?q=search&keyword=кошмар&args.keyword
 
--elseif args.q == 'search' then
	--	if not args.keyword then
	--		return {view='keyword',message='@string/search_message'}
--		end
	--	feedmobile(t,'search/v2/?',{query=urlencode(args.keyword),sort='new'},from,{q='search',keyword=urlencode(args.keyword)},args.keyword)
	
 --https://api.ivi.ru/mobileapi/search/v7/?query=рокки&fake=2
 
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		
		local url = 'https://api.ivi.ru/mobileapi/search/v7/?query=' .. urlencode(args.keyword) .. '&fake=' .. tostring(page)
	--	.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = http.getz(url)
	
	
	
       for title, image, url in string.gmatch(x, '"hru".-"title":"(.-)".-content_format":"TrendNowFill.-"url":"(http.-jpg)".-share_link":"(.-)"') do
	
--	for title, url, image in string.gmatch(x, 'synopsis.-"title":"(.-)".-"share_link":"(.-)".-poster_originals.-%[{"path":"(http.-jpg)"') do
      url = string.gsub(url, '\\', '')
	image = string.gsub(image, '\\', '')	
    --    for url, title, image  in string.gmatch(x, '<li class="searchResultItem searchBlock__searchResultItem".-<a.-href="(.-)".-<img.-alt="(.-)".-src="(.-)"') do

	--		url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&fake=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
 
 
    
			
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
		local x = conn:load(args.id)
  --  	local x = http.getz(args.id)
		
       -- x = string.gsub(x, 'onclick', '')
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<meta property="og:title" content="(.-) — на Иви')
		t['description'] = parse_match(x, '<div class="clause__text%-inner hidden%-children" data%-test="details_text".-<p>(.-)</p>')
			t['poster'] = args.p
			
    --        t['poster'] = parse_match(x,'<div class="FullstoryFormLeft".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			
			
	    	t['annotation'] = parse_array(x, {
           '<div class="nbl%-link nbl%-link_style_wovou nbl%-link nbl%-link_noLink".-<ul class="watchParams__paramsList">(.-)<ul class="watchParams__paramsList"',
})

--https://api.ivi.ru/mobileapi/videoinfo/?id=527138
--   <meta property="og:video" content="https://www.ivi.ru/player/video/?id=126962"
  
  
       
  
  
  
--"kp_id":655435,
--"release_date".-"title":"(Вне\/себя)"
   
   --   <h1.->(.-) \(.-\).-</div>
   
       for title  in string.gmatch(x, '<meta property="og:title" content="(.-) — на Иви!"') do

         print(url)
		 

         url = string.gsub(title, '^(.-)', 'http://xplay.bz/list?search=')
         
     --    local x = fxml({url = url})
    --    for url in string.gmatch(url, '"playlist_url":"(.-)"') do
        
 
       
        local x = fxml({url = url})
        for _, v in ipairs(x) do
 

    	if string.find(v.mrl, '^#') then
    	
			v.mrl = v.mrl .. '&package=' .. urlencode(REPO .. 'xplay.IMC.zip')
		end
		table.insert(t, v)
	end
      end 


         for url in string.gmatch(x, '{"state":"idle".-"_referrer_content_id":(.-),".-"discount_percent"') do
         
         
    --     for url in string.gmatch(x, '"title","user_auth_status".-"dynx_itemid":".-_(.-)"') do
			
		url = string.gsub(url, '^(.-)', 'https://api.ivi.ru/mobileapi/videoinfo/?id=')
--	table.insert(t, {title = url, mrl = url})
		
		local x = http.getz(url)
       for url in string.gmatch(x, '"kp_id":(.-),') do
		
		 
    
        print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     end
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-or (//video.zagonka.org/movies/.-mp4)') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end
  
    

        for url in string.gmatch(x, '{"state":"idle".-"_referrer_content_id":(.-),".-"discount_percent"') do
			
		url = string.gsub(url, '^(.-)', 'https://api.ivi.ru/mobileapi/videoinfo/?id=')
--	table.insert(t, {title = url, mrl = url})
		
		local x = http.getz(url)
       for url in string.gmatch(x, '"kp_id":(.-),') do
		
		
        print(url) 
       url = string.gsub(url, '^(.-)', 'https://voidboost.net/embed/')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
         end
         end
          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do

            
          local slist=string.match(x, '<select name="season".->(.-)</select>')
          
           if slist then
          
             for url1, title in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
             

             
            local slist=string.match(x, '<select name="episode".->(.-)</select>')
            
           if slist then
            for url2, total in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do
         

          t['view'] = 'simple'
        	table.insert(t, {title = title .. ':' .. (total) .. ' (' .. total1 .. ')', mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
			end
			end
   	    	end	
   	    	end
            end	
   	    	end
    

--https://voidboost.net/movie/149fa08a44c989e65e37289b4c796736/iframe?h=baskino.me

          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
             
             
          t['view'] = 'simple'
        	table.insert(t, {title = total1, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/movie/' .. url3 .. '/iframe?'})
             
            end
            end
    
          
	--		for url1, title in string.gmatch(x, '<option value="(.-)".->(Сезон.-)</option>') do
	--		end
     --     local x = string.match(x, '<select name="episode".->(.-)</select>')
			
     --      for url2, total in string.gmatch(x, '<option value="(.-)".->(Серия.-)</option>') do
	--	   end
            
         
    --      local x = string.match(x, '<select name="translator.->Перевод.->(.-)</div>')
      --      for url3, total1 in string.gmatch(x, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
    
         
         
       -- 	table.insert(t, {title = 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
	--		end

   		
   		
       for url  in string.gmatch(x, 'var CDNplayerConfig.-file.-#2(.-)\'') do
     --    print(url)
		 url = string.gsub(url, '//_//', '')
         url = string.gsub(url, 'Xl4jQEAhIUAjISQ=', '')
         url = string.gsub(url, 'JCQkIyMjIyEhISEhISE=', '')
         url = string.gsub(url, 'QCFeXiFAI0BAJCQkJCQ=', '')
         




         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, url in string.gmatch(url, '(360p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if url then
			for title, url in string.gmatch(url, '(480p).-(http.-.mp4)') do
             t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
				
               table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(720p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p)].-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p Ultra).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end
			end





	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end