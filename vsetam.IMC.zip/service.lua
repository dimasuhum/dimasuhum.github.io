-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://zvukino.com'
--local HOME = 'https://4ivi.net'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH






--HOME = 'https://vsetam.net'
--HOME1 = 'https://kadikama.online'

--HOME_SLASH = HOME .. '/'
--HOME1_SLASH = HOME1 .. '/'
function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
       table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})	
	if not args.q then

	

		local page = tonumber(args.page or 1)
		local genre = args.genre or '/films/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
        local x = conn:load(url)
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
       
       
       

       
    --   for  title in string.gmatch(x, '<div class="movie(.-)</div>') do
       
       
		for url, image, title in string.gmatch(x, '<div class="movie__info".-<a href="(.-)".-src="(/uploads.-)".-title="(.-)"') do
          
      --  url = string.gsub(url, '^(.-)', HOME .. '/')
       image = string.gsub(image, '^(.-)', HOME)
        
         table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
	--		table.insert(t, {title = title, mrl = '#stream/genre' .. url .. url1})
		
		end
		
	--	for title in string.gmatch(x, '<div id=(.-)alt') do
		
		
      if genre == '/collections/' then
	
    	local url = HOME .. genre
    	if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
	
  	
		local x = conn:load(url)
       local x = string.match(x, 'main class="content">(.-)<div class="pagination')
	
		
     for genre, title, image in string.gmatch(x, '<a href="(/collections.-)" class="coll img%-responsive img%-fit%-cover grid%-item".-class="coll__title">(.-)<.-<img src="(/uploads.-)"') do
          

     image = string.gsub(image, '^(.-)', HOME)
        
         	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre, image = image})
		
		end
		end
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = conn:load(HOME)
	
	

		local x = string.match(x, 'Фильмы по жанрам.-class="acor%-body">(.-)<input type="checkbox"')
		for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = 'Фильмы : ' .. title, mrl = '#folder/genre=' .. genre})
		end
        
        local x = conn:load(HOME)

		local x = string.match(x, 'Сериалы по жанрам.-class="acor%-body">(.-)<input type="checkbox"')
		for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = 'Сериалы : ' .. title, mrl = '#folder/genre=' .. genre})
		end
		
		local x = conn:load(HOME)

		local x = string.match(x, 'Мультики по жанрам.-class="acor%-body">(.-)<input type="checkbox"')
		for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = 'Мультики : ' .. title, mrl = '#folder/genre=' .. genre})
		end
		
	local x = conn:load(HOME)

		local x = string.match(x, 'Подборки.-class="acor%-body">(.-)</nav>')
		for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = 'Подборка : ' .. title, mrl = '#folder/genre=' .. genre})
		end	
		
		
     
      

--https://4ivi.net/index.php?story=Чужой&do=search&subaction=search
       
       
        		
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search' .. '&page=' .. tostring(page)



		local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="movie__info".-<a href="(.-)" class="movie__link.-<img src="(/uploads.-)".-title="(.-)"') do
          
      --  url = string.gsub(url, '^(.-)', HOME .. '/')
       image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
			
			
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)смотреть')
		t['description'] = parse_match(x,'<div class="accordion__content full%-text clearfix.->(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Дата выхода:</div>.-)</li>','(Категория:</div>.-)</li>', '(Страна:</div>.-)</li>', '(В ролях:</div>.-)</li>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})






      for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%)') do
     
     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')

     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1


     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
     


url1 = string.gsub(title3, '^(.-)', 'http://movixhd.online/lite/hdvb?kinopoisk_id=') 
    
       table.insert(t, {title = 'hdvb', mrl = '#stream/q=content&id=' .. url1, image = image})
       end
       end
    --  local x = http.getz(url1)

     
       for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   
      local x = conn:load(url2 .. url3)

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :' .. tolazy(total2), mrl = url4})

      end 
      end
    --  end
    --  end

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end




       
      
      
      for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%)') do
     
     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')

     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1


     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
     
  
url1 = string.gsub(title3, '^(.-)', 'https://lams.maxvol.pro/lite/zetflix?kinopoisk_id=') 


    table.insert(t, {title = 'Zetflix', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
       end
   
   for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total), mrl = url2})

       
    end
    
    
 --   local x = conn:load(url1)
        for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end
  
  
  
  
  
  for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%)') do
     
     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')

     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1


     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
     
      
     url1 = string.gsub(title3, '^(.-)', 'https://lams.maxvol.pro/lite/videodb?kinopoisk_id=')
     --.. '&title=' .. title .. '&year=' .. title1 
  
  table.insert(t, {title = 'Videodb', mrl = '#stream/q=content&id=' .. url1, image = image})
		end
    end
   --   local x = conn:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite/videodb.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'https://lams.maxvol.pro')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite/videodb.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'https://lams.maxvol.pro') 
       local x = conn:load(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'https://lams.maxvol.pro') 
       local x = conn:load(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite/videodb.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'https://lams.maxvol.pro')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
    
   
   
   
     for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%)') do
     
     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')

     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1


     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
     
      
      url1 = string.gsub(title3, '^(.-)', 'http://93.183.92.183:9118/lite/mirage?kinopoisk_id=') .. '&uid=m7alois3'
    
--http://147.45.77.28:9118/lite/mirage?kinopoisk_id=386&uid=m7alois3
 
    
     local x = conn:load(url1)
     
     for  url2, url3,  total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
  
      url3 = string.gsub(url3, '\\u0026', '&')

    
       local x = conn:load(url2 .. url3)
    
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
    
       url4 = string.gsub(url4, '^(.-)', 'http://93.183.92.183:9118')
    
   --    t['view'] = 'simple'

    table.insert(t, {title = tolazy(total2) .. '(' .. tolazy(total3) .. ')', mrl = url4})

      end 
      end
     
  

      
       for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
       url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       
     url2 = string.gsub(url2, '\\u0026', '&')
     
   --  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)


      for url3, url4, total1, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"url":"http.-(/lite/mirage)(.-)".-voice_name":"(.-)".-class="videos__item%-title">(.-серия)</div>') do

       url3 = string.gsub(url3, '^(.-)', 'http://93.183.92.183:9118')
       
     url4 = string.gsub(url4, '\\u0026', '&')
      local x = conn:load(url3 .. url4)
     local x = string.match(x, '"quality"(.-)}')
      for  total3, url5 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
   
     url5 = string.gsub(url5, '^(.-)', 'http://93.183.92.183:9118')
    
  --     t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total2) .. '(' .. total3 .. ')' .. '(' .. total1 .. ')', mrl = url5})

    end
end
end
 
  end  
  end












       for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%)') do
     
     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')

     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1


     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
     
   url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
   --    t['view'] = 'simple'
				table.insert(t,{title= tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
  --    t['view'] = 'simple'
				table.insert(t,{title= tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end
         end
         end
         
         
         
         
         
   
   
      
      for title, total in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%)') do

  
       title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')


     url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    

     
 --    table.insert(t, {title = 'Torrs', mrl = '#stream/q=content&id=' .. url, image = image})
    --     end


      local x = conn:load(url)

        for total in string.gmatch(x,'%[{"size.-trackerName.-kinozal.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        

       url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      

        local x = conn:load(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
    --    t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
     --    t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
     --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	


  --   local x = conn:load(url)
     
      for total in string.gmatch(x,'%[{"size.-trackerName.-nnmclub.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        
      url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      

        local x = conn:load(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     
   --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
    --   t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
    --    t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	
   end


	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end