-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')


--local HOME = 'https://apivb.com'
local HOME = 'http://api.vokino.tv/v2'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/list?genre=%D1%83%D0%B6%D0%B0%D1%81%D1%8B

	-- #stream/genre=/list?sort=updatings?type=movie
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/genre/боевик
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/q=tag&id=боевик
    -- #stream/genre=/show/
	if not args.q then



--https://kinopoiskapiunofficial.tech/api/v2.2/films/386&apiKey=2a4a0808-81a3-40ae-b0d3-e11335ede616
--ApiKeyAuth (apiKey)	

--http://api.vokino.tv/v2/list?genre=%D1%83%D0%B6%D0%B0%D1%81%D1%8B&page=2
--http://api.vokino.tv/v2/list?sort=updatings

		local page = tonumber(args.page or 1)
	--	local genre = args.genre or '/list?sort=&genre='
		
       local genre = args.genre or '/list?sort=updatings'
		
		local url = HOME .. genre
		if page > 1 then
			url = url .. '&page=' .. tostring(page)
			

	 	end
		

		
--	/list?genre=%D1%83%D0%B6%D0%B0%D1%81%D1%8B	
		
		local x = conn:load(url)
		
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

	
     --   for title in string.gmatch(x, '"list"(.-)"page') do
		
       for title, total, image, url in string.gmatch(x, '"details".-"name":"(.-)".-"released":(.-),.-"poster":"(.-)".-"playlist_url":"(.-)"') do
    --   image = string.gsub(id, '^(.-)', 'https://st.kp.yandex.net/images/film_big/') .. '.jpg' 
			table.insert(t, {title=title  .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
--   table.insert(t, {title=title, mrl = '#stream/q=content&id=' .. title, image = image})
	--	end
   
   if genre == '/compilations/list?sort=' then

     local url = HOME .. genre
		if page > 1 then
			url = url .. '&page=' .. tostring(page)
	 	end
       for genre, title, image in string.gmatch(x, '"playlist_url":"http.-(/compilations/content/.-)".-"name":"(.-)".-"poster":"(http.-)"') do
   
   table.insert(t, {title=title, mrl = '#stream/genre=' .. genre, image = image})
		end
   end
   
   
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		
		

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
       table.insert(t, {title = 'Подборка', mrl = '#stream/genre=' .. '/compilations/list?sort='})
		

--http://api.vokino.org/v2/list?genre=%D1%83%D0%B6%D0%B0%D1%81%D1%8B

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Ужасы : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'ужасы'})
		end

      local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Триллер : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'триллер'})
		end

      local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Мелодрама : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'мелодрама'})
		end

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Фантастика : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'фантастика'})
		end

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Боевик : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'боевик'})
		end


local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Биография : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'биография'})
		end

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Комедия : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'комедия'})
		end

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Детектив : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'детектив'})
		end

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Приключения : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'приключения'})
		end

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Фэнтези : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'фэнтези'})
		end

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Семейный : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'семейный'})
		end

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Музыка : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'музыка'})
		end


local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Драма : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'драма'})
		end

local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'История : ' .. tolazy(title), mrl = '#stream/q=tag&id=' .. id .. '&id1=' .. 'история'})
		end




--http://api.vokino.tv/v2/list?type=movie&sort=updatings

		local x = conn:load(HOME .. '/category?type=movie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&.-(movie)"') do
       
--id = string.gsub(id1, '^(.-)', '/list?') .. '&' .. id 
        
			table.insert(t, {title = 'Фильмы : ' .. tolazy(title), mrl = '#stream/q=genre&id=' .. id .. '&id1=' .. id1})
		end
    
    local x = conn:load(HOME .. '/category?type=serial')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&.-(serial)"') do
        
			table.insert(t, {title = 'Сериалы : ' .. tolazy(title), mrl = '#stream/q=genre&id=' .. id .. '&id1=' .. id1})
		end
		
		local x = conn:load(HOME .. '/category?type=multfilm')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&.-(multfilm)"') do
        
			table.insert(t, {title = 'Мультфильмы : ' .. tolazy(title), mrl = '#stream/q=genre&id=' .. id .. '&id1=' .. id1})
		end
		
		
		local x = conn:load(HOME .. '/category?type=multserial')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&.-(multserial)"') do
        
			table.insert(t, {title = 'Мультсериал : ' .. tolazy(title), mrl = '#stream/q=genre&id=' .. id .. '&id1=' .. id1})
		end
         		
		local x = conn:load(HOME .. '/category?type=anime')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&.-(anime)"') do
        
			table.insert(t, {title = 'Аниме : ' .. tolazy(title), mrl = '#stream/q=genre&id=' .. id .. '&id1=' .. id1})
		end
			local x = conn:load(HOME .. '/category?type=documovie')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&.-(documovie)"') do
        
			table.insert(t, {title = 'Докфильм : ' .. tolazy(title), mrl = '#stream/q=genre&id=' .. id .. '&id1=' .. id1})
		end
		
		
local x = conn:load(HOME .. '/category?type=docuserial')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&.-(docuserial)"') do
        
			table.insert(t, {title = 'Доксериал : ' .. tolazy(title), mrl = '#stream/q=genre&id=' .. id .. '&id1=' .. id1})
		end
		
		local x = conn:load(HOME .. '/category?type=tvshow')
		
		
    	for title, id, id1 in string.gmatch(x, '"title":"(.-)".-"playlist_url":"http.-(/list.-)&.-(tvshow)"') do
        
			table.insert(t, {title = 'Тв-шоу : ' .. tolazy(title), mrl = '#stream/q=genre&id=' .. id .. '&id1=' .. id1})
		end
		
		
		
		
    elseif args.q == 'tag' then


    local page = tonumber(args.page or 1)



    local x = conn:load(HOME .. args.id .. '&genre=' .. urlencode(args.id1) .. '&page=' .. tostring(page))

   
       for title, total, image, url in string.gmatch(x, '"details".-"name":"(.-)".-"released":(.-),.-"poster":"(.-)".-"playlist_url":"(.-)"') do
    --   image = string.gsub(id, '^(.-)', 'https://st.kp.yandex.net/images/film_big/') .. '.jpg' 
			table.insert(t, {title=title  .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end

		
		local url = '#stream/q=tag&id=' .. args.id .. '&id1=' .. urlencode(args.id1) .. '&page=' .. tostring(page + 1)
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		
		
		
     elseif args.q == 'genre' then


    local page = tonumber(args.page or 1)



    local x = conn:load(HOME .. args.id .. '&type=' .. args.id1 .. '&page=' .. tostring(page))

   
       for title, total, image, url in string.gmatch(x, '"details".-"name":"(.-)".-"released":(.-),.-"poster":"(.-)".-"playlist_url":"(.-)"') do
    --   image = string.gsub(id, '^(.-)', 'https://st.kp.yandex.net/images/film_big/') .. '.jpg' 
			table.insert(t, {title=title  .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end




    
		
		
	local url = '#stream/q=genre&id=' .. args.id .. '&id1=' .. args.id1 .. '&page=' .. tostring(page + 1)
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	
	
			
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
	
	
--http://api.vokino.org/v2/search?name=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&page=2

		local url = HOME .. '/search?name=' .. urlencode(args.keyword) .. '&page=' .. tostring(page)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
  for title, total, image, url in string.gmatch(x, '"details".-"name":"(.-)".-"released":(.-),.-"poster":"(.-)".-"playlist_url":"(.-)"') do
    --   image = string.gsub(id, '^(.-)', 'https://st.kp.yandex.net/images/film_big/') .. '.jpg' 
			table.insert(t, {title=title  .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
		local x = conn:load(args.id)
		
		
		
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
		
		
		





--table.insert(t, {title=args.id, mrl = '#stream/q=content&id=' .. args.id, image = image})


		
		
		
    --	local x = http.getz(args.id)
		
       -- x = string.gsub(x, 'onclick', '')
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)смотреть онлайн</h1>')
		t['description'] = parse_match(x, '"about":"(.-)"')
			t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="FullstoryFormLeft".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			

--"genre":{"26":"Ужасы","11":"Фантастика","13":"Триллер","10":"Зарубежный"}
	
		x = string.gsub(x, '"country":"', 'Страна :')
	x = string.gsub(x, '"genre":"', 'Жанр :')

			
	    	t['annotation'] = parse_array(x, {

			'(Страна :.-)"',
			'(Жанр :.-)"',
			'(Качество:</h4>.-)</p>',
			'(Время:</h4>.-)</p>',
			'(Бюджет:</h4>.-)</p>'})
   





     for title, title1 in string.gmatch(x, '"type":"view".-"name":"(.-)".-"released":(.-),') do


   --  title = urlencode(title)
      
 --     title = string.gsub(title, '+', '%%20') 
  --   url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '&year=' .. title1



    
     table.insert(t, {title = 'Источники', mrl = '#stream/q=video&id=' .. title .. '&id1='.. title1, image = image})
        end
        
        
        
        
        

   
   for title, title1 in string.gmatch(x, '{"type":"view","details".-"name":"(.-)".-"released":(.-),') do
      
       title = urlencode(title)
      
 --     title = string.gsub(title, '+', '%%20') 
     url = string.gsub(title, '^(.-)', 'https://apivb.com/api/filter.json?metod=search&token=d16fe09ddd4d031b06a32a2e535147fc&title=') .. '&year=' .. title1

      local x = conn:load(url)
--https://apivb.com/api/filter.json?metod=search&token=d16fe09ddd4d031b06a32a2e535147fc&title=чужой&year=1979


    for title3  in string.gmatch(x, 'system":.-"kinopoisk_id":(.-),') do   
      

       url1 = string.gsub(title3, '^(.-)', 'http://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 
 
   -- table.insert(t, {title = 'Hdvb(v2)', mrl = '#stream/q=content&id=' .. url1, image = image})
       -- end
   --  end
   local x = conn:load(url1)
     
       for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   
      local x = conn:load(url2 .. url3)



for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/360/index.m3u8')
    
    --  t['view'] = 'simple'

    table.insert(t, {title = '360p ' .. tolazy(total2), mrl = url4})

end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/480/index.m3u8')
    
   --   t['view'] = 'simple'

    table.insert(t, {title = '480p ' .. tolazy(total2), mrl = url4})
end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/720/index.m3u8')
    
    --  t['view'] = 'simple'

    table.insert(t, {title = '720p ' .. tolazy(total2), mrl = url4})
end

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
    --  t['view'] = 'simple'

    table.insert(t, {title = '1080p ' .. tolazy(total2), mrl = url4})

      end 
   
      end
      

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       --t['view'] = 'simple'

    table.insert(t, {title = total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end

end
end


--local x = string.match(x, 'casts(.-)count')
  
  
  
 for url, title, image in string.gmatch(x, '(cast=.-)".-biography.-"title":"(.-)","poster":"(.-)"') do
  
  table.insert(t, {title=title, mrl = '#stream/q=cast&id=' .. url, image = image})
		end
		
      
  local x = string.match(x, '"similars"(.-)casts')
  
  
for title, total, image, url in string.gmatch(x, '"details".-"name":"(.-)".-"released":(.-),.-"poster":"(.-)".-"playlist_url":"(.-)"') do
    --   image = string.gsub(id, '^(.-)', 'https://st.kp.yandex.net/images/film_big/') .. '.jpg' 
			table.insert(t, {title=title  .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
   
  
 
  
   
  
  
   
     elseif args.q == 'cast' then
  
local page = tonumber(args.page or 1)
  
  	local x = conn:load(HOME .. '/list?' .. args.id .. '&page=' .. tostring(page))
			

		
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

	

		
       for title, total, image, url in string.gmatch(x, '"details".-"name":"(.-)".-"released":(.-),.-"poster":"(.-)".-"playlist_url":"(.-)"') do
    --   image = string.gsub(id, '^(.-)', 'https://st.kp.yandex.net/images/film_big/') .. '.jpg' 
			table.insert(t, {title=title  .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
  
  
  local url = '#stream/page=' .. tostring(page + 1) .. '&q=cast&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
  
  
  
  
  
  
  
  
  
  
    elseif args.q == 'video' then
	--	t['view'] = 'annotation'
 

        
	local x = conn:load('http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=' .. urlencode(args.id) .. '(' .. args.id1 .. ')')
		
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	


   for title, title1, title3 in string.gmatch(x, '"fxml".-align:center.->.-: (.-)%((.-)%)<.-"playlist_url":"http.-kinopoisk.-info&cid=(.-)"') do

     title = urlencode(title)


url1 = string.gsub(title, '^(.-)', 'https://lampa.persh1n.ru/lite/kinobase?title=') .. '&year=' .. title1
    --.. '&uid=m7alois3'
   
  -- table.insert(t, {title = url1, mrl = url1})

  
 
     local x = conn:load(url1)
    
      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
    --  t['view'] = 'simple'

url2 = string.gsub(url2, '\\u002B', '+')

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2})

     end  
    end

--https://lampa.persh1n.ru/lite/kinobase?title=%d0%b1%d1%83%d0%bc%d0%b0%d0%b6%d0%bd%d1%8b%d0%b9+%d0%b4%d0%be%d0%bc&year=2017&s=1
  

   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
    
       
    
      local x = conn:load(url2)

      
       

      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
    
url3 = string.gsub(url3, '\\u002B', '+')

    
         
    url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
    
     --  t['view'] = 'simple'



    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3})

    end   
    end
    
     

--http://178.20.46.40:12600/lite/filmix?kinopoisk_id=386

    --  url1 = string.gsub(title3, '^(.-)', 'https://mylam.ru/lite/vdbmovies?kinopoisk_id=') 
     
   
     
      url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/veoveo?kinopoisk_id=')
      --.. '&title=' .. title .. '&year=' .. title1
   
   local x = conn:load(url1)
     
       for  url2, total2 in string.gmatch(x, 'class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do

      t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2), mrl = url2})

      end 



     for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)

for total3, url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-media="" s=.-e="(.-)".-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total3) .. ' серия' .. tolazy(total4), mrl = url4})

      end 
      end



url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
     t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end





--  https://lampa.ds220kirill.synology.me

      
     url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/videodb?kinopoisk_id=')
     --.. '&title=' .. title .. '&year=' .. title1 
  
  
    
      local x = conn:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600') 
       local x = conn:load(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600') 
       local x = conn:load(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://178.20.46.40:12600')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
    



     
     url1 = string.gsub(title3, '^(.-)', 'https://lam.maxvol.pro/lite/vdbmovies?kinopoisk_id=')
     --.. '&uid=m7alois3'


    local x = conn:load(url1)

       for total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-/proxy.-mp4.-class="videos__item%-title">(.-)</div>') do
  
  
  
      local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)"') do
      
  
  
     url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
  
            url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 


      t['view'] = 'simple'


   table.insert(t, {title = 'vdbmovies' .. ':'.. tolazy(total) .. ( total1), mrl = url2})

       
    end
    end
    

    
  
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

    --     url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    

      local x = conn:load(url2)

     
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
  
     --    url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
    
       
    
     local x = conn:load(url3)
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')
  
            url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end
  
        
   
     



     url1 = string.gsub(title3, '^(.-)', 'https://mylam.ru/lite/filmix?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
  
      local x = conn:load(url1)
      
     for  url3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

   table.insert(t, {title = 'filmix' .. ':'.. tolazy(total2), mrl = url3})

     end  


      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for url5, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'filmix :' .. total .. ' '  .. tolazy(total3) .. total2, mrl = url5})

       
    end

end
end


    



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/remux?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

    local x = conn:load(url1)

    

      for  url2, total in string.gmatch(x, '"url".-(http.-)quality.-class="videos__item%-title">(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      
       url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
      
       for  url3 in string.gmatch(x, '"play".-"url":.-(http.-)"') do

       t['view'] = 'simple'

   table.insert(t, {title = 'remux :' .. tolazy(total), mrl = url3})

     end  
    end






   
    

    
    
 
 
 
 
 
    url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&search=') .. '-' .. title1
      --.. '&box_mac=acace24b8434'
			
			
			
			
      local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')

     
     for url1 in string.gmatch(x, 'fxml.-<channel>.-(http.-)]]') do

 --    total1=base64_decode(total1)
     
--     total1 = string.gsub(total1, 'item/', '')


--http://kb-team.club/?do=%2Fplugin&bid=kinofit-kinofit_4k&search=%D1%87%D1%83%D0%B6%D0%BE%D0%B9-1979&box_mac=acace24b8434
       
    local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
     
     
   --   for title in string.gmatch(x, '"id":(.-),') do

    --     print(url)
		 
   --      title = string.gsub(title, '^(.-)', 'item/')
         
      --   title=base64_encode(title)
 

   --    url1 = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=')
       
      
   --    local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')


     
     
     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = total .. (total1), mrl = url2})
    
        end
        end
        end
  
    
url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
    --.. '&rjson=true'

    local x = conn:load(url1)



      for  url2, url3,  total, total1 in string.gmatch(x, '"play".-"url":"(http.-pidtor)(.-)".-class="videos__item%-title">(.-)<.-<!%-%-(.-)%-') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total) .. ' ' .. total1, mrl = url2 .. url3})

       
    end
    
url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 
      


         url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 

    


   
    
    
    

  url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=') 
  --.. '&uid=m7alois3'
    
    
      local x = conn:load(url1)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=') 

    local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vibix :' .. tolazy(total1) .. total2, mrl = url3})

       
    end

end


--https://mylam.ru

      url1 = string.gsub(title3, '^(.-)', 'https://mylam.ru/lite/rezka?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

     local x = conn:load(url1)
 
  
  
       for  url3, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. tolazy(total1), mrl = url3})
  --   end
     end  
  
         local x = conn:load(url1)

     
     for url3, total2  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
     
     url3 = string.gsub(url3, '\\u0026', '&')

     url3 = string.gsub(url3, '\\u002B', '+')

  
     local x = conn:load(url1)

   for url4, total3  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')

     url4 = string.gsub(url4, '\\u002B', '+')
     

      local x = conn:load(url3)

      for url5, total4  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')

     url5 = string.gsub(url5, '\\u002B', '+')
     
    
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. total2 .. ' '  .. tolazy(total3) .. ' ' .. total4, mrl = url5})

       
    end
end
end

end







   
   
      
    
  

  

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end