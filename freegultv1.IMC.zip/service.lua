-- onlinetv plugin

require('support')
require('video')
require('parser')

HOME = 'https://zigfreed.ru'

HOME_SLASH = HOME .. '/'

--http://www.teleguide.info/download/new3/jtv.zip;
--http://iptvx.one/epg/epg_lite.xml.gz;
--http://programtv.ru/xmltv.xml.gz;
--http://epg.it999.ru/edem.xml.gz;

--TV_URL = 'https://vse-tv.net/tvguide/vse-tv-lite.xml.gz'

--TV_URL = 'https://iptvx.one/epg/epg.xml.gz, https://vse-tv.net/tvguide/vse-tv-lite.xml.gz, http://www.teleguide.info/download/new3/jtv.zip, http://epg.one/epg.xml.gz, https://zigfreed.ru/Z!/epg.xml'


--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'

--TV_URL = 'http://myott.top/api/epg.xml.gz'

--TV_URL = 'http://epg.one/epg2.xml.gz'


--TV_URL = 'http://epg.it999.ru/edem.xml.gz'

--TV_URL = 'https://italo.drm-play.com/full.xml.gz'

--TV_URL = 'https://zigfreed.ru/Z!/epg.xml'

TV_URL = 'http://epg.one/epg.xml.gz'



--TV_URL = 'https://zigfreed.ru/Z!/epg.xml'

TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

--PASS = '7777'

--local lockpass


function onLoad()
	print('Hello from onlinetv plugin')
	return 1
end

function onUnLoad()
	print('Bye from onlinetv plugin')
end

function onCreate(args)

--if not args.q and args.keyword then
--lockpass = args.keyword
--end

--if lockpass == PASS then
--else
--return {view="keyword",message="enter --access code"}
--end



	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	if not args.q then
	
	local genre = args.genre or '1'

--https://proxy4.rte.net.ru/http://live.guljaj.com/user/ent.php

local page = tonumber(args.page or '1')
    
local offset = (page - 1) * 6 + 1
		
		for i = 1, 6 do
 
 

	   local url = 'https://free.guljaj.com/tags.php?id=&tag=' .. genre .. '&page=' .. tostring(offset + i - 1) .. '#goog_fullscreen_ad'

   
    
local headers = {
    ["Host"] = "free.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://free.guljaj.com/tags.php?id=&tag=" .. genre,
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; __gads=ID=3faa83d6dc725b22:T=1788532734:RT=1788841203:S=ALNI_MZByx4oyUsiu5-gFcFpjGWa3ZrVWg; __gpi=UID=0000142c18f20f93:T=1788532734:RT=1788841203:S=ALNI_MYIP67oSAj06e0Q3Hb6_7ZK8yquOQ; __eoi=ID=cd56993845987ea2:T=1788532734:RT=1788841203:S=AA-AfjaXln8Dk2C8cyb8EaFgPEYO; _ym_isad=2; mdd=0; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788925305%2C471559000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol_FwNl8fnoVfWd_oHBbpmxdQkQNUs59VX5R1X5SHfJXUIlfwx2OlX3djlYHHGBE77cZAnAuX1ev1MxtNN7CF7z22tBMe2O47n74z59Q0KbMECKiXm_U1IY7SqNY3Tl8Py_o9GYHFmIET_xaFDv7Ajz2COyLvQ%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin"
}



 local x = http.getz(url, headers)
     
  -- for slist in string.gmatch(x, '</h1>(.-)</p>')	do
     	
        for idk, logo, name in string.gmatch(x, '<h1.-<a href=\'/online/.-idk=(.-)\'.-<img src=\'(http.-png)\'.-<p>.-<strong.->(.-)<') do
	
--	for idk, logo, name in string.gmatch(x, '<td width.-<a href=\'/online/.-idk=(.-)\'.-<img src=.-(http.-)\'.-class=.-stylish%-link.->(.-)</a>') do
	

		table.insert(t, {title = '1 ист.' .. name, mrl = '#stream/q=channel&id=' .. idk .. '&id1=' .. name, image = logo})
	
	table.insert(t, {title = '2 ист. ' .. name, mrl = '#stream/q=channel2&id=' .. idk .. '&id1=' .. name, image = logo})
	
table.insert(t, {title = '3 ист. ' .. name, mrl = '#stream/q=channel3&id=' .. idk .. '&id1=' .. name, image = logo})
	
	table.insert(t, {title = '4 ист. ' .. name, mrl = '#stream/q=channel4&id=' .. idk .. '&id1=' .. name, image = logo})
	
end
		end
  
  local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
		
		local url = 'https://free.guljaj.com'


local headers = {
    ["Host"] = "free.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; __gads=ID=3faa83d6dc725b22:T=1788532734:RT=1788841203:S=ALNI_MZByx4oyUsiu5-gFcFpjGWa3ZrVWg; __gpi=UID=0000142c18f20f93:T=1788532734:RT=1788841203:S=ALNI_MYIP67oSAj06e0Q3Hb6_7ZK8yquOQ; __eoi=ID=cd56993845987ea2:T=1788532734:RT=1788841203:S=AA-AfjaXln8Dk2C8cyb8EaFgPEYO; _ym_isad=2; mdd=0; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788925305%2C471559000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol_FwNl8fnoVfWd_oHBbpmxdQkQNUs59VX5R1X5SHfJXUIlfwx2OlX3djlYHHGBE77cZAnAuX1ev1MxtNN7CF7z22tBMe2O47n74z59Q0KbMECKiXm_U1IY7SqNY3Tl8Py_o9GYHFmIET_xaFDv7Ajz2COyLvQ%3D%3D%22%5D%5D",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1"
    }

 local x = http.getz(url, headers)
     	
--	local slist = string.match(x, '<h2>Категории(.-)Казахстан')
	

local slist = string.match(x, '<h2>Категории(.-)</section>')


for genre, title in string.gmatch(slist, '<a href=\'/tags.php.-tag=(.-)\'.-stylish%-link.->(.-)</a>') do
	

   table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})

end




  
  
  elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword

--local page = tonumber(args.page or '1')
    
--local offset = (page - 1) * 4 + 1
		
	--	for i = 1, 4 do

		
     local url = 'https://free.guljaj.com/search.php?ss=' .. urlencode(args.keyword)
     --.. '&page=' .. tostring(offset + i - 1) .. '#goog_fullscreen_ad'
     
      	

local headers = {
    ["Host"] = "free.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://free.guljaj.com/",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; __gads=ID=3faa83d6dc725b22:T=1788532734:RT=1788841203:S=ALNI_MZByx4oyUsiu5-gFcFpjGWa3ZrVWg; __gpi=UID=0000142c18f20f93:T=1788532734:RT=1788841203:S=ALNI_MYIP67oSAj06e0Q3Hb6_7ZK8yquOQ; __eoi=ID=cd56993845987ea2:T=1788532734:RT=1788841203:S=AA-AfjaXln8Dk2C8cyb8EaFgPEYO; _ym_isad=2; mdd=0; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788925305%2C471559000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol_FwNl8fnoVfWd_oHBbpmxdQkQNUs59VX5R1X5SHfJXUIlfwx2OlX3djlYHHGBE77cZAnAuX1ev1MxtNN7CF7z22tBMe2O47n74z59Q0KbMECKiXm_U1IY7SqNY3Tl8Py_o9GYHFmIET_xaFDv7Ajz2COyLvQ%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin"
}


 local x = http.getz(url, headers)
     	
     	for idk, logo, name in string.gmatch(x, '<h1.-<a href=\'/online/.-idk=(.-)\'.-<img src=.-(http.-)\'.-class=.-stylish%-link.->(.-)</a>') do
	


table.insert(t, {title = '1 ист. ' .. name, mrl = '#stream/q=channel&id=' .. idk .. '&id1=' .. name, image = logo})

table.insert(t, {title = '2 ист. ' .. name, mrl = '#stream/q=channel2&id=' .. idk .. '&id1=' .. name, image = logo})

table.insert(t, {title = '3 ист. ' .. name, mrl = '#stream/q=channel3&id=' .. idk .. '&id1=' .. name, image = logo})

table.insert(t, {title = '4 ист. ' .. name, mrl = '#stream/q=channel4&id=' .. idk .. '&id1=' .. name, image = logo})


		end
  
  





elseif args.q == 'search1' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword

--local page = tonumber(args.page or '1')
    
--local offset = (page - 1) * 4 + 1
		
	--	for i = 1, 4 do

		
     local url = 'https://free.guljaj.com/search.php?ss=' .. urlencode(args.keyword)
     --.. '&page=' .. tostring(offset + i - 1) .. '#goog_fullscreen_ad'
     
      	

local headers = {
    ["Host"] = "free.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://free.guljaj.com/",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; __gads=ID=3faa83d6dc725b22:T=1788532734:RT=1788841203:S=ALNI_MZByx4oyUsiu5-gFcFpjGWa3ZrVWg; __gpi=UID=0000142c18f20f93:T=1788532734:RT=1788841203:S=ALNI_MYIP67oSAj06e0Q3Hb6_7ZK8yquOQ; __eoi=ID=cd56993845987ea2:T=1788532734:RT=1788841203:S=AA-AfjaXln8Dk2C8cyb8EaFgPEYO; _ym_isad=2; mdd=0; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788925305%2C471559000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol_FwNl8fnoVfWd_oHBbpmxdQkQNUs59VX5R1X5SHfJXUIlfwx2OlX3djlYHHGBE77cZAnAuX1ev1MxtNN7CF7z22tBMe2O47n74z59Q0KbMECKiXm_U1IY7SqNY3Tl8Py_o9GYHFmIET_xaFDv7Ajz2COyLvQ%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin"
}


 local x = http.getz(url, headers)
     	
     	for idk, logo, name in string.gmatch(x, '<h1.-<a href=\'/online/.-idk=(.-)\'.-<img src=.-(http.-)\'.-class=.-stylish%-link.->(.-)</a>') do
	


		table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. idk .. '&id1=' .. name, image = logo})
			
	
		end
  
  
--local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
	--	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
        




		
		elseif args.q == 'channel' then
 
 --t['view'] = 'annotation'
 
 local headers = {
    ["Host"] = "free.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; _ym_isad=2; mdd=0; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788925305%2C471559000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol_XeKwl0DSp258QPcaYvHkrMNQO5H7ugoE6Jda6I6Mu5YOUtFCktLci-rSn59X-9H8O2g-5rmnA4ES0iFfHT5dZCMJNpsHZPKTAbyKbqJnSCCswurRcJ5VlppbSnjORfIUzxoiO9bVVfpksmWrcx97u7csVeQ%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
    }
    
 
    local url = 'http://free.guljaj.com/online/?idk=' .. args.id .. '&pot=1#goog_fullscreen_ad'

 
 --local url = 'http://free.guljaj.com/online/?idk=' .. args.id 
 
 local x = http.getz(url, headers)
 

     
  t['title'] = parse_match(x,'<font color=.-#E25D61.->(.-)</font>')
     

     local meta = t['title']
      
       
        t['poster'] = parse_match(x,'<h2>Программа канала.-<img src=.-(http.-)\'')
 
 local logo = t['poster']
 

 
 t['url'] = parse_match(x, 'Playerjs.-file:.-(http.-m3u8)')
 
 local video = t['url']
 


if meta then

--t['view'] = 'list'

t = {
 view = 'list',
 title = meta,
  time = meta,
  time1 = meta,
  description = meta,
  mrl = video,
  image = logo
}

--https://proxy4.rte.net.ru/

--https://api.potok.rip/api/proxy?url=



 table.insert(t, {title = meta, time = meta, description = meta, time1 = meta, time2 = meta, mrl = 'https://api.potok.rip/api/proxy?url=' .. urlencode(video), image = logo})		
 
end
 
 if not meta then
 
-- t['view'] = 'list'
 
 t = {
  view = 'list',
  title = meta,
  name = args.id,
  mrl = video
}
 
 
 
 table.insert(t, {title = args.id1, mrl = 'https://api.potok.rip/api/proxy?url=' .. urlencode(video), image = logo})	
  
 end   

 
 

elseif args.q == 'channel2' then
 
 --t['view'] = 'annotation'
 
 local headers = {
    ["Host"] = "free.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; _ym_isad=2; mdd=0; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788925305%2C471559000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol_XeKwl0DSp258QPcaYvHkrMNQO5H7ugoE6Jda6I6Mu5YOUtFCktLci-rSn59X-9H8O2g-5rmnA4ES0iFfHT5dZCMJNpsHZPKTAbyKbqJnSCCswurRcJ5VlppbSnjORfIUzxoiO9bVVfpksmWrcx97u7csVeQ%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
    }
    
 
    

 
 local url = 'http://free.guljaj.com/online/?idk=' .. args.id .. '&pot=2#goog_fullscreen_ad'
 
 local x = http.getz(url, headers)
 

     
  t['title'] = parse_match(x,'<font color=.-#E25D61.->(.-)</font>')
     

     local meta = t['title']
      
       
        t['poster'] = parse_match(x,'<h2>Программа канала.-<img src=.-(http.-)\'')
 
 local logo = t['poster']
 
 
 
 
 t['url'] = parse_match(x, 'Playerjs.-file:.-(http.-m3u8)')
 
 local video = t['url']
 


if meta then


t = {
  view = 'list',
  title = meta,
  name = args.id1,
  mrl = video
}

t['view'] = 'list'

 table.insert(t, {title = meta, time = meta, description = meta, time1 = meta, time2 = meta, mrl = 'https://api.potok.rip/api/proxy?url=' .. urlencode(video), image = logo})		
 
end
 
 if not meta then
 
-- t['view'] = 'list'
 
 t = {
  view = 'list',
  title = meta,
  name = args.id,
  mrl = video
}
 
 
 
 table.insert(t, {title = args.id1, mrl = 'https://api.potok.rip/api/proxy?url=' .. urlencode(video), image = logo})	
  
 end   

 
 

elseif args.q == 'channel3' then
 
 --t['view'] = 'annotation'
 
 local headers = {
    ["Host"] = "free.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; _ym_isad=2; mdd=0; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788925305%2C471559000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol_XeKwl0DSp258QPcaYvHkrMNQO5H7ugoE6Jda6I6Mu5YOUtFCktLci-rSn59X-9H8O2g-5rmnA4ES0iFfHT5dZCMJNpsHZPKTAbyKbqJnSCCswurRcJ5VlppbSnjORfIUzxoiO9bVVfpksmWrcx97u7csVeQ%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
    }
    
 
    
 
 local url = 'http://free.guljaj.com/online/?idk=' .. args.id .. '&pot=2#goog_fullscreen_ad'
 
 --local url = 'http://free.guljaj.com/online/?idk=' .. args.id 
 
 local x = http.getz(url, headers)
 

     
  t['title'] = parse_match(x,'<font color=.-#E25D61.->(.-)</font>')
     

     local meta = t['title']
      
       
        t['poster'] = parse_match(x,'<h2>Программа канала.-<img src=.-(http.-)\'')
 
 local logo = t['poster']
 
 
            

 
 
-- local url1 = 'http://free.guljaj.com/online/?idk=' .. args.id .. '&pot=3#goog_fullscreen_ad'
 

 
 t['url'] = parse_match(x, 'Playerjs.-file:.-(http.-m3u8)')
 
 local video = t['url']
 
--t['view'] = 'list'

if meta then


t = {
  view = 'list',
  title = meta,
  name = args.id1,
  mrl = video
}


 table.insert(t, {title = meta, time = meta, description = meta, time1 = meta, time2 = meta, mrl = 'https://api.potok.rip/api/proxy?url=' .. urlencode(video), image = logo})		
 
end
 
 if not meta then
 
-- t['view'] = 'list'
 
 t = {
  view = 'list',
  title = meta,
  name = args.id,
  mrl = video
}
 
 
 
 table.insert(t, {title = args.id1, mrl = 'https://api.potok.rip/api/proxy?url=' .. urlencode(video), image = logo})	
  
 end   




elseif args.q == 'channel4' then
 
 --t['view'] = 'annotation'
 
 local headers = {
    ["Host"] = "free.guljaj.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; _ym_isad=2; mdd=0; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788925305%2C471559000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol_XeKwl0DSp258QPcaYvHkrMNQO5H7ugoE6Jda6I6Mu5YOUtFCktLci-rSn59X-9H8O2g-5rmnA4ES0iFfHT5dZCMJNpsHZPKTAbyKbqJnSCCswurRcJ5VlppbSnjORfIUzxoiO9bVVfpksmWrcx97u7csVeQ%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
    }
    
 
    local url = 'http://free.guljaj.com/online/?idk=' .. args.id .. '&pot=4#goog_fullscreen_ad'

 
 --local url = 'http://free.guljaj.com/online/?idk=' .. args.id 
 
 local x = http.getz(url, headers)
 

     
  t['title'] = parse_match(x,'<font color=.-#E25D61.->(.-)</font>')
     

     local meta = t['title']
      
       
        t['poster'] = parse_match(x,'<h2>Программа канала.-<img src=.-(http.-)\'')
 
 local logo = t['poster']
 

 
 t['url'] = parse_match(x, 'Playerjs.-file:.-(http.-m3u8)')
 
 local video = t['url']
 


if meta then

--t['view'] = 'list'

t = {
 view = 'list',
 title = meta,
  time = meta,
  time1 = meta,
  description = meta,
  mrl = video,
  image = logo
}


 table.insert(t, {title = meta, time = meta, description = meta, time1 = meta, time2 = meta, mrl = 'https://api.potok.rip/api/proxy?url=' .. urlencode(video), image = logo})		
 
end
 
 if not meta then
 
-- t['view'] = 'list'
 
 t = {
  view = 'list',
  title = meta,
  name = args.id,
  mrl = video
}
 
 
 
 table.insert(t, {title = args.id1, mrl = 'https://api.potok.rip/api/proxy?url=' .. urlencode(video), image = logo})	
  
 end   
		
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end