-- MySeria.NET plugin

require('video')
require('parser')
require('client')

--SITE = 'myseria.net'
SITE = 'fanserials.vip'
HOME = 'https://' .. SITE
HOME_SLASH = HOME .. '/'
print(HOME_SLASH)

local conn = client.new()
conn['encoding'] = 'UTF-8'
conn['root'] = HOME_SLASH

function onLoad()
	print('Hello from ' .. SITE .. ' plugin')
	return 1
end

function onUnLoad()
	print('Bye from ' .. SITE .. ' plugin')
end

function onCreate(args)
	local t = {view = 'grid_large', type = 'folder', menu = {}}
	if args['q'] ~= 'series' then
		table.insert(t['menu'], {title = '@string/series', mrl = '#folder/q=series', image = '#self/list.png'})
	end
	if not args.q then
		local path = args.path or '/series/serials/'
		local page = tonumber(args.page or '1')
		local url = HOME .. path
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		print(url)
		local x = conn:load(url)
		--print(x)
		for item in string.gmatch(x, 'class="item"(.-)</li>') do
			--print(item)
			local url, title = string.match(item, 'field%-title.-href="(.-)">(.-)</a>')
			local descr = string.match(item, 'field%-description.-<a.->(.-)</a>')
			if descr then
				title = title .. ' - ' .. descr
			end
			local icon = string.match(item, "background%-image: url%('(.-)'%)")
			if icon and not string.find(icon, '://') then
				icon = HOME .. icon
			end
			table.insert(t, {title = tolazy(title), mrl = '#video/q=video&url=' .. http.urlencode(url) .. '&t=' .. title, image = icon})
		end
		local url='#folder/path='..path..'&page='..tostring(page+1)
		table.insert(t, {title = 'Страница ' .. tostring(page+1), mrl = url, image = '#self/next.png'})

	-- #folder/q=series
	elseif args.q == 'series' then
		t['view'] = 'simple'
		local x = conn:load(HOME_SLASH)
		--print(x)
		for id, title in string.gmatch(x,'class="literal__item.-href="(.-)">(.-)</a>') do
			--if string.find(id, '/$') then
				table.insert(t, {title = tolazy(title), mrl = '#folder/path=' .. id})
			--end
		end
		
	-- #video/q=video&url=http%3A%2F%2Fmyseria%2Enet%2F645%2Dfizika%2Dili%2Dhimija%2Dvossoedinenie%2F1%2Dseason%2F1%2Depisode%2Ehtml&t=Физика или химия: Воссоединение - 1 сезон 1 серия
	elseif args.q == 'video' then
		local url = string.gsub(args['url'], '^/', HOME_SLASH)
		local x = conn:load(url)
		local url = string.match(x, 'file=([^&"]+)')
		if url then
			print(url)
			return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}
		end
		return {view = 'error', message = 'Видео недоступно для просмотра!'}
	end
	return t
end
