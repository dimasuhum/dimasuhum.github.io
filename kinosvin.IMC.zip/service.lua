-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://kinosvinka.cc'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



--HOME = 'https://kinosvinka.cc'



--HOME = 'https://kinosvin.ru'
--HOME1 = 'https://kadikama.online'

--HOME_SLASH = HOME .. '/'
--HOME1_SLASH = HOME1 .. '/'
function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

	if not args.q then
	

	
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/lastnews/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
         local x = conn:load(url)
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for  url, title, image  in string.gmatch(x, '<div class="title".-<a href="(.-)".->(.-)</a.-<img src="(/.-)"') do
          

        image = string.gsub(image, '^(.-)', HOME)
        
         table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})

		
		end
		
     --     if url == HOME1 .. genre then

     --     url = url .. 'page/' .. tostring(page) .. '/'
       --   end
	--	local x = http.getz(url)
         

	--	for  url, image, title in string.gmatch(x, '<a href="(https://kadikama.-html)".-class="mov%-i img%-box".-<img src="(.-)" alt="(.-)"') do
          

     --   image = string.gsub(image, '^(.-)', HOME1)
        
     --    table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})

	--	end
--		end
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = conn:load(HOME)
		
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, '<div class="post%-cont clrfix">(.-)</div')

		for genre, image, title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
		
            image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre, image = image})
		end

		--	table.insert(t, {title = 'По году', mrl = '#stream/genre=' .. '/tags/'})
            
            table.insert(t, {title = 'Русские фильмы', mrl = '#stream/genre=' .. '/russkie-filmy/'})
            
            table.insert(t, {title = 'Русские сериалы', mrl = '#stream/genre=' .. '/russkij-serial/'})
            
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="post%-cont clrfix">(.-)<br>')
     --   t['poster'] = args.p
		t['poster'] = parse_match(x,'<img itemprop="image" src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(<td>Жанр </td>.-)</td>','(Жанр:</span>.-)</div>', '(<td>Год </td>.-)</td>', '(<td>Качество </td>.-)</td>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
		
		
--https://kinomobi.net/tor.php?id=18266.html
        for url in string.gmatch(x, 'url=(aHR0.-)\'') do
         print(url)
         
		 url = string.gsub(url, '%%3D', '')

        url=http.urldecode(base64_decode(url))
         
       table.insert(t, {title = 'Смотреть', mrl = url})

			
		end


         local x = string.match(x, '<nav id="rel%-news">(.-)</nav>')

         for url, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end






	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end