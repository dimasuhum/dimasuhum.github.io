-- VideoCDN

require('support')
require('video')
require('parser')

HOME = 'http://stvplay.mooo.com:81/vk/vk.php?search='
--API_TOKEN = '6Onb1W1alEUrBcKJZD3GoKBbWyAl2uG2'




--https://videocdn.tv/api/short?api_token=6Onb1W1alEUrBcKJZD3GoKBbWyAl2uG2&kinopoisk_id=666


function onLoad()
	print('Hello from VideoCDN')
	return 1
end

function onUnLoad()
	print('Bye from VideoCDN')
end

-- #self/keyword=28
function onCreate(args)
	if args['keyword'] then
		local t = {view = 'simple', type = 'folder'}
		t['menu'] = {}
       table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
		
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME  .. urlencode(args.keyword) .. '&page=' .. tostring(page)


		 local x = http.getz(url)
     
       for total, url in string.gmatch(x, '</channel.-<channel.-title>.-%[CDATA%[(.-)].-playlist_url>.-%[CDATA%[(http.-)]') do


       local x = http.getz(url)
   
        for total1, url in string.gmatch(x, 'title>.-%[CDATA%[(1080p).-<stream_url>.-%[CDATA%[(https.-)]') do
   
      table.insert(t, {title = total1 ..  ' ' ..  total, mrl = url})
    
        end
   end
   
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
		return t
	elseif args['q'] == 'play' then
		return video(args.url, args)
	else
		return {view = 'keyword', message = '@string/search_text'}
	end
	
end
   
