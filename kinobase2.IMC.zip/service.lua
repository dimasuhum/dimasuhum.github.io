-- kinobase plugin

require('support')
require('video')
require('parser')
require('client')
--require('fxml')

--local fxml = onCreate




--local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'

local HOME = 'https://kinobase.org'
--local HOME = 'https://kinovod120224.cc'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




--https://kinobase.org/user_data?page=movie&movie_id=20597&cuid=becbba75f70a129327afa2d6dfc4a1ac&device=DESKTOP&_=1652508426908
    --       165204183297

--HOME = 'https://kinobase.org'
--HOME = 'https://kinob.net'

--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinobase plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinobase plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
       table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/films'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
	--	local x = http.getz(url)
        local x = conn:load(url)
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for  url, image, title in string.gmatch(x, '<div class="poster".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
        url = string.gsub(url, '^(.-)', HOME)
          

			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
         for  url, image, title in string.gmatch(x, '<li class="item".-<a href="(/collection.-)".-<img src="(.-)".-alt="(.-)"') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. url, image = image})
		
		end
		
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         




         table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections'})
      --    local x = http.getz(HOME .. '/films')

       --  local x = string.match(x, '<ul class="dropdown%-menu">(.-)</ul>')
		--	for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			--	table.insert(t, {title = 'Фильмы :' .. (title), mrl = '#stream/genre=' .. genre})
		--	end
	--	end
		local x = http.getz(HOME .. '/films')
     --   local tt = {
--			'<script type="text/javascript".-genres(.-)</script>',
--		}
		

    --    for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Фильмы :' .. tolazy(title), mrl = '#stream/genre=' .. '/films/' .. genre})
		--	end
		end
		
		local x = http.getz(HOME .. '/serials')
	--	local tt = {
		--	'<script type="text/javascript".-genres(.-)</script>',
--		}
		
	--	for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Сериалы :' .. tolazy(title), mrl = '#stream/genre='  .. '/serials/' .. genre})
		--	end
		end
		local x = http.getz(HOME .. '/tv')
    --    local tt = {
		--	'<script type="text/javascript".-genres(.-)</script>',
	--	}
		

     --   for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Телепередачи :' .. tolazy(title), mrl = '#stream/genre=' .. '/tv/' .. genre})
		--	end
		end
	
	
     local x = http.getz(HOME .. '/animation')
      --  local tt = {
	--		'<script type="text/javascript".-genres(.-)</script>',
--		}
		

      --  for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Мультфильмы :' .. tolazy(title), mrl = '#stream/genre=' .. '/animation/' .. genre})
		--	end
		end
		
		





    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search?query=' .. urlencode(args.keyword) .. '&page='  .. tostring(page)

		
		local x = http.getz(url)
		
        for  url, image, title in string.gmatch(x, '<div class="poster".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
    --     url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			


	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	-- #stream/q=content&id=http://fxmlparsers.in.net/http://videocdn.tv/?id=info&cid=//65503.svetacdn.in/NNdOI7MjO2YU/movie/65569&translate=0&title=%D0%A0%D0%B5%D0%BD%D1%84%D0%B8%D0%BB%D0%B4+%D0%94%D1%83%D0%B1%D0%BB%D1%8F%D0%B6
    elseif args.q == 'content' then
		t['view'] = 'annotation'
	--	local x = http.getz(args.id)
        local x = conn:load(args.id)
       -- local x = http.getz(HOME .. args.id)
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="body" itemprop="description">(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'Год</div>(.-)</li>','(Страна:</b>.-)</li>','Жанр</div>(.-)</div>','(Режиссер:</b>.-)</li>','(Актеры:</b>.-)</li>','(Качество:</b>.-)</li>', 
                    
                
		})
		

        for url6, url1, url2, url3 in string.gmatch(x, 'STATIC_VERSION.-"(.-)";.-MOVIE_ID = (.-);.-PLAYER_CUID.-"(.-)";.-IDENTIFIER.-"(.-)";') do


        local url = HOME .. '/user_data?page=movie&movie_id=' .. url1 .. '&cuid=' .. url2 .. '&device=DESKTOP&_=' .. url6
		
       local x = http.getz(url)


         

         for url4, url5 in string.gmatch(x, '"vod_time2":(.-),"vod_hash2":"(.-)"') do

         
         
         
        local url = HOME .. '/vod/' .. url1 .. '?identifier=' .. url3 .. '&player_type=new&file_type=mp4&st=' .. url5 .. '&e=' .. url4 .. '&_=' .. url6

           local x = http.getz(url)




     --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
    --  end
   --  end


    --    local x = conn:load(HOME .. '/vod/' .. url1 .. '?identifier=' .. url3 .. '&player_type=new&file_type=mp4&st=' .. url5 .. '&e=' .. url4 .. '&_=' .. url)
       
       for title, url in string.gmatch(x, '(360p).-(http.-0.mp4)') do
		

      url = string.gsub(url, '\\', '')

        table.insert(t, {title = title, mrl = url})
		end

		
       for title, url in string.gmatch(x, '(720p).-(http.-0.mp4)') do
		

      url = string.gsub(url, '\\', '')

        table.insert(t, {title = title, mrl = url})
		end
		
      for title, url in string.gmatch(x, '(1080p).-(http.-0.mp4)') do
		

      url = string.gsub(url, '\\', '')

        table.insert(t, {title = title, mrl = url})
		end
		
		
  --   for title, url in string.gmatch(x, '(360p).-or.-(http.-0.mp4)') do
		
      --  url = string.gsub(url, '\\', '')

   --     table.insert(t, {title = title, mrl = url})
--		end
		
	--	for title, url in string.gmatch(x, '(720p).-or.-(http.-0.mp4)') do
		
     --   url = string.gsub(url, '\\', '')

    --    table.insert(t, {title = title, mrl = url})
	--	end
		
   --    for title, url in string.gmatch(x, '(1080p).-or.-(http.-0.mp4)') do
		
   --     url = string.gsub(url, '\\', '')

  --      table.insert(t, {title = title, mrl = url})
	--	end
		
		
		
        end
        end
         








         for url  in string.gmatch(x, '<h1.->(.-)</h1>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
        table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    
        end
    
    
      --   local x = http.getz(url)
         for url, url1  in string.gmatch(x, 'current_page".-"data":%[{"id":(.-),"kinopoisk_id":(.-),') do
  

        url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=') .. '&kinopoisk_id=' .. url1
        

      local x =  http.getz(url)
       
      
       
       for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(1080p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(720p).-(http.-mp4)') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(480p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(360p).-(http.-mp4)') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end

        
        
        for url1, url2  in string.gmatch(x, 'current_page".-"data":%[{"id":(.-),"kinopoisk_id":(.-),') do
       
		url = string.gsub(url2, '^(.-)', 'https://voidboost.net/embed/')
       
       
        local x = http.getz(url)
    --x = string.match(x, '<select name="season".->(.-)</select>')
    
        for url, title in string.gmatch(x, '<option value="(.-)".-(Сезон.-)</option>') do
  

       url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=' .. url1 .. '&kinopoisk_id=' .. url2 .. '&title=&original_title=&s=')
        

         
     local x = http.getz(url)



       for url, total  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do
       

       t['view'] = 'simple'

       table.insert(t, {title = title .. (total), mrl = url})
    
    	end
	end
    end

         
      
      
      
      
   --     for url in string.gmatch(x, '<h1.->(.-)</h1>') do
       --   url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
     --   local x = http.getz(url)
    
   --    for  url  in string.gmatch(x, 'current_page".-"data":%[{"id".-"kinopoisk_id":(.-),') do
  
      
      
--https://cors.nb557.workers.dev:8443/https://zeflix.online/iplayer/videodb.php?id=0&kp=386&domain=kinobd.net
      
    --   url = string.gsub(url, '^(.-)', 'https://cdnmovies-stream.online/kinopoisk/') .. '/iframe?domain=kinobd.net'
    	
    	

	--		table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
			
	--	end

      --   local x = http.getz(url)
         
     --    for url in string.gmatch(x, 'player.-:.-#2(.-)"') do
       
       
     --    print(url)

  --       url = string.gsub(url, '\\/\\/Ni14UVdNaDdlcnRMcDh0X005aHVVRGsxTTBWcllK', '')
     --    url = string.gsub(url, '\\/\\/d05wMndCVE5jUFJRdlRDMF9DcHhDc3FfOFQxdTlR', '')
     --    url = string.gsub(url, '\\/\\/bWQtT2QyRzlSV09nU2E1SG9CU1NiV3JDeUlxUXlZ', '')
     --    url = string.gsub(url,'\\/\\/a3p1T1lRcUJfUVNPTC14ek5fS3oza2tna0hoSGl0', '')
    --     url = string.gsub(url,'VfR0xFc1h4bnBVNExqamQwUmVZLVZI', '')
  --       url = string.gsub(url,'\\/\\/UnlUd3RmMT', '')




      --   url=http.urldecode(base64_decode(url))
  


        
     --   if url then
		--	for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(240p)](http.-.m3u8)') do
			

      --     t['view'] = 'simple'
   --    url = string.gsub(url, '\\', '')
      
       
		--		table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
	--		end
--		end	
        
		  --      if url then
	--		for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(360p)](http.-.m3u8)') do
			

        --    t['view'] = 'simple'
    --   url = string.gsub(url, '\\', '')
       
		--		table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
	--		end
--		end	
			
           --     if url then
		--	for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(480p)](http.-.m3u8)') do
			
           --  title = tolazy(title)
        --   t['view'] = 'simple'
    --   url = string.gsub(url, '\\', '')
       
		--		table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
		--	end
	--	end	
          --      if url then
		--	for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(720p)](http.-.m3u8)') do
			
         --    title = tolazy(title)
     --      t['view'] = 'simple'
    --   url = string.gsub(url, '\\', '')
       
		--		table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
	--		end
	--	end	
          --      if url then
	--		for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(1080p)](http.-.m3u8)') do
			
         --    title = tolazy(title)
       --     t['view'] = 'simple'
    --   url = string.gsub(url, '\\', '')
       
			--	table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
	--		end
	--	end	
    --    end
  --    end
      
      
         
         
         
          for url in string.gmatch(x, '<h1.->(.-)</h1>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
        local x = http.getz(url)
    
       for  url  in string.gmatch(x, 'current_page".-"data":%[{"id".-"kinopoisk_id":(.-),') do
  

       print(url) 
   
       url = string.gsub(url, '^(.-)', 'https://videocdn.tv/api/short?api_token=bVycnMuy5Dfe0IkzXt87eeVa9EtIkUl5&kinopoisk_id=')
  
--&domain=kinobd.net

         local x = http.getz(url)
       for  url  in string.gmatch(x, '"iframe_src":"(.-)"') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
  
       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
    end
    end
  

  
  
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(360p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       
       
        for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(480p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
  
      for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(720p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(1080p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
	
		
       for title, url  in string.gmatch(x, 'movie.-%[(360p)].-(cloud-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
     	 for title, url  in string.gmatch(x, 'movie.-%[(480p)].-(cloud.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
	for title, url  in string.gmatch(x, 'movie.-%[(720p)].-(cloud.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
		
        for title, url  in string.gmatch(x, 'movie.-%[(1080p)].-(cloud.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
		
		
         




        for url  in string.gmatch(x, '<h1.->(.-)</h1>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
   --     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    
        
    
    
        local x = http.getz(url)
         for url, url1  in string.gmatch(x, 'current_page".-"data":%[{"id":(.-),"kinopoisk_id":(.-),') do

        url = string.gsub(url1, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
        end
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-or (//video.zagonka.org/movies/.-mp4)') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end




    --    for title  in string.gmatch(x, '<div id="title"><h1>(.-)</h1>') do

    --     print(url)
		 

    --     url = string.gsub(title, '^(.-)', 'http://xplay.bz/list?search=')
         
     --    local x = fxml({url = url})
    --    for url in string.gmatch(url, '"playlist_url":"(.-)"') do
        
 
       
    --    local x = fxml({url = url})
   --     for _, v in ipairs(x) do
 

   -- 	if string.find(v.mrl, '^#') then
    	
		--	v.mrl = v.mrl .. '&package=' .. urlencode(REPO .. 'xplay.IMC.zip')
	--	end
--		table.insert(t, v)
--	end
    --  end 



       for url  in string.gmatch(x, '<h1.->(.-)</h1>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
   --     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    
        
    
    
        local x = http.getz(url)
         for url, url1  in string.gmatch(x, 'current_page".-"data":%[{"id":(.-),"kinopoisk_id":(.-),') do

         url = string.gsub(url1, '^(.-)', 'http://divantv.zz.mu/kinomovie/zombie.m3u.php?kp_id=')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
		end
		
		
		
        for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end
   

        
        
	elseif args.q == 'play' then
	
     --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end