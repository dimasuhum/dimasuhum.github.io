-- kinobase plugin

require('support')
--require('video')
--require('parser')
require('client')
--require('fxml')

--local fxml = onCreate

local video = require('video')
local parser = require('parser')


local headers = {
	['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
	Connection = 'close'
}




--local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


--https://kinovod.net/film/227662-chuzhoy-romul

--local HOME = 'http://byzkhkgr.deploy.cx/?ip=185.228.133.208/https://kinobase.org'
--local HOME = 'https://kinovod020824.pro/'
local HOME = 'https://kinobase.org'
--local HOME = 'https://kinovod220224.pro'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




--https://kinobase.org/user_data?page=movie&movie_id=20597&cuid=becbba75f70a129327afa2d6dfc4a1ac&device=DESKTOP&_=1652508426908
    --       165204183297

--HOME = 'https://kinobase.org'
--HOME = 'https://kinob.net'

--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinobase plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinobase plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
       table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/films'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
	--	local x = http.getz(url)
        local x = conn:load(url)
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for  url, image, title in string.gmatch(x, '<div class="poster".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
        url = string.gsub(url, '^(.-)', HOME)
          

			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
         for  url, image, title in string.gmatch(x, '<li class="item".-<a href="(/collection.-)".-<img src="(.-)".-alt="(.-)"') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. url, image = image})
		
		end
		
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         




         table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections'})
      --    local x = http.getz(HOME .. '/films')

       --  local x = string.match(x, '<ul class="dropdown%-menu">(.-)</ul>')
		--	for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			--	table.insert(t, {title = 'Фильмы :' .. (title), mrl = '#stream/genre=' .. genre})
		--	end
	--	end
		local x = http.getz(HOME .. '/films')
     --   local tt = {
--			'<script type="text/javascript".-genres(.-)</script>',
--		}
		

    --    for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Фильмы :' .. tolazy(title), mrl = '#stream/genre=' .. '/films/' .. genre})
		--	end
		end
		
		local x = http.getz(HOME .. '/serials')
	--	local tt = {
		--	'<script type="text/javascript".-genres(.-)</script>',
--		}
		
	--	for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Сериалы :' .. tolazy(title), mrl = '#stream/genre='  .. '/serials/' .. genre})
		--	end
		end
		local x = http.getz(HOME .. '/tv')
    --    local tt = {
		--	'<script type="text/javascript".-genres(.-)</script>',
	--	}
		

     --   for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Телепередачи :' .. tolazy(title), mrl = '#stream/genre=' .. '/tv/' .. genre})
		--	end
		end
	
	
     local x = http.getz(HOME .. '/animation')
      --  local tt = {
	--		'<script type="text/javascript".-genres(.-)</script>',
--		}
		

      --  for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Мультфильмы :' .. tolazy(title), mrl = '#stream/genre=' .. '/animation/' .. genre})
		--	end
		end
		
		





    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search?query=' .. urlencode(args.keyword) .. '&page='  .. tostring(page)

		
		local x = http.getz(url)
		
        for  url, image, title in string.gmatch(x, '<div class="poster".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
         url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			


	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	-- #stream/q=content&id=http://fxmlparsers.in.net/http://videocdn.tv/?id=info&cid=//65503.svetacdn.in/NNdOI7MjO2YU/movie/65569&translate=0&title=%D0%A0%D0%B5%D0%BD%D1%84%D0%B8%D0%BB%D0%B4+%D0%94%D1%83%D0%B1%D0%BB%D1%8F%D0%B6
    elseif args.q == 'content' then
		t['view'] = 'annotation'
	--	local x = http.getz(args.id)
        local x = conn:load(args.id)
       -- local x = http.getz(HOME .. args.id)
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="body" itemprop="description">(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'Год</div>(.-)</li>','(Страна:</b>.-)</li>','Жанр</div>(.-)</div>','(Режиссер:</b>.-)</li>','(Актеры:</b>.-)</li>','(Качество:</b>.-)</li>', 
                    
                
		})
		

       for url  in string.gmatch(x, '<h1.->(.-)</h1>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
       
       local x = http.getz(url)
      
        for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
        
       url = string.gsub(url, '^(.-)', 'https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=')
   
        local x = http.getz(url)
   

   
       for title, url  in string.gmatch(x, 'url.-http.-kinovibe.co.-%-(.-).html.-embed.-(http.-)"') do
   
       url = string.gsub(url, '\\', '')
   
       title = string.gsub(title, 'series', '')
         
    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})

       end
       end
       end

        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
         
        t['view'] = 'simple'
         
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
     
         t['view'] = 'simple'
     
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
         t['view'] = 'simple'
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end



		
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-id:"playerjshd".-file:"(.-txt)"') do
         -- print(url)
      --    t['view'] = 'grid'
       --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' ..  url})
    --table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})
--		end

       local x = http.getz(url)



           for title, url in string.gmatch(x, '"comment":"(.-)".-file.-(https://s.-mp4)"') do
			print(url)  

          url = string.gsub(url, '_[480,720]', '')
          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title), mrl = url})
        end



		for title, url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do

          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title) .. ' (480p)'  , mrl = url .. url1 .. '_480.mp4'})
   

        end
	
	
          for title,  url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do
		--	print(url)  

      --    url = string.gsub(url, '(.-)', url) .. '_720.mp4'
          t['view'] = 'grid'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title) .. ' (720p)', mrl = url .. url1 .. '_720.mp4'})
   
   --     table.insert(t, {title = tolazy(title) .. (total), mrl = url})
        end
	
      end









        for url6, url1, url2, url3 in string.gmatch(x, 'STATIC_VERSION.-"(.-)";.-MOVIE_ID = (.-);.-PLAYER_CUID.-"(.-)";.-IDENTIFIER.-"(.-)";') do

        local url = HOME .. '/user_data?page=movie&movie_id=' .. url1 .. '&cuid=' .. url2 .. '&device=DESKTOP&_=' .. url6
  
  
  
--http://byzkhkgr.deploy.cx/?ip=185.228.133.208/https://kinobase.org/vod/232587?identifier=2fN60lW5anRN4EYTAaAs&player_type=new&file_type=mp4&st=3q3SX7WAjyDuX67jwjq6yw&e=1723348528&_=1723284845593
  
 -- 'http://byzkhkgr.deploy.cx/?ip=185.228.133.208/' .. 
   
      --  local url = HOME .. '/user_data?page=movie&movie_id=' .. url1 .. '&cuid=' .. url2 .. '&_=' .. url6

  --   table.insert(t, {title = url, mrl = url})
       local x = http.getz(url)


--   "vod_time2":1723348031,"vod_hash2":"Tbg2nFGXPxVOofPYjsKEfQ"      

         for url4, url5 in string.gmatch(x, '"vod_time2":(.-),"vod_hash2":"(.-)"') do
   
         
          local x = http.getz('http://nb557.surge.sh/online_mod.js')
     
         for url7 in string.gmatch(x, ' sbk: \'(.-)\'') do

--'http://byzkhkgr.deploy.cx/?ip=185.228.133.208/' .. 
     
        local url = HOME .. '/vod/' .. url1 .. '?sbk=' .. url7 .. '&identifier=' .. url3 .. '&player_type=new&file_type=mp4&st=' .. url5 .. '&e=' .. url4 .. '&_=' .. url6
       
       


    table.insert(t, {title = url, mrl = url})

          local x = http.getz(url)


      
       for title, url in string.gmatch(x, 'file|.-%[(360p)](http.-0.mp4)') do
     
     table.insert(t, {title = tolazy(title), mrl = url})
		end
       
      for title, url in string.gmatch(x, 'file|.-%[(360p)].-or (http.-0.mp4)') do
     
     table.insert(t, {title = tolazy(title), mrl = url})
		end
       
          
     for title, url in string.gmatch(x, 'file|.-%[(720p)](http.-0.mp4)') do
   
     table.insert(t, {title = url, mrl = url})
     
  --    table.insert(t, {title = tolazy(title), mrl = url})
     

		end
		
          for title, url in string.gmatch(x, 'file|.-%[(720p)].-or (http.-0.mp4)') do
     
     
        table.insert(t, {title = tolazy(title), mrl = url})
		end
		
     for title, url in string.gmatch(x, 'file|.-%[(1080p)](http.-0.mp4)') do
     
     table.insert(t, {title = tolazy(title), mrl = url})
		end  
		
      for title, url in string.gmatch(x, 'file|.-%[(1080p)].-or (http.-0.mp4)') do
     
     table.insert(t, {title = tolazy(title), mrl = url})
		end     
		
		
		
		
		
       for total, url, title in string.gmatch(x, '"file".-%[(360p).-(http.-0.mp4).-"title":"(.-)"') do
		

      url = string.gsub(url, '\\', '')

        title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')



         table.insert(t, {title = '('.. total .. ')' .. tolazy(title), mrl = url})
		end

		
              
       for total, url, title in string.gmatch(x, '"file".-%[(720p).-(http.-0.mp4).-"title":"(.-)"') do
		

      url = string.gsub(url, '\\', '')

        title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')



         table.insert(t, {title = '('.. total .. ')' .. tolazy(title), mrl = url})
		end
		
             
       for total, url, title in string.gmatch(x, '"file".-%[(1080p).-(http.-0.mp4).-"title":"(.-)"') do
		

      url = string.gsub(url, '\\', '')

        title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')



         table.insert(t, {title = '('.. total .. ')' .. tolazy(title), mrl = url})
		end
		end
		end
        end
         



       for url  in string.gmatch(x, '<h1.->(.-)</h1>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')

        
  --  url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=') 
       table.insert(t, {title = 'cdnvideohub плеер', mrl = '#stream/q=content&id=' .. url})

        end
  
     --    local x = http.getz(url)
          for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
  
       url = string.gsub(url, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=23&kid=')
 
   --    table.insert(t, {title = 'cdnvideohub плеер', mrl = '#stream/q=content&id=' .. url})
 
 
   --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})

     --  end
     --  end 
        
        local x = http.getz(url)
        
        for title, url in string.gmatch(x, '\'title\':.-\'(.-)\'.-\'file.-(http.-)\'') do
     
        url = string.gsub(url, '\\u0026', '&')
     
      url = string.gsub(url, '_IPHONE', '')
     url = string.gsub(url, '\\', '')
     
            t['view'] = 'simple'
        table.insert(t, {title = title, mrl = url})
       end
       end 





         for url  in string.gmatch(x, '<h1.->(.-)</h1>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
        table.insert(t, {title = 'Zetflix плеер', mrl = '#stream/q=content&id=' .. url})
    
        end
    
    

         for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   

         url = string.gsub(url, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=')



      --   url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=')

    --    url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=0&kinopoisk_id=')
        

      local x =  http.getz(url)
       
    
      
       
       for total, url, title in string.gmatch(x, '"method":"play","url".-(1080p).-(http.-)".-class="videos__item%-title">(.-)<') do
       
   --    local title = json.decode(title)
   --    print(title)
       
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
			
			
      for total, url, title in string.gmatch(x, '"method":"play","url".-(720p).-(http.-)".-class="videos__item%-title">(.-)<') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
   
      for total, url, title in string.gmatch(x, '"method":"play","url".-(480p).-(http.-)".-class="videos__item%-title">(.-)<') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for total, url, title in string.gmatch(x, '"method":"play","url".-(360p).-(http.-)".-class="videos__item%-title">(.-)<') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end
--end
        
        
          for url2  in string.gmatch(x, 'current_page".-"data":%[{"id.-"kinopoisk_id":(.-),') do
       

        url = string.gsub(url2, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=23&kid=')
       
        local x = http.getz(url)


       for title, url3 in string.gmatch(x, '\'title\': \'(Season) (.-)\',') do


        local x = http.getz('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)
  
  
     
      
   --   local x = http.getz('https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)


  
        for url5, total5  in string.gmatch(x, 'method":"link".-(&t=.-)".->(.-)</div>') do


       local x = http.getz('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3 .. url5)



       for url4, total2  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do

        total2 = string.gsub(total2, '\\u0441\\u0435\\u0440\\u0438\\u044F', 'серия')

       t['view'] = 'simple'
   
   

      table.insert(t, {title = title .. ' ' .. url3 .. (total2) .. (total5), mrl = url4})
    

	end
    end
    end
    end
  
        

   
   
   
      
      for title, total in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%) смотреть') do
 
       
       title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
        url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '(' .. total .. ')'
  

         local x = http.get(url)
     
       for total  in string.gmatch(x, '"fxml".-playlist_url.-?id=info&cid=(.-)"') do
       

        url = string.gsub(total, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
   
       table.insert(t, {title = 'Zagonka плеер', mrl = '#stream/q=content&id=' .. url})
       end
       end
    --    end
   --    local x = http.getz(url)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-(//video.zagonka.org/movies/.-})') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
			
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
		
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
    end    
 --   end

 


     
  





      for title, total in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%) смотреть') do
  
     

       
       title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
        url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '(' .. total .. ')'
  

         local x = http.get(url)
     
       for total1  in string.gmatch(x, '"fxml".-playlist_url.-?id=info&cid=(.-)"') do
       
         url = string.gsub(total1, '^(.-)', 'https://kinobadi.mom/hd_pars/pleer_on.php?url&kp=')
    
  --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
	
  		
		local x = http.get(url)

	
		for url2  in string.gmatch(x, '<iframe.-src="/pleer_4.-(/embed.-)"') do

	
		url = string.gsub(url2, '^(.-)', 'https://672431256.videoframe1.com')
	

   
       table.insert(t, {title = 'Vibix', mrl = '#stream/q=content&id=' .. url})
	
	
	end
	end
	end

	

		
		for title in string.gmatch(x, '{"title":"(.-)"') do
		
         for total, url  in string.gmatch(x, 'MP4(.-)](http.-mp4)') do
         
		t['view'] = 'simple'
		
        table.insert(t, {title = title .. ' ' .. (total), mrl = url})
        end
        end

        
        for title in string.gmatch(x, '{"title":"(Сезон.-)"') do
   
       for total, total1, total2,  url in string.gmatch(x, '{"title":"(.-)".-{"title":"(.-)".-"file":"%[(.-p)](http.-mp4)') do
 
 
       total1 = string.gsub(total1, '{"title":', '')

       total2 = string.gsub(total2, '{"title":', '')

     
     
        t['view'] = 'simple'
  
      table.insert(t, {title = (total) .. ' ' .. (total1) .. ' ' .. (total2), mrl = url})
        end
       end
      
 

       
      for title, total in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%) смотреть') do

      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
     
    
     
--http://stvplay.mooo.com:81/torrents/rutor.php?search=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%20(1979)

     url = string.gsub(title, '^(.-)', 'http://stvplay.mooo.com:81/torrents/rutor.php?search=') .. '(' .. total .. ')'
     
  --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
   --    end
  --     end
        
    local x = http.get(url)

   

   
    
      for title, url in string.gmatch(x, '</channel.-<channel.-<title.-CDATA%[(.-)].-<playlist_url.-http.-rutor.php?.-=(.-)]') do
   

   
       url = string.gsub(url, '^(.-)', 'http://rutor.info')
  
      table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
         end
         end
         
         
         
  
      for total in string.gmatch(x, '<a href="magnet.-btih:(.-)&') do


      total = string.lower(total)
    
  --   total = total:lower()
      
        url = string.gsub(total, '^(.-)', 'https://ts.moviecorn.one/stream/file.m3u?link=') .. '&m3u'
  
  --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
         local x = http.get(url)
   
    
      for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-)(http.-play)') do
   

   
       t['view'] = 'grid'
     	table.insert(t, {title = total1, mrl = url .. '&hitid='})
    	
     	end
        end
   --    end
 --  end
   
		
		
   
   
   
   
   

        
        
	elseif args.q == 'play' then
	
     --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end