-- kinobase plugin

require('support')
require('video')
require('parser')

HOME = 'https://kinobase.org'
--HOME = 'https://kinob.net'

HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinobase plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinobase plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
       table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/films'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		local x = http.getz(url)
         
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for  url, image, title in string.gmatch(x, '<div class="poster".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
     --   url = string.gsub(url, '^(.-)', HOME)
          

			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
         for  url, image, title in string.gmatch(x, '<li class="item".-<a href="(/collection.-)".-<img src="(.-)".-alt="(.-)"') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. url, image = image})
		
		end
		
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         




         table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections'})
      --    local x = http.getz(HOME .. '/films')

       --  local x = string.match(x, '<ul class="dropdown%-menu">(.-)</ul>')
		--	for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			--	table.insert(t, {title = 'Фильмы :' .. (title), mrl = '#stream/genre=' .. genre})
		--	end
	--	end
		local x = http.getz(HOME .. '/films')
     --   local tt = {
--			'<script type="text/javascript".-genres(.-)</script>',
--		}
		

    --    for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Фильмы :' .. tolazy(title), mrl = '#stream/genre=' .. '/films/' .. genre})
		--	end
		end
		
		local x = http.getz(HOME .. '/serials')
	--	local tt = {
		--	'<script type="text/javascript".-genres(.-)</script>',
--		}
		
	--	for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Сериалы :' .. tolazy(title), mrl = '#stream/genre='  .. '/serials/' .. genre})
		--	end
		end
		local x = http.getz(HOME .. '/tv')
    --    local tt = {
		--	'<script type="text/javascript".-genres(.-)</script>',
	--	}
		

     --   for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Телепередачи :' .. tolazy(title), mrl = '#stream/genre=' .. '/tv/' .. genre})
		--	end
		end
	
	
     local x = http.getz(HOME .. '/animation')
      --  local tt = {
	--		'<script type="text/javascript".-genres(.-)</script>',
--		}
		

      --  for _, v in ipairs(tt) do
		--	local x = string.match(x, v)
			for genre, title in string.gmatch(x, 'url:\'(.-)\',title:\'(.-)\',') do
				table.insert(t, {title = 'Мультфильмы :' .. tolazy(title), mrl = '#stream/genre=' .. '/animation/' .. genre})
		--	end
		end
		
		





    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search?query=' .. urlencode(args.keyword) .. '&page='  .. tostring(page)

		
		local x = http.getz(url)
		
        for  url, image, title in string.gmatch(x, '<div class="poster".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
    --     url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			


	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	-- #stream/q=content&id=http://fxmlparsers.in.net/http://videocdn.tv/?id=info&cid=//65503.svetacdn.in/NNdOI7MjO2YU/movie/65569&translate=0&title=%D0%A0%D0%B5%D0%BD%D1%84%D0%B8%D0%BB%D0%B4+%D0%94%D1%83%D0%B1%D0%BB%D1%8F%D0%B6
    elseif args.q == 'content' then
		t['view'] = 'annotation'
	--	local x = http.getz(args.id)
        local x = http.getz(HOME .. args.id)
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="body" itemprop="description">(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Год:</b>.-)</li>','(Страна:</b>.-)</li>','(Жанр:</b>.-)</li>','(Режиссер:</b>.-)</li>','(Актеры:</b>.-)</li>','(Качество:</b>.-)</li>', 
                    
                
		})
		
--http://fxmlparsers.ru/https://kinobase.org/?do=view&id=/serial/153444-chuzhaya-staya

--http://fxmlparsers.in.net/http://www.kinobase.org/?id=pfile&page=9ffc6b5281d893c0d267ef44c8c3c062&fjs=fe1a8c3c985fb91df0a45d9026a54295&r=/film/208906-gipnotik&plst=648f5358e25ef60aaefd5f5f5492f966

--<span class="rating_kp" title="КиноПоиск – 6.8 (40 761)"></span> <a href="https://www.kinopoisk.ru/film/5047468/"

     --    local x = http.getz(args.id)
--http://divantv.zz.mu/kinoboom_dimon1978pl_no_save_2018_kino_live_profi_krad_i_portal_2018-12-22_10-32-46/kinotop.net/kinotop.net.php?Urlpage=


--https://kinobase.org/film/212289-tri-mushketera-dartanyan

   --    local x = http.getz('http://sp-social.ru/rad/NJVg9XvEKBsdHE2vLh3IXxPZsLJvBxHe7tl6.php?uid=' .. HOME .. args.id)
  
  
--http://fxmlparsers.ru/https://cdn.kinobase.org/?do=view&id=
  
  
--http://fxmlparsers.in.net/http://videocdn.tv/?id=info&cid=//65503.svetacdn.in/NNdOI7MjO2YU/movie/65569&translate=0&title=%D0%A0%D0%B5%D0%BD%D1%84%D0%B8%D0%BB%D0%B4+%D0%94%D1%83%D0%B1%D0%BB%D1%8F%D0%B6
  
  
--http://fxmlparsers.in.net/https://cdn.kinobase.org/?do=view&id=/film/223442-holop-2
  
  
    --  local x = http.getz('http://fxmlparsers.ru/https://kinobase.org/?do=view&id=' .. args.id)

         
  
  
--http://fxmlparsers.in.net/https://cdn.kinobase.org/?do=view&id=/film/205153-indiana-dzhons-i-koleso-sudby
         
  
         local x = http.getz('http://fxmlparsers.in.net/https://cdn.kinobase.org/?do=view&id=' .. args.id)
  
--{"br":".-,"title":"(.-)","stream_url":"(.-)"
      
      
       for title, url in string.gmatch(x, '{"br":"1","preview":"","title":"(.-)","stream_url":"(http.-m3u8)"') do

       
 --        url = string.gsub(url, '\\\\', '')
          url = string.gsub(url, '\\', '')



title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')



         table.insert(t, {title = tolazy(title), mrl = url})
		end
      
      
  

       for title, url in string.gmatch(x, '{"br":1,"position":"list","title":"(.-)","preview":"","stream_url":"(http.-m3u8#playerjw)"') do
       
      --   url = string.gsub(url, '\\\\', '')
          url = string.gsub(url, '\\', '')


title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')




         table.insert(t, {title = tolazy(title), mrl = url})
		end



       
  
       
       for title, url in string.gmatch(x, '<title>.-CDATA.-(360)].-<stream_url.-(https.-m3u8)') do
		

        table.insert(t, {title = title, mrl = url})
		end
     for title, url in string.gmatch(x, '<title.-CDATA.-(720)].-<stream_url.-(https.-m3u8)') do
		

        table.insert(t, {title = title, mrl = url})
		end
        for title, url in string.gmatch(x, '<title.-CDATA.-(1080)].-<stream_url.-(https.-m3u8)') do
		

        table.insert(t, {title = title, mrl = url})
		end
       
       




         for title, url in string.gmatch(x, '<title.-CDATA(.-серия).-<stream_url.-(https.-m3u8)') do
		
         
        
        table.insert(t, {title = tolazy(title), mrl = url})
		end

         

        
	elseif args.q == 'play' then
	
     --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end