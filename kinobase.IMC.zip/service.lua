-- kinobase plugin

require('support')
require('video')
require('parser')

--HOME = 'https://kinobase.org'
HOME = 'https://kinob.net'

HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinobase plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinobase plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
       table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/films'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		local x = http.getz(url)
         
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for  url, image, title in string.gmatch(x, '<div class="col%-xs%-2 item".-<a href="(/.-)".-<img src="(.-)".-alt="(.-)"') do
     --   url = string.gsub(url, '^(.-)', HOME)
          

			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
         for  url, image, title in string.gmatch(x, '<div class="col%-xs%-3 item collection%-item".-<a href="(.-)".-<img src="(.-)".-alt="(.-)" ') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. url, image = image})
		
		end
		
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         




         table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collections'})
          local x = http.getz(HOME .. '/films')

         local x = string.match(x, '<ul class="dropdown%-menu">(.-)</ul>')
			for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
				table.insert(t, {title = 'Фильмы :' .. (title), mrl = '#stream/genre=' .. genre})
			end
	--	end
		local x = http.getz(HOME .. '/films')
        local tt = {
			'<span class="dropdown%-u">Жанр.->(.-)<div class="dropdown%-menu audio%-dropdown"',
		}
		

        for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for genre, title in string.gmatch(x, '<input type="checkbox" value="(.-)">(.-)</label>') do
				table.insert(t, {title = 'Фильмы :' .. (title), mrl = '#stream/genre=' .. '/films/' .. genre})
			end
		end
		
		local x = http.getz(HOME .. '/serials')
		local tt = {
			'<ul class="dropdown%-menu">(.-)<div class="row items"',
		}
		
		for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
				table.insert(t, {title = 'Сериалы :' .. (title), mrl = '#stream/genre=' .. genre})
			end
		end
		local x = http.getz(HOME .. '/serials')
        local tt = {
			'<span class="dropdown%-u">Жанр.->(.-)<div class="row items">',
		}
		

        for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for genre, title in string.gmatch(x, '<input type="checkbox" value="(.-)">(.-)</label>') do
				table.insert(t, {title = 'Сериалы :' .. (title), mrl = '#stream/genre=' .. '/serials/' .. genre})
			end
		end
		
		
		
--https://kinotop.net/films/animation
    	local x = http.getz(HOME .. '/films/animation')
		local tt = {
			'<ul class="dropdown%-menu">(.-)<div class="row items"',
		}
		
		for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
				table.insert(t, {title = 'Мультфильмы :' .. (title), mrl = '#stream/genre=' .. genre})
			end
		end	
		local x = http.getz(HOME .. '/films/animation')
        local tt = {
			'<span class="dropdown%-u">Жанр.->(.-)<div class="dropdown%-menu audio%-dropdown"',
		}
		

        for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for genre, title in string.gmatch(x, '<input type="checkbox" value="(.-)">(.-)</label>') do
				table.insert(t, {title = 'Мультфильмы :' .. (title), mrl = '#stream/genre=' .. '/films/animation_' .. genre})
			end
		end
		
		
		
--https://kinotop.net/tv
		local x = http.getz(HOME .. '/tv')
		local tt = {
			'<ul class="dropdown%-menu">(.-)<div class="row items"',
		}
		
		for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
				table.insert(t, {title = 'Телепередачи :' .. (title), mrl = '#stream/genre=' .. genre})
			end
		end	
		
        local x = http.getz(HOME .. '/tv')
		local tt = {
			'<span class="dropdown%-u">Жанр.->(.-)<div class="row items">',
		}
		

        for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for genre, title in string.gmatch(x, '<input type="checkbox" value="(.-)">(.-)</label>') do
				table.insert(t, {title = 'Телепередачи :' .. (title), mrl = '#stream/genre=' .. '/tv/' .. genre})
			end
		end



    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search?query=' .. urlencode(args.keyword) .. '&page='  .. tostring(page)

		
		local x = http.getz(url)
		
        for url, image, title in string.gmatch(x, '<div class="col%-xs%-2 item".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"')do
    --     url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			


	-- #stream/q=content&id=/15387-predchuvstvie-2020.html

    elseif args.q == 'content' then
		t['view'] = 'annotation'
	--	local x = http.getz(args.id)
        local x = http.getz(HOME .. args.id)
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="body" itemprop="description">(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Год:</b>.-)</li>','(Страна:</b>.-)</li>','(Жанр:</b>.-)</li>','(Режиссер:</b>.-)</li>','(Актеры:</b>.-)</li>','(Качество:</b>.-)</li>', 
                    
                
		})
		


       local x = http.getz('http://sp-social.ru/rad/NJVg9XvEKBsdHE2vLh3IXxPZsLJvBxHe7tl6.php?uid=' .. HOME .. args.id)
  
  
  


  
       
       for title, url in string.gmatch(x, '<title>.-CDATA.-(360)].-<stream_url.-(https.-m3u8)') do
		

        table.insert(t, {title = title, mrl = url})
		end
     for title, url in string.gmatch(x, '<title.-CDATA.-(720)].-<stream_url.-(https.-m3u8)') do
		

        table.insert(t, {title = title, mrl = url})
		end
        for title, url in string.gmatch(x, '<title.-CDATA.-(1080)].-<stream_url.-(https.-m3u8)') do
		

        table.insert(t, {title = title, mrl = url})
		end
       
       




         for title, url in string.gmatch(x, '<title.-CDATA(.-серия).-<stream_url.-(https.-m3u8)') do
		
         
        
        table.insert(t, {title = title, mrl = url})
		end

         

        
	elseif args.q == 'play' then
	
     --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end