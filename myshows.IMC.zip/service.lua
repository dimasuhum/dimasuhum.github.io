-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')

--local HOME = 'http://stvplay.mooo.com:81/cub/cub.php'

local HOME1 = 'http://parsers.appfxml.com'
local HOME = 'https://myshows.me'

--https://myshows.me/collections/users/?q=%D0%A3%D0%B6%D0%B0%D1%81

--https://cub.red/api/collections/view/180
--https://cub.red/api/collections/view/249204?=

local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

local conn1 = client.new()
conn1['encoding'] = 'windows-1251'


--  HOME = 'http://stvplay.mooo.com:81/cub/cub.php?col=1&sort=releases&name=Релизы'

--http://stvplay.mooo.com:81/cub/cub.php?col=1&topic=128-per-rishar-luchshee&serial=0

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
   table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

table.insert(t['menu'], {title = 'Поиск по коллекциям', mrl = '#folder/q=searchcoll', image = '#self/search.png'})


-- #stream/page=2
-- #stream/genre=col=1&genre=27
	if not args.q then
--https://myshows.me/collections/users/?sort=id_desc&page=2	

		local page = tonumber(args.page or 1)
	
		local genre = args.genre or '/collections/users/'
		local url = HOME .. genre
     
	 url = url .. '?sort=id_desc' .. '&page=' .. tostring(page)
	local x = conn:load(url)
   
       x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
	
	
--	<h3 class="title__main%-text".-<a href="(.-)".->(.-)</a>.-<img src="(.-)"
	
	
	
	
       for id, title, image in string.gmatch(x, '<h3 class="title__main%-text".-<a href="(.-)".->(.-)</a>.-src.-(http.-)"') do

	

    
  -- image = string.gsub(image, '\\', '')
	
 --  id = string.gsub(id, '^(.-)', '/collections/')
	
	
 --  table.insert(t, {title = id, mrl = '#stream/genre=' ..  id, url = url, image = image})
	
	t['view'] = 'grid_large'
	
	table.insert(t, {title = tolazy(title), mrl = '#stream/q=coll&id='.. id, image = image})
end

local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' ..  genre
		
		
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	
	
	
		
		elseif args.q == 'coll' then

--https://myshows.me/lists/16788/
		
		local x = conn:load(HOME .. args.id)
	
	
	
local slist = string.match(x, '{"list"(.-)"emotionId"')

if slist then

for id, title, image in string.gmatch(slist,'"totalSeasons".-"audience".-},(.-),"(.-)".-"(http.-)"') do

url = string.gsub(id, '^(.-)', HOME .. '/view/') .. '/'


table.insert(t, {title = tolazy(title), mrl = '#stream/q=contents&id=' .. url .. '&id1=' .. title, image = image})
		
	end		
end


local x = conn:load(HOME .. args.id)


		
local slist = string.match(x, '{"list"(.-)"emotionId"')

if slist then
for id, title, image in string.gmatch(slist,'"userMovie".-"audience".-},(.-),"(.-)".-"(http.-)"') do

url = string.gsub(id, '^(.-)', HOME .. '/movie/') .. '/'


table.insert(t, {title = tolazy(title), mrl = '#stream/q=contents&id=' .. url .. '&id1=' .. title, image = image})
		
	end		
end

  


		
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'





--	local genre = args.genre or '/list?='
		local x = conn:load(HOME .. '/list?=')
     
--	 url = url .. '&page=' .. tostring(page)
--	local x = conn:load(url)
       
	
       for genre, title, image in string.gmatch(x, '{"id":(.-),.-"title":"(.-)".-"backdrop_path":"(/.-)"') do

	image = string.gsub(image, '^(.-)', 'https://imagetmdb.cub.red/t/p/w355_and_h200_multi_faces')
	
	
    
	
   genre = string.gsub(genre, '^(.-)', '/view/') .. '?='
	
	
 --  table.insert(t, {title = genre, mrl = '#stream/genre=' ..  genre, image = image})
	
	table.insert(t, {title = tolazy(title), mrl = '#stream/genre='.. genre, image = image})
end





--http://stvplay.mooo.com:81/cub/cub.php?col=1&genre=27&serial=0&name=Ужасы

table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. 'genre=1'})

table.insert(t, {title = 'Подборка', mrl = '#stream/genre=' .. 'topic=257'})

      local x = conn:load(HOME .. 'genres=1')

		
--http://stvplay.mooo.com:81/cub/cub.php?genres=1&name=Фильмы
		
        
	--	local x = string.match(x, '<ul class="reset top%-menu">(.-)</ul>')
		for title, genre in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url>.-http.-(genre.-)&serial') do
			table.insert(t, {title = 'Фильмы : ' .. title, mrl = '#stream/genre=' .. genre})
		end
     
     
    local x = conn:load(HOME .. 'genres=2')

		
--http://stvplay.mooo.com:81/cub/cub.php?genres=1&name=Фильмы
		
        
	--	local x = string.match(x, '<ul class="reset top%-menu">(.-)</ul>')
		for title, genre in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url>.-http.-(col.-)&serial') do
			table.insert(t, {title = 'Сериалы : ' .. title, mrl = '#folder/genre=' .. genre})
		end
     
     
     
     
        
   --     local x = http.get(HOME .. '/kino-podborka.html')
       -- x = iconv(http.get(HOME .. '/kino-podborka.html'), 'WINDOWS-1251', 'UTF-8')
        --x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--local x = string.match(x, '<nav class="side%-box to%-mob">(.-)</nav>')
		--for genre, title in string.gmatch(x, '<a href="(.-)".-<span class="podborki%-title">(.-)</span>') do
		--	table.insert(t, {title = title, mrl = '#folder/genre=' .. genre})
	--	end
  
  
  
  
  
  
  
  elseif args.q == 'list' then
   
local page = tonumber(args.page or 1)
   
   local x = conn:load('https://api.poiskkino.dev/v1.4/' .. args.id .. '?page=' .. tostring(page) .. '&limit=10&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG') 
   
  
  
  for id, image, title in string.gmatch(x, '"slug":"(.-)".-"cover":.-"url":"(.-)".-"name":"(.-)"') do
  
    table.insert(t, {title = tolazy(title), mrl = '#stream/q=collection&id=' .. id, image = image})
	end	
  
  local url = '#stream/page=' .. tostring(page + 1) .. '&q=list&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
  
  
  elseif args.q == 'collection' then
  
   local page = tonumber(args.page or 1)
   
   local x = conn:load('https://api.poiskkino.dev/v1.4/movie?lists=' .. args.id .. '&language=RU' .. '&page=' .. tostring(page) .. '&limit=10&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
  


x = string.gsub(x, '("names".-])', '')
	
 x = string.gsub(x, '("genres".-])', '')
 x = string.gsub(x, '("countries".-])', '')



  for id, title,  image  in string.gmatch(x, '"id":(.-),.-"name":"(.-)".-"poster".-"url":"(http.-)"') do
  
--https://api.kinopoisk.dev/v1.4/movie?lists=top250&page=1&limit=10&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG
  
  
--table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. title, image = image})
  
 table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. id, image = image})
	end	


  
  local url = '#stream/page=' .. tostring(page + 1) .. '&q=collection&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
  





    elseif args.q == 'acter' then
   
   local x = conn:load('https://api.poiskkino.dev/v1.4/movie/' .. args.id .. '?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
  
     local x = string.match(x, '"persons":(.-)"lists"')
     
     for id, image, title, total  in string.gmatch(x, '"id":(.-),.-photo":"(http.-)".-"name":"(.-)".-"profession":"(.-)"') do   
 
       table.insert(t, {title = title .. '  (' .. total .. ')', mrl = '#stream/q=person&id=' .. id, image = image})
       end 
 
 
 

 
elseif args.q == 'persons' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
      
   --   HOME = string.gsub(HOME, '?id=navigator&genre=', '') 
		
		local url = 'https://api.poiskkino.dev/v1.4/person/search' .. '?page=' .. tostring(page) .. '&limit=10&query=' ..    urlencode(args.keyword) .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'


		local x = conn:load(url)
	
		
        for id, title, image in string.gmatch(x, '"id":(.-),"name":"(.-)".-"photo":"(.-)"') do
    
  

        
			table.insert(t, {title = title, mrl = '#stream/q=person&id=' .. id, image = image})
		end
		
    	local url = '#folder/q=persons&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
 
 
 
 
 
 
 
 
    elseif args.q == 'person' then
   
   local x = conn:load('https://api.poiskkino.dev/v1.4/person/' .. args.id .. '?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
  
 
--https://api.kinopoisk.dev/v1.4/person/6915?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG
 

local x = string.match(x, '"movies":(.-)]')
     
     for id, title, total  in string.gmatch(x, '"id":(.-),.-"name":"(.-)".-"enProfession":"(.-)"') do   
 
 
image = string.gsub(id, '^(.-)', 'https://kinopoiskapiunofficial.tech/images/posters/kp_small/') .. '.jpg' 
 
       table.insert(t, {title = title .. '  (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
       end 





   
   elseif args.q == 'similar' then
  
   local x = conn:load('https://api.poiskkino.dev/v1.4/movie/' .. args.id .. '?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
  
   local x = string.match(x, '"lists"(.-)"videos"')
 

 
 for id, title, image, total in string.gmatch(x, '"id":(.-),"name":"(.-)".-"poster".-"url":"(http.-)".-"year":(.-)}') do
  
  
  title = string.gsub(title, '\\', '')
title = string.gsub(title, '"', '')
  
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
     


    elseif args.q == 'collect' then
  
   local x = conn:load('https://api.poiskkino.dev/v1.4/movie/' .. args.id .. '?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
  
   local x = string.match(x, '"lists"(.-)]')
 
 for id in string.gmatch(x, '"(.-)"') do
  
  
     t['view'] = 'simple'

			table.insert(t, {title=id, mrl = '#stream/q=collection&id=' .. id, image = image})
		end
     
  
  
--https://myshows.me/collections/users/?q=%D0%A3%D0%B6%D0%B0%D1%81
  
        
        elseif args.q == 'searchcoll' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
      

		
		local url = HOME .. '/collections/users/?q=' .. urlencode(args.keyword) .. '&page=' .. tostring(page)
        
        local x = conn:load(url)
   
       x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

	
       for id, title, image in string.gmatch(x, '<h3 class="title__main%-text".-<a href="(.-)".->(.-)</a>.-src.-(http.-)"') do


	
	t['view'] = 'grid_large'
	
	table.insert(t, {title = tolazy(title), mrl = '#stream/q=coll&id='.. id, image = image})
end

local url = '#folder/q=searchcoll&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
        
        
        
        
   elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
      
   --   HOME = string.gsub(HOME, '?id=navigator&genre=', '') 
		
		local url = HOME1 .. '/https://www.kinopoisk.ru/?id=search&search=' .. urlencode(args.keyword) .. '&p=' .. tostring(page)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
	
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
	
		
        for  title, url, image in string.gmatch(x, '{"title":"(.-)".-"playlist_url":".-?id=info&cid=(.-)".-"logo.-:"(.-.jpg)"') do

 
  
    image = string.gsub(image, '\\', '') 
  
  
  --  url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=')
    
        
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
       
   
   
   elseif args.q == 'contents' then
		t['view'] = 'annotation'
	
      local x = conn:load(args.id)

--t['name'] = parse_match(x,'charset=.-<title>(.-)</title>')
		t['description'] = parse_match(x,'<div class="HtmlContent">(.-)</div>')
   
      t['annotation'] = parse_array(x, {
			'charset=.-<title>.-%((.-)%)', '(Жанры: </td>.-)</td>',
		})
   
       t['poster'] = args.p
	--	t['poster'] = parse_match(x,'poster.-"(http.-)"')
--		if t['poster'] then
	--		t['poster'] = string.gsub(t['poster'], '\\', '')
--		end
   
 
  
   
  for id2 in string.gmatch(x,'charset=.-<title>.-%((.-)%)') do
  
  --.-<td class="info%-row__value".-<a href="http.-kinopoisk.-/.-/(.-)/"') do


     local x = conn:load('http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=' .. urlencode(args.id1) .. ',' .. id2)


   
    for id3 in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
  
 -- for id3, id1, id2 in string.gmatch(x, '"id":(.-),.-"name":"(.-)".-"year":(.-),') do 
 
 
 
     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=video&id1=' .. args.id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
		
		



--	for title  in string.gmatch(x, '<td class="info%-row__value".-<a href="http.-kinopoisk.-/.-/(.-)/"') do
table.insert(t, {title = 'Актёры', mrl = '#stream/q=acter&id=' .. id3, image = image})
    --   end
       
       
   -- for title  in string.gmatch(x, '<td class="info%-row__value".-<a href="http.-kinopoisk.-/.-/(.-)/"') do
table.insert(t, {title = 'Похожие', mrl = '#stream/q=similar&id=' .. id3, image = image})
    --   end
  
  --    for title  in string.gmatch(x, '<td class="info%-row__value".-<a href="http.-kinopoisk.-/.-/(.-)/"') do
table.insert(t, {title = 'Коллекции', mrl = '#stream/q=collect&id=' .. id3, image = image})
   --    end 	
		
 end
	end	
       
       
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html


	elseif args.q == 'content' then
		t['view'] = 'annotation'
	


--https://myshows.me/movie/411/
	
--	local x = conn:load(HOME .. '/http://kinopoisk.ru/?id=info&cid=' .. args.id)
--	local x = http.get(args.id)
     
  --   local x = fxml(args.id)



--x = string.gsub(x, '{"name":"', '')
--x = string.gsub(x, '\\r\\n\\t', '')

--	https://api.kinopoisk.dev/v1.4/list/popular?page=1&limit=10&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG
	
--https://api.kinopoisk.dev/v1.4/movie?page=1&limit=10&listMovies.id=67ebbcd25da2d4ce280a5d86&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG





--https://api.kinopoisk.dev/v1.4/person/search?page=1&limit=10&query=%D0%A8%D0%B2%D0%B0%D1%80%D1%86%D0%B5%D0%BD%D0%B5%D0%B3%D0%B3%D0%B5%D1%80

--https://api.kinopoisk.dev/v1.4/list?page=1&limit=10&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG


--https://api.kinopoisk.dev/v1.4/movie?lists=top250&page=1&limit=10&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG

--https://api.kinopoisk.dev/v1.4/person/6915?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG


--https://api.poiskkino.dev/v1.4/movie/386?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG

--https://api.kinopoisk.dev/v1.4/movie/386?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG

--		local x = conn:load('https://api.poiskkino.dev/v1.4/movie/' .. args.id .. '?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
   
  
  
--  (Жанры: </td>.-)</td>
  
--  <span class="SlidingTabs__header-container".-Описание</span>.-class="HtmlContent">(.-)</div>
   local x = conn:load('https://api.poiskkino.dev/v1.4/movie?id=' .. args.id.. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')

x = string.gsub(x, '{"name":"', '')
x = string.gsub(x, '"}', '')

x = string.gsub(x, '"genres":%[', 'Жанр:')
  
     

	
--/http:\/\/kinopoisk.ru\/?id=info&cid=
	
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'{"id":.-"name":"(.-)".-"year":(.-),')
		t['description'] = parse_match(x,'"description":"(.-)"')
   
      t['annotation'] = parse_array(x, {
			'"year":(.-),', '(Жанр:.-)]',
		})
   
       t['poster'] = args.p
	--	t['poster'] = parse_match(x,'poster.-"(http.-)"')
--		if t['poster'] then
	--		t['poster'] = string.gsub(t['poster'], '\\', '')
--		end

 
 
 
 for id3, id1, id2 in string.gmatch(x, '"id":(.-),.-"name":"(.-)".-"year":(.-),') do 
 
     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=video&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
		
		end
 
 
      
    



      for title  in string.gmatch(x, '"id":(.-),') do
table.insert(t, {title = 'Актёры', mrl = '#stream/q=acter&id=' .. title, image = image})
       end
       
       
    for title  in string.gmatch(x, '"id":(.-),') do
table.insert(t, {title = 'Похожие', mrl = '#stream/q=similar&id=' .. title, image = image})
       end
      for title  in string.gmatch(x, '"id":(.-),') do
table.insert(t, {title = 'Коллекции', mrl = '#stream/q=collect&id=' .. title, image = image})
       end 
       
       
 
          elseif args.q == 'video' then

       t['view'] = 'simple'



  --  table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3, image = image})
  
  table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. args.id3})
  
table.insert(t, {title = 'Hdvb2', mrl = '#stream/q=hdvbf&id3=' .. args.id3})
  
  table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id3=' .. args.id3, image = image})
  
  
       table.insert(t, {title = 'Collaps', mrl = '#stream/q=collaps&id3=' .. args.id3})

  table.insert(t, {title = 'Collaps-dash', mrl = '#stream/q=collaps-dash&id3=' .. args.id3})
  
       
       table.insert(t, {title = 'Kino4k', mrl = '#stream/q=kino4k&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
   table.insert(t, {title = 'Filmix', mrl = '#stream/q=filmix&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
--table.insert(t, {title = 'Filmix2', mrl = '#stream/q=filmix2&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})

table.insert(t, {title = 'Kinofit', mrl = '#stream/q=kinofit&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 
table.insert(t, {title = 'Videocdn', mrl = '#stream/q=videocdn&id3=' .. args.id3})
  
  
 table.insert(t, {title = 'Lumex', mrl = '#stream/q=lumex&id3=' .. args.id3})
   
   
   table.insert(t, {title = 'Kinopub', mrl = '#stream/q=kinopub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
       
       
    table.insert(t, {title = 'Alloha', mrl = '#stream/q=alloha&id3=' .. args.id3})
 
 -- table.insert(t, {title = 'Mirage', mrl = '#stream/q=mirage&id3=' .. args.id3})
  
  table.insert(t, {title = 'Mirage', mrl = '#stream/q=mirage&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  table.insert(t, {title = 'Seasonvar', mrl = '#stream/q=seasonvar&id1=' .. args.id1})
  
table.insert(t, {title = 'Cdnmovies', mrl = '#stream/q=cdnmovies&id3=' .. args.id3})
  
  table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=vdbmovies&id3=' .. args.id3})
  

 
 table.insert(t, {title = 'Videodb', mrl = '#stream/q=videodb&id3=' .. args.id3})
  
  
table.insert(t, {title = 'Krasview', mrl = '#stream/q=krasview&id1=' .. args.id1 .. '&id2=' .. args.id2})

    table.insert(t, {title = 'Getstv', mrl = '#stream/q=getstv&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = image})
    
    table.insert(t, {title = 'Anwap', mrl = '#stream/q=anwap&id1=' .. args.id1 .. '&id5=' .. '1' .. '&id6=' .. 'on'})
    
      table.insert(t, {title = 'Rezka', mrl = '#stream/q=rezka&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
 
local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=' .. urlencode(args.id1) .. '-' .. args.id2 .. '&box_mac=acace24b8434')

x = string.gsub(x, '%%20', '+')

    local slist = string.match(x, 'Мультфильмы.-</playlist_url>(.-)</playlist_url>')
      if slist then
    
    for url in string.gmatch(slist,'<channel>.-<title><!%[CDATA.-<playlist_url><!%[CDATA%[http.-&stream=(.-)]]') do
 
     url = base64_decode(url)
  
  
   table.insert(t, {title = 'Hdrezka', mrl = '#stream/q=hdrezka&id=' .. url})
   end
   end
 
   
   table.insert(t, {title = 'Kinobase', mrl = '#stream/q=kinobase&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
table.insert(t, {title = 'Videohub', mrl = '#stream/q=cdnvideohub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  table.insert(t, {title = 'Kinogo', mrl = '#stream/q=kinogo&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
 
 table.insert(t, {title = 'Videoseed', mrl = '#stream/q=videoseed&id3=' ..  args.id3})
 
 
   table.insert(t, {title = 'Vkmovie', mrl = '#stream/q=vkmovie&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
table.insert(t, {title = 'Remux', mrl = '#stream/q=remux&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   
   table.insert(t, {title = 'Jac', mrl = '#stream/q=jac&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Pidtor', mrl = '#stream/q=pidtor&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Torrs', mrl = '#stream/q=torrs&id1=' .. args.id1 .. '&id2=' .. args.id2, image = image})
   
   

   
   table.insert(t, {title = 'Kinotochka', mrl = '#stream/q=kinotochka&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})

table.insert(t, {title = 'Vibix', mrl = '#stream/q=vibix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
   
   table.insert(t, {title = 'Veo', mrl = '#stream/q=veo&id3=' .. args.id3, image = image})
   
   
table.insert(t, {title = 'Veoveo', mrl = '#stream/q=veoveo&id3=' .. args.id3 .. '&id1=' .. args.id1})
  
  
  
 --   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=' .. urlencode(args.id1) .. '-' .. args.id2 .. '&box_mac=acace24b8434')



  --  local slist = string.match(x, 'Мультфильмы.-</playlist_url>(.-)</playlist_url>')
    --  if slist then
    
  --  for url in string.gmatch(slist,'<channel>.-<title><!%[CDATA.-<playlist_url><!%[CDATA%[http.-&stream=(.-)]]') do
 
  --   url = base64_decode(url)
  
  
 --  table.insert(t, {title = 'Hdrezka', mrl = '#stream/q=hdrezka&id=' .. url})
 --  end
--   end
   
   

--table.insert(t, {title = 'Xkino', mrl = '#stream/q=xkino&id4=' .. args.id4})


--https://tv-1-kinoserial.net/api_player.php?kp_id=386&token=fbdcf2438c4f9f0ed76121801807891a

--https://videoseed.tv/apiv2.php?item=movie&token=fbdcf2438c4f9f0ed76121801807891a&kp=386
 
--https://api.videoseed.tv/apiv2.php?item=movie&token=fbdcf2438c4f9f0ed76121801807891a&kp=386
 
 
 
 
-- https://api.rstprgapipt.com/balancer-api/iframe?kp=1338024&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI
 
 
 
-- https://lamp-movie.ru/proxy/ZHIM6TGAty9DENCUXI0WgbWABkCG8d5eYFt9ugGnaifV6o6r4JSbogF6tULIbPy8ubQ2zoTCK7p91ZFpyLN2Z7YbW7aoURb34AcmP8Rj2V237gA+0RssGh+FWHxl56EabeEQbhVAsos4xLa2TRcCY5fayg05xD6Ujjcn9TIBhmKLnGKR\u002BOq5SdPykrmA/9dQRUwcv6hGPPC4RohGLKfc9+k/BdPpgiYpind0xbQrLLKuyLhGqI3IqW+ZG4ei4LUygJ1bCikGN41iVikFBHYLX/PnD9XLxbU+/CgZXJ9fkgHyKt6qW29Obzzc3Hd4DIhFYCM9Yz5oP4ccX/7nlQ/1qo2gh9oVSUYqevvoK7E6SnU=.m3u8
 
 
 --https://evkh.lol
 
-- https://lamp-movie.ru/lite/kinogo?kinopoisk_id=386&title=чужой&year=1979
 --https://mylam.ru/lite/kinogo?kinopoisk_id=386&title=чужой&year=1979
 
 
 
 
elseif args.q == 'flixcdn' then

 
-- https://cdn0.cdnhub.help/show/kinopoisk/386?domain=piratka.tv
 
 
 local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv')



local slist = string.match(x, '<select name="translator"(.-)movies')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
         
    local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv&translation=' .. id5)



    local slist = string.match(x, 'file.-:(.-)CDNquality')

    if slist then
 
 for title1, url in string.gmatch(slist, '%[(.-)](http.-m3u8)') do

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   end
end
 end



 
    local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv&autoplay=1&extrans=1')



local slist = string.match(x, '<select name="season"(.-)</select>')
  
      if slist then
                                             for id2, title1 in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
                                    

  local slist = string.match(x, '<select name="episode"(.-)</select>')
  
      if slist then
                                            for id4, title2 in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do





  local slist = string.match(x, '<select name="translator"(.-)series')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
 id5 = string.gsub(id5, '^(.-)', 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv&autoplay=1&extrans=1&translation=') 
 
 

    t['view'] = 'simple'

   table.insert(t, {title = title1 .. ' ' .. title2 .. ' ' .. title, mrl = '#stream/q=flixcdns&id3=' .. args.id3 .. '&id5=' .. id5 .. '&id1=' .. title .. '&id2=' .. id2 .. '&id4=' .. id4})

  end
   end
   end
   end
    end
 end
   
   
    
    elseif args.q == 'flixcdns' then  
    
    local x = conn:load(args.id5 .. '&season=' .. args.id2 .. '&episode=' .. args.id4)
    
      local slist = string.match(x, 'file.-:(.-)CDNquality')

    if slist then
 
 for title, url in string.gmatch(slist, '%[(.-)](http.-m3u8)') do

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
   end

 
 
 
 
 
elseif args.q == 'krasview' then

    local x = conn1:load('https://krasview.ru/movie?mode=search&ajax&query=' .. urlencode(args.id1) .. ',' .. args.id2)


   for url, total in string.gmatch(x, '<li id=.-<a href=.-(http.-)\'.-alt=\'(.-)\'>') do


      local x = conn1:load(url)



    for id in string.gmatch(x, '<ul class=.-video%-gallery.-itemscope itemtype=.-id=\'v%-(.-)\'') do

     id = string.gsub(id, '^(.-)', 'https://zedfilm.ru/') 
 
     local x = conn1:load(id)
 
 for url1 in string.gmatch(x, 'video_Init.-\'(.-)\'') do
 
 
    url1 = base64_decode(url1)
   
 
   for url2 in string.gmatch(url1, '"url2":"(http.-)"') do
    
    
      url2 = string.gsub(url2, 'media', 'm')
         t['view'] = 'simple'
table.insert(t, {title = total, mrl = url2})

--https://m4.krasview.ru/video/fabd2523f76f3e9/video-1080.m3u8

    end
end
end
end

    local x = conn1:load('https://krasview.ru/series?mode=search&ajax&query=' .. urlencode(args.id1))
    --.. ',' .. args.id2)


    for url, total in string.gmatch(x, '<li id=.-<a href=\'(http.-)\'.-alt=\'(.-)\'') do
         t['view'] = 'simple'
    table.insert(t, {title = tolazy(total), mrl = '#stream/q=krasviews&id=' .. url})
    end
 
   elseif args.q == 'krasviews' then

      local page = tonumber(args.page or 1)

      local x = conn1:load(args.id .. '?page=' .. tostring(page))



   for id, title in string.gmatch(x, '<li itemprop=\'itemListElement\' itemscope itemtype=.-id=\'v%-(.-)\'.-alt=\'(.-)\'') do

   id = string.gsub(id, '^(.-)', 'https://zedfilm.ru/') 
 
     local x = conn1:load(id)
 
 for url1 in string.gmatch(x, 'video_Init.-\'(.-)\'') do
 
 
    url1 = base64_decode(url1)
   
 
   for url2 in string.gmatch(url1, '"url2":"(http.-)"') do
    
    
      url2 = string.gsub(url2, 'media', 'm')
         t['view'] = 'simple'
table.insert(t, {title = tolazy(title), mrl = url2})

    end
end
end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=krasviews&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


 
 
 
 
  --http://93.183.95.219:11378
 
  elseif args.q == 'kinogo' then
 
 local x = conn:load('https://evkh.lol/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
-- table.insert(t, {title = 'https://lamp-movie.ru/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lamp-movie.ru/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
 
    for url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"http.-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
  
  
      
      
 -- url = string.gsub(url, '\\u0026', '&')
     url = string.gsub(url, '\\u002B', '+')
  
            url = string.gsub(url, '^(.-)', 'https://evkh.lol') 
     


      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total), mrl = url})

       
    end
 --   end
 
 
 
 for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
      --  url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    

      local x = conn:load(url2)

  -- x = string.gsub(x, '< img', '')
   --  x = string.gsub(x, '<img', '')
   --  x = string.gsub(x, '">', '')
  
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do
         
  
         url3 = string.gsub(url3, '\\u0026', '&')
 
     -- url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
    
       
    
     local x = conn:load(url3)
     
    -- x = string.gsub(x, '<img', '')
  --   x = string.gsub(x, '">', '')
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
  
            url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end
 
 
 elseif args.q == 'veo' then

    local x = conn:load('https://api.rstprgapipt.com/balancer-api/iframe?kp=' .. args.id3 .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI')
 
  
 
   for id in string.gmatch(x, 'MOVIE_ID=(.-);') do
 


 local x = conn:load('https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI')
 
-- https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=14981&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI
 
 local slist = string.match(x, '"order":0.-"season".-"order":0(.-)}]}]')
 
 if slist then
 
 for url1, title in string.gmatch(slist, '"filepath":"(http.-)".-"title":"(.-)"') do
 
 t['view'] = 'simple'

   table.insert(t, {title = '(1080p)' .. title, mrl = url1})
end
end


 
 
 
 for total, total1, url1, title in string.gmatch(x, '"order":(.-),"season":.-"order":(.-)}.-"filepath":"(http.-)".-"title":"(.-)"') do
 
 --if total > 0 then
 
 t['view'] = 'simple'

 --= string.gsub(x, '0 сезон 0 серия', '')


   table.insert(t, {title = total1 .. ' ' .. 'сезон ' .. total .. ' серия ' .. title, mrl = url1})
-- end
 end

end
 
 
 
 
 elseif args.q == 'videoseed' then

--https://kinoserials.online/get_cdn/movies/797215e9ad2b02f0e81cb34221cc1d56c4d94398/1080.mp4:hls:manifest-v1-a4.m3u8

--https://kinoserials.online/get_cdn/movies/797215e9ad2b02f0e81cb34221cc1d56c4d94398/hls-v1-a4.m3u8

    
      local x = conn:load('https://api.videoseed.tv/apiv2.php?item=movie&token=fbdcf2438c4f9f0ed76121801807891a&kp=' .. args.id3)
 
 
    for url in string.gmatch(x, 'status.-"iframe":"(http.-)"') do
   
   url = string.gsub(url, '\\', '')
 
-- table.insert(t, {title = url, mrl = url})
 
 
     local x = conn:load(url)
 
    local x = string.match(x, '"file":"#2(.-)"') 
 
 x = string.gsub(x, '|||', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

--http.urlencode(
    x =http.urldecode(base64_decode(x))

--if url then

   for total, url1 in string.gmatch(x, '{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end



end

    
      local x = conn:load('https://api.videoseed.tv/apiv2.php?item=serial&token=fbdcf2438c4f9f0ed76121801807891a&kp=' .. args.id3)

--table.insert(t, {title = 'https://api.videoseed.tv/apiv2.php?item=serial&token=fbdcf2438c4f9f0ed76121801807891a&kp=' .. args.id3, mrl = 'https://api.videoseed.tv/apiv2.php?item=serial&token=fbdcf2438c4f9f0ed76121801807891a&kp=' .. args.id3})
 
for url in string.gmatch(x, 'status.-"iframe":"(http.-)"') do
   
   url = string.gsub(url, '\\', '')
 
 --table.insert(t, {title = url, mrl = url})
 
 
     local x = conn:load(url)
 
    local x = string.match(x, '"file".-"#2(.-)"') 
 
 x = string.gsub(x, '|||', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

--http.urlencode(
    x =http.urldecode(base64_decode(x))

--if url then


for total in string.gmatch(x, '{"title": "(.-сезон)"') do


 --local slist = string.match(x, 'сезон(.-)')
 

  local slist = string.match(x, '"file".-"(.-)"')
if slist then
 
for total1 in string.gmatch(x, '{"title":"(.-серия)"') do

   for total2, url1 in string.gmatch(slist, '{(.-)}.-(http.-m3u8)') do
   
 t['view'] = 'simple'

 -- table.insert(t, {title = x, mrl = x})


--table.insert(t, {title = total2, mrl = url1})


table.insert(t, {title = tolazy(total) .. total1 .. ' ' .. total2, mrl = url1})

end
end
end
end
end
    elseif args.q == 'xkino' then
    
    
      local x = conn:load('https://xkino.net/stars.php?name=' .. urlencode(args.id4))
  
  t['view'] = 'simple'

      
      for url, image, title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<br.->(.-)</a>') do
 
      
  --   https://xkino.net/12806-zaslanec-iz-kosmosa-(4-sezon).html 
      
      
    url = string.gsub(url, '^(.-)', 'https://xkino.net/')

image = string.gsub(image, '/posters/mini/', '')

image = string.gsub(image, '^(.-)', 'https://img.xkino.net/')


  
   table.insert(t, {title = tolazy(title), mrl = '#stream/q=xkinos&id=' .. url})

     end 
  
  
  elseif args.q == 'xkinos' then
    
    
      local x = conn:load(args.id)
  
  
  local slist = string.match(x, 'new Playerjs.-file(.-)poster')

if slist then


for  total, url2, url3 in string.gmatch(slist, '%[(.-)](http.-/mp4/)(.-mp4)') do
  
t['view'] = 'simple'

    table.insert(t, {title = tolazy(total), mrl = url2 .. url3})

     end 
  end
  
  
  
    for url4, url5 in string.gmatch(x, 'Playerjs.-file:"(http.-txt?)(.-)"') do
  
     local x = conn:load(url4 .. url5)
  
  
for total3 in string.gmatch(x, '"title":"(.-)"') do
  
  local slist = string.match(x, 'file(.-)}')

    if slist then


for  total4, url6 in string.gmatch(slist, '%[(.-)](http.-mp4)') do
  
t['view'] = 'simple'
  
  table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url6})

     end 
  end
  end
  end
  
  
  
  
    elseif args.q == 'zetflix' then
    
    
      local x = conn:load('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. args.id3)
   
   for  total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-hidxlglk.-class="videos__item%-title">(.-)</div>') do
  
  
     local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-m3u8)"') do
      
      url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')

      
      
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
        for url2, url3, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-zetflix)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = http.getz(url2 .. url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = http.getz(url4)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
      t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end



elseif args.q == 'getstv' then
    
   
--https://evkh.lol
--http://z01.online/lite/getstv?kinopoisk_id=386&title=Чужой&year=1979
    
      local x = conn:load('https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
     url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

     local x = conn:load(url1)
   
 

 
     local slist = string.match(x, 'quality(.-)}')
      
if slist then

   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

    total1 = string.gsub(total1, ',"', '') 
total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

      end 
    end

    end
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-"stream".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end

    
    
elseif args.q == 'mirage1' then
    

   
local x = conn:load('https://evkh.lol/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do

url4 = string.gsub(url4, '\\u0026', '&')
url4 = string.gsub(url4, '\\u002B', '+')



      url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do


url5 = string.gsub(url5, '\\u0026', '&')
url5 = string.gsub(url5, '\\u002B', '+')

      url5 = string.gsub(url5, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
    

     
    elseif args.q == 'mirage' then
    
    
  --  https://lam.maxvol.pro/lite/mirage?kinopoisk_id=386&title=чужой&year=1979
    
     local x = conn:load('https://lam.maxvol.pro/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



  -- x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

      t['view'] = 'simple'


    table.insert(t, {title = total, mrl = url})

 
    end
    
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
     

  --  http://z01.online/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025 
     
    elseif args.q == 'cdnvideohub' then
    
  local x = conn:load('https://lam.maxvol.pro/lite/cdnvideohub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)





for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url = string.gsub(url, '\\u0026', '&')
   url = string.gsub(url, '\\u002B', '+')
  
  local x = conn:load(url)
  
  
  for  url1 in string.gmatch(x, '"method":"play","url":".-(/proxy.-)"') do
  
  url1 = string.gsub(url1, '\\u0026', '&')
  url1 = string.gsub(url1, '\\u002B', '+')
  
  
url1 = string.gsub(url1, '^(.-)', 'https://lam.maxvol.pro')


t['view'] = 'simple'

  table.insert(t, {title = total, mrl = url1})

end
end
  
  
  for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')
    url5 = string.gsub(url5, '\\u002B', '+')
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end


  
    
  elseif args.q == 'alloha' then
 
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=' .. args.id3 .. '&box_mac=acace24b8434')

    
    
  
    --   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, id1, id2, id3, id4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA.-&stream=(.-)&season=(.-)&translate=(.-)&ta=(.-)]]') do
  
  
  t['view'] = 'simple'
  
    
    table.insert(t,{title= tolazy(total) .. ' ' .. tolazy(total1),mrl = '#stream/q=allohas&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
    
    end
    end

    

    

local x = conn:load('https://evkh.lol/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do

      url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
    
    url4 = string.gsub(url4, '\\u0026', '&')
   url4 = string.gsub(url4, '\\u002B', '+')
  
    
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do

    url5 = string.gsub(url5, '\\u0026', '&')
   url5 = string.gsub(url5, '\\u002B', '+')
   url5 = string.gsub(url5, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end



elseif args.q == 'allohas' then
    
    
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&stream=' .. args.id1 .. '&season=' .. args.id2 .. '&translate=' .. args.id3 .. '&ta=' .. args.id4 .. '&box_mac=acace24b8434')
  
  

  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
    t['view'] = 'simple'
				table.insert(t,{title= tolazy(total3) .. ' ' .. (total2),mrl = url5})
			end
          end
    

    
    elseif args.q == 'cdnmovies' then
      
      local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?kinopoisk_id=' .. args.id3)


 local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630')
    
    

      local x = conn:load(url2)

     
      for id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-&kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=cdnmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})
  
  
  end
  end


 
     elseif args.q == 'cdnmoviess' then
 
 
     local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?' .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end





--https://lamp-movie.ru
    
    elseif args.q == 'vdbmovies' then
      
      local x = conn:load('https://lam.maxvol.pro/lite/vdbmovies?kinopoisk_id=' .. args.id3)


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    
    

      local x = conn:load(url2)

     
      for id4, id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"(http.-)&.-kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=vdbmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
  
  
  end
  end


 
     elseif args.q == 'vdbmoviess' then
 
 
     local x = conn:load(args.id4 .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end




    elseif args.q == 'hdvb' then
      
      local x = conn:load('http://178.20.46.40:12600/lite/hdvb?kinopoisk_id=' .. args.id3)
      
      for  url, total2 in string.gmatch(x, '"method":"call".-"url":"http.-(/lite.-)".-class="videos__item%-title">(.-)</div>') do
  
      url = string.gsub(url, '\\u0026', '&')
   url = string.gsub(url, '\\u002B', '+')


      local x = conn:load('http://178.20.46.40:12600' .. url)

    for  url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do
 
 
 --https://cdn-400.fotpro135alto.com/stream2/cdn-400/f9522e399333a8b96e6d76b6e57ddace/MJTMsp1RshGTygnMNRUR2N2MSlnWXZEdMNDZzQWe5MDZzMmdZJTO1R2RWVHZDljekhkSsl1VwYnWtx2cihVT290VStWWyYUbZpWVxoVbVpnT6lENOpWUx4ERRNzTEtWNPRlRtpFVrFTTEVUP:1768243115:185.228.133.239:7a925e945c08c1c081924669c581c8f04f15477797657d0e9b7057e51eebf17d:ru/1080/index.m3u8
    
    url2 = string.gsub(url2, '/index.m3u8', '/360/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '360p ' .. tolazy(total2), mrl = url2})

end


for  url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url2 = string.gsub(url2, '/index.m3u8', '/480/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '480p ' .. tolazy(total2), mrl = url2})
end


for  url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url2 = string.gsub(url2, '/index.m3u8', '/720/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '720p ' .. tolazy(total2), mrl = url2})
end

    for  url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url2 = string.gsub(url2, '/index.m3u8', '/1080/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '1080p ' .. tolazy(total2), mrl = url2})

      end 
   
      end
      

      
 
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url2 = string.gsub(url2, '\\u0026', '&')
url2 = string.gsub(url2, '\\u002B', '+')


     local x = conn:load('http://178.20.46.40:12600' .. url2)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     
     local x = conn:load('http://178.20.46.40:12600' .. url4)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"http.-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do




     url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = 'http://178.20.46.40:12600' .. url6})
    end
end
end



--http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=386&box_mac=acace24b8434

--http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=search&search=чужой+1979&box_mac=acace24b8434

--http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&content=aHR0cHM6Ly92aWQxNzU5NjU0ODA0LmZvdHBybzEzNWFsdG8uY29tL21vdmllLy9pZnJhbWU=&userdata=1&kp=386&box_mac=acace24b8434




elseif args.q == 'hdvbf' then

    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	




      for title, url, id in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"(http.-)".-"translator_id":(.-),') do


 
      url = string.gsub(url, '\\', '')

--http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=https://vid1766135200.fotpro135alto.com/serial/56e881da922e06b2a74d84e242afcf65f05f4fe9f090bfa4e5a1a82d2b3e48d8/iframe&translate=Дубляж Ultradox&translator_id=218



url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. '&translator_id=' .. id
       --.. '&play=1'

    --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
--	end
       local x = conn:load(url)


         for url2 in string.gmatch(x, '"parser":"(http.-)"') do 
         
        url2 = string.gsub(url2, '\\', '')



      local x = conn:load(url2)

         for total, url3 in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')

url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

t['view'] = 'simple'
       table.insert(t, {title = total .. ' ' .. title, mrl = url3})

       end
       
         for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	


   t['view'] = 'simple'
   
       table.insert(t, {title = total .. ' ' .. title, mrl = url3})

       end
        for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480', '720')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

t['view'] = 'simple'

       table.insert(t, {title = '720p' .. ' ' .. title, mrl = url3})

       end
       
      for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480', '1080')
     
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	
     
 t['view'] = 'simple'
 
       table.insert(t, {title = '1080p' .. ' ' .. title, mrl = url3})

       end
       end
       end
     
     
     
     local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
     
     
     x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	


     
     
     
     
     for title, url, id in string.gmatch(x, '"translator":"(.-)".-"type":"serial".-"iframe_url":"(http.-)".-"translator_id":(.-),') do
     
     
     url = string.gsub(url, '\\', '')



url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. '&translate=' .. urldecode(title) .. '&translator_id=' .. id
     
     
     local x = conn:load(url)

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	


         for title1, title2, id1, id2, id3, id4, id5, id6, id7 in string.gmatch(x, '"information":"(.-)<br>(.-)".-"parser":"http.-?id=file&u=(.-)&v=(.-)&key=(.-)&.-&href=(.-)&ep=(.-)&season=(.-)&fid=(.-)"') do 
         
       -- url2 = string.gsub(url2, '\\', '')
title2 = string.gsub(title2, '<br>', ' ')
 
 t['view'] = 'simple'
 
 
     table.insert(t, {title = title1 .. ' ' .. title2, mrl = '#stream/q=hdvbs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. id6 .. '&id7=' .. id7 .. '&id8=' .. title1 .. '&id9=' .. title2})
     
     end
     end
     
     
     elseif args.q == 'hdvbs' then
     
     
      local x = conn:load('http://fxmlparsers.in.net/VilkaDB/?id=file&u=' .. args.id1 .. '&v=' .. args.id2 .. '&key=' ..args.id3 .. '&tid=&href=' .. args.id4 .. '&ep=' .. args.id5 .. '&season=' .. args.id6 .. '&fid=' .. args.id7)





         for total, url3 in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

t['view'] = 'simple'
       table.insert(t, {title = total .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})

       end
       
         for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')

url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

   t['view'] = 'simple'
   
       table.insert(t, {title = total .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})


       end
        for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480', '720')

url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

t['view'] = 'simple'

       table.insert(t, {title = '720p' .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})


       end
       
      for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480', '1080')
     
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	
     
 t['view'] = 'simple'
 
       table.insert(t, {title = '1080p ' .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})


       end
       




elseif args.q == 'hdvb2' then

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=' .. args.id3 .. '&box_mac=acace24b8434')

--url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
   --   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end

--http://lam.maxvol.pro
--http://178.20.46.40:12600
 --   https://lampa.freepad.netcraze.club
    
    elseif args.q == 'videodb' then
    
    local x = conn:load('https://lamp-movie.ru/lite/videodb?kinopoisk_id=' .. args.id3)
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(http.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
   --  url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
    -- url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

    --  url3 = string.gsub(url3, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(http.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
   -- url4 = string.gsub(url4, '^(.-)', 'http://lam.maxvol.pro')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end


   elseif args.q == 'videocdn' then
 
 
-- https://lampa.ip917.ru/lite/lumex/video.m3u8?playlist=%2fvalidate%2fU2FsdGVkX1-HWJXR-68d4L5FZ5G8XZbankXomi3bA2NSRN28LPBPtpORtthxOnUsx0Lg3KqSB6Kfg3EJql4hhh7YMO-Pp2SLx9TnO-tBp5myBFbjXKKEuKfrYZ2wVwdb45iSZaB5Cok7fK_Cb4QprlmNkOfV5hLruFWpJtTVIuGIf3Dk65SDRFcyJOHKPXleu07ieysuHAkAZEDcjDZUECF4FIdxBkqkYwP6CPUt4x8&csrf=636ebee3ad5caa58ecd60717b4c38dc7&max_quality=1080&uid=2hlekqiu   
--https://lamp-movie.ru
--http://lam.maxvol.pro
--http://89.110.96.198:12267/lite/lumex?kinopoisk_id=386
    
 --   http://z01.online/lite/vdbmovies?kinopoisk_id=386
    
 --   http://z01.online/lite/lumex?kinopoisk_id=386
    
   local x = conn:load('https://lam.maxvol.pro/lite/lumex?kinopoisk_id=' .. args.id3) 
   
   --.. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3, mrl = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":.-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
      url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

  --   local x = conn:load(url1)
   
 

 
 --    local slist = string.match(x, 'quality(.-)}')
      
--if slist then

--   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

  --  total1 = string.gsub(total1, ',"', '') 
--total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url1})

      end 
--    end

  --  end
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end


   
--https://lam.akter-black.com/lite/lumex/video.m3u8?playlist=%2fvalidate%2fU2FsdGVkX19kA03qeE272aRpz8lQQE0fY5HEvl7F_RO3nkcUKj7v6wo5c5mdN-R3joZk7xxFg5V30e28XLnqhas-xz9_SX4_Oz6DvDXYynpAtkrw0bbgbOZz2efTjB5KQAm_lSMoe75qzJx3dy4BBUU5RC46eKig0FzmYCTf6-vlwt6S3kaZwk1ITyD0npzM4spY-7Ru7MiYWUkVVLS6SNhnqklDVNaUt5x2DueCeiot0fYrasgtFvP4DeDuwbB3BPyfKGskaP85ea7cZes4Qw&csrf=5a94042588868cf1acf1bc4ff0cae444&max_quality=1080&uid=jvxp6m4u
   
   
elseif args.q == 'lumex' then
    
  --  http://lam.maxvol.pro
 --   http://178.20.46.40:12600

--http://lam.maxvol.pro/lite/lumex?kinopoisk_id=4910542

   local x = conn:load('https://lam.maxvol.pro/lite/lumex?kinopoisk_id=' .. args.id3)
   -- https://lam.akter-black.com
    
   --  local x = conn:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
--  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

 --  table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p) ' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
 
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
      
url3 = string.gsub(url3, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p) '.. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '480.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p) ' .. tolazy(total), mrl = url3})
       
    end
    
   local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '360/index')
      url3 = string.gsub(url3, '360.mp4', '360.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '360.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(360p) ' .. tolazy(total), mrl = url3})
       
    end 
    
local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '240/index')
      url3 = string.gsub(url3, '360.mp4', '240.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '240.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(240p) ' .. tolazy(total), mrl = url3})
       
    end
    
    
    
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
       --   url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end
  end
  
  

 elseif args.q == 'lumexs' then
    
     local x = conn:load('https://lam.maxvol.pro/lite/lumex?content_id=' .. args.id1 .. '&kinopoisk_id=' .. args.id2 .. '&clarification=' .. args.id3 .. '&s=' .. args.id4 .. '&t=' .. args.id5)



for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = 'Сезон ' .. args.id4 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end






      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
 
 
 
 local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '1080/index')
      url5 = string.gsub(url5, '360.mp4', '1080.mp4')
      
     url5 = string.gsub(url5, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8') 
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(1080p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
 

     local x = conn:load(url4)
  
  for url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
  
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(720p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
   
   local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '480/index')
      url5 = string.gsub(url5, '360.mp4', '480.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '480.mp4:hls:manifest.m3u8')
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(480p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
  
end


    

   elseif args.q == 'kino4k' then

local x = conn:load('https://evkh.lol/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

x = string.gsub(x, ' or', '"')




local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then

    
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
    
    --     for  total3, url4, total2 in string.gmatch(x, '"(.-p)":"http.-mp4.-(http.-mp4).-class="videos__item%-title">(.-)<') do
-- total3 = string.gsub(total3, ',"', '')
 --   t['view'] = 'simple'
--    table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
    
--end
-- end


    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

x = string.gsub(x, ' or', '"')


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
 
    
    if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
   
  if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
   
end
end
--end


   elseif args.q == 'filmix' then

local x = conn:load('https://lamp-movie.ru/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 

    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
   if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
    
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do


       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end

    
end
end



elseif args.q == 'kinofit' then

local x = conn:load('http://z01.online/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2)

for id in string.gmatch(x,'<div class="videos__line".-"method":"link".-"url":"http.-postid=(.-)\\u0026') do


id = string.gsub(id, '^(.-)', 'item/')
         
         id=base64_encode(id)
 

 
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')


     
     
     for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = (total1) .. ' ' .. tolazy(total), mrl = url2})
    
        end
        end
        
  
      




     local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')



      for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
  
       total = string.gsub(total, '<!%[CDATA%[', '')
       total = string.gsub(total, ']]>', '')
       
     local x = conn:load(url1 .. '&box_mac=acace24b8434')

    
    for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-сезон).-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
       total1 = string.gsub(total1, ']]> <![CDATA[', '')
       total1 = string.gsub(total1, ']]>', '')
   
        local x = conn:load(url2 .. '&box_mac=acace24b8434')
   

     
     for total2, total3, url3 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<playlist_url><!%[CDATA%[http.-&goto=(.-)&.-]]') do
    
 --     total2 = string.gsub(total2, '<!%[CDATA%[', '')
   --   total2 = string.gsub(total2, ']]>', '')
 
 
 t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total2) .. ' ' .. tolazy(total), mrl = '#stream/q=kinofits&id=' .. url3})
 
 end
 end
 end
 end
 
 
 elseif args.q == 'kinofits' then

local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. args.id .. '&viewseason' .. '&box_mac=acace24b8434')
 
 
      
  --    local x = conn:load(url3 .. '&box_mac=acace24b8434')
 
     
     
     for total4, url4 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]].-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do
    
       total4 = string.gsub(total4, '<!%[CDATA%[', '')
      total4 = string.gsub(total4, ']]>', '')
    
    
    
      t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total4), mrl = url4})
    
        end
      





     elseif args.q == 'hdrezka' then

  --http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=чужой:+земля-2025&box_mac=acace24b8434


   
      local x = conn:load(args.id)


          for id, title in string.gmatch(x,'data%-translator_id.-href="(.-)">(.-)</a>') do
     t['view'] = 'simple'
  
  

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title =tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
         
         
for title1, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=.-&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=rezkis&id=' .. args.id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
        
end
 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end

    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    
elseif args.q == 'rezkis' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end

elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end






     elseif args.q == 'rezka' then

local x = conn:load('https://evkh.lol/lite/rhsprem?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)


for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do


url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')
    
       t['view'] = 'simple'

table.insert(t, {title = '(1080p) ' .. total, mrl = url})

     end  
	
		local x = conn:load('https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
 -- table.insert(t, {title = 'https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lampa.persh1n.ru/lite/rezka?title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
  
       
    local slist = string.match(x, '"quality"(.-)}')
      
     if slist then
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"http.-(/proxy.-m3u8)"') do
  
      url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
     end
  
  
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
       t['view'] = 'simple'
   
      local x = conn:load(url2)

  local slist = string.match(x, '"quality"(.-)}')
      
      
   
   for  total1, url3 in string.gmatch(slist, '"(.-p)":"http.-(/proxy.-m3u8)"') do
  
      url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')' .. total, mrl = url3})

     end  
 end
     




   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      



      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rez' then

   local x = conn:load('https://lampa.persh1n.ru/lite/rezka/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
  
--https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=4760854&title=%D0%9A%D0%BE%D1%80%D0%BE%D0%BB%D1%8C+%D0%A2%D0%B0%D0%BB%D1%81%D1%8B&year=2025&serial=1

    elseif args.q == 'kinobase' then

--https://lampa.persh1n.ru/lite/rezka?kinopoisk_id=386&title=чужой&year=1979
   
   
		local x = conn:load('https://lampa.persh1n.ru/lite/kinobase?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&t=&s=1')
     
  
  
  
   --    for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
   --   local x = conn:load(url)

      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
     t['view'] = 'simple'

url2 = string.gsub(url2, '\\u002B', '+')

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2})
    end
     end  
  --  end

--https://lampa.persh1n.ru/lite/kinobase?title=%d0%b1%d1%83%d0%bc%d0%b0%d0%b6%d0%bd%d1%8b%d0%b9+%d0%b4%d0%be%d0%bc&year=2017&s=1
  
     for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
      local x = conn:load(url)
   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
    
       
    
      local x = conn:load(url2)

      
       

      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
    
url3 = string.gsub(url3, '\\u002B', '+')

    
         
    url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
    
       t['view'] = 'simple'



    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3})

    end   
    end
    end
   





   elseif args.q == 'kinotop' then

--url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=search&search=') .. '+' .. total

	--	table.insert(t, {title = url, mrl = url})
   
   
local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=search&search=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&box_mac=acace24b8434')
   
   
    --  local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')
 
--http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=watch&media=L2ZpbG0vMjM0MzM4LWJ5dC1sdWNoc2hlLWlzdG9yaXlhLXJvYmJpLXVpbHlhbXNh&box_mac=acace24b8434



       for url1  in string.gmatch(x, '<title><!%[CDATA%[.-]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do

 
       
 
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
    
     for total1, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-.mp4)]]') do
    
    
     t['view'] = 'simple'
      table.insert(t, {title = total1, mrl = url2})

       end
     end
   --  end



for url1  in string.gmatch(x, '<title><!%[CDATA%[.-]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do

 
       
 
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-сезон)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
        local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
    
 
  
     for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-.mp4)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = total2 .. (total3) .. (total4), mrl = url3})

end
       end
      end
      
      

elseif args.q == 'jac' then

    

   local x = conn:load('https://lam.akter-black.com/lite/jac?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
   
       t['view'] = 'simple'
    table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     
     


		local x = conn:load('https://lam.akter-black.com/lite/jac?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
  
  
  
  
  
       t['view'] = 'simple'
     table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     



     
     
     
     elseif args.q == 'result' then
      args.id = args.id:lower() 
      
      local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end
   
   
   
    elseif args.q == 'pidtor' then
  
  
  local x = conn:load('https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
  

      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-?tr=).-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
  local x = conn:load('https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
  


--https://lam.akter-black.com/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=






for url2, title in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')

      local x = conn:load(url2)
    

    
      for url3, total  in string.gmatch(x, '"method":"link".-"url":"http.-/lite/pidtor/serial/(.-)?tr=.-class="videos__item%-title videos__season%-title">(.-)</div>') do


--url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')

     url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'
     table.insert(t, {title = title .. ' ' ..  total,mrl = '#stream/q=result&id=' .. url3,image = image})
     end
     
   end
 
 
 
 elseif args.q == 'torrs' then

local x = conn:load('http://torrs.ru/search?query=' .. urlencode(args.id1) .. '(' .. args.id2 .. ')')
   
 --  table.insert(t, {title = 'http://torrs.ru/search?query=' .. urldecode(args.id) .. '(' .. args.id1 .. ')', mrl = '#stream/q=result&id=' .. 'http://torrs.ru/search?query=' .. urldecode(args.id) .. '(' .. args.id1 .. ')', image = image})
   
	--	local x = conn:load(url)
		x = string.gsub(x, '",', '\\u0026')	
    --    x = string.gsub(x, '&', '\\u0026')	
		
    for title, total in string.gmatch(x,'"size".-"title":"(.-)\\u0026.-"magnet":"magnet:?.-btih:(.-)\\u0026') do
      
--title = string.gsub(title, '\\u0026','&')
     -- total = string.gsub(total, '\\u0026','&')
   t['view'] = 'simple'
   
   table.insert(t, {title = title, mrl = '#stream/q=results&id=' .. total, image = image})
		end


elseif args.q == 'results' then
		
      args.id = args.id:lower() 

local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      
      --	 https://lam.akter-black.com/lite/pidtor/serial/7d2dd45792a2695ff0cc88cde4af51cd5189dfb4?tr=	
--https://lam.akter-black.com/lite/jac?serial=1&title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%20%D0%B7%D0%B5%D0%BC%D0%BB%D1%8F


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   end
 
 
       

elseif args.q == 'anwap' then
  
  
--https://tv.anwap.today/films/search/?toch=on&slv=чужой-Alien&vid=1
  
  
--  local x = conn:load('https://tv.anwap.today/films/search/?slv=' .. urlencode(args.id1) .. '&vid=' .. args.id5 .. '&toch=' .. args.id6)
  
  local x = conn:load('https://tv.anwap.today/films/search/?toch=on' .. '&slv=' .. urlencode(args.id1) .. '&vid=1')

  
local slist=string.match(x, '</form><div class="save">По.-id="cn"(.-)"menuniz"')
  

  if slist then
    for url, title in string.gmatch(slist, '<div class="my_razdel film".-<a href="(.-)".-alt="(.-)"') do

     local x = conn:load('https://tv.anwap.today' .. url)

    local slist=string.match(x, '<ul class="tl2">(.-)</ul>')


		if slist then
			for url1, title2 in string.gmatch(slist, '<a href="(/films/load.-)">Скачать MP4(.-)<.-</a>') do
       print(url)
	   	url1 = string.gsub(url1, '^(.-)', 'https://tv.anwap.today')
   
      t['view'] = 'simple'
        table.insert(t, {title = title2 .. tolazy(title), mrl = url1})
	
		end
		end
		end
		end
  
  
--https://tv.anwap.today/films/search/?slv=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&alien&vid=1&toch=on
--https://tv.anwap.today/serials/search/?word=%D1%87%D1%83%D0%B6%D0%BE%D0%B9-alien&vid=1&t=on

local x = conn:load('https://tv.anwap.today/serials/search/?t=on' .. '&word=' .. urlencode(args.id1) .. '&vid=1') 

--local x = conn:load('https://tv.anwap.today/serials/search/?word=' .. urlencode(args.id1) .. '-' .. urlencode(args.id4) .. '&vid=' .. args.id5 .. '&toch=' .. args.id6)




   local slist=string.match(x, '</form><div class="save">По.-id="cn"(.-)"menuniz"')

	if slist then

       for url, title in string.gmatch(slist, '<div class="my_razdel film".-<a href="(.-)".-alt="(.-)"') do

    
    local x = conn:load('https://tv.anwap.today' .. url)

       local slist=string.match(x, '<ul class="tl2">(.-)"popular"')


		if slist then
			for url1, title1 in string.gmatch(slist, '<li><a href="(/serials/s.-)">(.-)</a></li>') do
       
       t['view'] = 'simple'
      
       table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=sezon&id=' .. url1})
        
        end
		end
		end	
end


elseif args.q == 'sezon' then

local page = tonumber(args.page or 1)
    
    local x = conn:load('https://tv.anwap.today' .. args.id .. '-' .. tostring(page))
		

      -- local slist=string.match(x, '<ul class="tl">(.-)</ul>')


	--	if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/down.-)">(.-)</a>') do
       print(url)
	  -- 	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=sezond&id=' .. url})
		end 
	
	
			
	local url = '#stream/page=' .. tostring(page + 1) .. '&q=sezon&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


  
    elseif args.q == 'sezond' then
  
   local x = conn:load('https://tv.anwap.today' .. args.id)
  
  
  
  local slist=string.match(x, 'tlsiconkoi.-<ul class="tlsiconkoi">(.-)</ul>')


		if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/load.-)".-Скачать(.-)<span') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = 'Смотреть' .. tolazy(title), mrl = url})
	
		end
		end	







elseif args.q == 'collaps' then
  
  
  local x = conn:load('http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=' .. args.id3)

for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})


       
    end

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end


elseif args.q == 'collaps-dash' then
  
 

  local x = conn:load('http://178.20.46.40:12600/lite/collaps-dash?kinopoisk_id=' .. args.id3)



   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end


elseif args.q == 'kinotochka' then
  
 

  

local x = conn:load('http://178.20.46.40:12600/lite/kinotochka?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(По умолчанию)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end

    
     local x = conn:load('http://178.20.46.40:12600/lite/kinotochka?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie..-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end

--https://kinovibe.vip/embed/8003




elseif args.q == 'vibix' then
  
  
  
--  https://reyohoho-old.onrender.com/#386
  
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  
 -- for url in string.gmatch(x, '(<option player.-</option>)') do
  
  
 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed/.-)"') do
 
 
 
 --https://672431256.videoframe2.com/api/v1/embed-serials/5523?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com/embed-serials/5523
  
--https://672431256.videoframe2.com/api/v1/embed/215500?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com/embed/215500 
 
 local x = conn:load('https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url)
 
 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slis = string.gsub(slist, ',', '"')
 slist = string.gsub(slist, ';', '"')
 
for total, title, url in string.gmatch(slist, '%[(480p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
	
t['view'] = 'simple'
 
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 
 
for total, title, url in string.gmatch(slist, '%[(720p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"%{.-}http.-"({.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 


for total, title, url in string.gmatch(slist, '%[(1080p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end

end
    end
  
  
  
  
  
  
  
   
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  

 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed%-serials.-)"') do
 

 local x = conn:load('https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url)
  
 -- table.insert(t, {title = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url, mrl = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url})
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slist = string.gsub(slist, ',', '"')
-- slist = string.gsub(slist, ';', '"')
slist = string.gsub(slist, ']{', '"name":')
slist = string.gsub(slist, ';{', '"name1":')

-- for total1 in string.gmatch(slist, '"title":"(Сезон.-)"') do
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
    end
  end


--http://178.20.46.40:12600

--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979

--https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=386

elseif args.q == 'veoveo' then
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
   
--table.insert(t, {title = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1), mrl = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1)})
      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'veoveo :' .. tolazy(total), mrl = url2})

       
    end
     
--  local x = conn:load('http://178.20.46.40:12600/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
 
 

 
 
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do
     
   --  url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600') 
     
     
     local x = conn:load(url2)

--table.insert(t, {title = url2, mrl = url2})

for  url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total4), mrl = url3})

      end 
      end


elseif args.q == 'kinopub' then
  
  
--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979
 --   https://mylam.ru/lite/remuc?kinopoisk_id=386&title=чужой&year=1979

  local x = conn:load('https://lamp-movie.ru/lite/kinopub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
  

      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end
  
  
  
  
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)

   
   for  url3, total3 in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
   
     t['view'] = 'simple'

   table.insert(t, {title = tolazy(total2) .. ' ' .. total3, mrl = url3})

       
    end
end
   


     
     local x = conn:load('http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=' .. urlencode(args.id1) .. '+' .. args.id2 .. '+')
  


     for url2 in string.gmatch(x, '<playlist_name>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn:load(url2)
    


    
    for total, url3, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA(.-)]>.-<playlist_url><!%[CDATA%[(http.-namee=).-(&perewod.-)]]></playlist_url>') do
	
	    local x = conn:load(url3 .. url4)
	   
	   
	     for total1, url5 in string.gmatch(x, '<channel.-<title>.-(1080)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end

for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(720)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end

for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(480)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end


for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(360)]]>.-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. tolazy(total), mrl = url5, image = image})
     end

     end
	    end




local x = conn:load('https://lampa.inick22.ru/lite/kinopub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  

 -- http://online7.skaz.tv/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979   
  
  
  for  total in string.gmatch(x, '<div class="videos__item videos.-class="videos__item%-title">(.-)</div>') do
  
  local x = string.match(x, '"quality"(.-)"subtitles"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"(http.-)"') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
         --   url2 = string.gsub(url2, '^(.-)', 'https://lampa.inick22.ru') 
     


      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total1) .. ( total), mrl = url2})

       
    end
    end
 
 
 for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)
 
 
    for id, id1, id2, id3, total3 in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"http.-&postid=(.-)&title=(.-)&.-&s=(.-)&t=(.-)&.-".->(.-)</div>') do


   t['view'] = 'simple'

    

table.insert(t, {title = tolazy(total2) .. ' ' .. tolazy(total3), mrl = '#stream/q=kinopubs&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})


      end 
      end

    
    elseif args.q == 'kinopubs' then
   
   local x = conn:load('https://lampa.inick22.ru/lite/kinopub?rjson=False&postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&s=' .. args.id2 .. '&t=' .. args.id3 .. '&codec=aac')
   


    for  total in string.gmatch(x, '<div class="videos__item videos.-class="videos__item%-title">(.-)</div>') do
  
  local x = string.match(x, '"quality"(.-)"subtitles"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"(http.-)"') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
         --   url2 = string.gsub(url2, '^(.-)', 'https://lampa.inick22.ru') 
     


      t['view'] = 'simple'


   table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

       
    end
    end




elseif args.q == 'filmix2' then

    

   local x = conn:load('https://evkh.lol/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
   
   
--for url, total1, image, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-"year":(.-),.-"img":.-(/proxy.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   
--url = string.gsub(url, '\\u0026', '&')
   
  -- image = string.gsub(image, '\\u002B', '+')
   
  -- image = string.gsub(image, '^(.-)', 'https://lamp-movie.ru')
   
  --  table.insert(t, {title = total .. ' ' .. total1, mrl = '#stream/q=filmixx&id=' .. url, image = image})
--end
    
   -- elseif args.q == 'filmixx' then

   --  local x = conn:load(args.id)

  for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"(http.-mp4)') do
 
 total3 = string.gsub(total3, ',"', '')
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
    end
end
 
 
 
   

     
  --   local x = conn:load('http://peppega.ru/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play.-class="videos__item%-title">(.-)</div>') do

   --  url5 = string.gsub(url5, '\\u0026', '&')
   -- url5 = string.gsub(url5, '^(.-)', 'http://peppega.ru')
   
   
     local x = string.match(x, '"quality":{(.-)}')
      for  total4, url5 in string.gmatch(x, '"(.-p)":"(http.-mp4)') do
 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

       
    end
end
end
end

   
   elseif args.q == 'vkmovie' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lam.maxvol.pro/lite/vkmovie?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
     

     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro')
      url4 = string.gsub(url4, '\\u002B', '+')
       t['view'] = 'simple'

   table.insert(t, {title = '(' .. total3 .. ') ' .. tolazy(total2), mrl = url4})
    end
     end  


elseif args.q == 'remux' then


--https://lam.akter-black.com/lite/remux?kinopoisk_id=386&title=чужой&year=1979

		local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



      for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')
      
      

    --   url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
   
   
   
for  url3, total1 in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url3 = string.gsub(url3, '\\u0026', '&')
      url3 = string.gsub(url3, '\\u002B', '+')
      
 
 
 local x = conn:load(url3)
 
       for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url4 = string.gsub(url4, '\\u0026', '&')
      url4 = string.gsub(url4, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url4})

     end  
    end
end

local x = conn:load('https://lam.akter-black.com/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
   
     for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
 
 
 local x = conn:load(url)
 
       for url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total), mrl = url2})

     end  
    end



elseif args.q == 'seasonvar' then
    
   

    
      local x = conn:load('http://seasonvar.ru/?mode=search&query=' .. urlencode(args.id1))
  
  
 -- local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
     --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'http:')
        
        t['view'] = 'simple'
		
			

  
  
  local x = conn:load('http://seasonvar.ru' .. url)
 
 
 local slist = string.match(x, '<ul class="tabs%-result">(.-)</ul>')
      
if slist then

   for url2, total in string.gmatch(slist, '<a href="(.-)".-Сериал (.-)<') do
   
  table.insert(t, {title = tolazy(total), mrl = '#stream/q=seasonvars&id=' .. url2, image = image})
		
		end
end
end



   
   elseif args.q == 'seasonvars' then
   
   local x = conn:load('http://seasonvar.ru' .. args.id)
        
      --  local x = conn:load(url2)
 
 for id1, total1 in string.gmatch(x,'"(/playls2.-)".-data%-translate%-percent=.->(.-)</li>') do
 
 
    --    for id1 in string.gmatch(x,'player = new Playerjs.-var pl.-"(/playls2.-)"') do
            
    local x = conn:load('http://seasonvar.ru' .. id1)
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id2 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id2 = string.gsub(id2, '\\/\\/b2xvbG8=', '') 
      
      id2=http.urldecode(base64_decode(id2))
       id2 = string.gsub(id2, '^(.-)', 'http:') 
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title1) .. ' ' .. total1, mrl = id2})
            end  
	end

    
      
      
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end