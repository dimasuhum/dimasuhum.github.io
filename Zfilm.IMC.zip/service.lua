-- zfilm plugin

require('support')
require('video')
require('parser')
require('client')
--http://jgdsgi1iogojkqogisdg.ua63.fun/v/1314843/

--https://www.zfilm-hd.org/films-00621/
--https://zfilm-hd.org/films-00421/
--HOME = 'https://zfilm-hd.org'
--HOME = 'http://hdd-hd720.zfilm-hd-zerkalo.fun'
--HOME = 'http://newseries.zfilm-hd.site'
--HOME = 'http://hd-720-hd1.zfilm-720.com'
--HOME = 'http://movielib.zfilm-hd.club'
--HOME = 'http://warcinema.zfilm-hd-2755.online'    
--local HOME = 'https://xkino.site'
--HOME = 'http://zfilme-hd1.site'
--local HOME = 'https://one.kinchik.se'

--https://one.kinchik.se/films-030623/

--local HOME = 'http://v70601683.kinomax-film.site'


local HOME = 'https://filmec.pro'
--local HOME_SLASH = HOME .. '/'


local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from zfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from zfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/gente=/muzykalnye_kanaly
	-- #stream/gente=/novostnye_kanaly
	-- #stream/genre=/razvlekatelnyye_kanaly
	-- #stream/genre=/sputnikovye_kanaly
	-- #stream/genre=/f/genre:ужасы

	if not args.q then
		local page = tonumber(args.page or 1)

--https://filmec.pro/films/
         local genre = args.genre or '/hotnews/'
        local genre = args.genre or '/films/'

        
     	local url = HOME .. genre
		if page > 1 then
        
			url = url .. 'page/' .. tostring(page) .. '/'
		end

         if genre == '/f/genre:ужасы' then
        url = HOME .. genre .. '/' .. 'page/' .. tostring(page) .. '/' .. '#dle-content'
		end 

			
	--	local x = http.getz(url)
        local x = conn:load(url)
       -- x = iconv(x, 'windows-1251', 'UTF-8')
       


        for url, image, title in string.gmatch(x, '<a class="poster__link d%-block has%-overlay" href="(.-)".-<img src="(.-)".-class="poster__title line%-clamp">(.-)</b>') do
       
       
      --  for url, image, title in string.gmatch(x, '<a class="poster__link d%-block has%-overlay" href="(http.-html)".-<img data%-src="(//.-)".-class="poster__title line%-clamp">(.-)<') do
        
    --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', HOME)


		  table.insert(t, {title = title, mrl =  '#stream/q=content&id=' .. url, image = image})
		end
    

        for url, image, title in string.gmatch(x, '<div class="podborki%-item grid%-item".-<a href="http.-(/podborki.-)".-<img.-src="(.-jpg)".-class="podborki%-item__title">(.-)<') do
        
      --  url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^(.-)', HOME)


		  table.insert(t, {title = title, mrl =  '#folder/genre=' .. url, image = image})
		end
		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
        table.insert(t, {title = 'ПОДБОРКА', mrl = '#stream/genre=' .. '/podborki-filmov/'})
        
--http://v70601683.kinomax-film.site/podborki-filmov-00223/

--https://filmec.pro/podborki-filmov/
        
        
        table.insert(t, {title = 'Горячие новинки', mrl = '#stream/genre=' .. '/hotnews/'})
     
        
        table.insert(t, {title = 'Самое популярное', mrl = '#stream/genre=' .. '/popular/'})
     
     table.insert(t, {title = 'Сейчас смотрят', mrl = '#stream/genre=' .. '/watched/'})
     
     table.insert(t, {title = 'ТОП-250 КП', mrl = '#stream/genre=' .. '/top250/'})
     
      table.insert(t, {title = 'ТОП-250 IMDb', mrl = '#stream/genre=' .. '/top250imdb/'})
     
     

  
        local x = conn:load(HOME .. '/')

 
      
      local x = string.match(x, '<ul class="nav__menu d%-flex flex%-grow%-1 has%-scroll">(.-)<div class="nav__ext%-menu d%-flex ai%-center"')
        for genre, title in string.gmatch(x, '<a href="(.-)" title="(.-)".-</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end
        


         local x = conn:load(HOME .. '/')
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
      local x = string.match(x, '<ul class="top%-block__left menu%-btns">(.-)</ul>')
        for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. urlencode(genre) .. '/'})
		end


--https://v68629786.irecommend-film.site/search/%D0%A7%D1%83%D0%B6%D0%B8%D0%B5
--https://filmec.pro/search/%D0%A0%D0%BE%D0%BA%D0%BA%D0%B8

    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/' .. urlencode(args.keyword)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<a class="poster__link d%-block has%-overlay" href="(.-)".-<img src="(.-)".-class="poster__title line%-clamp">(.-)</b>') do
        
    --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', HOME)


		  table.insert(t, {title = title, mrl =  '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})






	-- #stream/q=content&id=/35272-koroleva-yuga-900518144.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
          t['ref'] = args.id
	
          --x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1 class="sect__title flex-grow-1">(.-)смотреть онлайн.-</h1>')
		

		t['description'] = parse_match(x, 'class="page__text full%-text.-<br><br>(.-)<br><br>')
			t['poster'] = args.p
--	   t['poster'] = parse_match(x,'<img class="logo%-mobile scale%-with%-grid" src="(.-)"')
	--	if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
	    	t['annotation'] = parse_array(x, {	'(Год:</b>.-)</p>', '(Страна:</b>.-)</p>', '(Жанр:</b>.-)</p>', '(Режиссер:</b>.-)</p>', '(Актеры:</b>.-)</p>'  })
  
 
--http://zagonka1.zagonkom.gb.net/embed/kp-1269654?v=1


        for url in string.gmatch(x, 'class="page__info%-rating".-url=http.-kinopoisk.ru/.-/(.-)"') do
          
    

     url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=') 
         table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

         end

         
         
        for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   

        url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=0&kinopoisk_id=')
        

      local x =  http.getz(url)
       
      
       
       for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(1080p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(720p).-(http.-mp4)') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(480p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(360p).-(http.-mp4)') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end
--end
        
        
          for url1, url2  in string.gmatch(x, 'current_page".-"data":%[{"id":(.-),"kinopoisk_id":(.-),') do
       
	--	url = string.gsub(url2, '^(.-)', 'https://voidboost.net/embed/')
	
	
	
	
        url = string.gsub(url2, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=9&kid=')
       
        local x = http.getz(url)
    --x = string.match(x, '<select name="season".->(.-)</select>')
    
   --     for url, title in string.gmatch(x, '<option value="(.-)".-(Сезон.-)</option>') do


       for title, url3 in string.gmatch(x, '\'title\': \'(Сезон) (.-)\',') do

    --   url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=' .. url1 .. '&kinopoisk_id=' .. url2 .. '&title=&original_title=&s=')
        

         
     local x = http.getz('http://79.137.204.8:9118/lite/zetflix?id=' .. url1 .. '&kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)



       for url, total  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do
       

       t['view'] = 'simple'

       table.insert(t, {title = title .. ' ' .. url3 .. (total), mrl = url})
    
    	end
	end
    end







    
        for url in string.gmatch(x, 'class="page__info%-rating".-url=http.-kinopoisk.ru/.-/(.-)"') do
    
        print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-or (//video.zagonka.org/movies/.-mp4)') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end
      
 
 
 
 
 
 
 
 
       for url in string.gmatch(x, 'class="page__info%-rating".-url=http.-kinopoisk.ru/.-/(.-)"') do
       print(url)
       
    --    url = string.gsub(url, '^(.-)', 'https://videocdn.svetacdn.in/IAF0wWTdNYZm?kp_id=')
        --.. '&domain=kinobd.net'
       
		 url = string.gsub(url, '^(.-)', 'https://videocdn.tv/api/short?api_token=bVycnMuy5Dfe0IkzXt87eeVa9EtIkUl5&kinopoisk_id=')
       
        local x = http.getz(url)
      for  url  in string.gmatch(x, '"iframe_src":"(.-)"') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})

   --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})

		end
   end
    
  

  
  
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(360p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       
       
        for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(480p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
  
      for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(720p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(1080p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
	
		
       for title, url  in string.gmatch(x, 'movie.-%[(360p)].-(cloud-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
     	 for title, url  in string.gmatch(x, 'movie.-%[(480p)].-(cloud.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
	for title, url  in string.gmatch(x, 'movie.-%[(720p)].-(cloud.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
		
        for title, url  in string.gmatch(x, 'movie.-%[(1080p)].-(cloud.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
 
 
 
       
        for url in string.gmatch(x, 'class="page__info%-rating".-url=http.-kinopoisk.ru/.-/(.-)"') do
        
            print(url)
		 url = string.gsub(url, '^(.-)', 'http://divantv.zz.mu/kinomovie/zombie.m3u.php?kp_id=')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
		
        for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end
	
	
--http://hdrezka.vip/ajax/get_cdn_tiles/0/125918/?t=1677352534
--https://voidboost.net/embed/?t=1677352534
		
        for url in string.gmatch(x, '"image":".-img.-/uploads/.-/(.-).jpg"') do
             print(url)
             
			url = string.gsub(url, '^(.-)', 'https://voidboost.net/embed/')
        --   url = string.gsub(url, ')', '')
       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
        local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do

            
          local slist=string.match(x, '<select name="season".->(.-)</select>')
          
           if slist then
          
             for url1, title in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
             

             
            local slist=string.match(x, '<select name="episode".->(.-)</select>')
            
           if slist then
            for url2, total in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do
         

          t['view'] = 'simple'
        	table.insert(t, {title = title .. ':' .. (total) .. ' (' .. total1 .. ')', mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
			end
			end
   	    	end	
   	    	end
            end	
   	    	end
    
    
--https://voidboost.net/movie/149fa08a44c989e65e37289b4c796736/iframe?h=baskino.me

          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
             
             
          t['view'] = 'simple'
        	table.insert(t, {title = total1, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/movie/' .. url3 .. '/iframe?'})
             
            end
            end
    
          
	--		for url1, title in string.gmatch(x, '<option value="(.-)".->(Сезон.-)</option>') do
	--		end
     --     local x = string.match(x, '<select name="episode".->(.-)</select>')
			
     --      for url2, total in string.gmatch(x, '<option value="(.-)".->(Серия.-)</option>') do
	--	   end
            
         
    --      local x = string.match(x, '<select name="translator.->Перевод.->(.-)</div>')
      --      for url3, total1 in string.gmatch(x, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
    
         
         
       -- 	table.insert(t, {title = 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
	--		end

   		
   		
       for url  in string.gmatch(x, 'var CDNplayerConfig.-file.-#2(.-)\'') do
     --    print(url)
		 url = string.gsub(url, '//_//', '')
         url = string.gsub(url, 'Xl4jQEAhIUAjISQ=', '')
         url = string.gsub(url, 'JCQkIyMjIyEhISEhISE=', '')
         url = string.gsub(url, 'QCFeXiFAI0BAJCQkJCQ=', '')
         




         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, url in string.gmatch(url, '(360p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if url then
			for title, url in string.gmatch(url, '(480p).-(http.-.mp4)') do
             t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
				
               table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(720p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p)].-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p Ultra).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end
			end
        
	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end