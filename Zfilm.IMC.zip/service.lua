-- zfilm plugin

require('support')
require('video')
require('parser')
require('client')
--http://jgdsgi1iogojkqogisdg.ua63.fun/v/1314843/

--https://www.zfilm-hd.org/films-00621/
--https://zfilm-hd.org/films-00421/
--HOME = 'https://zfilm-hd.org'
--HOME = 'http://hdd-hd720.zfilm-hd-zerkalo.fun'
--HOME = 'http://newseries.zfilm-hd.site'
--HOME = 'http://hd-720-hd1.zfilm-720.com'
--HOME = 'http://movielib.zfilm-hd.club'
--HOME = 'http://warcinema.zfilm-hd-2755.online'    
--HOME = 'http://q.zfilm-hd.xyz'
--HOME = 'http://zfilme-hd1.site'
--local HOME = 'http://v67297320.shazoo-film.site'
local HOME = 'http://v70601683.kinomax-film.site'
--local HOME = 'https://tv.zfilm-hd.biz'
--local HOME_SLASH = HOME .. '/'


local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from zfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from zfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/gente=/muzykalnye_kanaly
	-- #stream/gente=/novostnye_kanaly
	-- #stream/genre=/razvlekatelnyye_kanaly
	-- #stream/genre=/sputnikovye_kanaly
	-- #stream/genre=/f/genre:ужасы

	if not args.q then
		local page = tonumber(args.page or 1)
     --   local offset = (page - 1) * 3 + 1
	--	for  i= 1, 3 do
	
      --   local genre = args.genre or '/c'
        local genre = args.genre or '/films-01122/'
     	local url = HOME .. genre
		if page > 1 then
        
			url = url .. 'page/' .. tostring(page) .. '/'
		end

         if genre == '/f/genre:ужасы' then
        url = HOME .. genre .. '/' .. 'page/' .. tostring(page) .. '/' .. '#dle-content'
		end 

			
	--	local x = http.getz(url)
        local x = conn:load(url)
       -- x = iconv(x, 'windows-1251', 'UTF-8')
       
       

       
       
       
        for url, image, title in string.gmatch(x, '<a class="poster__link d%-block has%-overlay" href="(http.-html)".-<img data%-src="(//.-)".-class="poster__title line%-clamp">(.-)<') do
        
    --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'https:')


		  table.insert(t, {title = title, mrl =  '#stream/q=content&id=' .. url, image = image})
		end
    

        for url, image, title in string.gmatch(x, '<div class="podborki%-item grid%-item".-<a href="http.-(/podborki.-)".-<img.-src="(.-jpg)".-class="podborki%-item__title">(.-)<') do
        
      --  url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH)


		  table.insert(t, {title = title, mrl =  '#folder/genre=' .. url, image = image})
		end
		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
        table.insert(t, {title = 'ПОДБОРКА', mrl = '#stream/genre=' .. '/podborki-filmov-01122/'})
        local x = conn:load(HOME .. '/b')
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
      
      local x = string.match(x, '<ul class="header__menu d%-flex">(.-)<div class="nav__ext%-menu d%-flex ai%-center"')
        for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end
        


         local x = conn:load(HOME .. '/b')
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
      local x = string.match(x, '<ul class="menu%-btns__genres d%-none">(.-)</ul>')
        for genre, title in string.gmatch(x, '<a href=.-(/.-)">(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. urlencode(genre) .. '/'})
		end


--https://v68629786.irecommend-film.site/search/%D0%A7%D1%83%D0%B6%D0%B8%D0%B5


    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/' .. urlencode(args.keyword)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<a class="poster__link d%-block has%-overlay" href="(http.-html)".-<img data%-src="(//.-)".-class="poster__title line%-clamp">(.-)<') do
        
    --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'https:')


		  table.insert(t, {title = title, mrl =  '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})






	-- #stream/q=content&id=/35272-koroleva-yuga-900518144.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
          t['ref'] = args.id
	
          --x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1 class="sect__title flex-grow-1">(.-)смотреть онлайн.-</h1>')
		t['description'] = parse_match(x, '<article class="page__text full%-text.->(.-)</article>')
			t['poster'] = args.p
--	   t['poster'] = parse_match(x,'<img class="logo%-mobile scale%-with%-grid" src="(.-)"')
	--	if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
	    	t['annotation'] = parse_array(x, {	'(Год:</b>.-)</p>', '(Страна:</b>.-)</p>', '(Жанр:</b>.-)</p>', '(Режиссер:</b>.-)</p>', '(Актеры:</b>.-)</p>'  })
  
 


    
        for url in string.gmatch(x, '"image":".-img.-/uploads/.-/(.-).jpg"') do
    
        print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-or (//video.zagonka.org/movies/.-mp4)') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end
      
 
 
 
 
 
 
 
       
        for url in string.gmatch(x, '"image":".-img.-/uploads/.-/(.-).jpg"') do
        print(url)
		 url = string.gsub(url, '^(.-)', 'http://divantv.zz.mu/kinomovie/zombie.m3u.php?kp_id=')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
		
        for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end
	
	
	
	
		
        for url in string.gmatch(x, '"image":".-img.-/uploads/.-/(.-).jpg"') do
             print(url)
             
			url = string.gsub(url, '^(.-)', 'https://voidboost.net/embed/')
        --   url = string.gsub(url, ')', '')
       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
        for url in string.gmatch(x, '\'file\':.-#2(.-)\'') do
         url = string.gsub(url, '\\/\\/_\\/\\/', '')
         url = string.gsub(url, 'Xl5eXl5eIyNA', '')
         url = string.gsub(url, 'QCMhQEBAIyMkJEBA', '')
         url = string.gsub(url, 'Xl4jQEAhIUAjISQ=', '')
         url = string.gsub(url,'JCQkIyMjIyEhISEhISE=', '')
         url = string.gsub(url,'QCFeXiFAI0BAJCQkJCQ=', '')

         url=http.urldecode(base64_decode(url))
         
        if url then
			for title, url in string.gmatch(url, '(240p)].-or https://(.-mp4),') do
			
           url = string.gsub(url, '^(.-)', 'https://loki.')
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
		if url then
			for title, url in string.gmatch(url, '(360p)].-or https://(.-mp4),') do
			
           url = string.gsub(url, '^(.-)', 'https://loki.')
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if url then
			for title, url in string.gmatch(url, '(480p)].-or https://(.-mp4),') do
			
           url = string.gsub(url, '^(.-)', 'https://loki.')
             t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(720p)].-or https://(.-mp4),') do
			
           url = string.gsub(url, '^(.-)', 'https://loki.')
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p)].-or https://(.-mp4)') do
			
           url = string.gsub(url, '^(.-)', 'https://loki.')
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
				
			end
		end	
     
     end
     
     
        
        for url, title in string.gmatch(x, '<option data%-token="(.-)".->(.-)</option>') do
			
            print(url)
        
			url = string.gsub(url, '^(.-)', 'https://voidboost.net/movie/') .. '/iframe?h=gidonline.io&block=jp,mx,us,au,br,in,cn,ch,be,kp,sg,ca,kr,hk&df=1&vstop=5&vsright=107&partner=gidonline'
         t['view'] = 'simple'
         table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})

		end
		
     --   for url in string.gmatch(x, 'params.-/embed/(.-)?autoplay=1&start') do
	
       --  print(url)
        
	--	url = string.gsub(url, '^(.-)', 'https://voidboost.net/embed/')
		
		
		
		
		
		
		for url2 in string.gmatch(x, 'params.-/embed/(.-)?') do
    	
        print(url2)
        
		url2 = string.gsub(url2, '^(.-)', 'https://voidboost.net/embed/')
		
		
   --    for id in string.gmatch(x, '(block=.-&partner=gidonline)') do
		
	--	local x = string.match(x, '<select name="season".->(.-)</select>')
		
		
        for url, title in string.gmatch(x, '<option value="(.-)".-(Сезон.-)</option') do
	
        print(url)
		url = string.gsub(url, '^(.-)', '?s=')  
		
        local x = string.match(x, '<select name="episode".->(.-)</select>')
        
        for url1, title in string.gmatch(x, '<option value="(.-)".-(Серия.-)</option') do

        print(url1)
		url1 = string.gsub(url1, '^(.-)', '&e=') .. '&h=gidonline.io&block=jp,mx,us,au,br,in,cn,ch,be,kp,sg,ca,kr,hk&df=1&tp=21,2&vstop=5&vsleft=44&partner=gidonline'
		

    	
    --    print(url3)
        
	--	url3 = string.gsub(url3, '^(.-)', ) .. '&partner=gidonline'

      --   t['view'] = 'simple'
         table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url2 .. url .. url1})

		end	
		end
		end
        
        
        for title, url in string.gmatch(x, 'file:.-(240p).-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        for title, url in string.gmatch(x, 'file:.-(360p).-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        for title, url in string.gmatch(x, 'file:.-(480p).-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        
        for title, url in string.gmatch(x, 'file:.-(720p).-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        for title, url in string.gmatch(x, 'file:.-(1080p).-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        
        
        for title, url in string.gmatch(x, 'file:.-(240p).-(https.-mp4)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        for title, url in string.gmatch(x, 'file:.-(360p).-(https.-mp4)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        for title, url in string.gmatch(x, 'file:.-(480p).-(https.-mp4)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        
        for title, url in string.gmatch(x, 'file:.-(720p).-(https.-mp4)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        for title, url in string.gmatch(x, 'file:.-(1080p).-(https.-mp4)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        
        end
        
	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end