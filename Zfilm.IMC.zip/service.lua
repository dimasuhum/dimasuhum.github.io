-- zfilm plugin

require('support')
require('video')
require('parser')
require('client')
--http://jgdsgi1iogojkqogisdg.ua63.fun/v/1314843/

--https://www.zfilm-hd.org/films-00621/
--https://zfilm-hd.org/films-00421/
--HOME = 'https://zfilm-hd.org'
--HOME = 'http://hdd-hd720.zfilm-hd-zerkalo.fun'
--HOME = 'http://newseries.zfilm-hd.site'
--HOME = 'http://hd-720-hd1.zfilm-720.com'
--HOME = 'http://movielib.zfilm-hd.club'
--HOME = 'http://warcinema.zfilm-hd-2755.online'    
--local HOME = 'https://xkino.site'
--HOME = 'http://zfilme-hd1.site'
--local HOME = 'https://one.kinchik.se'

--https://one.kinchik.se/films-030623/

--local HOME = 'http://v70601683.kinomax-film.site'

-- local HOME = 'https://ww.kinoland3333.buzz'
--local HOME = 'https://filmec.pro'
--local HOME_SLASH = HOME .. '/'
local HOME = 'https://17dec11.z5k2.cfd'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




function onLoad()
	print('Hello from zfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from zfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/gente=/muzykalnye_kanaly
	-- #stream/gente=/novostnye_kanaly
	-- #stream/genre=/razvlekatelnyye_kanaly
	-- #stream/genre=/sputnikovye_kanaly
	-- #stream/genre=/f/genre:ужасы

	if not args.q then
		local page = tonumber(args.page or 1)

--https://filmec.pro/films/
         local genre = args.genre or '/hotnews/'
        local genre = args.genre or '/films/'

        
     	local url = HOME .. genre
		if page > 1 then
        
			url = url .. 'page/' .. tostring(page) .. '/'
		end

         if genre == '/f/genre:ужасы' then
        url = HOME .. genre .. '/' .. 'page/' .. tostring(page) .. '/' .. '#dle-content'
		end 

			
	--	local x = http.getz(url)
        local x = conn:load(url)
       -- x = iconv(x, 'windows-1251', 'UTF-8')
       


        for url, image, title in string.gmatch(x, '<a class="poster__link d%-block has%-overlay" href="(.-)".-<img src="(.-)".-class="poster__title line%-clamp">(.-)</h2>') do
       
       
      --  for url, image, title in string.gmatch(x, '<a class="poster__link d%-block has%-overlay" href="(http.-html)".-<img data%-src="(//.-)".-class="poster__title line%-clamp">(.-)<') do
        
    --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', HOME)


		  table.insert(t, {title = title, mrl =  '#stream/q=content&id=' .. url, image = image})
		end
    

        for url, image, title in string.gmatch(x, '<div class="podborki%-item grid%-item".-<a href="http.-(/podborki.-)".-<img.-src="(.-jpg)".-class="podborki%-item__title">(.-)<') do
        
      --  url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^(.-)', HOME)


		  table.insert(t, {title = title, mrl =  '#folder/genre=' .. url, image = image})
		end
		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
        table.insert(t, {title = 'ПОДБОРКА', mrl = '#stream/genre=' .. '/podborki-filmov/'})
        
--http://v70601683.kinomax-film.site/podborki-filmov-00223/

--https://filmec.pro/podborki-filmov/
        
        
        table.insert(t, {title = 'Горячие новинки', mrl = '#stream/genre=' .. '/hotnews/'})
     
        
        table.insert(t, {title = 'Самое популярное', mrl = '#stream/genre=' .. '/popular/'})
     
     table.insert(t, {title = 'Сейчас смотрят', mrl = '#stream/genre=' .. '/watched/'})
     
     table.insert(t, {title = 'ТОП-250 КП', mrl = '#stream/genre=' .. '/top250/'})
     
      table.insert(t, {title = 'ТОП-250 IMDb', mrl = '#stream/genre=' .. '/top250imdb/'})
     
     

  
        local x = conn:load(HOME .. '/')

 
      
      local x = string.match(x, '<ul class="nav__menu d%-flex flex%-grow%-1 has%-scroll">(.-)<div class="nav__ext%-menu d%-flex ai%-center"')
        for genre, title in string.gmatch(x, '<a href="(.-)" title="(.-)".-</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end
        


        local x = conn:load(HOME .. '/')
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
   --   local x = string.match(x, '<ul class="top%-block__left menu%-btns">(.-)</ul>')
        for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. urlencode(urldecode(genre)) .. '/'})
		end


--https://v68629786.irecommend-film.site/search/%D0%A7%D1%83%D0%B6%D0%B8%D0%B5
--https://filmec.pro/search/%D0%A0%D0%BE%D0%BA%D0%BA%D0%B8

    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/' .. urlencode(args.keyword)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<a class="poster__link d%-block has%-overlay" href="(.-)".-<img src="(.-)".-class="poster__title line%-clamp">(.-)</h2>') do
        
    --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', HOME)


		  table.insert(t, {title = title, mrl =  '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})






	-- #stream/q=content&id=/35272-koroleva-yuga-900518144.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
          t['ref'] = args.id
	
          --x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1 class="sect__title flex-grow-1">(.-)смотреть онлайн.-</h1>')
		

		t['description'] = parse_match(x, 'class="page__text full%-text.-<br><br>(.-)<br><br>')
			t['poster'] = args.p
--	   t['poster'] = parse_match(x,'<img class="logo%-mobile scale%-with%-grid" src="(.-)"')
	--	if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
	    	t['annotation'] = parse_array(x, {	'(Год:</b>.-)</p>', '(Страна:</b>.-)</p>', '(Жанр:</b>.-)</p>', '(Режиссер:</b>.-)</p>', '(Актеры:</b>.-)</p>'  })
  
 
    
 




    
        for url in string.gmatch(x, 'class="page__info%-rating".-url=http.-kinopoisk.ru/.-/(.-)"') do
    
        print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Zagonka', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
        local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-(//video.zagonka.org/movies/.-})') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
			
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
		
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end
      
 
 
 
 
 
 
 
 
for title, total  in string.gmatch(x,'<h1.->(.-)%((.-)%)') do

      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
     url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    

    table.insert(t, {title = 'Источники', mrl = '#stream/q=content&id=' .. url, image = image})
         end
   
   
    local x = conn:load(args.id)
    
    for title, title1 in string.gmatch(x, '%[{"size".-"name":"(.-)".-"relased":(.-),') do

     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')


    --   title1 = urlencode(title1)
      
   --   title1 = string.gsub(title1, '+', '%%20')
        url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '+'  .. '(' .. title1 .. ')'
  
         local x = conn:load(url)
    
     
       for title3  in string.gmatch(x, '"fxml".-playlist_url.-?id=info&cid=(.-)"') do

         url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 

      
         local x = conn:load(url1)

   
   
   
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :' .. tolazy(total2), mrl = url2})

      end 
 
     
  

      
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. total3, mrl = url4})

       
    end

end
end





      url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/fancdn?kinopoisk_id=')
      --.. '&uid=m7alois3'
    
    
      local x = conn:load(url1)
   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url1 = string.gsub(url1, '\\u0026', '&')
  --  url1 = string.gsub(url1, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'


 --   table.insert(t, {title = url2, mrl = url2})

   table.insert(t, {title = 'fancdn :' .. tolazy(total), mrl = url2})

       
    end

    
     
     
     
     

      url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/fancdn?kinopoisk_id=') .. '&uid=m7alois3'
    
     local x = conn:load(url1)
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = 'fancdn :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end









   --    title1 = string.gsub(title1, '%%20', '-')

    url1 = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&search=') .. '-' .. title1
     
     url1 = string.gsub(url1, '%%20', '-')
     
     
     --.. '&box_mac=acace24b8434'
			
	
		   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')


     for total1 in string.gmatch(x, 'fxml.-<channel>.-http.-&goto=(.-)]]') do




    total1=base64_decode(total1)
     
    total1 = string.gsub(total1, 'item/', '')
     
  

  
     url2 = string.gsub(total1, '^(.-)', 'https://api.manhan.one/rc/filmix?postid=')
  
  
        local x = conn:load(url2)
      
     for  url3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

   table.insert(t, {title = 'filmix' .. ':'.. tolazy(total2), mrl = url3})

     end  


      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for url5, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'filmix :' .. total .. ' '  .. tolazy(total3) .. total2, mrl = url5})

       
    end

end
end
end








    url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title='alloha' .. ':' .. tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
      t['view'] = 'simple'
				table.insert(t,{title= 'alloha :' .. tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end






     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/zetflix?kinopoisk_id=') 

    
       local x = conn:load(url1)
   
   
   for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total), mrl = url2})

       
    end
    
    
    
        for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end






  url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=') .. '&uid=m7alois3'
    
    
      local x = conn:load(url1)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=') 

    local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total1) .. total2, mrl = url3})

       
    end

end


url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/lumex?kinopoisk_id=') .. '&uid=m7alois3'
    
    
    local x = conn:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/lite.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
       t['view'] = 'simple'

   table.insert(t, {title = 'lumex :' .. tolazy(total), mrl = url2})

       
    end
     

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://hidxlglk.deploy.cx')
    
  --    url4 = string.gsub(url4, 'rjson=False&', '')
    
    
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end





url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/mirage?kinopoisk_id=') .. '&uid=m7alois3'

      
         local x = conn:load(url1)

   
   
   
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'mirage :' .. tolazy(total2), mrl = url2})

      end 
 
     
  

      
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'mirage :'  .. total2 .. ' '  .. tolazy(total) .. total3, mrl = url4})

       
    end

end
end


        url1 = string.gsub(title, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=') .. '+' .. title1 .. '+'
	
    	 local x = conn:load(url1)
      
      	for url2 in string.gmatch(x, '<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn:load(url2)
    
    
    for total, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<logo.-<!%[CDATA%[.-</logo.-<description><!%[CDATA%[.-</description>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	
	     local x = conn:load(url3)
	     
	     for total1, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. total1 .. ' ' .. total, mrl = url4, image = image})
         end
	     end
    end
    	




end
end
    
    
    
    
    
    

    for total in string.gmatch(x,'%[{"size.-trackerName.-kinozal.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        

       url = string.gsub(total, '^(.-)','http://torr.unknot.ru:8090/stream/?link=') .. '&m3u'
      

        local x = http.get(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
         t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
         t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
        t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	



      for total in string.gmatch(x,'%[{"size.-trackerName.-nnmclub.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        
      url = string.gsub(total, '^(.-)','http://torr.unknot.ru:8090/stream/?link=') .. '&m3u'
      

        local x = http.get(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     
     t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
        t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
        t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	




 
        
	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end