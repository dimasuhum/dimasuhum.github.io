-- fast-film plugin

require('support')
require('video')
require('parser')

--HOME = 'https://wap.tizam.club'

HOME = 'https://vip.tizam.org'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
--https://wap.tizam.club/poslednie_postupleniya/?p=1
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/poslednie_postupleniya/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?p=' .. tostring(page)
		end
		local x = http.getz(url)
         
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for image, title, url in string.gmatch(x, '<img class="item__img" src="(/.-)".-alt="(.-)".-<a href="(.-)"') do
         -- url = string.gsub(url, '^(.-)', HOME)
          image = string.gsub(image, '^(.-)', HOME)
          url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
       
		local x = http.getz(url)
      if genre == '/aktrisy/' then
      for id, image, title in string.gmatch(x, 'class="item video%-block model".-<a href="(/aktrisy.-)".-<img.-src="(.-)" alt="(.-)"') do
      --    url = string.gsub(url, '^(.-)', HOME)
          image = string.gsub(image, '^(.-)', HOME)
          

			table.insert(t, {title = title,mrl = '#folder/genre' .. id, image = image})
		end
		end
		if genre == '/studii/' then
       for id, image, title in string.gmatch(x, 'class="item video%-block studios".-<a href="(/studii.-)".-<img.-src="(.-)" alt="(.-)"') do
      --   url = string.gsub(url, '^(.-)', HOME)
          image = string.gsub(image, '^(.-)', HOME)
          

			table.insert(t, {title = title,mrl = '#folder/genre' .. id, image = image})
		end
		end
		
	
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
  
  local x = http.getz(HOME)
  
local x = string.match(x, 'name="Категории">(.-)<ul class="dropdown%-menu')
  
  
for genre, title in string.gmatch(x, '<item.-link="(.-)".->(.-)</item>') do
  table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
  end
         local x = http.getz(HOME .. '/fil_my_dlya_vzroslyh/')
		
   --     x = iconv(x, 'WINDOWS-1251', 'UTF-8')
	--	local x = string.match(x, '<ul class="reset top%-menu">(.-)</ul>')
		for genre, title, total in string.gmatch(x, '<li class="item_drop".-<a href="(.-)".->(.-)<') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
           local x = http.getz(HOME .. '/podborki/')
        for genre, title, total in string.gmatch(x, '<li class="item_drop".-<a href="(.-)".->(.-)<') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. genre})
		end
        table.insert(t, {title = 'Модели', mrl = '#stream/genre=' .. '/aktrisy/'})
       table.insert(t, {title = 'Студии', mrl = '#stream/genre=' .. '/studii/'})
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="m%-desc full%-text clearfix slice%-this slice slice%-masked">(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
--src="https://tizam.cc/videoapi/directplayer.html?url=https%3A%2F%2Fvideo1.tizam.cc%2Ffilms%2F5fb56fd76ba53.mp4"
		
     
for url in string.gmatch(x, '<source src="(http.-mp4)".-type="video') do
    table.insert(t, {title = 'Смотреть', mrl = url})

			
		end 
       for url, title in string.gmatch(x, '<source src="(http.-mp4)".-data%-res="(.-)"') do
	--	url = string.gsub(url, '^(.-)', 'https://')
   --    url = string.gsub(url, '%%2F', '/')
         table.insert(t, {title = 'Смотреть:' .. title, mrl = url})

			
		end

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end