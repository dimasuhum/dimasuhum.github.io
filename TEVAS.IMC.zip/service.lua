-- tevas plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://tevas.tv'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH






--HOME = 'https://tevas.ru'
--HOME = 'https://tevas.live'
--HOME = 'https://tevas.party'
--HOME = 'https://tevas.store'
--HOME = 'https://tevas.org'
--HOME = 'https://tevas.stream'
--HOME = 'https://tevas.cpads.ru'
--HOME = 'https://tevas.mobi'
--HOME = 'https://tevas.cpads.ru'
--HOME1 = 'https://vezonchik.ru'
--HOME_SLASH = HOME .. '/'
--HOME_SLASH1 = HOME1 .. '/'



function onLoad()
	print('Hello from tevas plugin')
	return 1
end

function onUnLoad()
	print('Bye from tevas plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'} 
         
	t['menu'] = {}
	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
		
	
	-- #stream/sort=top
	-- #stream/sort=mysort
	-- #stream/sort=boe
	-- #stream/sort=hor	
	-- #stream/sort=nov
	-- #stream/sort=bio
	-- #stream/sort=ves
	-- #stream/sort=voe	
	
	-- #stream/sort=det
	-- #stream/sort=kid
	-- #stream/sort=dok
	-- #stream/sort=dra	
	-- #stream/sort=ist
	-- #stream/sort=kom
	-- #stream/sort=kri
	-- #stream/sort=mel		
	-- #stream/sort=mul
	-- #stream/sort=pri
	-- #stream/sort=sem
	-- #stream/sort=spo
	-- #stream/sort=tri
	-- #stream/sort=fan
	-- #stream/sort=fen	
	-- #stream/genre=/kino/download/?page=
	if not args.q then
		

         local page = tonumber(args.page or 1)

         local genre = args.genre or '/kino/download/'
    --     local genre = args.genre or '/kino/'
         local url = HOME .. genre 


       
        url = url .. '?page=' .. tostring(page)
        
--https://tevas.org/kino/download/?sort=hor&big=033

        if genre == '?sort=hor&' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. genre .. total
		end



   --     local x = http.get(url)
         local x = conn:load(url)
        
		for url, image, title  in string.gmatch(x, '<a href="(?f=.-mp4).-src="..(/.-)".-<span>(.-)<')do 
        url = string.gsub(url, '^(.-)', HOME .. '/kino/download/')
		image = string.gsub(image, '^(.-)', HOME .. '/kino')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
		end
		
	--	local x = http.get(url)

    --   for url, image, title  in string.gmatch(x, '<a href="(all/.-)".-src="(.-)".-<span>(.-)<')do 
      --  url = string.gsub(url, '^(.-)', HOME .. '/serial/')
	--	image = string.gsub(image, '^(.-)', HOME .. '/serial/')
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
	--	end
     --   for url, image, title  in string.gmatch(x, '<a href="(all/.-)".-src="(.-)".-<span>(.-)<')do 
      --  url = string.gsub(url, '^(.-)', HOME .. '/serial/')
	--	image = string.gsub(image, '^(.-)', HOME .. '/serial/')
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
	--	end
       -- for url, title in string.gmatch(x,'<a href="(.-/)".-class="i s01">(Сезон.-)<
        local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre 
       
		table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
    
        local x = http.getz(HOME .. '/kino/')
        
--https://tevas.org/kino/download/?sort=hor&big=033
        
        for genre, total, title in string.gmatch(x, '<a href="download/(?.-&)(.-)".->(.-)</div>') do
    --    table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. '/kino/download/' .. genre})
         total = string.gsub(total, 'amp;', '')
         genre = string.gsub(genre, '^(.-)','/kino/download/')
        table.insert(t, {title = HOME .. genre .. total, mrl = '#stream/genre=' .. genre .. total})
        end
         
--    <div class="clear"></div>  <a href="/search/"><div class="i s2">Поиск</div></a>     --    <script type="text/javascript"
		
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/search.php?' .. 'p=' .. tostring(page) .. '&q=' .. urlencode(args.keyword)

		
		local x = conn:load(url)
		
        for url, image, title  in string.gmatch(x, '<a href=".-(?f.-)".-src=.-/.-(/.-)".-<span>(.-)</span>')do 
        url = string.gsub(url, '^(.-)', HOME .. '/kino/download/')
		image = string.gsub(image, '^(.-)', HOME .. '/kino')
		
		
    --    for url, image, title  in string.gmatch(x, '<a href=.-(/kino.-mp4).-src=.-(/.-jpg).-<span>(.-)</')do 
     --   url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
		end
    	local url = '#folder/q=search&keyword=' .. 'p=' .. tostring(page + 1) .. '&q=' .. urlencode(args.keyword)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
	
	
	
			
	-- #stream/q=content&id=https://mulltik.me/6248-mikki-maus-mir-priklyucheniy.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1. ->(.-)</h1>') 
		t['description'] = parse_match(x, '<div style="padding:.-<br.-<br.-<br.-br>(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div align="center".-src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Фильм:.-)<br>', '(Год:.-)<br>', '(Перевод:.-)<br>', '(Качество:.-)<br>',
		})

        --x = string.gsub(x, 'скачать', '')
        
        for url, title in string.gmatch(x,'<a href="(0.-)".-class="i s01">(Сезон.-)<') do
          print(url) 
          url = string.gsub(url, '^(.-)', args.id)
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
		
         table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
		 end
		 
		  for url, title in string.gmatch(x, '<a href="(?f=.-mp4)".-class="i epi vn">(Серия.-)<') do
		 url = string.gsub(url, '^(.-)', args.id)
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
           t['view'] = 'simple'
         table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
		 end
		 
		 
        for url in string.gmatch(x, '<a rel="noindex nofollow" href="?f=(.-mp4)') do
        
          print(url) 
          url = string.gsub(url, '^(.-)', 'https://get.tevas.fans/kino/download/top/')
--https://get.tevas.fans/kino/download/top/Beskraynij_bassejn_2023.mp4
          
          
			--addvideo(t, url, t['name'])
	--	url = '#stream/q=play&url=' .. url	
		
         table.insert(t, {title = url, mrl = url})
		 end
		 
		 
--//get.tevas.fans/kino/download/top/Vedma_reinkarnaciya_2023.mp4
--https:/kino/download/top/Za_predelami_neona_2022.mp4

--https://get.tevas.fans/kino/download/top//kino/download/top/Beskraynij_bassejn_2023.mp4
--<video playsinline="1" preload="metadata" src="//get.tevas.tech/kino/download/top/Na_krayu_2022.mp4"

        for url in string.gmatch(x, 'var player = new Playerjs.-id:"player".-file:"(.-)"') do
          print(url) 
          url = string.gsub(url, '^(.-)', 'https://get.tevas.tech')
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
		
         table.insert(t, {title = 'Смотреть', mrl = url})
		 end

        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end