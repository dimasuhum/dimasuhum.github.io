-- tevas plugin

require('support')
require('video')
require('parser')

--HOME = 'https://tevas.ru'
--HOME = 'https://tevas.live'
--HOME = 'https://tevas.party'
--HOME = 'https://tevas.store'
HOME = 'https://tevas.stream'
--HOME = 'https://tevas.cpads.ru'
--HOME = 'https://tevas.mobi'
--HOME = 'https://tevas.cpads.ru'
--HOME1 = 'https://vezonchik.ru'
HOME_SLASH = HOME .. '/'
--HOME_SLASH1 = HOME1 .. '/'



function onLoad()
	print('Hello from tevas plugin')
	return 1
end

function onUnLoad()
	print('Bye from tevas plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'} 
         
	t['menu'] = {}
	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
		
	
	-- #stream/sort=top
	-- #stream/sort=mysort
	-- #stream/sort=boe
	-- #stream/sort=hor	
	-- #stream/sort=nov
	-- #stream/sort=bio
	-- #stream/sort=ves
	-- #stream/sort=voe	
	
	-- #stream/sort=det
	-- #stream/sort=kid
	-- #stream/sort=dok
	-- #stream/sort=dra	
	-- #stream/sort=ist
	-- #stream/sort=kom
	-- #stream/sort=kri
	-- #stream/sort=mel		
	-- #stream/sort=mul
	-- #stream/sort=pri
	-- #stream/sort=sem
	-- #stream/sort=spo
	-- #stream/sort=tri
	-- #stream/sort=fan
	-- #stream/sort=fen	
	-- #stream/genre=/kino/download/?page=
	if not args.q then
		
        --local offset = (page - 1) * 3 + 1
		--for  i= 1, 1 do

		
		
         local page = tonumber(args.page or 1)
       -- local genre = args.genre or '/kino/virus.html'
--https://tevas.stream/kino/download/?page=4
         local genre = args.genre or '/kino/download/'
--https://tevas.stream/kino/download/?sort=mysort&gib=121
         local url = HOME .. genre 
    --   local url = HOME .. '/kino/virus.html' 
         -- local url = HOME .. '/kino/download/?sort=mysort&gib=121'

       
        url = url .. '?page=' .. tostring(page)
        
        if genre == '/kino/download/?sort=dok' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=dok' --.. '&big=150'
		end
        if genre == '/kino/download/?sort=hor' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=hor' --.. '&big=150'
		end
		if genre == '/kino/download/?sort=top' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=top' --.. '&big=150'
        end
		if genre == '/kino/download/?sort=boe' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=boe' --.. '&big=150' 
        end
		if genre == '/kino/download/?sort=nov' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=nov' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=bio' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=bio' --.. '&big=150'
 end
        if genre == '/kino/download/?sort=ves' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=ves'
--.. '&big=150'
 end
		if genre == '/kino/download/?sort=voe' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=voe' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=det' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=det' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=kid' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=kid' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=dra' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=dra' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=ist' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=ist' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=kom' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=kom'
--.. '&big=150'
 end
		if genre == '/kino/download/?sort=kri' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=kri' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=mel' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=mel' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=mul' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=mul' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=pri' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=pri' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=sem' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=sem'
--.. '&big=150'
 end
		if genre == '/kino/download/?sort=spo' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=spo' --.. '&big=150'
 end
        if genre == '/kino/download/?sort=tri' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=tri'
--.. '&big=150'
 end
		if genre == '/kino/download/?sort=fan' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=fan' --.. '&big=150'
 end
		if genre == '/kino/download/?sort=fen' then
        url = HOME .. '/kino/download/' .. '?page=' .. tostring(page) .. '&sort=fen' --.. '&big=150'
 end
     --  if genre == '/serial/' then
    --    url = HOME .. genre
	--	end
        local x = http.get(url)

        
		for url, image, title  in string.gmatch(x, '<.-href=.-(?f.-mp4).-src="..(/.-)".-<span>(.-)<')do 
        url = string.gsub(url, '^(.-)', HOME .. '/kino/download/')
		image = string.gsub(image, '^(.-)', HOME .. '/kino')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
		end
		
	--	local x = http.get(url)

    --   for url, image, title  in string.gmatch(x, '<a href="(all/.-)".-src="(.-)".-<span>(.-)<')do 
      --  url = string.gsub(url, '^(.-)', HOME .. '/serial/')
	--	image = string.gsub(image, '^(.-)', HOME .. '/serial/')
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
	--	end
     --   for url, image, title  in string.gmatch(x, '<a href="(all/.-)".-src="(.-)".-<span>(.-)<')do 
      --  url = string.gsub(url, '^(.-)', HOME .. '/serial/')
	--	image = string.gsub(image, '^(.-)', HOME .. '/serial/')
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
	--	end
       -- for url, title in string.gmatch(x,'<a href="(.-/)".-class="i s01">(Сезон.-)<
        local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre 
       
		table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
    
        local x = http.getz(HOME .. '/kino/')
        for genre, title in string.gmatch(x, '.-download(/?sort=.-)\'.->(.-)</a>') do
        table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
        end
         
         table.insert(t, {title = 'Топ', mrl = '#stream/genre=' .. '/kino/download/?sort=top'})
         table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/kino/download/?sort=mysort'})
         table.insert(t, {title = 'Боевики', mrl = '#stream/genre=' .. '/kino/download/?sort=boe'})
         table.insert(t, {title = 'Ужасы', mrl = '#stream/genre=' .. '/kino/download/?sort=hor'})
         table.insert(t, {title = 'Новогодние', mrl = '#stream/genre=' .. '/kino/download/?sort=nov'})
         table.insert(t, {title = 'Биографические', mrl = '#stream/genre=' .. '/kino/download/?sort=bio'})
         table.insert(t, {title = 'Вестерн', mrl = '#stream/genre=' .. '/kino/download/?sort=ves'})
         table.insert(t, {title = 'Военные', mrl = '#stream/genre=' .. '/kino/download/?sort=voe'})
         table.insert(t, {title = 'Детективы', mrl = '#stream/genre=' .. '/kino/download/?sort=det'})
         table.insert(t, {title = 'Детские', mrl = '#stream/genre=' .. '/kino/download/?sort=kid'})
         table.insert(t, {title = 'Документальные', mrl = '#stream/genre=' .. '/kino/download/?sort=dok'})
         table.insert(t, {title = 'Драмы', mrl = '#stream/genre=' .. '/kino/download/?sort=dra'})
        table.insert(t, {title = 'Исторические', mrl = '#stream/genre=' .. '/kino/download/?sort=ist'})
         table.insert(t, {title = 'Комедии', mrl = '#stream/genre=' .. '/kino/download/?sort=kom'})
         table.insert(t, {title = 'Приключения', mrl = '#stream/genre=' .. '/kino/download/?sort=pri'})
         
         table.insert(t, {title = 'Мелодрамы', mrl = '#stream/genre=' .. '/kino/download/?sort=mel'})
        table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/kino/download/?page=1&sort=mul'})
         table.insert(t, {title = 'Комедии', mrl = '#stream/genre=' .. '/kino/download/?sort=kom'})
         table.insert(t, {title = 'Криминал', mrl = '#stream/genre=' .. '/kino/download/?sort=kri'})
         
        table.insert(t, {title = 'Семейные', mrl = '#stream/genre=' .. '/kino/download/?sort=sem'})
         table.insert(t, {title = 'Спорт', mrl = '#stream/genre=' .. '/kino/download/?sort=spo'})
         table.insert(t, {title = 'Триллер', mrl = '#stream/genre=' .. '/kino/download/?sort=tri'})
         
         
        table.insert(t, {title = 'Фантастика', mrl = '#stream/genre=' .. '/kino/download/?sort=fan'})
         table.insert(t, {title = 'Фентези', mrl = '#stream/genre=' .. '/kino/download/?sort=fen'})
     --   table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serial/'})
         
         
         
         
		local x = http.getz(HOME .. '/kino/')
	  --  x = iconv(http.get(HOME), 'UTF-8')
      -- local x = string.match(x, 'Поиск.->(.-)<div class="clear"')
         for genre, title in string.gmatch(x, '<a href="download(/.-)".-<div.->(.-)</div>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. '/kino/download' ..  genre})
		end
		-- local x = http.getz(HOME1)
      --  local x = string.match(x, 'Кино и Сериалы.->(.-)<.-Порно на TEGOS')
	--	for genre, title in string.gmatch(x, '<a href="(.-)".-<div.->(.-)</div>') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
	--	end	
		
		
--https://tevas.stream/search/search.php?q=%D0%BF%D0%BE
--https://tevas.stream/search/search.php?p=2&q=%D0%BF%D0%BE		

		
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/search.php?' .. 'p=' .. tostring(page) .. '&q=' .. urlencode(args.keyword)

		
		local x = http.getz(url)
		
        for url, image, title  in string.gmatch(x, '<a href=".-(?f.-)".-src=.-/.-(/.-)".-<span>(.-)</span>')do 
        url = string.gsub(url, '^(.-)', HOME .. '/kino/download/')
		image = string.gsub(image, '^(.-)', HOME .. '/kino')
		
		
    --    for url, image, title  in string.gmatch(x, '<a href=.-(/kino.-mp4).-src=.-(/.-jpg).-<span>(.-)</')do 
     --   url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
		end
    	local url = '#folder/q=search&keyword=' .. 'p=' .. tostring(page + 1) .. '&q=' .. urlencode(args.keyword)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
	
	
	
			
	-- #stream/q=content&id=https://mulltik.me/6248-mikki-maus-mir-priklyucheniy.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1. ->(.-)</h1>') 
		t['description'] = parse_match(x, '<div style="padding:.-<br.-<br.-<br.-br>(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div align="center".-src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Фильм:.-)<br>', '(Год:.-)<br>', '(Перевод:.-)<br>', '(Качество:.-)<br>',
		})

        --x = string.gsub(x, 'скачать', '')
        
        for url, title in string.gmatch(x,'<a href="(0.-)".-class="i s01">(Сезон.-)<') do
          print(url) 
          url = string.gsub(url, '^(.-)', args.id)
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
		
         table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
		 end
		 
		  for url, title in string.gmatch(x, '<a href="(?f=.-mp4)".-class="i epi vn">(Серия.-)<') do
		 url = string.gsub(url, '^(.-)', args.id)
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
           t['view'] = 'simple'
         table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
		 end
     --   for url in string.gmatch(x, 'content=".-?f=(.-mp4)"') do
         -- print(url) 
       --   url = string.gsub(url, '^(.-)', 'https://ogo365.me/kino/download/all/')
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
		
      --   table.insert(t, {title = url, mrl = url})
	--	 end
--https://middle.tevas.store/kino/download/Mortal_Kombat_2021_TEVAS.mp4
        for url in string.gmatch(x, 'var player = new Playerjs.-id:"player".-file:"(.-)"') do
          print(url) 
          url = string.gsub(url, '^(.-)', 'https:')
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
		
         table.insert(t, {title = 'Смотреть', mrl = url})
		 end
      --  for url in string.gmatch(x, 'content=".-?f=(.-mp4)"') do
     --     print(url) 
     --     url = string.gsub(url, '^(.-)', 'https://middle.tevas.store/kino/download/')
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
		
      --   table.insert(t, {title = 'Смотреть', mrl = url})
	--	 end
        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end