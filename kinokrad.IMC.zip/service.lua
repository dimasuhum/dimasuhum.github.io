-- kinokrad plugin

require('support')
require('video')
require('parser')
require('client')



--local HOME = 'https://kinokrad.fm'
local HOME = 'https://kinokrad.la'
--local HOME = 'https://kinokrad.day'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
--conn['encoding'] = 'windows-1251'
conn['root'] = HOME_SLASH



--HOME = 'https://kinokrad.in'
--HOME = 'https://kinokrad.film'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinokrad plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinokrad plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	 table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	 
	-- #stream/page=2
	-- #stream/genre=/dokumentalny-3/
	-- #stream/genre=/filmy-2022-2/
	-- #stream/genre=/serial-6/
	-- #stream/genre=/russkie-2/
	-- #stream/genre=/3-uzhasy/
	-- #stream/genre=/uzhasy-online-1/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
        local x = conn:load(url)

        for  url, title, image  in string.gmatch(x, '<div class="shorbox".-<a href="(.-)">(.-)<.-<img.-src="(/uploads.-)"') do
       

          
          image = string.gsub(image, '^(.-)', HOME)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
   
   

   
        for image, total,  url, title in string.gmatch(x, '<div class="collect".-<img src="(.-)".-class="num">(.-)<.-class="namec".-<a href="(.-)">(.-)<') do
        
        image = string.gsub(image, '^(.-)', HOME)
		table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/genre=' .. url, image = image})
		
		end
		
        local genre = args.genre or ''
		local url = HOME .. genre
	--	if page > 1 then
			url = url
			--.. '/page/' .. tostring(page) .. '/'
	--	end
		local x = conn:load(url)
     --	local x = http.getz(url)
			for  url, title, image in string.gmatch(x, 'align="center".-<a href="(.-)".-alt="(.-)".-src="(.-)"') do
           image = string.gsub(image, '^(.-)', HOME)
          

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end	
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

--https://kinokrad.co/index.php?do=search&story=вий&search_start&dosearch
--results_from
--http://kinokrad.co/index.php?story=вой&do=search&subaction=search



	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'



      --   table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/4-serial/'})
        
        local x = conn:load(HOME)
      --  local x = http.getz(HOME)
        local x = string.match(x, '<div class="headermenu">(.-)</ul>')
		for genre, title in string.gmatch(x, '<li><a href="(/.-)".->(.-)</a>') do
		
       table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
        
        end

        local x = conn:load(HOME)
     --  	local x = http.getz(HOME)
        local x = string.match(x, '<div class="leftmenubox">(.-)<div class="leftbox%-comm%-ind"')
		for genre, title in string.gmatch(x, '<li><a href=.-//.-(/.-)".->(.-)</a>') do
		
        table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
        
        end


		
	--	local x = conn:load(HOME)
        
			
--"https://kinokrad.film/index.php?story=Рокки&do=search&subaction=search"
		
        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
	--	local url = HOME .. '/index.php?do=search&story=' .. urlencode(args.keyword) .. '&search_start=' .. '&results_from='
	--	local url = HOME .. '/index.php?do=search&story=' .. urlencode(args.keyword) .. '&search_start=' .. '/page/' .. tostring(page) .. '/'
--		local url = HOME .. '/index.php?story=' .. args.keyword .. '&do=search&subaction=search'  .. tostring(page) .. '/'


--https://kinokrad.film/index.php?story=рокки&do=search&subaction=search


    	local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'

    --    local x = http.post(url)
		
		local x = conn:load(url)
     --   local x = http.getz(HOME)
        
        

        
        
        for  url, title, image  in string.gmatch(x, '<div class="shorbox".-<a href="(.-)">(.-)<.-<img.-src="(/uploads.-)"') do
       

          
          image = string.gsub(image, '^(.-)', HOME)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
--		local x = conn:load(args.id)
		
        local x = http.getz(args.id)
   --     x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="fulltext".->(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</li>','(Жанр:</span>.-)</li>', '(Страна:</span>.-)</li>', '(Актерский состав:</span>.-)</div>'
		})





--http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https%3A%2F%2Fkinokrad.film%2F445901-myslit-kak-prestupnik-evolyuciya-1-sezon.html





--http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https://kinokrad.film/472289-reginald-the-vampire.html

--http://cloud.fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https%3A%2F%2Fkinokrad.fm%2F475881-kung-fu-games.html



     
     
        local x = http.getz('http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=' .. args.id)
     
   --     for url in string.gmatch(x, '<meta property="og:url" content="(.-)"') do
    
       -- url = string.gsub(url, '^(.-)', 'https://')
        
    --    url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=')
        
    --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
    --   end
       
       
       
   --    local x = http.getz(url)
       
        for url, url1 in string.gmatch(x, '?id=search","logo_30x30":"none"},{"title":".-,"preview".-id=file&u=(.-)(movie.-)"') do
	




     url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=file&u=') .. url1
        
    --    table.insert(t, {title = url, mrl = url})
       
        local x = http.getz(url)

         for title, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
         for title, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
        for title, url in string.gmatch(x, '(720p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
     	end

 --   end
     
     
  --   local x = conn:load(args.id)
     
  --     for url in string.gmatch(x, '<ul class="film".-"(//.-)"') do
     --     print(url)
--		 url = string.gsub(url, '^(.-)', 'https:')


   --    table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

   --    end
     
     
     
 --     for url in string.gmatch(x, '<meta property="og:url" content="(.-)"') do
   
   
  --     url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=')
   
   
   
      local x = http.getz('http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=' .. args.id)
      
    
   --     table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
     
  --   end


       

 
      for total, total2, url1, url2 in string.gmatch(x, '{"position":"list","preview".-"title":"(.-\\u0441\\u0435\\u0440\\u0438\\u044f) (\\u0421\\u0435\\u0437\\u043e\\u043d.-)\\.-"parser":"http.-id=file&u=(http.-)(serial.-)"') do
   
       total = string.gsub(total, '\\u0441\\u0435\\u0440\\u0438\\u044f', 'Серия')
   
        total2 = string.gsub(total2, '\\u0421\\u0435\\u0437\\u043e\\u043d', 'Сезон')
       url = string.gsub(url1, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=file&u=') .. url2
   
 --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
     
  --   end
       local x = http.getz(url)

         for total1, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = total .. total2 .. total1, mrl = url})

       end
       
         for total1, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = total .. total2 .. total1, mrl = url})

       end
        for total1, url in string.gmatch(x, '(720p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = total .. total2 .. total1, mrl = url})

       end
     
     
     
      end
   --   end
     
     
        
     
     
     
     
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end