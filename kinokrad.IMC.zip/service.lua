-- kinokrad plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://kinokrad.film'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



--HOME = 'https://kinokrad.in'
--HOME = 'https://kinokrad.film'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinokrad plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinokrad plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	 table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	 
	-- #stream/page=2
	-- #stream/genre=/dokumentalny-3/
	-- #stream/genre=/filmy-2022-2/
	-- #stream/genre=/serial-6/
	-- #stream/genre=/russkie-2/
	-- #stream/genre=/3-uzhasy/
	-- #stream/genre=/uzhasy-online-1/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
        local x = conn:load(url)

        for  url, title, image  in string.gmatch(x, '<div class="shorbox".-<a href="(.-)">(.-)<.-<img.-data%-src="(.-)"') do
       

          
          image = string.gsub(image, '^(.-)', HOME)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
   
   

   
        for image, total,  url, title in string.gmatch(x, '<div class="collect".-<img src="(.-)".-class="num">(.-)<.-class="namec".-<a href="(.-)">(.-)<') do
        
        image = string.gsub(image, '^(.-)', HOME)
		table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/genre=' .. url, image = image})
		
		end
		
        local genre = args.genre or ''
		local url = HOME .. genre
	--	if page > 1 then
			url = url
			--.. '/page/' .. tostring(page) .. '/'
	--	end
		local x = conn:load(url)
     --	local x = http.getz(url)
			for  url, title, image in string.gmatch(x, 'align="center".-<a href="(.-)".-alt="(.-)".-src="(.-)"') do
           image = string.gsub(image, '^(.-)', HOME)
          

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end	
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

--https://kinokrad.co/index.php?do=search&story=вий&search_start&dosearch
--results_from
--http://kinokrad.co/index.php?story=вой&do=search&subaction=search



	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'



      --   table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/4-serial/'})
        
        local x = conn:load(HOME)
      --  local x = http.getz(HOME)
        local x = string.match(x, '<div class="headermenu">(.-)</ul>')
		for genre, title in string.gmatch(x, '<li><a href="(/.-)".->(.-)</a>') do
		
       table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
        
        end

        local x = conn:load(HOME)
     --  	local x = http.getz(HOME)
        local x = string.match(x, '<div class="leftmenubox">(.-)<div class="leftbox%-comm%-ind"')
		for genre, title in string.gmatch(x, '<li><a href=.-//.-(/.-)".->(.-)</a>') do
		
        table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
        
        end


		
	--	local x = conn:load(HOME)
        
			
--"https://kinokrad.film/index.php?story=Рокки&do=search&subaction=search"
		
        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
	--	local url = HOME .. '/index.php?do=search&story=' .. urlencode(args.keyword) .. '&search_start=' .. '&results_from='
	--	local url = HOME .. '/index.php?do=search&story=' .. urlencode(args.keyword) .. '&search_start=' .. '/page/' .. tostring(page) .. '/'
--		local url = HOME .. '/index.php?story=' .. args.keyword .. '&do=search&subaction=search'  .. tostring(page) .. '/'


--https://kinokrad.film/index.php?story=рокки&do=search&subaction=search


    	local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'

    --    local x = http.post(url)
		
		local x = conn:load(url)
     --   local x = http.getz(HOME)
        
        

        
        
        for  url, title, image  in string.gmatch(x, '<div class="shorbox".-<a href="(.-)">(.-)<.-class="postershort".-<img.-data%-src="(.-)"') do
       

          
          image = string.gsub(image, '^(.-)', HOME)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
		
    --    local x = http.getz(args.id)
   --     x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="fulltext" id="fulltext" itemprop="description">(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</li>','(Жанр:</span>.-)</li>', '(Страна:</span>.-)</li>', '(Актерский состав:</span>.-)</div>'
		})





--http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https%3A%2F%2Fkinokrad.film%2F445901-myslit-kak-prestupnik-evolyuciya-1-sezon.html





--http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https://kinokrad.film/472289-reginald-the-vampire.html




         local x = http.getz('http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=' .. args.id)

    --    for  title in string.gmatch(x,'id=search","logo_30x30":"none"},{"title":"(.-)"') do
        
        
        
    --    for  title in string.gmatch(x, '"position":"html".-"br":1.-"logo_30x30":"none".-{"title":"(.-)"') do
        
      
       --  for  title in string.gmatch(x, '{"title":"(Novamedia)"') do

       -- for  title in string.gmatch(x, '{"title":"(LostFilm)"') do

      --  for  title in string.gmatch(x, '{"title":"(Coldfilm)"') do

       -- for  title in string.gmatch(x, '{"title":"(HamsterStudio)"') do

      -- for  title in string.gmatch(x, '{"title":"(Octopus)"') do
       
       


      --for  title in string.gmatch(x, '{"position":"list","preview":.-{"title":"(\\u041d\\u0435 \\u0442\\u0440\\u0435\\u0431\\u0443\\u0435\\u0442\\u0441\\u044f)"') do





--"logo_30x30":"none"},{"title":"(.-)","playlist_url":"submenu".-
        
        
        for title,  total, total1,  url, url1  in string.gmatch(x, '{"position":"list","preview":.-"title":"(.-u044f)(.-u043d)(.-)\\.-".-"parser":".-?id=file&u=(.-)(serial.-)"') do
   

       
   
        
        url = string.gsub(url, '\\', '')

      url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=file&u=') .. url1
   
         
         title = string.gsub(title, '\\u0441\\u0435\\u0440\\u0438\\u044f', 'Серия')
   
       total = string.gsub(total, '\\u0421\\u0435\\u0437\\u043e\\u043d', 'Сезон')
       
        

        
  --    table.insert(t, {title = url,mrl = '#stream/q=content&id=' .. url})

  --    end
        local x = http.getz(url)

   --      for total2, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
  --       print(url)
	--	 url = string.gsub(url, '\\', '')


    --   table.insert(t, {title = total .. (total1) .. (total2), mrl = url})
   --    end
       
      --   for total2, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
    --     print(url)
	--	 url = string.gsub(url, '\\', '')


   --    table.insert(t, {title = total .. (total1) .. (total2), mrl = url})

   --    end
        for  url in string.gmatch(x, '720p.-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title .. (total) .. (total1), mrl = url})

       end
       
       
     end
  --   end
  --   end
   --  end
  --   end
  --   end
    --  end
  --   end
  --   end
     
     
         local x = http.getz('http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=' .. args.id)
     
   --     for url in string.gmatch(x, '<meta property="og:url" content=".-//(.-)"') do
       -- url = string.gsub(url, '^(.-)', 'https://')
        
   --     url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https://')
        
        --table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
       --end
       
       
       
   --    local x = http.getz(url)
       
        for url, url1 in string.gmatch(x, '?id=search","logo_30x30":"none"},{"title":".-,"preview".-id=file&u=(.-)(movie.-)"') do
	




     url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=file&u=') .. url1
        
    --    table.insert(t, {title = url, mrl = url})
       
        local x = http.getz(url)

         for title, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
         for title, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
        for title, url in string.gmatch(x, '(720p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
     	end

 --   end
     
     
     local x = conn:load(args.id)
     
       for url, url1 in string.gmatch(x, '<ul class="film".-"(//.-svetacdn.in)(.-)"') do
          print(url)
		 url = string.gsub(url, '^(.-)', 'https:') .. url1


       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

       end
     
     
     
     
     
     
        for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(360p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
        
        
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
        
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       
       
        for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(480p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
  
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
  
  
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
  
      for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(720p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
  
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(1080p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
total1 = string.gsub(total1, '\\u0410', 'А')
      total1 = string.gsub(total1, '\\u0430', 'а')
       
       total1 = string.gsub(total1, '\\u0411', 'Б')
       total1 = string.gsub(total1, '\\u0431', 'б')  
       total1 = string.gsub(total1, '\\u0412', 'В')
      total1 = string.gsub(total1, '\\u0432', 'в')
       total1 = string.gsub(total1, '\\u0413', 'Г')
       total1 = string.gsub(total1, '\\u0433', 'г')  
      total1 = string.gsub(total1, '\\u0414', 'Д')
      total1 = string.gsub(total1, '\\u0434', 'д')
       total1 = string.gsub(total1, '\\u0415', 'Е')
       total1 = string.gsub(total1, '\\u0435', 'е')  
      total1 = string.gsub(total1, '\\u0401', 'Ё')
      total1 = string.gsub(total1, '\\u0451', 'ё')
       total1 = string.gsub(total1, '\\u0416', 'Ж')
       total1 = string.gsub(total1, '\\u0436', 'ж')  
       total1 = string.gsub(total1, '\\u0417', 'З')
      total1 = string.gsub(total1, '\\u0437', 'з')
       total1 = string.gsub(total1, '\\u0418', 'И')
       total1 = string.gsub(total1, '\\u0438', 'и')  
       total1 = string.gsub(total1, '\\u0419', 'Й')
      total1 = string.gsub(total1, '\\u0439', 'й')
       total1 = string.gsub(total1, '\\u041a', 'К')
       total1 = string.gsub(total1, '\\u043a', 'к')  
       total1 = string.gsub(total1, '\\u041b', 'Л')
       total1 = string.gsub(total1, '\\u043b', 'л')
       total1 = string.gsub(total1, '\\u041c', 'М')
       total1 = string.gsub(total1, '\\u043c', 'м')
       total1 = string.gsub(total1, '\\u041d', 'Н')
       total1 = string.gsub(total1, '\\u043d', 'н')
       total1 = string.gsub(total1, '\\u041e', 'О')
       total1 = string.gsub(total1, '\\u043e', 'о')
       total1 = string.gsub(total1, '\\u041f', 'П')
       total1 = string.gsub(total1, '\\u043f', 'п')
       total1 = string.gsub(total1, '\\u0420', 'Р')
       total1 = string.gsub(total1, '\\u0440', 'р')
       total1 = string.gsub(total1, '\\u0421', 'С')
       total1 = string.gsub(total1, '\\u0441', 'с')
       total1 = string.gsub(total1, '\\u0422', 'Т')
       total1 = string.gsub(total1, '\\u0442', 'т')
       total1 = string.gsub(total1, '\\u0423', 'У')
       total1 = string.gsub(total1, '\\u0443', 'у')
       total1 = string.gsub(total1, '\\u0424', 'Ф')
        total1 = string.gsub(total1, '\\u0444', 'ф')
        total1 = string.gsub(total1, '\\u0425', 'Х')
        total1 = string.gsub(total1, '\\u0445', 'х')
        total1 = string.gsub(total1, '\\u0426', 'Ц')
        total1 = string.gsub(total1, '\\u0446', 'ц')
        total1 = string.gsub(total1, '\\u0427', 'Ч')
        total1 = string.gsub(total1, '\\u0447', 'ч')
        total1 = string.gsub(total1, '\\u0428', 'Ш')
        total1 = string.gsub(total1, '\\u0448', 'ш')
        total1 = string.gsub(total1, '\\u0429', 'Щ')
        total1 = string.gsub(total1, '\\u0449', 'щ')
        total1 = string.gsub(total1, '\\u042a', 'Ъ')
        total1 = string.gsub(total1, '\\u044a', 'ъ')
        total1 = string.gsub(total1, '\\u042b', 'Ы')
        total1 = string.gsub(total1, '\\u044b', 'ы')
        total1 = string.gsub(total1, '\\u042c', 'Ь')
        total1 = string.gsub(total1, '\\u044c', 'ь')
        total1 = string.gsub(total1, '\\u042d', 'Э')
        total1 = string.gsub(total1, '\\u044d', 'э')
        total1 = string.gsub(total1, '\\u042e', 'Ю')
        total1 = string.gsub(total1, '\\u044e', 'ю')
        total1 = string.gsub(total1, '\\u042f', 'Я')
        total1 = string.gsub(total1, '\\u044f', 'я')
        total1 = string.gsub(total1, '\\u00ab', '<<')
        total1 = string.gsub(total1, '\\u00bb', '>>')
        total1 = string.gsub(total1, '\\u2014', '-')
  
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
	
		
       for title, url  in string.gmatch(x, 'movie.-%[(360p)](-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
     	 for title, url  in string.gmatch(x, 'movie.-%[(480p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
	for title, url  in string.gmatch(x, 'movie.-%[(720p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
		
        for title, url  in string.gmatch(x, 'movie.-%[(1080p)](.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
     
     
     
     
     
     
     
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end