-- kinokrad plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://kinokrad.film'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



--HOME = 'https://kinokrad.in'
--HOME = 'https://kinokrad.film'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinokrad plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinokrad plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	 table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	 
	-- #stream/page=2
	-- #stream/genre=/dokumentalny-3/
	-- #stream/genre=/filmy-2022-2/
	-- #stream/genre=/serial-6/
	-- #stream/genre=/russkie-2/
	-- #stream/genre=/3-uzhasy/
	-- #stream/genre=/uzhasy-online-1/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
        local x = conn:load(url)

        for  url, title, image  in string.gmatch(x, '<div class="shorbox".-<a href="(.-)">(.-)<.-<img.-data%-src="(.-)"') do
       

          
          image = string.gsub(image, '^(.-)', HOME)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
   
   

   
        for image, total,  url, title in string.gmatch(x, '<div class="collect".-<img src="(.-)".-class="num">(.-)<.-class="namec".-<a href="(.-)">(.-)<') do
        
        image = string.gsub(image, '^(.-)', HOME)
		table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/genre=' .. url, image = image})
		
		end
		
        local genre = args.genre or ''
		local url = HOME .. genre
	--	if page > 1 then
			url = url
			--.. '/page/' .. tostring(page) .. '/'
	--	end
		local x = conn:load(url)
     --	local x = http.getz(url)
			for  url, title, image in string.gmatch(x, 'align="center".-<a href="(.-)".-alt="(.-)".-src="(.-)"') do
           image = string.gsub(image, '^(.-)', HOME)
          

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end	
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

--https://kinokrad.co/index.php?do=search&story=вий&search_start&dosearch
--results_from
--http://kinokrad.co/index.php?story=вой&do=search&subaction=search



	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'



      --   table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/4-serial/'})
        
        local x = conn:load(HOME)
      --  local x = http.getz(HOME)
        local x = string.match(x, '<div class="headermenu">(.-)</ul>')
		for genre, title in string.gmatch(x, '<li><a href="(/.-)".->(.-)</a>') do
		
       table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
        
        end

        local x = conn:load(HOME)
     --  	local x = http.getz(HOME)
        local x = string.match(x, '<div class="leftmenubox">(.-)<div class="leftbox%-comm%-ind"')
		for genre, title in string.gmatch(x, '<li><a href=.-//.-(/.-)".->(.-)</a>') do
		
        table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
        
        end


		
	--	local x = conn:load(HOME)
        
			
--"https://kinokrad.film/index.php?story=Рокки&do=search&subaction=search"
		
        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
	--	local url = HOME .. '/index.php?do=search&story=' .. urlencode(args.keyword) .. '&search_start=' .. '&results_from='
	--	local url = HOME .. '/index.php?do=search&story=' .. urlencode(args.keyword) .. '&search_start=' .. '/page/' .. tostring(page) .. '/'
--		local url = HOME .. '/index.php?story=' .. args.keyword .. '&do=search&subaction=search'  .. tostring(page) .. '/'


--https://kinokrad.film/index.php?story=рокки&do=search&subaction=search


    	local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'

    --    local x = http.post(url)
		
		local x = conn:load(url)
     --   local x = http.getz(HOME)
        
        

        
        
        for  url, title, image  in string.gmatch(x, '<div class="shorbox".-<a href="(.-)">(.-)<.-class="postershort".-<img.-data%-src="(.-)"') do
       

          
          image = string.gsub(image, '^(.-)', HOME)

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
		
    --    local x = http.getz(args.id)
   --     x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="fulltext" id="fulltext" itemprop="description">(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</span>.-)</li>', '(Страна:</span>.-)</li>', '(Актерский состав:</span>.-)</div>'
		})




         



--http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https://kinokrad.film/472289-reginald-the-vampire.html




         local x = http.getz('http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=' .. args.id)

   --     for  title in string.gmatch(x,'id=search","logo_30x30":"none"},{"title":"(.-)"') do
        
        
        
    --    for  title in string.gmatch(x, '"position":"html".-"br":1.-"logo_30x30":"none".-{"title":"(.-)"') do
        
      
       --  for  title in string.gmatch(x, '{"title":"(Novamedia)"') do

       -- for  title in string.gmatch(x, '{"title":"(LostFilm)"') do

      --  for  title in string.gmatch(x, '{"title":"(Coldfilm)"') do

       -- for  title in string.gmatch(x, '{"title":"(HamsterStudio)"') do

      -- for  title in string.gmatch(x, '{"title":"(Octopus)"') do
       
       


      --for  title in string.gmatch(x, '{"position":"list","preview":.-{"title":"(\\u041d\\u0435 \\u0442\\u0440\\u0435\\u0431\\u0443\\u0435\\u0442\\u0441\\u044f)"') do

         


--"logo_30x30":"none"},{"title":"(.-)","playlist_url":"submenu".-
        
        
        for  total, url, url1  in string.gmatch(x, '{"position":"list","preview":.-"title":"(.-)".-"parser":".-?id=file&u=(.-)(serial.-)"') do
   

   
        
        url = string.gsub(url, '\\', '')

      url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=file&u=') .. url1
   
         

       total = string.gsub(total, '\\u0410', 'А')
      total = string.gsub(total, '\\u0430', 'а')
       
       total = string.gsub(total, '\\u0411', 'Б')
       total = string.gsub(total, '\\u0431', 'б')  
       total = string.gsub(total, '\\u0412', 'В')
      total = string.gsub(total, '\\u0432', 'в')
       total = string.gsub(total, '\\u0413', 'Г')
       total = string.gsub(total, '\\u0433', 'г')  
      total = string.gsub(total, '\\u0414', 'Д')
      total = string.gsub(total, '\\u0434', 'д')
       total = string.gsub(total, '\\u0415', 'Е')
       total = string.gsub(total, '\\u0435', 'е')  
      total = string.gsub(total, '\\u0401', 'Ё')
      total = string.gsub(total, '\\u0451', 'ё')
       total = string.gsub(total, '\\u0416', 'Ж')
       total = string.gsub(total, '\\u0436', 'ж')  
       total = string.gsub(total, '\\u0417', 'З')
      total = string.gsub(total, '\\u0437', 'з')
       total = string.gsub(total, '\\u0418', 'И')
       total = string.gsub(total, '\\u0438', 'и')  
       total = string.gsub(total, '\\u0419', 'Й')
      total = string.gsub(total, '\\u0439', 'й')
       total = string.gsub(total, '\\u041a', 'К')
       total = string.gsub(total, '\\u043a', 'к')  
       total = string.gsub(total, '\\u041b', 'Л')
       total = string.gsub(total, '\\u043b', 'л')
       total = string.gsub(total, '\\u041c', 'М')
       total = string.gsub(total, '\\u043c', 'м')
       total = string.gsub(total, '\\u041d', 'Н')
       total = string.gsub(total, '\\u043d', 'н')
       total = string.gsub(total, '\\u041e', 'О')
       total = string.gsub(total, '\\u043e', 'о')
       total = string.gsub(total, '\\u041f', 'П')
       total = string.gsub(total, '\\u043f', 'п')
       total = string.gsub(total, '\\u0420', 'Р')
       total = string.gsub(total, '\\u0440', 'р')
       total = string.gsub(total, '\\u0421', 'С')
       total = string.gsub(total, '\\u0441', 'с')
       total = string.gsub(total, '\\u0422', 'Т')
       total = string.gsub(total, '\\u0442', 'т')
       total = string.gsub(total, '\\u0423', 'У')
       total = string.gsub(total, '\\u0443', 'у')
       total = string.gsub(total, '\\u0424', 'Ф')
        total = string.gsub(total, '\\u0444', 'ф')
        total = string.gsub(total, '\\u0425', 'Х')
        total = string.gsub(total, '\\u0445', 'х')
        total = string.gsub(total, '\\u0426', 'Ц')
        total = string.gsub(total, '\\u0446', 'ц')
        total = string.gsub(total, '\\u0427', 'Ч')
        total = string.gsub(total, '\\u0447', 'ч')
        total = string.gsub(total, '\\u0428', 'Ш')
        total = string.gsub(total, '\\u0448', 'ш')
        total = string.gsub(total, '\\u0429', 'Щ')
        total = string.gsub(total, '\\u0449', 'щ')
        total = string.gsub(total, '\\u042a', 'Ъ')
        total = string.gsub(total, '\\u044a', 'ъ')
        total = string.gsub(total, '\\u042b', 'Ы')
        total = string.gsub(total, '\\u044b', 'ы')
        total = string.gsub(total, '\\u042c', 'Ь')
        total = string.gsub(total, '\\u044c', 'ь')
        total = string.gsub(total, '\\u042d', 'Э')
        total = string.gsub(total, '\\u044d', 'э')
        total = string.gsub(total, '\\u042e', 'Ю')
        total = string.gsub(total, '\\u044e', 'ю')
        total = string.gsub(total, '\\u042f', 'Я')
        total = string.gsub(total, '\\u044f', 'я')
        total = string.gsub(total, '\\u00ab', '<<')
        total = string.gsub(total, '\\u00bb', '>>')
        total = string.gsub(total, '\\u2014', '-')
        
        

        
   --   table.insert(t, {title = url,mrl = '#stream/q=content&id=' .. url})

   --   end
     local x = http.getz(url)

   --      for total2, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
  --       print(url)
	--	 url = string.gsub(url, '\\', '')


    --   table.insert(t, {title = total .. (total1) .. (total2), mrl = url})
   --    end
       
      --   for total2, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
    --     print(url)
	--	 url = string.gsub(url, '\\', '')


   --    table.insert(t, {title = total .. (total1) .. (total2), mrl = url})

   --    end
        for  url in string.gmatch(x, '720p.-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = total, mrl = url})

       end
       
       
      end
  --   end
  --   end
   --  end
  --   end
  --   end
    --  end
  --   end
  --   end
     
     
         local x = http.getz('http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=' .. args.id)
     
   --     for url in string.gmatch(x, '<meta property="og:url" content=".-//(.-)"') do
       -- url = string.gsub(url, '^(.-)', 'https://')
        
   --     url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https://')
        
        --table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
       --end
       
       
       
   --    local x = http.getz(url)
       
        for url, url1 in string.gmatch(x, '?id=search","logo_30x30":"none"},{"title":".-,"preview".-id=file&u=(.-)(movie.-)"') do
	




     url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=file&u=') .. url1
        
    --    table.insert(t, {title = url, mrl = url})
       
        local x = http.getz(url)

         for title, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
         for title, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
        for title, url in string.gmatch(x, '(720p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
     	end

 --   end
     
     
     
     
     
     
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end