-- filmhd.newmulti-torrent.ru plugin

require('support')
require('video')
require('parser')
--require('magnet')
--require('url')
require('client')

--https://ts.moviecorn.one/stream/he Crow (2024).mkv?link=63FC204C90D4621FF2A70E6A8887224B68012A85&index=1&play&hitid=

--https://rutracker.net/forum/viewtopic.php?t=6568688



--https://ts.moviecorn.one/stream/.Меган К вашим услугам.WEB-DLRip.HDRezka Studio.Меган%20К%20вашим%20услугам.WEB-DLRip.by.Сибиряк.avi?link=A4071A2F93AA46411323BB46DA2EFC34F80818A4&index=1&play&hitid=

local HOME = 'https://rutracker.net'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'Windows-1251'
conn['root'] = HOME_SLASH




--https://rutracker.net/forum/viewtopic.php?t=6558757


--HOME = 'http://nnm-club.me'
--HOME = 'https://rutracker.net'


--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from filmhd.newmulti-torrent.ru plugin')
	return 1
end

function onUnLoad()
	print('Bye from filmhd.newmulti-torrent.ru plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=2
	-- #stream/page=100
	-- #stream/page=50
	-- #stream/genre=/forum/portal.php?c=11&start=
	-- #stream/genre=/forum/viewtopic.php?t=6475216

	if not args.q then
 
 	local page = tonumber(args.page or 0)
		local genre = args.genre or '/forum/viewforum.php?f=252'
     --   local offset = (page - 1) * 13 + 1
	--	for  i= 1, 2 do
        
--tolazy(title)

  
  
--	page = tonumber(page)
		

		local url = HOME .. genre
		if page > 1 then
			url = url .. '&start=' .. tostring(page)
			--+ i - 1) 
			--.. '#pagestart'
		end 
       -- local x = http.getz(HOME .. '/')
   --     local x = http.get(url)
        
       local x = conn:load(url)
        
        
      --  x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
         for url, title in string.gmatch(x, '<div class="torTopic".-<a id="tt.-href="(.-)" class="torTopic bold tt%-text">(.-)</a>') do
			url = string.gsub(url, '^(.-)', HOME .. '/forum/')
           -- image = string.gsub(image, '^/', HOME_SLASH)
           
         t['view']='simple'
           
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	--	end
	


	 --     for url, title in string.gmatch(x, '<tr id=".-class="hl%-tr".-<td class="vf%-col%-t%-title tt".-class="topictitle".-<a id=".-href="(.-)" class="topictitle tt%-text">(.-)</a>') do 
	
--	url = string.gsub(url, '^(.-)', '/forum/')
--	t['view']='simple'
           
	--		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
	--	end



		
    --   for title, url in string.gmatch(x, '<span class="post%-b">(.-)</span.-<a href="(.-)"') do
	--		url = string.gsub(url, '^(.-)', HOME .. '/forum/')
           -- image = string.gsub(image, '^/', HOME_SLASH)
           
      --   t['view']='simple'
           
	--		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		
		
		
		
		local url = '#stream/page=' .. tostring(page + 50) .. '&genre=' .. genre 
 --.. '&start=' .. tostring(page + 50)

        table.insert(t,{title = 'далее', mrl = url, image = '#self/next.png'})

	
	
--	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

--#folder/page=2&genre=/forum/viewforum.php?f=252

--#stream/page=51&genre=/forum/viewforum.php?f=252&start=51
		
	-- #folder/q=genres
    elseif args.q == 'genres' then
		t['view']='simple'
		t['message']='@string/genres'

	
        local x = conn:load(HOME)

--https://rutracker.net/forum/index.php?c=2





--https://rutracker.net/forum/viewforum.php?f=1640
       
   --    table.insert(t, {title = 'Тематические подборки ссылок', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1640'})
    


       table.insert(t, {title = 'Класика мирового кинематографа', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=187'})

       table.insert(t, {title = 'Зарубежное кино до 90', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2090'})
    

       table.insert(t, {title = 'Зарубежное кино 1991-2000', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2221'})
       

       table.insert(t, {title = 'Зарубежное кино 2001-2005', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2091'})
       

       table.insert(t, {title = 'Зарубежное кино 2011-2015', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2093'})
       
       
       table.insert(t, {title = 'Зарубежное кино 2016-2020', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2200'})

       table.insert(t, {title = 'Зарубежное кино 2021-2023', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1950'})
       
       table.insert(t, {title = 'Зарубежное кино 2024', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=252'})
       
       
	   table.insert(t, {title = 'Зарубежное кино HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=313'})
	   
	   
      table.insert(t, {title = 'Зарубежное кино UHD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1457'}) 
    

      table.insert(t, {title = 'Фильмы ближнего зарубежья', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2540'}) 
    

    table.insert(t, {title = 'Азиатские фильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=934'})
    table.insert(t, {title = 'Азиатские фильмы HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2201'})
    
    table.insert(t, {title = 'Индийские фильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=505'}) 
    
     table.insert(t, {title = 'Индийские фильмы HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=140'}) 
    
    
 --    table.insert(t, {title = 'Закадровые дорожки и переводы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=185'}) 
     

         
  --   table.insert(t, {title = 'Авторский перевод', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1454'}) 
     
  --   table.insert(t, {title = 'Закадровый перевод', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2374'}) 
   

   --    table.insert(t, {title = 'Зарубежные актеры и фильмы с их участием', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=254'}) 
   
     
  --   table.insert(t, {title = 'Зарубежные режиссёры и их творчество', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=771'}) 
     
    table.insert(t, {title = 'Кино СССР', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=941'}) 
   

     table.insert(t, {title = 'Детские отечественные фильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1666'}) 
      
      
      

       table.insert(t, {title = 'Наше кино HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=312'}) 
   
       table.insert(t, {title = 'Наше кино UHD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1940'}) 
   
      table.insert(t, {title = 'Отечественные полнометражные мультфильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=539'}) 
      
       table.insert(t, {title = 'Отечественные мультфильмы (HD Video)', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2343'}) 

    table.insert(t, {title = 'Иностранные мультфильмы (HD Video)', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=930'}) 

    table.insert(t, {title = 'Иностранные мультфильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=209'}) 

       table.insert(t, {title = 'мультфильмы UHD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=84'}) 
    --  	   table.insert(t, {title = 'Документальные HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=314'})
       
       
--	http://stvplay.mooo.com:81/torrents/rutrack.php?search=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%201979	
        
    	
    	
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = 'http://stvplay.mooo.com:81/torrents/rutrack.php?search=' .. urlencode(args.keyword) 
		--.. tostring(page)

        local x = http.get(url)
	--	local x = conn:load(url)
		
        for title, url in string.gmatch(x, '</channel.-<channel>.-<title>.-%[CDATA%[(.-)].-%[CDATA%[http.-?.-=(.-)]') do


       url = string.gsub(url, '^(.-)', HOME .. '/forum/viewtopic.php?t=')
	--	image = string.gsub(image, '^/', HOME_SLASH1)
         t['view']='simple'
	
    --	local x = http.get(url)
    --	table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
    	
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
   --   end
    
    
    
 --   	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
--		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
    	
    	
    	
    	
    	
    	
	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		
		
        local x = conn:load(args.id)
--		local x = http.getz(args.id)
    --    x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
--		t['ref'] = args.id
        t['name'] = parse_match(x,'<span style="font%-size:.->(.-)</span>')
		t['description'] = parse_match(x, 'Описание</span>:<br>(.-)<span')
		
		--	t['poster'] = args.p
		t['poster'] = parse_match(x, '<var class="postImg postImgAligned img%-right" title="(.-)"')

		
	    	t['annotation'] = parse_array(x, {'(Страна</span>:.-)<br>', 
			'(Жанр</span>:.-)<br>',
			'(Год выпуска</span>:.-)<br>',
			'(Режиссер</span>:.-)<br>',
		
			'(В ролях</span>:.-)</br>',})
			

			
			
      
     --   local x = http.get(url)
     

   --      for title, image, url in string.gmatch(x, '<channel>.-<title>.-%[CDATA%[(.-)].-<img class="postImg postImgAligned img%-right.-src=.-(http.-png).-<div class="clear".-<a href=.-(viewtopic.-)"') do
      
    --    url = string.gsub(url, '^(.-)', HOME .. '/forum/')
       
   --    	table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
   --   end
      
      
     
	    --addvideo(t, url, t['name'])
 
 
 
    --   local x = http.getz(args.id)
       
    	for title in string.gmatch(x, '<a href="magnet.-btih:(.-)&') do
    
    
       url = string.gsub(title, '^(.-)', 'https://ts.moviecorn.one/stream/?link=') .. '&index=1&play&hitid='
  

    
    url = string.gsub(url, '_от ', '.')
     url = string.gsub(url, ' ', '%%20')
    
    table.insert(t, {title = 'Смотреть', mrl = url})

		end
  

	elseif args.q == 'url' then
       -- return {view = 'open with', label = args.t, mrl = url, seekable = 'true', direct = 'true'}  
    --   return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
		return video(args.url, args)
	end
	return t
end
    