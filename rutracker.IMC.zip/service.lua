-- filmhd.newmulti-torrent.ru plugin

require('support')
require('video')
require('parser')
--require('magnet')
--require('url')
require('client')

--https://ts.moviecorn.one/stream/?link=2D27A24D85A6FDF12AB50BB99FEE5DCEAAAAE18A&index=62&play&hitid=

--local last = l[ #l ]
--last[ #last+1 ] = 9
--Также существует table.insert функция, --которая по умолчанию добавляется в конец --последовательности:

--table.insert( l[ #l ], 9 )



--6M2RB39-M5Q4ZN1-JP7Q25T-FWK4S7B

--Есть страница <a href="/wiki/%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA_%D1%8D%D0%BF%D0%B8%D0%B7%D0%BE%D0%B4%D0%BE%D0%B2_%D1%82%D0%B5%D0%BB%D0%B5%D1%81%D0%B5%D1%80%D0%B8%D0%B0%D0%BB%D0%B0_%C2%AB%D0%92%D0%BB%D0%B0%D1%81%D1%82%D0%B5%D0%BB%D0%B8%D0%BD_%D0%BA%D0%BE%D0%BB%D0%B5%D1%86:_%D0%9A%D0%BE%D0%BB%D1%8C%D1%86%D0%B0_%D0%B2%D0%BB%D0%B0%D1%81%D1%82%D0%B8%C2%BB"

--https://rutracker.net/forum/viewtopic.php?t=6027801

--https://api.rutracker.cc/v1/get_post_text?by=topic_id&val=6027801

--https://api.rutracker.cc/v1/get_archived_tor_data_get?by=topic_id&val=6560291


--https://api.rutracker.cc/v1/docs/swagger.json

--https://ts.moviecorn.one/stream/?link=F07C8F2F538806372B07C866223BC83DA61946BF&index=2&play&hitid=4010

--https://rutracker.org/forum/viewtopic.php?t=3517503

--https://api.rutracker.cc/v1/get_tor_hash?by=topic_id&val=6560291

--https://api.rutracker.cc/v1/get_peer_stats?by=hash&val=f41b8c7a091cf5aa6826d8eb3cbe14b562ab3783

--https://instant.io#f41b8c7a091cf5aa6826d8eb3cbe14b562ab3783

--https://api.rutracker.cc/v1/get_topic_id?by=hash&val=f41b8c7a091cf5aa6826d8eb3cbe14b562ab3783

--https://api.rutracker.cc/v1/get_tor_topic_data?by=topic_id&val=6027801


--https://api.rutracker.cc/v1/get_tor_status_titles?by=hash&val=f41b8c7a091cf5aa6826d8eb3cbe14b562ab3783

--4485518

--https://api.rutracker.cc/v1/get_tor_topic_data?by=topic_id&val=2947121
--https://rutracker.org/forum/viewtopic.php?t=2947121

--https://api.rutracker.cc/v1/docs/

--//bigpkcqnm.tevas.tech/kino/download/Temnaya_istoriya_2024.mp4

--src="//bigpkcqnm.tevas.tech/kino/download/top/Voron_2024.mp4


--https://rutracker.net/forum/viewforum.php?f=252

local HOME = 'https://rutracker.net'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'Windows-1251'
conn['root'] = HOME_SLASH




--https://rutracker.net/forum/viewtopic.php?t=6558757


--HOME = 'http://nnm-club.me'
--HOME = 'https://rutracker.net'


--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from filmhd.newmulti-torrent.ru plugin')
	return 1
end

function onUnLoad()
	print('Bye from filmhd.newmulti-torrent.ru plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=2
	-- #stream/page=100
	-- #stream/page=50
	-- #stream/genre=/forum/portal.php?c=11&start=
	-- #stream/genre=/forum/viewtopic.php?t=6475216

	if not args.q then
 
 	local page = tonumber(args.page or 0)
		local genre = args.genre or '/forum/viewforum.php?f=252'
     --   local offset = (page - 1) * 13 + 1
	--	for  i= 1, 2 do
        
--tolazy(title)

  
  
--	page = tonumber(page)
		

		local url = HOME .. genre
		if page > 1 then
			url = url .. '&start=' .. tostring(page)
			--+ i - 1) 
			--.. '#pagestart'
		end 
       -- local x = http.getz(HOME .. '/')
   --     local x = http.get(url)
        
       local x = conn:load(url)
        
        
      --  x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
         for url, title in string.gmatch(x, '<div class="torTopic".-<a id="tt.-href="(.-)" class="torTopic bold tt%-text">(.-)</a>') do
			url = string.gsub(url, '^(.-)', HOME .. '/forum/')
           -- image = string.gsub(image, '^/', HOME_SLASH)
           
         t['view']='simple'
           
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	--	end
	


	  --    for url, title in string.gmatch(x, 'class="topictitle".-<a id=".-href="(viewforum.-)" class="topictitle tt%-text">(.-)</a>') do 
	--	url = string.gsub(url, '^(.-)', '/forum/')
     --	t['view']='simple'
           
	--		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
	--	end



		
    --   for title, url in string.gmatch(x, '<span class="post%-b">(.-)</span.-<a href="(viewforum.-)"') do
	--		url = string.gsub(url, '^(.-)', HOME .. '/forum/')
           -- image = string.gsub(image, '^/', HOME_SLASH)
           
       --  t['view']='simple'
           
	--		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		
		
		for url, title, image  in string.gmatch(x, '<span class="topictitle".-<a.-href="(viewtopic.-)" class="topictitle tt%-text">(.-)</a>.-<img src="(.-)"') do
	
     	t['view']='simple'
     	
		table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. '/forum/' .. url, image = image})
		end
	
		local url = '#stream/page=' .. tostring(page + 50) .. '&genre=' .. genre 
 --.. '&start=' .. tostring(page + 50)

        table.insert(t,{title = 'далее', mrl = url, image = '#self/next.png'})

	
	
--	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

--#folder/page=2&genre=/forum/viewforum.php?f=252

--#stream/page=51&genre=/forum/viewforum.php?f=252&start=51
		
	-- #folder/q=genres
    elseif args.q == 'genres' then
		t['view']='simple'
		t['message']='@string/genres'

	
        local x = conn:load(HOME)

--https://rutracker.net/forum/index.php?c=2



--https://rutracker.net/forum/viewforum.php?f=1640

--https://rutracker.net/forum/viewforum.php?f=1640
       
     --  table.insert(t, {title = 'Тематические подборки ссылок', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1640'})
    


       table.insert(t, {title = 'Класика мирового кинематографа', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=187'})

       table.insert(t, {title = 'Зарубежное кино до 90', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2090'})
    

       table.insert(t, {title = 'Зарубежное кино 1991-2000', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2221'})
       

       table.insert(t, {title = 'Зарубежное кино 2001-2005', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2091'})
       

       table.insert(t, {title = 'Зарубежное кино 2011-2015', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2093'})
       
       
       table.insert(t, {title = 'Зарубежное кино 2016-2020', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2200'})

       table.insert(t, {title = 'Зарубежное кино 2021-2024', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1950'})
       
   --    table.insert(t, {title = 'Зарубежное кино 2024', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=252'})
       
       table.insert(t, {title = 'Зарубежное кино 2025', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=252'})
       
	   table.insert(t, {title = 'Зарубежное кино HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=313'})
	   
	   
      table.insert(t, {title = 'Зарубежное кино UHD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1457'}) 
    

      table.insert(t, {title = 'Фильмы ближнего зарубежья', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2540'}) 
  
    table.insert(t, {title = 'Звуковые дорожки и переводы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=185'}) 



    table.insert(t, {title = 'Азиатские фильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=934'})
    table.insert(t, {title = 'Азиатские фильмы HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2201'})
    
    table.insert(t, {title = 'Индийские фильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=505'}) 
    
     table.insert(t, {title = 'Индийские фильмы HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=140'}) 
    
    
    table.insert(t, {title = 'Сборники фильмов', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=212'}) 
     

         
  --   table.insert(t, {title = 'Авторский перевод', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1454'}) 
     
  --   table.insert(t, {title = 'Закадровый перевод', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2374'}) 
   

   --    table.insert(t, {title = 'Зарубежные актеры и фильмы с их участием', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=254'}) 
   
     
 --   table.insert(t, {title = 'Зарубежные режиссёры и их творчество', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=771'}) 
     
    table.insert(t, {title = 'Кино СССР', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=941'}) 
   

     table.insert(t, {title = 'Детские отечественные фильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1666'}) 
      
      
      

       table.insert(t, {title = 'Наше кино HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=312'}) 
   
       table.insert(t, {title = 'Наше кино UHD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1940'}) 
   
      table.insert(t, {title = 'Отечественные полнометражные мультфильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=539'}) 
      
       table.insert(t, {title = 'Отечественные мультфильмы (HD Video)', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=2343'}) 

    table.insert(t, {title = 'Иностранные мультфильмы (HD Video)', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=930'}) 

    table.insert(t, {title = 'Иностранные мультфильмы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=209'}) 

       table.insert(t, {title = 'мультфильмы UHD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=84'}) 
      	   table.insert(t, {title = 'Мультсериалы', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=921'})
       table.insert(t, {title = 'Мультсериалы HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=1460'})
       
       table.insert(t, {title = 'Новинки и сериалы в стадии показа', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=842'})
     
  
      table.insert(t, {title = 'Зарубежные сериалы HD', mrl = '#stream/genre=' .. '/forum/viewforum.php?f=119'})
  

 --   http://megapeer.vip/torrent/181357/vsjo-zakonchitsya-na-nas_it-ends-with-us-2024-web-dl-1080p-d-moviedalen 
       
--	http://stvplay.mooo.com:81/torrents/megapeer.php?fid=181357	
        
  --  http://stvplay.mooo.com:81/torrents/rutrack.php?fid=5553228
    	
         local x = conn:load(HOME .. '/forum/index.php?c=20')	
         

         
    	x = string.match(x, 'Документальные.-DVD.->(.-)</p>')
      for genre, title in string.gmatch(x,'<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. '/forum/' .. genre})
		end
    	
--https://rutracker.net/forum/index.php?c=20
    	
    	
    	
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = 'http://stvplay.mooo.com:81/torrents/rutrack.php?search=' .. urlencode(args.keyword) 
		--.. tostring(page)

        local x = http.get(url)
	--	local x = conn:load(url)
		
        for title, url in string.gmatch(x, '</channel.-<channel>.-<title>.-%[CDATA%[(.-)].-%[CDATA%[http.-?.-=(.-)]') do


       url = string.gsub(url, '^(.-)', HOME .. '/forum/viewtopic.php?t=')
	--	image = string.gsub(image, '^/', HOME_SLASH1)
         t['view']='simple'
	
    --	local x = http.get(url)
    --	table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
    	
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
   --   end
    
    
    
 --   	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
--		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
    	
    	
    	
    	
    	
    	
	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		
		
        local x = conn:load(args.id)
--		local x = http.getz(args.id)
    --    x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
--		t['ref'] = args.id
        t['name'] = parse_match(x,'<span style="font%-size:.->(.-)</span>')
		t['description'] = parse_match(x, '(Описание</span>:.-)<')



		
		--	t['poster'] = args.p
		
    	 
		t['poster'] = parse_match(x, 'class="postImg.-="(http.-)"')
         
		
		
		
	    	t['annotation'] = parse_array(x, {'(Страна</span>:.-)<br>', 
			'(Жанр</span>:.-)<br>',
			'(Год выпуска</span>:.-)<br>',
			'(Режиссер</span>:.-)<br>',
		
			'(В ролях</span>:.-)</br>',})
			

      for title in string.gmatch(x, '<a href="magnet.-btih:(.-)&') do


      title = string.lower(title)
      
     url = string.gsub(title, '^(.-)', 'https://ts.moviecorn.one/stream/file.m3u?link=') .. '&m3u'
   

  --  t['view']='simple'
  
   --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
      
   --   end
  --  table.insert(t, {title = title, mrl = url})
        
    
       local x = http.get(url)
   
    
      for title, url  in string.gmatch(x, 'EXTINF:.-,(.-)(http.-play)') do
    
     	table.insert(t, {title = title, mrl = url .. '&hitid='})

         end
        end
     
     
     
     
     
         
      
        for url in string.gmatch(x, '<a href="https://www.kinopoisk.ru/.-/(.-)/"') do
  
  
          print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Zagonka плеер', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-(//video.zagonka.org/movies/.-})') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
			
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
		
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end
       





	elseif args.q == 'url' then
       -- return {view = 'open with', label = args.t, mrl = url, seekable = 'true', direct = 'true'}  
    --   return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
		return video(args.url, args)
	end
	return t
end
    