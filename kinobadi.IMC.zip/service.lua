-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--https://api.embess.ws/embed/movie/486

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


--https://kinobadi.mom/film/?sort=-views&type=films&collection_id=80

--https://kinobadi.mom/film/?sort=-views&type=films&collection_id=80

local HOME = 'https://kinobadi.mom'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




  
function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

-- #stream/genre=/film/?genre_id=41


	-- #stream/page=2
	-- #stream/genre=/year/2020/



	if not args.q then
	
--https://kinobadi.mom/film/?page=2
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/film/?'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '&page=' .. tostring(page)
		
		end
		
		if genre == '/film/top.php?' then
		
			url = HOME .. genre .. 'p=' .. tostring(page)
		end
		
        local x = conn:load(url)
 
 
 

 
         
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
	
	
	for url, image, title in string.gmatch(x, '<div class="v vi p".-<img.-src=.-?id=(.-)&img=(http.-jpg).-class ="p_title_film".->(.-)</span>') do
	
--		for url, image, title in string.gmatch(x, '<a onclick="perehod2.-href=.-file.-<img.-src=.-?id=(.-)&img=(http.-jpg).-class ="p_title_film".->(.-)</span>') do
     --    url = string.gsub(url, '.php', '') 
   --    url = string.gsub(url, '?id=', '-') 
--https://kinobadi.mom/hd_pars/pleer_on.php?url&id_file=1426
         
       url = string.gsub(url, '^(.-)', HOME.. '/film/file-')
    
        
         table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})

		end
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
    
 --   https://kinobadi.mom/film/top.php
    table.insert(t, {title = 'Топ сегодня', mrl = '#stream/genre=' .. '/film/top.php?'})

--https://kinobadi.mom/film/top-2024.html
 

     local x = conn:load(HOME .. '/film/')
		
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, 'Выберите год(.-)</select>')
		for genre, title in string.gmatch(x, '<option VALUE=".-year=(.-)&.->(.-)</option>') do
			table.insert(t, {title = 'Топ Фильмы : ' .. title, mrl = '#stream/genre=' .. '/film/top-' .. genre .. '.html?'})
		end




         local x = conn:load(HOME .. '/film/')
		
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, 'Все жанры(.-)window.location.href')
		for genre, title in string.gmatch(x, '<option VALUE=".-(genre_id=.-)&.->(.-)</option>') do
			table.insert(t, {title = 'Фильмы : ' .. title, mrl = '#stream/genre=' .. '/film/?' .. genre})
		end
    
    table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/film/?type=cartoon'})
    
table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/film/?type=anime'})
   
   
   
   
   
   
    
       local x = conn:load(HOME .. '/film/')
		
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, 'Все подборки(.-)window.location.href')
		for genre, title in string.gmatch(x, '<option VALUE=".-(collection_id=.-)".->(.-)</option>') do
			table.insert(t, {title = 'Фильмы : ' .. title, mrl = '#stream/genre=' .. '/film/?' .. genre})
		end
		
    
    
        local x = conn:load(HOME .. '/film/')
		
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, 'Все страны(.-)window.location.href')
		for genre, title in string.gmatch(x, '<option VALUE=".-(country_id=.-)".->(.-)</option>') do
			table.insert(t, {title = 'Фильмы : ' .. title, mrl = '#stream/genre=' .. '/film/?' .. genre})
		end
        
        
        
  --   local x = conn:load(HOME .. '/film/?type=serials')
		
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
	--	local x = string.match(x, 'Все жанры(.-)window.location.href')
--		for genre, title in string.gmatch(x, '<option VALUE=".-(genre_id=.-)&.->(.-)</option>') do
	--		table.insert(t, {title = 'Сериалы : ' .. title, mrl = '#stream/genre=' .. '/film/?type=serials&' .. genre})
	--	end
       
--https://kinobadi.mom/film/?type=serials
    table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/film/?type=serials'})
    
    table.insert(t, {title = 'Мультсериалы', mrl = '#stream/genre=' .. '/film/?type=cartoon-serials'})
    
    table.insert(t, {title = 'Анимесериалы', mrl = '#stream/genre=' .. '/film/?type=anime-serials'})
  
       
  --   local x = conn:load(HOME .. '/film/?type=serials')
       
   --    local x = string.match(x, 'Все подборки(.-)window.location.href')
--		for genre, title in string.gmatch(x, '<option VALUE=".-(collection_id=.-)".->(.-)</option>') do
	--		table.insert(t, {title = 'Сериалы : ' .. title, mrl = '#stream/genre=' .. '/film/?type=serials&' .. genre})
	--	end
       
       
   --   local x = conn:load(HOME .. '/film/?type=serials')
   --   local x = string.match(x, 'Все страны(.-)window.location.href')
	--	for genre, title in string.gmatch(x, '<option VALUE=".-(country_id=.-)".->(.-)</option>') do
	--		table.insert(t, {title = 'Сериалы : ' .. title, mrl = '#stream/genre=' .. '/film/?type=serials&' .. genre})
	--	end


--https://kinobadi.mom/film/poisk.php?do=search&subaction=search&q=%D0%A0%D0%BE&search=%D0%9F%D0%BE%D0%B8%D1%81%D0%BA





    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/film/poisk.php?do=search&subaction=search&q=' .. urlencode(args.keyword) 
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<a href=.-/film/poisk(.-)".-<img.-src=.-(http.-jpg).-class ="p_title_film".->(.-)</span>') do
          
       url = string.gsub(url, '^(.-)', HOME.. '/film/file')
    --   image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
  --  	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
--		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  





		
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	
	--	local x = http.get(args.id)
       local x = conn:load(args.id)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
--		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		
     t['name'] = parse_match(x,'<meta charset=.-<title>(.-)Смотреть')
		
	

    --    t['description'] = parse_match(x,'<meta property="og:description" content=.-mp4 %.(.-)"')
		
		t['description'] = parse_match(x,'<p itemprop="articleBody">(.-)</p>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end


t['annotation'] = parse_array(x, {
			'<meta property="og:description" content="(.-)Длительность'
		})
		
	--	t['annotation'] = parse_array(x, {
		--	'(Страна:</td>.-)</td>','(Жанр:</td>.-)</td>', '(Режиссер:</td>.-)</td>', '(Актёры:</td>.-)</td>', '(Режиссер:</span>.-)</div>',
	--		'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
--		})
		


		
--https://kinomobi.net/tor.php?id=18266.html
     


    --  url = string.gsub(title, '^(.-)', 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=') .. '&year=' .. title1 .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
  
  --   local x = conn:load(url)
     
      
 --   for title3 in string.gmatch(x, 'docs.-{"id":(.-),.-name":"(.-)"') do
    
   
   
   
   
   
   
  --   for title in string.gmatch(x, '<link rel="canonical" href="http.-file%-(.-)"') do
   
 --    url = string.gsub(title, '^(.-)', HOME .. '/hd_pars/pleer_on.php?url&id_file=')
  
    --   local x = conn:load(url)
  
  --   https://kinobadi.mom/hd_pars/pleer_on.php?url&id_file=1426
     
--?kp=21503&
     
     
 --    for title3 in string.gmatch(x, '?kp=(.-)&') do
     
    
    
    
    
    
   for title, title1 in string.gmatch(x, '<meta charset=.-<title>(.-) %((.-)%)') do
      
     title = urlencode(title)
      
     title = string.gsub(title, '+', '%%20')
	
     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
      
     
    
url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/lumex?kinopoisk_id=') 
       --.. '&uid=m7alois3'
 
   table.insert(t, {title = 'Lumex', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
         end
   -- local x = conn:load(url1)
    
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
 -- table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p)lumex :' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '3600/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p)lumex :' .. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p)lumex :' .. tolazy(total), mrl = url3})
       
    end
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
    
     local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"http.-(http.-mp4)') do
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url5})

       
    end
end
end
end
    
     
     
     
     
     
    for title, title1 in string.gmatch(x, '<meta charset=.-<title>(.-) %((.-)%)') do
      
     title = urlencode(title)
      
     title = string.gsub(title, '+', '%%20')
	
     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
      
   
    
     
     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 
 
    table.insert(t, {title = 'Hdvb', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
     end
     
       for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   
      local x = conn:load(url2 .. url3)

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :' .. tolazy(total2), mrl = url4})

      end 
      end
      

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end
     











      for title, title1 in string.gmatch(x, '<meta charset=.-<title>(.-) %((.-)%)') do
      
     title = urlencode(title)
      
     title = string.gsub(title, '+', '%%20')
	
     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
      


   url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=') 

    
      table.insert(t, {title = 'Zetflix', mrl = '#stream/q=content&id=' .. url1, image = image})
    
    end
    end
    
for  total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-hidxlglk.-class="videos__item%-title">(.-)</div>') do
  
  
     local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-m3u8)"') do
      
      url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')

      
      
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
    
        for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"http.-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
  
      url4 = string.gsub(url4, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end
end
end
  
  
  
  
  
      for title, title1 in string.gmatch(x, '<meta charset=.-<title>(.-) %((.-)%)') do
      
     title = urlencode(title)
      
     title = string.gsub(title, '+', '%%20')
	
     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
      
     url1 = string.gsub(title3, '^(.-)', 'http://lampa.vip/lite/videodb?kinopoisk_id=')
     --.. '&title=' .. title .. '&year=' .. title1 
  
  table.insert(t, {title = 'Videodb', mrl = '#stream/q=content&id=' .. url1, image = image})
		end
    end
    
   --   local x = conn:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://s1.lampa.vip')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://s1.lampa.vip') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://s1.lampa.vip') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://s1.lampa.vip')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end








for title, title1 in string.gmatch(x, '<meta charset=.-<title>(.-) %((.-)%)') do
      
     title = urlencode(title)
      
     title = string.gsub(title, '+', '%%20')
	
     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do

url1 = string.gsub(title3, '^(.-)', 'http://lampa.vip/lite/vokino?kinopoisk_id=') 

--.. '&balancer=filmix'

table.insert(t, {title = 'filmix+', mrl = '#stream/q=content&id=' .. url1, image = image})
end
end


     for url2 in string.gmatch(x, 'class="videos__line".-class="videos__item videos.-"method":"link","url":"(http.-)\\u0026balancer') do

    url2 = string.gsub(url2, '\\u0026', '&')
    
 --   table.insert(t, {title = url2 .. url3, mrl = '#stream/q=content&id=' .. url2 .. url3, image = image})
    
     local x = conn:load(url2 .. '&balancer=vokino')



     for url3, title in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do
       url3 = string.gsub(url3, '^(.-)', 'http://s2.lampa.vip')

    t['view'] = 'simple'

    table.insert(t, {title = title, mrl = url3})

 end
end







      for url2 in string.gmatch(x, 'class="videos__line".-class="videos__item videos.-"method":"link","url":"(http.-)\\u0026balancer') do

    url2 = string.gsub(url2, '\\u0026', '&')

       local x = conn:load(url2 .. '&balancer=alloha')

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do

      url4 = string.gsub(url4, '^(.-)', 'http://s2.lampa.vip') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do

      url5 = string.gsub(url5, '^(.-)', 'http://s2.lampa.vip') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end

end







    for url2 in string.gmatch(x, 'class="videos__line".-class="videos__item videos.-"method":"link","url":"(http.-)\\u0026balancer') do

    url2 = string.gsub(url2, '\\u0026', '&')
    
     local x = conn:load(url2 .. '&balancer=filmix')
     

     for url4, total3 in string.gmatch(x, '<div class="videos__button.-"method":"link","url":"(http.-)".->(.-])<') do

     local x = conn:load(url4)
    
    for url5, total4 in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"http.-(/proxy.-mp4)".-class="videos__item%-title">(.-)</div>') do 
    
    url5 = string.gsub(url5, '^(.-)', 'http://s2.lampa.vip') 
    
    t['view'] = 'simple'


table.insert(t, {title = total4 .. ' ' .. total3, mrl = url5})


end
end








     for url4, total5  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url4)

      for url5, total6  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url5)


      for url6, total7  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url":".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       url6 = string.gsub(url6, '^(.-)', 'http://s2.lampa.vip') 
    
    t['view'] = 'simple'

    table.insert(t, {title = total5 .. ' '  .. tolazy(total6) .. total7, mrl = url6})

       
    end

end
end
end







  
  for title, title1 in string.gmatch(x, '<meta charset=.-<title>(.-) %((.-)%)') do
      
     title = urlencode(title)
      
     title = string.gsub(title, '+', '%%20')
  
url1 = string.gsub(title, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=') .. '+' .. title1 .. '+'

table.insert(t, {title = 'Kinopub', mrl = '#stream/q=content&id=' .. url1, image = image})

   --   table.insert(t, {title = url1, mrl = '#stream/q=content&id=' .. url1, image = image})
	  end
	  
--  local x = conn1:load(url1)

     for url2 in string.gmatch(x, '<playlist_name>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn:load(url2)
    
    
    

    
    for total, url3, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-])]].-<playlist_url><!%[CDATA%[(http://185.188.183.182.-) %[.-(&perewod.-)]]></playlist_url>') do
	
	    local x = conn:load(url3 .. url4)
	   
	   
	     for total1, url5 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. tolazy(total1) .. total, mrl = url5, image = image})
     end
	    end
    end





  
    for title, title1 in string.gmatch(x, '<meta charset=.-<title>(.-) %((.-)%)') do
      
     title = urlencode(title)
      
     title = string.gsub(title, '+', '%%20')
	
     url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

     local x = conn:load(url)

    for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
  
  url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
      local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end
    end
end

 
 
 
 




	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end