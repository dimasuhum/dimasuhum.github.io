-- kinowatch plugin

require('support')
require('video')
require('parser')


HOME = 'https://kino.watch'

HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinowatch plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinowatch plugin')
end

function onCreate(args)
	local t = {view = 'grid', type = 'folder'}


	if not args.q then

         local genre = args.genre or '/'
     	local url = HOME .. genre

			url = url

		local x = http.getz(url)

        for url, title in string.gmatch(x, '<a href="(/ch/.-)" class="header__nav%-link">(.-)</a>') do
        
        url = string.gsub(url, '^(.-)', HOME)
             
		  table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = 'https://avatars.mds.yandex.net/i?id=643742ed1114d212f136a283048efb37_l-7754520-images-thumbs&n=13'})
		end 
     elseif args.q == 'content' then
		
		local x = http.getz(args.id)
        for url in string.gmatch(x, '<source src="(https.-m3u8)"') do
			print(url)
			t = video(url, args)
			if t['view'] ~= 'error' then
				break
			end
        table.insert(t, {mrl = url})
		end
		
		
		
	end
	return t
end