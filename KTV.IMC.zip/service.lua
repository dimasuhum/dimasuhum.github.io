-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--https://api.embess.ws/embed/movie/486

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'





local HOME = 'http://kb-team.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH








PASS = '7777'

local lockpass



function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)

if not args.q and args.keyword then
lockpass = args.keyword
end

if lockpass == PASS then
else
return {view="keyword",message="enter access code"}
end


	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then

     --    table.insert(t['menu'], {title = 'Общие', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/EDEMTV1.IMC.zip', image = '#self/list.png'})


	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

	if not args.q then


      local url = 'http://kb-team.club/?do=/plugin&bid=kbc&m3u=&box_mac=b8bc5bf8dea3'
			url = url


		local x = conn:load(url)

		for image, title, url in string.gmatch(x, 'EXTINF:.-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end
		





    local genre = args.genre or '/?do=/fml&id=7-iptv&m3u=&box_mac=b8bc5bf8dea3'
	
		local url = HOME .. genre
      
     --   local url = 'http://kb-team.club/?do=/plugin&bid=kbc&m3u=&box_mac=b8bc5bf8dea3'
			url = url


		local x = conn:load(url)

        for title, image, url in string.gmatch(x, '<channel>.-<title>.-%[CDATA%[(.-)]].-<logo.-%[CDATA%[(.-)].-<playlist_url>.-%[CDATA%[(http.-)]]') do

       local x = conn:load(url .. '&m3u=&box_mac=b8bc5bf8dea3')

		for image, title, url in string.gmatch(x, 'EXTINF:.-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end
		end
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
    --    local x = conn:load(HOME .. 'http://kb-team/?do=/fml&id=7-iptv&m3u=&box_mac=b8bc5bf8dea3')
	
--		for title, image, genre in string.gmatch(x, '<channel>.-<title>.-%[CDATA%[(.-)]].-<logo.-%[CDATA%[(.-)].-<playlist_url>.-%[CDATA%[http.-)]]') do
     
    --    table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. '&m3u=&box_mac=b8bc5bf8dea3', image = image})
    --    end

    
    
  --  table.insert(t, {title = 'IPTV I (Jamovie)', mrl = '#stream/url=' .. 'http://kb-team.club/?do=/plugin&bid=iptvn&m3u=&box_mac=b8bc5bf8dea3', image = 'http://kb-team.club/msx/img/plugins/IPTV.png'})
    
    
    
    
    

    
    
      
	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html


	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end

