-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--https://api.embess.ws/embed/movie/486

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'





local HOME = 'http://kb-team.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH








PASS = '7777'

local lockpass



function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)

if not args.q and args.keyword then
lockpass = args.keyword
end

if lockpass == PASS then
else
return {view="keyword",message="enter access code"}
end


	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then



	if not args.q then



      local url = 'http://kb-team.club/?do=/plugin&bid=iptvk&m3u'
			url = url


		local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')

		for image, title, url in string.gmatch(x, 'EXTINF:.-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end
		





    


	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
end
	end
	return t
end

