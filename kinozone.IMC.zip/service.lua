-- fast-film plugin

require('support')
require('video')
require('parser')




HOME = 'https://www.kinozone.online'
--HOME1 = 'https://kadikama.online'

HOME_SLASH = HOME .. '/'
--HOME1_SLASH = HOME1 .. '/'
function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=2
    -- #stream/genre=%D0%B4%D1%80%D0%B0%D0%BC%D0%B0


--https://www.kinozone.online/videos_list.php?genre=%D0%B4%D1%80%D0%B0%D0%BC%D0%B0


    -- #stream/genre=/videos_list.php?genre=%D0%B4%D1%80%D0%B0%D0%BC%D0%B0


	if not args.q then
	

		local page = tonumber(args.page or 1)
		
        local genre = args.genre or '/videos_list.php?q='
--&p=2
	--	local genre = args.genre or '/novinki.php'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '&p=' .. tostring(page)
		end
	--	if genre == '/videos_list.php?genre=%D0%B4%D1%80%D0%B0%D0%BC%D0%B0' then
	--	local url = HOME .. genre
    	

		local x = http.getz(url)
         

       for url, image, title in string.gmatch(x, '<div class="channels%-card%-image".-<a href="(video.-)".-<img.-src="(.-)".-class="btn btn%-outline%-secondary btn%-sm">(.-)<') do
		
          
        url = string.gsub(url, '^(.-)', HOME .. '/')
      --  image = string.gsub(image, '^(.-)', HOME)
        
         table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
	--		table.insert(t, {title = title, mrl = '#stream/genre' .. url .. url1})
		

		end
		
		
		
		if genre == '/novinki.php' then
      local url = HOME .. genre
       if page > 1 then
			url = url .. '?p=' .. tostring(page)
		end	
    	end
		local x = http.getz(url)
		
		for image, url, title in string.gmatch(x, '<div class="video%-card video%-card%-list".-src="(.-)".-class="video%-title".-<a href="(.-)">(.-)</a>') do
          
        url = string.gsub(url, '^(.-)', HOME .. '/')
        
         table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})


		end
	--	end
		
        for url, image, title in string.gmatch(x, '<div class="channels%-card%-image".-<a href="(top.-)".-<img class="img%-fluid" src="(.-)" alt="(.-)"') do
		
         image = string.gsub(image, '^(.-)', HOME .. '/')
		 table.insert(t, {title = title, mrl = '#stream/genre=' .. '/' .. url, image = image})


		end
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = http.getz(HOME)
		
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, '<div class="top%-category">(.-)<div class="col%-md%-12 adblock"')
		for genre, image, title in string.gmatch(x, '<a href=".-=(.-)".-<img.-src="(.-)".-alt="(.-)"') do
         
         --	genre=http.urldecode(urlencode(genre))
	    	genre=http.urlencode(urldecode(genre))
			table.insert(t, {title = title, mrl = '#stream/genre=' .. '/videos_list.php?genre=' .. genre, image = HOME .. '/' .. image})
		end
        
        local x = http.get(HOME)
   --    x = iconv(http.get(HOME .. '/kino-podborka.html'), 'WINDOWS-1251', 'UTF-8')
        --x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, '<ul class="sidebar navbar%-nav toggled".-Главная</span>(.-)<a class="nav%-link" href="tv.php".-</ul>')
		for genre, title in string.gmatch(x, '<a class="nav%-link" href="(.-)".-<span>(.-)</span>') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. '/' .. genre})
		end
        
        
        
        
--https://www.kinozone.online/videos_list.php?q=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8
        
        
        
        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/videos_list.php?q=' .. urlencode(args.keyword) .. '&p=' .. tostring(page)


		local x = http.getz(url)
         

       for url, image, title in string.gmatch(x, '<div class="channels%-card%-image".-<a href="(.-)".-<img.-src="(.-)".-class="btn btn%-outline%-secondary btn%-sm">(.-)<') do
         url = string.gsub(url, '^(.-)', HOME .. '/')
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
        
        
        
        
        
        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
    --    x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h2>.-</i>(.-)</h2>')
		t['description'] = parse_match(x,'<div class="single%-video%-info%-content box mb%-2".-<p>(.-)</p>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Страна:</h6>.-)</p>','(Жанры:</h6>.-)</p>', '(Страна:</span>.-)</div>', '(Режиссер:</h6>.-)<br>', '(Актёры</h6>.-)<br>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
		
		
		
       for url in string.gmatch(x, 'var k_id=(.-);') do
		 print(url) 
		url = string.gsub(url, '^(.-)', 'http://sarnage.cc/kinopoisk/')
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'let player = new Playerjs.-id:"player".-file:.-#2(.-)\'') do
         url = string.gsub(url, '//', '')
         url = string.gsub(url, 'bHZmeWNnbmRxY', '')
         url = string.gsub(url, 'ZGY4dmc2', '')
         url = string.gsub(url, 'OXI5enhXZGx5ZisqZmd4NDU1ZzhmaDl6LWUqUQ==', '')
         url = string.gsub(url, 'NTR2amZoY2dkYnJ5ZGtjZmtuZHo1Njg0MzZmcmVkKypk', '')
         url = string.gsub(url, 'UqcSpZ', '')
         url = string.gsub(url, 'YXorLWVydyozNDU3ZWRndGpkLWZlcXNwdGYvcm', '')
        url = string.gsub(url, 'LSpmcm9mcHNjcHJwYW1mcFEqNDU2MTIuMzI1NmRmcmdk', '')
        url = string.gsub(url, '3lkcmNnY2ZnKzk1MTQ3Z2ZkZ2YtemQq', '')
        
 
         url=http.urldecode(base64_decode(url))
        
		if url then
			for title,  url in string.gmatch(url, '{"title":(.-)"file":"(.-)"') do
           t['view'] = 'simple'
       
       

       
         
         title = string.gsub(title, '"subtitle":".-",', '')
         title = string.gsub(title, '"folder":%[{"title":', '')
         
        title = string.gsub(title, ',', '')
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
  
       end

		
		
		
		
		
--https://api.strvid.ws/embed/movie/58362?host=uitools.space
		
         for url in string.gmatch(x, 'var k_id=(.-);') do
		print(url) 
		url = string.gsub(url, '^(.-)', 'https://api.getcodes.ws/embed/kp/')
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
		
		
		
         for title, url, total in string.gmatch(x, '"episode".-"hlsList".-"(.-)".-(https.-)".-"title".-"(.-)"') do

			print(url)
        t['view'] = 'simple'
      --  t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb=
        end
		
		for title, url, total in string.gmatch(x, '"episode".-"hlsList".-,"(.-)".-(https.-)".-"title".-"(.-)"') do
			print(url)
        t['view'] = 'simple'
      --  t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb='})
        end
--src="https://api1617026518.tobaco.ws
--https://api1584276060.tobaco.ws/embed/kp/737843


        -- for url, title in string.gmatch(x, '"ovsEmbededHtml":"https://api.-(/embed.-)".-"title":"(.-)"') do

       --  url = string.gsub(url, '^(.-)',  'https://api.getcodes.ws')
       --  t['view'] = 'simple'

        --  table.insert(t, {title = title, mrl = '#stream/q=content&id='  .. url})
	--	end
		
    --   for url in string.gmatch(x, '<iframe.-src="(.-)"') do 
       -- t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
		--	table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id='  .. url})
	--	end
		
        
        for title, url in string.gmatch(x, 'title: "(.-)".-hls: "(https://.-m3u8)"') do
        --	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end

     	for url, title in string.gmatch(x, '"hls":"(https.-m3u8)".-"title":"(.-)"') do

			print(url)
        t['view'] = 'simple'
      --  t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end	
       for title, url, total in string.gmatch(x, '"episode".-"hlsList".-"(.-)".-(https.-)".-"title".-"(.-)"') do

			print(url)
        t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb='})
        end
		
		for title, url, total in string.gmatch(x, '"episode".-"hlsList".-,"(.-)".-(https.-)".-"title".-"(.-)"') do
			print(url)
         t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb='})
        end

        
         
			
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-,"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end
		
		
		
		
		
		
		
		
		
		
		
         for url in string.gmatch(x, 'var k_id=(.-);') do
    
        print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-or (//video.zagonka.org/movies/.-mp4)') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
        
        
    end


        for url in string.gmatch(x, 'var k_id=(.-);') do
        print(url)
		 url = string.gsub(url, '^(.-)', 'http://divantv.zz.mu/kinomovie/zombie.m3u.php?kp_id=')

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
		
        for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end