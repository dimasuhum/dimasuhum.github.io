-- kinotochka plugin

require('support')
require('video')
require('parser')
require('client')


local HOME = 'https://kinovibe.cc'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




--HOME = 'https://kinotochka.live'
--HOME = 'https://kinovibe.vip'
--HOME_SLASH = HOME .. '/'
--HOME_SLASH1 = HOME1 .. '/'

function onLoad()
	print('Hello from kinotochka plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinotochka plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/playlist/162/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/premier/'

        local url = HOME .. genre
    	if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
			
      	end
	
    	if genre == '' then
		local url = HOME .. genre
 
    	if page > 1 then
			url = url .. tostring(page)
	
    	end
		end
	
--https://kinovibe.co/playlist/2373/?page=2
		
		local x = conn:load(url)
		
       -- x = iconv(http.get(url2), 'utf-8', 'UTF-8')




		
		for url, image, title  in string.gmatch(x, '<div class="custom1%-item".-<a.-href="(.-)".-<img.-src="(.-)".-class="custom1%-title">(.-)<') do
			--url = string.gsub(url, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
         for url, image, title  in string.gmatch(x, '<a href="(/podborki/.-)".-src="(.-)".-style="text%-transform.->(.-)<') do
		--	url = string.gsub(url, '^/', HOME_SLASH)
            image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
		end









		
    --     for image, url,  title   in string.gmatch(x, '<div class="custom1%-img".-<img.-data%-cfsrc="(.-)".-<a.-href="(/playlist.-)".-class="p%-playlist%-item%-title custom1%-title">(.-)%[.-</a>') do

     --     image = string.gsub(image, '^(.-)', HOME)
	--		table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
	--	end
  
  
  

         for genre, image,  title  in string.gmatch(x, 'data%-id=.-href=.-(/playlist/.-/).-<img src=.-(/uploads.-)".-class="p%-playlist%-item%-title custom1%-title.->(.-)<') do
         
          image = string.gsub(image, '^(.-)', HOME)
          
    
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. genre .. '?page=', image = image})
		end
  
  
  

    for url, image,  title, total  in string.gmatch(x, '<div class="custom1%-item x%-selar%-item".-<a.-href="(/selection.-)".-<img src="(/uploads.-)".-class="custom1%-title">(.-)<.-class="x%-selar%-seasons">(.-)<') do
      url = string.gsub(url, '^(.-)', HOME)
			   image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title) ..  tolazy(total), mrl = '#stream/q=content&id=' .. url, image = image})
            end



        for image, url,  title  in string.gmatch(x, '<div class="p%-playlist%-post custom1%-item custom1%-img".-<img src="(.-)".-href=.-/index.php?.-=(.-)".-class="p%-playlist%-post%-title custom1%-title">(.-)<') do
    --    url = string.gsub(url, '^(.-)', HOME)
			url = string.gsub(url, '^(.-)', HOME .. '/embed/')
         --   image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
            end
    
     --     for url, image, title, total  in string.gmatch(x, '<div class="custom1%-img".-<a href="(/playlist/.-)".-<img src="(.-)".-class="p%-playlist%-item%-title custom1%-title">(.-)<.-class="p%-playlist%-item%-quantity">(.-)</div>') do
		--	url = string.gsub(url, '^/', HOME_SLASH)
        --    image = string.gsub(image, '^(.-)', HOME)
	--		table.insert(t, {title = tolazy(title) .. '|' .. (total), mrl = '#folder/genre=' .. url, image = image})
        --    end
    
   --      for url, image, title in string.gmatch(x, '<div class="p%-playlist%-post custom1%-item custom1%-img".-<a href="(.-)".-<img src="(.-)".-class="p%-playlist%-post%-title custom1%-title">(.-)<') do
	   -- 	url = string.gsub(url, '^(.-)', HOME)
       --     image = string.gsub(image, '^(.-)', HOME)
        --	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
        --    end
       	
		 
        local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
      -- table.insert(t, {title = '4k-2020', mrl = '#stream/genre=' .. '/category/4k/4k-2020/'})
   --     table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/multfilmy/'})
	--	table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serialy/'})

        
       table.insert(t, {title = 'Подборки', mrl = '#folder/genre=' .. '/podborki_filmov.html'})
       
--https://kinovibe.co/playlist/
       
       table.insert(t, {title = 'Подборки пользователей', mrl = '#folder/genre=' .. '/playlist/'}) 
   
   

   
   
   local x = http.getz(HOME)
	    --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
       local x = string.match(x, '<a href=.-Фильмы.-<ul class="sub%-menu clearfix">(.-)</ul>')
         for genre, title in string.gmatch(x, '<a href="(/.-)">(.-)</a>') do
			table.insert(t, {title = 'Фильмы : ' .. title, mrl = '#stream/genre=' .. genre}) 
		end
		
		
   
     	local x = http.getz(HOME)
	    --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
       local x = string.match(x, 'Сериалы.-<ul class="sub%-menu clearfix">(.-)</ul>')
         for genre, title in string.gmatch(x, '<a href="(/.-)">(.-)</a>') do
			table.insert(t, {title = 'Сериалы : ' .. title, mrl = '#stream/genre=' .. genre}) 
		end
		
		
		
       --  local x = http.getz(HOME1)
   --    table.insert(t, {title = 'TOP Playlist', mrl = '#stream/genre=' .. '/playlist/162/'})
     
     
  --  local x = http.getz(HOME .. '/playlist/top/')
     
     -- table.insert(t, {title = 'Топ подборок', mrl = '#folder/genre=' .. '/playlist/top'})
    
   --   for genre, image, title, total  in string.gmatch(x, '<div class="p%-playlist%-item custom1%-item.-id="playlist%-(.-)".-<img src="(.-)".-class="p%-playlist%-item%-title custom1%-title">(.-)<.-class="p%-playlist%-item%-quantity">(.-)<') do
	--		image = string.gsub(image, '^/', HOME_SLASH)
	--		table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/genre' .. '/playlist/' .. genre .. '/', image = image})
	--	end
    
    

        
--https://kinotochka.co/playlist/
    
       
    
   --     table.insert(t, {title = 'Все mp4(фильмы) mp4', mrl = '#stream/genre=' .. '/to-filmis/'})
	--	table.insert(t, {title = 'Боевик mp4', mrl = '#stream/genre=' .. '/genrefilm/action/'})
	--	table.insert(t, {title = 'Военный mp4', mrl = '#stream/genre=' .. '/genrefilm/to-militarii/'})
	--	table.insert(t, {title = 'Драма mp4', mrl = '#stream/genre=' .. '/genrefilm/the-dramas/'})
	--	table.insert(t, {title = 'Комедия mp4', mrl = '#stream/genre=' .. '/genrefilm/the5-komediyas/'})
	--	 table.insert(t, {title = 'Мелодрама mp4', mrl = '#stream/genre=' .. '/genrefilm/melodramas/'})
	--	table.insert(t, {title = 'Приключения mp4', mrl = '#stream/genre=' .. '/genrefilm/8-travels/'})
	--	table.insert(t, {title = 'Триллер mp4', mrl = '#stream/genre=' .. '/genrefilm/the-2triller/'})
	--	table.insert(t, {title = 'Фантастика mp4', mrl = '#stream/genre=' .. '/genrefilm/fantastics/'})
	--	 table.insert(t, {title = 'Русские mp4', mrl = '#stream/genre=' .. '/genrefilm/russkiys/'})
	--	table.insert(t, {title = 'Вестерн mp4', mrl = '#stream/genre=' .. '/genrefilm/vestern/'})
	--	table.insert(t, {title = 'Детектив mp4', mrl = '#stream/genre=' .. '/genrefilm/detektiv/'})
	--	table.insert(t, {title = 'Исторический mp4', mrl = '#stream/genre=' .. '/genrefilm/2-historikal/'})
	--	 table.insert(t, {title = 'Криминал mp4', mrl = '#stream/genre=' .. '/genrefilm/vkriminale/'})
	--	table.insert(t, {title = 'Мистика mp4', mrl = '#stream/genre=' .. '/genrefilm/mistik-films/'})
	--	table.insert(t, {title = 'Семейный mp4', mrl = '#stream/genre=' .. '/genrefilm/semeynyy/'})
		
	--	table.insert(t, {title = 'Ужасы mp4', mrl = '#stream/genre=' .. '/genrefilm/2-ujasys/'})
	--	 table.insert(t, {title = 'Фентези mp4', mrl = '#stream/genre=' .. '/genrefilm/fentezim/'})
	--	table.insert(t, {title = 'HD720 mp4', mrl = '#folder/genre=' .. '/hs720/'})
		
		
		
    --  table.insert(t, {title = 'Все mp4(сериалы)', mrl = '#stream/genre=' .. '/strseries/'})
     --   table.insert(t, {title = 'Боевик mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/boevikys/'})
	--	table.insert(t, {title = 'Военный mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/warrior/'})
	--	table.insert(t, {title = 'Драма mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/dramas/'})
	--	table.insert(t, {title = 'Комедия mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/2-komediya/'})
	--	 table.insert(t, {title = 'Мелодрама mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/4-melodrama/'})
	--	table.insert(t, {title = 'Приключения mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/priklyucheniyas/'})
	--	table.insert(t, {title = 'Триллер mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/triller/'})
	--	table.insert(t, {title = 'Фантастика mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/to2-fantastik/'})
	--	 table.insert(t, {title = 'Русские mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/tvr-russians/'})
		
	--	table.insert(t, {title = 'Детектив mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/detektives/'})
	--	table.insert(t, {title = 'Исторический mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/historikallys/'})
	--	 table.insert(t, {title = 'Криминал mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/kriminals/'})
		
	--	table.insert(t, {title = 'Семейный mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/semeynyys/'})
	--	table.insert(t, {title = 'Ужасы mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/3-horrors/'})
	--	 table.insert(t, {title = 'Фентези mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/5-fentezis/'})		
	--	table.insert(t, {title = 'Дорамы mp4(сериалы)', mrl = '#stream/genre=' .. '/doramas/'})
		
    --    table.insert(t, {title = 'Коллекция mp4(сериалы)', mrl = '#stream/genre=' .. '/selection/'})
		

		
		

    table.insert(t, {title = 'ТВ-шоу', mrl = '#stream/genre=' .. '/shows/'})

		
		
		
          
        --table.insert(t, {title = 'Плейлист Топ', mrl = '#folder/genre=' .. '/playlist/top/'})
       table.insert(t, {title = 'Мульты Отечественные', mrl = '#folder/genre=' .. '/cartoon/rusmult/'})
        table.insert(t, {title = 'Мульты Зарубежные', mrl = '#folder/genre=' .. '/cartoon/zarubezmult/'})
     --   table.insert(t, {title = 'Мульты Все mp4', mrl = '#folder/genre=' .. '/cartoonis/'})
       -- table.insert(t, {title = 'Плейлист Фильмов mp4 Все', mrl = '#folder/genre=' .. '/playlist/'})
         
--https://kinotochka.co/index.php?story={searchTerms}&do=search&subaction=search

--https://kinotochka.co/?do=search&mode=advanced&subaction=search&story=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/?do=search&mode=advanced&subaction=search&story=' .. urlencode(args.keyword) --.. '#'  .. tostring(page)

		
		local x = http.getz(url)
		
        for url, image, title  in string.gmatch(x, '<a class="sres%-wrap clearfix.-href="(.-)".-<img.-src="(.-)".-<h2>(.-)</h2') do
			--url = string.gsub(url, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '#' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})





	-- #stream/q=content&id=/13879-rzhev-2019.html
	
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
        --x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1 itemprop="name".->(.-)смотреть онлайн</h1>')


   --     t['description'] = parse_match(x,'<div class="full%-text movie%-desc clearfix" itemprop="description">(.-)</div>')
--div class="full%-text movie%-desc clearfix" itemprop="description".-<br><br>(.-)<br>
        t['description'] = parse_match(x,'<div class="full%-text movie%-desc clearfix".-QuoteEEnd.->(.-)</div>')
      --  t['poster'] = args.p
		t['poster'] = parse_match(x,'<img itemprop="image" class="xfieldimage miniFiltereder" src="(.-)"')
		if t['poster'] then
		--	t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
	--	t['annotation'] = parse_array(x, {
		--	'(Оригинальное название:</span>.-)</div>', '(Год:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Жанр:</span>.-)</div>', '(Качество:</span>.-)</div>', '(Режиссер:</span>.-)</div>', '(В ролях:</span>.-)</div>', '(Год выпуска:</strong>.-)<br>',  '(Жанр:</strong>.-)<br>', '(Режиссёр:</strong>.-)<br>', '(В ролях:</strong>.-)<br>', '<span itemprop="alternativeHeadline">(.-)</span>',})
        --x = string.gsub(x, 'скачать', '')
  
  

  
  for title in string.gmatch(x, '<meta property="og:url" content="(http.-)"') do
 
 
    url = string.gsub(title, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/serii.php?film=') .. '&page='
 
     local x = http.get(url)
     
    for title1, url2 in string.gmatch(x, '<channel.-<title>(Источник:.-)</title>.-<stream_url.-<!%[CDATA.-(http.-)]]') do
 
 
  
  table.insert(t, {title = title1, mrl = url2})
		 end
  end
  
  
--http://185.188.183.182/iptv/kinotochka/serii.php?film=https://kinovibe.vip/33418-obitel-2025.html&page=
  
  --http://185.188.183.182/iptv/kinotochka/serii.php?film=http://zagonka5.zagonkomv.gb.net/132094-vozvraschenie-v-sajlent-hill-2026-onlayn.html&page=

     
     for title, title1 in string.gmatch(x, '<meta property="og:title" content="(.-) %((.-)%)"') do
 
--title = string.gsub(title, 'Сезон', '')
--title = string.gsub(title, '[%d]', '')
  	 
  	 local x = conn:load('http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=' .. urlencode(title) .. '(' .. title1 .. ')')
  
    for title3 in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-info&cid=(.-)"') do

     title = urlencode(title)

--http://hidxlglk.deploy.cx/lite/kinotochka?


--local x = conn:load('https://p01--lampac--9dxms589q2gt.code.run/lite/kinotochka?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)


    url1 = string.gsub(title3, '^(.-)', 'https://p01--lampac--9dxms589q2gt.code.run/lite/kinotochka?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

 --  table.insert(t, {title = url1, mrl = url1})
       
    local x = conn:load(url1)

     for url2, title4 in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"http.-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do


url2 = string.gsub(url2, '^(.-)', 'https://p01--lampac--9dxms589q2gt.code.run') 
url2 = string.gsub(url2, '\\u002B', '+')


table.insert(t, {title = title4, mrl = url2})
        end
end
end
  
  
  
  
  
  
  
--  table.insert(t, {title = title, mrl = '#stream/q=kinotochka&id=' .. title .. '&id1=' .. title1})
		-- end
  
  
  
  
  
  
       for url in string.gmatch(x, 'var player = new Playerjs.-player%-trailer.-file.-(https.-mp4)"') do

      --   t['view'] = 'grid'
         table.insert(t, {title = 'Трейлер', mrl = url})
		 end
  
         
        for url, title in string.gmatch(x, '<ul class="seasons%-list".-<a href="(.-)">(.-)</a>') do

      --   t['view'] = 'grid'
         table.insert(t, {title = title, mrl = '#stream/q=content&id=' ..  url})
		 end

		for url in string.gmatch(x, '<video.-src="(https.-mp4)"') do
         -- print(url) 
          table.insert(t, {title = 'Смотреть mp4', mrl = url})
		end
		
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-id:"playerjshd".-file:"(.-txt)"') do
         -- print(url)
      --    t['view'] = 'grid'
       --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' ..  url})
          table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})
		end





           for title, url in string.gmatch(x, '"comment":"(.-)".-file.-(https://s.-mp4)"') do
			print(url)  

          url = string.gsub(url, '_[480,720]', '')
          t['view'] = 'simple'
   
       table.insert(t, {title = tolazy(title), mrl = url})
   
   --     table.insert(t, {title = title .. (total), mrl = url})
        end


		for title, url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do
	--		print(url)  

    --      url = string.gsub(url, '(.-)', url) .. '_480.mp4'
          t['view'] = 'simple'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title) .. ' (480p)'  , mrl = url .. url1 .. '_480.mp4'})
   
   --     table.insert(t, {title = tolazy(title) .. (total), mrl = url})
        end
	
	
          for title,  url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do
		--	print(url)  

      --    url = string.gsub(url, '(.-)', url) .. '_720.mp4'
          t['view'] = 'simple'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title) .. ' (720p)', mrl = url .. url1 .. '_720.mp4'})
   
   --     table.insert(t, {title = tolazy(title) .. (total), mrl = url})
        end
	





       for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end
     --  for url in string.gmatch(x, '<a class="dlMediaAction%-download" href="(https.-mp4)?download"') do
    --   table.insert(t, {title = 'Смотреть', mrl = url})
	--	end




--https://kinovibe.co/embed/30712

--https://s19.kvb.cool/video_mp4/films/2025/Sinners/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVnTHVzbQt-WQ::/Sinners2025_480.mp4



--https://lam.maxvol.pro/proxy/lbxJUDzFAKrzJxN7u6otgzONNi+IOMjWF5etPWcEbKOqilFpJF5m/VnX3E0f/3d6UEoZPIGUP9qbhZfz90siq67XrefrCUWgi6PVBtYJkldE03MhAhbwy9FdbVKWmKlkmRGNmi3boGIimjVdDIfdvyjyeEpLXap1q/avsBB7u0twUL/YstoPmKbLwOwDvYTTmofSDTsNsTrPoNP/d/o2pXEM1N6N2twBgJivfCHil2d4wS7+ZGeqBSyNQ8OLU6Wl6sRfDnIYi0pDFEwl3uDSHg==.mp4



   elseif args.q == 'kinotochka' then
	--	t['view'] = 'annotation'
 

        
	local x = http.get('http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=' .. urlencode(args.id) .. '(' .. args.id1 .. ')')
		
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	


   for title, title1, title3 in string.gmatch(x, '"fxml".-align:center.->.-: (.-)%((.-)%)<.-"playlist_url":"http.-kinopoisk.-info&cid=(.-)"') do

     title = urlencode(title)

--http://hidxlglk.deploy.cx/lite/kinotochka?

    url1 = string.gsub(title3, '^(.-)', 'https://p01--lampac--9dxms589q2gt.code.run/lite/kinotochka?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

   table.insert(t, {title = url1, mrl = url1})
       
    local x = conn:load(url1)

     for url2, title4 in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"http.-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do


url2 = string.gsub(url2, '^(.-)', 'https://p01--lampac--9dxms589q2gt.code.run') 
url2 = string.gsub(url2, '\\u002B', '+')


table.insert(t, {title = url2, mrl = url2})
        end

end





	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end