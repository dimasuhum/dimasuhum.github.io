-- kinotochka plugin

require('support')
require('video')
require('parser')





--HOME = 'https://kinotochka.co'
HOME = 'https://kinovibe.tv'
HOME_SLASH = HOME .. '/'
--HOME_SLASH1 = HOME1 .. '/'

function onLoad()
	print('Hello from kinotochka plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinotochka plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/playlist/162/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/premier/'

        local url = HOME .. genre
    	if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		
		if genre == '' then
		local url = HOME .. genre
    	if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		end
	
    	if genre == '/playlist/2823/' then
		local url = HOME .. genre
    	if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		end
	
--https://kinotochka.co/playlist/2373/?page=2
		
		local x = http.getz(url)
		
       -- x = iconv(http.get(url2), 'utf-8', 'UTF-8')




		
		for url, image, title  in string.gmatch(x, '<div class="custom1%-item".-<a.-href="(.-)".-<img.-src="(.-)".-class="custom1%-title">(.-)<') do
			--url = string.gsub(url, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
         for url, image, title  in string.gmatch(x, '<a href="(/podborki/.-)".-src="(.-)".-style="text%-transform.->(.-)<') do
		--	url = string.gsub(url, '^/', HOME_SLASH)
            image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url, image = image})
		end




		
         for url, image, title  in string.gmatch(x, '<div class="custom1%-img".-<a href="(/playlist/.-)".-<img src="(.-)".-class="p%-playlist%-item%-title custom1%-title">(.-)<') do
		--	url = string.gsub(url, '^/', HOME_SLASH)
            image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. url .. '/', image = image})
		end
  

--<div class="p%-playlist%-post custom1%-item custom1%-img".-<a href="(/index.php?newsid=320)".-<img src="(.-)".-class="p%-playlist%-post%-title custom1%-title">(.-)</a>
    
        for image, url,  title  in string.gmatch(x, '<div class="p%-playlist%-post custom1%-item custom1%-img".-<img src="(.-)".-href=.-/index.php?.-=(.-)".-class="p%-playlist%-post%-title custom1%-title">(.-)<') do
    --    url = string.gsub(url, '^(.-)', HOME)
			url = string.gsub(url, '^(.-)', HOME .. '/embed/')
         --   image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
            end
    
     --     for url, image, title, total  in string.gmatch(x, '<div class="custom1%-img".-<a href="(/playlist/.-)".-<img src="(.-)".-class="p%-playlist%-item%-title custom1%-title">(.-)<.-class="p%-playlist%-item%-quantity">(.-)</div>') do
		--	url = string.gsub(url, '^/', HOME_SLASH)
        --    image = string.gsub(image, '^(.-)', HOME)
	--		table.insert(t, {title = tolazy(title) .. '|' .. (total), mrl = '#folder/genre=' .. url, image = image})
        --    end
    
   --      for url, image, title in string.gmatch(x, '<div class="p%-playlist%-post custom1%-item custom1%-img".-<a href="(.-)".-<img src="(.-)".-class="p%-playlist%-post%-title custom1%-title">(.-)<') do
	   -- 	url = string.gsub(url, '^(.-)', HOME)
       --     image = string.gsub(image, '^(.-)', HOME)
        --	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
        --    end
       	
		 
        local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
      -- table.insert(t, {title = '4k-2020', mrl = '#stream/genre=' .. '/category/4k/4k-2020/'})
   --     table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/multfilmy/'})
	--	table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serialy/'})

        
       table.insert(t, {title = 'Подборки', mrl = '#folder/genre=' .. '/podborki_filmov.html'})
       table.insert(t, {title = 'Подборки пользователей', mrl = '#folder/genre=' .. '/playlist/'}) 
     	local x = http.getz(HOME)
	    --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
       local x = string.match(x, '<ul class="sub%-menu clearfix">(.-)</nav>')
         for genre, title in string.gmatch(x, '<a href="(/.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre}) 
		end
       --  local x = http.getz(HOME1)
   --    table.insert(t, {title = 'TOP Playlist', mrl = '#stream/genre=' .. '/playlist/162/'})
     
     
  --  local x = http.getz(HOME .. '/playlist/top/')
     
     -- table.insert(t, {title = 'Топ подборок', mrl = '#folder/genre=' .. '/playlist/top'})
    
   --   for genre, image, title, total  in string.gmatch(x, '<div class="p%-playlist%-item custom1%-item.-id="playlist%-(.-)".-<img src="(.-)".-class="p%-playlist%-item%-title custom1%-title">(.-)<.-class="p%-playlist%-item%-quantity">(.-)<') do
	--		image = string.gsub(image, '^/', HOME_SLASH)
	--		table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/genre' .. '/playlist/' .. genre .. '/', image = image})
	--	end
    
    

        
--https://kinotochka.co/playlist/
    
       
    
   --     table.insert(t, {title = 'Все mp4(фильмы) mp4', mrl = '#stream/genre=' .. '/to-filmis/'})
	--	table.insert(t, {title = 'Боевик mp4', mrl = '#stream/genre=' .. '/genrefilm/action/'})
	--	table.insert(t, {title = 'Военный mp4', mrl = '#stream/genre=' .. '/genrefilm/to-militarii/'})
	--	table.insert(t, {title = 'Драма mp4', mrl = '#stream/genre=' .. '/genrefilm/the-dramas/'})
	--	table.insert(t, {title = 'Комедия mp4', mrl = '#stream/genre=' .. '/genrefilm/the5-komediyas/'})
	--	 table.insert(t, {title = 'Мелодрама mp4', mrl = '#stream/genre=' .. '/genrefilm/melodramas/'})
	--	table.insert(t, {title = 'Приключения mp4', mrl = '#stream/genre=' .. '/genrefilm/8-travels/'})
	--	table.insert(t, {title = 'Триллер mp4', mrl = '#stream/genre=' .. '/genrefilm/the-2triller/'})
	--	table.insert(t, {title = 'Фантастика mp4', mrl = '#stream/genre=' .. '/genrefilm/fantastics/'})
	--	 table.insert(t, {title = 'Русские mp4', mrl = '#stream/genre=' .. '/genrefilm/russkiys/'})
	--	table.insert(t, {title = 'Вестерн mp4', mrl = '#stream/genre=' .. '/genrefilm/vestern/'})
	--	table.insert(t, {title = 'Детектив mp4', mrl = '#stream/genre=' .. '/genrefilm/detektiv/'})
	--	table.insert(t, {title = 'Исторический mp4', mrl = '#stream/genre=' .. '/genrefilm/2-historikal/'})
	--	 table.insert(t, {title = 'Криминал mp4', mrl = '#stream/genre=' .. '/genrefilm/vkriminale/'})
	--	table.insert(t, {title = 'Мистика mp4', mrl = '#stream/genre=' .. '/genrefilm/mistik-films/'})
	--	table.insert(t, {title = 'Семейный mp4', mrl = '#stream/genre=' .. '/genrefilm/semeynyy/'})
		
	--	table.insert(t, {title = 'Ужасы mp4', mrl = '#stream/genre=' .. '/genrefilm/2-ujasys/'})
	--	 table.insert(t, {title = 'Фентези mp4', mrl = '#stream/genre=' .. '/genrefilm/fentezim/'})
	--	table.insert(t, {title = 'HD720 mp4', mrl = '#folder/genre=' .. '/hs720/'})
		
		
		
    --  table.insert(t, {title = 'Все mp4(сериалы)', mrl = '#stream/genre=' .. '/strseries/'})
     --   table.insert(t, {title = 'Боевик mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/boevikys/'})
	--	table.insert(t, {title = 'Военный mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/warrior/'})
	--	table.insert(t, {title = 'Драма mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/dramas/'})
	--	table.insert(t, {title = 'Комедия mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/2-komediya/'})
	--	 table.insert(t, {title = 'Мелодрама mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/4-melodrama/'})
	--	table.insert(t, {title = 'Приключения mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/priklyucheniyas/'})
	--	table.insert(t, {title = 'Триллер mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/triller/'})
	--	table.insert(t, {title = 'Фантастика mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/to2-fantastik/'})
	--	 table.insert(t, {title = 'Русские mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/tvr-russians/'})
		
	--	table.insert(t, {title = 'Детектив mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/detektives/'})
	--	table.insert(t, {title = 'Исторический mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/historikallys/'})
	--	 table.insert(t, {title = 'Криминал mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/kriminals/'})
		
	--	table.insert(t, {title = 'Семейный mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/semeynyys/'})
	--	table.insert(t, {title = 'Ужасы mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/3-horrors/'})
	--	 table.insert(t, {title = 'Фентези mp4(сериалы)', mrl = '#stream/genre=' .. '/genreserial/5-fentezis/'})		
	--	table.insert(t, {title = 'Дорамы mp4(сериалы)', mrl = '#stream/genre=' .. '/doramas/'})
		
    --    table.insert(t, {title = 'Коллекция mp4(сериалы)', mrl = '#stream/genre=' .. '/selection/'})
		

		
		

    table.insert(t, {title = 'ТВ-шоу', mrl = '#stream/genre=' .. '/shows/'})

		
		
		
          
        --table.insert(t, {title = 'Плейлист Топ', mrl = '#folder/genre=' .. '/playlist/top/'})
       table.insert(t, {title = 'Мульты Отечественные', mrl = '#folder/genre=' .. '/cartoon/rusmult/'})
        table.insert(t, {title = 'Мульты Зарубежные', mrl = '#folder/genre=' .. '/cartoon/zarubezmult/'})
     --   table.insert(t, {title = 'Мульты Все mp4', mrl = '#folder/genre=' .. '/cartoonis/'})
       -- table.insert(t, {title = 'Плейлист Фильмов mp4 Все', mrl = '#folder/genre=' .. '/playlist/'})
         
--https://kinotochka.co/index.php?story={searchTerms}&do=search&subaction=search

--https://kinotochka.co/?do=search&mode=advanced&subaction=search&story=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/?do=search&mode=advanced&subaction=search&story=' .. urlencode(args.keyword) --.. '#'  .. tostring(page)

		
		local x = http.getz(url)
		
        for url, image, title  in string.gmatch(x, '<a class="sres%-wrap clearfix.-href="(.-)".-<img.-src="(.-)".-<h2>(.-)</h2') do
			--url = string.gsub(url, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '#' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})





	-- #stream/q=content&id=/13879-rzhev-2019.html
	
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
        --x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1 itemprop="name".->(.-)смотреть онлайн</h1>')


   --     t['description'] = parse_match(x,'<div class="full%-text movie%-desc clearfix" itemprop="description">(.-)</div>')
--div class="full%-text movie%-desc clearfix" itemprop="description".-<br><br>(.-)<br>
        t['description'] = parse_match(x,'<div class="full%-text movie%-desc clearfix".-QuoteEEnd.->(.-)</div>')
      --  t['poster'] = args.p
		t['poster'] = parse_match(x,'<img itemprop="image" class="xfieldimage miniFiltereder" src="(.-)"')
		if t['poster'] then
		--	t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
	--	t['annotation'] = parse_array(x, {
		--	'(Оригинальное название:</span>.-)</div>', '(Год:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Жанр:</span>.-)</div>', '(Качество:</span>.-)</div>', '(Режиссер:</span>.-)</div>', '(В ролях:</span>.-)</div>', '(Год выпуска:</strong>.-)<br>',  '(Жанр:</strong>.-)<br>', '(Режиссёр:</strong>.-)<br>', '(В ролях:</strong>.-)<br>', '<span itemprop="alternativeHeadline">(.-)</span>',})
        --x = string.gsub(x, 'скачать', '')
  
  
  

  
  
  
  
  
       for url in string.gmatch(x, 'var player = new Playerjs.-player%-trailer.-file.-(https.-mp4)"') do

      --   t['view'] = 'grid'
         table.insert(t, {title = 'Трейлер', mrl = url})
		 end
  
         
        for url, title in string.gmatch(x, '<ul class="seasons%-list".-<a href="(.-)">(.-)</a>') do

      --   t['view'] = 'grid'
         table.insert(t, {title = title, mrl = '#stream/q=content&id=' ..  url})
		 end

		for url in string.gmatch(x, '<video.-src="(https.-mp4)"') do
         -- print(url) 
          table.insert(t, {title = 'Смотреть mp4', mrl = url})
		end
		
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-id:"playerjshd".-file:"(.-txt)"') do
         -- print(url)
      --    t['view'] = 'grid'
       --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' ..  url})
          table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})
		end





           for title, url in string.gmatch(x, '"comment":"(.-)".-file.-(https://s.-mp4)"') do
			print(url)  

          url = string.gsub(url, '_[480,720]', '')
          t['view'] = 'grid'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title), mrl = url})
   
   --     table.insert(t, {title = title .. (total), mrl = url})
        end


		for title, url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do
	--		print(url)  

    --      url = string.gsub(url, '(.-)', url) .. '_480.mp4'
          t['view'] = 'grid'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title) .. ' (480p)'  , mrl = url .. url1 .. '_480.mp4'})
   
   --     table.insert(t, {title = tolazy(title) .. (total), mrl = url})
        end
	
	
          for title,  url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do
		--	print(url)  

      --    url = string.gsub(url, '(.-)', url) .. '_720.mp4'
          t['view'] = 'grid'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title) .. ' (720p)', mrl = url .. url1 .. '_720.mp4'})
   
   --     table.insert(t, {title = tolazy(title) .. (total), mrl = url})
        end
	





       for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end
     --  for url in string.gmatch(x, '<a class="dlMediaAction%-download" href="(https.-mp4)?download"') do
    --   table.insert(t, {title = 'Смотреть', mrl = url})
	--	end

	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end