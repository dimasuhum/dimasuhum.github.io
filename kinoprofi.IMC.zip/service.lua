-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate


--http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=Погребенный (2023)

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local HOME = 'https://kinoprofi.day'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'windows-1251'
local conn1 = client.new()
conn1['encoding'] = 'utf-8'

conn['root'] = HOME_SLASH
conn1['root'] = HOME_SLASH


--HOME = 'https://kinoprofi.day'

--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
  --    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=2

	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
         local x = conn:load(url)

		for url, image, title  in string.gmatch(x, '<div class="short%-left".-<a.-href="(.-)".-<img.-data%-src="(/uploads.-jpg)" alt="(.-)"') do
          image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		
		end


        for url, image, title  in string.gmatch(x, '<a href="(/tags.-)".-url.-(/uploads.-jpg).-class="hyphenate">(.-)</span>') do
            image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = title, mrl = '#stream/genre=' .. url, image = image})
		
		end
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = conn:load(HOME)
		
       table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/kino-podborka.html'})
		local x = string.match(x, '<div class="side%-bc fx%-row">(.-)<a href="/films%-4k')
		for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
       table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/cartoons/'})
  
   --   table.insert(t, {title = 'Передачи', mrl = '#stream/genre=' .. '/doc/'})
  
--https://kinoprofi.day/index.php?do=search&story=Рокки&do=search&subaction=search  
        
--https://kinoprofi.day/index.php?do=search &subaction=search&story=Рокки&do=search&subaction=search        
--https://kinokrad.cc/index.php?story=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8&do=search&subaction=search
		
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
	
	--urlencode
      	local url = HOME .. '/index.php?story=' .. (args.keyword) .. '&do=search&subaction=search'

		--.. tostring(page)

    
	local x = conn:load(url)

        for url, image, title  in string.gmatch(x, '<div class="short%-left".-<a.-href="(.-)".-<img.-data%-src="(/uploads.-jpg)" alt="(.-)"') do
        
        
          image = string.gsub(image, '^(.-)', HOME)
          
       
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
   local x = conn1:load(args.id)
		
    	local url = '#folder/q=search&keyword=' .. (args.keyword) .. '&page=' .. tostring(page + 1)
		
    --	local url = '#folder/q=search&keyword=' .. HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search' .. '&page=' .. tostring(page + 1)

    --   table.insert(t,{title = url, mrl= url, image = '#self/next.png'})

		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
        
        
        
        
        
        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="mtext full%-text video%-box clearfix">(.-)<br>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Актеры:</span>.-)</div>', '(Перевод:</span>.-)</div>'
		})
		
        
    
--https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=Alien&year=1979&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG

--https://api.kinopoisk.dev/v1.4/movie?page=1&limit=10&id=386&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG

  
  
   -- for title, title1  in string.gmatch(x,'<h1.->(.-)%((.-)%)') do
  --  local x = conn1:load(args.id)
    
  --    title = urlencode(title)
     
  --    title = string.gsub(title, '+', '%%20')
  
      --url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')
      --.. ',' .. title1

    -- local x = conn1:load(url)

  --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
   
   -- for title3 in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
      
  --   url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '(' .. title1 .. ')'

  --   local x = conn1:load(url)

--    for title2  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do

     
     
     for url  in string.gmatch(x, 'iframe.-(https://vid.-)"') do
    
    table.insert(t, {title = 'Источники', mrl = '#stream/q=content&id=' .. url})
    
  --    local x = conn1:load(url)

   end

    for title3 in string.gmatch(x, '"kp":"(.-)"') do


--http://parsers.appfxml.com/http://kinopoisk.ru/?id=info&cid=6224943

    url1 = string.gsub(title3, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=info&cid=')

     local x = conn1:load(url1)
     
    for title, title1  in string.gmatch(x, 'fxml.-"title":"(.-)".-"description":".->.-: (.-)<br>') do

   --    url1 = string.gsub(title3, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=')

   --  table.insert(t, {title = url1, mrl = '#stream/q=content&id=' .. url1})
 --    end
 --   end


   --  for title3, title, title1  in string.gmatch(x, '"current_page":.-"id".-"kinopoisk_id":(.-),.-"name_russian":"(.-)".-"year.-:"(.-)"') do
    
    title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')

     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
    
   
  
  
  
url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/fancdn?kinopoisk_id=') .. '&uid=m7alois3'
    
   
     local x = conn1:load(url1)
   
   
     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url1 = string.gsub(url1, '\\u0026', '&')
    url1 = string.gsub(url1, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = 'fancdn' .. ':'.. tolazy(total), mrl = url1})

       
    end

    
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/fan.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
       
    
      local x = conn1:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(/lite/fan.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       
    
     local x = conn1:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = 'fancdn :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end
  
  
  
   
   
url1 = string.gsub(title, '^(.-)', 'https://lams.maxvol.pro/lite/kinobase?title=') .. '&year=' .. title1
    --.. '&uid=m7alois3'
   
  -- table.insert(t, {title = url1, mrl = url1})

  
 
     local x = conn1:load(url1)
    
      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lams.maxvol.pro')
    --  t['view'] = 'simple'

   table.insert(t, {title = tolazy(total) .. ' (' .. total1 .. ')', mrl = url2})

     end  
    end

--http://movixhd.online/lite/kinobase?title=%d0%b1%d1%83%d0%bc%d0%b0%d0%b6%d0%bd%d1%8b%d0%b9+%d0%b4%d0%be%d0%bc&year=2017&s=1
  

   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lams.maxvol.pro')
    
       
    
      local x = conn1:load(url2)

      
       

      for  total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-/proxy.-class="videos__item%-title">(.-серия)</div>') do
      
    local x = string.match(x, '"quality"(.-)}}')
    
    for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
  total3 = string.gsub(total3, ',"', '')
         
    url3 = string.gsub(url3, '^(.-)', 'https://lams.maxvol.pro')
    
     --  t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' ' .. tolazy(total2) .. ' (' .. total3 .. ')', mrl = url4})

    end   
    end
    end 
     

 
     
     
      url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/veoveo?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
   
   local x = conn1:load(url1)
     
       for  url2, total2 in string.gmatch(x, 'class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do

      t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2), mrl = url2})

      end 



     for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn1:load(url2)

for total3, url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-media="" s=.-e="(.-)".-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total3) .. ' серия' .. tolazy(total4), mrl = url4})

      end 
      end
   
   
   
   url1 = string.gsub(title3, '^(.-)', 'https://lamp.z-network.ru/lite/vdbmovies?kinopoisk_id=') 


  --  table.insert(t, {title = url1, mrl = '#stream/q=content&id=' .. url1, image = image})

 --   table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=content&id=' .. url1, image = image})
    --    end
  --     end
        
        
      local x = conn1:load(url1)
   
     for total1 in string.gmatch(x, '"method":"play".-"url":"http.-class="videos__item%-title">(.-)<') do
      
   
      local x = string.match(x, '"quality"(.-)"translate"')
      
      
   for total,  url2 in string.gmatch(x, '"(.-p)":"(http.-mp4)"') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :'.. tolazy(total) .. ' ' .. tolazy(total1), mrl = url2})

      end 
    end
    
    
    
        for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-videos__season%-title.->(.-сезон)</div>') do


      local x = conn1:load(url2)

   

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url".-"(http.-)".->(.-)</div>') do

     local x = conn1:load(url3)


      for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(http.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do

  --   url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end
   
     url1 = string.gsub(title3, '^(.-)', 'https://lams.maxvol.pro/lite/videodb?kinopoisk_id=')
     --.. '&title=' .. title .. '&year=' .. title1 
  
  
    
      local x = conn1:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'https://lams.maxvol.pro')
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'https://lams.maxvol.pro') 
       local x = conn:load(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'https://lams.maxvol.pro') 
       local x = conn1:load(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'https://lams.maxvol.pro')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
    



   
    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 
    
       
      local x = conn1:load(url1)

     
       for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   
      local x = conn1:load(url2 .. url3)

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :' .. tolazy(total2), mrl = url4})

      end 
      end
      

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn1:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn1:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end
 



url1 = string.gsub(title3, '^(.-)', 'http://93.183.92.183:9118/lite/mirage?kinopoisk_id=') .. '&uid=m7alois3'
    
--http://147.45.77.28:9118/lite/mirage?kinopoisk_id=386&uid=m7alois3
 
  --  table.insert(t, {title = 'Mirage', mrl = '#stream/q=content&id=' .. url1, image = image})
    --    end
    --    end
    local x = conn1:load(url1)
     
     for  url2, url3,  total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"http.-(/lite/mirage)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
  
      url3 = string.gsub(url3, '\\u0026', '&')

    
       local x = conn1:load(url2 .. url3)
    
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
    
       url4 = string.gsub(url4, '^(.-)', 'http://93.183.92.183:9118')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'mirage :' .. tolazy(total2) .. '(' .. tolazy(total3) .. ')', mrl = url4})

      end 
      end
     
  

      
       for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
       url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       
     url2 = string.gsub(url2, '\\u0026', '&')
     
   --  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn1:load(url2)


      for url3, url4, total1, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"url":"http.-(/lite/mirage)(.-)".-voice_name":"(.-)".-class="videos__item%-title">(.-серия)</div>') do

       url3 = string.gsub(url3, '^(.-)', 'http://93.183.92.183:9118')
       
     url4 = string.gsub(url4, '\\u0026', '&')
      local x = conn1:load(url3 .. url4)
     local x = string.match(x, '"quality"(.-)}')
      for  total3, url5 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
   
     url5 = string.gsub(url5, '^(.-)', 'http://93.183.92.183:9118')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'mirage :'  .. total .. ' '  .. tolazy(total2) .. '(' .. total3 .. ')' .. '(' .. total1 .. ')', mrl = url5})

    end
end
end
           
              


  url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/filmix?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
  
      local x = conn1:load(url1)
      
     for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"(http.-mp4)"') do
     
     
      
       t['view'] = 'simple'

   table.insert(t, {title = 'filmix' .. ':'.. tolazy(total2) .. (total3), mrl = url4})
    end
     end  


      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn1:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn1:load(url4)


      for url5, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'filmix :' .. total .. ' '  .. tolazy(total3) .. total2, mrl = url5})

       
    end

end
end





    
       url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=') 

    
     local x = conn1:load(url1)
   
   for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total), mrl = url2})

       
    end
    
      for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn1:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn1:load(url3)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

   --  url5 = string.gsub(url5, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end
end
end


   
       
     


  
    url1 = string.gsub(title, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/atodo.php?perewod=') 
   
     local x = conn1:load(url1)
      
         

       for  url2 in string.gmatch(x, '</playlist_name><channel>.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[(http.-)]]') do

      local x = conn1:load(url2)
      
      
     for  url3 in string.gmatch(x, '<title><!%[CDATA%[дальше]].-<playlist_url><!%[CDATA%[(http.-)]]') do

       local x = conn1:load(url3)
       
      for total, url4 in string.gmatch(x, '<title><!%[CDATA%[(.-)]].-<parser><!%[CDATA%[(http.-)|url"') do
        
        local x = conn1:load(url4)

     for  url5 in string.gmatch(x, '</playlist_name>url":"(http.-)"') do
     t['view'] = 'simple'
      table.insert(t, {title = 'atodo :' .. tolazy(total), mrl = url5})

     end
     end
     end
    end

         

       for  url2 in string.gmatch(x, '</playlist_name><channel>.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[(http.-)]]') do

      local x = conn1:load(url2)
      
      
     for  url3 in string.gmatch(x, '<title><!%[CDATA%[дальше]].-<playlist_url><!%[CDATA%[(http.-)]]') do
     
       local x = conn1:load(url3)
       
      for total, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url><!%[CDATA%[(http.-)]]') do
      
      local x = conn1:load(url4)

    for total1, url5 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]].-<playlist_url><!%[CDATA%[(http.-)]]') do

       local x = conn1:load(url5)
       
     for total2, url6 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]].-<parser><!%[CDATA%[(http.-)|url"') do


       local x = conn1:load(url6)
       
     for url7 in string.gmatch(x, '</playlist_name>url":"(http.-)"') do
     
     t['view'] = 'simple'
      table.insert(t, {title = 'atodo :' .. tolazy(total) .. ' ' ..  tolazy(total1) .. ' ' .. tolazy(total2), mrl = url7})

     end
     end
     end
    end
    end
    end
    



    url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn1:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn1:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title='alloha' .. ':' .. tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn1:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn1:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn1:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
      t['view'] = 'simple'
				table.insert(t,{title= 'alloha :' .. tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end







     
     url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/vdbmovies?kinopoisk_id=') .. '&uid=m7alois3'


--table.insert(t, {title = url1, mrl = '#stream/q=content&id=' .. url1, image = image})


 --   table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=content&id=' .. url1, image = image})
   --    end
 --      end

    local x = conn1:load(url1)

       for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-)</div>') do
  
      url1 = string.gsub(url1, '\\u0026', '&')
    url1 = string.gsub(url1, '^(.-)', 'http://178.20.46.40:12600')


      t['view'] = 'simple'


   table.insert(t, {title = 'vdbmovies' .. ':'.. tolazy(total), mrl = url1})

       
    end

    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

    --     url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
  --    table.insert(t, {title = url2, mrl = '#stream/q=content&id=' .. url2, image = image})
 --   end
  
      local x = conn1:load(url2)

     

      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
   --  table.insert(t, {title = url3, mrl = '#stream/q=content&id=' .. url3, image = image})
         
     --    url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       
    
     local x = conn1:load(url3)
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end

url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
    --.. '&rjson=true'

    local x = conn1:load(url1)



      for  url2, url3,  total, total1 in string.gmatch(x, '"play".-"url":"(http.-pidtor)(.-)".-class="videos__item%-title">(.-)<.-<!%-%-(.-)%-') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total) .. ' ' .. total1, mrl = url2 .. url3})

       
    end


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/remux?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

    local x = conn1:load(url1)

    

      for  url2, total in string.gmatch(x, '"url".-(http.-)quality.-class="videos__item%-title">(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      
       url2 = string.gsub(url2, '&', '')
      
      local x = conn1:load(url2)
      
       for  url3 in string.gmatch(x, '"play".-"url":.-(http.-)"') do

       t['view'] = 'simple'

   table.insert(t, {title = 'remux :' .. tolazy(total), mrl = url3})

     end  
    end




   
url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 
      


         url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 
      


     

  url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=') 
  --.. '&uid=m7alois3'
    
    
      local x = conn1:load(url1)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn1:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=') 

    local x = conn1:load(url1)


      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn1:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vibix :' .. tolazy(total1) .. total2, mrl = url3})

       
    end

end



url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/rezka?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

     local x = conn1:load(url1)
 
  
  
       for  url3, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. tolazy(total1), mrl = url3})
  --   end
     end  
  
         local x = conn1:load(url1)

     
     for url3, total2  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
     
     url3 = string.gsub(url3, '\\u0026', '&')

     url3 = string.gsub(url3, '\\u002B', '+')

  
     local x = conn1:load(url1)

   for url4, total3  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')

     url4 = string.gsub(url4, '\\u002B', '+')
     

      local x = conn1:load(url3)

      for url5, total4  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')

     url5 = string.gsub(url5, '\\u002B', '+')
     
    
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. total2 .. ' '  .. tolazy(total3) .. ' ' .. total4, mrl = url5})

       
    end
end
end

end
     
end     
     

  
  
  
  
  
  

  
  
  
    for title in string.gmatch(x, 'iframe="http.-api.-/embed/.-/(.-)"') do


      url = string.gsub(title, '^(.-)', 'http://178.20.46.40:12600/lite/collaps?orid=')
     local x = conn1:load(url)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
   --   t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

  --   end  
    end


   
  
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/collaps.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn1:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
    --   t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end
end
  
  
  
  
  
  
    
    
  --  for title, title1  in string.gmatch(x,'<h1.->(.-)%((.-)%)') do
  --  local x = conn1:load(args.id)
    
  --    title = urlencode(title)
     
    --  title = string.gsub(title, '+', '%%20')
      
--   url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')
   --.. ',' .. title1

    -- local x = conn1:load(url)

  --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
   
  --  for title3 in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
    
    
    
    
    for url  in string.gmatch(x, 'iframe.-(https://vid.-)"') do

     local x = conn1:load(url)

   for title3 in string.gmatch(x, '"kp":"(.-)"') do
   
   
 --  local x = conn:load(args.id)
   
   
  --  for title, title1 in string.gmatch(x, '<h1.->(.-) %((.-)%)') do
	
    --  title = urlencode(title)
     
  --    title = string.gsub(title, '+', '%%20')
      
  --   url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

  --  local x = conn1:load(url)

 --   for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
   
   
  -- table.insert(t, {title = url, mrl = url})
   
     url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
      local x = conn1:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn1:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end
   end
   end
   
   
   
   
 
  
  
    
    
    
    
    
    
--local x = conn:load(args.id)
        
          for url in string.gmatch(x, '<meta property="og:url" content=".-//(.-)"') do
       -- url = string.gsub(url, '^(.-)', 'https://')
        
        url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https://')
        
        --table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
       --end
       
       
       
       local x = http.getz(url)
       
        for url in string.gmatch(x, 'id=file&u=(.-)"') do
	




     url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=file&u=')
        
    --    table.insert(t, {title = url, mrl = url})
       
        local x = http.getz(url)

         for title, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
         for title, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
        for title, url in string.gmatch(x, '(720p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       for title, url in string.gmatch(x, '(720p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')
       url = string.gsub(url, '720', '1080')

       table.insert(t, {title = '1080p', mrl = url})

       end
     	end

end

    
    
    
   -- for title, title1  in string.gmatch(x,'<h1.->(.-)%((.-)%)') do
  
       -- title = urlencode(title)
      
    --  title = string.gsub(title, '+', '%%20')

  --  url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')
    --.. ',' .. title1

   --  local x = conn1:load(url)

  --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
   
   -- for title3 in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
    
    
    
      for url  in string.gmatch(x, 'iframe.-(https://vid.-)"') do

      local x = conn1:load(url)

    for title3 in string.gmatch(x, '"kp":"(.-)"') do
    
   url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/lumex?kinopoisk_id=') 
       --.. '&uid=m7alois3'
 
   table.insert(t, {title = 'Lumex', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
        end
    
    
     local x = conn1:load(args.id)
    
        
for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/lite/lumex.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
   url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
       t['view'] = 'simple'

   table.insert(t, {title = 'lumex :' .. tolazy(total), mrl = url2})

       
    end
     

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite/lumex.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn1:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button.-"link".-"url".-(/lite/lumex.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn1:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie.-"play".-"url".-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://178.20.46.40:12600')
    
  --    url4 = string.gsub(url4, 'rjson=False&', '')
    
    
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end
   
  --   local x = conn:load(args.id)
   
    
  --  for title, title1  in string.gmatch(x,'<h1.->(.-)%((.-)%)') do
  
      --  title = urlencode(title)
      
     -- title = string.gsub(title, '+', '%%20')

  --  url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=')
    --.. ',' .. title1

   --  local x = conn1:load(url)

  --  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
   
   -- for title3 in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
    
    
    
    
--for url  in string.gmatch(x, 'iframe.-(https://vid.-)"') do

  --    local x = conn1:load(url)

 --   for title3 in string.gmatch(x, '"kp":"(.-)"') do
    
    
 
    
    
    
    
    
 

        

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end