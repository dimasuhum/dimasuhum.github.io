-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate




local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local HOME = 'https://kinoprofi.day'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'windows-1251'
local conn1 = client.new()
conn1['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH
conn1['root'] = HOME_SLASH


--HOME = 'https://kinoprofi.day'

--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
    --    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=2

	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
	--	local x = http.getz(url)
         local x = conn:load(url)

		for url, image, title  in string.gmatch(x, '<div class="short%-left".-<a.-href="(.-)".-<img.-data%-src="(/uploads.-jpg)" alt="(.-)"') do
          image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		
		end


        for url, image, title  in string.gmatch(x, '<a href="(/tags.-)".-url.-(/uploads.-jpg).-class="hyphenate">(.-)</span>') do
            image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = title, mrl = '#stream/genre=' .. url, image = image})
		
		end
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = conn:load(HOME)
		
       table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/kino-podborka.html'})
		local x = string.match(x, '<div class="side%-bc fx%-row">(.-)<a href="/films%-4k')
		for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
       table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/cartoons/'})
  
   --   table.insert(t, {title = 'Передачи', mrl = '#stream/genre=' .. '/doc/'})
  
--https://kinoprofi.day/index.php?do=search&story=Рокки&do=search&subaction=search  
        
--https://kinoprofi.day/index.php?do=search &subaction=search&story=Рокки&do=search&subaction=search        
--https://kinokrad.cc/index.php?story=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8&do=search&subaction=search
		
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
	
	
      	local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
	--	local url = HOME .. '/index.php?story=' .. conn:load(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)

    --    local x = http.getz(url)
		local x = conn:load(url)
		
        for url, image, title  in string.gmatch(x, '<div class="short%-left".-<a.-href="(.-)".-<img.-data%-src="(/uploads.-jpg)" alt="(.-)"') do
          image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
        
        
        
        
        
        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="mtext full%-text video%-box clearfix">(.-)<br>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Актеры:</span>.-)</div>', '(Перевод:</span>.-)</div>'
		})
		
        
        
          for url in string.gmatch(x, '<meta property="og:url" content=".-//(.-)"') do
       -- url = string.gsub(url, '^(.-)', 'https://')
        
        url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=info&act=https://')
        
        --table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
       --end
       
       
       
       local x = http.getz(url)
       
        for url in string.gmatch(x, 'id=file&u=(.-)"') do
	




     url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/http://kinokrad.co/?id=file&u=')
        
    --    table.insert(t, {title = url, mrl = url})
       
        local x = http.getz(url)

         for title, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
         for title, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
        for title, url in string.gmatch(x, '(720p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       for title, url in string.gmatch(x, '(1080p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
     	end

end




 
 
    for title, total  in string.gmatch(x,'<h1.->(.-)%((.-)%)') do

      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
     url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    
     
    table.insert(t, {title = 'Torrs', mrl = '#stream/q=content&id=' .. url, image = image})
         end
   
   
  --     for title, total  in string.gmatch(x,'%[{"size".-"originalname":"(.-)".-"relased":(.-),') do

  --   url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '(' .. total .. ')'
     

	--	local x = conn1:load(url)
		
    
    
    
	--	for total1 in string.gmatch(x, '"fxml".-"playlist_url":"http.-?id=info&cid=(.-)"') do

         for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?&kinopoisk_id=')
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end
     
     




      for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'https://lam.akter-black.com/lite/zetflix?&kinopoisk_id=')
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end
     



     for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'http://93.183.92.183:9118/lite/fancdn?&kinopoisk_id=')
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       t['view'] = 'simple'

   table.insert(t, {title = 'fancdn' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end
     
     
--https://lam.akter-black.com/lite/vibix?kinopoisk_id=386
     
     
     for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=')
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --  url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       t['view'] = 'simple'

   table.insert(t, {title = 'vibix' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end
 
--http://93.183.92.183:9118/lite/lumex?&kinopoisk_id=5942378&uid=m7alois3


     for total  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do

      url1 = string.gsub(total, '^(.-)', 'http://93.183.92.183:9118/lite/lumex?&kinopoisk_id=') .. '&uid=m7alois3'
    
         
      
      local x = http.get(url1)
     
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/lite.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       t['view'] = 'simple'

   table.insert(t, {title = 'lumex' .. ':'.. tolazy(total2), mrl = url2})

       
    end
     end



    for total in string.gmatch(x,'%[{"size.-trackerName.-kinozal.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        

       url = string.gsub(total, '^(.-)','http://torr.unknot.ru:8090/stream/?link=') .. '&m3u'
      

        local x = http.get(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
         t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
         t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
        t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	



      for total in string.gmatch(x,'%[{"size.-trackerName.-nnmclub.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        
      url = string.gsub(total, '^(.-)','http://torr.unknot.ru:8090/stream/?link=') .. '&m3u'
      

        local x = http.get(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     
     t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
        t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
        t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	




 
 
 

      for title, total  in string.gmatch(x,'<h1.->(.-)%((.-)%)') do

      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
       url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '(' .. total .. ')'
     

		local x = conn1:load(url)
		
    	for total1 in string.gmatch(x, '"fxml".-"playlist_url":"http.-?id=info&cid=(.-)"') do  
  
       
      url1 = string.gsub(total1, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=') 

         table.insert(t, {title = 'Источники', mrl = '#stream/q=content&id=' .. url1})
        end
        end

         
         
        for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   

         url = string.gsub(url, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=')



      --   url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=')

    --    url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=0&kinopoisk_id=')
        

      local x =  http.getz(url)
       
    
      
       
       for total, url, title in string.gmatch(x, '"method":"play","url".-(1080p).-(http.-)".-class="videos__item%-title">(.-)<') do
       
   --    local title = json.decode(title)
   --    print(title)
       
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
			
			
      for total, url, title in string.gmatch(x, '"method":"play","url".-(720p).-(http.-)".-class="videos__item%-title">(.-)<') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
   
      for total, url, title in string.gmatch(x, '"method":"play","url".-(480p).-(http.-)".-class="videos__item%-title">(.-)<') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for total, url, title in string.gmatch(x, '"method":"play","url".-(360p).-(http.-)".-class="videos__item%-title">(.-)<') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end
--end
        
        
          for url2  in string.gmatch(x, 'current_page".-"data":%[{"id.-"kinopoisk_id":(.-),') do
       

        url = string.gsub(url2, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=22&kid=')
       
        local x = http.getz(url)


       for title, url3 in string.gmatch(x, '\'title\': \'(Season) (.-)\',') do


        local x = http.getz('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)
  
  
     
      
   --   local x = http.getz('https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)


  
        for url5, total5  in string.gmatch(x, 'method":"link".-(&t=.-)".->(.-)</div>') do


       local x = http.getz('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3 .. url5)



       for url4, total2  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do

        total2 = string.gsub(total2, '\\u0441\\u0435\\u0440\\u0438\\u044F', 'серия')

       t['view'] = 'simple'
   
   

      table.insert(t, {title = title .. ' ' .. url3 .. (total2) .. (total5), mrl = url4})
    

	end
    end
    end
    end
    





         
         

     
        

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end