-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')

--local support = require('support')
--local parser = require('parser')

--local video = require('video')
--local client = require('client')


--http://stvplay.mooo.com:81/cub/cub.php?select=1&id=83533&title=Аватар: Пламя и пепел&original_title=Avatar: Fire and Ash&original_language=en&year=2025&serial=0&imdb_id=tt1757678&kinopoisk_id=570402


--http://stvplay.mooo.com:81/cub/cub.php?select=1&id=83533&title=Аватар: Пламя и пепел&year=2025&serial=0&kinopoisk_id=570402


--local HOME = 'http://stvplay.mooo.com:81/cub/cub.php'

local HOME1 = 'http://parsers.appfxml.com'
local HOME = 'https://cub.red/api/collections'

local HOME2 = 'https://kinopoiskapiunofficial.tech/api/v2.2/films'

--https://cub.red/api/collections/view/180
--https://cub.red/api/collections/view/249204?=

local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

local conn1 = client.new()
conn1['encoding'] = 'windows-1251'


--  HOME = 'http://stvplay.mooo.com:81/cub/cub.php?col=1&sort=releases&name=Релизы'

--http://stvplay.mooo.com:81/cub/cub.php?col=1&topic=128-per-rishar-luchshee&serial=0

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
   table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

-- #stream/page=2
-- #stream/genre=col=1&genre=27
	if not args.q then
	
--https://cub.red/api/collections/list?=

--https://imagetmdb.cub.red/t/p/w355_and_h200_multi_faces/cYQvXNPZLow73lhspVQ7CYlT3Mi.jpg

		local page = tonumber(args.page or 1)
	
		local genre = args.genre or '/list?='
		local url = HOME .. genre
     
	 url = url .. '&page=' .. tostring(page)
--	local x = conn:load(url)
       
	local x = http.get(url)
	
       for id, title, image in string.gmatch(x, '{"id":(.-),.-"title":"(.-)".-"backdrop_path":"(/.-)"') do

	image = string.gsub(image, '^(.-)', 'https://imagetmdb.cub.red/t/p/w355_and_h200_multi_faces')
	
	
    
	
 --  id = string.gsub(id, '^(.-)', '/view/') .. '?='
	
	
 --  table.insert(t, {title = id, mrl = '#stream/genre=' ..  id, url = url, image = image})
	
	table.insert(t, {title = title, mrl = '#stream/q=coll&id='.. id, image = image})
end

 
 local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' ..  genre
		
		
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
 
    elseif args.q == 'coll' then
		
		local page = tonumber(args.page or 1)
		local x = conn:load(HOME .. '/view/' .. args.id .. '?=' .. '&page=' .. tostring(page))
		
		x = string.gsub(x, '"name":', '"title":')
		
			for title, image, url in string.gmatch(x,'{"adult".-"title":"(.-)".-"poster_path":"(/.-)".-"kinopoisk_id":"(.-)"') do
	image = string.gsub(image, '^(.-)', 'https://imagetmdb.cub.red/t/p/w300')	


			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		
	end		
  
  
local url = '#stream/page=' .. tostring(page + 1) .. '&q=coll&id=' .. args.id
		
		
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
   
	

  





		
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'





--	local genre = args.genre or '/list?='
		local x = conn:load(HOME .. '/list?=')
     
--	 url = url .. '&page=' .. tostring(page)
--	local x = conn:load(url)
       
	
       for genre, title, image in string.gmatch(x, '{"id":(.-),.-"title":"(.-)".-"backdrop_path":"(/.-)"') do

	image = string.gsub(image, '^(.-)', 'https://imagetmdb.cub.red/t/p/w355_and_h200_multi_faces')
	
	
    
	
   genre = string.gsub(genre, '^(.-)', '/view/') .. '?='
	
	
 --  table.insert(t, {title = genre, mrl = '#stream/genre=' ..  genre, image = image})
	
	table.insert(t, {title = tolazy(title), mrl = '#stream/genre='.. genre, image = image})
end





--http://stvplay.mooo.com:81/cub/cub.php?col=1&genre=27&serial=0&name=Ужасы

table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. 'genre=1'})

table.insert(t, {title = 'Подборка', mrl = '#stream/genre=' .. 'topic=257'})

      local x = conn:load(HOME .. 'genres=1')

		
--http://stvplay.mooo.com:81/cub/cub.php?genres=1&name=Фильмы
		
        
	--	local x = string.match(x, '<ul class="reset top%-menu">(.-)</ul>')
		for title, genre in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url>.-http.-(genre.-)&serial') do
			table.insert(t, {title = 'Фильмы : ' .. title, mrl = '#stream/genre=' .. genre})
		end
     
     
    local x = conn:load(HOME .. 'genres=2')

		
--http://stvplay.mooo.com:81/cub/cub.php?genres=1&name=Фильмы

--http://stvplay.mooo.com:81/cub/cub.php?col=1&search=1&name=фильмы&search=Чужой		
        
	--	local x = string.match(x, '<ul class="reset top%-menu">(.-)</ul>')
		for title, genre in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url>.-http.-(col.-)&serial') do
			table.insert(t, {title = 'Сериалы : ' .. title, mrl = '#folder/genre=' .. genre})
		end
     
     
     
     
        
   --     local x = http.get(HOME .. '/kino-podborka.html')
       -- x = iconv(http.get(HOME .. '/kino-podborka.html'), 'WINDOWS-1251', 'UTF-8')
        --x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--local x = string.match(x, '<nav class="side%-box to%-mob">(.-)</nav>')
		--for genre, title in string.gmatch(x, '<a href="(.-)".-<span class="podborki%-title">(.-)</span>') do
		--	table.insert(t, {title = title, mrl = '#folder/genre=' .. genre})
	--	end
  
  
  
elseif args.q == 'list' then
   
local page = tonumber(args.page or 1)
   
   local x = conn:load('https://proxy4.rte.net.ru/https://api.poiskkino.dev/v1.4/' .. args.id .. '?page=' .. tostring(page) .. '&limit=10&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG') 
   
  
  
  for id, image, title in string.gmatch(x, '"slug":"(.-)".-"cover":.-"url":"(.-)".-"name":"(.-)"') do
  
    table.insert(t, {title = tolazy(title), mrl = '#stream/q=collection&id=' .. id, image = image})
	end	
  
  local url = '#stream/page=' .. tostring(page + 1) .. '&q=list&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
  
  
  elseif args.q == 'collection' then
  
   local page = tonumber(args.page or 1)
   
   local x = conn:load('https://proxy4.rte.net.ru/https://api.poiskkino.dev/v1.4/movie?lists=' .. args.id .. '&language=RU' .. '&page=' .. tostring(page) .. '&limit=10&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
  


x = string.gsub(x, '("names".-])', '')
	
 x = string.gsub(x, '("genres".-])', '')
 x = string.gsub(x, '("countries".-])', '')



  for id, title,  image  in string.gmatch(x, '"id":(.-),.-"name":"(.-)".-"poster".-"url":"(http.-)"') do
  
--https://api.kinopoisk.dev/v1.4/movie?lists=top250&page=1&limit=10&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG
  
  
--table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. title, image = image})
  
 table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. id, image = image})
	end	


  
  local url = '#stream/page=' .. tostring(page + 1) .. '&q=collection&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
  





    elseif args.q == 'acter' then
   
   local x = conn:load('https://proxy4.rte.net.ru/https://api.poiskkino.dev/v1.4/movie/' .. args.id .. '?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
  
     local x = string.match(x, '"persons":(.-)"lists"')
     
     for id, image, title, total  in string.gmatch(x, '"id":(.-),.-photo":"(http.-)".-"name":"(.-)".-"profession":"(.-)"') do   
 
       table.insert(t, {title = title .. '  (' .. total .. ')', mrl = '#stream/q=person&id=' .. id, image = image})
       end 
 
 
 

 
elseif args.q == 'persons' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
      
   --   HOME = string.gsub(HOME, '?id=navigator&genre=', '') 
		
		local url = 'https://proxy4.rte.net.ru/https://api.poiskkino.dev/v1.4/person/search' .. '?page=' .. tostring(page) .. '&limit=10&query=' ..    urlencode(args.keyword) .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'


		local x = conn:load(url)
	
		
        for id, title, image in string.gmatch(x, '"id":(.-),"name":"(.-)".-"photo":"(.-)"') do
    
  

        
			table.insert(t, {title = title, mrl = '#stream/q=person&id=' .. id, image = image})
		end
		
    	local url = '#folder/q=persons&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
 
 
 
 
 
 
 
 
    elseif args.q == 'person' then
   
   local x = conn:load('https://proxy4.rte.net.ru/https://api.poiskkino.dev/v1.4/person/' .. args.id .. '?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
  
 
--https://api.kinopoisk.dev/v1.4/person/6915?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG
 

local x = string.match(x, '"movies":(.-)]')
     
     for id, title, total  in string.gmatch(x, '"id":(.-),.-"name":"(.-)".-"enProfession":"(.-)"') do   
 
 
image = string.gsub(id, '^(.-)', 'https://kinopoiskapiunofficial.tech/images/posters/kp_small/') .. '.jpg' 
 
       table.insert(t, {title = title .. '  (' .. total .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
       end 





   
   elseif args.q == 'similar' then
  
  local headers = {['accept'] = 'application/json',['X-API-KEY'] = 'c20595a1-3d8c-4cbd-92eb-fd7b0fa75c67'}
 
 
    
 
  
   local x = http.get(HOME2 .. '/' .. args.id .. '/similars', headers)
  
   
for id, title, image in string.gmatch(x, '"filmId":(.-),.-"nameRu":"(.-)".-"posterUrl":"(http.-)"') do
        

		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. id, image = image})
		end
     
elseif args.q == 'relations' then
  
local headers = {['accept'] = 'application/json',['X-API-KEY'] = 'c20595a1-3d8c-4cbd-92eb-fd7b0fa75c67'}
 
 
    
 
   local x = http.get(HOME2 .. '/' .. args.id .. '/relations', headers)
  
   
for id, title, image in string.gmatch(x, '"kinopoiskId":(.-),.-"nameRu":"(.-)".-"posterUrl":"(http.-)"') do
        

		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. id, image = image})
		end
		
	elseif args.q == 'sequels_and_prequels' then
  
local headers = {['accept'] = 'application/json',['X-API-KEY'] = 'c20595a1-3d8c-4cbd-92eb-fd7b0fa75c67'}
 
 
    
  
  
 -- https://kinopoiskapiunofficial.tech/api/v2.1/films/386/sequels_and_prequels
  
   local x = http.get('https://kinopoiskapiunofficial.tech/api/v2.1/films/' .. args.id .. '/sequels_and_prequels', headers)
  
   
for id, title, image in string.gmatch(x, '"filmId":(.-),.-"nameRu":"(.-)".-"posterUrl":"(http.-)"') do
        

		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. id, image = image})
		end


    elseif args.q == 'collect' then
  
   local x = conn:load('https://proxy4.rte.net.ru/https://api.poiskkino.dev/v1.4/movie/' .. args.id .. '?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG')
  
   local x = string.match(x, '"lists"(.-)]')
 
 for id in string.gmatch(x, '"(.-)"') do
  
  
     t['view'] = 'simple'

			table.insert(t, {title=id, mrl = '#stream/q=collection&id=' .. id, image = image})
		end
  
  
  
  
        
   elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
      
   --   HOME = string.gsub(HOME, '?id=navigator&genre=', '') 
		
		local url = HOME1 .. '/https://www.kinopoisk.ru/?id=search&search=' .. urlencode(args.keyword) .. '&p=' .. tostring(page)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
	
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
	
		
        for  title, url, image in string.gmatch(x, '{"title":"(.-)".-"playlist_url":".-?id=info&cid=(.-)".-"logo.-:"(.-.jpg)"') do

 
  
    image = string.gsub(image, '\\', '') 
  
  
 --   url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=')
    
        
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
       
       
       
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html


	elseif args.q == 'content' then
		t['view'] = 'annotation'
	
	local headers = {['accept'] = 'application/json',['X-API-KEY'] = 'c20595a1-3d8c-4cbd-92eb-fd7b0fa75c67'}
 
 
    

  
  local x = http.get('https://kinopoiskapiunofficial.tech/api/v2.2/films/' .. args.id, headers)
  
   
  -- local x = conn:load('https://apn-latest.onrender.com/https://api.poiskkino.dev/v1.4/movie?id=' .. args.id.. '&token=APDGYB9-VV5MWKH-K3EZDXM-SQG2YYN')

x = string.gsub(x, '{"name":"', '')
x = string.gsub(x, '"}', '')

x = string.gsub(x, '"genres":%[', 'Жанр:')
  x = string.gsub(x, '{"genre":"', '')
  
  --  table.insert(t, {title = 'https://apn-latest.onrender.com/https://api.poiskkino.dev/v1.4/movie?id=' .. args.id.. '&token=APDGYB9-VV5MWKH-K3EZDXM-SQG2YYN', mrl = '#stream/q=video&id1=' .. 'https://api.poiskkino.dev/v1.4/movie?id=' .. args.id.. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG', image = image})

	
--/http:\/\/kinopoisk.ru\/?id=info&cid=
	
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'{"id":.-"name":"(.-)".-"year":(.-),')
		t['description'] = parse_match(x,'"description":"(.-)"')
   
      t['annotation'] = parse_array(x, {
			'"year":(.-),', '(Жанр:.-)]',
		})
   
       t['poster'] = args.p
	--	t['poster'] = parse_match(x,'poster.-"(http.-)"')
--		if t['poster'] then
	--		t['poster'] = string.gsub(t['poster'], '\\', '')
--		end

 
 

 
 for id1 in string.gmatch(x, '"nameRu":"(.-)"') do
 for id2 in string.gmatch(x, '"year":(.-),') do 
 
     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=video&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. args.id, image = image})
		
		end
 end
 
      

table.insert(t, {title = 'Похожие', mrl = '#stream/q=similar&id=' .. args.id, image = image})
 
 table.insert(t, {title = 'Связанные', mrl = '#stream/q=relations&id=' .. args.id, image = image})
 
table.insert(t, {title = 'Сиквелы и приквелы', mrl = '#stream/q=sequels_and_prequels&id=' .. args.id, image = image})
 

     -- for title  in string.gmatch(x, '"id":(.-),') do
table.insert(t, {title = 'Актёры', mrl = '#stream/q=acter&id=' .. args.id, image = image})
      -- end
       
       
    
      --for title  in string.gmatch(x, '"id":(.-),') do
table.insert(t, {title = 'Коллекции', mrl = '#stream/q=collect&id=' .. args.id, image = image})
      -- end 
       
       
       
    elseif args.q == 'video' then

      t['view'] = 'list'



 --   table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})

     


  
  
  table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 table.insert(t, {title = 'HdvbF', mrl = '#stream/q=hdvbf&id3=' .. args.id3, image = '#self/movie.png'})
  
 table.insert(t, {title = 'Zagonka', mrl = '#stream/q=zagonka&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})


table.insert(t, {title = 'Kinobadi', mrl = '#stream/q=kinobadi&id3=' .. args.id3, image = '#self/movie.png'})


table.insert(t, {title = 'TurboDB', mrl = '#stream/q=turbo&id3=' .. args.id3, image = '#self/movie.png'})


 -- table.insert(t, {title = 'Hdvb3', mrl = '#stream/q=hdvb2&id3=' .. args.id3, image = '#self/movie.png'})
  

  
  table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id3=' .. args.id3,image = '#self/movie.png'})
  
       table.insert(t, {title = 'Collaps', mrl = '#stream/q=collaps&id3=' .. args.id3, image = '#self/movie.png'})

table.insert(t, {title = 'Collaps2', mrl = '#stream/q=collaps2&id3=' .. args.id3, image = '#self/movie.png'})



--  table.insert(t, {title = 'Collaps-dash', mrl = '#stream/q=collaps-dash&id3=' .. args.id3, image = '#self/movie.png'})
  
       
       table.insert(t, {title = 'Kino4k', mrl = '#stream/q=kino4k&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
  
   table.insert(t, {title = 'Filmix', mrl = '#stream/q=filmix&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
--table.insert(t, {title = 'Filmix2', mrl = '#stream/q=filmix2&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 
 table.insert(t, {title = 'Kinoportal', mrl = '#stream/q=filmixred&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 
 
 
 --  table.insert(t, {title = 'Lumex', mrl = '#stream/q=lumex&id3=' .. args.id3, image = '#self/movie.png'})
   
   table.insert(t, {title = 'Videocdn', mrl = '#stream/q=videocdn&id3=' .. args.id3, image = '#self/movie.png'})
 
 --  table.insert(t, {title = 'Vcdn', mrl = '#stream/q=vcdn&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
   
--  table.insert(t, {title = 'Kinopub', mrl = '#stream/q=kinopub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
 --table.insert(t, {title = 'Kinoportal', mrl = '#stream/q=kinopubtv&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3, image = '#self/movie.png'})
       
   
   
   
       
 --  table.insert(t, {title = 'Alloha', mrl = '#stream/q=alloha&id3=' .. args.id3, image = '#self/movie.png'})
    
    table.insert(t, {title = 'Aladdin', mrl = '#stream/q=spectre&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 
table.insert(t, {title = 'Paladin', mrl = '#stream/q=phantom&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
  table.insert(t, {title = 'Mirage', mrl = '#stream/q=mirage&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})


table.insert(t, {title = 'ZeroHD', mrl = '#stream/q=zerohd&id3=' .. args.id3, image = '#self/movie.png'})


--table.insert(t, {title = 'Videodb', mrl = '#stream/q=videodb&id3=' .. args.id3 .. '&id1=' .. args.id1, image = '#self/movie.png'})

 
--table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 table.insert(t, {title = 'ZetflixDB', mrl = '#stream/q=zetflixdb&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 --table.insert(t, {title = 'Turbo', mrl = '#stream/q=videodb1&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 
 
  
  table.insert(t, {title = 'Vibix', mrl = '#stream/q=vibix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
 --  table.insert(t, {title = 'Videx', mrl = '#stream/q=vibix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
 --  table.insert(t, {title = 'ViDex', mrl = '#stream/q=vibex&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
 table.insert(t, {title = 'ViDex', mrl = '#stream/q=videx&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
--table.insert(t, {title = 'Kinozen', mrl = '#stream/q=kinozen&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 
 
 
   
 table.insert(t, {title = 'Awmzone', mrl = '#stream/q=awmzone&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 table.insert(t, {title = 'Fanserial', mrl = '#stream/q=fanserial&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
  
table.insert(t, {title = 'Seasonvar', mrl = '#stream/q=seasonvar&id1=' .. args.id1, image = image, image = '#self/movie.png'})
  

  
  
  
 -- table.insert(t, {title = 'Cdnmovies', mrl = '#stream/q=cdnmovies&id3=' .. args.id3, image = '#self/movie.png'})


--  table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=vdbmovies&id3=' .. args.id3, image = '#self/movie.png'})
  

  
   table.insert(t, {title = 'Krasview', mrl = '#stream/q=krasview&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 
 
 
 table.insert(t, {title = 'Scts', mrl = '#stream/q=scts&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
--   table.insert(t, {title = 'Sakhtv', mrl = '#stream/q=sakhtv&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
   
  -- table.insert(t, {title = 'Getstv', mrl = '#stream/q=getstv&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
    
    table.insert(t, {title = 'Anwap', mrl = '#stream/q=anwap&id1=' .. args.id1 .. '&id5=' .. '1' .. '&id6=' .. 'on', image = '#self/movie.png'})
    
   table.insert(t, {title = 'Kinotochka', mrl = '#stream/q=kinotochka&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   


table.insert(t, {title = 'Voidboost', mrl = '#stream/q=voidboost&id3=' .. args.id3, image = '#self/movie.png'})

 table.insert(t, {title = 'HDRezka', mrl = '#stream/q=hdrezkatest&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
  table.insert(t, {title = 'Rezka', mrl = '#stream/q=rezka&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
   table.insert(t, {title = 'FxmlRezka', mrl = '#stream/q=fxmlrezka&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
   
   
   table.insert(t, {title = 'Kinobase', mrl = '#stream/q=kinobase&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 

--table.insert(t, {title = 'Kinotop', mrl = '#stream/q=kinotop&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 
 
table.insert(t, {title = 'Kinoserials', mrl = '#stream/q=videoseed2&id3=' ..  args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
  
 table.insert(t, {title = 'Videoseed', mrl = '#stream/q=videoseed&id3=' .. args.id3, image = '#self/movie.png'})
 
 
 table.insert(t, {title = '24kino', mrl = '#stream/q=24kino&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 
 table.insert(t, {title = 'Mirkino', mrl = '#stream/q=mirkino&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
   table.insert(t, {title = 'Vkmovie', mrl = '#stream/q=vkmovie&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
   table.insert(t, {title = 'Rutube', mrl = '#stream/q=rutube&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
   
   table.insert(t, {title = 'Kinoflix', mrl = '#stream/q=kinoflix&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
   
table.insert(t, {title = 'Videohub', mrl = '#stream/q=videohub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
 
 table.insert(t, {title = 'Shizard', mrl = '#stream/q=shizard&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
 
 
  table.insert(t, {title = 'Atodo', mrl = '#stream/q=atodo&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = '#self/movie.png'})
  
 
  
 --table.insert(t, {title = 'test', mrl = '#stream/q=test&id1=' .. args.id1 .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
  
-- table.insert(t, {title = 'Kinogotest', mrl = '#stream/q=kinogotest&id1=' .. args.id1 .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
  table.insert(t, {title = 'Kinogo', mrl = '#stream/q=kinogox&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
  
  
   
table.insert(t, {title = 'Remux', mrl = '#stream/q=remux&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
   
 --  table.insert(t, {title = 'Jac', mrl = '#stream/q=jac&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
  
  
  table.insert(t, {title = 'Jacred', mrl = '#stream/q=jacred&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
  
   
   table.insert(t, {title = 'Pidtor', mrl = '#stream/q=pidtor&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' .. args.id3, image = '#self/movie.png'})
   
-- table.insert(t, {title = 'Potok', mrl = '#stream/q=potok&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
 
 --  table.insert(t, {title = 'Torrs', mrl = '#stream/q=torrs&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
   
  -- table.insert(t, {title = 'Torrs', mrl = '#stream/q=torrsuuu&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})
   
   
   table.insert(t, {title = 'Veo', mrl = '#stream/q=veo&id3=' .. args.id3, image = '#self/movie.png'})
   
   
table.insert(t, {title = 'Veoveo', mrl = '#stream/q=veoveo&id3=' .. args.id3 .. '&id1=' .. args.id1, image = '#self/movie.png'})

--table.insert(t, {title = 'Rapidcdn', mrl = '#stream/q=rapidcdn&id1=' .. args.id1 .. '&id2=' .. args.id2, image = '#self/movie.png'})




table.insert(t, {title = 'Xkino', mrl = '#stream/q=xkino&id1=' .. args.id1, image = '#self/movie.png'})




    elseif args.q == 'flixcdn' then

--https://storage.kinohd.co/movies/575b6f10170af1dd33e2f8ac560365cce622f972/f182fc6c13f2e3a34c4e9e9882a34dba:2026082709/720.mp4:hls:manifest.m3u8

 --https://player0.flixcdn.space/show/kinopoisk/1044280?domain=flixcdn.live&season=1&token=3218fae1545746e1b03cb7178bd1827b
 
 local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=flixcdn.live&token=3218fae1545746e1b03cb7178bd1827b')


for id, translation in string.gmatch(x,'"id":(.-),"is_serial":false.-"translations":%[(.-)].-"type":"movie"') do

for trans, title in string.gmatch(translation,'{"id":(.-),"title":"(.-)"') do

local player = 'https://tarantino.factorios.live/api/player/files'



local headers = {
    ["Host"] = "tarantino.factorios.live",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Referer"] = "https://tarantino.factorios.live/show/kinopoisk/" .. args.id3 .. "?domain=flixcdn.live&token=3218fae1545746e1b03cb7178bd1827b",
  ["Cookie"] = "_ga_ECHML7LBXL=GS2.1.s1778775911$o1$g0$t1778775911$j60$l0$h0; _ga=GA1.1.1864259193.1778775912"
}

local params = '{"id":' .. id.. ',"season_number":null,"translation":' .. trans .. '}'

local x = http.postz(player, headers, params)

local file = string.match(x,'{"file":"(.-)}') 

t['view'] = 'list'

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

table.insert(t, {title = qual .. 'p ' .. title, mrl = url, image = '#self/movie.png'})


local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '480.mp4') 

table.insert(t, {title = '480p ' .. title, mrl = url, image = '#self/movie.png'})

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '720.mp4') 

table.insert(t, {title = '720p ' .. title, mrl = url, image = '#self/movie.png'})

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '1080.mp4') 


table.insert(t, {title = '1080p ' .. title, mrl = url, image = '#self/movie.png'})

   end
end

 
--https://storage.kinohd.co/movies/19454f81710f66bd681abb254384ba9e0ce50e21/9a4b9c8f88a6dbbe1b07a6b54a38e156:2026082709/360.mp4:hls:manifest.m3u8



  local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=flixcdn.live&token=3218fae1545746e1b03cb7178bd1827b')


--table.insert(t, {title = 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local', mrl = 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local'})
  
  
   for id, seasons, translations in string.gmatch(x,'id":(.-),"is_serial":true.-"seasons_episodes":{(.-)}.-"translations":%[(.-)]') do
  
  seasons = string.gsub(seasons, '%[', '["') 
seasons = string.gsub(seasons, ']', '"]') 
seasons = string.gsub(seasons, ',', '","') 
  
  
  for season, episodes in string.gmatch(seasons,'"(.-)":%[(.-)]') do
  
  for episode in string.gmatch(episodes,'"(.-)"') do
  
  for trans, title in string.gmatch(translations,'"id":(.-),"title":"(.-)"') do
  
   
   season = string.gsub(season, ',""', '') 
   

  t['view'] = 'list'  

 
  
 table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = '#stream/q=flixcdns&id=' .. id .. '&id1=' .. trans .. '&id2=' .. season .. '&id3=' .. episode .. '&id4=' .. args.id3, image = '#self/movie.png'})
 
 
 
 end
 end
 end
 end
 
    
    elseif args.q == 'flixcdns' then  
  
  

    local player = 'https://tarantino.factorios.live/api/player/files'



local headers = {
    ["Host"] = "tarantino.factorios.live",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        ["Referer"] = "https://tarantino.factorios.live/show/kinopoisk/" .. args.id4 .. "?domain=flixcdn.live&token=3218fae1545746e1b03cb7178bd1827b",
    
  ["Cookie"] = "_ga_ECHML7LBXL=GS2.1.s1778775911$o1$g0$t1778775911$j60$l0$h0; _ga=GA1.1.1864259193.1778775912"
}

local params = '{"id":' .. args.id .. ',"season_number":' .. args.id2 .. ',"episode_number":' .. args.id3 .. ',"translation":' .. args.id1 .. '}'

local x = http.postz(player, headers, params)

local file = string.match(x,'{"file":"(.-)}') 

t['view'] = 'list'

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

table.insert(t, {title = qual .. 'p', mrl = url, image = '#self/movie.png'})


local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '480.mp4') 

table.insert(t, {title = '480p', mrl = url, image = '#self/movie.png'})

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '720.mp4') 

table.insert(t, {title = '720p', mrl = url, image = '#self/movie.png'})

local qual, url = string.match(file,'%[(360)](.-m3u8)') 

url = string.gsub(url, '360.mp4', '1080.mp4') 


table.insert(t, {title = '1080p', mrl = url, image = '#self/movie.png'})

  


elseif args.q == 'scts' then



local x = conn:load('https://lampa.li/lite/scts?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

if x then

--table.insert(t, {title = 'https://lampa.li/lite/scts?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn', mrl = 'http://beta.l-vid.online/lite/zona?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn'})

--https://z01.online/lite/solntse?kinopoisk_id=386&title=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&year=1979

--table.insert(t, {title = 'https://z01.online/lite/solntse?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'http://z01.online//lite/zona?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '\\u002B', '+')


   for url, total in string.gmatch(x, 'videos__item videos__movie.-stream.-(http.-)&#.-videos__item%-title.->(.-)<') do

t['view'] = 'list'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = tolazy(total), mrl = url, image = '#self/movie.png'})

     end 
end

local x = conn:load('https://z01.online/lite/solntse?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

if x then


--https://z01.online/lite/solntse?kinopoisk_id=386&title=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&year=1979

--table.insert(t, {title = 'https://z01.online/lite/solntse?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'http://z01.online//lite/zona?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '\\u002B', '+')


   for url, total in string.gmatch(x, 'videos__item videos__movie.-url.-(http.-)".-videos__item%-title.->(.-)<') do

t['view'] = 'list'


table.insert(t, {title = tolazy(total), mrl = url, image = '#self/movie.png'})

     end 
end





   elseif args.q == 'krasview' then


--https://krasview.ru/movie?mode=search&ajax&query=

--    local x = conn1:load('https://krasview.ru/movie?mode=vector-search&ajax&query=' .. urlencode(args.id1) .. '+' .. args.id2)

local x = conn1:load('https://krasview.ru/movie?mode=search&ajax&query=' .. urlencode(args.id1) .. '+' .. args.id2)



--table.insert(t, {title = 'https://krasview.ru/movie?mode=vector-search&ajax&query=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://krasview.ru/movie?mode=search&ajax&query=' .. urlencode(args.id1) .. ',' .. args.id2})


   for url, total in string.gmatch(x, '<li id=.-<a href=.-(http.-)\'.-alt=\'(.-)\'>') do


--table.insert(t, {title = url, mrl = url})

  
  local headers = {
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = url,
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
  
  
  
      local x = http.getz(url, headers)



    for id in string.gmatch(x, '<ul class=.-video%-gallery.-itemscope itemtype=.-id=\'v%-(.-)\'') do

t['view'] = 'list'

table.insert(t, {title = total, mrl = '#stream/q=krasviewvideo&id=' .. id, image = '#self/movie.png'})

end
end






--https://sersoap.ru/series/Game_of_Thrones/?page=2

    local x = conn1:load('https://krasview.ru/series?mode=search&ajax&query=' .. urlencode(args.id1) .. '+' .. args.id2)


    for url, total in string.gmatch(x, '<li id=.-<a href=\'(http.-)\'.-alt=\'(.-)\'') do
         t['view'] = 'list'
 
    table.insert(t, {title = tolazy(total), mrl = '#stream/q=krasviews&id=' .. url, image = '#self/movie.png'})
    end
 
   elseif args.q == 'krasviews' then

local page = tonumber(args.page or 1)

      local x = conn1:load(args.id .. '?page=' .. tostring(page))



   for id, title in string.gmatch(x, '<li itemprop=\'itemListElement\' itemscope itemtype=.-id=\'v%-(.-)\'.-alt=\'(.-)\'') do

t['view'] = 'list'

table.insert(t, {title = title, mrl = '#stream/q=krasviewvideo&id=' .. id, image = '#self/movie.png'})


end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=krasviews&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


--https://smartkino.ru/video/1285056-Hischnik.Planeta.smerti-Film

--https://zedfilm.ru/1285056

elseif args.q == 'krasviewvideo' then

local headers = {
    ["Host"] = "zedfilm.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://zedfilm.ru/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
     args.id = string.gsub(args.id, '^(.-)', 'https://zedfilm.ru/') 
 
 --  table.insert(t, {title = args.id, mrl = args.id})
   
     local x = http.getz(args.id, headers)
 
 local slist = string.match(x, 'video_Init.-\'(.-)\'') 
 
 
    slist = base64_decode(slist)
   
  --local url  = string.match(slist, '"url":"(http.-).mp.-"') 
   for url in string.gmatch(slist, '"url.-:"(https://media.-).mp.-"') do
    
   -- "url.-:"(https://media.-).mp.-"
    
    
      url = string.gsub(url, 'media', 'm')
     -- url = string.gsub(url, '^(.-)', '.mp4')
      
      if url then
    print(url2)
    return {view = 'playback', mrl = url .. '.mp4', seekable = 'true', direct = 'true'}
-- end
      
 
end
end


 
 
 
 
 
 
elseif args.q == 'zagonka' then
 


--args.id1 = string.gsub(args.id1, ':', '') 
args.id1 = string.gsub(args.id1, ' ', '%%20') 
		
 -- args.id1 = urlencode(args.id1)
 
-- args.id1 = string.gsub(args.id1, '+', '%%20') 
   
       local url = 'http://abc.zagonkop.gb.net/engine/ajax/xsearch/f.php?q=' .. args.id1
       --.. ' ' .. args.id2)

--table.insert(t, {title = url, mrl = url})	

local headers = {    
      ["host"] = "abc.zagonkop.gb.net",
      ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0",
       ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive"
}



local x = http.getz(url, headers)

--table.insert(t, {title = x, mrl = x})	

local x = json.decode(x)

		for _, v in ipairs(x) do
		--	local url = 'http://rutube.ru/video/' .. v['id'] .. '/'
	
	t['view'] = 'list'
	
	table.insert(t, {title = v['text'], mrl = '#stream/q=zagonkaz&id1=' .. v['id'] .. '&id=' .. v['url'], image = '#self/movie.png'})

end






--for ids, urls in string.gmatch(x, '{"id":"(.-)".-url.-(/.-)"') do

--{"id":"(.-)","text":"(.-)","url":"\/135628-ubivat-nado-vovremja-1998-onlayn.html"

--local ids, urls = string.match(x, '{"id":"(.-)".-url.-(/.-)"')

--urls = string.gsub(urls, '^(.-)', 'http://abc.zagonkop.gb.net') 

 
--t['view'] = 'simple'

--table.insert(t, {title = urldecode(args.id1) .. '(' .. args.id2 .. ')', mrl = '#stream/q=zagonkaz&id=' .. urls .. '&id1=' .. ids .. '&id2=' .. args.id2})

--end


elseif args.q == 'zagonkaz' then

  local url1 = 'http://abc.zagonkop.gb.net/embed/' .. args.id1


--http://abc.zagonkop.gb.net/embed/kp-5499518


local headersz = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = 'http://abc.zagonkop.gb.net' .. args.id,
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}



  local x = http.getz(url1, headersz)


--local id = string.match(x, 'data%-id="(.-)"')

--table.insert(t, {title = id, mrl = id})


x = string.gsub(x, 'ZYzNM', '')
        x = string.gsub(x, 'ZUzls', '')
x = string.gsub(x, 'ZUzVw', '')

x = string.gsub(x, 'ZUTB5', '')

x = string.gsub(x, 'ZaTdV', '')


local x = string.match(x, 'Playerjs%(\'#2(.-)\'%)+') 
   
  if x then      
    
    
    x = base64_decode(x)
     
 x = string.gsub(x, '{v1}', '.mp4')   

 --table.insert(t, {title = x, mrl = x})
  
 
 for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')
 
 
 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

  table.insert(t, {title = '(1080p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3, image = '#self/movie.png'})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/720.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

  table.insert(t, {title = '(720p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3, image = '#self/movie.png'})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

  table.insert(t, {title = '(480p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3, image = '#self/movie.png'})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/360.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

  table.insert(t, {title = '(360p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3, image = '#self/movie.png'})
  
  end
 
 
  
for tr, voise in string.gmatch(x, 'class=\'in_tr\'>(.-)<br>.-folder(.-)}]') do

for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3, image = '#self/movie.png'})
  
  end
end

for tr, voise in string.gmatch(x, 'class=\'in_tr\'>(.-)<br>.-folder(.-)}]') do

for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do


 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3, image = '#self/movie.png'})
 end 
 end



for voise in string.gmatch(x, '<div id=\'_not\'.-folder(.-)}]') do


for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия', mrl = url3,bimage = '#self/movie.png'})
  
  end
end


for voise in string.gmatch(x, '<div id=\'_not\'.-folder(.-)}]') do


for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'list'

 table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия', mrl = url3, image = '#self/movie.png'})
  
  end
end



 
 end
  


 
--local url = 'https://kinogo2026.com/index.php?story=' .. urlencode(args.id1) .. '&do=search&subaction=search'

--https://kinonix.net/109372-mortal-kombat-2.html

--https://kinonix.net/index.php?story=чужой+1979&do=search&subaction=search

--https://proxy4.rte.net.ru/https://kinogo.biz/index.php?story=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB+2025&do=search&subaction=search

--https://kinogo2026.com/index.php?story=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB+2025&do=search&subaction=search

--https://hdrezka.inc//index.php?story=чужой+1979&do=search&subaction=search





elseif args.q == 'kinogox' then

--https://kinogo2026.com/

--https://kinonix.net

local x = conn:load('https://kinogo2026.com/index.php?story=' .. urlencode(args.id1 .. ' ' .. args.id2) .. '&do=search&subaction=search')


local search = string.match(x, '<h2.-href.-(http.-html)') 

if search then



 local x = conn:load(search)
 


local headers2 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Sec-Fetch-Storage-Access"] = "none",
    ["Connection"] = "keep-alive",
    ["Referer"] = search,
    ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb; device_fp=dc5352f6d0c470ed5624bc225b261ecc",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}

 
 
 local url2 = string.match(x,'(//cinemar.cc/embed/.-)"')
 

 
if url2 then
 
--  https://proxy4.rte.net.ru/
  
 local embed = 'https:' .. url2
 

 local x = http.getz(embed, headers2)


local player = string.match(x,'Cinemar%((.-)%)+')

if player then


 local url3 = string.match(player,'"file":"#.-(W3sia.-)%"+')

 
 url3 = urldecode(url3)

 
url3 = string.gsub(url3,'#pZCf1azIuc3J0LF','')

 url3 = string.gsub(url3,'#0JnMVRf1ae84I6IjV','')
 
 url3 = string.gsub(url3,'#NjU0f1aeWVlVLQVZW','')

 
url3 = base64_decode(url3)
 


 url3 = string.gsub(url3, '\\u0410', 'А')
      url3 = string.gsub(url3, '\\u0430', 'а')
       
       url3 = string.gsub(url3, '\\u0411', 'Б')
       url3 = string.gsub(url3, '\\u0431', 'б')  
       url3 = string.gsub(url3, '\\u0412', 'В')
      url3 = string.gsub(url3, '\\u0432', 'в')
       url3 = string.gsub(url3, '\\u0413', 'Г')
       url3 = string.gsub(url3, '\\u0433', 'г')  
      url3 = string.gsub(url3, '\\u0414', 'Д')
      url3 = string.gsub(url3, '\\u0434', 'д')
       url3 = string.gsub(url3, '\\u0415', 'Е')
       url3 = string.gsub(url3, '\\u0435', 'е')  
      url3 = string.gsub(url3, '\\u0401', 'Ё')
      url3 = string.gsub(url3, '\\u0451', 'ё')
       url3 = string.gsub(url3, '\\u0416', 'Ж')
       url3 = string.gsub(url3, '\\u0436', 'ж')  
       url3 = string.gsub(url3, '\\u0417', 'З')
      url3 = string.gsub(url3, '\\u0437', 'з')
       url3 = string.gsub(url3, '\\u0418', 'И')
       url3 = string.gsub(url3, '\\u0438', 'и')  
       url3 = string.gsub(url3, '\\u0419', 'Й')
      url3 = string.gsub(url3, '\\u0439', 'й')
       url3 = string.gsub(url3, '\\u041a', 'К')
       url3 = string.gsub(url3, '\\u043a', 'к')  
       url3 = string.gsub(url3, '\\u041b', 'Л')
       url3 = string.gsub(url3, '\\u043b', 'л')
       url3 = string.gsub(url3, '\\u041c', 'М')
       url3 = string.gsub(url3, '\\u043c', 'м')
       url3 = string.gsub(url3, '\\u041d', 'Н')
       url3 = string.gsub(url3, '\\u043d', 'н')
       url3 = string.gsub(url3, '\\u041e', 'О')
       url3 = string.gsub(url3, '\\u043e', 'о')
       url3 = string.gsub(url3, '\\u041f', 'П')
       url3 = string.gsub(url3, '\\u043f', 'п')
       url3 = string.gsub(url3, '\\u0420', 'Р')
       url3 = string.gsub(url3, '\\u0440', 'р')
       url3 = string.gsub(url3, '\\u0421', 'С')
       url3 = string.gsub(url3, '\\u0441', 'с')
       url3 = string.gsub(url3, '\\u0422', 'Т')
       url3 = string.gsub(url3, '\\u0442', 'т')
       url3 = string.gsub(url3, '\\u0423', 'У')
       url3 = string.gsub(url3, '\\u0443', 'у')
       url3 = string.gsub(url3, '\\u0424', 'Ф')
        url3 = string.gsub(url3, '\\u0444', 'ф')
        url3 = string.gsub(url3, '\\u0425', 'Х')
        url3 = string.gsub(url3, '\\u0445', 'х')
        url3 = string.gsub(url3, '\\u0426', 'Ц')
        url3 = string.gsub(url3, '\\u0446', 'ц')
        url3 = string.gsub(url3, '\\u0427', 'Ч')
        url3 = string.gsub(url3, '\\u0447', 'ч')
        url3 = string.gsub(url3, '\\u0428', 'Ш')
        url3 = string.gsub(url3, '\\u0448', 'ш')
        url3 = string.gsub(url3, '\\u0429', 'Щ')
        url3 = string.gsub(url3, '\\u0449', 'щ')
        url3 = string.gsub(url3, '\\u042a', 'Ъ')
        url3 = string.gsub(url3, '\\u044a', 'ъ')
        url3 = string.gsub(url3, '\\u042b', 'Ы')
        url3 = string.gsub(url3, '\\u044b', 'ы')
        url3 = string.gsub(url3, '\\u042c', 'Ь')
        url3 = string.gsub(url3, '\\u044c', 'ь')
        url3 = string.gsub(url3, '\\u042d', 'Э')
        url3 = string.gsub(url3, '\\u044d', 'э')
        url3 = string.gsub(url3, '\\u042e', 'Ю')
        url3 = string.gsub(url3, '\\u044e', 'ю')
        url3 = string.gsub(url3, '\\u042f', 'Я')
        url3 = string.gsub(url3, '\\u044f', 'я')
        url3 = string.gsub(url3, '\\u00ab', '<<')
        url3 = string.gsub(url3, '\\u00bb', '>>')
        url3 = string.gsub(url3, '\\u2014', '-')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/ua.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\"%[', '')



url3 = string.gsub(url3, '\\u00a0', ' ')
 
 url3 = string.gsub(url3,'\\','')

url3 = string.gsub(url3, '<img src="/flags/us.png" alt=""%[', '')

 url3 = string.gsub(url3,'"title":"Сезон','')
url3 = string.gsub(url3,'"title":"Серия','')
 

for title, data in string.gmatch(url3, '{"id":".-".-"title":"(.-)","title2":.-"data":(".-")') do

if data then

local list = 'https://cinemar.cc/api/playlist/load'


local headers3 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/json",
  ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb",
    ["Content-Length"] = "266",
    ["Origin"] = "https://cinemar.cc",
    ["Connection"] = "keep-alive",
    ["Referer"] = embed,
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local data = data

local x = http.postz(list, headers3, data)

if x then


-- t['view'] = 'list'
 
 
 local file = string.match(x,'"file":"(.-)/hls.m3u8"')

 if file then
 
 local m3u = conn:load(file .. '/hls.m3u8')

if m3u then

m3u = string.gsub(m3u, './', ',./') 

m3u = string.gsub(m3u, 'stream', '/stream') 
 
for qual, file2 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'list'

table.insert(t, {title = '(' .. tolazy(qual) .. 'p) ' .. tolazy(title), mrl = file .. file2, image = '#self/movie.png'})
 
end
 end
 end
 end
 end
 

for title, title1, data1 in string.gmatch(url3,'{"id":".-".-"title":"(.-)","title2":"(.-ерия)".-"data":"(.-)"') do
 
 if title1 then
 

table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=kinogoxs&id=' .. data1 .. '&id1=' .. embed, image = '#self/movie.png'})


end
end  
end
end
end
end








 
if not search then

local x =  conn:load('https://hdrezka.inc/index.php?story=' .. urlencode(args.id1 .. ' ' .. args.id2) .. '&do=search&subaction=search')


--if x then

local search1 = string.match(x,'<h2.-href.-(http.-html)') 
 
 if search1 then
 
 local x = conn:load(search1)
 

 
 local headers2 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Sec-Fetch-Storage-Access"] = "none",
    ["Connection"] = "keep-alive",
    ["Referer"] = search1,
    ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb; device_fp=dc5352f6d0c470ed5624bc225b261ecc",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}

 
 
 local url2 = string.match(x,'(//cinemar.cc/embed/.-)"')
 

 
if url2 then
 
--  https://proxy4.rte.net.ru/
  
 local embed = 'https:' .. url2
 

 local x = http.getz(embed, headers2)


local player = string.match(x,'Cinemar%((.-)%)+')

if player then


 local url3 = string.match(player,'"file":"#.-(W3sia.-)%"+')

 
 url3 = urldecode(url3)

 
url3 = string.gsub(url3,'#pZCf1azIuc3J0LF','')

 url3 = string.gsub(url3,'#0JnMVRf1ae84I6IjV','')
 
 url3 = string.gsub(url3,'#NjU0f1aeWVlVLQVZW','')

 
url3 = base64_decode(url3)
 


 url3 = string.gsub(url3, '\\u0410', 'А')
      url3 = string.gsub(url3, '\\u0430', 'а')
       
       url3 = string.gsub(url3, '\\u0411', 'Б')
       url3 = string.gsub(url3, '\\u0431', 'б')  
       url3 = string.gsub(url3, '\\u0412', 'В')
      url3 = string.gsub(url3, '\\u0432', 'в')
       url3 = string.gsub(url3, '\\u0413', 'Г')
       url3 = string.gsub(url3, '\\u0433', 'г')  
      url3 = string.gsub(url3, '\\u0414', 'Д')
      url3 = string.gsub(url3, '\\u0434', 'д')
       url3 = string.gsub(url3, '\\u0415', 'Е')
       url3 = string.gsub(url3, '\\u0435', 'е')  
      url3 = string.gsub(url3, '\\u0401', 'Ё')
      url3 = string.gsub(url3, '\\u0451', 'ё')
       url3 = string.gsub(url3, '\\u0416', 'Ж')
       url3 = string.gsub(url3, '\\u0436', 'ж')  
       url3 = string.gsub(url3, '\\u0417', 'З')
      url3 = string.gsub(url3, '\\u0437', 'з')
       url3 = string.gsub(url3, '\\u0418', 'И')
       url3 = string.gsub(url3, '\\u0438', 'и')  
       url3 = string.gsub(url3, '\\u0419', 'Й')
      url3 = string.gsub(url3, '\\u0439', 'й')
       url3 = string.gsub(url3, '\\u041a', 'К')
       url3 = string.gsub(url3, '\\u043a', 'к')  
       url3 = string.gsub(url3, '\\u041b', 'Л')
       url3 = string.gsub(url3, '\\u043b', 'л')
       url3 = string.gsub(url3, '\\u041c', 'М')
       url3 = string.gsub(url3, '\\u043c', 'м')
       url3 = string.gsub(url3, '\\u041d', 'Н')
       url3 = string.gsub(url3, '\\u043d', 'н')
       url3 = string.gsub(url3, '\\u041e', 'О')
       url3 = string.gsub(url3, '\\u043e', 'о')
       url3 = string.gsub(url3, '\\u041f', 'П')
       url3 = string.gsub(url3, '\\u043f', 'п')
       url3 = string.gsub(url3, '\\u0420', 'Р')
       url3 = string.gsub(url3, '\\u0440', 'р')
       url3 = string.gsub(url3, '\\u0421', 'С')
       url3 = string.gsub(url3, '\\u0441', 'с')
       url3 = string.gsub(url3, '\\u0422', 'Т')
       url3 = string.gsub(url3, '\\u0442', 'т')
       url3 = string.gsub(url3, '\\u0423', 'У')
       url3 = string.gsub(url3, '\\u0443', 'у')
       url3 = string.gsub(url3, '\\u0424', 'Ф')
        url3 = string.gsub(url3, '\\u0444', 'ф')
        url3 = string.gsub(url3, '\\u0425', 'Х')
        url3 = string.gsub(url3, '\\u0445', 'х')
        url3 = string.gsub(url3, '\\u0426', 'Ц')
        url3 = string.gsub(url3, '\\u0446', 'ц')
        url3 = string.gsub(url3, '\\u0427', 'Ч')
        url3 = string.gsub(url3, '\\u0447', 'ч')
        url3 = string.gsub(url3, '\\u0428', 'Ш')
        url3 = string.gsub(url3, '\\u0448', 'ш')
        url3 = string.gsub(url3, '\\u0429', 'Щ')
        url3 = string.gsub(url3, '\\u0449', 'щ')
        url3 = string.gsub(url3, '\\u042a', 'Ъ')
        url3 = string.gsub(url3, '\\u044a', 'ъ')
        url3 = string.gsub(url3, '\\u042b', 'Ы')
        url3 = string.gsub(url3, '\\u044b', 'ы')
        url3 = string.gsub(url3, '\\u042c', 'Ь')
        url3 = string.gsub(url3, '\\u044c', 'ь')
        url3 = string.gsub(url3, '\\u042d', 'Э')
        url3 = string.gsub(url3, '\\u044d', 'э')
        url3 = string.gsub(url3, '\\u042e', 'Ю')
        url3 = string.gsub(url3, '\\u044e', 'ю')
        url3 = string.gsub(url3, '\\u042f', 'Я')
        url3 = string.gsub(url3, '\\u044f', 'я')
        url3 = string.gsub(url3, '\\u00ab', '<<')
        url3 = string.gsub(url3, '\\u00bb', '>>')
        url3 = string.gsub(url3, '\\u2014', '-')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/ua.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\"%[', '')

url3 = string.gsub(url3, '\\u00a0', ' ')
 
 url3 = string.gsub(url3,'\\','')
 
 url3 = string.gsub(url3,'"title":"Сезон','')
url3 = string.gsub(url3,'"title":"Серия','')
 

for title, data in string.gmatch(url3, '{"id":".-".-"title":"(.-)","title2":.-"data":(".-")') do

if data then

local list = 'https://cinemar.cc/api/playlist/load'


local headers3 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/json",
  ["Cookie"] = "PHPSESSID=e795ce30072e7fe64fb5db5e0aada2fb",
    ["Content-Length"] = "266",
    ["Origin"] = "https://cinemar.cc",
    ["Connection"] = "keep-alive",
    ["Referer"] = embed,
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local data = data

local x = http.postz(list, headers3, data)

if x then


-- t['view'] = 'list'
 
 
 local file = string.match(x,'"file":"(.-)/hls.m3u8"')

 if file then
 
 local m3u = conn:load(file .. '/hls.m3u8')

if m3u then

m3u = string.gsub(m3u, './', ',./') 

m3u = string.gsub(m3u, 'stream', '/stream') 
 
for qual, file2 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'list'

table.insert(t, {title = '(' .. tolazy(qual) .. 'p) ' .. tolazy(title), mrl = file .. file2, image = '#self/movie.png'})
 
end
 end
 end
 end
end 
 

for title, title1, data1 in string.gmatch(url3,'{"id":".-".-"title":"(.-)","title2":"(.-ерия)".-"data":"(.-)"') do
 
 if title1 then
 
 t['view'] = 'list'

table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=kinogoxs&id=' .. data1 .. '&id1=' .. embed, image = '#self/movie.png'})


end
end  
end
end
end
end


end

 
 
 elseif args.q == 'kinogoxs' then

args.id = string.gsub(args.id, ' ', '+') 
args.id1 = string.gsub(args.id1, ' ', '+') 

 local list1 = 'https://cinemar.cc/api/playlist/load'


local headers4 = {
    ["Host"] = "cinemar.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/json",
    ["Content-Length"] = "",
    ["Origin"] = "https://cinemar.cc",
    ["Connection"] = "keep-alive",
    ["Referer"] = args.id1,
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}
 
 local data1 = '"' .. args.id .. '"'

--table.insert(t, {title = args.id1, mrl = data1})
 
local x = http.postz(list1, headers4, data1)
 
 
 if x then
 
 local file = string.match(x,'"file":"(.-)/hls.m3u8"')

 if file then
 
 local m3u = conn:load(file .. '/hls.m3u8')

if m3u then

m3u = string.gsub(m3u, './', ',./') 

m3u = string.gsub(m3u, 'stream', '/stream') 
 
for qual, file2 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'list'

table.insert(t, {title = '(' .. tolazy(qual) .. 'p)', mrl = file .. file2, image = '#self/movie.png'})
 
 
 end
end
end
end
 



 
 elseif args.q == 'test' then
 
 

 
 
local url = 'https://w140.zona.plus/ajax/video/2868935?client_time=1769403672'
    
    
    
        local cookies = {
            _ym_uid = '1685951488624399200',
            _ym_d = '1685951488',
            _ga = 'GA1.2.1205909313.1685951488',
            _gid = 'GA1.2.31974282.1685951488',
            _ym_visorc = 'b',
            _ym_isad = '2',
            _buzz_fpc = 'JTdCJTIycGF0aCUyMiUzQSUyMiUyRiUyMiUyQyUyMmRvbWFpbiUyMiUzQSUyMi53MTQwLnpvbmEucGx1cyUyMiUyQyUyMmV4cGlyZXMlMjIlM0ElMjJXZWQlMkMlMjAwNSUyMEp1biUyMDIwMjQlMjAwOCUzQTMwJTNBNTklMjBHTVQlMjIlMkMlMjJTYW1lU2l0ZSUyMiUzQSUyMkxheCUyMiUyQyUyMnZhbHVlJTIyJTNBJTIyJTdCJTVDJTIydWZwJTVDJTIyJTNBJTVDJTIyMzUwZjA4ZjFmZTY2YmQ3ZGE1MmRhMmZkYWJkOTAwYWMlNUMlMjIlMkMlNUMlMjJicm93c2VyVmVyc2lvbiU1QyUyMiUzQSU1QyUyMjExMy4wJTVDJTIyJTdEJTIyJTdE',
            __upin = 'Te7Wz49Kadq4g4afsfh0Aw',
            _ohmybid_cmf = '2',
            adtech_uid = '928b96f6-71c3-4991-8418-8775cd4f6afb%3Azona.plus',
            top100_id = 't1.7627570.1236391857.1685951615289',
            t3_sid_7627570 = 's1.22459236.1685951615291.1685953879223.1.7',
            last_visit = '1685917879021%3A%3A1685953879021',
            ZONAMOBI = 'oibefqkgdfumjofr09uu16co16; path=/',
            uuid = '2306a8ba8dae8a94%3A3'
        }
        local headers = {
            ['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3',
            ['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            ['Accept-Language'] = 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
            ['Accept-Encoding'] = 'gzip, deflate, br',
            ['Connection'] = 'keep-alive',
            ['Sec-Fetch-Dest'] = 'document',
            ['Sec-Fetch-Mode'] = 'navigate',
            ['Sec-Fetch-Site'] = 'none',
            ['Sec-Fetch-User'] = '?1'
        }
 
 local x = conn:load(url, headers, cookies)
 url = url_for(x)


 table.insert(t, {title = url, mrl = url})




 elseif args.q == 'kinogotest' then
 
--https://cors.fx666.workers.dev:8443/https://api.apbugall.org/v2/movies/search/?kp=386&imdb_id=tt0078748&tmdb_id=348&token=e7b61f129f4a392ac4bf6726a9dd6a&token_movie=a6ef0986c7558c5792c3ad19d43611

--https://apbugall.org/v2/movies/search?id_kp=386&id_imdb=tt0078748&id_tmdb=348&token_movie=a6ef0986c7558c5792c3ad19d43611

--https://cors.fx666.workers.dev:8443/

local url = 'https://apbugall.org/v2/movies/search?kp=386&token=a6ef0986c7558c5792c3ad19d43611'


--local url = 'https://cors.fx666.workers.dev:8443/https://harald-as.newplayjj.com/?kp=386&token=token=e7b61f129f4a392ac4bf6726a9dd6a'



--local url = 'https://apbugall.org/v2/movies/search?kp=386&token=a6ef0986c7558c5792c3ad19d43611'
--local response_body = {}


local token = 'pXzvbyDGLYyB6VkwsWZDv3iMKZtsXNzpzRyxZUcsKHXxsSeaYakbo3hw9mBFRc5VQTpqAX6BW8aDEqyLaHYcXSQiV6KHYTVTK6MYRphNAy5sBjtrevqkDzKmLqNdfMZGEU9NELjmtKfZy3RNGzCd767sNh1mXEj4tCcvqndHtzmwAbZNkhm4ghDEasodotMBewypNQ56uotJAQGX11csfeRfBAPk8DcUWWkkqzxca8vbnEw12vUFbBzT6hz8ZB3F3dzUhUXoL2cr1WM1bXQArRCS1MUNMz3X5WDMMQoZKxj2AMTRqp7QQX4dDB9B7VzEZTmyFULhm1AcHHMkoMvSVvKYoBoAKLycYAgMHeD4ECJcGEAGpnkJhrV57zQ7'

--https://beta.l-vid.online/lite/mirage/video.m3u8?id_file=912591&token_movie=a6ef0986c7558c5792c3ad19d43611

--XMLHttpRequest

--local r = {}

--headers = {Authorization = 'Bearer ${token}'}

 local data = {method = 'GET', url,
headers = {["X-Requested-With"] = "XMLHttpRequest",["Authorizations"] = "Bearer " .. token,["Accept"] = "application/json" 
}}

local params = http.encode{
		kp = '386',
		token = e7b61f129f4a392ac4bf6726a9dd6a,
		
					}



--local params = {
      --  token = '9673771083c9eb06f6fb929331ce3a',
      --  domain = 'https%3A%2F%2Fdoor-as.newplayjj.com%3A9443%2F',
    --    device = '1',
  --      selector = '1',
       -- autoPlayChange = '0',
   --     saveTime = '1',
        
 --       fullscreen = '0',
      --  autoplay = '0',
   --     start = '0',
  --      audio = '',
   --     subtitle = '',
  --      log = '0',
 --       debug = '0',
 --   }
    local movie = {
        id = 'f0e4e83f6a2367c75592357115312d',
        type ='movie',
    }
 --   local urlPLog = 'https://iqslgbok.deploy.cx/https://ppc.ipchanger.live:11443/index.php?md5=Zi2TlGR4V5O2aK5-QvQqJQ&expires=1769837883'




n = {
    method = 'GET'
   } 



--local x = http.postz(n,headers)


local x = conn:load(data)



--local response_text = (n,headers)

--local x = conn:load('https://apbugall.org/v2/movies/search?kp=386&token=a6ef0986c7558c5792c3ad19d43611',headers,r)

--url1 = string.gsub(n,n,n)




--https://cors.fx666.workers.dev:8443/https://Avitaminosis-as.stloadi.live/?token=095d89f5d8e10355ef49dece98795f&kp=386

--https://672431256.videoframe2.com/api/v1/embed/kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz



--https://cors.fx666.workers.dev:8443/https://alloha.tv/embed?src=https://Avitaminosis-as.stloadi.live/?token_movie=a6ef0986c7558c5792c3ad19d43611&token=095d89f5d8e10355ef49dece98795f&autoplay=1

--https://Avitaminosis-as.stloadi.live/?token_movie=a6ef0986c7558c5792c3ad19d43611&token=095d89f5d8e10355ef49dece98795f
 
 
 -- x = json.decode(x)
 
 url = url_for(x)
-- x = urldecode(x)




 local userParam = {
    token = '095d89f5d8e10355ef49dece98795f',
    domain = 'https%3A%2F%2Favitaminosis-as.stloadi.live%2F',
    device = 1,
    selector = 1,
    autoPlayChange = 1,
    saveTime = 1,
    hidden = 'JSON.parse(\'(.-)\')',
    fullscreen = 0,
    autoplay = 0,
    start = '0',
    audio = '',
    subtitle = '',
    log = 0,
    debug = 0
}

local movie = {
    id = '(.-)',
    type = '(.-)'
}

--for url in string.gmatch(x, 'urlPLog.-\'(.-)\'') do

--for token in string.gmatch(x, 'token = \'(.-)\',') do

--for total in string.gmatch(x, '"%[cat]":"(.-)"') do

--for id in string.gmatch(x, '"id":(.-),') do


--local x = conn:load(url,userParam,movie,headers1)

--local x = conn:load('https://Avitaminosis-as.stloadi.live' .. '/' .. total .. '/' .. id .. '&token=095d89f5d8e10355ef49dece98795f' .. '&av1=true',headers1)


--url = url_for(x)


 table.insert(t, {title = url, mrl = url})

 -- end
-- end
 --end
 
 
 
 
-- http://z01.online/lite/events?
 
--https://lam.maxvol.pro/lite/fancdn?kinopoisk_id=464475
  
 -- http://178.20.46.40:12600/
  
  elseif args.q == 'fancdn' then
 
 --https://lam.maxvol.pro/lite/fancdn?kinopoisk_id=386
 
 local x = conn:load('http://z01.online/lite/fancdn?kinopoisk_id=' .. args.id3)

-- table.insert(t, {title = 'http://178.20.46.40:12600/lite/fancdn?kinopoisk_id=' .. args.id3, mrl = 'http://178.20.46.40:12600/lite/fancdn?kinopoisk_id=' .. args.id3})

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
  
        --  url = string.gsub(url, '^(.-)', 'https://lam.maxvol.pro') 
     
url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
 
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls.m3u8', '480.mp4:hls:manifest.m3u8')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end

--https://1fanserials.online/films.php?kp=386&key=PJdXIEj9_QmrZZ2rXw7gO5OrzW7sasrR_rxmAMyhWUdQTsVXlVi3IxruRn4kYve1a0n3K1RTMAUwPPu26akJBF4lMAEEXT1WsvCIRx4cg035-Dzh-ou2cSZQimizYa5q0Nwb

--http://fork.tutkino.fun/xml/cdn/iframe.php?link=https://cdn-54243ba5.obrut.show/stream/AO/MHc0RHa/QbvNmLuR2YyVGc1RmclBXdz5ie/AO1NTbuYTYtEjdtQ3clZWauFWb6MHbopDNw1mLwIzNvQTM5IDNwYjMwIjO0YjZ3czMmljM5U2MkNWZkRGO2ATN0QjM5cDZ1AjM0UzL4MjNzcDOkBzMjhTZkdTMkZWZ2ATZkNDO5AzM0IzNkR2N2YjZhJGMy8ycllmdv12L

--https://fanserial.me/player/?file=

--https://www.m3u8player.online/embed/m3u8?url=https://fanserial.me/movies/570402

--https://fanserial.me/player/?file=https://fancdn.net/iframe/?kinopoisk=386



elseif args.q == 'fanserial' then

 
 
--local url = 'https://1fanserials.org/index.php?do=search'
 
 local url = 'https://1fanserials.org/?do=search&subaction=search&story=' .. urlencode(args.id1)

 local headers = {
    ["Host"] = "1fanserials.org",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://1fanserials.org/",
    ["Connection"] = "keep-alive",
    ["Content-Type"] = "application/x-www-form-urlencoded",
["Content-Length"] = "",
    ["Cookie"] = "__ddg8_=1fmsm0vHdmBHUNd2; __ddg10_=1785251191; __ddg9_=185.228.133.239; __ddg1_=yKoRO1EMPs6rMsq5RYxZ; PHPSESSID=1a21b2ffc6e416654a5282bb064269d3; _ym_uid=1785251045348708012; _ym_d=1785251045; _ym_isad=2; _ym_visorc=b; adrfpip=nAbe16msPTPn; _ohmybid_cmf=2; domain_sid=APwDrHvXKAJ6iYZlPJ69p%3A1785251239326; _sltm=8d703f70f587d25c492c5c2b66042230~0; _sltb=0; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0, i"
}
 
 
local params = 'do=search&subaction=search&search_start=0&full_search=1&result_from=1&story=' .. args.id1 .. '&all_word_seach=1&titleonly=3&searchuser=&replyless=0&replylimit=0&searchdate=0&beforeafter=after&sortby=title&resorder=asc&showposts=0&catlist%5B%5D=10'

 
 local x = http.getz(url, headers)
 
 
  
for url in string.gmatch(x,'<h2.-href=.-(http.-html)') do


 
local x = http.getz(url, headers) 
 
 
  local movie = string.match(x,'itemprop="item.-href="/films/"(.-)"post"')
  
  if movie then
                
 for title, total, kp, key in string.gmatch(movie,'<h1.->(.-)</h1>.-Год.-class="field%-text.->(.-)<.-<iframe.-src=.-/movies/(.-)%?key=(.-)"') do

if kp then
if key then

t['view'] = 'list'

table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=fanserialsm&id=' .. kp .. '&id1=' .. key, image = '#self/movie.png'})

--table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=fanserialsm&id=' .. url .. '&id3=' .. args.id3})
 
 end
 end
 end
end 
end 
 
 
local headers = {['X-Requested-With'] = 'XMLHttpRequest'
, ['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3',
['Server'] = 'ddos-guard',
['Connection'] = 'keep-alive',
['Keep-Alive'] = 'timeout=60',
['Set-Cookie'] = '__ddg8_=M1eAeJegjCoESH2r; Domain=.opravar.online; Path=/; Expires=Thu, 05-Mar-2026 17:45:45 GMT',
['Set-Cookie'] = '__ddg10_=1772731545; Domain=.opravar.online; Path=/; Expires=Thu, 05-Mar-2026 17:45:45 GMT',
['Set-Cookie'] = '__ddg9_=185.228.133.239; Domain=.opravar.online; Path=/; Expires=Thu, 05-Mar-2026 17:45:45 GMT',
['Content-Security-Policy'] = 'upgrade-insecure-requests;',
['Set-Cookie'] = '__ddg1_=m8GVy1LFbHMztg4oE7BK; Domain=.opravar.online; HttpOnly; Path=/; Expires=Fri, 05-Mar-2027 17:25:45 GMT',
['Content-Type'] = 'text/html; charset=UTF-8',
['Set-Cookie'] = 'PHPSESSID=rueknm41suikcuankk6rtun7cj; path=/; Secure; SameSite=None; secure',
['Expires'] = 'Thu, 19 Nov 1981 08:52:00 GMT',
['Cache-Control'] = 'no-store, no-cache, must-revalidate',
['Pragma'] = 'no-cache',
['P3P'] = 'CP="IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT"',
['Transfer-Encoding'] = 'chunked'}
 
 
 
 
 
 
 local x = conn:load('https://lomont.site/gt/' .. args.id3 .. '?&alloff=true', headers)


if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 


local data = string.match(x,'<div id="inputData"(.-)<div id="vPreloader"') 

if data then

for video, season, episode, title, voice in string.gmatch(data,'"video_id":(.-),"season":(.-),"episode":(.-),"voice_name":"(.-)","voice_id":(.-),') do


--local x = conn:load('https://lomont.site/player/responce.php?video_id=' .. video)
--.. '&season=' .. season .. '&episode=' .. episode .. '&voice=' .. voice)

--x = string.gsub(x, '\\', '')

--local url = string.match(x,'"src".-(http.-m3u8)"')

--t['view'] = 'simple'

--table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = url})

t['view'] = 'list'


table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = '#stream/q=fanserials&id3=' .. args.id3 .. '&id=' .. video .. '&id1=' .. season .. '&id2=' .. episode .. '&id4=' .. voice .. '&id5=' .. title, image = '#self/movie.png'})


end
end
end



 elseif args.q == 'fanserials' then

local x = conn:load('https://lomont.site/player/responce.php?video_id=' .. args.id .. '&season=' .. args.id1 .. '&episode=' .. args.id2 .. '&voice=' .. args.id4 .. '&alloff=true', headers)
  --   print(x)


if x then

local url = string.match(x,'"src".-(http.-m3u8)"')

url = string.gsub(url, '\\', '')
  
 
  --    t['view'] = 'list'

return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}

--table.insert(t, {title = 'Сезон ' .. args.id1 .. ' серия ' .. args.id2 .. ' ' .. args.id5, mrl = url})

end





elseif args.q == 'fanserialsm' then
   
local headers = {
    ["Host"] = "1fanserials.org",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://1fanserials.org/films/",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "__ddg8_=1fmsm0vHdmBHUNd2; __ddg10_=1785251191; __ddg9_=185.228.133.239; __ddg1_=yKoRO1EMPs6rMsq5RYxZ; PHPSESSID=1a21b2ffc6e416654a5282bb064269d3; _ym_uid=1785251045348708012; _ym_d=1785251045; _ym_isad=2; _ym_visorc=b; adrfpip=nAbe16msPTPn; _ohmybid_cmf=2; domain_sid=APwDrHvXKAJ6iYZlPJ69p%3A1785251239326; _sltm=8d703f70f587d25c492c5c2b66042230~0; _sltb=0; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0, i"
}


 
 --local x = http.getz(args.id, headers) 
 
 
 
 --local kp, key = string.match(x,'<iframe.-src="/.-/(.-)%?key=(.-)"')
 
-- if key then
 
local headers1 = {
    ["Host"] = "1fanserials.org",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://1fanserials.org/movies/" .. args.id .. "?key=" .. args.id1,
    ["Connection"] = "keep-alive",
    ["Cookie"] = "__ddg8_=vWS2jN5TY7k1hQmR; __ddg10_=1785251259; __ddg9_=185.228.133.239; __ddg1_=yKoRO1EMPs6rMsq5RYxZ; PHPSESSID=1a21b2ffc6e416654a5282bb064269d3; _ym_uid=1785251045348708012; _ym_d=1785251045; _ym_isad=2; _ym_visorc=b; adrfpip=nAbe16msPTPn; _ohmybid_cmf=2; domain_sid=APwDrHvXKAJ6iYZlPJ69p%3A1785251239326; _sltm=8d703f70f587d25c492c5c2b66042230~0; _sltb=0; dle_user_id=132923; dle_password=0ca93da340a11e0260f04af4dc31aa09; dle_newpm=0",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}

 local x = http.getz('https://1fanserials.org/film.php?kp=' .. args.id ..'&key=' .. args.id1, headers1) 
 
 
 
 if x then
 
 for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'list'

table.insert(t, {title = '(1080p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
 
   for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '720.mp4:hls:manifest')

   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
 
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '480.mp4:hls:manifest')

   
 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
 
 
 for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '360.mp4:hls:manifest')

   
 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '240.mp4:hls:manifest')


   
   
 t['view'] = 'list'

table.insert(t, {title = '(240p)' .. tolazy(title), mrl = url, image = '#self/movie.png'})

end
end 
-- end

 



--https://fanserial.me/films.php?kp=570402

--https://playep.pro/pl/1235054

--https://gencit.info
--https://lomont.site/player/responce.php?video_id=991208

--https://cors.nb557.workers.dev:8443/https://lomont.site/gt/1235054

--https://cors.kp556.workers.dev/https://lomont.site/gt/1235054


--https://fanserial.me/player?file=https://fanserial.me/films.php?kp=98977


--https://fanserial.me/tvseries.php?kp=https://cors.nb557.workers.dev:8443/https://cors.bwa.workers.dev/

--https://apn-latest.onrender.com/78.40.199.67/https://lomont.site/gt/4910542

--https://apn-latest.onrender.com/ip/195.3.223.172/https://lomont.site/gt/4910542

--https://lomont.sitehttps://gencit.info/player/response.php?kp_id=1235054&season=3&episode=20&voice=22&alloff=true



-- http://lampac.egorpomidor.site/lite/kinogo?href=56119-strazhi-galaktiki-chast-3-2023.html
 
 --http://31.129.234.181:80
 
 
  elseif args.q == 'kinogo' then
 

--https://lampa.kimabel.by/lite/events?
 
 
 --http://31.129.234.181/lite/kinogo?href=https://kinonix.net/3618-godzilla-x-kong-the-new-empire.html&uid=guest
 
 local x = conn:load('https://lampa.kimabel.by/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
 table.insert(t, {title = 'https://lampa.kimabel.by/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lampa.kimabel.by/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
 
    for url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url".-http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do
  
  
  
      
      
 url = string.gsub(url, '\\u0026', '&')
     url = string.gsub(url, '\\u002B', '+')
  
            url = string.gsub(url, '^(.-)', 'https://lampa.kimabel.by') 
     


      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total), mrl = url})

       
    end
 --   end
 
 
 
 for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'https://lampa.kimabel.by')
    

      local x = conn:load(url2)

  -- x = string.gsub(x, '< img', '')
   --  x = string.gsub(x, '<img', '')
   --  x = string.gsub(x, '">', '')
  
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
  
         url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'https://lampa.kimabel.by')
    
       
    
     local x = conn:load(url3)
     
    -- x = string.gsub(x, '<img', '')
  --   x = string.gsub(x, '">', '')
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
  
            url4 = string.gsub(url4, '^(.-)', 'https://lampa.kimabel.by') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end
 
 
-- https://a7c5ea7c.obrut.show/embed/1EjM/content/MTM4EjM?domain=gokino.su
 
 
--https://gokino.su/vv-player.php?path=/&movie_id=14981


 elseif args.q == 'veo' then

--https://aprelteam.gokino.by/vv-player.php?path=/&movie_id=14981

local url = 'https://api.rstprgapipt.com/balancer-api/iframe?kp=' .. args.id3 .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI'



local headers = {
    ["Host"] = "api.rstprgapipt.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

  --  local x = http.getz(url, headers)
 
  local x = conn:load(url)
 
  
 
   local id = string.match(x,'MOVIE_ID=(%d+)%;')
 

 
local url1 = 'https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI'


--table.insert(t, {title = 'https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI', mrl = 'https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI'})


--table.insert(t, {title = url1, mrl = url1})

  local x = http.get(url1)


 local slist = string.match(x, '"order":0.-"season".-"order":0(.-)}]}]')
 
 if slist then
 
 for url2, title in string.gmatch(slist, '"filepath":"(http.-)".-"title":"(.-)"') do
 
 
 t['view'] = 'list'

   table.insert(t, {title = '(1080p) ' .. title, mrl = url2, image = '#self/movie.png'})
end
end


 for total, total1, url2, title in string.gmatch(x, '"order":(.-),"season":.-"order":(.-)}.-"filepath":"(http.-)".-"title":"(.-)"') do
 


local text = total1 .. ' ' .. 'сезон ' .. total .. ' серия ' .. title


text = string.gsub(text, '0 сезон 0 серия', '')

 t['view'] = 'list'
 
 table.insert(t, {title = text, mrl = url2, image = '#self/movie.png'})
 

end
 
 
-- https://storage.videoseedcdn.com/movies/aec50961c21ef09d0040260875ff6627d9728a49/bfd76f0b07fdcc385574bcc1bbc18767:2026011806/1080.mp4:hls:manifest.m3u8
 
 
-- https://iqslgbok.deploy.cx/https://kinoserials.tv/videos/32489/32489/
 
-- https://kinoserials.tv/videos?id=32489
-- https://kinoserials.tv/videos/1042459/get/
 
 --https://api.videoseed.tv/embed/32489/?token=6091e1d0bf421f73804d2f0dcc2bf1cf
 
 --https://apn-latest.onrender.com/https://videoseed.tv/videos/32489/chujoy/
 
 
 elseif args.q == 'videoseed2' then
 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
   for url in string.gmatch(x, 'status.-"iframe":"http.-(/embed.-)"') do




local url = 'https://kinoserials.tv' .. url
   
   local headers = {
    ["Host"] = "kinoserials.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 
--https://kinoserials.tv/videos/36512/zatashchi-menya-v-ad/

   
 local x = http.getz(url, headers)
 
 local slist = string.match(x, 'var player = new Playerjs%((.-)%)') 
 
 --url = url_for(slist)
 --url = urldecode(url)
 
-- table.insert(t, {title = url, mrl = url})
 
 local slist1 = string.match(slist, '#2(.-)\"+') 
 
 if slist1 then




 
 slist1 = string.gsub(slist1, '|||', '')
 
 slist1 = string.gsub(slist1, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 slist1 = string.gsub(slist1, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 slist1 = string.gsub(slist1, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
slist1 = string.gsub(slist1, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

slist1 = string.gsub(slist1, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 
 
 
 slist1 = string.gsub(slist1, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 slist1 = string.gsub(slist1, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 slist1 = string.gsub(slist1, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
slist1 = string.gsub(slist1, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

slist1 = string.gsub(slist1, 'N3IzYXcyRWF0MD', '')

slist1 = string.gsub(slist1, 'NBaUNHQTI2ME9CcWc', '')
 
slist1 = string.gsub(slist1, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    


slist1 = http.urldecode(base64_decode(slist1))


slist1 = string.gsub(slist1, ';{', '"{')



for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   

   
 t['view'] = 'list'


table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})
end

for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   

   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

   
 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist1, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   

   
 t['view'] = 'list'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end
 end
end
 
 

 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')
	
	
x = string.gsub(x, 'tv%-1%-', '')

x = string.gsub(x, '%- %d сезон"', '')


        
 for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"http.-(/embed.-)"') do
 

   
   t['view'] = 'list'
   
 table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds2&id=' .. id, image = '#self/movie.png'})
 
 end

elseif args.q == 'videoseeds2' then

local url = 'https://kinoserials.tv' .. args.id



local headers = {
    ["Host"] = "kinoserials.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}


local x = http.getz(url, headers)



local x = string.match(x, '#2(.-)\"+')
 
 if x then
 
 x = string.gsub(x, '|||', '')
 
 
x = string.gsub(x, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 x = string.gsub(x, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 x = string.gsub(x, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
x = string.gsub(x, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

x = string.gsub(x, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    x =http.urldecode(base64_decode(x))


x = string.gsub(x, ';{', '"{')

--local slist = string.match(x, '"file":"(.-)"')
--if x then
 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'list'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
  -- url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
   
 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
 --  url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'list'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end
 end







 
 elseif args.q == 'videoseed' then

local url = 'https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3


  local headers = {
    ["Host"] = "api.videoseed.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

      local x = http.get(url, headers)
 

 
    for url in string.gmatch(x, 'status.-"iframe":"(http.-)"') do

  url = string.gsub(url, '\\', '')

--tv-3-kinolot.net

local headersS = {

    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["Cookie"] = "PHPSESSID=0f872a7617175500ab7b29ec4dbba1b4;kt_rt_token=6091e1d0bf421f73804d2f0dcc2bf1cf;kt_ips=159.69.148.100",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache",
["Vary"] = "Accept-Encoding",
["Content-Encoding"] = "gzip"
}

   local headers1 = {
    ["Host"] = "tv-1-kinoserial.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://tv-1-kinoserial.net/",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "PHPSESSID=7b7624424d89b8f1b62693cd364c0080; path=/; domain=.tv-1-kinoserial.net; SameSite=Lax; kt_rt_token=6091e1d0bf421f73804d2f0dcc2bf1cf; Max-Age=31104000; path=/; domain=.tv-1-kinoserial.net; SameSite=Lax",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}
  
     local x = http.getz(url, headers1)
 

   
    local slist = string.match(x,'#2(.-)%)') 
 
 
 --local slist = string.match(x, '#2(.-)\"+') 
 
 if slist then
 
 
 slist = string.gsub(slist, '|||', '')
 
 
slist = string.gsub(slist, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 slist = string.gsub(slist, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 slist = string.gsub(slist, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
slist = string.gsub(slist, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

slist = string.gsub(slist, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 
 
 slist = string.gsub(slist, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 slist = string.gsub(slist, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 slist = string.gsub(slist, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
slist = string.gsub(slist, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

slist = string.gsub(slist, 'N3IzYXcyRWF0MD', '')

slist = string.gsub(slist, 'NBaUNHQTI2ME9CcWc', '')
 
slist = string.gsub(slist, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')


    slist = base64_decode(slist)

slist = string.gsub(slist, ';{', '"{')

--table.insert(t, {title = x, mrl = x})


--local slist = string.match(x, '"file":"(.-)"') 
 

   for total, url1 in string.gmatch(slist,'"{(.-)}.-(http.-m3u8)') do
  
  
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'list'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

end
end


local url = 'https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3



    local headers = {
    ["Host"] = "api.videoseed.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
    }

      local x = http.get(url, headers)
 

 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')
	
	
--x = string.gsub(x, 'tv%-1%-', '')

x = string.gsub(x, '%- %d сезон"', '')


--https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=1384617

 for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"(http.-)"') do
 

   
   t['view'] = 'list'
   
 table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds&id=' .. id, image = '#self/movie.png'})
 
 end
 
 elseif args.q == 'videoseeds' then

local headersss = {
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "url",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}


local headers = {
    ["Host"] = "tv-1-kinoserial.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://tv-1-kinoserial.net/",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "PHPSESSID=7b7624424d89b8f1b62693cd364c0080; path=/; domain=.tv-1-kinoserial.net; SameSite=Lax; kt_rt_token=6091e1d0bf421f73804d2f0dcc2bf1cf; Max-Age=31104000; path=/; domain=.tv-1-kinoserial.net; SameSite=Lax",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}

 local x = http.getz(args.id, headers)


 
    local x = string.match(x, '#2(.-)\"+') 
 
 if x then
 
 
 
 x = string.gsub(x, '|||', '')
 
 
x = string.gsub(x, 'R1gyUWl4N3JHYWJvVnd1M0hZN3BlYXZ6M3IzVk9sUWtNUXhlUnJyNm5hdVNYUU5LSlZhRlhMeDBRa1F2NzNDVg==', '')
 
 
 x = string.gsub(x, 'ZFJyT25COTM3MndRUnRzYWs1Mm1GaXNMazVsemZFbmFKU1NXYXBnaHZvUjdycmQ2TnJ1dllSYkluNkkzVzlHWA==', '')
 
 x = string.gsub(x, 'd3ozV3FsSlNMRWp3NnRSNmNPMVdNZExmN1owSkNVbTZCUFJTbnAxbzlXSE90MGpBU3c0YldGY0VxaTM1Z3ZSRA==', '')
 
x = string.gsub(x, 'ekltTG5ueUhKaDNiU3R3dXpiamlhdnBLWnI3YWpXNWplY3J3ZGo0NGY0dnlja0RXcVp2dHZVMFZjUFl5VHI2eQ==', '')

x = string.gsub(x, 'S0xncDlhZGhubGRkYTJGd0dnUDR0cGlEbzNTY1hmWVZlWXdKeWtSSXdUSEdiSDB6RFhON0h0bFl6d3RnZzNRWQ==', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

--http.urlencode(
    x =http.urldecode(base64_decode(x))

x = string.gsub(x, ';{', '"{')

  -- local slist = string.match(x, '"file":"(.-)"')

--table.insert(t, {title = slist, mrl = x})
 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
  
  
  
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'list'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   

   
 t['view'] = 'list'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

 t['view'] = 'list'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

   
 t['view'] = 'list'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
 t['view'] = 'list'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1, image = '#self/movie.png'})

end
end
 
 
 
 --https://movie.kinodostuptut.com/search?filters={"yearRange":[1979]}&q=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%2C
 
 elseif args.q == 'rapidcdn' then
  
  
   local x = conn:load('https://movie.kinodostuptut.com/search?filters={"yearRange":[' .. args.id2 .. ']}&q=' .. urlencode(args.id1))
 
  t['view'] = 'simple'

      
      for url, image, title, total in string.gmatch(x, '<a class="group relative block.-href="(.-)".-<img.-src="(.-)".-<span class="text%-sm.->(.-)</span>.-class="text%-xs.->(.-)</span>') do
      
    url = string.gsub(url, '^(.-)', 'https://movie.kinodostuptut.com')
    
    table.insert(t, {title = tolazy(title) .. ',' .. total, mrl = '#stream/q=rapidcdns&id=' .. url, image = image})

     end 
 
 

      elseif args.q == 'rapidcdns' then
    
   -- Хищник: Планета смерти | сезон 0 | эпизод 0 в хорошем качестве без регистрации, смс и vpn\
    
      local x = conn:load(args.id)

      for url, title in string.gmatch(x, '"m3u8MasterFilePath.-"(http.-)\\".-{.-"title.-":.-"Смотреть сериал (.-)в хорошем') do
     
     
     title = string.gsub(title, '| сезон 0 | эпизод 0', '')
     
     t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = url})

     end 




elseif args.q == '24kino' then


local headers = {
["Host"] = "api-web-systema.platform24.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
["Accept"] = "application/json, text/plain, */*",
["Accept-Language"] = "ru-ru",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-Type"] = "application/json",
["Content-Length"] = "52",
["Origin"] = "https://tv.cyxym.net",
["Connection"] = "keep-alive",
["Referer"] = "https://tv.cyxym.net/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site"
}

local params = '{"device_id":"c99fe352-7718-4879-b92a-c6e3f61c9ccd"}'


   local url = 'https://api-web-systema.platform24.tv/v2/auth/device'

        local x = http.postz(url, headers, params)

      local token = string.match(x, '"access_token":"(.-)"')

	if token then

local url = 'https://api-web-systema.platform24.tv/v2/rows/1154861723594598690?access_token=' .. token .. '&channels_version=2&format=json&limit=15&offset=0&text=' .. urlencode(args.id1 .. ' ' .. args.id2)

if url then

 local x = conn:load(url)

--table.insert(t, {title = url, mrl = url, image = image})

--search%-movie.-"contents".-%[

 local movie = string.match(x,'search%-movie.-"contents".-%[(.-)]}')


if movie then

for id, title, year in string.gmatch(movie,'{"id":"(.-)","title":"(.-)".-"content_type":"movie".-"year":"(.-)".-"rowset_id"') do

if year then

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id .. '?access_token=' .. token .. '&format=json')


local id1, libs = string.match(x,'"graphic_title".-"id":"(.-)".-"libraries":%[{"id":(.-)}')

if id1 then

local x = conn:load('https://api-web-systema.platform24.tv/v2/libraries/' .. libs .. '/contents/' .. id1 .. '/stream?access_token=' .. token .. '&channels_version=2&format=json&ts=0&type=hls')


local play = string.match(x,'"hls":"(.-)"')   
  if play then

t['view'] = 'list'

table.insert(t, {title = 'Фильм - ' .. title .. ' (' .. year .. ')', mrl = play, image = '#self/movie.png'})

end
end
end
end
end
end



local url1 = 'https://api-web-systema.platform24.tv/v2/rows/1154861723663302975?offset=0&limit=15&channels_version=2&format=json&access_token=' .. token .. '&text=' .. urlencode(args.id1 .. ' ' .. args.id2)

if url1 then

--table.insert(t, {title = url1, mrl = url1, image = image})

local x = conn:load(url1)

--table.insert(t, {title = url1, mrl = url1, image = image})

local series = string.match(x,'search%-series.-"contents".-%[(.-)]}')


if series then

for id, title, year in string.gmatch(series,'{"id":"(.-)","title":"(.-)".-"content_type":"series".-"year":"(.-)".-"rowset_id"') do

--local id, title, year = string.match(x,'"contents".-%[{"id":"(.-)".-"title":"(.-)".-"year":"(.-)"')

if id then


t['view'] = 'list'

table.insert(t, {title = 'Сериал - ' .. title .. ' (' .. year .. ')', mrl = '#stream/q=24kinos&id=' .. id .. '&id1=' .. token, image = '#self/movie.png'})

end
end
end
end
end

elseif args.q == '24kinos' then


local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. args.id .. '?access_token=' .. args.id1 .. '&format=json')



local seasons = string.match(x,'"contents":%[(.-)]')
  
  
  for id1, season in string.gmatch(seasons,'{"id":"(.-)".-"title":"(.-)"') do

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id1 .. '?access_token=' .. args.id1 .. '&format=json')

local episodes = string.match(x,'"contents":%[(.-)]')
  
  
  for id2, series in string.gmatch(episodes,'{"id":"(.-)".-"content_type".-"series":(.-),') do

local x = conn:load('https://api-web-systema.platform24.tv/v2/contents/' .. id2 .. '?access_token=' .. args.id1 .. '&format=json')

  local id3, libs = string.match(x,'"graphic_title".-"id":"(.-)".-"libraries":%[{"id":(.-)}')

local x = conn:load('https://api-web-systema.platform24.tv/v2/libraries/' .. libs .. '/contents/' .. id3 .. '/stream?access_token=' .. args.id1 .. '&channels_version=2&format=json&ts=0&type=hls')


local play = string.match(x,'"hls":"(.-)"')   
  if play then

t['view'] = 'list'

table.insert(t, {title = season .. ' серия ' .. series, mrl = play, image = '#self/movie.png'})


end
end
end
--end
--end

--end






elseif args.q == 'mirkino' then


local url = 'https://ru.mir-kino.pp.ru/Items?userId=75280f7de0a64771b9dd63c4b23b814d&isMissing=false&limit=800&recursive=true&searchTerm=' .. urlencode(args.id1) .. '&ProductionYear=' .. args.id2 .. '&fields=PrimaryImageAspectRatio&fields=CanDelete&fields=MediaSourceCount&includeItemTypes=Movie&includeItemTypes=Series&includeItemTypes=Episode&includeItemTypes=Playlist&includeItemTypes=MusicAlbum&includeItemTypes=Audio&includeItemTypes=TvChannel&includeItemTypes=PhotoAlbum&includeItemTypes=Photo&includeItemTypes=AudioBook&includeItemTypes=Book&includeItemTypes=BoxSet&imageTypeLimit=1&enableTotalRecordCount=false'


local headers = {
    ["Host"] = "ru.mir-kino.pp.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    ["Accept"] = "application/json, text/plain, */*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Authorization"] = 'MediaBrowser Client="Jellyfin%20Web", Device="Firefox", DeviceId="TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6MTUyLjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvMTUyLjB8MTc4NDEwMDMxMDg1OQ11", Version="10.11.10", Token="7325db2c854d4d0aadea155da54f2d58"',
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local x = http.getz(url, headers)

for name, item, year in string.gmatch(x,'"Name":"(.-)".-"Type":"Movie".-"ItemId":"(.-)".-"ProductionYear":(.-),') do

if item then

local x = http.getz('https://ru.mir-kino.pp.ru/Items/' .. item, headers)

for id, qual in string.gmatch(x,'{"Protocol":"File","Id":"(.-)".-"Name":"(%d+p)"') do

t['view'] = 'list'


table.insert(t, {title = qual .. ' ' .. name .. ' (' .. year .. ')', mrl = 'https://ru.mir-kino.pp.ru/Videos/' .. id .. '/stream?api_key=7325db2c854d4d0aadea155da54f2d58&Static=true', image = '#self/movie.png'})

end
end
end

local url = 'https://ru.mir-kino.pp.ru/Items?userId=75280f7de0a64771b9dd63c4b23b814d&isMissing=false&limit=800&recursive=true&searchTerm=' .. urlencode(args.id1) .. '&ProductionYear=' .. args.id2 .. '&fields=PrimaryImageAspectRatio&fields=CanDelete&fields=MediaSourceCount&includeItemTypes=Movie&includeItemTypes=Series&includeItemTypes=Episode&includeItemTypes=Playlist&includeItemTypes=MusicAlbum&includeItemTypes=Audio&includeItemTypes=TvChannel&includeItemTypes=PhotoAlbum&includeItemTypes=Photo&includeItemTypes=AudioBook&includeItemTypes=Book&includeItemTypes=BoxSet&imageTypeLimit=1&enableTotalRecordCount=false'


local headers = {
    ["Host"] = "ru.mir-kino.pp.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    ["Accept"] = "application/json, text/plain, */*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Authorization"] = 'MediaBrowser Client="Jellyfin%20Web", Device="Firefox", DeviceId="TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NDsgcnY6MTUyLjApIEdlY2tvLzIwMTAwMTAxIEZpcmVmb3gvMTUyLjB8MTc4NDEwMDMxMDg1OQ11", Version="10.11.10", Token="7325db2c854d4d0aadea155da54f2d58"',
    ["Connection"] = "keep-alive",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}



local x = http.getz(url, headers)

for name, item in string.gmatch(x,'"Name":"(.-)".-"Type":"Playlist".-"ItemId":"(.-)"') do

if item then


local x = http.getz('https://ru.mir-kino.pp.ru/Playlists/' .. item .. '/Items?Fields=PrimaryImageAspectRatio,MediaSourceCount,Chapters,Trickplay&EnableImageTypes=Primary,Backdrop,Banner,Thumb', headers)



for name1, item1, year in string.gmatch(x,'{"Name":"(.-)".-"Type":"Movie".-"ItemId":"(.-)".-"ProductionYear":(.-),') do

if item1 then

  local x = http.getz('https://ru.mir-kino.pp.ru/Items/' .. item1, headers)



for id, qual in string.gmatch(x,'{"Protocol":"File","Id":"(.-)".-"Name":"(%d+p)"') do

t['view'] = 'list'


table.insert(t, {title = qual .. ' ' .. name1 .. ' (' .. year .. ')', mrl = 'https://ru.mir-kino.pp.ru/Videos/' .. id .. '/stream?api_key=7325db2c854d4d0aadea155da54f2d58&Static=true', image = '#self/movie.png'})

end
end
end
end
end

 local x = http.getz(url, headers)


local id, series, item = string.match(x,'"Items".-"Name".-"Id":"(.-)".-"Type":"(Series)".-"ItemId":"(.-)"') 

if item then


local x = http.getz('https://ru.mir-kino.pp.ru/Shows/' .. id .. '/Seasons?userId=75280f7de0a64771b9dd63c4b23b814d&Fields=ItemCounts,PrimaryImageAspectRatio,CanDelete,MediaSourceCount', headers)



for name, id1, season in string.gmatch(x,'"Name":"(Сезон.-)".-"Id":"(.-)".-"SeriesId":"(.-)"') do

if season then

local x = http.getz('https://ru.mir-kino.pp.ru/Shows/' .. season .. '/Episodes?seasonId=' .. id1 .. '&userId=75280f7de0a64771b9dd63c4b23b814d&Fields=ItemCounts,PrimaryImageAspectRatio,CanDelete,MediaSourceCount,Overview', headers)



for nameser, id2 in string.gmatch(x,'"Name":"(.-)".-"Id":"(.-)"') do


local x = http.getz('https://ru.mir-kino.pp.ru/Items/' .. id2 .. '?userId=75280f7de0a64771b9dd63c4b23b814d', headers)


local episode, item = string.match(x,'{"Name":".-".-/episode/(.-)".-"ItemId":"(.-)"')

t['view'] = 'list'



table.insert(t, {title = name .. ' ' .. 'серия ' .. episode .. ' ' .. nameser, mrl = 'https://ru.mir-kino.pp.ru/Videos/' .. item .. '/stream?api_key=7325db2c854d4d0aadea155da54f2d58&Static=true', image = '#self/movie.png'})

end
end
end
end






elseif args.q == 'zerohd' then

local headers = {
["Host"] = "r.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["Content-Length"] = "",
["Origin"] = "http://app.xsmart.tv",
["Connection"] = "keep-alive",
["Referer"] = "http://app.xsmart.tv/",
["Priority"] = "u=0"
}

local url = 'http://r.xsmart.tv/api/'

local params = 'key=&type=gold&status=user&mac=xsm350529839&serial=snf2dfaeb614f&ver=5.4.368'


local x = http.postz(url, headers, params)

if x then

local key, status = string.match(x,'"key_hash":"(.-)","key_check":"(.-)"')



local kp = args.id3

if kp then




local url = 'http://r.xsmart.tv/api/parser/'

local headerss = {
["Host"] = "r.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["Content-Length"] = "166",
["Origin"] = "http://app.xsmart.tv",
["Connection"] = "keep-alive",
["Referer"] = "http://app.xsmart.tv/",
["Priority"] = "u=0"
}



local params = 'key=' .. key .. '&adult=0&use_cdn=0&url=%3Fmode%3Dxkino%26cat%3D6%26id_film%3D' .. kp .. '&uid=119399&user=Free&status=user&platform=BROWSER&ver=5.4.368'

local x = http.postz(url, headerss, params)

if x then

--table.insert(t, {title = x, mrl = x, image = '#self/movie.png'})

x = string.gsub(x, '\\u041f\\u043e\\u043b\\u043d\\u043e\\u0435', 'Полное')

x = string.gsub(x, '\\u0417\\u0432\\u0443\\u043a \\u043d\\u0430 \\u0432\\u044b\\u0431\\u043e\\u0440', 'Звук на выбор')

x = string.gsub(x, '\\u0438\\u0441\\u0442\\u043e\\u0447\\u043d\\u0438\\u043a', 'источник')



t['view'] = 'list'


local sources = string.match(x,'sources.-%[(.-)]')

if sources then

--table.insert(t, {title = sources, mrl = sources, image = '#self/movie.png'})


for id, names in string.gmatch(sources,'{"id":"(.-)","name":"(.-)"') do



--table.insert(t, {title = name, mrl = '#stream/q=zerocdnm&id=' .. cat .. '&id3=' .. kp .. '&id4=' .. id, image = '#self/movie.png'})

--end
--end
--end
--end

--elseif args.q == 'zerocdnm' then


local headers1 = {
["Host"] = "r.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["Content-Length"] = "",
["Origin"] = "http://app.xsmart.tv",
["Connection"] = "keep-alive",
["Referer"] = "http://app.xsmart.tv/",
["Priority"] = "u=0"
}


local url2 = 'http://r.xsmart.tv/api/parser/'

local params2 = 'key=' .. key .. '&key_status=' .. status .. '&adult=0&use_cdn=0&url=%3Fmode%3Dxkino%26cat%3D6%26id_film%3D' .. kp .. '%26source%3D' .. id .. '&mac=xsm350529839&platform=BROWSER'

local x = http.postz(url2, headers1, params2)

if x then


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')

x = string.gsub(x, 'Низкое', '360p')
x = string.gsub(x, 'Нормальное', '480p')
x = string.gsub(x, 'Высокое', '720p')
x = string.gsub(x, 'Максимальное', '1080p')


	
	t['view'] = 'list'


for url in string.gmatch(x,'{".-":.-"url".-"urls":%["(.-)"') do

if url then
    
  --  return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}
    
table.insert(t, {title = names, mrl = url, image = '#self/movie.png'})

end
end

for title, video in string.gmatch(x,'{"title":"(.-)".-"url":%[(.-)]') do

for name, url in string.gmatch(video,'"name":"(.-)","url":"(.-)"') do

table.insert(t, {title = name .. ' ' .. title, mrl = url, image = '#self/movie.png'})

end
end


for title, video in string.gmatch(x,'{"title":"(.-)","stream":%[(.-)}]}') do

for total, url in string.gmatch(video,'"name":"(.-)","urls":.-"(.-)"') do


table.insert(t, {title = title .. ' ' .. total, mrl = url, image = '#self/movie.png'})

end
end

end
end
end
end
end


-- elseif args.q == 'zerocdns' then
 
 
 local headers = {
["Host"] = "r.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["Content-Length"] = "",
["Origin"] = "http://app.xsmart.tv",
["Connection"] = "keep-alive",
["Referer"] = "http://app.xsmart.tv/",
["Priority"] = "u=0"
}

local url = 'http://r.xsmart.tv/api/'

local params = 'key=&type=gold&status=user&mac=xsm350529839&serial=snf2dfaeb614f&ver=5.4.368'


local x = http.postz(url, headers, params)

if x then

local key, status = string.match(x,'"key_hash":"(.-)","key_check":"(.-)"')

 local url1 = 'http://r.xsmart.tv/api/parser/'


local params1 = 'key=' .. key .. '&key_status=' .. status .. '&adult=0&use_cdn=0&url=%3Fmode%3Dxkino%26id_film%3D' .. args.id3 .. '%26cat%3D3%26source%3D10&mac=xsm350529839&platform=BROWSER'
 
 
 local x = http.postz(url1, headers, params1)

if x then



local x = json.decode(x)

for _, v in ipairs(x) do

--for seasons, id in string.gmatch(x,'"title":"(.-)".-"url":"(.-)"') do

local id = v['url']
 local season = v['title'] 

local params2 = 'key=' .. key .. '&key_status=' .. status .. '&adult=0&use_cdn=0&url=' .. urlencode(id) .. '&mac=xsm350529839&platform=BROWSER'

 local x = http.postz(url1, headers, params2)

if x then



x = urldecode(x)

local x = json.decode(x)

for _, v in ipairs(x) do

--for episodes, id1 in string.gmatch(x,'{"title":"(.-)","url":"(.-)"') do


local id1 = v['url']
local episode = v['title'] 
 
 
 local params3 = 'key=' .. key .. '&key_status=' .. status .. '&adult=0&use_cdn=0&url=' .. urlencode(id1) .. '&mac=xsm350529839&platform=BROWSER'
 
 
 
 local x = http.postz(url1, headers, params3)

if x then


 
 local x = json.decode(x)

for _, v in ipairs(x) do

 local id2 = v['url']
 local voice = v['title'] 
 
 id2 = urldecode(id2)

--local params4 = 'key=' .. key .. '&type=video&key_status=' .. status .. '&url=' .. urlencode(id2) .. '&mac=xsm350529839&gold=Free&platform=BROWSER'
 
-- local url2 = 'http://r.xsmart.tv/api/'
 
--  local x = http.postz(url2, headers, params4)



t['view'] = 'list'

--for title, video in string.gmatch(x,'{"title":"(.-)".-"url":%[(.-)]') do

--for name, url in string.gmatch(video,'"name":"(.-)","url":"(.-)"') do
 
 table.insert(t, {title = voice .. ' ' .. season .. ' ' .. episode, mrl = '#stream/q=zerocdnsvi&id=' .. urlencode(id2), image = '#self/movie.png'})
 
--table.insert(t, {title = x, mrl = x, image = '#self/movie.png'})
 
 end
 end
 end
end
 end
end
 end
end


 
 elseif args.q == 'zerocdnsvi' then
 
 local headers = {
["Host"] = "r.xsmart.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate",
["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
["Content-Length"] = "",
["Origin"] = "http://app.xsmart.tv",
["Connection"] = "keep-alive",
["Referer"] = "http://app.xsmart.tv/",
["Priority"] = "u=0"
}

local url = 'http://r.xsmart.tv/api/'

local params = 'key=&type=gold&status=user&mac=xsm350529839&serial=snf2dfaeb614f&ver=5.4.368'


local x = http.postz(url, headers, params)

if x then

local key, status = string.match(x,'"key_hash":"(.-)","key_check":"(.-)"')

 local url1 = 'http://r.xsmart.tv/api/parser/'
 
 local params1 = 'key=' .. key .. '&type=video&key_status=' .. status .. '&adult=0&use_cdn=0&url=' .. urlencode(args.id) .. '&mac=xsm350529839&gold=Free&platform=BROWSER'
 
 
  local x = http.postz(url, headers, params1)
	
	t['view'] = 'list'
	
 local x = json.decode(x)

for _, v in ipairs(x) do

local name = v['name']
name = string.gsub(name, 'Низкое', '360p')
name = string.gsub(name, 'Нормальное', '480p')
name = string.gsub(name, 'Высокое', '720p')
name = string.gsub(name, 'Максимальное', '1080p')
  
  
  
table.insert(t, {title = name, mrl = v['url'], image = '#self/movie.png'})
 
 end
 
end






 
    elseif args.q == 'xkino' then
  
 -- https://ru.kinozona.net/poisk.php
--form=do=search&subaction=search&story=чужой
  
 -- local url = 'https://ru.kinozona.net/poisk.php?form=do%3Dsearch%26subaction%3Dsearch%26story%3D' .. urlencode(args.id1)
  
  local url = 'https://videomob.su/poisk.php'
  
--local url = 'https://ru.kinozona.net/poisk.php'
  
  local headers = {
    ["Host"] = "videomob.su",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Content-Length"] = "",
    ["Origin"] = "https://videomob.su",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://videomob.su/",
    ["Cookie"] = "PHPSESSID=kt614shanjhqpcb4qgqfuv7t0l; _ym_uid=1778172366407960634; _ym_d=1778172366; _ym_isad=2; vid=YOax6UDdZMBIbGlG; domain_sid=FP3g3yrURwKO2N-PHJz5S%3A1778172907526; adrdel=1778172387500; adrdel=1778172387500; adrcid=A61RKDqR0L5sDSPiVXIiXNg; adrcid=A61RKDqR0L5sDSPiVXIiXNg; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; ecf7d0dc55_delayCount=10; ecf7d0dc55_blockTimer=1; u_ecf7d0dc55=1; _ohmybid_cmf=2; adtech_uid=7956247a-a163-46a4-943d-af979def0958%3Akinozona.net; top100_id=t1.7627570.775262879.1778172521116; t3_sid_7627570=s1.389385681.1778172521120.1778172911440.1.20.8.1..",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

  local form = 'form=do%3Dsearch%26subaction%3Dsearch%26story%3D' .. urlencode(args.id1)
  
      local x = http.postz(url, headers, form)
      
  
for urls, title in string.gmatch(x,'<a href="(.-)">(.-)<span') do
 
 urls = string.gsub(urls, '^(.-)', 'https://videomob.su')
 
  t['view'] = 'list'
  
  
   table.insert(t, {title = title, mrl = '#stream/q=xkinos&id=' .. urls, image = '#self/movie.png'})

   end  
  
  
  elseif args.q == 'xkinos' then
    
    
      local x = conn:load(args.id)
  
    
  local id = string.match(x,'<div class="trailer".-torLoad%(\'(.-)\'')
  
  local se = string.match(x,'function torLoad%(id.-se = (.-)%)')
 
 
 
 
  local tor = string.match(x,'function torLoad.-load.-(tor.-php)')
   
   local poster = string.match(x,'function torLoad.-load.-tor.-php.-poster:"(.-)"')
   
  --  load("/tor_series.php"
    
  local url = 'https://videomob.su/' .. tor




local headers = {
    ["Host"] = "videomob.su",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Content-Length"] = "",
    ["Origin"] = "https://videomob.su",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://videomob.su/",
    ["Cookie"] = "PHPSESSID=kt614shanjhqpcb4qgqfuv7t0l; _ym_uid=1778172366407960634; _ym_d=1778172366; _ym_isad=2; vid=YOax6UDdZMBIbGlG; domain_sid=FP3g3yrURwKO2N-PHJz5S%3A1778172907526; adrdel=1778172387500; adrdel=1778172387500; adrcid=A61RKDqR0L5sDSPiVXIiXNg; adrcid=A61RKDqR0L5sDSPiVXIiXNg; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; acs_3=%7B%22hash%22%3A%221aa3f9523ee6c2690cb34fc702d4143056487c0d%22%2C%22nst%22%3A1778258793659%2C%22sl%22%3A%7B%22224%22%3A1778172393659%2C%221228%22%3A1778172393659%7D%7D; ecf7d0dc55_delayCount=10; ecf7d0dc55_blockTimer=1; u_ecf7d0dc55=1; _ohmybid_cmf=2; adtech_uid=7956247a-a163-46a4-943d-af979def0958%3Akinozona.net; top100_id=t1.7627570.775262879.1778172521116; t3_sid_7627570=s1.389385681.1778172521120.1778172911440.1.20.8.1..",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

  local params = 'id=' .. id .. '&se=' .. se .. '&poster=' .. poster
  
      local x = http.postz(url, headers, params)

--table.insert(t, {title = url, mrl = url, image = image})   


local video = string.match(x,'<video src="(http.-)"')
 
 if video then
 
 print(video)
    return {view = 'playback', mrl = video, seekable = 'true', direct = 'true'}
 
 --table.insert(t, {title = video, mrl = video, image = image})
 
 end
 
   
   for video, title in string.gmatch(x,'(https://s.-)\'>(.-)<') do
   
 --   url = url_for(x)
--url = urldecode(url)
 
 --table.insert(t, {title = url, mrl = url, image = image})   
  
t['view'] = 'list'
  
 -- if video then
--    print(video)
 --   return {view = 'playback', mrl = video, seekable = 'true', direct = 'true'}
--end

  table.insert(t, {title = title, mrl = video, image = '#self/movie.png'})   
  
  end
  
  
 -- http://seasonvar.ru/?mode=search&query
  
  
  elseif args.q == 'seasonvar' then
    
   

    
      local x = conn:load('http://seasonvar.ru/?mode=search&query=' .. urlencode(args.id1))
  
  
 -- local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
     --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'http:')
        
        t['view'] = 'list'
		
			

  
  
  local x = conn:load('http://seasonvar.ru' .. url)
 
 
 local slist = string.match(x, '<ul class="tabs%-result">(.-)</ul>')
      
if slist then

   for url2, total in string.gmatch(slist, '<a href="(.-)".-Сериал (.-)<') do
   
  table.insert(t, {title = tolazy(total), mrl = '#stream/q=seasonvars&id=' .. url2, image = '#self/movie.png'})
		
		end
end
end



   
   elseif args.q == 'seasonvars' then
   
   local x = conn:load('http://seasonvar.ru' .. args.id)
        
        
        
        
        
      --  local x = conn:load(url2)
 
 for id1, total1 in string.gmatch(x,'"(/playls2.-)".-data%-translate%-percent=.->(.-)</li>') do
 
 
    --    for id1 in string.gmatch(x,'player = new Playerjs.-var pl.-"(/playls2.-)"') do
            
    local x = conn:load('http://seasonvar.ru' .. id1)
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id2 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id2 = string.gsub(id2, '\\/\\/b2xvbG8=', '') 
      
      id2=http.urldecode(base64_decode(id2))
       id2 = string.gsub(id2, '^(.-)', 'http:') 
           t['view'] = 'list'
				table.insert(t,{title=tolazy(title1) .. ' ' .. total1, mrl = id2, image = '#self/movie.png'})
            end  
	end
  
 
  local x = conn:load('http://seasonvar.ru' .. args.id)
        
 
 local id2 = string.match(x,'var pl.-(/playls2.-)"')

            local x = conn:load('http://seasonvar.ru' .. id2)
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id3 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id3 = string.gsub(id3, '\\/\\/b2xvbG8=', '') 
      
      id3=http.urldecode(base64_decode(id3))
       id3 = string.gsub(id3, '^(.-)', 'http:') 
           t['view'] = 'list'
				table.insert(t,{title=tolazy(title1), mrl = id3, image = '#self/movie.png'})
            end  
  
  
  

  
  
    elseif args.q == 'zetflix' then
    
 --  https://beta.l-vid.online/lite/videodb?kinopoisk_id=386&title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&year=1979&token=a46f8a8a-8878-4fa5-8554-8296ba62260d

--https://beta.l-vid.online/online/js/a46f8a8a-8878-4fa5-8554-8296ba62260d


--https://beta.l-vid.online/online/js/8126ef1f-0a68-4b87-be2b-732e679461cc

--http://31.129.234.181/lite/events?uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv

 --   https://lampa.li/lite/zetflix?kinopoisk_id=386&title=чужой&year=1979&uid=hlltpzjn
    
    local headers = {['X-Requested-With'] = 'XMLHttpRequest'}
    
    
    
      local x = http.get('https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

   
 x = string.gsub(x, '\\u0026', '&')
 

 
   for url, total in string.gmatch(x, 'videos__item videos__movie.-stream.-(http.-)&#.-videos__item%-title.->(.-)<') do
  
-- table.insert(t, {title = url .. '&uid=bwygkgxn', mrl = url .. '&uid=bwygkgxn'})
 
      local x = http.get(url .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
  
  
 --  local slist = string.match(x, 'qualit.-{(.-)}')
   
   for  total1, url2 in string.gmatch(x, '"(.-)".-http.-(/lite.-)"') do
      
    url2 = string.gsub(url2, '^(.-)', 'https://lampa.li')



--http://178.20.46.40:12600/lite/videodb/manifest.m3u8?
      
  --   total1 = string.gsub(total1, ':{"', '') 
      
       t['view'] = 'simple'



    table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
  
 -- http://beta2.l-vid.online:888/lite/zetflix/manifest.m3u8?link=https%3A%2F%2Fcdn-54243ba5.obrut.show%2Fstream%2FAO%2FMHc0RHa%2FQbvNmLuR2YyVGc1RmclBXdz5ie%2F4U3Mt5CdzVmZp5WYtpzcshmO0AXbuADO08SMxYTM0AjNyAjM6MGO5MGOlR2YjJmYwImNyADZjNDM0cTYjVDN1MzN0gDNvUjNmVGOkJmZwYTMzgDNmJDMjRzY1QGN5AjN0gDM1QTOiRDNkdDMjNzLzVWayV2c2R3L
  

   
 -- local x = http.get('https://beta.l-vid.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

table.insert(t, {title = 'https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn', mrl = 'http://beta.l-vid.online/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn'})
   
 --  x = string.gsub(x, '\\u0026', '&')

   
        for url3, total1  in string.gmatch(x, 'videos__item videos__season.-method.-link.-url.-http.-&s=(.-)&#.-videos__item%-title videos__season%-title.->(.-)<') do


   local x = http.get('https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&s=' .. url3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

table.insert(t, {title = 'https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&s=' .. url3 .. '&uid=bwygkgxn', mrl = 'https://lampa.li/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&s=' .. url3 .. '&uid=bwygkgxn'})

    --  local x = http.getz('http://beta.l-vid.online' .. url3 .. '&uid=bwygkgxn')

      for url4, total2  in string.gmatch(x, 'videos__button.-method.-link.-url.-(http.-)&#.->(.-)<') do

url4 = string.gsub(url4, '\\u0026', '&')



     local x = http.getz(url4 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')


x = string.gsub(x, '\\u0026', '&')

      for url5, total3  in string.gmatch(x, 'videos__item videos__movie.-method.-stream.-title.-url.-http.-(/proxy.-m3u8).-videos__item%-title.->(.-серия)<') do

     url5 = string.gsub(url5, '^(.-)', 'https://s.lampa.li')
    

      t['view'] = 'simple'

 
 table.insert(t, {title = url5, mrl = url5})
 
    table.insert(t, {title = total1 .. ' -'  .. total3 .. tolazy(total2), mrl = url5})

   
    end
end
end




--https://beta.l-vid.online/lite/sakhtv?title=чужой&year=1979&uid=bwygkgxn


  
 elseif args.q == 'sakhtv' then
  
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

     local url = 'https://beta.l-vid.online/lite/sakhtv?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
   if x then
  
    
  x = string.gsub(x, '\\u0026', '&')

 
  for url1, total in string.gmatch(x, 'method.-url.-(http.-)&#.-videos__item%-title.->(.-)<') do

--local x = conn:load(url1)


      t['view'] = 'simple'

 --table.insert(t, {title = total, mrl = '#stream/q=paladins&id=' .. })
 
  table.insert(t, {title = total, mrl = url1})

      end 
   
   
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-(http.-)&.-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')

--url3 = string.gsub(url3, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


       local x = conn:load(url3)

    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&.->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')

 -- url4 = string.gsub(url4, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


     local x = conn:load(url4)
    
    x = string.gsub(x, '\\u0026', '&')
    

   for id, id1, total2 in string.gmatch(x, 'method.-stream.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do
 

  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
  

end
end
end
end     
      
 elseif args.q == 'paladinsbbb' then
    
local headers = {
    ["Host"] = "beta2.l-vid.online:888",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cache-Control"] = "no-cache"
}

local x = http.getz('http://beta2.l-vid.online:888/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d', headers)

      local slist = string.match(x, '"quality"(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":"(http.-)"') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
   url6 = string.gsub(url6, '\\u002B', '+')

--  url6 = string.gsub(url6, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = url6})

end
end




elseif args.q == 'getstv' then
    
   
   
 --https://lampa.oksibutch.ru:443  
   
--https://evkh.lol
--http://z01.online/lite/getstv?kinopoisk_id=386&title=Чужой&year=1979
    
    
  --  http://z01.online/lite/getstv?orid=65aa68fa3c55bab796fa8820&title=%d0%a7%d1%83%d0%b6%d0%be%d0%b9&original_title=&year=0
    
      local x = conn:load('https://lampa.oksibutch.ru:443/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 -- table.insert(t, {title = 'https://lampa.oksibutch.ru:443/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


     for  url1, total in string.gmatch(x, 'videos__item videos__movie.-method.-url.-(http.-)&.-videos__item%-title.->(.-)<') do
  
    
     url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

     local x = conn:load(url1)
   
 

 
     local slist = string.match(x, 'quality(.-)}')
      
if slist then

   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

    total1 = string.gsub(total1, ',"', '') 
    total1 = string.gsub(total1, '1080p":"/error.mp4"', '')
    
    
    
    
total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

      end 
    end

    end
     
     
     
     for url2, total1  in string.gmatch(x, 'videos__item videos__season.-method.-url.-(http.-)&.-videos__item%-title videos__season%-title.->(.-сезон)<') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&.->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'videos__item videos__movie selector.-method.-url.-stream.-(http.-)&.-videos__item%-title.->(.-серия)<') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end

    
    
 
elseif args.q == 'mirage' then
    
  
--https://akter-black.com/lite/alloha?id=1304313&imdb_id=tt32612507&kinopoisk_id=6785084&title=%D0%9C%D1%83%D0%BC%D0%B8%D1%8F&original_title=Lee%20Cronin%27s%20The%20Mummy&serial=0&original_language=en&year=2026&source=tmdb&clarification=0&similar=false&rchtype=web&uid=hobqwt4m
  
 -- memkey=m2FtOXt7C35vHdKNklFlpw&
  
     local x = conn:load('https://akter-black.com/lite/alloha?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')



 --  x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"url":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

 local x = conn:load(url .. '&uid=hobqwt4m')
 
 
 
-- local x = conn:load(url)
 
 local slist = string.match(x,'quality.-{(.-)}')
 
 if slist then
 
 for qual, url1 in string.gmatch(slist, '"(%d+p)".-(http.-m3u8)') do
   
 
     t['view'] = 'list'


    table.insert(t, {title = '(' .. qual .. ') ' .. total, mrl = url1, image = '#self/movie.png'})

 end
    end
   end 
 
 
-- local x = conn:load('https://akter-black.com/lite/alloha?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')
 
 
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3 .. '&uid=hobqwt4m')


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4 .. '&uid=hobqwt4m')

--table.insert(t, {title = url4, mrl = url4})

x = string.gsub(x, '\\u0026', '&')

     for id, id1, id2, id3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"url":"http.-?t=(.-)&s=(.-)&e=(.-)&token_movie=(.-)&orid.-class="videos__item%-title">(.-)</div>') do

   
    t['view'] = 'list'



--https://akter-black.com/lite/alloha/video?t=234&s=1&e=2&token_movie=352d33e54cf583160797cae895ff80&orid





table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = '#stream/q=mirages&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2  .. '&id3=' ..  id3, image = '#self/movie.png'})

end
end
end
     
     elseif args.q == 'mirages' then
     
     local x = conn:load('https://akter-black.com/lite/alloha/video?t=' .. args.id .. '&s=' .. args.id1 .. '&e=' .. args.id2 .. '&token_movie=' .. args.id3 .. '&uid=hobqwt4m')
    
    local slist = string.match(x,'quality.-{(.-)}')
 
 if slist then
 
 for qual, url1 in string.gmatch(slist, '"(%d+p)".-(http.-m3u8)') do
   
 
     t['view'] = 'list'


    table.insert(t, {title = '(' .. qual .. ')', mrl = url1, image = '#self/movie.png'})

 end
    end 

     
    elseif args.q == 'mirage1' then
    
  
 -- https://vizhu.top
--  https://lampa.persh1n.ru
  
--  http://93.183.95.219:11378
 
-- http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=912590&stream=e8793ac5f12fe96596a7f3b2d9b59b&audio=0&box_mac=acace24b8434
 
-- https://lam.maxvol.pro/lite/mirage/video?id_file=911588\u0026token_movie=a6ef0986c7558c5792c3ad19d43611",
 
    
  --  https://lam.maxvol.pro/lite/mirage?kinopoisk_id=386&title=чужой&year=1979
 
-- http://78.40.199.67:10630
 
    
     local x = conn:load('https://mylam.ru/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



  -- x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

      t['view'] = 'simple'


    table.insert(t, {title = total, mrl = url})

 
    end
    
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')

url5 = string.gsub(url5, '\\u002B', '+') 
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
     
--http://online7.skaz.tv/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025

  --  http://z01.online/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025 
 
 
 --http://rc.bwa.ad/lite/events?
 
 local x = conn:load('http://z01.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



  -- x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

      t['view'] = 'simple'


    table.insert(t, {title = '720p ' .. total, mrl = url})

 
    end
    
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')

url5 = string.gsub(url5, '\\u002B', '+') 
    t['view'] = 'simple'

table.insert(t, {title = '720p ' .. total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
 
 


 
 
 
  
 elseif args.q == 'paladin' then
  
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

     local url = 'https://beta.l-vid.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
   if x then
   
--   for url1, total in string.gmatch(x, 'method.-url.-(http.-)&#.-videos__item%-title.->(.-)<') do
  
  x = string.gsub(x, '\\u0026', '&')

for id, id1, total in string.gmatch(x, 'method.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do



      t['view'] = 'simple'

 table.insert(t, {title = total, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
 
 -- table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

      end 
   
   
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-(http.-)&.-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')

--url3 = string.gsub(url3, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


       local x = conn:load(url3)

    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&.->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')

 -- url4 = string.gsub(url4, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


     local x = conn:load(url4)
    
    x = string.gsub(x, '\\u0026', '&')
    

   for id, id1, total2 in string.gmatch(x, 'method.-stream.-url.-http.-id_file=(.-)&token_movie=(.-)&#.-videos__item%-title.->(.-)<') do
 

  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
  

end
end
end
end     
      
 elseif args.q == 'paladins' then
    
local headers = {
    ["Host"] = "beta2.l-vid.online:888",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cache-Control"] = "no-cache"
}

local x = http.getz('http://beta2.l-vid.online:888/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d', headers)

      local slist = string.match(x, '"quality"(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":"(http.-)"') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
   url6 = string.gsub(url6, '\\u002B', '+')

--  url6 = string.gsub(url6, '^(.-)', 'http://beta2.l-vid.online:888') .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = url6})

end
end
 

 elseif args.q == 'spectre' then
 
 -- https://lam.akter-black.com/lite/spectre/video?id_file=911588&token_movie=a6ef0986c7558c5792c3ad19d43611&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
 
-- https://beta.mitsu.tv/api/lite/phantom?kinopoisk_id=386&title=чужой&year=1979
  
 -- http://31.129.234.181/lite/phantom/?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

  
  local url = 'https://beta.mitsu.tv/api/lite/phantom?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2

local x = conn:load(url)
  
  if x then
  
   
   for url1, total in string.gmatch(x, 'method.-url.-http.-(/lite.-)".-videos__item%-title.->(.-)<') do
  
   
        url1 = string.gsub(url1, '\\u0026', '&')

  
     local x = conn:load('https://beta.mitsu.tv/api' .. url1)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

 

   local slist = string.match(x, 'quality(.-)}')
      
      
   if slist then
   for  total1, url2 in string.gmatch(slist, '"(%d+p)".-http.-(/proxy.-m3u8)') do
  
   url2 = string.gsub(url2, '^(.-)', 'https://beta.mitsu.tv/api')   
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
      t['view'] = 'list'

 
  table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2, image = '#self/movie.png'})
 

      end 
    end
    end
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-http.-(/lite.-)".-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')



       local x = http.get('https://beta.mitsu.tv/api' .. url3)
       --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-(/lite.-)".->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')


     local x = http.get('https://beta.mitsu.tv/api' .. url4)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
    
    x = string.gsub(x, '\\u0026', '&')
    
--table.insert(t, {title = 'http://94.249.239.39' .. url4, mrl = 'http://94.249.239.39' .. url4})



  
  
   for id, id1, total2 in string.gmatch(x, 'method.-call.-url.-http.-id_file=(.-)&token_movie=(.-)".-videos__item%-title.->(.-)<') do
 
-- url5 = string.gsub(url5, '\\u0026', '&')
    
 --  url5 = string.gsub(url5, '\\u002B', '+')
 
   
  t['view'] = 'list'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=spectres&id=' .. id .. '&id1=' .. id1, image = '#self/movie.png'})
  
 -- table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=spectres&id=' .. id .. '&id1=' .. id1  .. '&id2=' .. id2 .. '&id3=' .. id3})
  


end
end
end
 end    
      
 elseif args.q == 'spectres' then
    
     
 --http://94.249.239.39/lite/mirage/video?t=34&s=1&e=1&token_movie=de9688cf5cb8bd7dd2876e9a61ed19
 
 
     local x = conn:load('https://beta.mitsu.tv/api/lite/phantom/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
     --.. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


--local x = http.get('http://94.249.239.39/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
--.. '&uid=bwygkgxn')

if x then


      local slist = string.match(x, 'quality.-{(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":.-http.-(/proxy.-m3u8)') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
  

    t['view'] = 'list'


table.insert(t, {title = '(' .. total3 .. ')', mrl = 'https://beta.mitsu.tv/api' .. url6, image = '#self/movie.png'})
--.. '&uid=bwygkgxn'})

end
end
end
 
 
 
 elseif args.q == 'phantom' then
  
 -- http://31.129.234.181/lite/phantom/?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0
  
 -- http://89.110.97.220:10254
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  

  
  local url = 'http://31.129.234.181/lite/phantom?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0'


local x = http.get(url)
  
  if x then
  
   
   for url1, total in string.gmatch(x, 'method.-url.-http.-(/lite.-)".-videos__item%-title.->(.-)<') do
  
   
        url1 = string.gsub(url1, '\\u0026', '&')

  
     local x = conn:load('http://31.129.234.181' .. url1 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

 

   local slist = string.match(x, 'quality(.-)}')
      
      
   if slist then
   for  total1, url2 in string.gmatch(slist, '"(%d+p)".-http.-(/proxy.-m3u8)') do
  
   url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')   
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
      t['view'] = 'list'

 
  table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2, image = '#self/movie.png'})
 

      end 
    end
    end
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-http.-(/lite.-)".-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')



       local x = http.get('http://31.129.234.181' .. url3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-(/lite.-)".->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')


     local x = http.get('http://31.129.234.181' .. url4 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
    
    x = string.gsub(x, '\\u0026', '&')
    
--table.insert(t, {title = 'http://94.249.239.39' .. url4, mrl = 'http://94.249.239.39' .. url4})



  
  
   for id, id1, total2 in string.gmatch(x, 'method.-call.-url.-http.-id_file=(.-)&token_movie=(.-)".-videos__item%-title.->(.-)<') do
 
-- url5 = string.gsub(url5, '\\u0026', '&')
    
 --  url5 = string.gsub(url5, '\\u002B', '+')
 
   
  t['view'] = 'list'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=phantoms&id=' .. id .. '&id1=' .. id1, image = '#self/movie.png'})
  
 -- table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladinnsss&id=' .. id .. '&id1=' .. id1  .. '&id2=' .. id2 .. '&id3=' .. id3})
  


end
end
end
 end    
      
 elseif args.q == 'phantoms' then
    
     
 --http://94.249.239.39/lite/mirage/video?t=34&s=1&e=1&token_movie=de9688cf5cb8bd7dd2876e9a61ed19
 
 
     local x = conn:load('http://31.129.234.181/lite/phantom/video?id_file=' .. args.id .. '&token_movie='  .. args.id1 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')


--local x = http.get('http://94.249.239.39/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)
--.. '&uid=bwygkgxn')

if x then


      local slist = string.match(x, 'quality.-{(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":.-http.-(/proxy.-m3u8)') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
  

    t['view'] = 'list'


table.insert(t, {title = '(' .. total3 .. ')', mrl = 'http://31.129.234.181' .. url6, image = '#self/movie.png'})
--.. '&uid=bwygkgxn'})

end
end
end
  
  
  
--https://kinogotv.cc/index.php?story=%D0%BE%D0%B1%D1%81%D0%B5%D1%81%D1%81%D0%B8%D1%8F+(2025)&do=search&subaction=search
 
 
 
 
 
 
 elseif args.q == 'atodo' then
 
-- t['view'] = 'list'
 
 
 local headers = {
    ["Host"] = "api.atodo.fun",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

 local x = conn:load('https://kinobd.net/api/player/search?q=' .. args.id3 .. '&type=kp_id&page=1')
 
 x = string.gsub(x, '"film"', '"movie"')
 x = string.gsub(x, '"serial"', '"tv"')

 
-- table.insert(t, {title = 'https://kinobd.net/api/player/search?q=' .. args.id3 .. '&type=kp_id&page=1', mrl = 'https://kinobd.net/api/player/search?q=' .. args.id3 .. '&type=kp_id&page=1'})
 
 local imdb, tmdb, media = string.match(x,'"imdb_id":"(.-)","tmdb_id":(.-),.-"type":"(movie)"') 
 
if media then
 
 local iframe = 'https://api.atodo.fun/api/source/xinu?id=' .. tmdb .. '&title=' .. urlencode(args.id1) .. '&original_title=&original_language=&imdb_id=' .. imdb .. '&year=' .. args.id2 .. '&type=' .. media
 
 
 
    local x = http.getz(iframe, headers)




x = string.gsub(x, '{"video_id":', '')
x = string.gsub(x, '}}', '}')


--table.insert(t, {title = iframe, mrl = iframe, image = '#self/movie.png'})


   
 local v = json.decode(x)

for _, m in ipairs(v['translations']) do


local id = '{"video_id":"' .. m['data'] .. '"}'

id = base64_encode(id)

local x = http.getz('https://api.atodo.fun/api/source/xinu?data=' .. id, headers)

if x then

x = string.gsub(x, '\\', '')

local qualities = string.match(x,'qualities.-{(.-)}')

if qualities then

for qual, url in string.gmatch(qualities,'"(.-)":"(.-)"') do
  
  if url then
  
  t['view'] = 'list'

 table.insert(t, {title = qual .. 'p ' ..  m['translation_name'], mrl = url, image = '#self/movie.png'})
 
 end
end
end
end
end
end


-- https://api.atodo.fun/api/source/xinu?data=eyJ2aWRlb19pZCI6IjE1NTY2MDQwMjkxOTI1In0%3D
 

 local x = conn:load('https://kinobd.net/api/player/search?q=' .. args.id3 .. '&type=kp_id&page=1')
 
 x = string.gsub(x, '"film"', '"movie"')
 x = string.gsub(x, '"serial"', '"tv"')

 
-- table.insert(t, {title = 'https://kinobd.net/api/player/search?q=' .. args.id3 .. '&type=kp_id&page=1', mrl = 'https://kinobd.net/api/player/search?q=' .. args.id3 .. '&type=kp_id&page=1'})
 
 local imdb, tmdb, media = string.match(x,'"imdb_id":"(.-)","tmdb_id":(.-),.-"type":"(tv)"') 
 
if media then
 
 local iframe = 'https://api.atodo.fun/api/source/xinu?id=' .. tmdb .. '&title=' .. urlencode(args.id1) .. '&original_title=&original_language=&imdb_id=' .. imdb .. '&year=' .. args.id2 .. '&type=' .. media
 
--table.insert(t, {title = iframe, mrl = iframe, image = '#self/movie.png'})
 
    local x = http.getz(iframe, headers)




x = string.gsub(x, '{"video_id":', '')
x = string.gsub(x, '}}', '}')


local v = json.decode(x)

for _, m in ipairs(v['translations']) do

for _, n in ipairs(m['seasons']) do

for _, b in ipairs(n['episodes']) do

local title = n['season_name'] .. ' ' .. b['episode_name'] .. ' ' .. m['translation_name']

t['view'] = 'list'

table.insert(t, {title = title, mrl = '#stream/q=atodos&id=' .. b['data'], image = '#self/movie.png'})

end
end
end
end

elseif args.q == 'atodos' then

local headers = {
    ["Host"] = "api.atodo.fun",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}

local id = '{"video_id":"' .. args.id .. '"}'

id = base64_encode(id)

local x = http.getz('https://api.atodo.fun/api/source/xinu?data=' .. id, headers)

if x then

 x = string.gsub(x, '\\', '')

local qualities = string.match(x,'qualities.-{(.-)}')

if qualities then

for qual, url in string.gmatch(qualities,'"(.-)":"(.-)"') do
  
  if url then
  
  t['view'] = 'list'
 
 table.insert(t, {title = qual .. 'p', mrl = url, image = '#self/movie.png'})
 
 end   
 end 
end
end
 
 
 
    
  
  elseif args.q == 'shizard' then

local headers = {
    ["Host"] = "bd.shizahd.pro",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


  
  local x = conn:load('https://kinogotv.cc/index.php?story=' .. urlencode(args.id1 .. ' ' .. '(' .. args.id2 .. ')') .. '&do=search&subaction=search') 
  
--    table.insert(t, {title = 'https://kinogotv.cc/index.php?story=' .. urlencode(args.id1 .. ' ' .. '(' .. args.id2 .. ')') .. '&do=search&subaction=search', mrl = 'https://kinogotv.cc/index.php?story=' .. urlencode(args.id1 .. ' ' .. '(' .. args.id2 .. ')') .. '&do=search&subaction=search'})
  
  
  local search = string.match(x,'<h2.-<a href="(http.-)"')
  
  if search then
 
 local x = conn:load(search)
 
 local iframe = string.match(x,'<li data%-src="http.-shizahd.-iframe/(.-)%?key')
 
 if iframe then
 
 local x = http.getz('https://bd.shizahd.pro/api/m/' .. iframe .. '/list.txt?key=c7068fd62304193a4163ad57', headers)
-- https://bd.shizahd.pro/api/m/0e8f855698ed975e/list.txt?key=c7068fd62304193a4163ad57
 
--  table.insert(t, {title = x, mrl = x})
  
  for total, slist, title in string.gmatch(x,'%{"title":"(.-)"%,%"file":"#2(.-)".-"title2":"(.-)"') do

slist = string.gsub(slist, '/shiza/', '')  
slist = string.gsub(slist, 'YWY1U', '')  

slist = string.gsub(slist, 'dWFKSVJs', '')  
slist = string.gsub(slist, 'EZR', '') 
slist = string.gsub(slist, 'SUl', '')  
slist = string.gsub(slist, 'SVd', '')  
slist = string.gsub(slist, 'kbjdx', '')  
slist = string.gsub(slist, 'OOEZB', '') 
slist = string.gsub(slist, 'S2N4UlN0', '')

slist = base64_decode(slist)
  
  local slist = slist .. ','
 -- table.insert(t, {title = slist, mrl = slist})
  
  
  for qual, url in string.gmatch(slist,'%[(.-)](http.-),') do
  
  t['view'] = 'list'
  
  table.insert(t, {title = '(' .. tolazy(qual) .. ') ' .. tolazy(title), mrl = url, image = '#self/movie.png'})
 end
end
end
end 
 
 if not search then
 
 local x = conn:load('https://kinogotv.cc/index.php?story=' .. urlencode(args.id1) .. '&do=search&subaction=search') 
 
 local search1 = string.match(x,'<h2.-<a href="(http.-)"')
  
  if search1 then
 
 local x = conn:load(search1)
 
 local iframe = string.match(x,'<li data%-src="http.-shizahd.-iframe/(.-)%?key')
 
 if iframe then
 
 local x = http.getz('https://bd.shizahd.pro/api/m/' .. iframe .. '/list.txt?key=c7068fd62304193a4163ad57', headers)
-- https://bd.shizahd.pro/api/m/0e8f855698ed975e/list.txt?key=c7068fd62304193a4163ad57
 
--table.insert(t, {title = x, mrl = x})
 


  x = string.gsub(x, '{"title":"Сезон', '')  
    x = string.gsub(x, 'серия","folder"', '')  
    
     x = string.gsub(x, '"folder":%[{"title"', '')  
  
  for total, slist, title in string.gmatch(x,'{"title":"(.-)"%,"file":"#2(.-)".-"title2":"(.-)"') do


--total = string.gsub(total, '","folder":[{"title":"', '')

slist = string.gsub(slist, '/shiza/', '')  
slist = string.gsub(slist, 'YWY1U', '')  

slist = string.gsub(slist, 'dWFKSVJs', '')  
slist = string.gsub(slist, 'EZR', '') 
slist = string.gsub(slist, 'SUl', '')  
slist = string.gsub(slist, 'SVd', '')  
slist = string.gsub(slist, 'kbjdx', '')  
slist = string.gsub(slist, 'OOEZB', '') 
slist = string.gsub(slist, 'S2N4UlN0', '')

slist = base64_decode(slist)
  
local slist = slist .. ','
--  table.insert(t, {title = slist, mrl = slist})
  
  
  for qual, url in string.gmatch(slist,'%[(.-)](http.-),') do
  
  t['view'] = 'list'
  
  table.insert(t, {title = '(' .. tolazy(qual) .. ') ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url, image = '#self/movie.png'})
 end
end
end
end 
end


     
    elseif args.q == 'videohub' then
    
 
 --https://bd.shizahd.pro/api/m/12766632761962/hls.m3u8?s=0&e=0&v=&key=c7068fd62304193a4163ad57&q=
 
-- https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=386
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 
 
 local slist = string.match(x, '"isSerial":false(.-)trailers')
 
 if slist then
 
 
 
 
for id, total, total1 in string.gmatch(slist, '"vkId":"(.-)".-"voiceStudio":"(.-)".-"voiceType":"(.-)"') do
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = '#stream/q=cdnvideohubm&id=' .. id})
 

 
 
	
 local headers = {
    ["Host"] = "plapi.cdnvideohub.com",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


     
 local x = http.getz('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, headers)
 
-- x = string.gsub(x, '\\u0026', '&')
  -- x = string.gsub(x, '\\u002B', '+')
  
 local slist = string.match(x, '"sources"(.-)}')
 

   slist = string.gsub(slist, 'mpegFullHdUrl', '1080p')
   
   slist = string.gsub(slist, 'mpegHighUrl', '720p')
   
slist = string.gsub(slist, 'mpegMediumUrl', '480p')

slist = string.gsub(slist, 'mpegLowUrl', '360p')
   
   
   
   
    
    if slist then
    
    for title, url in string.gmatch(slist, '"(1080p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url, image = '#self/movie.png'})
 end
 
 for title, url in string.gmatch(slist, '"(720p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url, image = '#self/movie.png'})
 end
 
for title, url in string.gmatch(slist, '"(480p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url, image = '#self/movie.png'})
 end
 
 
for title, url in string.gmatch(slist, '"(360p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = '(' .. title .. ') ' .. total .. ' ' .. total1, mrl = url, image = '#self/movie.png'})
 end
 
 end
 end
 end
 
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 local slist = string.match(x, '"isSerial":true(.-)trailers')
 
 if slist then
 
 

 for id, total, total1, season, episode in string.gmatch(slist, '"vkId":"(.-)".-"voiceStudio":"(.-)".-"voiceType":"(.-)".-"season":(.-),.-episode":(%d+)}') do
 
 t['view'] = 'list'
 
 table.insert(t, {title = 'Сезон :' .. season .. ' серия : ' .. episode  .. ' '.. total .. ' ' .. total1,  mrl = '#stream/q=videohubm&id=' .. id, image = '#self/movie.png'})
 end
 end
 


elseif args.q == 'videohubm' then
 
 local headers = {
    ["Host"] = "plapi.cdnvideohub.com",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
 


     
 local x = http.getz('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. args.id, headers)
 
-- x = string.gsub(x, '\\u0026', '&')
  -- x = string.gsub(x, '\\u002B', '+')
  
 local slist = string.match(x, '"sources"(.-)}')
 

   slist = string.gsub(slist, 'mpegFullHdUrl', '1080p')
   
   slist = string.gsub(slist, 'mpegHighUrl', '720p')
   
slist = string.gsub(slist, 'mpegMediumUrl', '480p')

slist = string.gsub(slist, 'mpegLowUrl', '360p')
   
   
   
   
    
    if slist then
    
    for title, url in string.gmatch(slist, '"(1080p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
 end
 
 for title, url in string.gmatch(slist, '"(720p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
 end
 
for title, url in string.gmatch(slist, '"(480p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
 end
 
 
for title, url in string.gmatch(slist, '"(360p)":"(http.-)"') do

  url = string.gsub(url, '\\u0026', '&')
    url = string.gsub(url, '\\u002B', '+')  
 
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
 end
 
 end
    

    
    
    
    
    
     
 elseif args.q == 'cdnvideohub' then
 
 
  local x = conn:load('https://lam.maxvol.pro/lite/cdnvideohub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)





for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url = string.gsub(url, '\\u0026', '&')
   url = string.gsub(url, '\\u002B', '+')
  
  local x = conn:load(url)
  
  
  for  url1 in string.gmatch(x, '"method":"play","url":".-(/proxy.-)"') do
  
  url1 = string.gsub(url1, '\\u0026', '&')
  url1 = string.gsub(url1, '\\u002B', '+')
  
  
url1 = string.gsub(url1, '^(.-)', 'https://lam.maxvol.pro')


t['view'] = 'simple'

  table.insert(t, {title = total, mrl = url1})

end
end
  
  
  for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')
    url5 = string.gsub(url5, '\\u002B', '+')
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end


    
    
    
    
      elseif args.q == 'alloha' then
 
 local data = 'http://kb-team.club/msx/msxFork.php?plugin=' .. base64_encode('plugin&bid=alloha-aloha&act=view&id=' .. args.id3) .. '&device=acace24b8434'
 
 --http://kb-team.club/msx/msxFork.php?plugin=cGx1Z2luJmJpZD1hbGxvaGEtYWxvaGEmYWN0PXZpZXcmaWQ9Mzg2&device=acace24b8434
 
 
 
    local x = conn:load(data)

--table.insert(t,{title = data,mrl = data})
    
    if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 
 
    local x = string.match(x,'"label":".-Просмотр"(.-)]') 
    
    for total, url in string.gmatch(x, '{"label":"(.-)".-"action".-content.-(http.-)"') do
  
  url = string.gsub(url, '\\', '') 
     
  
       local x = conn:load(url)
   
  -- table.insert(t,{title= url,mrl = url})
    
    
   
   for total1, url1 in string.gmatch(x, '"playerLabel":"(.-)".-video.-(http.-)"') do
   
   url1 = string.gsub(url1, '\\', '') 
   url1 = urldecode(url1)
   
  
  t['view'] = 'simple'
  
     table.insert(t,{title= tolazy(total) .. ' ' .. '(' .. total1 .. 'p)',mrl = url1})
    
    end
    end
end
    

local x = conn:load(data)

--table.insert(t,{title = data,mrl = data})



for title, url2 in string.gmatch(x,'{"label":"\\u0421.-(%d+)",.-action".-content.-(http.-)"') do
      
      url2 = string.gsub(url2, '\\', '')
  
  
      
   local x = conn:load(url2)
  
   
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')

--Выберите Сезон и Серию

--local x = string.match(x,'Выберите Сезон и Серию(.-)]') 

for title1, url3 in string.gmatch(x,'label":"(.-)".-"action".-content.-http.-plugin=(.-)&') do

   
url3 = string.gsub(url3, '\\', '')

t['view'] = 'simple'

table.insert(t, {title = 'сезон ' .. title .. ' ' .. tolazy(title1), mrl = '#stream/q=allohaz&id=' .. url3})

   end
  end
   
       
  elseif args.q == 'allohaz' then
 
   
  local x = conn:load('http://kb-team.club/msx/msxFork.php?view&plugin=' .. args.id .. '&device=acace24b8434')
  
--local x = conn:load(url3)
  
  for title2, url4 in string.gmatch(x,'"playerLabel":".-(%d+)".-video.-(http.-)",') do
  url4 = string.gsub(url4, '\\', '')
        
   local x = conn:load(url4)

 
    for url5 in string.gmatch(x,'url.-(http.-)"') do 
   
url5 = string.gsub(url5, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = ' серия ' .. title2, mrl = url5})

      end 
      end
    
    
    
    
  elseif args.q == 'alloha1' then
 
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=' .. args.id3 .. '&box_mac=acace24b8434')

    
    
  
    --   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
  
 -- table.insert(t,{title= url2 .. '&box_mac=acace24b8434',mrl = url2 .. '&box_mac=acace24b8434'})
  
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
       
--		table.insert(t,{title= url3,mrl = url3})
		table.insert(t,{title= 'alloha : ' ..  tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, id1, id2, id3, id4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA.-&stream=(.-)&season=(.-)&translate=(.-)&ta=(.-)]]') do
  
  
  t['view'] = 'simple'
  
    
    table.insert(t,{title= tolazy(total) .. ' ' .. tolazy(total1),mrl = '#stream/q=allohas&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
    
    end
    end

    



    

local x = conn:load('https://evkh.lol/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do


url4 = string.gsub(url4, '\\u002B', '+') 
     
      url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do

url5 = string.gsub(url5, '\\u002B', '+') 


      url5 = string.gsub(url5, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end




elseif args.q == 'allohas' then
    
    
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&stream=' .. args.id1 .. '&season=' .. args.id2 .. '&translate=' .. args.id3 .. '&ta=' .. args.id4 .. '&box_mac=acace24b8434')
  
  

  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
    t['view'] = 'simple'
				table.insert(t,{title= tolazy(total3) .. ' ' .. (total2),mrl = url5})
			end
          end
    
    



--http://78.40.199.67:10630/proxy/O3hSoc5CijVra2vCgfLNLB/PmRc+hqhKQgIOtzJlZSEN/U78WLhH33d7PTzmOoNEDwNxZZPw/cCL2DPw8vwZ+AtWC4MYaTNCqweYtblqcNLYD84RO+a9J2fQBoSstZ6c38UCxMq/hdkhO3eN06Bby6mor91qcMJXtoj7oQMvQb4LCGTqcuao/k4kE+O4e5YUbcSaRf6wbvMr+xw/pxPJLRjH3XBJVkyFY+94Tn8pggp22Td/Cka0vh7ih0qoejU+TjFZIFz8s/7BYVPvw5Tv8b+OOh3cAe7fQCrhzls/hqQ=.mp4
  
  
  
  
  
  
elseif args.q == 'cdnmovies' then
      
      local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?kinopoisk_id=' .. args.id3)


 local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630')
    
    

      local x = conn:load(url2)

     
      for id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-&kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=cdnmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})
  
  
  end
  end


 
     elseif args.q == 'cdnmoviess' then
 
 
     local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?' .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end





--https://lamp-movie.ru
    
    elseif args.q == 'vdbmovies' then
      
      local x = conn:load('https://lam.maxvol.pro/lite/vdbmovies?kinopoisk_id=' .. args.id3)


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    
    

      local x = conn:load(url2)

     
      for id4, id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"(http.-)&.-kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=vdbmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
  
  
  end
  end


 
     elseif args.q == 'vdbmoviess' then
 
 
     local x = conn:load(args.id4 .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


--https://lam.akter-black.com/lite/hdvb?imdb_id=tt29927663

--http://93.183.95.219:11378
--http://93.183.95.219:11378/proxy/de9ba7ff04c975beb30596bd47bb69d6.m3u8
   
 elseif args.q == 'hdvb' then
      
  t['view'] = 'list'
  
  
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

      for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"http.-(vid.-)(/movie.-)"') do
      
if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

-- entouaedon
 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Referer"] = "https://" .. origin .. "/",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)


local id, key = string.match(x, '"file":"%~(.-)".-"key":"(.-)"')

local href = string.match(x, '"href":"(.-)"')

if href then

id = string.gsub(id, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'

--https://vid1783002336.entouaedon.com/movie/d3d32b0257555ee658f1f6da50d11588/iframe

local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)

         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

--t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. title, mrl = url3, image = '#self/movie.png'})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

--t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. title, mrl = url3, image = '#self/movie.png'})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

--t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. title, mrl = url3, image = '#self/movie.png'})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

--t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. title, mrl = url3, image = '#self/movie.png'})

       end
       end
     
  end
  end
    
 end   
    
    
    
     
     local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
     
   --  table.insert(t, {title = 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3, mrl = '#stream/q=hdvbs&id1=' .. 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3})
     
     
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

     
     
   --  table.insert(t, {title = x, mrl = '#stream/q=hdvbs&id1=' .. x})
     
   
    --  for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') do
      
      local origin, url = string.match(x, '"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') 

if origin then 

origin = string.gsub(origin, '\\', '')
     
if url then

url = string.gsub(url, '\\', '')
     

--table.insert(t, {title = 'https://' .. origin .. url, mrl = url})




url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Referer"] = "https://" .. origin .. "/",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=177873309816283985; _ym_d=1778733098; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)

x = string.gsub(x, '\\', '')

local id, key = string.match(x, '"file":"(.-)".-"key":"(.-)"')

if id then
if key then

local href = string.match(x, '"href":"(.-)"')

if href then

id = string.gsub(id, '^(.-)', 'https://vid11.' .. href)

local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)


--url = url_for(x)
--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')







for id1, text in string.gmatch(x, '"file":"%~(.-)".-"text2":"(.-)"') do

--local text = string.match(x, '"file".-"text2":"(.-)"')


id1 = string.gsub(id1, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'


local x = http.postz(id1, headers1)



for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'list'
       table.insert(t, {title = '(360p) ' .. text, mrl = url3, image = '#self/movie.png'})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'list'
       table.insert(t, {title = '(480p) ' .. text, mrl = url3, image = '#self/movie.png'})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'list'
       table.insert(t, {title = '(720p) ' .. text, mrl = url3, image = '#self/movie.png'})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'list'
       table.insert(t, {title = '(1080p) ' .. text, mrl = url3, image = '#self/movie.png'})

       end
     
end
     
end
end
end
end
 end
 
     

elseif args.q == 'hdvbf' then
      
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

      for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"http.-(vid.-)(/movie.-)"') do
      
if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

-- https://lam.maxvol.pro/proxy/5ae371e16655f3ef2bae8d4a28d56b8d.m3u8

-- http://78.40.195.218:9118/lite/hdvb/serial?iframe=https%3a%2f%2fvid1733431681.entouaedon.com%2fserial%2f4e6eb80724f81b2fc89bf9c3f8507021e1f9a9dba4c9d493288c81a9f86943a3%2fiframe&t=BaibaKo&s=1&e=1
 
      url = string.gsub(url, '^(.-)', 'https://lam.maxvol.pro/lite/hdvb/video?iframe=' .. 'https://' .. origin)

--table.insert(t, {title = url, mrl = url})

local x = http.getz(url)


x = string.gsub(x, '\\', '')


local url2 = string.match(x,'method.-"play".-"url":"http.-(/proxy.-m3u8)"')
   
 
  
   local x = conn:load('https://lam.maxvol.pro' .. url2)

 
   x = string.gsub(x, '\\', '')
   

 
         for url3 in string.gmatch(x, 'RESOLUTION.-640.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'list'
       table.insert(t, {title = '(360p) ' .. title, mrl = url3, image = '#self/movie.png'})

       end
       
         for url3 in string.gmatch(x, 'RESOLUTION.-858.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')

t['view'] = 'list'
       table.insert(t, {title = '(480p) ' .. title, mrl = url3, image = '#self/movie.png'})

      
       end
        for url3 in string.gmatch(x, 'RESOLUTION.-1280.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
		 
t['view'] = 'list'
       table.insert(t, {title = '(720p) ' .. title, mrl = url3, image = '#self/movie.png'})


       end
       
for url3 in string.gmatch(x, 'RESOLUTION.-1920.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'list'
       table.insert(t, {title = '(1080p) ' .. title, mrl = url3, image = '#self/movie.png'})


       end
       end
     
  end
  end
    
    
    
    
    
     
     local x = conn:load('http://78.40.195.218:9118/lite/hdvb?kinopoisk_id=' .. args.id3)
     
     
  --   table.insert(t, {title = url, mrl = '#stream/q=hdvbs&id1=' .. url})
     
  -- table.insert(t, {title = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3, mrl = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3})


for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url2 = string.gsub(url2, '\\u0026', '&')
url2 = string.gsub(url2, '\\u002B', '+')


     local x = conn:load('http://78.40.195.218:9118' .. url2)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     
     local x = conn:load('http://78.40.195.218:9118' .. url4)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"http.-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do




     url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
    
       t['view'] = 'list'

    table.insert(t, {title = total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = 'http://78.40.195.218:9118' .. url6, image = '#self/movie.png'})
    end
end
end




    
        
    elseif args.q == 'turbo2' then
    

local headers = {["sec-fetch-dest"] = "iframe",["sec-fetch-mode"] = "navigate",
    ["sec-fetch-site"] = "cross-site",
    ["referer"] = "https://92d73433.obrut.show/"}

--https://92d73433.obrut.show/embed/MjM/content/1MDNwETM

local url = 'https://cors.nb557.workers.dev:8443/https://92d73433.obrut.show/embed/MjM/?kinopoisk_id=' .. args.id3



--local url = 'https://cors.nb557.workers.dev:8443/https://30bf3790.obrut.show/embed/AN/content/czN2YDO'


local x = conn:load(url)


local data = string.match(x, 'new.-Player.-(eyJsYW5.-\"+)')


    data = data:gsub('//[^=]+=', '') 
    -- remove '//ci9yL3I='-like parts
    local padding = 4 - (#data % 4)
    if padding < 4 then
        data = data .. string.rep('=', padding)
    end
   data = base64.decode(data)
 --  data = json.decode(data)

--  local decoded = base64.decode(data)
  --  local data_json = json.decode(decoded)


--local json = Encoding.UTF8.GetString(Base64.decode(base64))
 
-- table.insert(t, {title = base64, mrl = base64})
  
 --return data
--end



local x = conn:load(data)

data = string.gsub(data, '\\u0410', 'А')
      data = string.gsub(data, '\\u0430', 'а')
       
       data = string.gsub(data, '\\u0411', 'Б')
       data = string.gsub(data, '\\u0431', 'б')  
       data = string.gsub(data, '\\u0412', 'В')
      data = string.gsub(data, '\\u0432', 'в')
       data = string.gsub(data, '\\u0413', 'Г')
       data = string.gsub(data, '\\u0433', 'г')  
      data = string.gsub(data, '\\u0414', 'Д')
      data = string.gsub(data, '\\u0434', 'д')
       data = string.gsub(data, '\\u0415', 'Е')
       data = string.gsub(data, '\\u0435', 'е')  
      data = string.gsub(data, '\\u0401', 'Ё')
      data = string.gsub(data, '\\u0451', 'ё')
       data = string.gsub(data, '\\u0416', 'Ж')
       data = string.gsub(data, '\\u0436', 'ж')  
       data = string.gsub(data, '\\u0417', 'З')
      data = string.gsub(data, '\\u0437', 'з')
       data = string.gsub(data, '\\u0418', 'И')
       data = string.gsub(data, '\\u0438', 'и')  
       data = string.gsub(data, '\\u0419', 'Й')
      data = string.gsub(data, '\\u0439', 'й')
       data = string.gsub(data, '\\u041a', 'К')
       data = string.gsub(data, '\\u043a', 'к')  
       data = string.gsub(data, '\\u041b', 'Л')
       data = string.gsub(data, '\\u043b', 'л')
       data = string.gsub(data, '\\u041c', 'М')
       data = string.gsub(data, '\\u043c', 'м')
       data = string.gsub(data, '\\u041d', 'Н')
       data = string.gsub(data, '\\u043d', 'н')
       data = string.gsub(data, '\\u041e', 'О')
       data = string.gsub(data, '\\u043e', 'о')
       data = string.gsub(data, '\\u041f', 'П')
       data = string.gsub(data, '\\u043f', 'п')
       data = string.gsub(data, '\\u0420', 'Р')
       data = string.gsub(data, '\\u0440', 'р')
       data = string.gsub(data, '\\u0421', 'С')
       data = string.gsub(data, '\\u0441', 'с')
       data = string.gsub(data, '\\u0422', 'Т')
       data = string.gsub(data, '\\u0442', 'т')
       data = string.gsub(data, '\\u0423', 'У')
       data = string.gsub(data, '\\u0443', 'у')
       data = string.gsub(data, '\\u0424', 'Ф')
        data = string.gsub(data, '\\u0444', 'ф')
        data = string.gsub(data, '\\u0425', 'Х')
        data = string.gsub(data, '\\u0445', 'х')
        data = string.gsub(data, '\\u0426', 'Ц')
        data = string.gsub(data, '\\u0446', 'ц')
        data = string.gsub(data, '\\u0427', 'Ч')
        data = string.gsub(data, '\\u0447', 'ч')
        data = string.gsub(data, '\\u0428', 'Ш')
        data = string.gsub(data, '\\u0448', 'ш')
        data = string.gsub(data, '\\u0429', 'Щ')
        data = string.gsub(data, '\\u0449', 'щ')
        data = string.gsub(data, '\\u042a', 'Ъ')
        data = string.gsub(data, '\\u044a', 'ъ')
        data = string.gsub(data, '\\u042b', 'Ы')
        data = string.gsub(data, '\\u044b', 'ы')
        data = string.gsub(data, '\\u042c', 'Ь')
        data = string.gsub(data, '\\u044c', 'ь')
        data = string.gsub(data, '\\u042d', 'Э')
        data = string.gsub(data, '\\u044d', 'э')
        data = string.gsub(data, '\\u042e', 'Ю')
        data = string.gsub(data, '\\u044e', 'ю')
        data = string.gsub(data, '\\u042f', 'Я')
        data = string.gsub(data, '\\u044f', 'я')
        data = string.gsub(data, '\\u00ab', '<<')
        data = string.gsub(data, '\\u00bb', '>>')
        data = string.gsub(data, '\\u2014', '-')
	
 
 data = string.gsub(data, '\\', '')

--local x = conn:load(data)



    
     
     for title, title1, args in string.gmatch(data, '{"title":"(.-)".-%[(1080p)](http.-),') do
     

       local link = 'https://lampa.oksibutch.ru/lite/zetflix/manifest.m3u8?link=' .. http.urlencode(args)
       
-- local link = 'https://lam.maxvol.pro/lite/videodb/manifest.m3u8?link=' .. HttpUtility.UrlEncode(args) .. args
 
--url = url_for(x)
 
 
 table.insert(t, {title = link})
 end
--end
-- end
-- end
 
 
 
 
 
 --  for title, title1, url1 in string.gmatch(data, '{"title":"(.-)".-%[(1080p)](http.-),') do
 
 --url1 = string.gsub(url1, '\\', '')
   
 --  link=http.urlencode(url1)
   
   

   
   
   
 --  local x = conn:load('https://cors.nb557.workers.dev:8443/' .. url1,headers1,params)
 
-- url = url_for('GET', {file = x})
 
 
   
  -- for url2 in string.gmatch(x, '(http.-m3u8)') do
   
    
--http://lam.maxvol.pro/lite/videodb/manifest.m3u8?link=https://cdn-30bf3790.obrut.show/stream/AN/MHc0RHa/QbvNmLuR2YyVGc1RmclBXdz5ie/gTdz0mLzxGavMTM1AjMwYjMwIjO5IzNxMTYjVGOmNDOmRzY4ITMkZGZiVjYhFWO3MmYwU2L4MjNzcDOkBzMjhTZkdTMkZWZ2ATZkNDO5AzM0IzNkR2N2YjZhJGMy8ycllmdv12L
  

  
    
 --  table.insert(t, {title = 'http://lam.maxvol.pro/lite/videodb/manifest.m3u8?link=' .. link, mrl = 'http://lam.maxvol.pro/lite/videodb/manifest.m3u8?link=' .. link})
    
 --  end
  --  end
 
 
 
 elseif args.q == 'turbo1' then

--https://proxy4.rte.net.ru/http://beta2.l-vid.online:888/lite/videodb?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn
 
 
 
 local x = http.get('https://proxy4.rte.net.ru/http://beta.l-vid.online/lite/videodb?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2  .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   

   
 x = string.gsub(x, '\\u0026', '&')
 

 
   for url, total in string.gmatch(x, 'videos__item videos__movie.-stream.-http.-(/lite.-)&.-videos__item%-title.->(.-)<') do
  
 
      local x = http.get('https://proxy4.rte.net.ru/http://beta.l-vid.online' .. url .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
  
  
   local slist = string.match(x, 'qualit.-{(.-)}')
   
   for  total1, url2 in string.gmatch(slist, '"(.-)":"http.-(/lite.-)"') do
      
    url2 = string.gsub(url2, '^(.-)', 'https://proxy4.rte.net.ru/http://beta2.l-vid.online:888')  .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'

   



--http://178.20.46.40:12600/lite/videodb/manifest.m3u8?
      
  --   total1 = string.gsub(total1, ':{"', '') 
      
       t['view'] = 'simple'

--table.insert(t, {title = url2, mrl = url2})




    table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
        for url3, total1  in string.gmatch(x, 'videos__item videos__season.-method.-link.-url.-http.-(/lite.-)&#.-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')

--table.insert(t, {title = 'http://beta.l-vid.online' .. url3 .. '&uid=bwygkgxn', mrl = url3})




      local x = http.getz('http://beta.l-vid.online' .. url3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

      for url4, total2  in string.gmatch(x, 'videos__button.-method.-link.-url.-http.-(/lite.-)&#.->(.-)<') do

url4 = string.gsub(url4, '\\u0026', '&')



     local x = http.getz('http://beta.l-vid.online' .. url4 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')


x = string.gsub(x, '\\u0026', '&')

      for url5, total3  in string.gmatch(x, 'videos__item videos__movie.-method.-stream.-http.-/lite.-http.-(http.-)%%22.-videos__item%-title.->(.-серия)<') do

     url5 = string.gsub(url5, '^(.-)', 'http://beta2.l-vid.online:888/lite/videodb/manifest.mp4?link=')  .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'
    

      t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' -'  .. total3 .. tolazy(total2), mrl = url5})

   
    end
end
end



 
 
 
 elseif args.q == 'kinobadi' then
 
 local x = http.get('https://kinobadi.in/player/player.php?kp_id=' .. args.id3)
 
 --table.insert(t, {title = 'https://kinobadi.in/player/player.php?kp_id=' .. args.id3, mrl = 'https://kinobadi.in/player/player.php?kp_id=' .. args.id3})
 

 x = string.gsub(x, '&quot;', '"')
 
 
 local movie = string.match(x,'<div class=.-dl%-player.-data%-sources.-movie.-voices.-:%[(.-)]')
 
-- table.insert(t, {title = movie, mrl = movie})
 
 if movie then
 
 --movie = urldecode(movie)
 
 for name, qual in string.gmatch(movie,'{"name":"(.-)".-"qualities":{(.-)}') do
 
 for total, url in string.gmatch(qual,'"(%d+p)":"(.-)"') do
 
 t['view'] = 'list'
 
 table.insert(t, {title = total .. ' ' .. name, mrl = url, image = '#self/movie.png'})

 end
 
 
  for url1 in string.gmatch(qual,'"240p":"(.-)"') do
 
 url1 = string.gsub(url1, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 t['view'] = 'list'

 
  table.insert(t, {title = '1080p' .. ' ' .. name, mrl = url1, image = '#self/movie.png'})

      end 
 end
 end
 
 
 
 local series = string.match(x,'<div class=.-dl%-player.-data%-sources.-series.-"seasons":%[(.-)]}"')


if series then

--table.insert(t, {title = series, mrl = series})
 
 for season, voices in string.gmatch(series,'{"num":(.-),"voices":%[(.-)]}]') do
 
 --table.insert(t, {title = voices, mrl = voices})
 
 
 for name, episodes in string.gmatch(voices,'{"name":"(.-)","episodes":%[(.-)]') do
 
 --table.insert(t, {title = voices, mrl = voices})
 
 
 
 for episode, qual in string.gmatch(episodes,'{"num":(.-),"qualities":{(.-)}') do

for total, url in string.gmatch(qual,'"(%d+p)":"(.-)"') do
 

 
 t['view'] = 'list'

 
 table.insert(t, {title = '(' .. total .. ')' .. ' Сезон: ' .. season .. ' серия: ' .. episode .. ' ' .. name, mrl = url, image = '#self/movie.png'})

      end 
end
end
end
end 
 
 
 
 
 
 
    
elseif args.q == 'turbo' then

--https://proxy4.rte.net.ru/


--https://go.zet-flix.online/iplayer/player.php?id=JTJGaXBsYXllciUyRnZpZGVvZGIucGhwJTNGa3AlM0QzODY=

--https://a7c5ea7c.obrut.show/embed/1EjM/kinopoisk/386/

local url = 'https://54243ba5.obrut.show/embed/AO/kinopoisk/' .. args.id3 .. '/'


local headers = {
    ["Host"] = "54243ba5.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cookie"] = "wd_trust=AAAAAGnw-KMyM0U0OTMyRQFSZP9Ll3IMgg; XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}







local x = http.getz(url, headers)




--url = url_for(x)

--url = urldecode(url)


x = string.gsub(x, '//ci9yL3I=', '')
 
x = string.gsub(x, '//by9vL28=', '')
 
x = string.gsub(x, '//dC90L3Q=', '')
 
x = string.gsub(x, '//Yi9iL2I=', '')

x = string.gsub(x, '//dS91L3U=', '')
	
					


local slist = string.match(x, 'new.-Player.-(eyJsYW5.-\"+)')
 
 
 if slist then
 
 slist = base64_decode(slist)
 
-- url = url_for(slist)

-- table.insert(t, {title = url, mrl = '#stream/q=turbovideo&id=' .. url})
 
 
 
slist = string.gsub(slist, '\\u0410', 'А')
      slist = string.gsub(slist, '\\u0430', 'а')
      slist = string.gsub(slist, '\\u0411', 'Б')
       slist = string.gsub(slist, '\\u0431', 'б')
       slist = string.gsub(slist, '\\u0412', 'В')
      slist = string.gsub(slist, '\\u0432', 'в')
       slist = string.gsub(slist, '\\u0413', 'Г')
       slist = string.gsub(slist, '\\u0433', 'г')      slist = string.gsub(slist, '\\u0414', 'Д')
      slist = string.gsub(slist, '\\u0434', 'д')
       slist = string.gsub(slist, '\\u0415', 'Е')
       slist = string.gsub(slist, '\\u0435', 'е')      slist = string.gsub(slist, '\\u0401', 'Ё')
      slist = string.gsub(slist, '\\u0451', 'ё')
       slist = string.gsub(slist, '\\u0416', 'Ж')
       slist = string.gsub(slist, '\\u0436', 'ж')
       slist = string.gsub(slist, '\\u0417', 'З')
      slist = string.gsub(slist, '\\u0437', 'з')
       slist = string.gsub(slist, '\\u0418', 'И')
       slist = string.gsub(slist, '\\u0438', 'и')     slist = string.gsub(slist, '\\u0419', 'Й')
      slist = string.gsub(slist, '\\u0439', 'й')
       slist = string.gsub(slist, '\\u041a', 'К')
       slist = string.gsub(slist, '\\u043a', 'к')
       slist = string.gsub(slist, '\\u041b', 'Л')
       slist = string.gsub(slist, '\\u043b', 'л')
       slist = string.gsub(slist, '\\u041c', 'М')
       slist = string.gsub(slist, '\\u043c', 'м')
       slist = string.gsub(slist, '\\u041d', 'Н')
       slist = string.gsub(slist, '\\u043d', 'н')
       slist = string.gsub(slist, '\\u041e', 'О')
       slist = string.gsub(slist, '\\u043e', 'о')
       slist = string.gsub(slist, '\\u041f', 'П')
       slist = string.gsub(slist, '\\u043f', 'п')
    slist = string.gsub(slist, '\\u0420', 'Р')
    slist = string.gsub(slist, '\\u0440', 'р')
    slist = string.gsub(slist, '\\u0421', 'С')
    slist = string.gsub(slist, '\\u0441', 'с')
    slist = string.gsub(slist, '\\u0422', 'Т')
    slist = string.gsub(slist, '\\u0442', 'т')
    slist = string.gsub(slist, '\\u0423', 'У')
    slist = string.gsub(slist, '\\u0443', 'у')
    slist = string.gsub(slist, '\\u0424', 'Ф')
    slist = string.gsub(slist, '\\u0444', 'ф')
    slist = string.gsub(slist, '\\u0425', 'Х')
    slist = string.gsub(slist, '\\u0445', 'х')
    slist = string.gsub(slist, '\\u0426', 'Ц')
    slist = string.gsub(slist, '\\u0446', 'ц')
    slist = string.gsub(slist, '\\u0427', 'Ч')
    slist = string.gsub(slist, '\\u0447', 'ч')
    slist = string.gsub(slist, '\\u0428', 'Ш')
    slist = string.gsub(slist, '\\u0448', 'ш')
    slist = string.gsub(slist, '\\u0429', 'Щ')
    slist = string.gsub(slist, '\\u0449', 'щ')
    slist = string.gsub(slist, '\\u042a', 'Ъ')
    slist = string.gsub(slist, '\\u044a', 'ъ')
    slist = string.gsub(slist, '\\u042b', 'Ы')
    slist = string.gsub(slist, '\\u044b', 'ы')
    slist = string.gsub(slist, '\\u042c', 'Ь')
    slist = string.gsub(slist, '\\u044c', 'ь')
    slist = string.gsub(slist, '\\u042d', 'Э')
    slist = string.gsub(slist, '\\u044d', 'э')
    slist = string.gsub(slist, '\\u042e', 'Ю')
    slist = string.gsub(slist, '\\u044e', 'ю')
    slist = string.gsub(slist, '\\u042f', 'Я')
    slist = string.gsub(slist, '\\u044f', 'я')
    slist = string.gsub(slist, '\\u00ab', '<<')
    slist = string.gsub(slist, '\\u00bb', '>>')
    slist = string.gsub(slist, '\\u2014', '-')
 
 
 
 for title, title1, qual in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-"file":"(.-)"') do

for total, url1 in string.gmatch(qual, '%[(%d+p)](http.-),') do


 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

title = string.gsub(title, 'Season [%d+]', '')
title = string.gsub(title, 'Episode [%d+]', '')



title = string.gsub(title, '","folder":%[{"title":"', '')


 t['view'] = 'list'
 
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=turbovideo&id=' .. url1, image = '#self/movie.png'})
 
 end
 end 
 end

elseif args.q == 'turbovideo' then
  
  local headers = {
    ["Host"] = "54243ba5.obrut.show",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Referer"] = "url",
    ["Cookie"] = "wd_trust=AAAAAGnw-KMyM0U0OTMyRQFSZP9Ll3IMgg; XSRF-TOKEN=eyJpdiI6IjBqTU92T3VEakNQN0d6b1J1ZksvQmc9PSIsInZhbHVlIjoiSGIvdkpzL1BhYkF0QWRyZXU2aE53ZFY1Y1JLUTNmY2tyQVFFd01QMFNQaFdEaUQzNmYvWUxoRU43VW5wM24wVmt4MXpFSGhzRjI4b1ptWWhKbjFWYkJ1SjJnTTJSRlhBdC94c1hpTEVhcmdBTnVOb2cxQjVKdVJLcUd3UzVCNDQiLCJtYWMiOiJkNzFlMjU3MzYyOGE4NGFlZThmOGQ1YzM4MTgxODg5MWEyNDM5NDBiZWI4MmNlOWZlZGZhODVmZTExMDNmYTU0IiwidGFnIjoiIn0%3D; turbo_player_session=eyJpdiI6ImRWa0pVZUZVYy9lU2tyZ01VelRZNmc9PSIsInZhbHVlIjoiam1hU3dmU1hXTllzb053NkpXbjRxWmNHRGhTUEszNFBQb0JvOWZEYURqRWVIanRVOTRNVlFvTk5NTU5rRFFMR1BmQzB4L24yazlOU3A1NndUMmwzWG8vaHRiVDk1NTEvTUY2bmRxTlRyaXZMaldqNTFNSXhhcjVFYWpyT2Q3SVEiLCJtYWMiOiJmNDBmOTkzODdjYTVlMDBiZjI4ZDg4MWRjMzRiYmM4YWQ5MWYwZGFjOGU4NDVlNzM3NTE5NGY3YWFhYmM2ZWRlIiwidGFnIjoiIn0%3D",
    ["Cache-Control"] = "no-cache"
}
  
  
  
 local x = http.getz(args.id, headers)
 
 --if x then
 

local url = string.match(x,'<meta http%-equiv="refresh".-url=.-(http.-m3u8)')
  
 -- for url in string.gmatch(x,'<meta http%-equiv="refresh".-url=.-(http.-m3u8)') do
  
-- table.insert(t, {title = 'Смотреть', mrl = url})
  if url then
    print(url)
    return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}
 end
 
 
 elseif args.q == 'videodb1' then
  
--https://proxy4.rte.net.ru/

--http://31.129.234.181/lite/zetflixdb?id=1318447&imdb_id=tt16431404&kinopoisk_id=6553387&title=На вершине&original_title=Apex&serial=0&original_language=en&year=2026&source=cub&clarification=0&similar=false&rchtype=web&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0





local headers = {
    ["Host"] = "31.129.234.181",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/plain, */*; q=0.01",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br"

}


    local x = http.getz('https://proxy4.rte.net.ru/http://31.129.234.181/lite/zetflixdb?kinopoisk_id=' .. args.id3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
   

   
   for  url2, total in string.gmatch(x, '"method".-"url":.-(http.-)".-class="videos__item%-title">(.-)<') do
 

      url2 = string.gsub(url2, '\\u0026', '&') 
     
     
      t['view'] = 'list'
    

 
    table.insert(t, {title = tolazy(total), mrl = url2, image = '#self/movie.png'})

      end 
    

      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
      
    
      url2 = string.gsub(url2, '\\u0026', '&') 
 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

    
      url3 = string.gsub(url3, '\\u0026', '&') 

       local x = http.getz(url3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')

   
      for  url4, total2 in string.gmatch(x, '"method":"play".-"url".-(http.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    
      url4 = string.gsub(url4, '\\u0026', '&') 

      t['view'] = 'list'
 
 
   --  table.insert(t, {title = url4, mrl = url4})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4, image = '#self/movie.png'})

     end
     end
    end
  
  

    
    elseif args.q == 'videodb' then
  
 -- http://31.129.234.181/lite/videodb?href=https%3a%2f%2fkinogo.media%2f37869-chuzhoj.html
  
  
--  http://78.40.195.218:9118/lite/videodb?rjson=False&href=https%3a%2f%2fkinogo.media%2f37869-chuzhoj.html

--http://78.40.195.218:9118/lite/videodb?title=чужой&year=1979

--http://78.40.195.218:9118/lite/videodb?rjson=False&href=https%3a%2f%2fiframe.cloud%2fiframe%2f386

 
 -- local page = tonumber(args.page or 1)
  
--  local url = 'https://apn-latest.onrender.com/https://kinogo.media/search/' .. urlencode(args.id1) .. '/page/' .. tostring(page) .. '/'
	
	--	local x = conn:load(url)
		
	
		
       -- for image, title, id, total in string.gmatch(x, '<div class="short".-<img src=.-(/uploads.-)".-alt="(.-)".-data%-href="(http.-)".-class="sd%-line".-Год выхода:.->(.-)<') do
      


--id  = string.gsub(id, '^(.-)', 'http://78.40.195.218:9118/lite/videodb?rjson=False&href=')
--image  = string.gsub(image, '^(.-)', 'https://apn-latest.onrender.com/https://kinogo.media')

		--	table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=videodbz&id=' .. id, image = image})
	--	end
    
    
 --   local url = '#folder/page=' .. tostring(page + 1) .. '&q=videodb&id1=' .. args.id1
		--table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
    
    
   -- 	local url = '#folder/q=search&keyword=' .. urlencode(args.id1) .. '&page=' .. tostring(page + 1)
--		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
		
  
  
--  elseif args.q == 'videodbz' then
  
  
 local x = conn:load('https://x.vmestefilms.online/api/kinopoisk/?kp_id=' .. args.id3)
  
  
  
     local total = string.match(x, '"slug":.-"(.-)",')
  
  if total then
  
  local id = string.match(x, '"TURBO".-"id": (.-)}')

if id then
  
  
  
    local x = conn:load('http://78.40.195.218:9118/lite/videodb?rjson=False&href=https://x.vmestefilms.online/room/' .. id .. '/' .. total .. '/')
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-http.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://78.40.195.218:9118')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
    url2 = string.gsub(url2, '^(.-)', 'http://78.40.195.218:9118') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://78.40.195.218:9118') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-http.-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://78.40.195.218:9118')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end

end
end

--http://api.vokino.pro/v2/search?name=чужой&year=1979






  
elseif args.q == 'zetflixdb' then
  
  
--http://31.129.234.181:80/lite/zetflix?kinopoisk_id=386&title=чужой&year=1979&uid=guest
 
-- https://beta.mitsu.tv/api/lite/phantom?kinopoisk_id=386&title=чужой&year=1979
 
    local x = http.get('https://beta.mitsu.tv/api/lite/zetflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
    
   for quality, title in string.gmatch(x, 'method.-url.-"quality":{(.-)}.-videos__item%-title.->(.-)<') do

    for total, url in string.gmatch(quality, '"(%d+p)":"http.-(/proxy.-)"') do


 
 --url = string.gsub(url, '.m3u8', '')
 
    url = string.gsub(url, '\\u0026', '')
    url = string.gsub(url, '^(.-)', 'https://beta.mitsu.tv/api')
    --'&uid=guest'
     
      t['view'] = 'list'
    
    
   -- table.insert(t, {title = url, mrl = url})
    
    table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = url, image = '#self/movie.png'})
     end 
 
 end  
    
   
    
    

local x = http.get('https://beta.mitsu.tv/api/lite/zetflix?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   


      for  url2, total in string.gmatch(x, 'class="videos__item videos__season.-"method".-"link".-"url".-(http.-)".-class="videos__item%-title videos__season%-title">(.-)<') do
 
url2 = string.gsub(url2, '\\u0026', '&') 
 url2 = string.gsub(url2, '\\u002B', '+') 
 
 

       local x = http.get(url2)
  
     x = string.gsub(x, '\\u0026', '&') 
x = string.gsub(x, '\\u002B', '+') 
   
--   table.insert(t, {title = url2, mrl = url2})  




   for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do


url3 = string.gsub(url3, '\\u0026', '&') 
url3 = string.gsub(url3, '\\u002B', '+') 


       local x = http.get(url3)

   x = string.gsub(x, '\\u0026', '&') 
x = string.gsub(x, '\\u002B', '+') 
     
  --  table.insert(t, {title = url3, mrl = url3})

      for id, id1, id2, id3, total2 in string.gmatch(x, 'class="videos__item videos__movie.-"method".-"call".-"url".-http.-kinopoisk_id=(.-)&.-&s=(.-)&e=(.-)&t=(.-)".-class="videos__item%-title.->(.-)<') do
  

      t['view'] = 'list'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = '#stream/q=zetflixdbs&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = '#self/movie.png'})

     end
     end
    end

elseif args.q == 'zetflixdbs' then

local x = http.getz('https://beta.mitsu.tv/api/lite/zetflix/video?serial=1&kinopoisk_id=' .. args.id .. '&s=' .. args.id1 .. '&e=' .. args.id2 .. '&t=' .. urlencode(args.id3))



local slist = string.match(x, 'quality(.-)}')
      
if slist then

   for  total, url2 in string.gmatch(slist, '"(%d+p)":"http.-(/proxy.-)"') do

  url2 = string.gsub(url2, '^(.-)', 'https://beta.mitsu.tv/api') 
--total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'list'

   table.insert(t, {title = tolazy(total), mrl = url2, image = '#self/movie.png'})

      end 
    end






elseif args.q == 'vcdn' then

local x = conn:load('http://api.vokino.pro/v2/search?name=' .. urlencode(args.id1) .. '&year=' .. args.id2) 

local id = string.match(x, '"channels".-"details".-"id":"(.-)"') 


--http://api.vokino.pro/v2/online/videocdn/6593f8688914c04deae97e7c?token=windows_68988745062e9987f8b5b8502917b37d_1264491

local x = conn:load('http://api.vokino.pro/v2/online/videocdn/' .. id .. '?token=windows_68988745062e9987f8b5b8502917b37d_1264491')


for total, url in string.gmatch(x, '"title":"(.-)".-"stream_url":"(.-)"') do
  
      t['view'] = 'simple'
 
 
    table.insert(t, {title = total, mrl = url})
 
     end
     
   elseif args.q == 'videocdn' then
 
 


 --https://cors.fx666.workers.dev:8443/http://kb-team.club/msx/kinozal/videocdn.php?act=watch&vid=386&device=acace24b8434
 
 
 
 local x = conn:load('http://kb-team.club/msx/kinozal/videocdn.php?act=watch&vid=' .. args.id3 .. '&device=') 


if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 
 

 
 for title, url1 in string.gmatch(x,'"playerLabel":"(.-)".-video.-(http.-)"') do



url1 = string.gsub(url1, '\\', '')

 t['view'] = 'list'

   table.insert(t, {title = title, mrl = url1, image = '#self/movie.png'})

      end 
 
      
      
     for url2 in string.gmatch(x,'"label".-"action":"panel.-(http.-)"') do
      
      url2 = string.gsub(url2, '\\', '')
  
  
      
   local x = conn:load(url2)
  
   
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')


for title1, url3 in string.gmatch(x,'"playerLabel":"(.-)".-"action":"player:show".-"action.-video.-(http.-)"') do


   
url3 = string.gsub(url3, '\\', '')
   
   t['view'] = 'list'

   table.insert(t, {title = tolazy(title1), mrl = url3, image = '#self/movie.png'})

      end 
  
  
  for title2, url3 in string.gmatch(x,'"label":".-uddfa(.-)".-"action":"panel:(http.-)"') do
  url3 = string.gsub(url3, '\\', '')
        
   local x = conn:load(url3)
  
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
  
  
--  table.insert(t, {title = url, mrl = url})
  
 
    for title3, url4 in string.gmatch(x,'"playerLabel":"(.-)".-"action":"player:show".-video.-(http.-)"') do 
   
url4 = string.gsub(url4, '\\', '')
   
   t['view'] = 'list'

   table.insert(t, {title = title2 .. ' ' .. tolazy(title3), mrl = url4, image = '#self/movie.png'})

      end 
      end
   end
     
 end
 
 
 

 
-- https://lampa.ip917.ru/lite/lumex/video.m3u8?playlist=%2fvalidate%2fU2FsdGVkX1-HWJXR-68d4L5FZ5G8XZbankXomi3bA2NSRN28LPBPtpORtthxOnUsx0Lg3KqSB6Kfg3EJql4hhh7YMO-Pp2SLx9TnO-tBp5myBFbjXKKEuKfrYZ2wVwdb45iSZaB5Cok7fK_Cb4QprlmNkOfV5hLruFWpJtTVIuGIf3Dk65SDRFcyJOHKPXleu07ieysuHAkAZEDcjDZUECF4FIdxBkqkYwP6CPUt4x8&csrf=636ebee3ad5caa58ecd60717b4c38dc7&max_quality=1080&uid=2hlekqiu   
--https://lamp-movie.ru
--http://lam.maxvol.pro

--http://78.40.195.218:9118
--http://lam.maxvol.pro/lite/videodb?rjson=False&href=https://iframe.cloud/iframe/386

--http://89.110.96.198:12267/lite/lumex?kinopoisk_id=386
    
 --   http://z01.online/lite/vdbmovies?kinopoisk_id=386
    
 --   http://z01.online/lite/lumex?kinopoisk_id=386
 
 --http://z01.online/lite/videocdn?kinopoisk_id=4910542
    
--   local x = conn:load('http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3) 

   local x = conn:load('https://p01--lampac--9dxms589q2gt.code.run/lite/lumex?kinopoisk_id=' .. args.id3) 
   
   --.. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3, mrl = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":.-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
      url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

  --   local x = conn:load(url1)
   
 

 
 --    local slist = string.match(x, 'quality(.-)}')
      
--if slist then

--   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

  --  total1 = string.gsub(total1, ',"', '') 
--total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url1})

      end 
--    end

  --  end
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end


   
   
    elseif args.q == 'lumex' then
    
  --  http://lam.maxvol.pro
 --   http://178.20.46.40:12600

--http://lam.maxvol.pro/lite/lumex?kinopoisk_id=4910542

   local x = conn:load('https://p01--lampac--9dxms589q2gt.code.run/lite/lumex?kinopoisk_id=' .. args.id3)
   -- https://lam.akter-black.com
    
   --  local x = conn:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
 
 
-- http://fxmlparsers.in.net/VilkaDB/?id=vcdnep&vcdn_src=https://p.lumex.space/tUBmWYz7hh91/movie/87677
 
 --http://fxmlparsers.in.net/VilkaDB/?id=vcdnep&vcdn_src=https://p.lumex.space/tUBmWYz7hh91/movie/86142&translation_id=1369&varip=45.155.7.202&h=https://p.lumex.space
 
 
 
 --http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-Z3OGSNB_6LRXjDs8ksXnF60ID6sI-tsm3cQWS5QYihme3wQGUKtMNuZF2q-YVs0IyrDU2Hw2_NgmnUTPP1cwqm0LDBOZOyhcrVTdzyTL-Y49r8878YOFCqRox4uywhd1kjYFN4OUIY3e-K18tVWDLXIudWbcs3Qg2dEZ2Erpa5p81Mwe7NN09IcwocAKDUaTRxEsqoWOYjQ&varip=45.155.7.202&h=https://p.lumex.space

--http://45.155.7.202/hls/5850fd02cc56f5027cc0b69600f11f968a832831/http://mpa.education1ne.in.net/movies/2e6caf63dc352062c9306750386e5bd447d768ce/7bd886e1e75c421b281dafe98c333a74:2026021321/1080.mp4:hls:manifest.m3u8

 --http://mpa.education1ne.in.net/movies/77a3f30013f65273cdb368c0ec8d494fd1ca383b/523ef288098852d6d114c7c745bb2128:2026022205/1080.mp4:hls:manifest.m3u8
 
 
-- http://fxmlparsers.in.net/VilkaDB/?id=vcdnep&vcdn_src=https://p.lumex.space/tUBmWYz7hh91/movie/87677&varip=45.155.7.202&h=https://p.lumex.space
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
--  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
  
  
  
  
       t['view'] = 'simple'

 --  table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p) ' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
 
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
      
url3 = string.gsub(url3, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p) '.. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '480.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p) ' .. tolazy(total), mrl = url3})
       
    end
    
   local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '360/index')
      url3 = string.gsub(url3, '360.mp4', '360.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '360.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(360p) ' .. tolazy(total), mrl = url3})
       
    end 
    
local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '240/index')
      url3 = string.gsub(url3, '360.mp4', '240.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '240.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(240p) ' .. tolazy(total), mrl = url3})
       
    end
    
    
    
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
       --   url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end
  end
  
  

 elseif args.q == 'lumexs' then
    
     local x = conn:load('https://lam.maxvol.pro/lite/lumex?content_id=' .. args.id1 .. '&kinopoisk_id=' .. args.id2 .. '&clarification=' .. args.id3 .. '&s=' .. args.id4 .. '&t=' .. args.id5)



for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = 'Сезон ' .. args.id4 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end






      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
 
 
 
 local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '1080/index')
      url5 = string.gsub(url5, '360.mp4', '1080.mp4')
      
     url5 = string.gsub(url5, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8') 
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(1080p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
 

     local x = conn:load(url4)
  
  for url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
  
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(720p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
   
   local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '480/index')
      url5 = string.gsub(url5, '360.mp4', '480.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '480.mp4:hls:manifest.m3u8')
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(480p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
  
end

   
   
--   http://z01.online/lite/filmix?title=чужой&year=1979
    
--https://vizhu.top/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
 -- https://lamp-movie.ru/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
  
--http://z01.online/lite/filmix?postid=173202
      
 
 elseif args.q == 'filmixred' then
 
 local url = 'https://lampa.li/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2

  

local x = conn:load(url .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   
--  table.insert(t, {title = url .. '&uid=bwygkgxn', mrl = url .. '&uid=bwygkgxn'})
  
  x = string.gsub(x, '\\u0026', '&')



local search = string.match(x, '<div class="videos__line".-method.-url.-(http.-)&#')

local x = conn:load(search .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

x = string.gsub(x, '\\u0026', '&')

  for qual, total in string.gmatch(x, '<div class="videos__item videos__movie.-quality.-{(.-)}.-class="videos__item%-title">(.-)</div>') do
  
  --local slist = string.match(x, 'quality.-{(.-)}')
      
   for  total1, url2 in string.gmatch(qual,'(%d+p).-(http.-)&#') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
  -- url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     
      t['view'] = 'list'


   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total), mrl = url2, image = '#self/movie.png'})

       
    end
    end
 
 
 for  url2, total2 in string.gmatch(x, 'class=.-videos__item videos__season.-method.-url.-(http.-)&#.-videos__season%-title.->(.-)<') do
 
 
 url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 

     
     local x = conn:load(url2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 
-- table.insert(t, {title = url2 .. '&uid=bwygkgxn', mrl = url2 .. '&uid=bwygkgxn'})
 
 
 
 x = string.gsub(x, '\\u0026', '&')
     x = string.gsub(x, '\\u002B', '+')
 
-- table.insert(t, {title = x, mrl = '#stream/q=filmixreds&id=' .. x})


   for id, id1, id2, id3, total3 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-postid=(.-)&title=(.-)&.-&s=(.-)&t=(.-)&.->(.-)</div>') do


   t['view'] = 'list'

    

table.insert(t, {title = tolazy(total2) .. ' ' .. tolazy(total3), mrl = '#stream/q=filmixreds&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = '#self/movie.png'})


      end 
      end

    
    elseif args.q == 'filmixreds' then
   
   local x = conn:load('https://lampa.li/lite/filmix?rjson=False&postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&s=' .. args.id2 .. '&t=' .. args.id3 .. '&codec=aac' .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   


    for qual, total in string.gmatch(x, '<div class="videos__item videos.-streamqualit(.-)}].-class="videos__item%-title">(.-)</div>') do
  
 -- local x = string.match(x, 'quality.-{(.-)}')
   
   for  total1, url2 in string.gmatch(qual,'(%d+p).-(http.-)&#') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
   --   url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     


      t['view'] = 'list'


   table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2, image = '#self/movie.png'})

       
    end
    end




 
     elseif args.q == 'filmix' then

--https://api.filmix.tv/api-fx/list?search=горничная+2025

local x = conn:load('https://api.filmix.tv/api-fx/list?search=' .. urlencode(args.id1) .. '+' .. args.id2)

x = string.gsub(x, '\\', '')




for title, year, image, id in string.gmatch(x,'"id":.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)".-url":"https://.-/.-/.-/(.-)%-') do

--t['view'] = 'simple'


--table.insert(t, {title = 'http://filmix.red/fork/item/' .. id .. '/?box_mac=2732f8ed9573', mrl = '#stream/q=filmixapi&id=' .. id,image = image})

--end

--http://filmix.red/fork/item/181496/?box_mac=2732f8ed9573

--http://filmix.red/fork/item/185596?box_mac=2732f8ed9573


--elseif args.q == 'filmixapi' then

--local x = conn:load('http://178.20.46.40:12600/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2)

--for id in string.gmatch(x,'<div class="videos__line".-"method":"link".-"url":"http.-postid=(.-)\\u0026') do


local x = conn:load('https://api.filmix.tv/api-fx/post/' .. id .. '/video-links')

--table.insert(t, {title = 'https://api.filmix.tv/api-fx/post/' .. id .. '/video-links', mrl = '#stream/q=filmixapi&id=' .. 'https://api.filmix.tv/api-fx/post/' .. id .. '/video-links',image = image})


x = string.gsub(x, '\\', '')

--x = string.gsub(x, '"http.-.mp4"', '')


local video = string.match(x, '{"season":null(.-)"video"}]')



if video then

local video1 = string.match(video, '"files":%[(.-)"updated"') 

if video1 then

for url, url1, total in string.gmatch(video1,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video1,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
end



local video2 = string.match(video, '"files".-"files":%[(.-)"updated"')

if video2 then


for url, url1, total in string.gmatch(video2,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video2,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
 end
 
 
 
local video3 = string.match(video, '"files".-"files".-"files":%[(.-)"updated"') 


if video3 then

for url, url1, total in string.gmatch(video3,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video3,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
 end
 
 
 local video4 = string.match(video, '"files".-"files".-"files".-"files":%[(.-)"updated"') 

if video4 then

for url, url1, total in string.gmatch(video4,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video4,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
 end
 
 
local video5 = string.match(video, '"files".-"files".-"files".-"files".-"files":%[(.-)"updated"') 

if video5 then

for url, url1, total in string.gmatch(video5,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video5,'"voiceover":"(.-)"') do

t['view'] = 'list'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1, image = '#self/movie.png'})
   
      end
end
 end
 

 
 end




--x = string.gsub(x, '"http.-.mp4"', '')

       for url1, url2, url3, url4, url5, total in string.gmatch(x,'"url":"(http.-/hls/)(.-)(/s%d+)(e%d+)(_.-)".-quality":(.-),') do


			

    title1 = string.gsub(url3, '/s', 'Сезон ')
    title = string.gsub(url4, 'e', 'серия  ')
    
    title2 = string.gsub(url2, '(.-%d)', '')
    
      t['view'] = 'list'
      
      table.insert(t, {title = '(' .. total .. 'p)' .. title1 .. ' ' .. title .. ' ' .. title2, mrl = url1 .. url2 .. url3 .. url4 .. url5, image = '#self/movie.png'})
      

      end
end	
--end
   
    elseif args.q == 'kino4k' then
  
--http://wtch.ch/lite/fxapi
  
  
  
 -- https://akter-black.com/lite/filmix?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn
  
    
    -- local x = conn:load(args.id)
    
    local x = conn:load('https://get-balancer.akter-black.com/lite/fxapi?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
    
	--	local x = conn:load('http://wtch.ch/lite/fxapi?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
 
 
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 

    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
   if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do
--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
    
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'list'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5, image = '#self/movie.png'})

    end   
    end

    
end
end





--https://lamp-movie.ru


--http://hidxlglk.deploy.cx/lite/filmix?title=чужой+1979

--https://beta.l-vid.online/lite/filmix?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn


elseif args.q == 'kinofit' then


local x = conn:load('https://beta.l-vid.online/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&uid=bwygkgxn')

local x = conn:load('http://178.20.46.40:12600/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2)

for id in string.gmatch(x,'<div class="videos__line".-"method":"link".-"url":"http.-postid=(.-)\\u0026') do


id = string.gsub(id, '^(.-)', 'item/')
         
         id=base64_encode(id)
 

 
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')


  
     for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = (total1) .. ' ' .. tolazy(total), mrl = url2})
    
        end
        end
        
  
      




     local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')



      for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
  
       total = string.gsub(total, '<!%[CDATA%[', '')
       total = string.gsub(total, ']]>', '')
       
     local x = conn:load(url1 .. '&box_mac=acace24b8434')

    
    for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-сезон).-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
       total1 = string.gsub(total1, ']]> <![CDATA[', '')
       total1 = string.gsub(total1, ']]>', '')
   
        local x = conn:load(url2 .. '&box_mac=acace24b8434')
   

     
     for total2, total3, url3 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<playlist_url><!%[CDATA%[http.-&goto=(.-)&.-]]') do
    
 --     total2 = string.gsub(total2, '<!%[CDATA%[', '')
   --   total2 = string.gsub(total2, ']]>', '')
 
 
 t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total2) .. ' ' .. tolazy(total), mrl = '#stream/q=kinofits&id=' .. url3})
 
 end
 end
 end
 end
 
 
 elseif args.q == 'kinofits' then

local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. args.id .. '&viewseason' .. '&box_mac=acace24b8434')
 
 
      
  --    local x = conn:load(url3 .. '&box_mac=acace24b8434')
 
     
     
     for total4, url4 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]].-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do
    
       total4 = string.gsub(total4, '<!%[CDATA%[', '')
      total4 = string.gsub(total4, ']]>', '')
    
    
    
      t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total4), mrl = url4})
    
        end
      



--http://fxmlparsers.in.net/http://rezka.ag/?act=https://rezka.ag/films/drama/86937-lesnoy-pozhar-2026.html&m=1&ep=id%3D86937%26translator_id%3D238%26is_camrip%3D0%26is_ads%3D0%26is_director%3D0%26action%3Dget_movie

--https://rezka.ag/series/drama/86953-geroi-pustyni-2026.html#t:473-s:1-e:2

--http://78.40.199.67:10630/cors/https://30bf3790.obrut.show/embed/AN?kinopoisk_id=386

--http://z01.online/lite/rezka?title=чужой+1979
--https://app.lovefilm.cc



elseif args.q == 'hdrezkatest1' then

--http://fxmlparsers.in.net/VilkaDB/?id=rezka&act=https%3A%2F%2Frezka.ag%2Ffilms%2Ffiction%2F80586-proekt-ave-mariya-2026-latest.html

--http://fxmlparsers.in.net/VilkaDB/?id=rezka&act=https://rezka.fi/films/fiction/80586-proekt-ave-mariya-2026-latest.html


--&ep=id%3D80586%26translator_id%3D59%26


	local url = 'https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-/(film.-)"') do

--http://78.40.199.67:10630

--http://78.40.195.218:9118/lite/rezka/?href=films/horror/1447-chuzhoy-1979-latest.html&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv

local x = conn:load('http://78.40.195.218:9118/lite/rezka/?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')


x = string.gsub(x, '\\u0026', '&')

for id, id1, title in string.gmatch(x, 'class=.-videos__movie.-"method".-"call".-"url".-http.-&id=(.-)&t=(.-)&.-class="videos__item%-title">(.-)<') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=hdrezkatestm&id=' .. id .. '&id1=' .. id1})

end
end
   
local url = 'https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		

for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-/(series.-)"') do


	local x = conn:load('http://78.40.195.218:9118/lite/rezka?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')




x = string.gsub(x, '\\u0026', '&')

for url in string.gmatch(x, '<div class=.-videos__season.-"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-)<') do

local x = conn:load('http://78.40.195.218:9118' .. url)

	x = string.gsub(x, '\\u0026', '&')
	
	for id, title in string.gmatch(x,'class="videos__button.-"method".-"link".-"url".-"http.-&href=series.-&id=.-&t=(.-)"}.->(.-)<') do
	
	
	for id1, id2, id3, title1 in string.gmatch(x,'<div class="videos__item videos__movie.-"method".-"call".-"url":"http.-&id=(.-)&.-&s=(.-)&e=(.-)".-class="videos__item%-title">(.-)<') do
	

	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=hdrezkatests&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

end
end
end
end





elseif args.q == 'voidboost' then


	local url = 'https://rezka.metrpiva.com/info?id=' .. args.id3
		
			local x = conn:load(url)


--table.insert(t, {title = url, mrl = '#stream/q=voidboostm&id=' .. url})

local slist = string.match(x,'"translators".-%[(.-)hasSeasons":false')

if slist then

for id, name in string.gmatch(slist, '{"id":"(.-)","name":"(.-)"') do


t['view'] = 'list'

table.insert(t, {title = tolazy(name), mrl = '#stream/q=voidboostm&id=' .. id .. '&id3=' .. args.id3, image = '#self/movie.png'})

end
end



local url = 'https://rezka.metrpiva.com/info?id=' .. args.id3
		
			local x = conn:load(url)

--table.insert(t, {title = url, mrl = '#stream/q=voidboostm&id=' .. url})


local slist = string.match(x,'"translators".-%[(.-)hasSeasons":true')

if slist then

for id, name in string.gmatch(slist, '{"id":"(.-)","name":"(.-)"') do

t['view'] = 'list'

table.insert(t, {title = tolazy(name), mrl = '#stream/q=voidboostn&id=' .. id .. '&id3=' .. args.id3, image = '#self/movie.png'})

end
end


elseif args.q == 'voidboostn' then

local url1 = 'https://rezka.metrpiva.com/episodes?id=' .. args.id3 .. '&translator_id=' .. args.id



local x = conn:load(url1)



local episod = string.match(x,'"episodes".-{(.-)}}')

for seasonid, episodes in string.gmatch(episod,'"(%d+)":%[(.-)]') do


for episodeid, episodename in string.gmatch(episodes,'{"id":(.-),"title":"(Серия.-)"') do

t['view'] = 'list'


table.insert(t, {title = 'Сезон ' .. seasonid  .. ' ' .. episodename, mrl = '#stream/q=voidboosts&id=' .. args.id .. '&id3=' .. args.id3 .. '&id4=' .. seasonid .. '&id5=' .. episodeid, image = '#self/movie.png'})

end
end



elseif args.q == 'voidboosts' then


--https://rezka.metrpiva.com/episode-stream?id=4308326&translator_id=111&s=1&e=1

local url = 'https://rezka.metrpiva.com/episode-stream?id=' .. args.id3 .. '&translator_id=' .. args.id .. '&s=' .. args.id4 .. '&e=' .. args.id5
		
	local x = conn:load(url)

local slist = string.match(x,'stream(.-)}')

for quel, url1 in string.gmatch(x,'%[(%d+p)](http.-m3u8)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel), mrl = url1, image = '#self/movie.png'})

end

for quel, url1 in string.gmatch(x,'%[(%d+p)]http.-m3u8.-(http.-mp4)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel) .. ' (mp4)', mrl = url1, image = '#self/movie.png'})

end


elseif args.q == 'voidboostm' then



local url = 'https://rezka.metrpiva.com/movie-stream?id=' .. args.id3 .. '&translator_id=' .. args.id
		
	local x = conn:load(url)

local slist = string.match(x,'stream(.-)}')

for quel, url1 in string.gmatch(x,'%[(%d+p)](http.-m3u8)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel), mrl = url1, image = '#self/movie.png'})

end

for quel, url1 in string.gmatch(x,'%[(%d+p)]http.-m3u8.-(http.-mp4)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quel) .. ' (mp4)', mrl = url1, image = '#self/movie.png'})

end





elseif args.q == 'hdrezkatest' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'list'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=hdrezkatestm&id=' .. id .. '&id1=' .. id1, image = '#self/movie.png'})

end
end



local headersv = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMWEwMmQ5Ny01ZjBjLTdkNzktYWE0Ny1jN2IyMTlhMjhjYzYiLCJleHAiOjE3OTAwNjMzMDMsImlhdCI6MTc4NzQ3MTMwMywibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NzQ3MTI0MywicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImM0N2FlYTAwZTk4ZmE0NDgxYjYzNDNkOGU5MzA3OGNhMDk4NGExNDNkZTAzMzc2Mjk5MGEzMDllODE3Y2EzM2MifQ.o1PwWN46k-3u0CFAeinX6oB6QvP7vP1ClpMucxGxQJpXMWot3xfK9IgnILeZE1l0lew1YlHbwyLZUQlbL5-3Bw; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}


local headersv1 = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "device_fp=9f9139a533bc817f940b4ee8a95b90fb; _ym_uid=1783765420480304829; _ym_d=1783765420; _clck=lzs41b%5E2%5Eg7n%5E0%5E2383; adrdel=1783765433965; adrcid=AvUrk8BPUn0AXVkexSk3JgQ; acs_3=%7B%22hash%22%3A%2278168166d1d84ba31a91bed5b79968efe721107d%22%2C%22nst%22%3A1783851876598%2C%22sl%22%3A%7B%22224%22%3A1783765476598%2C%221228%22%3A1783765476598%7D%7D; PHPSESSID=225nrdd5b82hvum033cft7l9p6",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}



local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do
	--	local x = http.getz('https://kinopub.me' .. args.id, headersv)
		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}
		
		local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headersv, params)			
					

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})




url = url_for('get_movie', {file = x['url'], t = t['name']})


url = urldecode(url)

for quali, url1 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url1, image = '#self/movie.png'})

end
end
	end	
end
   
   
   
 
   
local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'list'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=hdrezkatests&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = '#self/movie.png'})

end
end
end
end
end

local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
--local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')

local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'list'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=hdrezkatests&id=' .. tid .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = '#self/movie.png'})

end
end
end
end

end
 


      elseif args.q == 'hdrezkatests' then
   
   
   local headers = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMWEwMmQ5Ny01ZjBjLTdkNzktYWE0Ny1jN2IyMTlhMjhjYzYiLCJleHAiOjE3OTAwNjMzMDMsImlhdCI6MTc4NzQ3MTMwMywibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NzQ3MTI0MywicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImM0N2FlYTAwZTk4ZmE0NDgxYjYzNDNkOGU5MzA3OGNhMDk4NGExNDNkZTAzMzc2Mjk5MGEzMDllODE3Y2EzM2MifQ.o1PwWN46k-3u0CFAeinX6oB6QvP7vP1ClpMucxGxQJpXMWot3xfK9IgnILeZE1l0lew1YlHbwyLZUQlbL5-3Bw; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}
   

					local params = http.encode{
		id = args.id1,
		translator_id = args.id,
		season = args.id2,
		episode = args.id3,
		action = 'get_stream'
					}
					
					local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})


	url = url_for('get_stream', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url3, image = '#self/movie.png'})

end      
   
   
   
    
    	elseif args.q == 'hdrezkatestm' then

local headers = {
    ["Host"] = "kinopub.me",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Referer"] = "https://kinopub.me/",
["Connection"] = "keep-alive",
["Cookie"] = "PHPSESSID=adae7j4ch12n7rpfimlgv0hrsb; techaro.lol-anubis-cookie-verification=01a02d97-5f0c-7d79-aa47-c7b219a28cc6; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMWEwMmQ5Ny01ZjBjLTdkNzktYWE0Ny1jN2IyMTlhMjhjYzYiLCJleHAiOjE3OTAwNjMzMDMsImlhdCI6MTc4NzQ3MTMwMywibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NzQ3MTI0MywicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImM0N2FlYTAwZTk4ZmE0NDgxYjYzNDNkOGU5MzA3OGNhMDk4NGExNDNkZTAzMzc2Mjk5MGEzMDllODE3Y2EzM2MifQ.o1PwWN46k-3u0CFAeinX6oB6QvP7vP1ClpMucxGxQJpXMWot3xfK9IgnILeZE1l0lew1YlHbwyLZUQlbL5-3Bw; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "document",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "same-origin",
["Priority"] = "u=0, i"}
   
	
					local params = http.encode{
						id = args.id,
						translator_id = args.id1,
						action = 'get_movie'
					}
					
					local x = http.postz('https://kinopub.me' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})




local x = json.decode(x)

	url = url_for('get_movie', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url3, image = '#self/movie.png'})

end



elseif args.q == 'fxmlrezka' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'list'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=fxmlrezkam&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. url, image = '#self/movie.png'})

end
end


local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}


local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. url .. '&m=1&ep=id%3D' .. id .. '%26translator_id%3D' .. tid .. '%26action%3Dget_movie')

--table.insert(t, {title = 'http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. url .. '&m=1&ep=id%3D' .. id .. '%26translator_id%3D' .. tid .. '%26action%3Dget_movie', mrl = 'http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. url .. '&m=1&ep=id%3D' .. id .. '%26translator_id%3D' .. tid .. '%26action%3Dget_movie'})


--url = url_for('get_movie', {file = x['url'], t = t['name']})


x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'list'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1, image = '#self/movie.png'})

end
end
	end	
end
   



local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'list'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=rezkas&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url, image = '#self/movie.png'})

end
end
end
end
end

local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
--local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')

local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'list'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=fxmlrezkas&id=' .. tid .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url, image = '#self/movie.png'})

end
end
end
end

end
 


      elseif args.q == 'fxmlrezkas' then
   
 
--http://fxmlparsers.in.net/http://www.rezka.ag/?act=https%3A%2F%2Frezka.ag%2Fseries%2Fdrama%2F91279-naslednica-2004.html&tid=59&m=1&ep=id%3D91279%26translator_id%3D59%26season%3D1%26episode%3D31%26action%3Dget_stream  
  
local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id4 .. '&m=1&ep=id%3D' .. args.id1 .. '%26translator_id%3D' .. args.id .. '%26season%3D' .. args.id2 .. '%26episode%3D' .. args.id3 .. '%26action%3Dget_stream')

--table.insert(t, {title = 'http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id4 .. '&m=1&ep=id%3D' .. args.id1 .. '%26translator_id%3D' .. args.id .. '%26season%3D' .. args.id2 .. '%26episode%3D' .. args.id3 .. '%26action%3Dget_stream', mrl = 'http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id4 .. '&m=1&ep=id%3D' .. args.id1 .. '%26translator_id%3D' .. args.id .. '%26season%3D' .. args.id2 .. '%26episode%3D' .. args.id3 .. '%26action%3Dget_stream'})




x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'list'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1, image = '#self/movie.png'})

end



elseif args.q == 'fxmlrezkam' then



local x = http.get('http://fxmlparsers.in.net/http://www.rezka.ag/?act=https://rezka.ag' .. args.id2 .. '&m=1&ep=id%3D' .. args.id .. '%26translator_id%3D' .. args.id1 .. '%26action%3Dget_movie')



x = string.gsub(x, '\\', '')
--url = urldecode(url)

for qual, url1 in string.gmatch(x, '"(%d+)":{"url":"(http.-)"') do


t['view'] = 'list'

table.insert(t, {title = tolazy(qual) .. 'p', mrl = url1, image = '#self/movie.png'})

end



					
 

 
 










elseif args.q == 'rezka' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	

	
	
	local x = http.getz('https://rezka.fi' .. url, headers)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'list'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezkam&id=' .. id .. '&id1=' .. id1, image = '#self/movie.png'})

end
end





local headers = {
    ["Host"] = "hdrzk.org",
    ["%{http_code}"] = "max-time 10",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
["Cookie"] = "cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
   ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://hdrzk.org/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}





local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do
	--	local x = http.getz('https://kinopub.me' .. args.id, headersv)
		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')



local params = http.encode{
		id = id,
		translator_id = tid,
		action = 'get_movie'
					}
		
		local x = http.postz('https://hdrzk.org' .. '/ajax/get_cdn_series/', headers, params)			
					

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})




url = url_for('get_movie', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url1 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do


t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url1, image = '#self/movie.png'})

end
end
	end	
end
   
   
   
 
   
local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do



local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0", 
["Host"] = "rezka.fi",
["Accept"] = "*/*",

["Accept-Encoding"] = "gzip",
["Cookie"] = "dle_user_id=2927296; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; expires=Sun, 18-Apr-2027 04:55:22 GMT; Max-Age=31536000; path=/; domain=.rezka.fi; HttpOnly"    
          
         }	




	local x = http.getz('https://rezka.fi' .. url, headers)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'list'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=rezkas&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url, image = '#self/movie.png'})

end
end
end
end
end

local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do

		
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
			
--local id = string.match(x, 'fav_holder_data.-data%-post_id="(.-)"')

local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do

t['view'] = 'list'

table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1), mrl = '#stream/q=rezkas&id=' .. tid .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. url, image = '#self/movie.png'})

end
end
end
end

end
 


      elseif args.q == 'rezkas' then
   
   
   local headers = {
    ["Host"] = "hdrzk.org",
    ["%{http_code}"] = "max-time 10",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
["Cookie"] = "techaro.lol-anubis-cookie-verification=019f8838-f797-7300-b45c-75710e4cb40c; techaro.lol-anubis-auth=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhY3Rpb24iOiJDSEFMTEVOR0UiLCJjaGFsbGVuZ2UiOiIwMTlmODgzOC1mNzk3LTczMDAtYjQ1Yy03NTcxMGU0Y2I0MGMiLCJleHAiOjE3ODcyODg4OTksImlhdCI6MTc4NDY5Njg5OSwibWV0aG9kIjoiZmFzdCIsIm5iZiI6MTc4NDY5NjgzOSwicG9saWN5UnVsZSI6ImFjOTgwZjQ5YzRkMzVmYWIiLCJyZXN0cmljdGlvbiI6ImUzMTEwYTFiZTdkZWZhNGNlYWZkYWFlZjczN2MxMGZmNWRlOWZjZjdiYTRjNmJkZWY3YTdkZDU5YThlYmRjY2EifQ.09wb9nbPOOqztqPGqz6YQP11Tj_capHS-14qndonPH9a4BEA6eCBL8FAr51QysAgck5prBPSvPNntuA0_GqjCA; cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
   ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://hdrzk.org/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}



local headerss = {
    ["Host"] = "hdrzk.org",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
   ["Cookie"] = "dle_user_id=2927296; dle_password=2d3a2e1e2e8cc01c52ca19348aed27f4; dle_newpm=0; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d"
}






					local params = http.encode{
		id = args.id1,
		translator_id = args.id,
		season = args.id2,
		episode = args.id3,
		action = 'get_stream'
					}
					
					local x = http.postz('https://hdrzk.org' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})

local x = json.decode(x)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})


	url = url_for('get_stream', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url3, image = '#self/movie.png'})

end      
   
 
local x = conn:load('http://78.40.195.218:9118/lite/pizdatoehd/movie?href=' .. args.id4 .. '&t=' .. args.id .. '&s=' .. args.id2 .. '&e=' .. args.id3)
  
  
local slist = string.match(x,'"quality":{(.-)}')

if slist then

 for qual, url in string.gmatch(slist,'"(%d+p)":".-(/proxy.-)"') do
 
   
url = string.gsub(url, '^(.-)', 'http://78.40.195.218:9118')
   
   
t['view'] = 'list'

    table.insert(t, {title = tolazy(qual), mrl = url, image = '#self/movie.png'})

     end
 end
 
 
 
   
   
    
    	elseif args.q == 'rezkam' then

local headers = {
    ["Host"] = "hdrzk.org",
    ["%{http_code}"] = "max-time 10",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 14; samsung) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ["X-Hdrezka-Android-App"] = "1",
   ["X-Hdrezka-Android-App-Version"] = "2.2.5",
["Cookie"] = "cf_clearance=mG_qbKcELkSr6tX_zpmU90wcKJwzD1uLhoR4vgjmjis-1784690164-1.2.1.1-lw0QFewFt8ZOnKoxhyD7p9ZgJnntQTFyWSTwl9lDoQykmKAEp7mwWatTQqcBupa.tikIZ6gNqJfFboRfDC.Q8lu7gEHzj1r_bpiBsSdS45EC2RtHxEf2S5fUBNGKNiIaPb2GfWPNyQGa2hOvjGELOE996g7su6ST3vwu2beeK5qD3OywwSjtZqhc.fZ7Op_CYvgmpafLaATdpSVFctv4S3l1sDek08eq61vWhaSRou_ZJztJU.nofelgPiHU7P3JKpGiQifm9Lqrv6xS0PoWrI0WOuK0qOgg_l5xpGVH3_rcBfQ7I_a4N3MKhBM2OXdkjqMll1Fy66slAtqUWVuCfLIzcQaBr5kptxzttwGAyrps2yE7wR5s8KfcFNOwEw4cSvvv6Xm4YGtVzD8dsAtv5OZ5jfi6j7NxWJv4YPxXgOLMEuHoMx_DE4Q9JXsAqBQ6et_7STDth1J4b.JJGWCfkYoNd4nJIo_.ImLVTWgwSk8AqlVkDJH8Un.qy373.029; dle_user_taken=1; dle_user_token=cf3c15774f570ef3c47d0b956a835fcb; _ym_uid=1779116564800304697; _ym_d=1779116564; _clck=1snsa8l%5E2%5Eg7y%5E0%5E2329; _vc_id=LatmuiuhJ-lpN41GcW00rx92-V-gObTy; PHPSESSID=pj6gl7oamds1rebnc5hdts4a0d; _ym_isad=2",
   ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://hdrzk.org/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}




	
					local params = http.encode{
						id = args.id,
						translator_id = args.id1,
						action = 'get_movie'
					}
					
					local x = http.postz('https://hdrzk.org' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})




local x = json.decode(x)


	url = url_for('get_movie', {file = x['url'], t = t['name']})



url = urldecode(url)

for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do



t['view'] = 'list'

table.insert(t, {title = tolazy(quali), mrl = url3, image = '#self/movie.png'})

end




--https://kinopub.me/

     elseif args.q == 'hdrezka222' then

  --http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=чужой:+земля-2025&box_mac=acace24b8434

--local url = 'http://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load('https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href=.-//.-/(.-)"') do
   
 
-- http://78.40.195.218:9118/lite/rezka/?href=series/horror/79810-ono-dobro-pozhalovat-v-derri-2025-latest.html&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv
 
 --http://31.129.234.181/lite/pizdatoehd?href=series/horror/79810-ono-dobro-pozhalovat-v-derri-2025-latest.html&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv
 
-- http://78.40.195.218:9118/lite/pizdatoehd?href=films/horror/1447-chuzhoy-1979-latest.html
 
      local x = conn:load('http://78.40.195.218:9118/lite/pizdatoehd?href=' .. '/' .. url)


 x = string.gsub(x, '\\u0026', '&')

for id, title in string.gmatch(x, 'class=.-videos__movie.-"method".-"url.-voice=(.-html).-class="videos__item%-title">(.-)<') do

id = urldecode(id)
 
 
 
 
     --     for id, title in string.gmatch(x,'data%-translator_id.-href="(.-)">(.-)</a>') do
     t['view'] = 'simple'
  
  

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. id) .. '&box_mac=acace24b8434')
    

  
  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title =tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
  end
  
  local x = conn:load('http://78.40.195.218:9118/lite/pizdatoehd?href=' .. '/' .. url)


 x = string.gsub(x, '\\u0026', '&')
 
  for url3, id1, total in string.gmatch(x, 'class="videos__button.-"method".-"url".-href=(.-html).-&t=(.-)".->(.-)<') do
 
 url3 = urldecode(url3)
  
         
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. url3) .. '&box_mac=acace24b8434')
  
  
         
for title1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=.-&translate=.-&season=(.-)&episode=(.-)]]') do
   
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(total), mrl = '#stream/q=rezkis&id=' .. url3 .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
        
end
 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. url) .. '&box_mac=acace24b8434')
    

      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end

    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
  
t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    end
   
    
elseif args.q == 'rezkis' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. base64_encode('https://kinopub.me/' .. args.id) .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end
elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end






     elseif args.q == 'rezka222' then

--https://evkh.lol/lite/rhsprem?kinopoisk_id=464475&title=франкенштейн&year=2025

--https://lampa.remagick.ru/lite/rhsprem

    		local x = conn:load('https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '+' .. args.id2)
    
  --table.insert(t, {title = 'https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '+' .. args.id2, mrl = 'https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
  
       local url = string.match(x, '<div class="videos__line".-method.-"url".-href=(.-)"') 
       
    local slist = string.match(x, '"quality"(.-)}')
      
    if slist then
   
   for  total1, url3 in string.gmatch(slist, '"(%d+p)":"(http.-mp4)') do
  
    --  url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'simple'

   table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
    end
  
 -- https://lampa.remagick.ru/lite/rhsprem?href=films%2fhorror%2f82897-prishlite-pomosch-2026.html
  
  
  
  
  local x = conn:load('https://lampa.remagick.ru/lite/rhsprem?href=' .. url)
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
      -- t['view'] = 'simple'
   
      local x = conn:load(url2)

  local slist = string.match(x, '"quality"(.-)}')
      
      
   
   for  total1, url3 in string.gmatch(slist, '"(%d+p)":"(http.-mp4)') do
  
   --   url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'list'

    table.insert(t, {title = '(' .. total1 .. ')' .. total, mrl = url3})

     end  
 end
     




   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      



      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rez' then

   local x = conn:load('https://lampa.remagick.ru/lite/rhsprem/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
  
  
  
--https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=4760854&title=%D0%9A%D0%BE%D1%80%D0%BE%D0%BB%D1%8C+%D0%A2%D0%B0%D0%BB%D1%81%D1%8B&year=2025&serial=1

        elseif args.q == 'kinobase' then

--http://31.129.234.181:80/lite/kinobase?href=film/244146-na-vershine&t=&s=1&uid=guest

   local x = conn:load('https://kinobase.org/search?query=' .. urlencode(args.id1) .. '+' .. args.id2)
   
 for title in string.gmatch(x, '<div class="poster".-<a href="/(.-)"') do
        
   
    url = string.gsub(title, '^(.-)', 'https://lam.akter-black.com/lite/kinobase?href=') .. '&t=&s=1'
    

     local x = conn:load(url .. '&uid=guest')
   

      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
   --   local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(%d+p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com')
     t['view'] = 'list'

url2 = string.gsub(url2, '\\u002B', '+')

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2, image = '#self/movie.png'})
    end
     end  
  

  
     for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
      local x = conn:load(url)
   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com')
    
       
      local x = conn:load(url2 .. '&uid=guest')

      
      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
    
url3 = string.gsub(url3, '\\u002B', '+')

    
         
    url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')
    
       t['view'] = 'list'



    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3, image = '#self/movie.png'})

    end   
    end
    end
   
end




   elseif args.q == 'kinotop' then


   
local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=search&search=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&box_mac=acace24b8434')
   
       for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do
 
       local x = conn:load(url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')
  
  
     for total1, url2  in string.gmatch(x, '<channel.-<title><!%[CDATA%[(%d+p)]]></title.-<stream_url><!%[CDATA%[(http.-)]]') do
    
    
     t['view'] = 'simple'
      table.insert(t, {title = total1, mrl = url2})

       end
     end
   

for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[http.-(&media=.-)]]') do


       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=watch' .. url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')


     for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = (total3) .. (total4), mrl = url3})

end
   
   
  for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-сезон)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
        local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = total2 .. (total3) .. (total4), mrl = url3})

end
end
     end
      
      

elseif args.q == 'jac' then

    

   local x = conn:load('https://lam.akter-black.com/lite/jac?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
   
       t['view'] = 'simple'
    table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     
     


		local x = conn:load('https://lam.akter-black.com/lite/jac?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
  
  
  
  
  
       t['view'] = 'simple'
     table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     


--https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=570402&title=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB&year=2025
     
--  https://lam.maxvol.pro/lite/pidtor/serial/548bae27dca47ab2805465cc12ab1d9a89d15426?tr=
     
     
     
     
     
     elseif args.q == 'result' then
      args.id = args.id:lower() 
      
      local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end
   
   
   
    elseif args.q == 'pidtor' then
  
  
  local x = conn:load('https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
 -- table.insert(t, {title = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})

      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-?tr=).-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'list'

   table.insert(t, {title = 'pidtor :' .. tolazy(total), mrl = url2, image = '#self/movie.png'})

       
    end
     
  
  
  local x = conn:load('https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
  
--https://lam.akter-black.com/lite/pidtor?kinopoisk_id=&title=чужой&serial=1

--https://lam.akter-black.com/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=

--https://lam.maxvol.pro/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=




for url2, title in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')

      local x = conn:load(url2)
    

    
      for url3, total  in string.gmatch(x, '"method":"link".-"url":"http.-/lite/pidtor/serial/(.-)?tr=.-class="videos__item%-title videos__season%-title">(.-)</div>') do


--url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')

     url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'list'
     table.insert(t, {title = title .. ' ' ..  total,mrl = '#stream/q=result&id=' .. url3, image = '#self/movie.png'})
     end
     
   end
 
 
 
-- https://jacred.stream/api/v1.0/torrents?search=чужой&relased=1979
 
 --elseif args.q == 'jacred' then

--local x = conn:load('https://jac.red/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
 

 
elseif args.q == 'jacred' then

local x = conn:load('https://jacred.stream/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
 
--https://jacred.stream/api/v1.0/torrents?search=kp386&limit=2


local x = json.decode(x)

		for _, v in ipairs(x) do
		--	local url = 'http://rutube.ru/video/' .. v['id'] .. '/'
	
	t['view'] = 'list'
	
	table.insert(t, {title = v['title'], mrl = '#stream/q=jacreds&id=' .. v['magnet'], image = '#self/movie.png'})

end


   

--https://torr1.akter-black.com/stream/Spider-Man%20Brand%20New%20Day%202026%201080p_nnm-club.mkv?link=7c30776fd2af7a74cd56ded216ddf1e0c9d65775&index=1&play
 
 -- https://lam.akter-black.com/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u 
 -- https://ts.maxvol.pro/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u
--  https://tv.alcopa.cc/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u 
  

 
 elseif args.q == 'jacreds' then

  --   args.id = args.id:lower() 

local x = conn:load('https://torr1.akter-black.com/stream?link=' .. urlencode(args.id) .. '&m3u')
 
-- table.insert(t, {title = x, mrl = x, image = image})
 
 for title, url in string.gmatch(x,'EXTINF:.-,(.-)\n(http.-)\n') do
 
-- url = urldecode(url)
 t['view'] = 'list'
 
table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
   
-- table.insert(t, {title = title, mrl = 'https://torr1.akter-black.com/stream' .. url})
		end
 
 
 
 
 
 elseif args.q == 'potok' then
 
-- https://api.potok.rip/api/media/search?query=чужой+1979&language=ru
 
 --local url = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru'
 
 local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru')
 
 for id, title, year, media in string.gmatch(x,'"id":(.-),"title":"(.-)".-"subtitle":"(.-)".-"mediaType":"(.-)"') do
 

table.insert(t, {title = id .. ' ' .. title .. ' ' .. year .. ' ' .. media, mrl = id .. ' ' .. title .. ' ' .. year .. ' ' .. media})
 
 
 
 --local url1 = 'https://search.potok.rip/api/v1/torrents/search'


local url1 = 'https://tv.alcopa.cc/api/v2.0/indexers/all/results?title=' .. title .. '&title_original=&year=' .. year .. '&is_serial=1'

local x = conn:load(url1)
 
 local x = json.decode(x)

		for _, v in ipairs(x['Results']) do

 
 

local url2 = 'https://torrent.potok.rip/api/torrents'


local headers = {
    ["Host"] = "torrent.potok.rip",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://potok.rip/",
     ["Content-Type"] = "application/json",
    ["Content-Length"] = "252",
    ["Origin"] = "https://potok.rip"}
  
  
 --   ["Connection"] = "keep-alive",
 --   ["Sec-Fetch-Dest"] = "empty",
 --   ["Sec-Fetch-Mode"] = "cors",
 --   ["Sec-Fetch-Site"] = "same-site",
 --   ["Priority"] = "u=4"
--}
    




local params = '{"title":"' .. v['Title'] .. '","link":"' .. v['Details'] .. '","magnetUri":"' .. v['MagnetUri'] .. '","mediaType":"' .. media .. '","tmdbId":' .. id .. '}'
 
 
 table.insert(t, {title = params, mrl = params})
 
local x = http.postz(url2, headers, params)
 
 
 url = url_for(x)     
 url = urldecode(url)     
  

  --    t['view'] = 'simple'
      
      table.insert(t, {title = url, mrl = url})
 
 end
 end
 
 
-- https://torrent.potok.rip/api/torrents/7c94aadc67067059d44b34b670d1e84bbd751977/files/1/metadata


--https://torrent.potok.rip/api/torrents/feed30a9b86e8e98f063149d21d2200a88e30f2f/files/1/hls/master.m3u8





 
 
 
 
 elseif args.q == 'torrs' then
 
 local url = 'https://tv.alcopa.cc/ts/torrents'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/json",
    ["Content-Length"] = "1578",
    ["Origin"] = "https://tv.alcopa.cc",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1785248696908035379; _ym_d=1785248696; _ym_isad=2; _ym_visorc=w; lampac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; alpac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; _lampac_auth=8126ef1f-0a68-4b87-be2b-732e679461cc",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}
 
 local params = '{"action":"add","link":"magnet:?xt=urn:btih:9a060fb9626117a6f283f0be3e2ca62a30ab881f&dn=Disclosure.Day.2026.1080p.WEB-DL.DDP5.1.H.264.mkv&tr=udp%3a%2f%2fopentor.net%3a6969&tr=http%3a%2f%2fbt.searchtor.to%2f00da7f34fc14674f374452da7ba4ebc8%2fannounce&tr=http%3a%2f%2fbt02.nnm-club.cc%3a2710%2f00da7f34fc14674f374452da7ba4ebc8%2fannounce&tr=http%3a%2f%2fipv6.bt.searchtor.to%2f00da7f34fc14674f374452da7ba4ebc8%2fannounce&tr=http%3a%2f%2fbt02.ipv6.nnm-club.cc%3a2710%2f00da7f34fc14674f374452da7ba4ebc8%2fannounce&tr=http%3a%2f%2ftracker.grepler.com%3a6969%2fannounce&tr=udp%3a%2f%2ftracker.dler.com%3a6969%2fannounce&tr=http%3a%2f%2fh4.trakx.nibba.trade%3a80%2fannounce&tr=udp%3a%2f%2fopen.stealth.si%3a80%2fannounce&tr=udp%3a%2f%2ftracker.bitsearch.to%3a1337%2fannounce&tr=udp%3a%2f%2fexodus.desync.com%3a6969%2fannounce&tr=udp%3a%2f%2ftracker-udp.gbitt.info%3a80%2fannounce&tr=udp%3a%2f%2ftracker.torrent.eu.org%3a451%2fannounce&tr=http%3a%2f%2ftracker.mywaifu.best%3a6969%2fannounce&tr=udp%3a%2f%2fevan.im%3a6969%2fannounce&tr=udp%3a%2f%2fbittorrent-tracker.e-n-c-r-y-p-t.net%3a1337%2fannounce&tr=udp%3a%2f%2fmartin-gebhardt.eu%3a25%2fannounce&tr=https%3a%2f%2ftr.nyacat.pw%3a443%2fannounce&tr=udp%3a%2f%2ftracker.opentorrent.top%3a6969%2fannounce&tr=udp%3a%2f%2fns575949.ip-51-222-82.net%3a6969%2fannounce&tr=udp%3a%2f%2ftracker.corpscorp.online%3a80%2fannounce&tr=http%3a%2f%2fretracker.local%2fannounce&tr=udp%3a%2f%2ftorrent.by%3a2710&tr=udp%3a%2f%2ftracker.torrent.eu.org%3a451","title":"День разоблачения / Disclosure Day (2026) WEB-DL","save_to_db":false}'
 
 local x = http.postz(url, headers, params)
 
 url = url_for(x)
 url = urldecode(url)
 
 table.insert(t, {title = url, mrl = url})
 
 
 elseif args.q == 'torrsuuu' then

local x = conn:load('http://jac.red/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
 


 x = string.gsub(x, '",', '\\u0026')	
 
	
 
  x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
     x = string.gsub(x, '\\u041A', 'К')
       x = string.gsub(x, '\\u043A', 'к')  
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  x = string.gsub(x, '\\u041B', 'Л')
       x = string.gsub(x, '\\u041b', 'Л')
    x = string.gsub(x, '\\u043B', 'л')
       x = string.gsub(x, '\\u043b', 'л')
     
     x = string.gsub(x, '\\u041C', 'М')
       x = string.gsub(x, '\\u043C', 'м')
       x = string.gsub(x, '\\u041D', 'Н')
       x = string.gsub(x, '\\u043D', 'н')
       x = string.gsub(x, '\\u041E', 'О')
     
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
    x = string.gsub(x, '\\u043E', 'о')
       x = string.gsub(x, '\\u043e', 'о')
    
    x = string.gsub(x, '\\u041F', 'П')
       x = string.gsub(x, '\\u043F', 'п')
     
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
          x = string.gsub(x, '\\u042A', 'Ъ')
        x = string.gsub(x, '\\u044A', 'ъ')
        x = string.gsub(x, '\\u042B', 'Ы')
        x = string.gsub(x, '\\u044B', 'ы')
        x = string.gsub(x, '\\u042C', 'Ь')
        x = string.gsub(x, '\\u044C', 'ь')
        x = string.gsub(x, '\\u042D', 'Э')
        x = string.gsub(x, '\\u044D', 'э')
        x = string.gsub(x, '\\u042E', 'Ю')
        x = string.gsub(x, '\\u044E', 'ю')
        x = string.gsub(x, '\\u042F', 'Я')
     
     x = string.gsub(x, '\\u044F', 'я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')

 
 for id, title, total, total1, total2 in string.gmatch(x,'{"tracker".-"magnet:?.-btih:(.-)\\u0026.-name":"(.-)\\u0026.-"relased":(.-),.-"quality":(.-),"voices":%[(.-)]') do
 
total2 = string.gsub(total2, '\\u0026', '",')
 

   
  -- t['view'] = 'simple'
   
--   table.insert(t, {title = title, mrl = '#stream/q=results&id=' .. id, image = image})
--		end


--elseif args.q == 'results' then
		
      id = id:lower() 

local url = 'https://webtor.io/ru/' .. id

local x = conn:load(url)

local resource, item = string.match(x,'<form class="stream".-<input type="hidden" name="resource%-id" value="(.-)".-<input type="hidden" name="item%-id" value="(.-)"')

if resource then
if item then


local url1 = 'https://webtor.io/ru/stream-video'
    	
    local headers = {
    ["Host"] = "webtor.io",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",  
    ["Referer"] = "https://webtor.io/ru/" .. id,
    ["rid"] = "anti-csrf",
    ["st-auth-mode"] = "cookie",

    ["x-layout"] = '{{ template "main" . }}',
    ["x-requested-with"] = "XMLHttpRequest",
    ["x-return-url"] = "/ru/" .. id,

    ["Content-Type"] = "multipart/form-data; boundary=----geckoformboundary2351d75989feaaab29367cec52302dcf",
    ["Content-Length"] = "361",
    ["Origin"] = "https://webtor.io",
    ["Alt-Used"] = "webtor.io",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "INGRESSCOOKIE=1783322851.769.27.209027|30f4c3c8c430593554a9c611add2fe8e; lang=ru; session=MTc4MzMyMjg1MHxOd3dBTkVRMlZsUTJRa3hPVFZaRVMwZEVTVVZJUTFWTE5FdFdWVVJJVGxoTldrdEVSMDgzVWxCRlYwUldTMDFNUVRSQlJFMVZWRkU9fPERPIXqmqLFj16BsJtUxltomSQSS0wlLyfTCUZWLaiP; cf_clearance=IZ5E5g50hgggo5cblyd1j13Dpts.9.q2.nhqFz0QAq4-1783355644-1.2.1.1-h58djc.A7pYEgfhr7kqY_8_iLmTcC7KTbpkwY2l13LrwMieOY8DV9kY.DBMlnwH6rV6nDjIfq6KHnb9hWAMPAvmgBVpXxf80h2wS1.DtLTFXHnCQhbE.oxk3BHJrgfXBNUutCZDwvYe1QWn7rhDf0wRkPKejVEbMmoLZ8sSYxQGt1f83SgyDkijSi7gS6CYYkcCRiPDvSYDHeBUGHYVRzjIU_PXL8jZcW9VBZyDQ1MlXz1.U3hkiRWXeMVyu1.89wzJqQysW7od6jFV3Ad2lyjnzbH0YT58mmIsczGq6MYrQs9yuUTNWRSiMnVbR5XC_TZDHcxu5Qg0Pss8hJXDAqA; st-last-access-token-update=1783322917853",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

 --   ["x-csrf-token"] = "LkveJ0cYcZ_APYAGsiXRnr1w7Cw=",

 --   ["x-session-id"] = "D6VT6BLNMVDKGDIEHCUK4KVUDHNXMZKDGO7RPEWDVKMLA4ADMUTQ",




local params = [[
------geckoformboundary2351d75989feaaab29367cec52302dcf
Content-Disposition: form-data; name="resource-id"

resource
------geckoformboundary2351d75989feaaab29367cec52302dcf
Content-Disposition: form-data; name="item-id"

item
------geckoformboundary2351d75989feaaab29367cec52302dcf--
]]



--table.insert(t, {title = url, mrl = url})

local x = http.postz(url1, headers, params)

--local url1 = string.match(x,'>source.torrent.-href="(.-)"')      
 url = url_for(x)     
 url = urldecode(url)     
  
      x = string.gsub(x, '\\', '')
      


 --   local url1 string.match(x, '"mp4":%["(.-mp4)"') 
  
  if url then
  
   --   url1 = string.gsub(url, '^(.-)', 'https://abra--5e4bd525.api.cosmic-crab.buzz/')
  --    t['view'] = 'simple'
      
      table.insert(t, {title = url, mrl = url})
  end
  end
 end
 end
 
  
  
  
  
 
      elseif args.q == 'awmzone' then

--https://lampa.plus



local headers = {
    ["Host"] = "lampa.plus",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6IkRHakdrTGkySDVEaVNRWE1hOUdCWEE9PSIsInZhbHVlIjoid1VGNlpvRGt0N3dENTZXQkxOMllwdHZlMDZzRTlwRDV1aWc5Q2JJUDRhbk1rSzR5dDZuMGhIaS9OSFdQcFhLWHk0ZnBxZDk2R1B6S2hvc2phK29JbSt4TElabGxPdXlPSEgwUEJoQ2daS3BGd0FzdjFPNEFEOERPUVBZZVFxMjkiLCJtYWMiOiIxYjc5YWIxNzk2YzZhODUzMTk3MjA3ODlhMGZlNWFiM2NlNjkzYmVlNzAzZmIwNTcxODFhNmUzZTcyYzBiMDdlIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlFMZEFSVWhwTWpxNUpkSGNCSDdYT1E9PSIsInZhbHVlIjoiNkxHdWhoWE1KOGYyQzBSazZvNldVOGlQb1pta3dOalJtLzBjcktVTFBFTVJCNEwxbXNQUmdPbE9OMHJXejUrdFhmSS9GSk0rOUkzVG8ydHhxU21uRDNzSnh4ekNUeUJGaHV1MGVRUzhFQllzdzVwS3FyRTNQbk1xZXdQd0tpQUYiLCJtYWMiOiI4ZDQ0NjFmMGJmYmJjZDdmOGFhOTUyMzQxYzQzNzAzOGFlZDMwYWQzMjU2NDhhZDM4OTMyYzU4Mzc3YTQ5OTkxIiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none"
}
 
-- https://www4.kinovod10.top/mary/spotlight?search=
 
  local search = 'https://lampa.plus/mary/spotlight?search=' .. urlencode(args.id1)
  
--  https://lampa.plus/36040688-mumiia.html
  
--  local x = conn:load(search)

local x = http.getz(search, headers)

if x then

local x = json.decode(x)

		for _, v in ipairs(x) do
			local link = 'https://lampa.plus' .. v['link']
			
if link then

local x = conn:load(link)

x = string.gsub(x, '\\', '')

local id, title = string.match(x,'"embedUrl":"http.-embed%-players/(.-)".-<h1.->(.-)<')

if id then

t['view'] = 'list'

  table.insert(t, {title = title, mrl = '#stream/q=awmzonepl&id=' .. 'https://lampa.plus/embed-player/' .. id, image = '#self/movie.png'})
  
  end
end
end
end







local headers = {
    ["Host"] = "turboserial.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6IkRHakdrTGkySDVEaVNRWE1hOUdCWEE9PSIsInZhbHVlIjoid1VGNlpvRGt0N3dENTZXQkxOMllwdHZlMDZzRTlwRDV1aWc5Q2JJUDRhbk1rSzR5dDZuMGhIaS9OSFdQcFhLWHk0ZnBxZDk2R1B6S2hvc2phK29JbSt4TElabGxPdXlPSEgwUEJoQ2daS3BGd0FzdjFPNEFEOERPUVBZZVFxMjkiLCJtYWMiOiIxYjc5YWIxNzk2YzZhODUzMTk3MjA3ODlhMGZlNWFiM2NlNjkzYmVlNzAzZmIwNTcxODFhNmUzZTcyYzBiMDdlIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6IlFMZEFSVWhwTWpxNUpkSGNCSDdYT1E9PSIsInZhbHVlIjoiNkxHdWhoWE1KOGYyQzBSazZvNldVOGlQb1pta3dOalJtLzBjcktVTFBFTVJCNEwxbXNQUmdPbE9OMHJXejUrdFhmSS9GSk0rOUkzVG8ydHhxU21uRDNzSnh4ekNUeUJGaHV1MGVRUzhFQllzdzVwS3FyRTNQbk1xZXdQd0tpQUYiLCJtYWMiOiI4ZDQ0NjFmMGJmYmJjZDdmOGFhOTUyMzQxYzQzNzAzOGFlZDMwYWQzMjU2NDhhZDM4OTMyYzU4Mzc3YTQ5OTkxIiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none"
}
 
 
  local search = 'https://turboserial.com/mary/spotlight?search=' .. urlencode(args.id1)
  
  
  
  local x = http.getz(search, headers)

--local x = conn:load(search)

if x then

local x = json.decode(x)

		for _, v in ipairs(x) do
			local link = 'https://turboserial.com' .. v['link']
			
if link then

local x = conn:load(link)



x = string.gsub(x, '\\', '')
 
local id, title = string.match(x,'"embedUrl":"http.-embed%-players/(.-)".-<h1.->(.-)</h1>')

if id then

t['view'] = 'list'

  table.insert(t, {title = title, mrl = '#stream/q=awmzonepl&id=' .. 'https://turboserial.com/embed-player/' .. id, image = '#self/movie.png'})
  
  end
end
end
end


--https://kinogotv.one/36456621-proekt-konec-sveta.html






elseif args.q == 'awmzonepl' then

local url = args.id

local headerss = {
   ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "laravel_session=eyJpdiI6ImJIZEJtYTVWZWJ0U3N3cHlGKzAxVlE9PSIsInZhbHVlIjoiOVNRNFRPWjZXZmpob01WZk5sSkJGTTNPNk9PN0NaZ2w4dVhIYVpVaklFWURXVFRTTjl5aDA3aE92N2VzMVJZV09HNGhiemNzRUtzcHJ1S1JwWmhIS1RMNTVNejh2RmxzMmZROWdwSDhXc01xTSttV2MyVHBwcmFuczNybTlieXAiLCJtYWMiOiJkOTE3NzUyYzUyNGNhNmVhMDJkMWE2YTZhZDA1NjEzMjA3MWVhNzk1Yjc3YjVmNWY4ZWYyZTc2OWEwNzRhZmVhIiwidGFnIjoiIn0%3D; XSRF-TOKEN=eyJpdiI6InVDdE9UWE5lQjJjUVgzbmNPMWZML0E9PSIsInZhbHVlIjoicE04emNaeGJiSXVMQXppNmIva1RjYkcrZ3FDSkZKLzBYbkM3RFczTzBBUkNEUUx2K0tEMjhzUjQ4cXByVE1JZmJNbFRkYnZJbkdmTWVHM2I3RTd6czMzZGN1YVhLVnF5L3Y5cDAwTGNvN1BYNTZYVFBrRW9hU0d4YVh3K21QQnAiLCJtYWMiOiI4MjBiNmJhM2RkNTBjYmY5ZTFlNmU1NTA3N2JkMzNhMDMzZjcxMGFkZTA2OWE5YWZlZjE2NTRhODhhYWZiZjI1IiwidGFnIjoiIn0%3D; _ym_uid=1779079991933178448; _ym_d=1779079991; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
["Priority"] = "u=0, i"
}

local headers = {
["Pragma"] = "no-cache",
["Cache-Control"] = "no-cache",
["sec-ch-ua"] = '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
["sec-ch-ua-mobile"] = "?0",
["sec-ch-ua-platform"] = "Windows",
["DNT"] = "1",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,uk-UA;q=0.8,uk;q=0.7,en-US;q=0.6,en;q=0.5",
["Priority"] = "u=1, i",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-origin",
["Sec-Fetch-Storage-Access"] = "active",
["Referer"] = iframe
}
 
  local x = conn:load(url)

--local x = http.getz(url, headerss)


  
  local slist = string.match(x,'Playerjs.-atob.-&#039;(.-)&#039;%)+')
  
  if slist then
  

  
  slist = base64_decode(slist)
  

local slist1 = string.match(slist,'"file":"#2(.-)\"+')

slist1 = string.gsub(slist1, '\\', '') 

slist1 = string.gsub(slist1, '//', '') 

slist1 = string.gsub(slist1, 'cG9zb3Npa2xvdW4=', '')

slist1 = string.gsub(slist1,'ZHZhZG9sYm9lYmE=', '')

--slist1 = string.gsub(slist1,'Qtn', '')

slist1 = string.gsub(slist1,'YmliYWlib2Jh', '')


slist1 = base64_decode(slist1)

slist1 = urldecode(slist1)


for title, url1, url2, url3 in string.gmatch(slist1,'{(.-)}(http.-)(/movie.-)(/hls.m3u8)') do

if url2 then

local m3u = conn:load(url1 .. url2 .. url3)

if m3u then

m3u = string.gsub(m3u, './', ',./') 

m3u = string.gsub(m3u, 'stream', '/stream') 
 
for qual, url4 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'list'

table.insert(t, {title = '(' .. tolazy(qual) .. 'p) ' .. tolazy(title), mrl = url1 .. url2 .. url4, image = '#self/movie.png'})
  
  end
end
 end
 end
 
 
 
 for season, episode, slist2 in string.gmatch(slist,'{"id":"S(.-)E(.-)".-"file":"#2(.-)\"+') do

slist2 = string.gsub(slist2, '\\', '') 

slist2 = string.gsub(slist2, '//', '') 

slist2 = string.gsub(slist2, 'cG9zb3Npa2xvdW4=', '')

slist2 = string.gsub(slist2,'ZHZhZG9sYm9lYmE=', '')

slist1 = string.gsub(slist1,'YmliYWlib2Jh', '')



slist2 = base64_decode(slist2)

slist2 = urldecode(slist2)
 
 
 for title, url2 in string.gmatch(slist2,'{(.-)}(http.-m3u8)') do


--local m3u = conn:load(url2 .. url3)

--if m3u then

--m3u = string.gsub(m3u, './', ',./') 

--m3u = string.gsub(m3u, 'stream', '/stream') 
 
--for qual, url4 in string.gmatch(m3u,'#EXT%-X%-STREAM.-RESOLUTION=.-x(.-),.-(/.-m3u8)') do
 
 t['view'] = 'list'

  table.insert(t, {title = 'Сезон ' .. season .. ' Серия ' .. episode .. ' ' .. tolazy(title), mrl = url2, image = '#self/movie.png'})
  
  end
 end
-- end
-- end
    
 end   
  
       

elseif args.q == 'anwap' then
  
  

  
  local x = conn:load('https://tv.anwap.today/films/search/?slv=' .. urlencode(args.id1) .. '&vid=1&toch=on')

  
local slist=string.match(x, '</form>.-div class="save">По.-id="cn"(.-)"menuniz"')
  

  if slist then
    for url, title, year in string.gmatch(x, '<div class="my_razdel film".-href="(.-)".-alt="(.-)".-class="in year">(.-)<') do

     local x = conn:load('https://tv.anwap.today' .. url)



local slist1=string.match(x,'"file":"#2(.-)"')


slist1 = string.gsub(slist1, '//', '')
        slist1 = string.gsub(slist1, 'WXQ2cmpGZA==', '')
slist1 = string.gsub(slist1, 'RmtpVTdoRw==', '')

slist1 = string.gsub(slist1, 'RXJTdzNBc2k=', '')

slist1 = string.gsub(slist1, 'UlRkM1M2NUZn', '')

    slist1 = base64_decode(slist1)
    
--local url1 = string.match(slist1, '(http.-m3u8)') 
   
      t['view'] = 'list'
        table.insert(t, {title = tolazy(title) .. ' (' .. year .. ')', mrl = slist1, image = '#self/movie.png'})
	
		end
		end


local x = conn:load('https://tv.anwap.today/serials/search/?t=on' .. '&word=' .. urlencode(args.id1) .. '&vid=1') 


   local slist=string.match(x, '</form><div class="save">По.-id="cn"(.-)"menuniz"')

	if slist then

       for url, title, year in string.gmatch(slist, '<div class="my_razdel film".-<a href="(.-)".-alt="(.-)".-class="in year">(.-)<') do

    
    local x = conn:load('https://tv.anwap.today' .. url)

       local slist1=string.match(x, '<ul class="tl2">(.-)</ul>')


		if slist1 then
			for url1, title1 in string.gmatch(slist1, '<li><a href="(/serials/s.-)">(.-)<') do
       
       t['view'] = 'list'
      
       table.insert(t, {title = tolazy(title) .. ' (' .. year .. ') ' .. title1, mrl = '#stream/q=sezond&id=' .. url1, image = '#self/movie.png'})
        
        end
		end
		end	
end


    elseif args.q == 'sezond' then
  
   local x = conn:load('https://tv.anwap.today' .. args.id)

 
 local ser = string.match(x,'<div class="blm".-<a href="(/serials/down/.-)"')
 
 local x = conn:load('https://tv.anwap.today' .. ser)
 
 
   local slist=string.match(x,'"file":"#2(.-)"')

slist = string.gsub(slist, '//', '')
        slist = string.gsub(slist, 'WXQ2cmpGZA==', '')
slist = string.gsub(slist, 'RmtpVTdoRw==', '')

slist = string.gsub(slist, 'RXJTdzNBc2k=', '')

slist = string.gsub(slist, 'UlRkM1M2NUZn', '')

    
    slist = base64_decode(slist)
    
local url1 = string.match(slist,'(http.-txt)') 

  local x = conn:load(url1)

  
  
			for title, url in string.gmatch(x, '"title":"(.-)".-"file":"(http.-)"') do
      

        t['view'] = 'list'
        table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
	
		end







elseif args.q == 'collaps' then
  
  
  local x = conn:load('http://31.129.234.181/lite/collaps?kinopoisk_id=' .. args.id3)

for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
    
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})


       
    end

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://31.129.234.181')
    
       t['view'] = 'list'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3, image = '#self/movie.png'})

       
    end

end






      local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)
   
   
   for title in string.gmatch(x, '"iframe_url":"http.-/embed/.-/(.-)"') do
   

      

url = string.gsub(title, '^(.-)', 'http://31.129.234.181/lite/collaps?orid=')
     local x = conn:load(url)

   
   
   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
      t['view'] = 'list'

   table.insert(t, {title = tolazy(total), mrl = url2, image = '#self/movie.png'})

     end  
  

     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/collaps.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://31.129.234.181')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://31.129.234.181')
    
       t['view'] = 'list'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3, image = '#self/movie.png'})

       
    end
end
end



elseif args.q == 'collaps2' then

 t['view'] = 'list'
-- t['image'] = 'https://mir-s3-cdn-cf.behance.net/projects/max_808/74ce85146344181.Y3JvcCw5NjEsNzUxLDAsMTIz.png'







local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)

 
   local iframe = string.match(x,'"id".-"iframe_url":".-(/embed.-)"')



--https://api.femd.ws/embed/movie/87442?oneSound=WinMedia&sharing=false&host=kinotik.top

local x = conn:load('https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top')

--table.insert(t, {title = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top', mrl = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top'})

x = string.gsub(x, '\\u0026', '&')

    x = string.gsub(x, '\\"', '')


local down = string.match(x,'download:.-"(http.-)"')


local hls = string.match(x,'hls:.-"(http.-)"')


local title = string.match(x,'hls.-audio:.-%["(.-)"') 



if title then

local x = conn:load(hls)

local total = string.match(x, '#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total then

--t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title), mrl = down .. '&audio=' .. total, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title), mrl = down .. '&video=v2&audio=' .. total, image = '#self/movie.png'})

end
end


local title1 = string.match(x,'hls.-audio:.-%[".-".-"(.-)"') 

if title1 then

local x = conn:load(hls)

local total1 = string.match(x, 'm3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total1 then

--t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title1), mrl = down .. '&audio=' .. total1, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title1), mrl = down .. '&video=v2&audio=' .. total1, image = '#self/movie.png'})



end
end




local title2 = string.match(x,'hls:.-audio:.-%[".-".-".-".-"(.-)"') 

if title2 then

local x = conn:load(hls)

local total2 = string.match(x, 'm3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total2 then

--t['view'] = 'simple'

table.insert(t, {title = '720p ' .. tolazy(title2), mrl = down .. '&audio=' .. total2, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title2), mrl = down .. '&video=v2&audio=' .. total2, image = '#self/movie.png'})


end
end




local title3 = string.match(x,'hls:.-audio:.-%[".-".-".-".-".-".-"(.-)"')

if title3 then

local x = conn:load(hls)

local total3 = string.match(x, 'm3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total3 then

table.insert(t, {title = '720p ' .. tolazy(title3), mrl = down .. '&audio=' .. total3, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title3), mrl = down .. '&video=v2&audio=' .. total3, image = '#self/movie.png'})


end
end


local title4 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-"(.-)"') 

if title4 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total4 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total4 then

table.insert(t, {title = '720p ' .. tolazy(title4), mrl = down .. '&audio=' .. total4, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title4), mrl = down .. '&video=v2&audio=' .. total4, image = '#self/movie.png'})
 
  end
   end


local title5 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title5 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total5 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total5 then

table.insert(t, {title = '720p ' .. tolazy(title5), mrl = down .. '&audio=' .. total5, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title5), mrl = down .. '&video=v2&audio=' .. total5, image = '#self/movie.png'})

  end
   end


local title6 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title6 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total6 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total6 then

table.insert(t, {title = '720p ' .. tolazy(title6), mrl = down .. '&audio=' .. total6, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title6), mrl = down .. '&video=v2&audio=' .. total6, image = '#self/movie.png'})

  end
   end

local title7 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title7 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total7 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total7 then

table.insert(t, {title = '720p ' .. tolazy(title7), mrl = down .. '&audio=' .. total7, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title7), mrl = down .. '&video=v2&audio=' .. total7, image = '#self/movie.png'})

  end
   end

local title8 = string.match(x, 'hls:.-audio:.-%[".-".-".-".-".-".-".-".-".-".-".-".-".-".-".-".-"(.-)"') 

if title8 then

local x = conn:load(hls)

--t['view'] = 'simple'

local total8 = string.match(x, 'm3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-m3u8.-#EXT%-X%-MEDIA:TYPE=AUDIO,GROUP%-ID="audio.-URI="http.-index%-(a.-).m3u8')

if total8 then

table.insert(t, {title = '720p ' .. tolazy(title8), mrl = down .. '&audio=' .. total8, image = '#self/movie.png'})

table.insert(t, {title = '480p ' .. tolazy(title8), mrl = down .. '&video=v2&audio=' .. total8, image = '#self/movie.png'})

  end
   end
   
local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)

 
   local iframe = string.match(x,'"id".-"iframe_url":".-(/embed.-)"')



--https://api.femd.ws/embed/movie/87442?oneSound=WinMedia&sharing=false&host=kinotik.top

local x = conn:load('https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top')

--table.insert(t, {title = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top', mrl = 'https://api.femd.ws' .. iframe .. '?sharing=false&host=kinotik.top'})

x = string.gsub(x, '\\u0026', '&')

    x = string.gsub(x, '\\"', '')


local season = string.match(x,'seasons:%[(.-)]}]')

if season then

for total, url in string.gmatch(season, '"duration".-"title":"(.-)".-"download":"(http.-)"') do

	
--	t['view'] = 'simple'
	
table.insert(t, {title = tolazy(total), mrl = url, image = '#self/movie.png'})

  end
 end
 


elseif args.q == 'collaps-dash' then
  
 

  local x = conn:load('http://178.20.46.40:12600/lite/collaps-dash?kinopoisk_id=' .. args.id3)



   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end


elseif args.q == 'kinotochka' then
  
 

--https://kinovibe.vip/embed/8003

 local url = 'https://kinovibe.cc/api/find-by-kinopoisk.php?kinopoisk=' .. args.id3
--https://kinovibe.co/embed/kinopoisk/386/


  
-- local url = 'https://kinovibe.cc/?do=search&mode=advanced&subaction=search&story=' .. urlencode(args.id1)

		
		local x = conn:load(url)
		
       
			x = string.gsub(x, '\\', '')
			
  
 -- https://kinovibe.vip/27131-persi-dzhekson-i-olimpiycy-2-sezon-2025.html
 
 
  
  local url1 = string.match(x,'"url":"(http.-)"')
  
 -- elseif args.q == 'kinotochkav' then
  
  

    local x = conn:load(url1)

local url, url1 = string.match(x, 'Playerjs.-file:"(http.-video_mp4)(.-mp4)')

			
t['view'] = 'list'

 table.insert(t, {title = 'Смотреть', mrl = url .. url1, image = '#self/movie.png'})



for url in string.gmatch(x, 'Playerjs.-file:"(http.-_480.mp4)') do

			
t['view'] = 'list'

 table.insert(t, {title = '480p', mrl = url, image = '#self/movie.png'})


url = string.gsub(url, '_480.mp4', '_720.mp4')
			
t['view'] = 'list'
 
 table.insert(t, {title = '720p', mrl = url, image = '#self/movie.png'})



end
    



 for url in string.gmatch(x, 'Playerjs.-file:"(http.-txt)"') do

   local x = conn:load(url)

--table.insert(t, {title = url, mrl = url})

--x = string.gsub(x, '[480,720]', '')


for total, title, url1 in string.gmatch(x,'"comment":"(.-Серия).-(%[.-])".-"file":"(http.-/s%d+e%d+)%_.-"') do



t['view'] = 'list'
  
  table.insert(t, {title =  '(' .. '480' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_480.mp4', image = '#self/movie.png'})


table.insert(t, {title = '(' .. '720' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_720.mp4', image = '#self/movie.png'})



end




local x = conn:load(url)

  for title, url2, url3, url4 in string.gmatch(x,'"comment":".-(%[.-])".-"file":"(http.-/s)(%d+)e(%d+)%.mp4"') do
  
  t['view'] = 'list'


table.insert(t, {title = 'Сезон ' .. url3.. ' ' .. 'серия ' .. url4 .. title, mrl = url2 .. url3 .. 'e' .. url4 .. '.mp4', image = '#self/movie.png'})


end
end

--https://beta.mitsu.tv/api/lite/kinoflix?iframe=https://videodb.stream/play/a11e592462863b6c0086d568b8207109?type=movie&id=348

--https://nexsw.stull.xyz/lite/kinoflix?link=/movie/49738/avatar-fire-and-ash&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl

--https://juija.manhan.one/lite/kinoflix?id=49738&title=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%9F%D0%B5%D0%BF%D0%B5%D0%BB&year=2025&account_email=rsmail@ukr.net


--http://31.129.234.181:80/lite/kinoflix?kinopoisk_id=570402&title=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%9F%D0%B5%D0%BF%D0%B5%D0%BB&year=2025&uid=guest

--https://kinoflix.tv/movie/49738/avatar-fire-and-ash

--https://api.themoviedb.org/search/movie?api_key=4ef0d7355d9ffb5151e987764708ce96&query=Чужой



elseif args.q == 'kinoflix' then



 local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru')
 
-- table.insert(t, {title = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru', mrl = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru'})

--https://videodb.cloud/embed/splayer.php?type=serial&id=
 
 for id, title, year in string.gmatch(x,'%[{"id":(.-),"title":"(.-)".-"subtitle":"(.-)".-"mediaType":"movie"') do
 
 if id then

 local x = conn:load('https://videodb.cloud/embed/player.php?type=movie&id=' .. id .. '&lang=ru')

--table.insert(t, {title = 'https://videodb.cloud/embed/player.php?type=movie&id=' .. id, mrl = 'https://videodb.cloud/embed/player.php?type=movie&id=' .. id})

--local file = string.match(x,'"file":"(.-)"')

if x then

for qual, url in string.gmatch(x,'"file".-%[(.-)]{Русский}(http.-);') do


url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=')

t['view'] = 'list'

 
 table.insert(t, {title = title .. ' (' .. year .. ')', mrl = url, image = '#self/movie.png'})
 

--local x = conn:load('https://videodb.stream/file/play?type=movie&id=1212763&name=slug&lang=ru&p=l.playlist'

end

--local iframe = string.match(x,'<iframe.-src="(http.-txt)"')

-- local x = conn:load(iframe)

--local playlist = string.match(x,'file: "(http.-playlist)"')

--local x = conn:load(playlist)

local headers = {
["Pragma"] = "no-cache",
["Cache-Control"] = "no-cache",
["sec-ch-ua"] = '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
["sec-ch-ua-mobile"] = "?0",
["sec-ch-ua-platform"] = "Windows",
["DNT"] = "1",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,uk-UA;q=0.8,uk;q=0.7,en-US;q=0.6,en;q=0.5",
["Priority"] = "u=1, i",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-origin",
["Sec-Fetch-Storage-Access"] = "active",
["Referer"] = iframe
}




--local txt = string.match(x,'"file":"(http.-txt)"')

--local x = http.getz('https://api.potok.rip/api/proxy?url=' .. txt, headers)

--table.insert(t, {title = x, mrl = x})

--table.insert(t, {title = 'https://api.potok.rip/api/proxy?url=' .. txt, mrl = 'https://api.potok.rip/api/proxy?url=' .. txt})

--for url in string.gmatch(x,'#EXT%-X%-MEDIA.-NAME="Russian.-LANGUAGE="ru".-URI="(/m3/.-)"') do

--url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=https://videodb.stream') 
--.. '#.m3u8'

--local x = http.getz('https://videodb.stream' .. url, headers)

--table.insert(t, {title = x, mrl = x})

--end

--for qual, url in string.gmatch(x,'#EXT%-X%-STREAM%-INF.-RESOLUTION=.-x(.-),.-AUDIO.-(/m3/.-)\n') do

--url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=https://videodb.stream') .. '#.m3u8'

--local x = http.getz('https://videodb.stream' .. url, headers)

--table.insert(t, {title = x, mrl = x})


--table.insert(t, {title = qual .. 'p', mrl = url})

--end


end
end
end

--/embed/splayer.php?type=serial&id=${query.tmdbId}


 local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru')
 
-- table.insert(t, {title = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru', mrl = 'https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&language=ru'})

--https://videodb.cloud/embed/splayer.php?type=serial&id=
 
 local id = string.match(x,'%[{"id":(.-),"title":".-".-"subtitle":".-".-"mediaType":"tv"')
 
 if id then

 local x = conn:load('https://videodb.cloud/embed/splayer.php?type=serial&id=' .. id)
 
 --table.insert(t, {title = 'https://videodb.cloud/embed/splayer.php?type=serial&id=' .. id, mrl = 'https://videodb.cloud/embed/splayer.php?type=serial&id=' .. id})
 
 if x then
 
 -- for season, folder in string.gmatch(x,'title":"(Сезон.-)".-"folder":%[(.-)%]%},') do 
  
  for seria, url, url1, url2 in string.gmatch(x,'"title":"(Серия.-)".-"file".-{Русский}(http.-/SE)(.-)(/.-);') do
 
 
 url = string.gsub(url, '^(.-)', 'https://api.potok.rip/api/proxy?url=') .. url1 .. url2

t['view'] = 'list'

 
 table.insert(t, {title = 'Сезон ' .. url1 .. ' ' .. seria, mrl = url, image = '#self/movie.png'})
 
end
end
 end
-- end
-- end
 
 

--https://beta.mitsu.tv/api/lite/kinoflix?kinopoisk_id=5463793&title=%D0%97%D0%BB%D0%BE%D0%B2%D0%B5%D1%89%D0%B8%D0%B5+%D0%BC%D0%B5%D1%80%D1%82%D0%B2%D0%B5%D1%86%D1%8B%3A+%D0%9F%D0%B5%D0%BA%D0%BB%D0%BE&year=2026

local x = conn:load('https://beta.mitsu.tv/api/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
 
 --local x = conn:load('https://lam5.akter-black.com/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')
 
 
 x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '\\u002B', '+')
x = string.gsub(x, '&quot;', '"')
 
 
--table.insert(t, {title = 'https://beta.mitsu.tv/api/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lam5.akter-black.com/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m'})

for url, title in string.gmatch(x, 'videos__item videos__movie.-method.-play.-url.-(http.-m3u8).-videos__item%-title.->(.-)<') do

t['view'] = 'list'

 table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})

end






for url, year, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"link".-"url".-(http.-)".-"year":(.-),.-videos__season%-title">(.-)<') do

if year then

 
    local x1 = conn:load(url)
  if x1 then  
    
x1 = string.gsub(x1, '&quot;', '"')
x1 = string.gsub(x1, '\\u0026', '&')
 x1 = string.gsub(x1, '\\u002B', '+')

for url1, total in string.gmatch(x1, '<div class="videos__item videos__movie.-"method".-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'list'

 table.insert(t, {title = title .. ' (' .. year .. ')', mrl = url1, image = '#self/movie.png'})

end
end
end
end

--local x = conn:load('https://lam5.akter-black.com/lite/kinoflix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=hobqwt4m')
 
-- x = string.gsub(x, '\\u0026', '&')
 x = string.gsub(x, '&quot;', '"')

for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"link".-url.-(http.-)".-videos__season%-title.->(Сезон.-)<') do


--table.insert(t, {title = url, mrl = url})


local x1 = conn:load(url)

if x1 then

 x1 = string.gsub(x1, '&quot;', '"')
x1 = string.gsub(x1, '\\u0026', '&')
 x1 = string.gsub(x1, '\\u002B', '+')

for url1, total in string.gmatch(x1, '<div class="videos__item videos__movie.-"method".-"play".-"url".-(http.-)".-class="videos__item%-title.->(Серия.-)<') do

t['view'] = 'list'

 table.insert(t, {title = title .. ' ' .. total, mrl = url1, image = '#self/movie.png'})

end
end
end




for total, url, title in string.gmatch(x, 'quality.-{"(.-)":"(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end

for total, url, title in string.gmatch(x, 'quality.-/proxy.-,"(.-)":"(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url})

end


for total, url, title in string.gmatch(x, 'quality.-/proxy.-/proxy.-,"(.-)":"(http.-)".-class="videos__item%-title">(.-)<') do

t['view'] = 'list'

 table.insert(t, {title = total .. ' ' .. title, mrl = url, image = '#self/movie.png'})

end

--end






elseif args.q == 'videxx' then


--http://31.129.234.181/lite/vibix/video.m3u8?id=r9iwXA8D631_b-7ZIXjHjNYjrRokJ52BN-IdDmEsgc06-F8trpFbnwCItQztLOCF8PVikkCdNVGeWYQEmkcNgMEzvgEpPnV4iWIerlM2zXBZeqDPhysK_4iWxvvektOh8EVILqA6SGdIeZLeyJ4blavyYm4myg1R6dxyGceLTzXYPwcrMaicK2AzupAVayzRoVxt2sj8UiwW62jVCdsU4g&uid=guest

local x = conn:load('http://31.129.234.181/lite/vibix/?kinopoisk_id=' .. args.id3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
 

 if x then
 
 x = string.gsub(x, '\\u0026', '&')

 
 for qual, title in string.gmatch(x,'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
   for total, url in string.gmatch(qual, '"(%d+p)":.-http.-(/lite.-)"') do
   
   
    url = string.gsub(url, '^(.-)', 'http://31.129.234.181')
 
  t['view'] = 'list'

 table.insert(t, {title = total .. ' ' .. title, mrl = url, image = '#self/movie.png'})

end
end
end
 
 
 
  
local x = conn:load('http://31.129.234.181/lite/vibix/?kinopoisk_id=' .. args.id3 .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
 

 if x then

x = string.gsub(x, '\\u0026', '&')


for url, season in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"url":"http.-(/lite.-)".-videos__season%-title.->(.-)<') do

url = string.gsub(url, '^(.-)', 'http://31.129.234.181')

 local x = conn:load(url .. '&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0')
 
x = string.gsub(x, '\\u0026', '&')

for qual, episod in string.gmatch(x,'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do

for total, url1 in string.gmatch(qual,'"(%d+p)":.-http.-(/lite.-)"') do
   
   
    url1 = string.gsub(url1, '^(.-)', 'http://31.129.234.181')
 
  t['view'] = 'list'


 table.insert(t, {title = total .. ' ' .. season .. ' ' .. episod, mrl = url1, image = '#self/movie.png'})

end
end
end
end




elseif args.q == 'vibix' then

--https://api.manhan.one/lite/vibix/video.m3u8?id=yOZH8-aITUVYstxy5YL4epTadJ889APSj_wBORMUqjprhZS0bE07NhlCFw62uAKTNhlWfcLZVy9noUwHe-muutsdkGvDPujwY9yB14ut4UjHLayS0NUVwFcuauA5-kNik6dhZOnLGrX1R34qPs9CXj2COLPaxEgHtsL7jMt1wRz_5SjmFEM12ZRAbS27yH_7&account_email=rsmail@ukr.net
 
 local x = conn:load('https://api.manhan.one/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
--local x = conn:load('https://lam10.akter-black.com/lite/vibix?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&uid=hobqwt4m')


 if x then
 
 x = string.gsub(x, '\\u0026', '&')
-- x = string.gsub(x, '0&referer', '1&referer')
 
-- x = string.gsub(x, '&account', '?kp=' .. args.id3 .. '&domain=kinobaza.vercel.app&parent_domain=kinobaza.vercel.app&account')
 
 
 for quality, title in string.gmatch(x, 'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
  for qual, url in string.gmatch(quality, '"(%d+p)":.-(http.-)"') do
    

  t['view'] = 'list'


 table.insert(t, {title = qual .. ' ' .. title, mrl = url, image = '#self/movie.png'})

end
end
end  

local x = conn:load('https://api.manhan.one/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
 --local x = conn:load('https://lam10.akter-black.com/lite/vibix?memkey=m2FtOXt7C35vHdKNklFlpw&kinopoisk_id=' .. args.id3 .. '&uid=hobqwt4m')
  if x then
  
    for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do


 local x = conn:load(url .. '&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl')
 
--local x = conn:load(url .. '&uid=hobqwt4m')
 
 
 x = string.gsub(x, '\\u0026', '&')
 
for quality, title1 in string.gmatch(x, 'div class="videos__item videos__movie.-"quality":{(.-)}.-class="videos__item%-title">(.-)<') do
  
  for qual, url1 in string.gmatch(quality, '"(%d+p)":.-(http.-)"') do
    

  t['view'] = 'list'

 table.insert(t, {title = qual .. ' ' .. title .. ' ' .. title1, mrl = url1, image = '#self/movie.png'})

  end
 end
 end
 end
  

  
 
 
 --https://kinozenhd.com/search?q=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9

elseif args.q == 'kinozen' then

--local url = 'https://kinozenhd.com/search?q=' .. urlencode(args.id1)

local url = 'https://kinozentv.com/api/graphql'

local headers = {
    ["Host"] = "kinozentv.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "application/json",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://kinozentv.com/",
    ["content-type"] = "application/json",
    ["x-apollo-operation-name"] = "QuickSearch",
    ["Content-Length"] = "",
    ["Origin"] = "https://kinozentv.com",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1785557337$o2$g1$t1785558906$j60$l0$h0; _ga=GA1.1.731350005.1785517557; _ym_uid=1785517560813624399; _ym_d=1785517560; _ym_isad=2; kz_rec_session=9d3debe8-dda6-43dd-a6b5-24c1a0f28386; _ym_visorc=w; _pow=0558d2ba6d620b6a18151fc646ffd44cd3d38fee1b4b1487; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTczODQsImV4cCI6MTc4NTY0Mzc4NH0.vM0PjntrT2TxdzGymyFirilB7TIW1s7ZqS9ML9LfI7jwZoP2wToi2LzyyK5j_r6_; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiM2YwMGI5ZGItNzUzNS00NzBhLWJkOTItMTBkNzQwOTcwNWU5IiwiaWF0IjoxNzg1NTU3Mzg0LCJleHAiOjE3ODgxNDkzODR9.cuIsJ6Gv9QvDxn2Kc_h2uLqFWgh0wVnpBNHSSPoXSrQZ61_Par6yWTcUvgz8gJAqQYLr4YzUEKZ47NnBox1kFQ",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}


local params = [[{"query":"query QuickSearch($q: String!) {\n searchMovies(\n query: $q\n limit: 12\n ) {\n slug_url\n type\n\n title {\n russian\n original\n }\n\n poster {\n poster_kp\n local_kp\n }\n\n year\n\n rating {\n kinopoisk {\n value\n }\n }\n\n actors {\n person {\n id\n name\n originalName\n\n poster {\n poster_kp\n local_kp\n }\n }\n }\n }\n\n searchPersons(\n query: $q\n limit: 4\n ) {\n id\n name\n originalName\n\n poster {\n poster_kp\n local_kp\n }\n\n movieCount\n }\n }","variables":{"q":"]] .. args.id1 .. [["},"operationName":"QuickSearch"}]]




local x = http.postz(url, headers, params)


--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})


 for id, type, name, year in string.gmatch(x, '{"slug_url":"(.-)".-"type":"(.-)".-"russian":"(.-)".-"year":(.-),') do

	
	t['view'] = 'simple'
	
	table.insert(t, {title = name .. ' ' .. year, mrl = '#stream/q=kinozentv&id=' .. id .. '&id1=' .. type})

table.insert(t, {title = 'Vibix ' .. name .. ' ' .. year, mrl = '#stream/q=kinozentvib&id=' .. id .. '&id1=' .. type})

end

elseif args.q == 'kinozentvib' then



local headerss = {
    ["Host"] = "kinozenhd.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://kinozenhd.com/" .. args.id1 .. "/" .. args.id,
    ["Content-Type"] = "application/json",
    ["Origin"] = "https://kinozenhd.com",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1787369344$o2$g0$t1787369344$j60$l0$h0; _ga=GA1.1.2092185324.1786808761; _ym_uid=1786808762143794613; _ym_d=1786808762; _ym_isad=2; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4",
    ["Content-Length"] = "0"
}


    local headers = {
    ["Host"] = "kinozenhd.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",

    ["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1785557337$o2$g1$t1785558906$j60$l0$h0; _ga=GA1.1.731350005.1785517557; _ym_uid=1785517560813624399; _ym_d=1785517560; _ym_isad=2; kz_rec_session=9d3debe8-dda6-43dd-a6b5-24c1a0f28386; _ym_visorc=w; _pow=0558d2ba6d620b6a18151fc646ffd44cd3d38fee1b4b1487; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTczODQsImV4cCI6MTc4NTY0Mzc4NH0.vM0PjntrT2TxdzGymyFirilB7TIW1s7ZqS9ML9LfI7jwZoP2wToi2LzyyK5j_r6_; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiM2YwMGI5ZGItNzUzNS00NzBhLWJkOTItMTBkNzQwOTcwNWU5IiwiaWF0IjoxNzg1NTU3Mzg0LCJleHAiOjE3ODgxNDkzODR9.cuIsJ6Gv9QvDxn2Kc_h2uLqFWgh0wVnpBNHSSPoXSrQZ61_Par6yWTcUvgz8gJAqQYLr4YzUEKZ47NnBox1kFQ"
}


--https://proxy4.rte.net.ru/

--local cold = 'https://kinozenhd.com/api/cold-prefetch/' .. args.id
--.. '?force=1&reason=hls_manifest'

table.insert(t, {title = 'https://kinozenhd.com/api/cold-prefetch/' .. args.id, mrl = 'https://kinozenhd.com/api/cold-prefetch/' .. args.id})

local x = http.postz('https://kinozenhd.com/api/cold-prefetch/' .. args.id, headers)

--if x then

--local media = 'https://kinozenhd.com/api/media-tree/' .. args.id

--local x = http.getz(media, headers)

--url = url_for()

--url = urldecode(url)

table.insert(t, {title = x, mrl = x})

--table.insert(t, {title = media, mrl = media})

--end



elseif args.q == 'kinozentv' then








local headers = {
["Pragma"] = "no-cache",
["Cache-Control"] = "no-cache",
["sec-ch-ua"] = '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
["sec-ch-ua-mobile"] = "?0",
["sec-ch-ua-platform"] = "Windows",
["DNT"] = "1",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,uk-UA;q=0.8,uk;q=0.7,en-US;q=0.6,en;q=0.5",
["Priority"] = "u=1, i",
    ["Cookie"] = "_ym_uid=1785518434798914300; _ym_d=1785518434; _ym_isad=2; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTQ5OTUsImV4cCI6MTc4NTY0MTM5NX0.uEmKY2reEyjfq7sAsnPIKS3BcYiouMaoMCRtj4NR6hUOLy1lJFr3l9VPXP1VvGCk; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiMjI4NWNkZWItODljZS00NDIxLWJmNjEtZWRhMjQzOGQwNGMzIiwiaWF0IjoxNzg1NTU0OTk1LCJleHAiOjE3ODgxNDY5OTV9.SrqdAB7uXNHNZjY3xUkI4b2u5bzTVlNyvCapakcapvv1tNdMBpNqNa_UhAFw2cjGzGY5P6c3XdKqRmnxR5UAYA; kz_rec_session=37cd0eb3-3199-4128-b24a-262910f4fbe9; _pow=ea40524e6453a3660e1857eedecad8ab5bab81313999c261; _ym_visorc=w",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-origin",
["Sec-Fetch-Storage-Access"] = "active",
["Referer"] = "https://kinozentv.com/" .. args.id1 .. "/" .. args.id
}


    
local headerss = {
    ["Host"] = "kinozentv.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Referer"] = "https://kinozentv.com/" .. args.id1 .. "/" .. args.id,
["Authorization"] = "Bearer eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU5MTQ1NTQsImV4cCI6MTc4NjAwMDk1NH0.Vn1M5xXzSmJYSNIYYnMCsmnZL5NxCCkeYaXNu4hrIhnhrE7wryE-wmv0EYKmMQpt",

["Cookie"] = "_ga_BL5HHSQFP3=GS2.1.s1785914549$o5$g1$t1785914574$j35$l0$h0; _ga=GA1.1.731350005.1785517557; _ym_uid=1785517560813624399; _ym_d=1785517560; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiM2YwMGI5ZGItNzUzNS00NzBhLWJkOTItMTBkNzQwOTcwNWU5IiwiaWF0IjoxNzg1NTU3Mzg0LCJleHAiOjE3ODgxNDkzODR9.cuIsJ6Gv9QvDxn2Kc_h2uLqFWgh0wVnpBNHSSPoXSrQZ61_Par6yWTcUvgz8gJAqQYLr4YzUEKZ47NnBox1kFQ; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU5MTQ1NTQsImV4cCI6MTc4NjAwMDk1NH0.Vn1M5xXzSmJYSNIYYnMCsmnZL5NxCCkeYaXNu4hrIhnhrE7wryE-wmv0EYKmMQpt; _ym_isad=2; kz_rec_session=e2c2ed68-0aac-4c6f-aeaf-acd25785bba1; _ym_visorc=w; _pow=7f221a6bcaceaaca2d001a87d8aebf32fd5229aa532c3f6b"
}

local url1 = 'https://kinozentv.com/api/alloha-tree/' .. args.id

local x = http.getz(url1, headerss)


local episodes = string.match(x, '{"kind":"movie","episodes":%[(.-)]}]')

for voice, qualities in string.gmatch(episodes, '{"voice":"(.-)".-"qualities":%[(.-)]') do

for qual, id in string.gmatch(qualities, '{"quality":"(%d+p)".-"move_id":"(.-)"') do




local url2 = 'https://kinozentv.com/api/alloha-playback/start/' .. args.id .. '?move_id=' .. id .. '&q=' .. qual

--https://api.potok.rip/api/proxy?url=https://kinozentv.com/api/alloha-playback/start/54736-film-chuzhoy-1979?move_id=alloha:m:t62&q=1080p

local x = http.getz(url2, headerss)

--	t['view'] = 'simple'
	
--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url2, mrl = '#stream/q=kinozentvm&id=' .. args.id .. '&id1=' .. id .. '&id2=' .. qual})


table.insert(t, {title = x, mrl = x})

end
end

elseif args.q == 'kinozentvm' then

local headers = {
    ["Host"] = "kinozentv.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Referer"] = "https://kinozentv.com/" .. args.id1 .. "/" .. args.id,
    ["Connection"] = "keep-alive",
        ["authorization"] = "Bearer eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTQ5OTUsImV4cCI6MTc4NTY0MTM5NX0.uEmKY2reEyjfq7sAsnPIKS3BcYiouMaoMCRtj4NR6hUOLy1lJFr3l9VPXP1VvGCk",
    ["Cookie"] = "_ym_uid=1785518434798914300; _ym_d=1785518434; _ym_isad=2; kz_session=eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJhY2Nlc3MiLCJpYXQiOjE3ODU1NTQ5OTUsImV4cCI6MTc4NTY0MTM5NX0.uEmKY2reEyjfq7sAsnPIKS3BcYiouMaoMCRtj4NR6hUOLy1lJFr3l9VPXP1VvGCk; kz_refresh=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImRpbWFzdWh1bSIsInN1YiI6IjZhNmQ2NWQ1YzMzZWNhNjk0YzZiN2Y1MyIsInJvbGVzIjoiVVNFUiIsInVzZXJTdGF0dXMiOiJBQ1RJVkUiLCJ0eXAiOiJyZWZyZXNoIiwianRpIjoiMjI4NWNkZWItODljZS00NDIxLWJmNjEtZWRhMjQzOGQwNGMzIiwiaWF0IjoxNzg1NTU0OTk1LCJleHAiOjE3ODgxNDY5OTV9.SrqdAB7uXNHNZjY3xUkI4b2u5bzTVlNyvCapakcapvv1tNdMBpNqNa_UhAFw2cjGzGY5P6c3XdKqRmnxR5UAYA; kz_rec_session=37cd0eb3-3199-4128-b24a-262910f4fbe9; _pow=ea40524e6453a3660e1857eedecad8ab5bab81313999c261; _ym_visorc=w",
["Content-Type"] = "application/json",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4",
   ["Pragma"] = "no-cache",
   ["Cache-Control"] = "no-cache"
}

local graphql = 'https://kinozentv.com/api/graphql'


local params = [[{"query":"mutation RecordWatchProgress(\n $slug: NonEmptyString!\n $progressSec: Int!\n $durationSec: Int\n $seasonNumber: Int\n $episodeNumber: Int\n ) {\n recordWatchProgress(\n slug: $slug\n progressSec: $progressSec\n durationSec: $durationSec\n seasonNumber: $seasonNumber\n episodeNumber: $episodeNumber\n )\n }","variables":{"slug":"]] .. args.id .. [[","progressSec":30,"durationSec":6975,"seasonNumber":null,"episodeNumber":null},"operationName":"RecordWatchProgress"}]]




local x = http.postz(graphql, headers, params)


local url = 'https://kinozentv.com/api/alloha-playback/start/' .. args.id .. '?move_id=' .. args.id1 .. '&q=' .. args.id2

local x = http.getz(url, headers)

local url1 = string.match(x,'(/media.-m3u8)')

local x = http.getz('https://kinozentv.com' .. url1, headers)


--url = url_for(x)

--url = urldecode(url)

table.insert(t, {title = 'https://kinozenhd.com' .. url1, mrl = 'https://kinozenhd.com' .. url1})

local url2 = string.match(x,'(/media/alloha/object/.-)\n')

--local x = conn:load('https://kinozentv.com' .. url2)





--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})



local x = http.getz('https://kinozentv.com' .. url2, headers)

local url3 = string.match(x,'(/media/alloha/object/.-)"') 

local x = http.getz('https://kinozenhd.com' .. url3, headers)

--url = url_for(x)

--url = urldecode(url)

--table.insert(t, {title = url, mrl = url})
--t['view'] = 'simple'



--table.insert(t, {title = 'https://kinozenhd.com' .. url1, mrl = 'https://kinozenhd.com' .. url1})

--table.insert(t, {title = 'https://kinozenhd.com' .. url2, mrl = 'https://kinozenhd.com' .. url2})

table.insert(t, {title = 'https://kinozentv.com' .. url3, mrl = 'https://kinozentv.com' .. url3})


elseif args.q == 'vibexx' then
 
 
 local x = conn:load('https://lampa.li/lite/vibix?kinopoisk_id=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 --table.insert(t, {title = 'https://lampa.li/lite/vibix?kinopoisk_id=' .. args.id3 .. '&uid=bwygkgxn', mrl = 'https://lampa.li/lite/vibix?kinopoisk_id=' .. args.id3 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'})
 
 --x = string.gsub(x, '&quot;', '"')

 
 for stream, title in string.gmatch(x,'<div class="videos__item videos__movie.-method.-streamquality(.-)].-videos__item%-title.->(.-)<') do
 
 
 
 for qual, url in string.gmatch(stream, 'quality.-(%d+p).-url.-(http.-)&#') do
 
 t['view'] = 'list'

 table.insert(t, {title = '(' .. qual .. ') ' .. title, mrl = url, image = '#self/movie.png'})

end
end

x = string.gsub(x, '\\u0026', '&')

for season, title in string.gmatch(x,'<div class="videos__item videos__season.-method.-link.-(http.-)&#.-videos__season%-title">(.-)<') do

local x = conn:load(season .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

for stream, title1 in string.gmatch(x,'<div class="videos__item videos__movie.-method.-streamquality(.-)].-videos__item%-title.->(.-)<') do
 
 
 
 for qual, url in string.gmatch(stream, 'quality.-(%d+p).-url.-(http.-)&#') do
 
 t['view'] = 'list'

 table.insert(t, {title = '(' .. qual .. ') ' .. title .. ' ' .. title1, mrl = url, image = '#self/movie.png'})

end
end
end




elseif args.q == 'videx' then
 
-- t['view'] = 'list'
 
 local x = conn:load('https://kinobd.net/api/player/search?q=' .. args.id3 .. '&type=kp_id&page=1')
 
 x = string.gsub(x, '"film"', '"movie"')
 x = string.gsub(x, '"serial"', '"tv"')

 
 --table.insert(t, {title = 'https://kinobd.net/api/player/search?q=' .. args.id3 .. '&type=kp_id&page=1', mrl = 'https://kinobd.net/api/player/search?q=' .. args.id3 .. '&type=kp_id&page=1'})
 
 for imdb, tmdb, media in string.gmatch(x,'"imdb_id":"(.-)","tmdb_id":(.-),.-"type":"(.-)"') do
 
 
 
 --local x = conn:load('http://fxmlparsers.in.net/VilkaDB/?id=search&search=' .. urlencode(args.id1) .. '&descitem%20year=' .. args.id2)


--local x = conn:load('https://api.potok.rip/api/media/search?query=' .. urlencode(args.id1) .. '&subtitle=' .. args.id2 .. '&language=ru')


--for id, media in string.gmatch(x,'%[{"id":(.-),.-"mediaType":"(.-)"') do




--for id, media, date in string.gmatch(x, '"fxml".-{"logo.-"playlist_url":"http.-&tid=(.-)&media_type=(.-)".-descitem year.->(.-)<') do

if tmdb then


lampa = string.gsub(tmdb,'^(.-)','http://lampa.mx/?card=') .. '&media=' .. media .. '&source=tmdb'

--table.insert(t, {title = id2, mrl = id2})


lampa = base64.encode(lampa)

lampa = urlencode(lampa)
--http://lampa.mx/?card=202555&media=movie&source=tmdb




--local x = conn:load('https://kinobd.net/api/films/search/kp_id?q=' .. args.id3 .. '&page=1')

--local x = conn:load('https://apitmdb.cubnotrip.top/3/' .. media .. '/' .. id.. '?append_to_response=content_ratings,release_dates,external_ids,keywords,alternative_titles&api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru&page=1&email=')


--https://apitmdb.cubnotrip.top/3/movie/kp_386?append_to_response=content_ratings,release_dates,external_ids,keywords,alternative_titles&api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru&page=1&email=

--table.insert(t, {title = 'https://www.imdb.com/find/?q=' .. urlencode(args.id1) .. '+' .. args.id2, mrl = 'https://www.imdb.com/find/?q=' .. urlencode(args.id1) .. '+' .. args.id2})


--local x = conn:load('https://api.manhan.one/externalids?kinopoisk_id=' .. args.id3)
  

--  local imdb = string.match(x, 'data%-testid="inline%-watched%-button%-(.-)"')
  
   
-- local imdb = string.match(x, '"imdb_id":"(.-)"')

if imdb then

local headerss = {
    ["Host"] = "api.lampa.stream",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "cf_clearance=OOYmoeM_PmBabhVZv4KVB83PiYN1Y5CDwZtIV3oi7kM-1778248424-1.2.1.1-N2lBdTioGB78gQ3NncjNIZLg4QgREKKpt084eRzADwLxOhYjJDCIDAon1uTPQC8w0o.4Hn9IbG0PJk251yXQpX4NqFoLtOf0A968CvEXsU0HFkwbNkn3jDgpyMl7MBPfYkHjS3RdRKe_XRdXKaxIH8ZcHGr0QsIzLsoan8IPVQTb_D3gEnSd06eyjA0cPqF3L7Zm6X32zuHBnT6Q15DvO3kjqbLboPz48ZnDuwKPl2KOl3cwrC9o01YKn964e1_iPWyCXVoEpZvxNmbJVWFwwNs7Ab.P2qsOjWOVA6Oh7TvMqUqCg.QQNV0bbBpBnOg.88px9FWPJcShpAsYkvSuOA",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1"
}




local headers = {["Host"] = "api.lampa.stream",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
      ["Referer"] = "http://api.lampa.stream/",
      ["Cookie"] = "cf_clearance=OOYmoeM_PmBabhVZv4KVB83PiYN1Y5CDwZtIV3oi7kM-1778248424-1.2.1.1-N2lBdTioGB78gQ3NncjNIZLg4QgREKKpt084eRzADwLxOhYjJDCIDAon1uTPQC8w0o.4Hn9IbG0PJk251yXQpX4NqFoLtOf0A968CvEXsU0HFkwbNkn3jDgpyMl7MBPfYkHjS3RdRKe_XRdXKaxIH8ZcHGr0QsIzLsoan8IPVQTb_D3gEnSd06eyjA0cPqF3L7Zm6X32zuHBnT6Q15DvO3kjqbLboPz48ZnDuwKPl2KOl3cwrC9o01YKn964e1_iPWyCXVoEpZvxNmbJVWFwwNs7Ab.P2qsOjWOVA6Oh7TvMqUqCg.QQNV0bbBpBnOg.88px9FWPJcShpAsYkvSuOA",
    ["Content-Type"] = "application/json; charset=utf-8",
    Connection = "close",
    Server = "cloudflare",
    ["Server-Timing"] = {
        'cfCacheStatus;desc="MISS"',
        "cfEdge;dur=9,cfOrigin;dur=31"
    },
    ["Vary"] = "Accept-Encoding",

    ["X-Powered-By"] = "modss",
    ["X-RateLimit-Limit"] = 40,
    ["X-RateLimit-Remaining"] = 38,
    ["X-RateLimit-Reset"] = 1778251762,
    ["X-Response-Time"] = "5.85ms",
    ["Access-Control-Allow-Headers"] = "*",
    ["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS",
    ["Content-Encoding"] = "gzip",
    ["Cache-Control"] = "max-age=86400",
    ["cf-cache-status"] = "MISS",
    ["CF-RAY"] = "9f8944c5dddf6d26-FRA"
}


--args.id1 = string.gsub(args.id1, ' ', '%%20')


--https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/807031/tt16431404/dW5kZWZpbmVk/aHR0cDovL2xhbXBhLm14Lz9jYXJkPTEzMTg0NDcmbWVkaWE9bW92aWUmc291cmNlPXRtZGI%3D?ips=2a0d:5600:9:3003:f35c:e2d8:1376:a2ad&uid=7b40eb0595118e5649d10dcda_1db58ea969d1843cbaa506a8&ip=185.228.133.239&title=На%20вершине

--https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/386/tt0078748/dW5kZWZpbmVk==/aHR0cDovL2xhbXBhLm14Lz9jYXJkPQ==?ip=185.228.133.239&title=чужой

--https://proxy4.rte.net.ru/

local url = 'https://proxy4.rte.net.ru/http://api.lampa.stream/videx/sId/mds/' .. args.id3 .. '/' .. imdb .. '/dW5kZWZpbmVk/' .. lampa .. '?ip=185.228.133.239&title=' .. urlencode(args.id1)



--local x = http.getz(url, headers)

local x = conn:load(url)



local slist = string.match(x,'"folder":%[(.-)],"duration"')

if slist then

for qual, title in string.gmatch(slist, 'method.-play.-"qualitys":{(.-)}.-"vast_msg":".-","voice_name":"(.-)"') do

for  total, url1 in string.gmatch(qual, '"(%d+p)":"(.-)"') do
  

  t['view'] = 'list'


--'https://proxy4.rte.net.ru/' .. 

 table.insert(t, {title = '(' .. total .. ') ' .. title, mrl = 'https://proxy4.rte.net.ru/' .. url1, image = '#self/movie.png'})

end
end
end




for qual, season, episod, title in string.gmatch(x, '"method":"play","title":"Серия.-"qualitys":{(.-)}.-"vast_msg":".-","season":"(.-)","episode":(.-),"voice_name":"(.-)"') do

for  total, url1 in string.gmatch(qual, '"(%d+p)":"(.-)"') do
  

  t['view'] = 'list'


--'https://proxy4.rte.net.ru/' .. 

 table.insert(t, {title = '(' .. total .. ') Сезон-' .. season .. ' серия-' .. episod .. ' ' .. title, mrl = 'https://proxy4.rte.net.ru/' .. url1, image = '#self/movie.png'})

end
end
end
end
end





elseif args.q == 'vibix1' then
  
  
  
--  https://reyohoho-old.onrender.com/#386
  
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  
 -- for url in string.gmatch(x, '(<option player.-</option>)') do
  
  
 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed/.-)"') do
 
 
 
--  embedCode=https://graphicslab.io/sdk/v2/rendex-sdk.min.js
 
 --https://cors.fx666.workers.dev:8443/http://91.142.72.69:9833/lite/vibix?title=чужой&year=1979 
 
 --http://fork.tutkino.fun/xml/cdn/iframe.php?link=https://667983605.videoframe2.com/embed/4539
 
 
 --http://fork.tutkino.fun/xml/cdn/iframe.php?link=https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed/4539
 
-- https://juija.manhan.one/lite/vibix/video.m3u8?play=true&url=&referer=https://667983605.videoframe2.com/api/v1/embed/4539&account_email=daniulov.d@yandex.ru&uid=zqos1vw0&nws_id=s7vl7ckpsmoejlwykybs3th4tky6f5ny
 
 --https://672431256.videoframe2.com/api/v1/embed-kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz&embedCode=https://graphicslab.io/sdk/v2/rendex-sdk.min.js


--https://m.kinobadi.im/pleer_4/pleer.php?id=/api/v1/embed/39378?domain=kino-arhiv.ucoz.club&iframe_url=https%3A%2F%2Friver-3-329.kinescopecdn.net%2F669681541%2Fembed-kp%2F5939991%3Fnc%3D491766&nc=491766

--https://m.kinobadi.im/pleer_4/pleer.php?id=/embed/4539


--https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-1-2110.kinescopecdn.net/hls/4000/4539/4539_1080p.mp4/index.m3u8

--https://river-1-2110.kinescopecdn.net/667983605/hls/4000/4539/4539_1080p.mp4/index.m3u8

--https://river-1-2110.kinescopecdn.net/hls/4000/4539/4539_1080p.mp4/index.m3u8?expires=1771002013&sign=0e528aa9c454fb4e67c4b1b887b60c49&ts=1770915600


--https://185.188.183.182/iptv/kinotochka/lesenkinolite46.php?link=https://river-3-329.kinescopecdn.net/667983605/embed/4539&nc=491748


--http://fork.tutkino.fun/xml/cdn/iframe.php?link=https://river-3-329.kinescopecdn.net/667983605/embed/4539&nc=491748

--https://cors.fx666.workers.dev:8443/https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed/4539&nc=491748
 
 --https://cors.fx666.workers.dev:8443/https://667983605.videoframe2.com/api/v1/embed-kp/386?domain=gokino.su&p=cUQROp1WbVlcWowHVUBTdwjIGg1VDF0EUoSDNUDAcczDXQQVSQVTWwTVKQ1GcthCh42SGZAHAUREgsVK&v=1
 
-- https://cors.fx666.workers.dev:8443/https://667983605.videoframe2.com/api/v1/embed/?domain=gokino.su&p=cUQROp1WbVlcWowHVUBTdwjIGg1VDF0EUoSDNUDAcczDXQQVSQVTWwTVKQ1GcthCh42SGZAHAUREgsVK&v=1
 
 
 --http://185.188.183.182/iptv/kinotochka/lesenkinolite46.php?link=https://river-3-329.kinescopecdn.net/667983605/embed/4539&page=postmd5
 
 
 
-- https://apn-latest.onrender.com/https://672431256.videoframe2.com/api/v1/embed/4539/vibixinscode.html
 
 
-- https://apn-latest.onrender.com/https://river-3-329.kinescopecdn.net/667983605/embed/4539/vibixinscode.html
 
-- https://672431256.videoframe2.com/api/v1/embed/4539/vibixinscode.html
 
 --https://672431256.videoframe2.com/embed/4539/vibixinscode.html
 
 --https://apn-latest.onrender.com/https://river-3-329.kinescopecdn.net/667983605/embed/4539
 --https://667983605.videoframe2.com/api/v1/ad-tags?domain=gokino.su&iframe_url=https%3A%2F%2F667983605.videoframe2.com%2Fembed%2F4539&nc=491705&_=5i6gi5rpqqx
 
 --https://apn-latest.onrender.com/https://672431256.videoframe2.com/api/v1/embed-kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz
 
 --https://672431256.videoframe2.com/api/v1/embed-kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz
 
 
-- https://672431256.videoframe2.com/api/v1/embed/4539?domain=reyohoho.gitlab.io&iframe_url=https://672431256.videoframe2.com/embed/4539&nc=491719

--https://neomovies.site/api/player/vibix/embed/?src=https://672431256.videoframe2.com/embed/4539&nc=491719

 
 --https://kinescope.io/embed/46wjDpcANy2CqZFg8r86Ug/720p
 
 --https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed/UUQRLlFVXYSDzUTHb92Qa1VVMkgDEsTUDQ1GcthCh42SGZAHAUREgsVK
 
 
 
 --https://672431256.videoframe2.com/api/v1/embed-serials/5523?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com/embed-serials/5523
  
--https://river-3-329.kinescopecdn.net/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed-kp/386?nc=491717&nc=491717
 

 
 
-- http://river-3-329.kinescopecdn.net/api/v1/embed/39378?domain=kino-arhiv.ucoz.club&iframe_url=https%3A%2F%2Friver-3-329.kinescopecdn.net%2F669681541%2Fembed-kp%2F5939991%3Fnc%3D491766&nc=491766
 
 
 
 --https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://667983605.videoframe2.com/embed/4539
 
-- &p=UUQRLlFVXYSDzUTHb92Qa1VVMkgDEsTUDQ1GcthCh42SGZAHAUREgsVK&v=1
 
 
 
 --https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https%3A%2F%2F667983605.videoframe2.com%2Fembed%2F4539&sig=2e46e50a334f897b7bdb7c65a9778b114114114114114114114114114114c396cec89dc8c5d29a9712dc6c8c5f4c5f4c5f493c894969ffffcaace969cc994c6d2101d5f29895fccb&ts=1771349966&nonce=k9mwi91jvte&nc=492041
 
 
 
 local x = conn:load('https://667983605.videoframe2.com/api/v1' .. url .. '?domain=gokino.su&iframe_url=https://667983605.videoframe2.com' .. url)
 
 table.insert(t, {title = 'https://667983605.videoframe2.com/api/v1' .. url .. '?domain=gokino.su&iframe_url=https://667983605.videoframe2.com' .. url, mrl = 'https://667983605.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://667983605.videoframe2.com' .. url})
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slis = string.gsub(slist, ',', '"')
 slist = string.gsub(slist, ';', '"')
 
for total, title, url in string.gmatch(slist, '%[(480p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
	
t['view'] = 'simple'
 
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 
 
for total, title, url in string.gmatch(slist, '%[(720p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"%{.-}http.-"({.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 


for total, title, url in string.gmatch(slist, '%[(1080p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end

end
    end
  
  
  
  
  
  
  
   
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  

 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed%-serials.-)"') do
 

 local x = conn:load('https://667983605.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://667983605.videoframe2.com' .. url)
  
 -- table.insert(t, {title = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url, mrl = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url})
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slist = string.gsub(slist, ',', '"')
-- slist = string.gsub(slist, ';', '"')
slist = string.gsub(slist, ']{', '"name":')
slist = string.gsub(slist, ';{', '"name1":')

-- for total1 in string.gmatch(slist, '"title":"(Сезон.-)"') do
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
    end
  end





--http://178.20.46.40:12600

--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979

--https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=386

--http://178.20.46.40:12600/lite/mirage/video?id_file=911588&token_movie=a6ef0986c7558c5792c3ad19d43611

--http://78.40.199.67:10630/lite/mirage/video?id_file=1265937&token_movie=9de4740ef5b4ff67555ff296494e31&q=1080p



--http://78.40.199.67:10630/proxy/6f687b82601c0dd158c9e0e926e86dba.m3u8



--http://78.40.199.67:10630/lite/mirage/stream.m3u8?id=1265937&q=1080p

--https://lampa.oksibutch.ru/lite/mirage/stream.m3u8?id=1265937&q=1080p


elseif args.q == 'veoveo' then
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
   
--table.insert(t, {title = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1), mrl = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1)})
      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'list'

   table.insert(t, {title = 'veoveo :' .. tolazy(total), mrl = url2, image = '#self/movie.png'})

       
    end
     
--  local x = conn:load('http://178.20.46.40:12600/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
 
 

 
 
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do
     
   --  url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600') 
     
     
     local x = conn:load(url2)

--table.insert(t, {title = url2, mrl = url2})

for  url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'list'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total4), mrl = url3, image = '#self/movie.png'})

      end 
      end


elseif args.q == 'kinopub' then
 
-- http://fxmlparsers.in.net/https://kino.pub/?code=z2ibsw9dywo0n01eeibym950w1afbtz6&act=enter
 
 
-- https://ab-ze.xyz/api/hls/alloha?type=film&kp=386&access_token=&quality=&translation=Дублированный
 
 --https://cors.bwa.workers.dev/http://fork.pet/search/result?field=title&search=%D0%93%D1%80%D0%B5%D1%88%D0%BD%D0%B8%D0%BA%D0%B8%26year%3D2025&access_token=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
-- http://go.forkplay.me?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&code=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
--  http://fxmlparsers.in.net/https://kino.pub/?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&code=9ymeff8cft97lcdjswbuww9ri9of2bh1
  
--https://cors.bwa.workers.dev/https://api.srvkp.com/v1/items/search?q=чужой&year=1979&field=title&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6
  
 -- http://parsers.appfxml.com/https://kino.pub/?cat=search&search=Чужой&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6
  
  
 --http://parsers.appfxml.com/https://kino.pub/?cat=view&id=118846&code=9ymeff8cft97lcdjswbuww9ri9of2bh1



 --https://api.pushbr.com/v1/watching?id=118846&access_token=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
 
 --https://app.service-kp.com/v1/items/search?q=чужой&year=1979&field=title&access_token=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
 --https://api.srvkp.com/v1/items/search?q=чужой&year=1979&field=title&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6
 
--http://fxmlparsers.in.net/https://kino.pub/?cat=search&search=%D0%93%D1%80%D0%B5%D1%88%D0%BD%D0%B8%D0%BA%D0%B8%26year%3D2025&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6

-- http://fxmlparsers.in.net/https://kino.pub/?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9%26year%3D1979&code=z2ibsw9dywo0n01eeibym950w1afbtz6
 
 
 --http://parsers.appfxml.com/https://kino.pub/?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9%26year%3D1979&code=9ymeff8cft97lcdjswbuww9ri9of2bh1
 

 
 
 --http://fork.pet/library/list?title=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&year=1979&type=movie&type=serial
 
--local x = conn:load('http://parsers.appfxml.com/https://kino.pub/?cat=search&search=' .. urlencode(args.id1 .. '&year=') .. args.id2 .. '&code=9ymeff8cft97lcdjswbuww9ri9of2bh1')

  local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=movie' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

--table.insert(t, {title = url1 .. '&box_mac=acace24b8434', mrl = url1 .. '&box_mac=acace24b8434'})


for url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[Воспроизвести]].-<playlist_url><!%[CDATA%[(http.-)]]') do


      local x = conn:load(url2 .. '&box_mac=acace24b8434')

 for title, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title), mrl = url3})
   
   end
   end
 end




 
 local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=serial' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

 
 
   
   for title, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   local x = conn:load(url2 .. '&box_mac=acace24b8434')
   
  for title1, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url><!%[CDATA%[(http.-)]]') do
  
  local x = conn:load(url3 .. '&box_mac=acace24b8434')
  
   for title2, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title) .. ' ' .. tolazy(title1) .. ' (' .. tolazy(title2) .. ')', mrl = url4})
   end
   end
   end
   
end
   

elseif args.q == 'kinopubtv' then
 
--https://beta.l-vid.online/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979&uid=bwygkgxn

--https://akter-black.com/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979&uid=zjs1uqrq&nws_id=thggv0skixm3hym58e5s9cyiqubwtjf0

--https://apn10.akter-black.com/https://api.srvkp.com/manifest/hls4/aWQ9Mjc0Nzc3NjsxNTAwNDA1OTY3OzM3MzQxODI2OzExNDMyNjU7MTc4MTk2MzMzNSZoPXFmTXRkWV80bEpsNFZSUEhwQ1N6eXcmZT0xNzgyMDQ5NzM1/1143265.m3u8?loc=ru


local url = 'https://lampa.li/lite/kinopub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d'


local x = conn:load(url)
   
  
  x = string.gsub(x, '\\u0026', '&')


  for qual, total in string.gmatch(x, '<div class="videos__item videos__movie.-quality.-{(.-)}.-class="videos__item%-title">(.-)</div>') do
  
  --local slist = string.match(x, 'quality.-{(.-)}')
      
   for  total1, url2 in string.gmatch(qual,'(%d+p).-http.-(/proxy.-m3u8)') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
   url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     
      t['view'] = 'list'


   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total), mrl = url2, image = '#self/movie.png'})

       
    end
    end
 
 
 for  url2, total2 in string.gmatch(x, 'class=.-videos__item videos__season.-method.-url.-(http.-)&#.-videos__season%-title.->(.-сезон)<') do
 
 
 url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 

     
     local x = conn:load(url2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
 
 x = string.gsub(x, '\\u0026', '&')
     x = string.gsub(x, '\\u002B', '+')
 
 
    for id, id1, id2, id3, total3 in string.gmatch(x, 'videos__button selector.-method.-url.-http.-postid=(.-)&title=(.-)&.-&s=(.-)&t=(.-)&.->(.-)</div>') do


   t['view'] = 'list'

    

table.insert(t, {title = tolazy(total2) .. ' ' .. tolazy(total3), mrl = '#stream/q=kinopubs&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = '#self/movie.png'})


      end 
      end

    
    elseif args.q == 'kinopubs' then
   
   local x = conn:load('https://lampa.li/lite/kinopub?rjson=False&postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&s=' .. args.id2 .. '&t=' .. args.id3 .. '&codec=aac' .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')
   


    for qual, total in string.gmatch(x, '<div class="videos__item videos.-quality.-{(.-)}.-class="videos__item%-title">(.-)</div>') do
  
 -- local x = string.match(x, 'quality.-{(.-)}')
   
   for  total1, url2 in string.gmatch(qual,'(%d+p).-http.-(/proxy.-m3u8)') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
      url2 = string.gsub(url2, '^(.-)', 'https://s.lampa.li') 
     


      t['view'] = 'list'


   table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2, image = '#self/movie.png'})

       
    end
    end




--https://lamp-movie.ru/lite/kinopub?title=чужой-1979




elseif args.q == 'filmix2' then

  -- https://nexsw.stull.xyz/lite/filmix?kinopoisk_id=386&title=чужой&year=1979&account_email=daniulov.d@yandex.ru 




local x = conn:load('https://akter-black.com/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
--.. '&account_email=daniulov.d@yandex.ru')


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://nexsw.stull.xyz')
  
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'list'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
   
   end
   end
 
    
    --     for  total3, url4, total2 in string.gmatch(x, '"(.-p)":"http.-mp4.-(http.-mp4).-class="videos__item%-title">(.-)<') do
-- total3 = string.gsub(total3, ',"', '')
 --   t['view'] = 'simple'
--    table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
    
--end
-- end


    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
 
    
    if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
   
  if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
 
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
  
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'list'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4, image = '#self/movie.png'})
   
   end
   end
   
end
end
   
   
   
   
 --  https://rutube.ru/api/search/video/?content_type=video&duration=movie&query=чужой&years=1979
   
   elseif args.q == 'rutube' then


--http://78.40.195.218:9118/lite/rutubemovie?title=чужой&year=1979

		local x = conn:load('https://rutube.ru/api/search/video/?content_type=video&duration=movie&query=' .. urlencode(args.id1 .. ' ' .. args.id2))
  
  

   
   for id, title in string.gmatch(x, '{"id":"(.-)","action_reason".-"title":"(.-)"') do
   
 --  if title == args.id1 then
  
 t['view'] = 'list'

   table.insert(t, {title = title, mrl = '#stream/q=rutubes&id=' .. id, image = '#self/movie.png'})
    end
-- end
 
 elseif args.q == 'rutubes' then
 
 local x = conn:load('http://kb-team.club/msx/kinofeed/viewtube.php?id=' .. args.id)
 
       x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
	
 
 

 
-- http://kb-team.club/msx/kinofeed/viewtube.php?id=37d5799de2cf4fcc86515fa9461bd296
   
   
   for url, title in string.gmatch(x, '"action":"video.-(http.-)".-"playerLabel":"(.-)"') do
  
  url = string.gsub(url, '\\', '')
  
   
   t['view'] = 'list'
   
   table.insert(t, {title = title, mrl = url, image = '#self/movie.png'})
    end
   
   elseif args.q == 'vkmovie' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lam.maxvol.pro/lite/vkmovie?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
     

     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro')
      url4 = string.gsub(url4, '\\u002B', '+')
       t['view'] = 'list'

   table.insert(t, {title = '(' .. total3 .. ') ' .. tolazy(total2), mrl = url4, image = '#self/movie.png'})
    end
     end  


elseif args.q == 'remux' then



local x = conn:load('https://lampa.li/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&token=a46f8a8a-8878-4fa5-8554-8296ba62260d')

--if x then

--table.insert(t, {title = 'https://lampa.li/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn', mrl = 'http://beta.l-vid.online/lite/zona?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&uid=bwygkgxn'})


for url, total in string.gmatch(x, '<div class="videos__item videos__movie.-method.-stream.-(http.-)&.-videos__item%-title.->(.-)<') do

url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
t['view'] = 'list'
 
 --table.insert(t, {title = 'http://z01.online' .. url, mrl = 'http://z01.online' .. url})

table.insert(t, {title = tolazy(total), mrl = url, image = '#self/movie.png'})


     end  

--http://z01.online/lite/remux/movie?linkid=8cTT/gvBR4Km3N&quality=1080p&title=%D0%9F%D0%B5%D1%80%D0%B2%D1%8B%D0%B9+%D0%BC%D1%81%D1%82%D0%B8%D1%82%D0%B5%D0%BB%D1%8C&original_title=


--http://z01.online/lite/remux/movie?linkid=R9zZ/s1tzUV1ZS&quality=1080p&title=%d0%9f%d0%b5%d1%80%d0%b2%d1%8b%d0%b9+%d0%bc%d1%81%d1%82%d0%b8%d1%82%d0%b5%d0%bb%d1%8c%3a+%d0%9f%d1%80%d0%be%d1%82%d0%b8%d0%b2%d0%be%d1%81%d1%82%d0%be%d1%8f%d0%bd%d0%b8%d0%b5&original_title=Captain+America%3a+Civil+War&uid=bwygkgxn

		local x = conn:load('https://z01.online/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

--table.insert(t, {title = 'http://z01.online/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://z01.online/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})

      for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"link".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')
      
      

    --   url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
   
   
   
for  url3, total1 in string.gmatch(x, '<div class="videos__item videos.-"method".-"call".-"url".-(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url3 = string.gsub(url3, '\\u0026', '&')
      url3 = string.gsub(url3, '\\u002B', '+')
      
 
 
 local x = conn:load(url3)
 
       for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url4 = string.gsub(url4, '\\u0026', '&')
      url4 = string.gsub(url4, '\\u002B', '+')   
       t['view'] = 'list'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url4, image = '#self/movie.png'})

     end  
    end
end

local x = conn:load('http://z01.online/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
   
     for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"call".-"url".-(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
 
 
 local x = conn:load(url)
 
       for url2 in string.gmatch(x, '"play".-"url".-"(http.-)"') do

   url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')   
       t['view'] = 'list'
 
 table.insert(t, {title = tolazy(total), mrl = url2, image = '#self/movie.png'})

     end  
    end
   
   
    
      
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end