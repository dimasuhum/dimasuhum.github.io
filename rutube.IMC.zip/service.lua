-- Moonwalk plugin
-- © IconBIT 2018

require('video')
require('parser')
require('support')
require('client')

local HOME = 'http://torrs.ru'

 local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

function onLoad()
	print("Hello from Moonwalk plugin")
	return 1
end

function onUnLoad()
	print("Bye from Moonwalk plugin")
end

function onCreate(args)
	local t = {}
	
t['menu'] = {}
--	if args.q ~= 'genres' then
--		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
--	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	if args.keyword then

	
		t['view'] = 'grid_large'
		t['type'] = 'folder'
		keyword = args.keyword
		local title = args.keyword



		local page = tonumber(args.page or '1')
     local url = 'http://rutube.ru/api/search/video/?query=' .. urlencode(keyword)
		
		--print(url)
		local x = http.get(url)
		--print(x)
		local x = json.decode(x)

		for _, v in ipairs(x['results']) do
			local url = 'http://rutube.ru/video/' .. v['id'] .. '/'
	
--	table.insert(t, {title = url, mrl = '#stream/q=rutubes&id=' .. v['id'], image = v['thumbnail_url']})
	
	table.insert(t, {title = v['title'], mrl = '#stream/q=rutubes&id=' .. v['id'], image = v['thumbnail_url']})

end


elseif args.q == 'search' then
    

    
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		t['view'] = 'grid_large'
		local page = tonumber(args.page or '1')
		local url = 'http://rutube.ru/api/search/video/?query=' .. urlencode(keyword)
		
		--print(url)
		local x = http.get(url)
		--print(x)
		local x = json.decode(x)

		for _, v in ipairs(x['results']) do
			local url = 'http://rutube.ru/video/' .. v['id'] .. '/'
	
	
	table.insert(t, {title = v['title'], mrl = '#stream/q=rutubes&id=' .. v['id'], image = v['thumbnail_url']})

end


elseif args.q == 'rutubes' then
 
-- http://rutube.ru/video/37d5799de2cf4fcc86515fa9461bd296/
 
 --http://kb-team.club/msx/kinofeed/viewtube.php?id=37d5799de2cf4fcc86515fa9461bd296
 

local url = 'http://kb-team.club/msx/kinofeed/viewtube.php?id=' .. args.id
 

 		--print(url)
		local x = conn:load(url)
		--print(x)

       x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
	
 
 

 
-- http://kb-team.club/msx/kinofeed/viewtube.php?id=37d5799de2cf4fcc86515fa9461bd296
   
   
   for url, title in string.gmatch(x, '"action":"video.-(http.-)".-"playerLabel":"(.-)"') do
  
  url = string.gsub(url, '\\', '')
  
   
   t['view'] = 'simple'
   
  table.insert(t, {title = title, mrl = url})
   end
	
	
elseif args.q == 'video' then

      args.id = args.id:lower() 

local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      
      --	 https://lam.akter-black.com/lite/pidtor/serial/7d2dd45792a2695ff0cc88cde4af51cd5189dfb4?tr=	
--https://lam.akter-black.com/lite/jac?serial=1&title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%20%D0%B7%D0%B5%D0%BC%D0%BB%D1%8F


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end
		
		
	elseif args.q == 'video1' then


--table.insert(t, {title = 'https://lam.akter-black.com/ts/stream?link=' .. args.id .. '&m3u', mrl =  'https://lam.akter-black.com/ts/stream?link=' .. args.id .. '&m3u', image = image})


		local x = conn:load('https://lam.akter-black.com/ts/stream?link=' .. args.id .. '&m3u')
	--	local x = conn:load(args.id)





   --   url = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      
 --  table.insert(t, {title = url, mrl = url})
    --    local x = conn1:load(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
        t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
        t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
       t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        
	end


	elseif args.q == 'play' then
		--args['ref']= 'http://' .. string.match(args.url, '://(.-)/')
		args['ref'] = 'https://cinema-hd.tv'
		return video(args.url, args)
	else
		t['view'] = 'keyword'
		t['message'] = '@string/search_text'
		t['keyword'] = keyword
	end
	
	return t
end
