-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate






local HOME = 'http://kb-team.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)




	local t = {view = 'grid', type = 'folder'}
		t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})


	if not args.q then

local genre = args.genre or 'all'
	
local page = tonumber(args.page or '1')
    
local offset = (page - 1) * 15 + 1
		
		for i = 1, 15 do
 

 
 
 local url = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist&page=' .. tostring(offset + i - 1) .. '&genre=' .. urlencode(genre) .. '&search='
 

local headers = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "application/json, text/javascript, */*; q=0.01",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
  
  ["Referer"] = "https://vse-tv.net/register.html",
  
["Cookie"] = "bonusBannerSeen=1; cf_clearance=a7YicIW5xIkITq65zq55.yzkBr75iGFM41.fyi7T1P4-1790259947-1.2.1.1-2on6hCsVSlgvwYfZNR8P_4Lj4SUhaMRmlomF1hXH00C0th..dmDfkEymydLHjl_jSmbpDu9fiYYHGgggJxANaVvav2qYCYJRAJ.WQ6sMZimHS5DCtUe99lwdKoijVOJjHOQBhm_59.Y8JxMnqRmZSnKeWTqQhVz7pVfJYKUAZTuMUb4DyD7zJmTQGwD5Q2VKWUAC_PqXuO.2MxSdW99XK.MT0zuVY_0ieiTB7oMX2YCJmhb1DBu.ONg.b9Z0ZhVxNaz8a2klXywLCbDKDFOEP861ZamV5nA2mbudh3NyOiZ2KstsPsimGVWI3LL5OCRHOAu_XyJiUoqUvV6wLCsnh14kSNooSOaGyG5qf4orZBo; billing_plugins_bonus_day=1790347006; _ga_05VH9CY87B=GS2.1.s1790260408$o1$g1$t1790260655$j51$l0$h0; NETCLOUDCDN=tsr633gnip49daav41o2s668g5; _ga=GA1.1.1901455965.1790260408; _ym_uid=1788611796413073323; _ym_d=1790260408; _ym_visorc=w; _ym_isad=2; mdd=0; dle_user_id=41135; dle_password=00318de380cec262efd5ac5af9bf226c; dle_newpm=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2208e4075a-5699-40b2-b93f-5717c9c6d2d5%5C%22%2C%5B1790260408%2C701000000%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol9N7TahaIIYAgvNKocQlk_CSx3Tagd8lWttNGTiRhWLdTYufRIn6H1h5FqNJtc3nlUeCSM9lZWMXYtrhY4cxyut_IMEuSoKK_qfj-JejfZz2NJ9Ukqc5cQYVMgK7euGhsZojDd31AKjpl290Fx8Vzle-ENIqw%3D%3D%22%5D%5D",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

 
 local x = http.getz(url, headers)
 



for id, name, token, cdn, logo in string.gmatch(x, 'video%-btn ripple.-onclick=.-checkAndOpenModal%(\'(.-)\', \'(.-)\', \'(.-)\', \'(.-)\', true.-<img src=.-"(.-)"') do


logo = string.gsub(logo, '\\', '')

logo = string.gsub(logo, '^(.-)', 'https://vse-tv.net')


title = string.gsub(name, '^(.-)', '{"title":"') .. '"}'

local v = json.decode(title)

local title = v['title']



 
table.insert(t, {title = title, mrl = 'https://' .. cdn .. '/' .. id .. '/index.m3u8?token=' .. token, image = logo})

end
end


local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. urlencode(genre)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
  
  
    	

		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 
 
 
 table.insert(t, {title = 'Все категории', mrl = '#stream/genre=' .. 'all', image = image})
 
 table.insert(t, {title = 'Без категории', mrl = '#stream/genre=' .. 'Без категории', image = image})
 
table.insert(t, {title = 'Новый Год', mrl = '#stream/genre=' .. 'Новый Год', image = image})
 
 
table.insert(t, {title = 'СССР', mrl = '#stream/genre=' .. 'СССР', image = image})
 
 table.insert(t, {title = 'VHS', mrl = '#stream/genre=' .. 'VHS', image = image})
 
 
 
 
table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. 'Фильмы', image = image})
 
 table.insert(t, {title = 'Кинозалы', mrl = '#stream/genre=' .. 'Кинозалы', image = image})
 
table.insert(t, {title = 'Криминал', mrl = '#stream/genre=' .. 'Криминал', image = image})
 
 
table.insert(t, {title = 'Новости', mrl = '#stream/genre=' .. 'Новости', image = image})
 
 table.insert(t, {title = 'Общие', mrl = '#stream/genre=' .. 'Общие', image = image})
 
 
 
 
table.insert(t, {title = 'Спорт', mrl = '#stream/genre=' .. 'Спорт', image = image})

table.insert(t, {title = 'Познавательные', mrl = '#stream/genre=' .. 'Познавательные', image = image})

table.insert(t, {title = 'Развлекательные', mrl = '#stream/genre=' .. 'Развлекательные', image = image})

table.insert(t, {title = 'Музыка', mrl = '#stream/genre=' .. 'Музыка', image = image})

table.insert(t, {title = 'Детские', mrl = '#stream/genre=' .. 'Детские', image = image})

table.insert(t, {title = 'Окно в мир', mrl = '#stream/genre=' .. 'Окно в мир', image = image})

table.insert(t, {title = 'Мужские', mrl = '#stream/genre=' .. 'Мужские', image = image})

table.insert(t, {title = 'Женские', mrl = '#stream/genre=' .. 'Женские', image = image})

table.insert(t, {title = 'Региональные', mrl = '#stream/genre=' .. 'Региональные', image = image})

table.insert(t, {title = 'Религиозные', mrl = '#stream/genre=' .. 'Религиозные', image = image})

table.insert(t, {title = 'Беларусь', mrl = '#stream/genre=' .. 'Беларусь', image = image})




table.insert(t, {title = 'Україна', mrl = '#stream/genre=' .. 'Україна', image = image})



table.insert(t, {title = 'Georgia', mrl = '#stream/genre=' .. 'Georgia', image = image})



table.insert(t, {title = 'Взрослые', mrl = '#stream/genre=' .. 'Для взрослых', image = image})




elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
	
local offset = (page - 1) * 8 + 1
		
		for i = 1, 8 do
 

 
 

 local url = 'https://vse-tv.net/engine/ajax/controller.php?mod=myplaylist&page=' .. tostring(offset + i - 1) .. '&genre=all&search=' .. urlencode(args.keyword)
 

local headers = {
    ["Host"] = "vse-tv.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "application/json, text/javascript, */*; q=0.01",
    ["Referer"] = "https://vse-tv.net/playlists.html",
    ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
  
  ["Referer"] = "https://vse-tv.net/register.html",
  
["Cookie"] = "bonusBannerSeen=1; cf_clearance=a7YicIW5xIkITq65zq55.yzkBr75iGFM41.fyi7T1P4-1790259947-1.2.1.1-2on6hCsVSlgvwYfZNR8P_4Lj4SUhaMRmlomF1hXH00C0th..dmDfkEymydLHjl_jSmbpDu9fiYYHGgggJxANaVvav2qYCYJRAJ.WQ6sMZimHS5DCtUe99lwdKoijVOJjHOQBhm_59.Y8JxMnqRmZSnKeWTqQhVz7pVfJYKUAZTuMUb4DyD7zJmTQGwD5Q2VKWUAC_PqXuO.2MxSdW99XK.MT0zuVY_0ieiTB7oMX2YCJmhb1DBu.ONg.b9Z0ZhVxNaz8a2klXywLCbDKDFOEP861ZamV5nA2mbudh3NyOiZ2KstsPsimGVWI3LL5OCRHOAu_XyJiUoqUvV6wLCsnh14kSNooSOaGyG5qf4orZBo; billing_plugins_bonus_day=1790347006; _ga_05VH9CY87B=GS2.1.s1790260408$o1$g1$t1790260655$j51$l0$h0; NETCLOUDCDN=tsr633gnip49daav41o2s668g5; _ga=GA1.1.1901455965.1790260408; _ym_uid=1788611796413073323; _ym_d=1790260408; _ym_visorc=w; _ym_isad=2; mdd=0; dle_user_id=41135; dle_password=00318de380cec262efd5ac5af9bf226c; dle_newpm=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2208e4075a-5699-40b2-b93f-5717c9c6d2d5%5C%22%2C%5B1790260408%2C701000000%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol9N7TahaIIYAgvNKocQlk_CSx3Tagd8lWttNGTiRhWLdTYufRIn6H1h5FqNJtc3nlUeCSM9lZWMXYtrhY4cxyut_IMEuSoKK_qfj-JejfZz2NJ9Ukqc5cQYVMgK7euGhsZojDd31AKjpl290Fx8Vzle-ENIqw%3D%3D%22%5D%5D",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin"
}

local x = http.getz(url, headers)
 


for id, name, token, cdn, logo in string.gmatch(x, 'video%-btn ripple.-onclick=.-checkAndOpenModal%(\'(.-)\', \'(.-)\', \'(.-)\', \'(.-)\', true.-<img src=.-"(.-)"') do


logo = string.gsub(logo, '\\', '')

logo = string.gsub(logo, '^(.-)', 'https://vse-tv.net')

 
 title = string.gsub(name, '^(.-)', '{"title":"') .. '"}'

local v = json.decode(title)

local title = v['title']
 
 
table.insert(t, {title = title, mrl = 'https://' .. cdn .. '/' .. id .. '/index.m3u8?token=' .. token, image = logo})

end
end


local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			

    

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
--end
	end
	return t
end