-- hdrezka

local video = require('video')
local parser = require('parser')

local headers = {
	['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0',
	Connection = 'close'
}

local r = {}
local x = http.get('http://hdrezka-router.com', headers, r)

--r['location'] = 'http://hdrezkagroup.org/'

local HOME = string.gsub(r['location'], '/$', '')
local HOME_SLASH = r['location']

print(HOME)

headers['Referer'] = HOME_SLASH

function onLoad()
	print('Hello from hdrezka')
end

function onUnLoad()
	print('Bye from hdrezka')
end

function onCreate(args)
	local t = {view = 'posters', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', url = url_for{q = 'genres'}, icon = get_image('list.png')})
	end
	--table.insert(t['menu'], {title = '@string/search', url = url_for{q = 'search'}, icon = get_image('search.png')})
	
	-- #self/page=2
	-- #self/genre=/series/horror/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/new/'
		
		local url = HOME .. genre
		if page > 1 then
			url = string.gsub(url, '/$', '') .. '/page/' .. tostring(page) .. '/'
		end
		print(url)

		local x = http.getz(url, headers)
		local x = string.match(x, '<div class="b%-content__inline_items">(.+)')
		--print(x)
		
		for id, icon, title in string.gmatch(x, '<div class="b%-content__inline_item".-href="(.-)".-src="(.-)".-<a.->(.-)</a>') do
			table.insert(t, {
				title = title,
				url = url_for{q = 'content', id = id},
				icon = icon
			})
		end
		
		table.insert(t, {
			title = L'page' .. ' ' .. tostring(page + 1),
			url = url_for{genre = genre, page = page + 1},
			icon = get_image('next.png')
		})
		
	-- #self/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
		local x = http.getz(HOME_SLASH)
		for genre, title in string.gmatch(x, '<a class="b%-topnav__item%-link" href="(.-)"> (.-)<') do
			table.insert(t, {title = title, url = url_for{genre = genre}})
			for genre, subtitle in string.gmatch(x, '<li><a href="(' .. genre .. '.-)">(.-)</a></li>') do
				local title = title .. ': ' .. subtitle
				table.insert(t, {title = title, url = url_for{genre = genre}})
			end
		end
		
	-- #stream/q=search&keyword=4400
	elseif args.q == 'search' then
		if args.keyword then
			
			local url = HOME .. '/search/?' .. http.encode{
				['do'] = 'search',
				subaction = 'search',
				q = args.keyword
			}
			local x = http.getz(url, headers)
			--local x = string.match(x, '<div class="b%-content__inline_items">(.+)')
			print(x)
			
			for id, icon, title in string.gmatch(x, '<div class="b%-content__inline_item".-href="(.-)".- src="(.-)".-alt="(.-)"') do
				table.insert(t, {
					title = title,
					url = url_for{q = 'content', id = id},
					icon = icon
				})
			end
			
			if #t == 0 then
				return {view = 'message', message = '@string/search_reply'}
			end
		else
			return {view = 'keyword', message = '@string/search_text'}
		end
	
	-- #self/q=content&id=http://hdrezkagroup.org/series/action/43391-tysyacha-klykov-2021.html
	-- #self/q=content&id=https://hdrezkaonlinetech.org/films/documentary/42634-bondarchuk-battle-2021.html
	-- #self/q=content&id=https://hdrezkagroup.org/series/detective/43638-chto-znaet-marianna-2021.html
	-- #self/q=content&id=https://hdrezkagroup.org/series/fiction/43239-moguchie-reyndzhery-dikiy-mir-2002.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		
		local url = string.gsub(args.id, '^/', HOME_SLASH)
		local r = {}
		local x = http.getz(url, headers, r)
		
		t['name'] = parser.match(x, '<h1.->(.-)</h1>')
		t['description'] = parser.match(x, 'class="b%-post__description_text">(.-)</div>')
		t['poster'] = parser.match(x, 'class="b%-sidecover".-src="(.-)"')
		
		t['annotation'] = parser.array(x, {
			'<h2>(Дата выхода</h2>:</td> <td>.-)</td>', '<h2>(Страна</h2>:</td> <td>.-)</td>',
			'<h2>(Режиссер</h2>:</td> <td>.-)</td>', '<h2>(Жанр</h2>:</td> <td>.-)</td>',
			'<h2>(В качестве</h2>:</td> <td>.-)</td>', '<h2>(Возраст</h2>:</td> <td>.-)</td>',
			'<h2>(Время</h2>:</td> <td>.-)</td>', '<h2>(В ролях актеры</h2>:.-)</td>'
		})
		
		local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do
			local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
			if data then
				local data = json.decode(data)
				if isseries then
					trans_id = trans_id or tid
				else
					table.insert(t, {
						title = '@string/watch',
						url = url_for('get', {file = data['streams'], t = t['name']})
					})
				end
			end
		end
	
		print('trans_id', trans_id)
		
		local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, '<li.-data%-translator_id="(.-)">(.-)</li>') do
					local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
					print(id, title)
					
					local headers = {['X-Requested-With'] = 'XMLHttpRequest'}
					local params = http.encode{
						id = data_id,
						translator_id = id,
						action = 'get_episodes'
					}
					
					local x = http.postz(HOME .. '/ajax/get_cdn_series/', headers, params)
					--print(x)
					local x = json.decode(x)
					for season, episode, name in string.gmatch(x['episodes'], 'data%-season_id="(%d+)" data%-episode_id="(%d+)">(.-)</li>') do
						local title = L'season' .. ' ' .. tostring(season) .. '. ' .. name .. ' (' .. title .. ')'
						table.insert(t, {
							title = title,
							url = url_for('get_stream', {
								id = data_id,
								translator_id = id,
								season = season,
								episode = episode,
								t = title
							}),
							__type__ = 'video'
						})
					end
				end
			else
				for season, episode, title in string.gmatch(x, 'data%-season_id="(%d+)" data%-episode_id="(%d+)">(.-)</li>') do
					table.insert(t, {
						title = title,
						url = url_for('get_stream', {
							id = data_id,
							translator_id = trans_id,
							season = season,
							episode = episode,
							t = title
						}),
						__type__ = 'video'
					})
				end
			end
		end
	
	end
	return t
end

function get(args)
	local videos = {}
	for quali, url in string.gmatch(args['file'], '%[(.-)%]([^,]+)') do
		videos[string.upper(quali)] = string.gsub(url, ' or.+', '')
	end
	return video.dialog{videos = videos, title = args['t']}
end

-- #self/t=%D0%A1%D0%B5%D0%B7%D0%BE%D0%BD+1.+%D0%A1%D0%B5%D1%80%D0%B8%D1%8F+1+(Coldfilm)&season=1&id=43391&episode=1&translator_id=35&__func__=get_stream
function get_stream(args)
	local headers = {
		['X-Requested-With'] = 'XMLHttpRequest',
	}
	local params = http.encode{
		id = args.id,
		translator_id = args.translator_id,
		season = args.season,
		episode = args.episode,
		action = 'get_stream'
	}
	
	print(params)
	local x = http.postz(HOME .. '/ajax/get_cdn_series/', headers, params)
	--print(x)
	local x = json.decode(x)
	
	if x['success'] then
		return get{file = x['url'], t = args['t']}
	end
	
	return {view = 'error', message = x['message']}
end

