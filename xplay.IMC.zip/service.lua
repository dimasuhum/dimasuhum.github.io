-- COOLTV

require('fxml')

-- #self/url=http://imboom.ru/account.php
-- #self/url=http://fork-portal.ru/no_save/iptv-parser
-- #self/url=http://xplay.bz/
-- #self/url=http://xplay.bz/img/folder.png
-- #self/url=https://imagetmdb.com/t/p/w200/6iRxKxfE6SB586cQV3BH8NSMzoZ.jpg
-- #stream/url=http%3A%2F%2Ffork%2Dportal%2Eru%2Fno%5Fsave%2Fiptv%2Dparser%2Fglaz%2Ejson
-- #stream/parser=https%3A%2F%2Fwww%2Eglaz%2Etv%2Fonline%2Dtv%2Fsts%7Cvar+signature+%3D+%22%7C%22&l=http%3A%2F%2F178%2E162%2E218%2E85%3A8081%2Fchromecast%2Fsts%2Dhq%2Estream%2Fplaylist%2Em3u8%3FwmsAuthSign%3Dmd5hash

 -- #stream/url=https://imagetmdb.com/t/p/w200/6iRxKxfE6SB586cQV3BH8NSMzoZ.jpg
-- #stream/url=http://xplay.bz/img/folder.png
-- #stream/url=http://xplay.bz/img/logo.png
-- #stream/url=http://xplay.bz/
-- #stream/url=http://staticdata.appinfo.su/staticfiles/fimg/open.png
-- #stream/url=http://xplay.bz/list
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka
-- #stream/url=http%3A%2F%2Fnserv%2Ehost%3A5300%2Frezka%2Flist%3Fcat%3Dfilms
-- #stream/url=http://imboom.ru/?ma=playlist
-- #stream/url=http://imboom.ru/?ma=imboomiptv
-- #stream/url=http://xplay.bz/view?id=958197&cat=movie&original_language=fr&kinopoisk_id=4860621&imdb_id=tt18036574
-- #self/url=http://xplay.bz/list
-- #self/url=http://imboom.ru/?ma=playlist
-- #self/url=http://imboom.ru/?ma=imboomiptv
-- #stream/url=http://imboom.ru/?ma=cinemahall&mb=full&md=1154107
