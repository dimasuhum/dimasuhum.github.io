-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')
--require('JSON')
--require('ltn12')


local fxml = onCreate

--https://lam.akter-black.com/tmdb/api/3/collection/collection_id/translations?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru&page=1

--https://api.themoviedb.org/3/search/collection?include_adult=false&language=en-US&page=1

--https://lam.akter-black.com/tmdb/api/3/search/collection?include_adult=false&api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru&page=1

--https://lam.akter-black.com/tmdb/api/3/movie/17199?include_adult=true&api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru

--https://lam.akter-black.com/tmdb/api/3/search/movie?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru&external_source=imdb_id&query=чужой_1979



--https://lam.akter-black.com/plugins/player-inner.js

--https://kinoflex.cc/trailer.php?id=17199
--local REPO1 = 'http://xplay.bz/'

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'

--https://api.themoviedb.org/3/collection/collection_id?language=en-US

--https://lam.akter-black.com/tmdb/api/3/collection/collection_id?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru

local HOME = 'http://fxmlparsers.in.net/VilkaDB'
local HOME1 = 'https://lam.maxvol.pro/tmdb/api/3/'

local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'

local conn1 = client.new()
conn1['encoding'] = 'windows-1251'
conn['root'] = HOME_SLASH


--HOME = 'https://kinoprofi.day'

--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
       table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=2
	-- #stream/genre=/?id=nowwatching
	-- #stream/genre=/?id=popular
	
	
	if not args.q then
		local page = tonumber(args.page or 1)

--https://lam.akter-black.com/tmdb/api/3/trending/all/day?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru&page=1
		
--http://fxmlparsers.in.net/VilkaDB/?id=nowwatching

--http://fxmlparsers.in.net/VilkaDB/?id=trands
	--	local genre = args.genre or '/'
		local genre = args.genre or 'trending/all/day'
		local url = HOME1 .. genre
	--	if page > 1 then
			url = url .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru' .. '&page=' .. tostring(page)
			--.. '/'
	--	end
	--	local x = http.getz(url)
        local x = conn:load(url)

for id, title, image, id1, total in string.gmatch(x, '"backdrop_path".-"id":(.-),".-":"(.-)".-"poster_path":"/(.-)".-"media_type":"(.-)".-".-_date":"(.-)-') do
	
	
	id  = string.gsub(id, '^(.-)', id1 .. '/')
	image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')
	
	table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
  
  table.insert(t, {title = 'Поиск по коллекциям', mrl = '#stream/q=coll', image = '#self/search.png'})
  table.insert(t, {title = 'Поиск по актёрам', mrl = '#stream/q=person', image = '#self/search.png'})
  
  table.insert(t, {title = 'Фильмы: Сейчас смотрят', mrl = '#stream/q=movies&id=' .. 'movie/now_playing'})
table.insert(t, {title = 'Фильмы: Популярное', mrl = '#stream/q=movies&id=' .. 'movie/popular'})
  table.insert(t, {title = 'Фильмы: В кино', mrl = '#stream/q=movies&id=' .. 'movie/upcoming'})
 table.insert(t, {title = 'Фильмы: Топ', mrl = '#stream/q=movies&id=' .. 'movie/top_rated'})
 
 
 table.insert(t, {title = 'Фильмы: В тренде сегодня', mrl = '#stream/q=trendm&id=' .. 'trending/movie/day'})
 table.insert(t, {title = 'Фильмы: В тренде за неделю', mrl = '#stream/q=trendm&id=' .. 'trending/movie/week'})
 

 
table.insert(t, {title = 'Сериалы: Сейчас смотрят', mrl = '#stream/q=series&id=' .. 'tv/on_the_air'})
table.insert(t, {title = 'Сериалы: Популярное', mrl = '#stream/q=series&id=' .. 'tv/popular'})
  table.insert(t, {title = 'Сериалы: Выходящие', mrl = '#stream/q=series&id=' .. 'tv/airing_today'})
 table.insert(t, {title = 'Сериалы: Топ', mrl = '#stream/q=series&id=' .. 'tv/top_rated'})
 
 table.insert(t, {title = 'Сериалы: В тренде сегодня', mrl = '#stream/q=trends&id=' .. 'trending/tv/day'})
 table.insert(t, {title = 'Сериалы: В тренде за неделю', mrl = '#stream/q=trends&id=' .. 'trending/tv/week'})
 
  
         local x = conn:load(HOME .. '/?type=movie')
		
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')


local tt = {
			'Жанр(.-)Год',
	        }
		
		for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for title, id in string.gmatch(x, '{"title":"(.-)".-"playlist_url".-&with_genres=(.-)&year=&rating="') do
		
      
       table.insert(t, {title = 'Фильмы : '.. title, mrl = '#stream/q=movie&id=' .. id})

   end
   end



      local x = conn:load(HOME .. '/?type=tv')
		
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')


local tt = {
			'Жанр(.-)Год',
	        }
		
		for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for title, id in string.gmatch(x, '{"title":"(.-)".-"playlist_url".-&with_genres=(.-)&year=&rating="') do
		
      
       table.insert(t, {title = 'Сериалы : '.. title, mrl = '#stream/q=tv&id=' .. id})

   end
   end






--		local x = string.match(x, '<div class="side%-bc fx%-row">(.-)<a href="/films%-4k')
	--	for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
--			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
	--	end
    --   table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/cartoons/'})
  
   --   table.insert(t, {title = 'Передачи', mrl = '#stream/genre=' .. '/doc/'})
  
--https://kinoprofi.day/index.php?do=search&story=Рокки&do=search&subaction=search  
        
--https://kinoprofi.day/index.php?do=search &subaction=search&story=Рокки&do=search&subaction=search        
--https://kinokrad.cc/index.php?story=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8&do=search&subaction=search



--https://lam.akter-black.com/tmdb/api/3/collection/397842?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru&page=1	

--https://lam.akter-black.com/tmdb/api/3/search/person?query=Сталлоне&api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru&page=1


--table.insert(t, {title = 'Поиск по коллекциям', mrl = '#stream/q=coll', image = '#self/search.png'})
    
    elseif args.q == 'coll' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')

	
	local x = conn:load(HOME1 .. 'search/collection?query=' .. urlencode(args.keyword) .. '&api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru' .. '&page=' .. tostring(page))
	


	for id, title, image in string.gmatch(x, '"adult".-"id":(.-),"name":"(.-)".-"poster_path":"/(.-)"') do
	image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')
	
	table.insert(t, {title=title, mrl = '#stream/q=collection&id=' .. id, image = image})
		end
   
   local url = '#stream/q=coll&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
  -- local url = '#stream/page=' .. tostring(page + 1) .. '&q=coll&id=' .. urlencode(args.keyword)
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


elseif args.q == 'person' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')

	
	local x = conn:load(HOME1 .. 'search/person?query=' .. urlencode(args.keyword) .. '&api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru' .. '&page=' .. tostring(page))
	


	for id, title, image, id1, total in string.gmatch(x, '"backdrop_path".-"id":(.-),"title":"(.-)".-"poster_path":"/(.-)".-"media_type":"(.-)".-"release_date":"(.-)-') do
	
	
	id  = string.gsub(id, '^(.-)', id1 .. '/')
	image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')
	
	table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
   
   local url = '#stream/q=coll&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
  -- local url = '#stream/page=' .. tostring(page + 1) .. '&q=person&id=' .. urlencode(args.keyword)
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

elseif args.q == 'collection' then


local page = tonumber(args.page or 1)
		
      local x = conn:load(HOME1 ..  'collection/' .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru' .. '&page=' .. tostring(page))


for id, title, image, id1, total  in string.gmatch(x, '"adult".-"id":(.-),"title":"(.-)".-"poster_path":"/(.-)".-"media_type":"(.-)".-"release_date":"(.-)-') do
      


id  = string.gsub(id, '^(.-)', id1 .. '/')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')


		
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
	
	

		local url = '#folder/page=' .. tostring(page + 1) .. '&q=collection&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


    
    
    
    elseif args.q == 'trendm' then

local page = tonumber(args.page or 1)
		
      local x = conn:load(HOME1 .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru' .. '&page=' .. tostring(page))


for id, title, image, total  in string.gmatch(x, '"adult".-"id":(.-),".-":"(.-)".-"poster_path":"/(.-)".-".-_date":"(.-)-') do


id  = string.gsub(id, '^(.-)', 'movie/')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')


		
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
	
	

		local url = '#folder/page=' .. tostring(page + 1) .. '&q=trendm&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
    
    elseif args.q == 'trends' then

local page = tonumber(args.page or 1)
		
      local x = conn:load(HOME1 .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru' .. '&page=' .. tostring(page))


for id, title, image, total  in string.gmatch(x, '"adult".-"id":(.-),".-":"(.-)".-"poster_path":"/(.-)".-".-_date":"(.-)-') do


id  = string.gsub(id, '^(.-)', 'tv/')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')


		
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
	
	

		local url = '#folder/page=' .. tostring(page + 1) .. '&q=trends&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})



elseif args.q == 'series' then


local page = tonumber(args.page or 1)
		
      local x = conn:load(HOME1 .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru' .. '&page=' .. tostring(page))


for id, image, total, title  in string.gmatch(x, '"id":(.-),.-"poster_path":"/(.-)".-".-_date":"(.-)-.-".-":"(.-)"') do
      


id  = string.gsub(id, '^(.-)', 'tv/')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')


		
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
	
	

		local url = '#folder/page=' .. tostring(page + 1) .. '&q=series&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})



elseif args.q == 'movies' then


local page = tonumber(args.page or 1)
		
      local x = conn:load(HOME1 .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru' .. '&page=' .. tostring(page))


for id, image, total, title  in string.gmatch(x, '"id":(.-),.-"poster_path":"/(.-)".-".-_date":"(.-)-.-".-":"(.-)"') do
      


id  = string.gsub(id, '^(.-)', 'movie/')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')


		
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
	
	

		local url = '#folder/page=' .. tostring(page + 1) .. '&q=movies&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

 
 
 
 elseif args.q == 'recommendations' then



  local page = tonumber(args.page or 1)


		
      local x = conn:load(HOME1 .. args.id .. '/recommendations?api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru' .. '&page=' .. tostring(page))
 
for id, title, image, id1, total in string.gmatch(x, '"backdrop_path".-"id":(.-),".-":"(.-)".-"poster_path":"/(.-)".-"media_type":"(.-)".-".-_date":"(.-)-') do
	
	
	id  = string.gsub(id, '^(.-)', id1 .. '/')
	image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')
	
	table.insert(t, {title=title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
 
  local url = '#folder/page=' .. tostring(page + 1) .. '&q=recommendations&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


 
 
elseif args.q == 'similars' then

--https://lam.akter-black.com/tmdb/api/3/tv/153312/similar?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru
  local page = tonumber(args.page or 1)


		
      local x = conn:load(HOME1 .. 'tv/' .. args.id .. '/similar?api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru' .. '&page=' .. tostring(page))
 
    for id, image, total, title  in string.gmatch(x, 'adult".-"id":(.-),.-"poster_path":"/(.-)".-"first_air_date":"(.-)-.-".-"name":"(.-)"') do
    id  = string.gsub(id, '^(.-)', 'tv/')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')

     table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})

		end
		
	local url = '#folder/page=' .. tostring(page + 1) .. '&q=similars&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})



	elseif args.q == 'similarm' then

--https://lam.akter-black.com/tmdb/api/3/movie/950396/similar?include_adult=true&api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru&page=1
  local page = tonumber(args.page or 1)


		
      local x = conn:load(HOME1 .. 'movie/' .. args.id .. '/similar?api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru' .. '&page=' .. tostring(page))
 
    for id, image, total, title in string.gmatch(x, 'adult".-"id":(.-),.-"poster_path":"/(.-)".-"release_date":"(.-)-.-".-"title":"(.-)"') do
    id  = string.gsub(id, '^(.-)', 'movie/')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')

     table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end

		local url = '#folder/page=' .. tostring(page + 1) .. '&q=similarm&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


    elseif args.q == 'tag' then


local page = tonumber(args.page or 1)


		
      local x = conn:load(HOME1 .. 'keyword/' .. args.id .. '/movies?api_key=4ef0d7355d9ffb5151e987764708ce96&include_adult=true&language=ru' .. '&page=' .. tostring(page))


    for id, image, total, title  in string.gmatch(x, '"id":(.-),.-"poster_path":"/(.-)".-".-_date":"(.-)-.-".-":"(.-)"') do
      


id  = string.gsub(id, '^(.-)', 'movie/')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org/t/p/w200/')


		
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
	
	

		local url = '#folder/page=' .. tostring(page + 1) .. '&q=tag&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})




    elseif args.q == 'movie' then
   
   local x = conn:load(HOME .. '/?type=movie&with_genres=' .. args.id .. '&year=&rating=')
      t['view'] = 'simple'
      t['title'] = args.t
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')





local tt = {'fxml.-"menu".-"menu".-"menu"(.-)"menu"',

}
		
		for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for title, id, id1 in string.gmatch(x, '{"title":"(.-)".-"playlist_url".-&with_genres=(.-)&year=(.-)&rating="') do
	
	local x = conn:load(HOME .. '/?type=movie&with_genres=' .. args.id .. '&year=&rating=')
      t['view'] = 'simple'
      
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')





local tt = {'fxml.-"menu".-"menu".-"menu".-"menu".-"menu"(.-)"menu"',

}
		
		for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for title1, id, id2 in string.gmatch(x, '{"title":"(.-)".-"playlist_url".-&with_genres=(.-)&year=&rating=(.-)"') do
	
	
				table.insert(t, {title = 'Год: ' ..  title .. ' Рейтинг: ' .. title1, mrl = '#stream/q=film&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2})
end
end
end
end



elseif args.q == 'film' then

local page = tonumber(args.page or 1)
		
      local x = conn:load(HOME .. '/?type=movie&with_genres=' .. args.id .. '&year=' .. args.id1 .. '&rating=' .. args.id2 .. '&p=' .. tostring(page))

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
local x = string.match(x, '"template".-"template".-"template"(.-)"search_on"')

		for title, total, id, image in string.gmatch(x, '{"title":"(.-)","infolink".-class=.-descitem year.->(.-)<.-"playlist_url":"http.-&tid=(.-)".-"logo_30x30":"(http.-)"') do
      


id  = string.gsub(id, '^(.-)', 'movie/')
image  = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
	

		local url = '#folder/page=' .. tostring(page + 1) .. '&q=film&id=' .. args.id .. '&id1=' .. args.id1 .. '&id2=' .. args.id2
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})



elseif args.q == 'tv' then
   
   local x = conn:load(HOME .. '/?type=tv&with_genres=' .. args.id .. '&year=&rating=')
      t['view'] = 'simple'
      t['title'] = args.t
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')





local tt = {'fxml.-"menu".-"menu".-"menu"(.-)"menu"',

}
		
		for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for title, id, id1 in string.gmatch(x, '{"title":"(.-)".-"playlist_url".-&with_genres=(.-)&year=(.-)&rating="') do
	
	local x = conn:load(HOME .. '/?type=tv&with_genres=' .. args.id .. '&year=&rating=')
      t['view'] = 'simple'
      
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')





local tt = {'fxml.-"menu".-"menu".-"menu".-"menu".-"menu"(.-)"menu"',

}
		
		for _, v in ipairs(tt) do
			local x = string.match(x, v)
			for title1, id, id2 in string.gmatch(x, '{"title":"(.-)".-"playlist_url".-&with_genres=(.-)&year=&rating=(.-)"') do
	
	
				table.insert(t, {title = 'Год: ' ..  title .. ' Рейтинг: ' .. title1, mrl = '#stream/q=serial&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2})
end
end
end
end



elseif args.q == 'serial' then

local page = tonumber(args.page or 1)
		
      local x = conn:load(HOME .. '/?type=tv&with_genres=' .. args.id .. '&year=' .. args.id1 .. '&rating=' .. args.id2 .. '&p=' .. tostring(page))

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
local x = string.match(x, '"template".-"template".-"template"(.-)"search_on"')

		for title, total, id, image in string.gmatch(x, '{"title":"(.-)","infolink".-class=.-descitem year.->(.-)<.-"playlist_url":"http.-&tid=(.-)".-"logo_30x30":"(http.-)"') do
      


id  = string.gsub(id, '^(.-)', 'tv/')
image  = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
	

		local url = '#folder/page=' .. tostring(page + 1) .. '&q=serial&id=' .. args.id .. '&id1=' .. args.id1 .. '&id2=' .. args.id2
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})




    elseif args.q == 'acterm' then

local page = tonumber(args.page or 1)
		
--http://fxmlparsers.in.net/VilkaDB/?id=tmdb&tid=679&media_type=movie

     local x = conn:load(HOME .. '/?id=tmdb&tid=' .. args.id .. '&media_type=movie')
     --.. '&p=' .. tostring(page))

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
	
	
local x = string.match(x, '&search=(.-)"infolink":')

	
for title, id, image in string.gmatch(x, '{"title":"(.-)".-"playlist_url":"http.-person&tid=(.-)".-"logo_30x30":"(http.-)"') do

        


id  = string.gsub(id, '\\', '')
image  = string.gsub(image, '\\', '')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=')
	
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=acter&id=' .. id, image = image})
		end
		
		
		
    
    elseif args.q == 'acters' then

local page = tonumber(args.page or 1)
		
--http://fxmlparsers.in.net/VilkaDB/?id=tmdb&tid=679&media_type=movie

     local x = conn:load(HOME .. '/?id=tmdb&tid=' .. args.id .. '&media_type=tv')
     --.. '&p=' .. tostring(page))

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
	
	
local x = string.match(x, '&search=(.-)"infolink":')

	
for title, id, image in string.gmatch(x, '{"title":"(.-)".-"playlist_url":"http.-person&tid=(.-)".-"logo_30x30":"(http.-)"') do

        


id  = string.gsub(id, '\\', '')
image  = string.gsub(image, '\\', '')
image  = string.gsub(image, '^(.-)', 'http://fxmlparsers.in.net/?wimg=')
	
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=acter&id=' .. id, image = image})
		end

--http://fxmlparsers.in.net/VilkaDB/?id=person&tid=10205


   elseif args.q == 'acter' then

local page = tonumber(args.page or 1)
		
--http://fxmlparsers.in.net/VilkaDB/?id=tmdb&tid=679&media_type=movie

     local x = conn:load(HOME .. '/?id=person&tid=' .. args.id)
     --.. '&p=' .. tostring(page))

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')


local x = string.match(x, '"fxml".-%[{"title":(.-)"title":"VilkaDB')
	
    for title, total, id, id1, image in string.gmatch(x, '{"title":"(.-)","infolink".-class=.-descitem year.->(.-)<.-"playlist_url":"http.-&tid=(.-)&media_type=(.-)".-"logo_30x30":"(http.-)"') do
      


id  = string.gsub(id, '^(.-)', id1 .. '/')
image  = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end




    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
	
--http://fxmlparsers.in.net/VilkaDB/?id=search&search=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&p=2


     
      	local url = ('http://fxmlparsers.in.net/VilkaDB/?id=search&search=' .. urlencode(args.keyword) .. '&p=' .. tostring(page))
	
		local x = conn:load(url)
		
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')

		x = string.gsub(x, '\\u2013', '-')

		
		
        for title, total, id, id1, image in string.gmatch(x, '{"title":"(.-)","infolink".-class=.-descitem year.->(.-)<.-"playlist_url":"http.-&tid=(.-)&media_type=(.-)".-"logo_30x30":"(http.-)"') do
      


id  = string.gsub(id, '^(.-)', id1 .. '/')
image  = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. id .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
        

        
 --  https://tmdb.kurwa-bober.ninja/3/movie/950396?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru    
        
    
--https://tmdb.kurwa-bober.ninja/3/tv/153312/keywords?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru
        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	
local x = conn:load('https://tmdb.kurwa-bober.ninja/3/' .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&append_to_response=alternative_titles&language=ru&email=')
	
	
--https://tmdb.kurwa-bober.ninja/3/1401778?api_key=4ef0d7355d9ffb5151e987764708ce96&append_to_response=alternative_titles&language=ru&email=

--https://tmdb.kurwa-bober.ninja/3/movie/1561969?api_key=4ef0d7355d9ffb5151e987764708ce96&append_to_response=content_ratings,release_dates,keywords,alternative_titles&language=ru&email=
	
	--	local x = conn:load('https://tmdb.kurwa-bober.ninja/3/' .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru')


		
	--	local x = conn:load(args.id)
		
--table.insert(t, {title = 'https://tmdb.kurwa-bober.ninja/3/' .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&append_to_response=alternative_titles&language=ru&email=', mrl = '#stream/q=video&id1=' .. 'https://tmdb.kurwa-bober.ninja/3/' .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&append_to_response=alternative_titles&language=ru&email=', image = image})
		
	
x = string.gsub(x, '"genres":', 'Жанр:')
	x = string.gsub(x, '(%[{"id":.-),', '')
	
x = string.gsub(x, '({"id":.-),', '')
		x = string.gsub(x, '"name":"', '')
	x = string.gsub(x, '"}', '')
	
			
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		
		t['description'] = parse_match(x,'"original_language":.-"overview":"(.-)"')
        t['poster'] = args.p

 	
		t['annotation'] = parse_array(x, { '(Жанр:.-)]', '(Страна:</span>.-)</div>'	})

 
    
	
--for title in string.gmatch(x, 'adult"(.-)release_quality') do
	

		
	--	end
	
--"names":["Долгая прогулка","The Long Walk"]

  --  for id2, id3 in string.gmatch(x, '"homepage".-"id":.-_date":"(.-)-.-".-"kinopoisk_id":"(.-)"') do

--for id2 in string.gmatch(x, '"homepage".-"id":.-_date":"(.-)-.-"') do


--for id2, id1, id4, id3 in string.gmatch(x, '"homepage".-"id":.-_date":"(.-)-.-".-"names":%["(.-)","(.-)".-"kinopoisk_id":"(.-)"') do


  --  args.id1 = urlencode(args.id1)
     
   --   id1 = string.gsub(id1, '+', '%%20')
  
  --    url = string.gsub(args.id1, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. ',' .. id2

 --    local x = conn:load('http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=' .. urlencode(args.id1) .. ',' .. args.id2)

--table.insert(t, {title = 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=' .. urlencode(args.id1) .. ',' .. args.id2, mrl = '#stream/q=acterm&id=' .. 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=' .. urlencode(args.id1) .. ',' .. args.id2})
   
  --  for id3 in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do
   
   local imdb = string.match(x, '"imdb_id":"(.-)"')
   
   local url = conn:load('https://api.manhan.one/externalids?imdb_id=' .. imdb)
   
 local kp = string.match(url, '"kinopoisk_id":"(.-)"')

if kp then

	table.insert(t, {title = 'Смотреть', mrl = '#stream/q=video&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. kp, image = image})
		
end
	--	end


	
local x = conn:load('https://tmdb.kurwa-bober.ninja/3/' .. args.id .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&append_to_response=alternative_titles&language=ru&email=')



for id in string.gmatch(x, '"homepage".-"id":(.-),.-release_date":') do

table.insert(t, {title = 'Актёры', mrl = '#stream/q=acterm&id=' .. id})
  end
  
    for id in string.gmatch(x, '"first_air_date".-"homepage".-"id":(.-),') do
    table.insert(t, {title = 'Актёры', mrl = '#stream/q=acters&id=' .. id})
  end
  
  
  
  
	table.insert(t, {title = 'Теги', mrl = '#stream/q=tags&id=' .. args.id})
  
  
  


    for id in string.gmatch(x, '"homepage".-"id":(.-),.-release_date":') do
    table.insert(t, {title = 'Похожее', mrl = '#stream/q=similarm&id=' .. id})
  end
    
    for id in string.gmatch(x, '"first_air_date".-"homepage".-"id":(.-),') do
    
    table.insert(t, {title = 'Похожее', mrl = '#stream/q=similars&id=' .. id})
  end
    
    table.insert(t, {title = 'Рекомендуется', mrl = '#stream/q=recommendations&id=' .. args.id})
    
    
    
	elseif args.q == 'tags' then
		t['view'] = 'simple'
     local x = conn:load(HOME1 .. args.id.. '/keywords' .. '?api_key=4ef0d7355d9ffb5151e987764708ce96&language=ru')


    local x = string.match(x, '".-s":(.-)]')
        for id, title in string.gmatch(x, '{"id":(.-),"name":"(.-)"') do	
        table.insert(t, {title = 'Тег : ' .. title, mrl = '#stream/q=tag&id=' .. id, image = image})
	end
 
    for  title, id in string.gmatch(x, '{"name":"(.-)","id":(.-)}') do
        
      table.insert(t, {title = 'Тег : ' .. title, mrl = '#stream/q=tag&id=' .. id, image = image})
end



     elseif args.q == 'video' then

       t['view'] = 'simple'



 --   table.insert(t, {title = 'Zetflix', mrl = '#stream/q=zetflix&id3=' .. args.id3, image = image})

     


  
  
  table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 table.insert(t, {title = 'Hdvb2', mrl = '#stream/q=hdvbf&id3=' .. args.id3})
  
 

 -- table.insert(t, {title = 'Hdvb3', mrl = '#stream/q=hdvb2&id3=' .. args.id3})
  
  
  table.insert(t, {title = 'Flixcdn-mp4', mrl = '#stream/q=flixcdnm&id3=' .. args.id3, image = image})
  
  table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id3=' .. args.id3, image = image})
  
       table.insert(t, {title = 'Collaps', mrl = '#stream/q=collaps&id3=' .. args.id3})

--table.insert(t, {title = 'Collaps2', mrl = '#stream/q=collaps2&id3=' .. args.id3})



  table.insert(t, {title = 'Collaps-dash', mrl = '#stream/q=collaps-dash&id3=' .. args.id3})
  
       
       table.insert(t, {title = 'Kino4k', mrl = '#stream/q=kino4k&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
   table.insert(t, {title = 'Filmix', mrl = '#stream/q=filmix&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
--table.insert(t, {title = 'Filmix2', mrl = '#stream/q=filmix2&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
 table.insert(t, {title = 'Kinofit', mrl = '#stream/q=kinofit&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 
 
 
 --  table.insert(t, {title = 'Lumex', mrl = '#stream/q=lumex&id3=' .. args.id3})
   
   table.insert(t, {title = 'Videocdn', mrl = '#stream/q=videocdn&id3=' .. args.id3})
 
   table.insert(t, {title = 'Vcdn', mrl = '#stream/q=vcdn&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
   
   table.insert(t, {title = 'Kinopub', mrl = '#stream/q=kinopub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
 -- table.insert(t, {title = 'Kinoportal', mrl = '#stream/q=kinopubtv&id1=' .. args.id1 .. '&id2=' .. args.id2 .. '&id3=' .. args.id3})
       
   
   
   
       
    table.insert(t, {title = 'Alloha', mrl = '#stream/q=alloha&id3=' .. args.id3})
 
--table.insert(t, {title = 'Paladin', mrl = '#stream/q=paladin&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  table.insert(t, {title = 'Mirage', mrl = '#stream/q=mirage&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
 table.insert(t, {title = 'Zetflix', mrl = '#stream/q=turbo&id3=' .. args.id3})
 
 table.insert(t, {title = 'Fancdn', mrl = '#stream/q=fancdn&id3=' .. args.id3})
 
 table.insert(t, {title = 'Fanserial', mrl = '#stream/q=fanserial&id3=' .. args.id3})
 
 
  
table.insert(t, {title = 'Seasonvar', mrl = '#stream/q=seasonvar&id1=' .. args.id1, image = image})
  

  
  
  
 -- table.insert(t, {title = 'Cdnmovies', mrl = '#stream/q=cdnmovies&id3=' .. args.id3})


--  table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=vdbmovies&id3=' .. args.id3})
  

 
 table.insert(t, {title = 'Videodb', mrl = '#stream/q=videodb&id3=' .. args.id3})
  
  
 
 -- table.insert(t, {title = 'Turbo', mrl = '#stream/q=turbo1&id3=' .. args.id3})
  
  
  table.insert(t, {title = 'Vibix', mrl = '#stream/q=vibix&id3=' .. args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
   

  
   table.insert(t, {title = 'Krasview', mrl = '#stream/q=krasview&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
 --   table.insert(t, {title = 'Getstv', mrl = '#stream/q=getstv&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3, image = image})
    
    table.insert(t, {title = 'Anwap', mrl = '#stream/q=anwap&id1=' .. args.id1 .. '&id5=' .. '1' .. '&id6=' .. 'on'})
    
   table.insert(t, {title = 'Kinotochka', mrl = '#stream/q=kinotochka&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   
 -- table.insert(t, {title = 'Rezka', mrl = '#stream/q=hdrezkatest&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
      table.insert(t, {title = 'Rezka', mrl = '#stream/q=hdrezkatest1&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
   table.insert(t, {title = 'HdRezka', mrl = '#stream/q=hdrezka&id1=' .. args.id1 .. '&id2=' .. args.id2})
   
   
   
   table.insert(t, {title = 'Kinobase', mrl = '#stream/q=kinobase&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 

table.insert(t, {title = 'Kinotop', mrl = '#stream/q=kinotop&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
 
 
 table.insert(t, {title = 'Kinoserials', mrl = '#stream/q=videoseed2&id3=' ..  args.id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
  
 table.insert(t, {title = 'Videoseed', mrl = '#stream/q=videoseed&id3=' ..  args.id3})
 
 
   table.insert(t, {title = 'Vkmovie', mrl = '#stream/q=vkmovie&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Rutube', mrl = '#stream/q=rutube&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   
   
   
   
table.insert(t, {title = 'Videohub', mrl = '#stream/q=cdnvideohub&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
--  table.insert(t, {title = 'Kinogo', mrl = '#stream/q=kinogo&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
-- table.insert(t, {title = 'Zagonka', mrl = '#stream/q=zagonka&id3=' .. args.id3})
  
 --table.insert(t, {title = 'test', mrl = '#stream/q=test&id1=' .. args.id1 .. '&id3=' .. args.id3})
  
  
-- table.insert(t, {title = 'Kinogotest', mrl = '#stream/q=kinogotest&id1=' .. args.id1 .. '&id3=' .. args.id3})
  
  table.insert(t, {title = 'Kinogo', mrl = '#stream/q=kinogox&id1=' .. args.id1 .. '&id2=' .. args.id2})
  
  
   
table.insert(t, {title = 'Remux', mrl = '#stream/q=remux&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   
   table.insert(t, {title = 'Jac', mrl = '#stream/q=jac&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
  
  
  table.insert(t, {title = 'Jacred', mrl = '#stream/q=jacred&id1=' .. args.id1 .. '&id2=' .. args.id2, image = image})
  
   
   table.insert(t, {title = 'Pidtor', mrl = '#stream/q=pidtor&id1=' .. args.id1 .. '&id2=' .. args.id2  .. '&id3=' ..  args.id3})
   
   table.insert(t, {title = 'Torrs', mrl = '#stream/q=torrs&id1=' .. args.id1 .. '&id2=' .. args.id2, image = image})
   
   
   
   
   table.insert(t, {title = 'Veo', mrl = '#stream/q=veo&id3=' .. args.id3, image = image})
   
   
table.insert(t, {title = 'Veoveo', mrl = '#stream/q=veoveo&id3=' .. args.id3 .. '&id1=' .. args.id1})

--table.insert(t, {title = 'Rapidcdn', mrl = '#stream/q=rapidcdn&id1=' .. args.id1 .. '&id2=' .. args.id2})




--table.insert(t, {title = 'Xkino', mrl = '#stream/q=xkino&id4=' .. args.id4})

--https://storage.videoseedcdn.com/movies/bd691b21ee132554ba429035fcd60e94f9ccaae8/04a52eaa9575c08e155647bda7b47423:2026011806/1080.mp4:hls:manifest.m3u8


--http://178.20.46.40:8975/https://cdn.fancdn.net/movies/bcd9da3930c90fe6e4630548f74594a91bd47c75/ae5665e59cc4145e3f00ca7c1d9058ed:2026012606/1080.mp4:hls:manifest.m3u8


--https://tv-1-kinoserial.net/api_player.php?kp_id=386&token=fbdcf2438c4f9f0ed76121801807891a

--https://tv-2-kinoserial.net/embed/80622/?token=fbdcf2438c4f9f0ed76121801807891a

--https://storage.videoseedcdn.com/movies/aec50961c21ef09d0040260875ff6627d9728a49/bfd76f0b07fdcc385574bcc1bbc18767:2026011806/1080.mp4:hls:manifest.m3u8

--https://tv-1-videoseedcdn.com/embed/26728/?token=fbdcf2438c4f9f0ed76121801807891a

--https://videoseed.tv/apiv2.php?item=movie&token=5333b968b6a054766ee984eee92d202d&kp=386

--https://videoseed.tv/apiv2.php?item=movie&token=fbdcf2438c4f9f0ed76121801807891a&kp=386
 
-- https://api.videoseed.tv/embed/32489/?token=fbdcf2438c4f9f0ed76121801807891a
 
 
--https://api.videoseed.tv/apiv2.php?item=movie&token=fbdcf2438c4f9f0ed76121801807891a&kp=386
 
 
 
 
-- https://api.rstprgapipt.com/balancer-api/iframe?kp=1338024&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI
 
 
 
-- https://lamp-movie.ru/proxy/ZHIM6TGAty9DENCUXI0WgbWABkCG8d5eYFt9ugGnaifV6o6r4JSbogF6tULIbPy8ubQ2zoTCK7p91ZFpyLN2Z7YbW7aoURb34AcmP8Rj2V237gA+0RssGh+FWHxl56EabeEQbhVAsos4xLa2TRcCY5fayg05xD6Ujjcn9TIBhmKLnGKR\u002BOq5SdPykrmA/9dQRUwcv6hGPPC4RohGLKfc9+k/BdPpgiYpind0xbQrLLKuyLhGqI3IqW+ZG4ei4LUygJ1bCikGN41iVikFBHYLX/PnD9XLxbU+/CgZXJ9fkgHyKt6qW29Obzzc3Hd4DIhFYCM9Yz5oP4ccX/7nlQ/1qo2gh9oVSUYqevvoK7E6SnU=.m3u8
 
 
 --https://evkh.lol
 
-- https://lam.maxvol.pro/lite/kinogo?kinopoisk_id=386&title=чужой&year=1979
 
--http://lampac.egorpomidor.site
 
 -- http://93.183.95.219:11378/lite/kinogo?href=56119-strazhi-galaktiki-chast-3-2023.html
 
--https://lampa.persh1n.ru/lite/kinogo?href=56119-strazhi-galaktiki-chast-3-2023.html

--https://lampa.persh1n.ru/lite/kinogo?rjson=False&title=%D0%A1%D1%82%D1%80%D0%B0%D0%B6%D0%B8+%D0%93%D0%B0%D0%BB%D0%B0%D0%BA%D1%82%D0%B8%D0%BA%D0%B8+%D0%A7%D0%B0%D1%81%D1%82%D1%8C+3+&serial=1&year=2025


--https://lampa.persh1n.ru/lite/kinogo?rjson=False&title=%D0%A1%D1%82%D1%80%D0%B0%D0%B6%D0%B8+%D0%93%D0%B0%D0%BB%D0%B0%D0%BA%D1%82%D0%B8%D0%BA%D0%B8%2E+%D0%A7%D0%B0%D1%81%D1%82%D1%8C+3&serial=1&original_language=ru&year=2023






    elseif args.q == 'flixcdnm' then

 
-- https://cdn0.cdnhub.help/show/kinopoisk/386?domain=piratka.tv
 
 
 --local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv')

local x = conn:load('https://api0.flixcdn.biz/api/search?token=7f2eb77db29b1304d42741f625f6d09e&kinopoisk_id=' .. args.id3)
 
 x = string.gsub(x, '\\', '')	
 
 for api in string.gmatch(x, '"iframe_url":"(http.-)"') do
 

   local x = conn:load(api .. '?domain=piratka.tv')


local slist = string.match(x, '<select name="translator"(.-)movies')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
         
    local x = conn:load(api .. '?domain=piratka.tv&translation=' .. id5)

--table.insert(t, {title = api .. '?domain=piratka.tv&translation=' .. id5, mrl = api .. '?domain=piratka.tv&translation=' .. id5})

  --  local slist = string.match(x, 'file.-:(.-)CDNquality')

  --  if slist then
 
 for title1, url in string.gmatch(x, '%[(240)](http.-mp4)') do

--url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

--table.insert(t, {title = url, mrl = url})

   end
 
 for title1, url in string.gmatch(x, '%[(360)](http.-mp4)') do

--url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
 
for title1, url in string.gmatch(x, '%[(480)](http.-mp4)') do

--url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
 
for title1, url in string.gmatch(x, '%[(720)](http.-mp4)') do

url = string.gsub(url, '/480.mp4', '/720.mp4') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
 
for title1, url in string.gmatch(x, '%[(1080)](http.-mp4)') do

url = string.gsub(url, '/480.mp4', '/1080.mp4') 

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
 
 
   end
end
 



 
    local x = conn:load(api .. '?domain=piratka.tv&autoplay=1&extrans=1')



local slist = string.match(x, '<select name="season"(.-)</select>')
  
      if slist then
                                             for id2, title1 in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
                                    

  local slist = string.match(x, '<select name="episode"(.-)</select>')
  
      if slist then
                                            for id4, title2 in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do





  local slist = string.match(x, '<select name="translator"(.-)series')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
 id5 = string.gsub(id5, '^(.-)', api .. '?domain=piratka.tv&autoplay=1&extrans=1&translation=') 
 
 

    t['view'] = 'simple'

   table.insert(t, {title = title1 .. ' ' .. title2 .. ' ' .. title, mrl = '#stream/q=flixcdns&id3=' .. args.id3 .. '&id5=' .. id5 .. '&id1=' .. title .. '&id2=' .. id2 .. '&id4=' .. id4})

  end
   end
   end
   end
    end
 end
  end 
   
    

    
    
    
    elseif args.q == 'flixcdns' then  
    
    local x = conn:load(args.id5 .. '&season=' .. args.id2 .. '&episode=' .. args.id4)
    
 --     local slist = string.match(x, 'file.-:(.-)CDNquality')

  --  if slist then
 
 for title, url in string.gmatch(x, '%[(240)](http.-mp4)') do

--url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
  
for title, url in string.gmatch(x, '%[(360)](http.-mp4)') do

--url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})

end

for title, url in string.gmatch(x, '%[(480)](http.-mp4)') do

--url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})

end


for title, url in string.gmatch(x, '%[(720)](http.-mp4)') do

url = string.gsub(url, '/480.mp4', '/720.mp4') 

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})

end


for title, url in string.gmatch(x, '%[(1080)](http.-mp4)') do

url = string.gsub(url, '/480.mp4', '/1080.mp4') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})

end




--https://api0.flixcdn.biz/api/search?token=7f2eb77db29b1304d42741f625f6d09e&kinopoisk_id=319

  elseif args.q == 'flixcdn' then

 
-- https://cdn0.cdnhub.help/show/kinopoisk/386?domain=piratka.tv
 --https://player0.flixcdn.space/show/kinopoisk/
 
 
 local x = conn:load('https://api0.flixcdn.biz/api/search?token=7f2eb77db29b1304d42741f625f6d09e&kinopoisk_id=' .. args.id3)
 
 x = string.gsub(x, '\\', '')	
 
 for api in string.gmatch(x, '"iframe_url":"(http.-)"') do
 
 
-- local x = conn:load('https://cdn0.cdnhub.help/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv')

   
   
   
   local x = conn:load(api .. '?domain=piratka.tv')

local slist = string.match(x, '<select name="translator"(.-)movies')
 
 
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
         
    local x = conn:load(api .. '?domain=piratka.tv&translation=' .. id5)


 


  --  local slist = string.match(x, 'charset(.-)window.PlayerjsEvents')



    if x then
 
 for title1, url in string.gmatch(x, '%[(240)](http.-m3u8)') do


 

--url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

--table.insert(t, {title = url, mrl = 'http://5.180.45.229/hls/' .. url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
   
   for title1, url in string.gmatch(x, '%[(360)](http.-m3u8)') do

--url = string.gsub(url, '^(.-)', 'http://5.180.45.229/hls/')	 


--url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
  
for title1, url in string.gmatch(x, '%[(480)](http.-m3u8)') do

--url = string.gsub(url, '^(.-)', 'http://5.180.45.229/hls/')	 

--url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
   
for title1, url in string.gmatch(x, '%[(720)](http.-m3u8)') do

--url = string.gsub(url, '^(.-)', 'http://5.180.45.229/hls/')	 

url = string.gsub(url, '/480.mp4', '/720.mp4') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   
for title1, url in string.gmatch(x, '%[(1080)](http.-m3u8)') do

--url = string.gsub(url, '^(.-)', 'http://5.180.45.229/hls/')	 

url = string.gsub(url, '/480.mp4', '/1080.mp4') 
 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   
   
   end
end
 end



 
  --  local x = conn:load('https://cdn0.cdnhub.help/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv&autoplay=1&extrans=1')



local slist = string.match(x, '<select name="season"(.-)</select>')
  
      if slist then
                                             for id2, title1 in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
                                    

  local slist = string.match(x, '<select name="episode"(.-)</select>')
  
      if slist then
                                            for id4, title2 in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do





  local slist = string.match(x, '<select name="translator"(.-)series')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
 id5 = string.gsub(id5, '^(.-)', api .. '?domain=piratka.tv&autoplay=1&extrans=1&translation=') 
 
 

    t['view'] = 'simple'

   table.insert(t, {title = title1 .. ' ' .. title2 .. ' ' .. title, mrl = '#stream/q=flixcdns&id3=' .. args.id3 .. '&id5=' .. id5 .. '&id1=' .. title .. '&id2=' .. id2 .. '&id4=' .. id4})

  end
   end
   end
   end
    end
 end
   
 end  
    
    elseif args.q == 'flixcdns' then  
    
    local x = conn:load(args.id5 .. '&season=' .. args.id2 .. '&episode=' .. args.id4)
    
   --   local slist = string.match(x, 'file.-:(.-)CDNquality')

  --  if slist then
 
 
 for title, url in string.gmatch(x, '%[(240)](http.-m3u8)') do

--url = string.gsub(url, '^(.-)', 'http://5.180.45.229/hls/')	 

--url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
 
 for title, url in string.gmatch(x, '%[(360)](http.-m3u8)') do

--url = string.gsub(url, '^(.-)', 'http://5.180.45.229/hls/')	 

--url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
   
for title, url in string.gmatch(x, '%[(480)](http.-m3u8)') do

--url = string.gsub(url, '^(.-)', 'http://5.180.45.229/hls/')	 

--url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end

for title, url in string.gmatch(x, '%[(720)](http.-m3u8)') do


--url = string.gsub(url, '^(.-)', 'http://5.180.45.229/hls/')	 

url = string.gsub(url, '/480.mp4', '/720.mp4') 

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end

for title, url in string.gmatch(x, '%[(1080)](http.-m3u8)') do

--url = string.gsub(url, '^(.-)', 'http://5.180.45.229/hls/')	 

url = string.gsub(url, '/480.mp4', '/1080.mp4')  
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end



--  https://player0.flixcdn.space/show/kinopoisk/386?domain=piratka.tv&autoplay=1&extrans=1&translation=




   elseif args.q == 'krasview' then

    local x = conn1:load('https://krasview.ru/movie?mode=search&ajax&query=' .. urlencode(args.id1) .. ',' .. args.id2)


   for url, total in string.gmatch(x, '<li id=.-<a href=.-(http.-)\'.-alt=\'(.-)\'>') do


      local x = conn1:load(url)



    for id in string.gmatch(x, '<ul class=.-video%-gallery.-itemscope itemtype=.-id=\'v%-(.-)\'') do

     id = string.gsub(id, '^(.-)', 'https://zedfilm.ru/') 
 
  -- table.insert(t, {title = id, mrl = id})
   
     local x = conn1:load(id)
 
 for url1 in string.gmatch(x, 'video_Init.-\'(.-)\'') do
 
 
    url1 = base64_decode(url1)
   
 
   for url2, url3, url4 in string.gmatch(url1, '"url2":"(http.-)"') do
    
    
      url2 = string.gsub(url2, 'media', 'm')
         t['view'] = 'simple'
table.insert(t, {title = total, mrl = url2})


--https://m5.krasview.ru/video/468d084cca7cd16/e9e9e5fff9cf10b.m3u8


--https://m5.krasview.ru/video/468d084cca7cd16/video-1080.m3u8

--https://m5.krasview.ru/video/468d084cca7cd16/video.m3u8

--https://m5.krasview.ru/video/468d084cca7cd16/video-360.m3u8

    end
end
end
end

--https://sersoap.ru/series/Game_of_Thrones/?page=2

    local x = conn1:load('https://krasview.ru/series?mode=search&ajax&query=' .. urlencode(args.id1))
    --.. ',' .. args.id2)


    for url, total in string.gmatch(x, '<li id=.-<a href=\'(http.-)\'.-alt=\'(.-)\'') do
         t['view'] = 'simple'
 
    table.insert(t, {title = tolazy(total), mrl = '#stream/q=krasviews&id=' .. url})
    end
 
   elseif args.q == 'krasviews' then

local page = tonumber(args.page or 1)

      local x = conn1:load(args.id .. '?page=' .. tostring(page))



   for id, title in string.gmatch(x, '<li itemprop=\'itemListElement\' itemscope itemtype=.-id=\'v%-(.-)\'.-alt=\'(.-)\'') do

   id = string.gsub(id, '^(.-)', 'https://zedfilm.ru/') 
 
     local x = conn1:load(id)
 
 for url1 in string.gmatch(x, 'video_Init.-\'(.-)\'') do
 
 
    url1 = base64_decode(url1)
   
 
   for url2 in string.gmatch(url1, '"url2":"(http.-)"') do
    
    
      url2 = string.gsub(url2, 'media', 'm')
         t['view'] = 'simple'
table.insert(t, {title = tolazy(title), mrl = url2})

    end
end
end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=krasviews&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})





--https://m4.krasview.ru/video/07022833dea865d/eb9e2b471a474eb-1080.mp4

  --http://93.183.95.219:11378
 
 
-- http://31.129.234.181:80
 
--https://kinogo.luxury/search/filmy/%D0%A7%D1%83%D0%B6%D0%BE%D0%B9
 
 -- },getAllResponseHeaders:function(){return h?p:null},setRequestHeader:function(e,
  
-- htstRequest
 
-- htst = document.createElement('video');return Boolean(htst.canPlayType('application/vnd.apple.mpegURL'
 
 

 --href="http://abc.zagonkop.gb.net/embed/css.css?v=220
 --http://abc.zagonkop.gb.net/embed/engine/classes/js/jquery.js?v=2
--http://abc.zagonkop.gb.net/embed/js/pjs.js?v=220
--http://abc.zagonkop.gb.net/embed/js/hls.js?v=220

 

 --http://abc.zagonkop.gb.net/embed/js/pl.js?v=220
 
 --http://abc.zagonkop.gb.net/embed//engine/classes/highslide/highslide.js?v1
 
 elseif args.q == 'zagonka' then
 
--js.global:document(


local headers = {['X-Requested-With'] = 'XMLHttpRequest'
,['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3',['Server'] = 'openresty',
['Content-Type'] = 'text/html; charset=UTF-8',
['Transfer-Encoding'] = 'chunked',
['Connection'] = 'keep-alive',
['X-Robots-Tag'] = 'noindex, follow, noarchive',
['X-Accel-Expires'] = '0',
['Referrer-Policy'] = 'no-referrer',
['Set-Cookie'] = 'PHPSESSID=32d1c3b8d717d468c5312753772e6f4c; path=/',
['cache-control'] = 'max-age=15, public',
['Expires'] = 'Fri, 06 Mar 2026 03:38:05 GMT',
['Access-Control-Allow-Origin'] = 'http://abc.zagonkop.gb.net',
['X-FastCGI-Cache'] = 'MISS'}



--http://zagonka5.zagonkomv.gb.net/embed/kp-386

  --  local video = ('https://cors.nb557.workers.dev:8443/http://player.zagonka.net/embed/kp-' .. args.id3)

  
--local video = 'https://apn-latest.onrender.com/http://player.zagonka.net/embed/kp-' .. args.id3
  
    
--https://apn-latest.onrender.com/https://warp-gen-vip.vercel.app/http://abc.zagonkop.gb.net/17613-1_chuzhoj-1979-onlayn.html

--local url = 'https://iqslgbok.deploy.cx/http://abc.zagonkop.gb.net/embed/kp-' .. args.id3

--https://web.scraper.workers.dev/http://abc.zagonkop.gb.net/embed/kp-386

--https://subs.online-store.su/M6PtxNGopmXaN7Gb/http://abc.zagonkop.gb.net/embed/kp-386



--http://abc.zagonkop.gb.net/away.php?i%3AaHR0cDovL2FiYy56YWdvbmtvcC5nYi5uZXQvZW1iZWQva3AtMzg2



--https://zagonka.tv/away.php?i%3AaHR0cHM6Ly9tYy55YW5kZXgucnUvd2F0Y2gvNzIyNDk4Mg%3D%3D


--https://apn-latest.onrender.com/http://zagonka30.zagonkop.gb.net/engine/ajax/down.php?id=17613&kpid=386


 

local x = conn:load('http://abc.zagonkop.gb.net/embed/kp-' .. args.id3 .. '?v=1', headers)
--  if x~=200 then return end
url = url_for(x)

  --local url = conn:load(x,response_headers)

local data = string.match(x,'Playerjs.-#2(.-)"') 
 
 url = url_for(data)
 

 
 table.insert(t, {title = url, mrl = url})
--return table.concat(response_body)
--end







 elseif args.q == 'kinogox' then

--http://kb-team.club/?do=/plugin&bid=iptvk&box_client=ott-foss&m3u&box_mac=40163b66e658

--http://kb-team.club/msx/kinozal/videocdn.php?device=c802104fe8fc


--http://kb-team.club/msx/enter.php

--http://kb-team.club/msx/msxFork.php?start&plugin=cGx1Z2luJmJpZD1hbGxvaGE-&device=40163b66e658
--d41d8cd98f00


local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofor-kinofor&act=search&search=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&box_mac=acace24b8434')
 
 
 
 for title, url in string.gmatch(x, '<channel>.-title><!%[CDATA%[(.-)]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do
 
 local x = conn:load(url .. '&box_mac=acace24b8434')
 
 for total, url1 in string.gmatch(x, '<channel>.-title><!%[CDATA%[(.-)]]></title.-<stream_url><!%[CDATA%[(http.-)]]') do
 
 t['view'] = 'simple'


   table.insert(t, {title = tolazy(total), mrl = url1})

       
    end
   end






local headers = {['X-Requested-With'] = 'XMLHttpRequest'}

--https://kinogo.ec

--https://kinogo2026.net/124462-grenlandija-2-migracija.html#124462

--https://kinogo2026.net/index.php?story=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB+2025&do=search&subaction=search

 local x = conn:load('https://kinogo2026.net/index.php?story=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&do=search&subaction=search',headers)
 
--table.insert(t, {title = 'https://kinogo2026.net/index.php?story=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&do=search&subaction=search', mrl = 'https://iqslgbok.deploy.cx/https://kinogo.ec/index.php?story=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&do=search&subaction=search'})


 for url1, title in string.gmatch(x, '<h2.-href.-(http.-)#.->(.-)<') do
 


 local x = conn:load(url1)
 
--table.insert(t, {title = 'https://kinogo2026.net' .. url1, mrl = 'https://iqslgbok.deploy.cx/https://kinogo2026.net' .. url1})
 
 
 local url2 = string.match(x, '(//cinemar.cc/embed/.-)"')
 
 url = string.gsub(url2, '^(.-)', 'https://apn-latest.onrender.com/https:')
 
 --local url = 'https://apn-latest.onrender.com/https:' .. url2
 
--table.insert(t, {title = url, mrl = url})
 
-- ['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0'
 
 local r = {}
 local headers = {['Strict-Transport-Security'] = 'max-age=15; includeSubDomains',['X-Requested-With'] = 'XMLHttpRequest',
['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3',
['Accept'] = '*/*',
['Accept-Language'] = 'en-US,en;q=0.5',
['Accept-Encoding'] = 'gzip, deflate, br',
['DNT'] = '1',
['Connection'] = 'keep-alive',
['Referer'] = 'https://cinemar.cc/',
['Upgrade-Insecure-Requests'] = '1',
['Sec-Fetch-Dest'] = 'empty',
['Sec-Fetch-Mode'] = 'cors',
['Sec-Fetch-Site'] = 'cross-site',
['Pragma'] = 'no-cache',
['Cache-Control'] = 'no-cache'}
 
 n = {
    url = url,
    headers = headers
   } 
 

 
-- string fileEncode = Regex.Match(embedHtml, "\"file\":\"([^\"]+)\"")
 

 local x = conn:load(url, headers, r)



-- x = string.gsub(x)
-- print(x)

 for url3 in string.gmatch(x,'\"file\":\".-(W3sia.-\"+)') do
 
 url3 = string.gsub(url3,'#','')
 
 

-- for url3 in string.gmatch(x, '"file":".-(W3sia.-)"') do
 

 
url3 = base64_decode(http.urldecode(url3))
 


 url3 = string.gsub(url3, '\\u0410', 'А')
      url3 = string.gsub(url3, '\\u0430', 'а')
       
       url3 = string.gsub(url3, '\\u0411', 'Б')
       url3 = string.gsub(url3, '\\u0431', 'б')  
       url3 = string.gsub(url3, '\\u0412', 'В')
      url3 = string.gsub(url3, '\\u0432', 'в')
       url3 = string.gsub(url3, '\\u0413', 'Г')
       url3 = string.gsub(url3, '\\u0433', 'г')  
      url3 = string.gsub(url3, '\\u0414', 'Д')
      url3 = string.gsub(url3, '\\u0434', 'д')
       url3 = string.gsub(url3, '\\u0415', 'Е')
       url3 = string.gsub(url3, '\\u0435', 'е')  
      url3 = string.gsub(url3, '\\u0401', 'Ё')
      url3 = string.gsub(url3, '\\u0451', 'ё')
       url3 = string.gsub(url3, '\\u0416', 'Ж')
       url3 = string.gsub(url3, '\\u0436', 'ж')  
       url3 = string.gsub(url3, '\\u0417', 'З')
      url3 = string.gsub(url3, '\\u0437', 'з')
       url3 = string.gsub(url3, '\\u0418', 'И')
       url3 = string.gsub(url3, '\\u0438', 'и')  
       url3 = string.gsub(url3, '\\u0419', 'Й')
      url3 = string.gsub(url3, '\\u0439', 'й')
       url3 = string.gsub(url3, '\\u041a', 'К')
       url3 = string.gsub(url3, '\\u043a', 'к')  
       url3 = string.gsub(url3, '\\u041b', 'Л')
       url3 = string.gsub(url3, '\\u043b', 'л')
       url3 = string.gsub(url3, '\\u041c', 'М')
       url3 = string.gsub(url3, '\\u043c', 'м')
       url3 = string.gsub(url3, '\\u041d', 'Н')
       url3 = string.gsub(url3, '\\u043d', 'н')
       url3 = string.gsub(url3, '\\u041e', 'О')
       url3 = string.gsub(url3, '\\u043e', 'о')
       url3 = string.gsub(url3, '\\u041f', 'П')
       url3 = string.gsub(url3, '\\u043f', 'п')
       url3 = string.gsub(url3, '\\u0420', 'Р')
       url3 = string.gsub(url3, '\\u0440', 'р')
       url3 = string.gsub(url3, '\\u0421', 'С')
       url3 = string.gsub(url3, '\\u0441', 'с')
       url3 = string.gsub(url3, '\\u0422', 'Т')
       url3 = string.gsub(url3, '\\u0442', 'т')
       url3 = string.gsub(url3, '\\u0423', 'У')
       url3 = string.gsub(url3, '\\u0443', 'у')
       url3 = string.gsub(url3, '\\u0424', 'Ф')
        url3 = string.gsub(url3, '\\u0444', 'ф')
        url3 = string.gsub(url3, '\\u0425', 'Х')
        url3 = string.gsub(url3, '\\u0445', 'х')
        url3 = string.gsub(url3, '\\u0426', 'Ц')
        url3 = string.gsub(url3, '\\u0446', 'ц')
        url3 = string.gsub(url3, '\\u0427', 'Ч')
        url3 = string.gsub(url3, '\\u0447', 'ч')
        url3 = string.gsub(url3, '\\u0428', 'Ш')
        url3 = string.gsub(url3, '\\u0448', 'ш')
        url3 = string.gsub(url3, '\\u0429', 'Щ')
        url3 = string.gsub(url3, '\\u0449', 'щ')
        url3 = string.gsub(url3, '\\u042a', 'Ъ')
        url3 = string.gsub(url3, '\\u044a', 'ъ')
        url3 = string.gsub(url3, '\\u042b', 'Ы')
        url3 = string.gsub(url3, '\\u044b', 'ы')
        url3 = string.gsub(url3, '\\u042c', 'Ь')
        url3 = string.gsub(url3, '\\u044c', 'ь')
        url3 = string.gsub(url3, '\\u042d', 'Э')
        url3 = string.gsub(url3, '\\u044d', 'э')
        url3 = string.gsub(url3, '\\u042e', 'Ю')
        url3 = string.gsub(url3, '\\u044e', 'ю')
        url3 = string.gsub(url3, '\\u042f', 'Я')
        url3 = string.gsub(url3, '\\u044f', 'я')
        url3 = string.gsub(url3, '\\u00ab', '<<')
        url3 = string.gsub(url3, '\\u00bb', '>>')
        url3 = string.gsub(url3, '\\u2014', '-')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/us.png\\" alt=\\"\\">', '')

url3 = string.gsub(url3, '<img src=\\"\\/flags\\/ua.png\\" alt=\\"\\">', '')


 
 --table.insert(t, {title = url3, mrl = url3})
 
-- {"id":".-","src_id":.-,"voice_id":.-,"title":"(.-)","title2":"(.-)".-"file":"(.-m3u8)"

 for title, title1, url4 in string.gmatch(url3, '{"id":".-","src_id":.-,"voice_id":.-,"title":"(.-)","title2":"(.-)",.-"file":"(.-m3u8)"') do
 
 t['view'] = 'simple'
 
 url4 = string.gsub(url4,'\\','')
 
 url4 = string.gsub(url4,'^(.-)','https:')
 

 
 table.insert(t, {title = title1 .. title, mrl = url4})

end
 end
 end
--end
 
 
 
 
 
 
 
 
 elseif args.q == 'test' then
 
 

 
 
local url = 'https://w140.zona.plus/ajax/video/2868935?client_time=1769403672'
    
    
    
        local cookies = {
            _ym_uid = '1685951488624399200',
            _ym_d = '1685951488',
            _ga = 'GA1.2.1205909313.1685951488',
            _gid = 'GA1.2.31974282.1685951488',
            _ym_visorc = 'b',
            _ym_isad = '2',
            _buzz_fpc = 'JTdCJTIycGF0aCUyMiUzQSUyMiUyRiUyMiUyQyUyMmRvbWFpbiUyMiUzQSUyMi53MTQwLnpvbmEucGx1cyUyMiUyQyUyMmV4cGlyZXMlMjIlM0ElMjJXZWQlMkMlMjAwNSUyMEp1biUyMDIwMjQlMjAwOCUzQTMwJTNBNTklMjBHTVQlMjIlMkMlMjJTYW1lU2l0ZSUyMiUzQSUyMkxheCUyMiUyQyUyMnZhbHVlJTIyJTNBJTIyJTdCJTVDJTIydWZwJTVDJTIyJTNBJTVDJTIyMzUwZjA4ZjFmZTY2YmQ3ZGE1MmRhMmZkYWJkOTAwYWMlNUMlMjIlMkMlNUMlMjJicm93c2VyVmVyc2lvbiU1QyUyMiUzQSU1QyUyMjExMy4wJTVDJTIyJTdEJTIyJTdE',
            __upin = 'Te7Wz49Kadq4g4afsfh0Aw',
            _ohmybid_cmf = '2',
            adtech_uid = '928b96f6-71c3-4991-8418-8775cd4f6afb%3Azona.plus',
            top100_id = 't1.7627570.1236391857.1685951615289',
            t3_sid_7627570 = 's1.22459236.1685951615291.1685953879223.1.7',
            last_visit = '1685917879021%3A%3A1685953879021',
            ZONAMOBI = 'oibefqkgdfumjofr09uu16co16; path=/',
            uuid = '2306a8ba8dae8a94%3A3'
        }
        local headers = {
            ['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3',
            ['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            ['Accept-Language'] = 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
            ['Accept-Encoding'] = 'gzip, deflate, br',
            ['Connection'] = 'keep-alive',
            ['Sec-Fetch-Dest'] = 'document',
            ['Sec-Fetch-Mode'] = 'navigate',
            ['Sec-Fetch-Site'] = 'none',
            ['Sec-Fetch-User'] = '?1'
        }
 
 local x = conn:load(url, headers, cookies)
 url = url_for(x)


 table.insert(t, {title = url, mrl = url})




 elseif args.q == 'kinogotest' then
 
--https://cors.fx666.workers.dev:8443/https://api.apbugall.org/v2/movies/search/?kp=386&imdb_id=tt0078748&tmdb_id=348&token=e7b61f129f4a392ac4bf6726a9dd6a&token_movie=a6ef0986c7558c5792c3ad19d43611

--https://apbugall.org/v2/movies/search?id_kp=386&id_imdb=tt0078748&id_tmdb=348&token_movie=a6ef0986c7558c5792c3ad19d43611

--https://cors.fx666.workers.dev:8443/

local url = 'https://apbugall.org/v2/movies/search?kp=386&token=a6ef0986c7558c5792c3ad19d43611'


--local url = 'https://cors.fx666.workers.dev:8443/https://harald-as.newplayjj.com/?kp=386&token=token=e7b61f129f4a392ac4bf6726a9dd6a'



--local url = 'https://apbugall.org/v2/movies/search?kp=386&token=a6ef0986c7558c5792c3ad19d43611'
--local response_body = {}


local token = 'pXzvbyDGLYyB6VkwsWZDv3iMKZtsXNzpzRyxZUcsKHXxsSeaYakbo3hw9mBFRc5VQTpqAX6BW8aDEqyLaHYcXSQiV6KHYTVTK6MYRphNAy5sBjtrevqkDzKmLqNdfMZGEU9NELjmtKfZy3RNGzCd767sNh1mXEj4tCcvqndHtzmwAbZNkhm4ghDEasodotMBewypNQ56uotJAQGX11csfeRfBAPk8DcUWWkkqzxca8vbnEw12vUFbBzT6hz8ZB3F3dzUhUXoL2cr1WM1bXQArRCS1MUNMz3X5WDMMQoZKxj2AMTRqp7QQX4dDB9B7VzEZTmyFULhm1AcHHMkoMvSVvKYoBoAKLycYAgMHeD4ECJcGEAGpnkJhrV57zQ7'



--XMLHttpRequest

--local r = {}

--headers = {Authorization = 'Bearer ${token}'}

 local data = {method = 'GET', url,
headers = {["X-Requested-With"] = "XMLHttpRequest",["Authorizations"] = "Bearer " .. token,["Accept"] = "application/json" 
}}

local params = http.encode{
		kp = '386',
		token = e7b61f129f4a392ac4bf6726a9dd6a,
		
					}



--local params = {
      --  token = '9673771083c9eb06f6fb929331ce3a',
      --  domain = 'https%3A%2F%2Fdoor-as.newplayjj.com%3A9443%2F',
    --    device = '1',
  --      selector = '1',
       -- autoPlayChange = '0',
   --     saveTime = '1',
        
 --       fullscreen = '0',
      --  autoplay = '0',
   --     start = '0',
  --      audio = '',
   --     subtitle = '',
  --      log = '0',
 --       debug = '0',
 --   }
    local movie = {
        id = 'f0e4e83f6a2367c75592357115312d',
        type ='movie',
    }
 --   local urlPLog = 'https://iqslgbok.deploy.cx/https://ppc.ipchanger.live:11443/index.php?md5=Zi2TlGR4V5O2aK5-QvQqJQ&expires=1769837883'




n = {
    method = 'GET'
   } 



--local x = http.postz(n,headers)


local x = conn:load(data)



--local response_text = (n,headers)

--local x = conn:load('https://apbugall.org/v2/movies/search?kp=386&token=a6ef0986c7558c5792c3ad19d43611',headers,r)

--url1 = string.gsub(n,n,n)




--https://cors.fx666.workers.dev:8443/https://Avitaminosis-as.stloadi.live/?token=095d89f5d8e10355ef49dece98795f&kp=386

--https://672431256.videoframe2.com/api/v1/embed/kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz



--https://cors.fx666.workers.dev:8443/https://alloha.tv/embed?src=https://Avitaminosis-as.stloadi.live/?token_movie=a6ef0986c7558c5792c3ad19d43611&token=095d89f5d8e10355ef49dece98795f&autoplay=1

--https://Avitaminosis-as.stloadi.live/?token_movie=a6ef0986c7558c5792c3ad19d43611&token=095d89f5d8e10355ef49dece98795f
 
 
 -- x = json.decode(x)
 
 url = url_for(x)
-- x = urldecode(x)




 local userParam = {
    token = '095d89f5d8e10355ef49dece98795f',
    domain = 'https%3A%2F%2Favitaminosis-as.stloadi.live%2F',
    device = 1,
    selector = 1,
    autoPlayChange = 1,
    saveTime = 1,
    hidden = 'JSON.parse(\'(.-)\')',
    fullscreen = 0,
    autoplay = 0,
    start = '0',
    audio = '',
    subtitle = '',
    log = 0,
    debug = 0
}

local movie = {
    id = '(.-)',
    type = '(.-)'
}

--for url in string.gmatch(x, 'urlPLog.-\'(.-)\'') do

--for token in string.gmatch(x, 'token = \'(.-)\',') do

--for total in string.gmatch(x, '"%[cat]":"(.-)"') do

--for id in string.gmatch(x, '"id":(.-),') do


--local x = conn:load(url,userParam,movie,headers1)

--local x = conn:load('https://Avitaminosis-as.stloadi.live' .. '/' .. total .. '/' .. id .. '&token=095d89f5d8e10355ef49dece98795f' .. '&av1=true',headers1)


--url = url_for(x)


 table.insert(t, {title = url, mrl = url})

 -- end
-- end
 --end
 
 
 
 
-- http://z01.online/lite/events?
 
--https://lam.maxvol.pro/lite/fancdn?kinopoisk_id=464475
  
 -- http://178.20.46.40:12600/
  
  elseif args.q == 'fancdn' then
 
 --https://lam.maxvol.pro/lite/fancdn?kinopoisk_id=386
 
 local x = conn:load('http://z01.online/lite/fancdn?kinopoisk_id=' .. args.id3)

-- table.insert(t, {title = 'http://178.20.46.40:12600/lite/fancdn?kinopoisk_id=' .. args.id3, mrl = 'http://178.20.46.40:12600/lite/fancdn?kinopoisk_id=' .. args.id3})

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
  
        --  url = string.gsub(url, '^(.-)', 'https://lam.maxvol.pro') 
     
url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
 
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls.m3u8', '480.mp4:hls:manifest.m3u8')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

 
    for url1, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
  
 url1 = string.gsub(url1, '\\u0026', '&')
     url1 = string.gsub(url1, '\\u002B', '+')
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end





elseif args.q == 'fanserial' then
 
 --https://lam.maxvol.pro/lite/fancdn?kinopoisk_id=386
 
 
 
-- https://fanserial.me/films.php?kp=570402
 
 local x = conn:load('https://fanserial.me/films.php?kp=' .. args.id3) 
 
 if x then
 
 for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(1080p)' .. tolazy(title), mrl = url})

end
 
   for title, url in string.gmatch(x, '"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '720.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(title), mrl = url})

end
 
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '480.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(title), mrl = url})

end
 
 
 for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '360.mp4:hls:manifest')

   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(title), mrl = url})

end
 
for title, url in string.gmatch(x,'"title":"(.-)","file":"(http.-)"') do
 
 url = string.gsub(url, '\\', '')
 
 url = string.gsub(url, 'hls', '240.mp4:hls:manifest')


   
   
 t['view'] = 'simple'

table.insert(t, {title = '(240p)' .. tolazy(title), mrl = url})

end
 
 end
 
 
 
 
 
local headers = {['X-Requested-With'] = 'XMLHttpRequest'
, ['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3',
['Server'] = 'ddos-guard',
['Connection'] = 'keep-alive',
['Keep-Alive'] = 'timeout=60',
['Set-Cookie'] = '__ddg8_=M1eAeJegjCoESH2r; Domain=.opravar.online; Path=/; Expires=Thu, 05-Mar-2026 17:45:45 GMT',
['Set-Cookie'] = '__ddg10_=1772731545; Domain=.opravar.online; Path=/; Expires=Thu, 05-Mar-2026 17:45:45 GMT',
['Set-Cookie'] = '__ddg9_=185.228.133.239; Domain=.opravar.online; Path=/; Expires=Thu, 05-Mar-2026 17:45:45 GMT',
['Content-Security-Policy'] = 'upgrade-insecure-requests;',
['Set-Cookie'] = '__ddg1_=m8GVy1LFbHMztg4oE7BK; Domain=.opravar.online; HttpOnly; Path=/; Expires=Fri, 05-Mar-2027 17:25:45 GMT',
['Content-Type'] = 'text/html; charset=UTF-8',
['Set-Cookie'] = 'PHPSESSID=rueknm41suikcuankk6rtun7cj; path=/; Secure; SameSite=None; secure',
['Expires'] = 'Thu, 19 Nov 1981 08:52:00 GMT',
['Cache-Control'] = 'no-store, no-cache, must-revalidate',
['Pragma'] = 'no-cache',
['P3P'] = 'CP="IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT"',
['Transfer-Encoding'] = 'chunked'}
 
 
 
 
 
 
 local x = conn:load('https://lomont.site/gt/' .. args.id3 .. '?&alloff=true', headers)


if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 


local data = string.match(x,'<div id="inputData"(.-)<div id="vPreloader"') 

if data then

for video, season, episode, title, voice in string.gmatch(data,'"video_id":(.-),"season":(.-),"episode":(.-),"voice_name":"(.-)","voice_id":(.-),') do


--local x = conn:load('https://lomont.site/player/responce.php?video_id=' .. video)
--.. '&season=' .. season .. '&episode=' .. episode .. '&voice=' .. voice)

--x = string.gsub(x, '\\', '')

--local url = string.match(x,'"src".-(http.-m3u8)"')

--t['view'] = 'simple'

--table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = url})

t['view'] = 'simple'


table.insert(t, {title = 'Сезон ' .. season .. ' серия ' .. episode .. ' ' .. title, mrl = '#stream/q=fanserials&id3=' .. args.id3 .. '&id=' .. video .. '&id1=' .. season .. '&id2=' .. episode .. '&id4=' .. voice .. '&id5=' .. title})


end
end
end

 elseif args.q == 'fanserials' then

local x = conn:load('https://lomont.site/player/responce.php?video_id=' .. args.id .. '&season=' .. args.id1 .. '&episode=' .. args.id2 .. '&voice=' .. args.id4 .. '&alloff=true', headers)
  --   print(x)


if x then

local url = string.match(x,'"src".-(http.-m3u8)"')

url = string.gsub(url, '\\', '')
  
 
      t['view'] = 'simple'


table.insert(t, {title = 'Сезон ' .. args.id1 .. ' серия ' .. args.id2 .. ' ' .. args.id5, mrl = url})

end






--https://fanserial.me/films.php?kp=570402

--https://playep.pro/pl/1235054

--https://gencit.info
--https://lomont.site/player/responce.php?video_id=991208

--https://cors.nb557.workers.dev:8443/https://lomont.site/gt/1235054

--https://cors.kp556.workers.dev/https://lomont.site/gt/1235054


--https://fanserial.me/player?file=https://lomont.site/gt/1235054?season=3&episode=20&voice=22&alloff=true


--https://fanserial.me/tvseries.php?kp=https://cors.nb557.workers.dev:8443/https://cors.bwa.workers.dev/

--https://apn-latest.onrender.com/78.40.199.67/https://lomont.site/gt/4910542

--https://apn-latest.onrender.com/ip/195.3.223.172/https://lomont.site/gt/4910542

--https://lomont.sitehttps://gencit.info/player/response.php?kp_id=1235054&season=3&episode=20&voice=22&alloff=true



-- http://lampac.egorpomidor.site/lite/kinogo?href=56119-strazhi-galaktiki-chast-3-2023.html
 
 --http://31.129.234.181:80
  elseif args.q == 'kinogo' then
 
 --http://kb-team.club/?do=/plugin&id=zetflix&box_mac=acace24b8434
 
 --http://kb-team.club/?do=/plugin&bid=zetflix-zetflix&act=view&stream=aHR0cHM6Ly8yMGZlYi56ZXQtZmxpeC5vbmxpbmUvc2VyaWFscy9raWJlcnN0YWxrZXIv&box_mac=acace24b8434
 
 --http://kb-team.club/?do=/plugin&bid=zetflix-zetflix&act=view&stream=aHR0cHM6Ly8yMGZlYi56ZXQtZmxpeC5vbmxpbmUvc2VyaWFscy9odHRwczovL3VhZml4Lm5ldC9zZXJpYWxzL2tpYmVyc3RhbGtlci8-&getepisodes&box_mac=acace24b8434
 
-- http://kb-team.club/?do=/plugin&bid=kinofor-kinofor&act=search&search=чужой+1979&box_mac=acace24b8434
 
-- http://kb-team.club/?do=/plugin&bid=kinofor-kinofor&act=view&stream=IzNwUjMjwWb0hmLq9Ga6VHaj1SLycDM1IzL5JXd4VHbu82Zv5War5id09yL6MHc0RHa&id=25072&src=kinogo&box_mac=acace24b8434
 
 
 local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofor-kinofor&act=search&search=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&box_mac=acace24b8434')
 
 
 
 for title, url in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do
 
 local x = conn:load(url .. '&box_mac=acace24b8434')
 
 for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title.-<stream_url><!%[CDATA%[(http.-)]]') do
 
 t['view'] = 'simple'


   table.insert(t, {title = tolazy(total), mrl = url1})

       
    end
   end
 
 
 local x = conn:load('http://lampac.egorpomidor.site/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
-- table.insert(t, {title = 'http://lampac.egorpomidor.site/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'http://lampac.egorpomidor.site/lite/kinogo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
 
    for url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"play","url":"http.-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
  
  
      
      
 url = string.gsub(url, '\\u0026', '&')
     url = string.gsub(url, '\\u002B', '+')
  
            url = string.gsub(url, '^(.-)', 'http://lampac.egorpomidor.site') 
     


      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total), mrl = url})

       
    end
 --   end
 
 
 
 for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'http://lampac.egorpomidor.site')
    

      local x = conn:load(url2)

  -- x = string.gsub(x, '< img', '')
   --  x = string.gsub(x, '<img', '')
   --  x = string.gsub(x, '">', '')
  
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
  
         url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'http://lampac.egorpomidor.site')
    
       
    
     local x = conn:load(url3)
     
    -- x = string.gsub(x, '<img', '')
  --   x = string.gsub(x, '">', '')
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
  
            url4 = string.gsub(url4, '^(.-)', 'http://lampac.egorpomidor.site') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end
 
 
-- https://a7c5ea7c.obrut.show/embed/1EjM/content/MTM4EjM?domain=gokino.su
 
 
--https://gokino.su/vv-player.php?path=/&movie_id=14981

 elseif args.q == 'veo' then

    local x = conn:load('https://api.rstprgapipt.com/balancer-api/iframe?kp=' .. args.id3 .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI')
 
  
 
   for id in string.gmatch(x, 'MOVIE_ID=(.-);') do
 


 local x = conn:load('https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=' .. id .. '&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI')
 
-- https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/contents/14981/available&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI
 
 

 
-- https://api.rstprgapipt.com/balancer-api/proxy/playlists/catalog-api/episodes?content-id=14981&token=eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiMzkwIiwiaXNzIjoiYXBpLXdlYm1hc3RlciIsInN1YiI6IjE5MyIsImlhdCI6MTc2MDQ0MTc3MCwianRpIjoiOGMwZjdjZTctNDkxNC00ZjQzLThmN2UtZjczYTA1N2QwODZlIiwic2NvcGUiOiJETEUifQ.XMd7StdM-mdB078Oh1nPWE50qhJyZKIV6ct1fCORvAI
 
 local slist = string.match(x, '"order":0.-"season".-"order":0(.-)}]}]')
 
 if slist then
 
 for url1, title in string.gmatch(slist, '"filepath":"(http.-)".-"title":"(.-)"') do
 
 t['view'] = 'simple'

   table.insert(t, {title = '(1080p)' .. title, mrl = url1})
end
end


 
 
 
 for total, total1, url1, title in string.gmatch(x, '"order":(.-),"season":.-"order":(.-)}.-"filepath":"(http.-)".-"title":"(.-)"') do
 
 --if total > 0 then
 
 t['view'] = 'simple'

 --= string.gsub(x, '0 сезон 0 серия', '')


   table.insert(t, {title = total1 .. ' ' .. 'сезон ' .. total .. ' серия ' .. title, mrl = url1})
-- end
 end

end
 
 
-- https://storage.videoseedcdn.com/movies/aec50961c21ef09d0040260875ff6627d9728a49/bfd76f0b07fdcc385574bcc1bbc18767:2026011806/1080.mp4:hls:manifest.m3u8
 
 
-- https://iqslgbok.deploy.cx/https://kinoserials.tv/videos/32489/32489/
 
-- https://kinoserials.tv/videos/32489/чужой/
-- https://kinoserials.tv/videos/1042459/get/
 
 --https://api.videoseed.tv/embed/32489/?token=6091e1d0bf421f73804d2f0dcc2bf1cf
 
 --https://apn-latest.onrender.com/https://videoseed.tv/videos/32489/chujoy/
 
 
 elseif args.q == 'videoseed2' then
 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
    for id in string.gmatch(x, '"name".-"id":"(.-)"') do
   
   
   local headers = {['X-Requested-With'] = 'XMLHttpRequest',['Host'] = 'kinoserials.tv',
['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0',
['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
['Accept-Language'] = 'en-US,en;q=0.5',
['Accept-Encoding'] = 'gzip, deflate, br',
['DNT'] = '1',
['Connection'] = 'keep-alive',
['Upgrade-Insecure-Requests'] = '1',
['Sec-Fetch-Dest'] = 'document',
['Sec-Fetch-Mode'] = 'navigate',
['Sec-Fetch-Site'] = 'cross-site',
['Pragma'] = 'no-cache',
['Cache-Control'] = 'no-cache'}
 
 
--https://tv-2-kinoserial.net/embed_auto/KP_ID/?token=ТОКЕН

--https://apn-latest.onrender.com/https://kinoserials.tv/videos/32489/чужой/?token=fa9664df0e6c5b063407d9ec408a6397
 
 
 
-- https://apn-latest.onrender.com/https://tv-2-kinoserial.net/embed_auto/386/?token=fa9664df0e6c5b063407d9ec408a6397
 
 
 --https://tv-2-kinoserial.net/embed/80622/?token=6091e1d0bf421f73804d2f0dcc2bf1cf
 
-- https://apn-latest.onrender.com/https://kinoserials.tv/videos/32489/get/?token=6091e1d0bf421f73804d2f0dcc2bf1cf
 
 local url = 'https://apn-latest.onrender.com/https://kinoserials.tv/videos/' .. id .. '/' .. 'get' .. '/?token=6091e1d0bf421f73804d2f0dcc2bf1cf'
   
  -- table.insert(t, {title = url, mrl = url})
   
 local x = conn:load(url, headers)
 
 
 local slist = string.match(x, '"#2(.-\"+)') 
 
 if slist then
 
 slist = string.gsub(slist, '|||', '')
 
 slist = string.gsub(slist, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 slist = string.gsub(slist, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 slist = string.gsub(slist, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
slist = string.gsub(slist, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

slist = string.gsub(slist, 'N3IzYXcyRWF0MD', '')

slist = string.gsub(slist, 'NBaUNHQTI2ME9CcWc', '')
 
slist = string.gsub(slist, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    


slist = http.urldecode(base64_decode(slist))


slist = string.gsub(slist, ';{', '"{')

--slist = string.gsub(slist)


-- table.insert(t, {title = slist, mrl = slist})

--local slist1 = string.match(slist, '"file":"(.-)"') 

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'simple'

--https://storage.videoseedcdn.com/tvseries/58b053ac37212065de0953ae6a3673ecac70122c/8f90e1587342df2f7361a16c8c4eeeb0:2026021209/1080.mp4:hls:manifest.m3u8

--table.insert(t, {title = url1, mrl = url1})

table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})
end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
  -- url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(slist, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   --url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end
 end
end
 
 

 
 local x = conn:load('https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')
	
	
x = string.gsub(x, 'tv%-1%-', '')

x = string.gsub(x, '%- %d сезон"', '')



-- local x = conn:load(url,headers)
 

        
 for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"http.-/embed/(.-)/') do
 

   
   t['view'] = 'simple'
   
 table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds2&id=' .. id})
 
 end

elseif args.q == 'videoseeds2' then

local x = conn:load('https://apn-latest.onrender.com/https://kinoserials.tv/videos/' .. args.id .. '/' .. 'get' .. '/?token=6091e1d0bf421f73804d2f0dcc2bf1cf')



local x = string.match(x, '"#2(.-\"+)')
 
 if x then
 
 x = string.gsub(x, '|||', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

    x =http.urldecode(base64_decode(x))


x = string.gsub(x, ';{', '"{')

--local slist = string.match(x, '"file":"(.-)"')
--if x then
 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'simple'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
--url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
  -- url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
 --  url1 = string.gsub(url1, '^(.-)', 'https://storage.videoseedcdn.com/')
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end
 end







 
 elseif args.q == 'videoseed' then


  local headers = {['X-Requested-With'] = 'XMLHttpRequest',['Host'] = 'kinoserials.tv',
['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0',
['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
['Accept-Language'] = 'en-US,en;q=0.5',
['Accept-Encoding'] = 'gzip, deflate, br',
['DNT'] = '1',
['Connection'] = 'keep-alive',
['Upgrade-Insecure-Requests'] = '1',
['Sec-Fetch-Dest'] = 'document',
['Sec-Fetch-Mode'] = 'navigate',
['Sec-Fetch-Site'] = 'cross-site',
['Pragma'] = 'no-cache',
['Cache-Control'] = 'no-cache'}

      local x = conn:load('https://api.videoseed.tv/apiv2.php?item=movie&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
    for url in string.gmatch(x, 'status.-"iframe":"http.-(/embed.-)"') do
   
   url = string.gsub(url, '^(.-)', 'https://kinoserials.tv')
   
 --  url = string.gsub(url, '^(.-)', 'https://tv-3-kinolot.net')
 
 --https://kinoserials.tv/embed/32489/?token=6091e1d0bf421f73804d2f0dcc2bf1cf

 --https://tv-2-kinoserial.net/embed_auto/386/?token=6091e1d0bf421f73804d2f0dcc2bf1cf
   
--https://tv-3-kinolot.net/embed/32489/?token=6091e1d0bf421f73804d2f0dcc2bf1cf
   
   url = string.gsub(url, '\\', '')
 
-- table.insert(t, {title = url, mrl = url})
 
 
     local x = conn:load('https://apn-latest.onrender.com/' .. url, headers)
 
    local x = string.match(x, '"#2(.-\"+)') 
 
 
 
 --if x then
 
 
 x = string.gsub(x, '|||', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

--http.urlencode(
    x =http.urldecode(base64_decode(x))

x = string.gsub(x, ';{', '"{')

--table.insert(t, {title = x, mrl = x})


--local slist = string.match(x, '"file":"(.-)"') 
 
if x then

   for total, url1 in string.gmatch(x,'"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end

end
end


    
local x = conn:load('https://api.videoseed.tv/apiv2.php?item=serial&token=6091e1d0bf421f73804d2f0dcc2bf1cf&kp=' .. args.id3)
 
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
x = string.gsub(x, '\\', '')
	
	
x = string.gsub(x, 'tv%-1%-', '')

x = string.gsub(x, '%- %d сезон"', '')



-- local x = conn:load(url,headers)
 

        
 for title, title1, id in string.gmatch(x, '"name":".-%- (.-сезон %-)(.-серия)".-"iframe":"http.-(/embed.-)"') do
 

   
   t['view'] = 'simple'
   
 table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=videoseeds&id=' .. id})
 
 end
 
 elseif args.q == 'videoseeds' then



     local x = conn:load('https://kinoserials.tv' .. args.id)
 
    local x = string.match(x, '"#2(.-\"+)') 
 
 --if x then
 
 
 
 x = string.gsub(x, '|||', '')
 
 x = string.gsub(x, 'aHhGTmhFdEpmZDFXZVprbnM2ZDdETHZKOHZ2OEU4OFhlbkF0WjRVdkRKZUJW', '')
 x = string.gsub(x, 'M2ROdXBUMXJmSUlJUWdGaDVYaGJrMmkxOFJmZTRHTjhEcTZJeEw1c2FHOVkx', '')
 
 x = string.gsub(x, 'cVZOUDAzNWZEbDNoZDA1UVpVa2tZc1JZQzFnbE9WRVJaVTBZR052cGVwRUZD', '')
 
x = string.gsub(x, 'ZzhjNzFJVVNhcm9xYjYzNkJUdDdobEtOTUE0b1I3MThueURiYmlNbTZQQ0Vo', '')

x = string.gsub(x, 'N3IzYXcyRWF0MD', '')

x = string.gsub(x, 'NBaUNHQTI2ME9CcWc', '')
 
x = string.gsub(x, '3cVltdFBiRzdhRlk4VDJiMUdTTnVM', '')

--http.urlencode(
    x =http.urldecode(base64_decode(x))

x = string.gsub(x, ';{', '"{')

  -- local slist = string.match(x, '"file":"(.-)"')

if x then
 
for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '1080.mp4:hls:manifest')

   
 t['view'] = 'simple'



table.insert(t, {title = '(1080p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '720.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(720p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '480.mp4:hls:manifest')
   

 t['view'] = 'simple'

table.insert(t, {title = '(480p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '360.mp4:hls:manifest')
   

   
 t['view'] = 'simple'

table.insert(t, {title = '(360p)' .. tolazy(total), mrl = url1})

end

for total, url1 in string.gmatch(x, '"{(.-)}.-(http.-m3u8)') do
   
   url1 = string.gsub(url1, 'hls', '240.mp4:hls:manifest')
   
   
 t['view'] = 'simple'


table.insert(t, {title = '(240p)' .. tolazy(total), mrl = url1})

end
end
 
 
 
 --https://movie.kinodostuptut.com/search?filters={"yearRange":[1979]}&q=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%2C
 
 elseif args.q == 'rapidcdn' then
  
  
   local x = conn:load('https://movie.kinodostuptut.com/search?filters={"yearRange":[' .. args.id2 .. ']}&q=' .. urlencode(args.id1))
 
  t['view'] = 'simple'

      
      for url, image, title, total in string.gmatch(x, '<a class="group relative block.-href="(.-)".-<img.-src="(.-)".-<span class="text%-sm.->(.-)</span>.-class="text%-xs.->(.-)</span>') do
      
    url = string.gsub(url, '^(.-)', 'https://movie.kinodostuptut.com')
    
    table.insert(t, {title = tolazy(title) .. ',' .. total, mrl = '#stream/q=rapidcdns&id=' .. url, image = image})

     end 
 
 

      elseif args.q == 'rapidcdns' then
    
   -- Хищник: Планета смерти | сезон 0 | эпизод 0 в хорошем качестве без регистрации, смс и vpn\
    
      local x = conn:load(args.id)

      for url, title in string.gmatch(x, '"m3u8MasterFilePath.-"(http.-)\\".-{.-"title.-":.-"Смотреть сериал (.-)в хорошем') do
     
     
     title = string.gsub(title, '| сезон 0 | эпизод 0', '')
     
     t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = url})

     end 
 
    elseif args.q == 'xkino' then
  
  
 -- https://s1.xkino.ne/play.php?kp=7418579&player=player&name=Идеальная афера&year=2025)
 
-- https://fast.xkino.net/Hischnik_planeta_smerti_2025.mp4" 
 -- <div>360p</div
  
-- https://fast.xkino.net/Hischnik_planeta_smerti_2025.hd.mp4" 
 -- <div>720p</div
 
 --https://ru.kinozona.net/play.php?player=player&kp=386&name=чужой&year=1979

--https://ru.kinozona.net/torLoad.php?id=Chuzhoy_1979

 
-- https://ru.kinozona.net/play.php?player=player&kp=386&name=чужой&year=1979&kadr=kadr-1607873096
 
 
-- https://s2.xkino.net/s1/serial.php?hesh=112823a6b050b374bede4b88f6895db7&n=&file=Chuzhoy_1979
 
 
 --https://s2.xkino.net/s1/serial.php?hesh=112823a6b050b374bede4b88f6895db7&n=&file=Istrebitel_gadov_2026/1/S1.1080.zip&server=s2&name=Istrebitel_gadov_2026 • 1 сезон • 1080
 
 
-- https://ru.kinozona.net/17317-na-pomosch-2026.html
 
 
-- https://s1.xkino.net/s2/mp4/112823a6b050b374bede4b88f6895db7/Na_pomosch_2026.mp4
 
-- https://s3.xkino.net/s2/mp4/112823a6b050b374bede4b88f6895db7/Na_pomosch_2026.mp4
 
-- https://s1.xkino.net/s2/17267-na-pomosch-2026.html
  
--  https://ru.kinozona.net/tor.php?id=17117
  
  --  https://ru.kinozona.net/vote.php?play_id=17117
    
 -- https://ru.kinozona.net/stars.php?name=alien
--  https://xkino.net/stars.php?name=alien
  
      local x = conn:load('https://ru.kinozona.net/stars.php?name=' .. urlencode(args.id4))
  
  t['view'] = 'simple'

      
      for url, image, title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<br.->(.-)</a>') do
 
      
  --   https://xkino.net/12806-zaslanec-iz-kosmosa-(4-sezon).html 
      
      
    url = string.gsub(url, '^(.-)', 'https://ru.kinozona.net/')

image = string.gsub(image, '/posters/mini/', '')

image = string.gsub(image, '^(.-)', 'https://img.xkino.net/')


  
   table.insert(t, {title = tolazy(title), mrl = '#stream/q=xkinos&id=' .. url})

     end 
  
  
  elseif args.q == 'xkinos' then
    
    
      local x = conn:load(args.id)
  
  
  local slist = string.match(x, 'new Playerjs.-file(.-)poster')

if slist then


for  total, url2, url3 in string.gmatch(slist, '%[(.-)](http.-/mp4/)(.-mp4)') do
  
t['view'] = 'simple'

    table.insert(t, {title = tolazy(total), mrl = url2 .. url3})

     end 
  end
  
  
  
    for url4, url5 in string.gmatch(x, 'Playerjs.-file:"(http.-txt?)(.-)"') do
  
     local x = conn:load(url4 .. url5)
  
  
for total3 in string.gmatch(x, '"title":"(.-)"') do
  
  local slist = string.match(x, 'file(.-)}')

    if slist then


for  total4, url6 in string.gmatch(slist, '%[(.-)](http.-mp4)') do
  
t['view'] = 'simple'
  
  table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url6})

     end 
  end
  end
  end
  
  
  
  
 -- http://seasonvar.ru/?mode=search&query
  
  
  elseif args.q == 'seasonvar' then
    
   

    
      local x = conn:load('http://seasonvar.ru/?mode=search&query=' .. urlencode(args.id1))
  
  
 -- local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
     --    url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'http:')
        
        t['view'] = 'simple'
		
			

  
  
  local x = conn:load('http://seasonvar.ru' .. url)
 
 
 local slist = string.match(x, '<ul class="tabs%-result">(.-)</ul>')
      
if slist then

   for url2, total in string.gmatch(slist, '<a href="(.-)".-Сериал (.-)<') do
   
  table.insert(t, {title = tolazy(total), mrl = '#stream/q=seasonvars&id=' .. url2, image = image})
		
		end
end
end



   
   elseif args.q == 'seasonvars' then
   
   local x = conn:load('http://seasonvar.ru' .. args.id)
        
        
        
        
        
      --  local x = conn:load(url2)
 
 for id1, total1 in string.gmatch(x,'"(/playls2.-)".-data%-translate%-percent=.->(.-)</li>') do
 
 
    --    for id1 in string.gmatch(x,'player = new Playerjs.-var pl.-"(/playls2.-)"') do
            
    local x = conn:load('http://seasonvar.ru' .. id1)
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id2 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id2 = string.gsub(id2, '\\/\\/b2xvbG8=', '') 
      
      id2=http.urldecode(base64_decode(id2))
       id2 = string.gsub(id2, '^(.-)', 'http:') 
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title1) .. ' ' .. total1, mrl = id2})
            end  
	end
  
 
  local x = conn:load('http://seasonvar.ru' .. args.id)
        
 
 local id2 = string.match(x,'var pl.-(/playls2.-)"')

            local x = conn:load('http://seasonvar.ru' .. id2)
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id3 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id3 = string.gsub(id3, '\\/\\/b2xvbG8=', '') 
      
      id3=http.urldecode(base64_decode(id3))
       id3 = string.gsub(id3, '^(.-)', 'http:') 
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title1), mrl = id3})
            end  
  
  
  
  
  
  
  
  
    elseif args.q == 'zetflix' then
    
   

    
      local x = conn:load('https://lampa.oksibutch.ru:443/lite/zetflix?kinopoisk_id=' .. args.id3)
   
   for url, total in string.gmatch(x, 'videos__item videos__movie.-title.-url.-(http.-)&.-videos__item%-title">(.-)<') do
  
  
     
      
      local x = conn:load(url)
   
   local slist = string.match(x, 'quality(.-)}')
   
   for  total1, url2 in string.gmatch(slist, '"(%d+p)":"(http.-)"') do
      
  --   url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')

--http://178.20.46.40:12600/lite/videodb/manifest.m3u8?
      
      
      
       t['view'] = 'simple'

--table.insert(t, {title = url2, mrl = url2})




    table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
        for url2, url3, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-zetflix)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = http.getz(url2 .. url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = http.getz(url4)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
      t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end



elseif args.q == 'getstv' then
    
   
   
 --https://lampa.oksibutch.ru:443  
   
--https://evkh.lol
--http://z01.online/lite/getstv?kinopoisk_id=386&title=Чужой&year=1979
    
      local x = conn:load('https://lampa.oksibutch.ru:443/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 -- table.insert(t, {title = 'https://lampa.oksibutch.ru:443/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://evkh.lol/lite/getstv?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})


     for  url1, total in string.gmatch(x, 'videos__item videos__movie.-method.-url.-(http.-)&.-videos__item%-title.->(.-)<') do
  
    
     url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

     local x = conn:load(url1)
   
 

 
     local slist = string.match(x, 'quality(.-)}')
      
if slist then

   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

    total1 = string.gsub(total1, ',"', '') 
    total1 = string.gsub(total1, '1080p":"/error.mp4"', '')
    
    
    
    
total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

      end 
    end

    end
     
     
     
     for url2, total1  in string.gmatch(x, 'videos__item videos__season.-method.-url.-(http.-)&.-videos__item%-title videos__season%-title.->(.-сезон)<') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&.->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'videos__item videos__movie selector.-method.-url.-stream.-(http.-)&.-videos__item%-title.->(.-серия)<') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end

    
    
elseif args.q == 'mirage1' then
    

   
local x = conn:load('https://evkh.lol/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do

url4 = string.gsub(url4, '\\u0026', '&')
url4 = string.gsub(url4, '\\u002B', '+')



      url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do


url5 = string.gsub(url5, '\\u0026', '&')
url5 = string.gsub(url5, '\\u002B', '+')

      url5 = string.gsub(url5, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
    

     
    elseif args.q == 'mirage' then
    
  
 -- https://vizhu.top
--  https://lampa.persh1n.ru
  
--  http://93.183.95.219:11378
 
-- http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=912590&stream=e8793ac5f12fe96596a7f3b2d9b59b&audio=0&box_mac=acace24b8434
 
-- https://lam.maxvol.pro/lite/mirage/video?id_file=911588\u0026token_movie=a6ef0986c7558c5792c3ad19d43611",
 
    
  --  https://lam.maxvol.pro/lite/mirage?kinopoisk_id=386&title=чужой&year=1979
 
-- http://78.40.199.67:10630
 
    
     local x = conn:load('https://mylam.ru/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



  -- x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

      t['view'] = 'simple'


    table.insert(t, {title = total, mrl = url})

 
    end
    
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')

url5 = string.gsub(url5, '\\u002B', '+') 
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
     
--http://online7.skaz.tv/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025

  --  http://z01.online/lite/cdnvideohub?kinopoisk_id=464475&title=франкенштейн&year=2025 
 
 
 --http://rc.bwa.ad/lite/events?
 
 local x = conn:load('http://z01.online/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



  -- x = string.gsub(x, '\\u0026', '&')


      for url, total in string.gmatch(x, '<div class="videos__item videos.-"method".-"stream":"(http.-)".-class="videos__item%-title.->(.-)</div>') do
   
   
        url = string.gsub(url, '\\u0026', '&')

url = string.gsub(url, '\\u002B', '+') 

      t['view'] = 'simple'


    table.insert(t, {title = '720p ' .. total, mrl = url})

 
    end
    
     
    for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')

url5 = string.gsub(url5, '\\u002B', '+') 
    t['view'] = 'simple'

table.insert(t, {title = '720p ' .. total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end
 
 
 

 
 
 elseif args.q == 'paladin' then
  
  
  
 local headers = {['User-Agent'] = 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 5_1_1 like Mac OS X; en) AppleWebKit/534.46.0 (KHTML, like Gecko) CriOS/19.0.1084.60 Mobile/9B206 Safari/7534.48.3'
 }
  
  
  
  
    
  --  https://lam2.akter-black.com/lite/paladin?kinopoisk_id=386&title=чужой&year=1979
    
  --  https://lam.maxvol.pro/lite/mirage?kinopoisk_id=386&title=чужой&year=1979
    
 -- https://lampa.oksibutch.ru/lite/mirage?kinopoisk_id=386&title=чужой&year=1979
    
  
--https://lampa.oksibutch.ru/lite/mirage/stream.m3u8?id=1231872&token_movie=22b440ccb9ff50149d6622c0542f1f&q=1080p
  
--https://lampa.oksibutch.ru/lite/mirage/video?id_file=1231872\u0026token_movie=22b440ccb9ff50149d6622c0542f1f
  
  local url = 'https://lampa.oksibutch.ru:443/lite/mirage?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2


local x = conn:load(url, headers)
   
   if x then
   
   for url1, total in string.gmatch(x, 'method.-url.-(http.-)&.-videos__item%-title.->(.-)<') do
  
--table.insert(t, {title = url1, mrl = url1})
   
        url1 = string.gsub(url1, '\\u0026', '&')



--http://onlinecf3.skaz.tv/lite/alloha/video?t=63&token_movie=a6ef0986c7558c5792c3ad19d43611
  
     local x = conn:load(url1, headers)


   local slist = string.match(x, 'quality(.-)}')
      
      
   if slist then
   for  total1, url2 in string.gmatch(slist, '"(%d+p)":"(http.-)"') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
 
      t['view'] = 'simple'

 
-- table.insert(t, {title = url2, mrl = url2})
 
  table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

      end 
    end
    end
    

    for url3, total in string.gmatch(x, 'videos__item videos__season.-method.-url.-(http.-)&.-videos__item%-title videos__season%-title.->(.-)<') do

url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')



       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, 'videos__button selector.-method.-url.-(http.-)&.->(.-)<') do


    url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')


     local x = conn:load(url4)
    
    x = string.gsub(x, '\\u0026', '&')
    

  
   for id, id1, total2 in string.gmatch(x, 'method.-stream.-url.-http.-id_file=(.-)&token_movie=(.-)".-videos__item%-title.->(.-)<') do
 
-- url5 = string.gsub(url5, '\\u0026', '&')
    
 --  url5 = string.gsub(url5, '\\u002B', '+')
 
   
  t['view'] = 'simple'



  table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1})
  
 -- table.insert(t, {title = total .. ' ' .. total2 .. ' ' .. total1, mrl = '#stream/q=paladins&id=' .. id .. '&id1=' .. id1  .. '&id2=' .. id2 .. '&id3=' .. id3})
  


end
end
end
end     
      
 elseif args.q == 'paladins' then
    
  --  url":"https://lampa.oksibutch.ru/lite/mirage/video?id_file=1216904\u0026token_movie=93ecb3b383a9f7d90a05257c78943f"
     
 --    local x = conn:load('https://lampa.oksibutch.ru/lite/mirage/video?t=' .. args.id .. '&s=' .. args.id1 .. '&e=' .. args.id2 .. '&token_movie='  .. args.id3)


local x = conn:load('https://lampa.oksibutch.ru/lite/mirage/video?id_file=' .. args.id .. '&token_movie='  .. args.id1)



      local slist = string.match(x, '"quality"(.-)}')
      
   if slist then
   for  total3, url6 in string.gmatch(slist, '"(%d+p)":"(http.-)"') do
      
 
 url6 = string.gsub(url6, '\\u0026', '&')
--    url6 = string.gsub(url6, '\\u002B', '+')
  

    t['view'] = 'simple'


table.insert(t, {title = '(' .. total3 .. ')', mrl = url6})

end
end

 
 
     
    elseif args.q == 'cdnvideohub' then
    
 
 
-- https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=386
 
-- local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3) 
 
 
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3, mrl = 'https://plapi.cdnvideohub.com/api/v1/player/sv/playlist?pub=923&aggr=kp&id=' .. args.id3})
 
-- "titleName":"Чужой","isSerial":false,"items"

--"vkId":"7554357484052","voiceStudio":"","voiceType":""}

-- "vkId":"11917742136012","voiceStudio":"Jaskier","voiceType":"Многоголосый"
 
-- for title in string.gmatch(x, '"titleName":"(.-)","isSerial":false') do
 
-- for id, total, total1 in string.gmatch(x, '"vkId":"(.-)","voiceStudio":"(.-)","voiceType":"(.-)"') do
 
-- table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = '#stream/q=cdnvideohubm&id=' .. id})
 
-- end
 --end
 
 
 

     
-- https://plapi.cdnvideohub.com/api/v1/player/sv/video/11917742136012
 
 --table.insert(t, {title = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id, mrl = 'https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. id})
 
-- end
-- end
 
 
 
  local x = conn:load('https://lam.maxvol.pro/lite/cdnvideohub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)





for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url = string.gsub(url, '\\u0026', '&')
   url = string.gsub(url, '\\u002B', '+')
  
  local x = conn:load(url)
  
  
  for  url1 in string.gmatch(x, '"method":"play","url":".-(/proxy.-)"') do
  
  url1 = string.gsub(url1, '\\u0026', '&')
  url1 = string.gsub(url1, '\\u002B', '+')
  
  
url1 = string.gsub(url1, '^(.-)', 'https://lam.maxvol.pro')


t['view'] = 'simple'

  table.insert(t, {title = total, mrl = url1})

end
end
  
  
  for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method".-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do

   url5 = string.gsub(url5, '\\u0026', '&')
    url5 = string.gsub(url5, '\\u002B', '+')
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end

elseif args.q == 'cdnvideohubm' then
 
 local x = conn:load('https://plapi.cdnvideohub.com/api/v1/player/sv/video/' .. args.id)
 
 local slist = string.match(x, '"sources"(.-)}')
    
    if slist then
    
     for total1, url2 in string.gmatch(slist, '"(.-Url)":"(http.-)"') do



  url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = string.gsub(url2, '\\u002B', '+')  
     
     url2 = string.gsub(url2, 'GECKO', 'CHROME_ANDROID')
     

     
      t['view'] = 'simple'

   table.insert(t, {title = url2, mrl = url2})
    end
    end
    
--  https://vd299.okcdn.ru/?expires=1768797038930&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=5&sig=oiqy4nM5q6Y&ct=0&urls=185.226.55.24&clientType=46&zs=41&id=10216803469855
   
 -- https://vd299.okcdn.ru/?expires=1768798368123&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=5&sig=blL2z7YgIDE&ct=0&urls=45.136.22.28&clientType=46&zs=41&id=10216803469855
   
   
    
  --https://vd299.okcdn.ru/?expires=1768798513604&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=2&sig=CKjpvCr3_h0&ct=0&urls=45.136.22.28&clientType=46&zs=41&id=10216803469855
 
 
 --http://vd299.okcdn.ru/?expires=1768797559897&srcIp=185.228.133.239&pr=90&srcAg=CHROME_ANDROID&ms=185.226.53.8&type=5&sig=k-en2-mOVts&ct=0&urls=45.136.22.28&clientType=46&zs=41&id=10216803469855
  
 -- http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=386&box_mac=acace24b8434
 
--https://cors.fx666.workers.dev:8443/https://blossom.stloadi.live/?kp=386&token=ec4ed80cd4de621b51b61b9e19f251
  
  --http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&stream=a6ef0986c7558c5792c3ad19d43611&audio=76&box_mac=acace24b8434
    
    
    
    
    
    
    
      elseif args.q == 'alloha' then
 
 local data = 'http://kb-team.club/msx/msxFork.php?plugin=' .. base64_encode('plugin&bid=alloha-aloha&act=view&id=' .. args.id3) .. '&device=acace24b8434'
 
 --http://kb-team.club/msx/msxFork.php?plugin=cGx1Z2luJmJpZD1hbGxvaGEtYWxvaGEmYWN0PXZpZXcmaWQ9Mzg2&device=acace24b8434
 
 
 
    local x = conn:load(data)

--table.insert(t,{title = data,mrl = data})
    
    if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 
 
    local x = string.match(x,'"label":".-Просмотр"(.-)]') 
    
    for total, url in string.gmatch(x, '{"label":"(.-)".-"action".-content.-(http.-)"') do
  
  url = string.gsub(url, '\\', '') 
     
  
       local x = conn:load(url)
   
  -- table.insert(t,{title= url,mrl = url})
    
    
   
   for total1, url1 in string.gmatch(x, '"playerLabel":"(.-)".-video.-(http.-)"') do
   
   url1 = string.gsub(url1, '\\', '') 
   url1 = urldecode(url1)
   
  
  t['view'] = 'simple'
  
     table.insert(t,{title= tolazy(total) .. ' ' .. '(' .. total1 .. 'p)',mrl = url1})
    
    end
    end
end
    

local x = conn:load(data)

--table.insert(t,{title = data,mrl = data})



for title, url2 in string.gmatch(x,'{"label":"\\u0421.-(%d+)",.-action".-content.-(http.-)"') do
      
      url2 = string.gsub(url2, '\\', '')
  
  
      
   local x = conn:load(url2)
  
   
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')

--Выберите Сезон и Серию

--local x = string.match(x,'Выберите Сезон и Серию(.-)]') 

for title1, url3 in string.gmatch(x,'label":"(.-)".-"action".-content.-http.-plugin=(.-)&') do

   
url3 = string.gsub(url3, '\\', '')

t['view'] = 'simple'

table.insert(t, {title = 'сезон ' .. title .. ' ' .. tolazy(title1), mrl = '#stream/q=allohaz&id=' .. url3})

   end
  end
   
       
  elseif args.q == 'allohaz' then
 
   
  local x = conn:load('http://kb-team.club/msx/msxFork.php?view&plugin=' .. args.id .. '&device=acace24b8434')
  
--local x = conn:load(url3)
  
  for title2, url4 in string.gmatch(x,'"playerLabel":".-(%d+)".-video.-(http.-)",') do
  url4 = string.gsub(url4, '\\', '')
        
   local x = conn:load(url4)

 
    for url5 in string.gmatch(x,'url.-(http.-)"') do 
   
url5 = string.gsub(url5, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = ' серия ' .. title2, mrl = url5})

      end 
      end
    
    
    
    
  elseif args.q == 'alloha1' then
 
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=' .. args.id3 .. '&box_mac=acace24b8434')

    
    
  
    --   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
  
 -- table.insert(t,{title= url2 .. '&box_mac=acace24b8434',mrl = url2 .. '&box_mac=acace24b8434'})
  
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
       
--		table.insert(t,{title= url3,mrl = url3})
		table.insert(t,{title= 'alloha : ' ..  tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, id1, id2, id3, id4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA.-&stream=(.-)&season=(.-)&translate=(.-)&ta=(.-)]]') do
  
  
  t['view'] = 'simple'
  
    
    table.insert(t,{title= tolazy(total) .. ' ' .. tolazy(total1),mrl = '#stream/q=allohas&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
    
    end
    end

    



    

local x = conn:load('https://evkh.lol/lite/vokino?kinopoisk_id=' .. args.id3 .. '&balancer=alloha')
    
 

     for url3, total in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

      local x = conn:load(url3)


      for url4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy.-)"') do


url4 = string.gsub(url4, '\\u002B', '+') 
     
      url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

   table.insert(t, {title = total, mrl = url4})


end
end



      for url3, total in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

       local x = conn:load(url3)


    for url4, total1 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)"}.->(.-)</div>') do

      local x = conn:load(url4)

     for url5, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"http.-(/proxy/.-)".-class="videos__item%-title">(.-)</div>') do

url5 = string.gsub(url5, '\\u002B', '+') 


      url5 = string.gsub(url5, '^(.-)', 'https://evkh.lol') 
    
    t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2 .. ' (' .. total1 .. ')', mrl = url5})

end
end
end




elseif args.q == 'allohas' then
    
    
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&stream=' .. args.id1 .. '&season=' .. args.id2 .. '&translate=' .. args.id3 .. '&ta=' .. args.id4 .. '&box_mac=acace24b8434')
  
  

  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
    t['view'] = 'simple'
				table.insert(t,{title= tolazy(total3) .. ' ' .. (total2),mrl = url5})
			end
          end
    
    



--http://78.40.199.67:10630/proxy/O3hSoc5CijVra2vCgfLNLB/PmRc+hqhKQgIOtzJlZSEN/U78WLhH33d7PTzmOoNEDwNxZZPw/cCL2DPw8vwZ+AtWC4MYaTNCqweYtblqcNLYD84RO+a9J2fQBoSstZ6c38UCxMq/hdkhO3eN06Bby6mor91qcMJXtoj7oQMvQb4LCGTqcuao/k4kE+O4e5YUbcSaRf6wbvMr+xw/pxPJLRjH3XBJVkyFY+94Tn8pggp22Td/Cka0vh7ih0qoejU+TjFZIFz8s/7BYVPvw5Tv8b+OOh3cAe7fQCrhzls/hqQ=.mp4
  
  
  
  
  
  
elseif args.q == 'cdnmovies' then
      
      local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?kinopoisk_id=' .. args.id3)


 local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630')
    
    

      local x = conn:load(url2)

     
      for id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-&kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=cdnmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})
  
  
  end
  end


 
     elseif args.q == 'cdnmoviess' then
 
 
     local x = conn:load('http://78.40.199.67:10630/lite/vdbmovies?' .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'http://78.40.199.67:10630') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end





--https://lamp-movie.ru
    
    elseif args.q == 'vdbmovies' then
      
      local x = conn:load('https://lam.maxvol.pro/lite/vdbmovies?kinopoisk_id=' .. args.id3)


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
    
    
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
if slist then
    
     for total1, url2, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-)<') do


  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')          url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' ' .. ( total2), mrl = url2})
    end
    end
   
    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
         
         url2 = string.gsub(url2, '\\u002B', '+')
 
url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    
    

      local x = conn:load(url2)

     
      for id4, id, id1, id2, id3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"(http.-)&.-kinopoisk_id=(.-)&.-&s=(.-)&sid=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=vdbmoviess&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4})
  
  
  end
  end


 
     elseif args.q == 'vdbmoviess' then
 
 
     local x = conn:load(args.id4 .. '&imdb_id=&kinopoisk_id=' .. args.id .. '&rjson=False&title=&original_title=&s=' .. args.id1 .. '&sid=' .. args.id2 .. '&t=' .. urlencode(args.id3))
 
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(1080p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end
    
if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(720p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(480p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end

if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(360p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end



if slist then
   
    for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"method":"play".-"quality".-"(240p)":"http.-(/proxy.-)".-class="videos__item%-title">(.-cерия)</div>') do
 
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = '(' .. total4 .. ') ' .. total3, mrl = url4})

    end   
    end


--https://lam.akter-black.com/lite/hdvb?imdb_id=tt29927663

--http://93.183.95.219:11378
--http://93.183.95.219:11378/proxy/de9ba7ff04c975beb30596bd47bb69d6.m3u8
    elseif args.q == 'hdvb' then
 
 
-- http://arkmv.ru:2053/lite/hdvb?kinopoisk_id=386
 
  --  http://arkmv.ru:2053/lite/hdvb/video?kinopoisk_id=386&title=&original_title=&iframe=https%3a%2f%2fvid1769248035.fotpro135alto.com%2fmovie%2fd3d32b0257555ee658f1f6da50d11588%2fiframe
    
      local x = conn:load('http://178.20.46.40:12600/lite/hdvb?kinopoisk_id=' .. args.id3)
      
      for  url, total2 in string.gmatch(x, '"method":"call".-"stream":".-(/lite.-)".-class="videos__item%-title">(.-)</div>') do
  
      url = string.gsub(url, '\\u0026', '&')
   url = string.gsub(url, '\\u002B', '+')


     -- local x = conn:load('http://178.20.46.40:12600' .. url)

   -- for  url2 in string.gmatch(x, '"play".-"url":"http.-(/)"') do
 
 
 
-- http://178.20.46.40:12600/lite/hdvb/video?kinopoisk_id=386&title=&original_title=&iframe=https%3a%2f%2fvid1733431681.entouaedon.com%2fmovie%2fd3d32b0257555ee658f1f6da50d11588%2fiframe
 
 
 --https://cdn-400.fotpro135alto.com/stream2/cdn-400/f9522e399333a8b96e6d76b6e57ddace/MJTMsp1RshGTygnMNRUR2N2MSlnWXZEdMNDZzQWe5MDZzMmdZJTO1R2RWVHZDljekhkSsl1VwYnWtx2cihVT290VStWWyYUbZpWVxoVbVpnT6lENOpWUx4ERRNzTEtWNPRlRtpFVrFTTEVUP:1768243115:185.228.133.239:7a925e945c08c1c081924669c581c8f04f15477797657d0e9b7057e51eebf17d:ru/1080/index.m3u8
    
    --url2 = string.gsub(url2, '/index.m3u8', '/360/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = tolazy(total2), mrl = 'http://178.20.46.40:12600' .. url})

end


--for  url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
  --  url2 = string.gsub(url2, '/index.m3u8', '/480/index.m3u8')
    
    --  t['view'] = 'simple'

  --  table.insert(t, {title = '480p ' .. tolazy(total2), mrl = url2})
--end


--for  url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
--    url2 = string.gsub(url2, '/index.m3u8', '/720/index.m3u8')
    
    --  t['view'] = 'simple'

  --  table.insert(t, {title = '720p ' .. tolazy(total2), mrl = url2})
--end

   -- for  url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
  --  url2 = string.gsub(url2, '/index.m3u8', '/1080/index.m3u8')
    
     -- t['view'] = 'simple'

 --   table.insert(t, {title = '1080p ' .. tolazy(total2), mrl = url2})

    --  end 
   
    --  end
      

      
 
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url2 = string.gsub(url2, '\\u0026', '&')
url2 = string.gsub(url2, '\\u002B', '+')


     local x = conn:load('http://178.20.46.40:12600' .. url2)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     
     local x = conn:load('http://178.20.46.40:12600' .. url4)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"http.-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do




     url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = 'http://178.20.46.40:12600' .. url6})
    end
end
end




--  http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?link=http://imboom.ru/?ma=cinemahall&mb=quality&mc=20
     local x = conn:load('http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=' .. urlencode(args.id1) .. '+' .. args.id2 .. '+')
  


     for url2 in string.gmatch(x, '<playlist_name>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn:load(url2)
    


    
    for total, url3, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA(.-)]>.-<playlist_url><!%[CDATA%[(http.-namee=).-(&perewod.-)]]></playlist_url>') do
	
	    local x = conn:load(url3 .. url4)
	   
	--   table.insert(t, {title = url3 .. url4, mrl = url3 .. url4})
	   
	     for total1, url5 in string.gmatch(x, '<channel.-<title>.-(1080)]]>.-<stream_url><!%[CDATA.-(http.-m3u8)') do

    url5 = string.gsub(url5, '\\', '')
   
    	t['view'] = 'simple'
    
url5 = string.gsub(url5, '^(.-)', 'http://5.180.45.229/hls/')	 




  --  table.insert(t, {title = url5, mrl = url5, image = image})
    	
     table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url5, image = image})
     end

for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(720)]]>.-<stream_url><!%[CDATA.-(http.-m3u8)') do

    url5 = string.gsub(url5, '\\', '')
url5 = string.gsub(url5, '^(.-)', 'http://5.180.45.229/hls/')	 
  
    	t['view'] = 'simple'
    	
     table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url5, image = image})
     end

for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(480)]]>.-<stream_url><!%[CDATA.-(http.-m3u8)') do

url5 = string.gsub(url5, '\\', '')
  
url5 = string.gsub(url5, '^(.-)', 'http://5.180.45.229/hls/')	 

    	t['view'] = 'simple'
    	
     table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url5, image = image})
     end


for total1, url5 in string.gmatch(x, '<channel.-<title><!%[CDATA.-(360)]]>.-<stream_url><!%[CDATA.-(http.-m3u8)') do

url5 = string.gsub(url5, '\\', '')
url5 = string.gsub(url5, '^(.-)', 'http://5.180.45.229/hls/')	 
  
  
  
    	t['view'] = 'simple'
    	
     table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url5, image = image})
     end

     end
	    end







--https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=570402


--https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=4910542

elseif args.q == 'hdvbf' then

    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	




      for title, url, id in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"(http.-)".-"translator_id":(.-),') do


 
      url = string.gsub(url, '\\', '')

--http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=https://vid1766135200.fotpro135alto.com/serial/56e881da922e06b2a74d84e242afcf65f05f4fe9f090bfa4e5a1a82d2b3e48d8/iframe&translate=Дубляж Ultradox&translator_id=218

--http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=https%3A%2F%2Fvid1768218223.fotpro135alto.com%2Fmovie%2Fbbaaa232db91957612c64c663b1405fd%2Fiframe&translator_id=89&play=1

--http://5.180.45.229/hls/https://b-401.fotpro135alto.com/stream2/b-401/54287b6c89142347d622ccdd32a6a01b/MJTMsp1RshGTygnMNRUR2N2MSlnWXZEdMNDZzQWe5MDZzMmdZJTO1R2RWVHZDljekhkSsl1VwYnWtx2cihVT2pFRShmWqVVNZRVV14keRVjWqVUePdUUz4UbSpWTykFNaRVVxkFVrpXTqFUP:1768275826:5.180.45.229:676452532fa833fe5ec09377902461eefedf113e75a71d0c900a4296cfabf695:cy/360/index.m3u8



url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. '&translator_id=' .. id
       --.. '&play=1'

    --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
--	end
       local x = conn:load(url)




         for url2 in string.gmatch(x, '"parser":"(http.-)"') do 
         
        url2 = string.gsub(url2, '\\', '')

      local x = conn:load(url2)

--table.insert(t, {title = url2, mrl = url2})

         for total, url3 in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
	url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	 

t['view'] = 'simple'
       table.insert(t, {title = total .. ' ' .. title, mrl = url3})

       end
       
         for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
   url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	 

   t['view'] = 'simple'
   
       table.insert(t, {title = total .. ' ' .. title, mrl = url3})

       end
        for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480/index', '720/index')

  url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')

t['view'] = 'simple'

       table.insert(t, {title = '720p' .. ' ' .. title, mrl = url3})

       end
       
      for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480/index', '1080/index')
     
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	 
     
     
 t['view'] = 'simple'
 
       table.insert(t, {title = '1080p' .. ' ' .. title, mrl = url3})

       end
       end
       end
     
     
     
     local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
     
     
     x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	


     
    
     
     
     for title, url, id in string.gmatch(x, '"translator":"(.-)".-"type":"serial".-"iframe_url":"(http.-)".-"translator_id":(.-),') do
     
     
     url = string.gsub(url, '\\', '')



url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. '&translate=' .. urldecode(title) .. '&translator_id=' .. id
     
     
     local x = conn:load(url)

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	


         for title1, title2, id1, id2, id3, id4, id5, id6, id7 in string.gmatch(x, '"information":"(.-)<br>(.-)".-"parser":"http.-?id=file&u=(.-)&v=(.-)&key=(.-)&.-&href=(.-)&ep=(.-)&season=(.-)&fid=(.-)"') do 
         
       -- url2 = string.gsub(url2, '\\', '')
title2 = string.gsub(title2, '<br>', ' ')
 
 t['view'] = 'simple'
 
 
     table.insert(t, {title = title1 .. ' ' .. title2, mrl = '#stream/q=hdvbs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. id6 .. '&id7=' .. id7 .. '&id8=' .. title1 .. '&id9=' .. title2})
     
     end
     end
     
     
     elseif args.q == 'hdvbs' then
     
     
      local x = conn:load('http://fxmlparsers.in.net/VilkaDB/?id=file&u=' .. args.id1 .. '&v=' .. args.id2 .. '&key=' ..args.id3 .. '&tid=&href=' .. args.id4 .. '&ep=' .. args.id5 .. '&season=' .. args.id6 .. '&fid=' .. args.id7)





         for total, url3 in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	 

t['view'] = 'simple'
       table.insert(t, {title = total .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})

       end
       
         for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')

url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	 

   t['view'] = 'simple'
   
       table.insert(t, {title = total .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})


       end
        for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480/index', '720/index')

t['view'] = 'simple'

url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	 

       table.insert(t, {title = '720p' .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})


       end
       
      for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480/index', '1080/index')
     
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	 
     
 t['view'] = 'simple'
 
       table.insert(t, {title = '1080p ' .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})


       end
       


--http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&content=aHR0cHM6Ly92aWQxNzU5NjU0ODA0LmZvdHBybzEzNWFsdG8uY29tL21vdmllLy9pZnJhbWU=&userdata=1&kp=386&box_mac=acace24b8434

elseif args.q == 'hdvb2' then

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=' .. args.id3 .. '&box_mac=acace24b8434')


   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end

--http://lam.maxvol.pro
--http://178.20.46.40:12600
 --   https://lampa.freepad.netcraze.club
    
        
    elseif args.q == 'turbo1' then
    

local headers = {["sec-fetch-dest"] = "iframe",["sec-fetch-mode"] = "navigate",
    ["sec-fetch-site"] = "cross-site",
    ["referer"] = "https://92d73433.obrut.show/"}

--https://92d73433.obrut.show/embed/MjM/content/1MDNwETM

local url = 'https://cors.nb557.workers.dev:8443/https://92d73433.obrut.show/embed/MjM/?kinopoisk_id=' .. args.id3



--local url = 'https://cors.nb557.workers.dev:8443/https://30bf3790.obrut.show/embed/AN/content/czN2YDO'


local x = conn:load(url)


local data = string.match(x, 'new.-Player.-(eyJsYW5.-\"+)')


    data = data:gsub('//[^=]+=', '') 
    -- remove '//ci9yL3I='-like parts
    local padding = 4 - (#data % 4)
    if padding < 4 then
        data = data .. string.rep('=', padding)
    end
   data = base64.decode(data)
 --  data = json.decode(data)

--  local decoded = base64.decode(data)
  --  local data_json = json.decode(decoded)


--local json = Encoding.UTF8.GetString(Base64.decode(base64))
 
-- table.insert(t, {title = base64, mrl = base64})
  
 --return data
--end



local x = conn:load(data)

data = string.gsub(data, '\\u0410', 'А')
      data = string.gsub(data, '\\u0430', 'а')
       
       data = string.gsub(data, '\\u0411', 'Б')
       data = string.gsub(data, '\\u0431', 'б')  
       data = string.gsub(data, '\\u0412', 'В')
      data = string.gsub(data, '\\u0432', 'в')
       data = string.gsub(data, '\\u0413', 'Г')
       data = string.gsub(data, '\\u0433', 'г')  
      data = string.gsub(data, '\\u0414', 'Д')
      data = string.gsub(data, '\\u0434', 'д')
       data = string.gsub(data, '\\u0415', 'Е')
       data = string.gsub(data, '\\u0435', 'е')  
      data = string.gsub(data, '\\u0401', 'Ё')
      data = string.gsub(data, '\\u0451', 'ё')
       data = string.gsub(data, '\\u0416', 'Ж')
       data = string.gsub(data, '\\u0436', 'ж')  
       data = string.gsub(data, '\\u0417', 'З')
      data = string.gsub(data, '\\u0437', 'з')
       data = string.gsub(data, '\\u0418', 'И')
       data = string.gsub(data, '\\u0438', 'и')  
       data = string.gsub(data, '\\u0419', 'Й')
      data = string.gsub(data, '\\u0439', 'й')
       data = string.gsub(data, '\\u041a', 'К')
       data = string.gsub(data, '\\u043a', 'к')  
       data = string.gsub(data, '\\u041b', 'Л')
       data = string.gsub(data, '\\u043b', 'л')
       data = string.gsub(data, '\\u041c', 'М')
       data = string.gsub(data, '\\u043c', 'м')
       data = string.gsub(data, '\\u041d', 'Н')
       data = string.gsub(data, '\\u043d', 'н')
       data = string.gsub(data, '\\u041e', 'О')
       data = string.gsub(data, '\\u043e', 'о')
       data = string.gsub(data, '\\u041f', 'П')
       data = string.gsub(data, '\\u043f', 'п')
       data = string.gsub(data, '\\u0420', 'Р')
       data = string.gsub(data, '\\u0440', 'р')
       data = string.gsub(data, '\\u0421', 'С')
       data = string.gsub(data, '\\u0441', 'с')
       data = string.gsub(data, '\\u0422', 'Т')
       data = string.gsub(data, '\\u0442', 'т')
       data = string.gsub(data, '\\u0423', 'У')
       data = string.gsub(data, '\\u0443', 'у')
       data = string.gsub(data, '\\u0424', 'Ф')
        data = string.gsub(data, '\\u0444', 'ф')
        data = string.gsub(data, '\\u0425', 'Х')
        data = string.gsub(data, '\\u0445', 'х')
        data = string.gsub(data, '\\u0426', 'Ц')
        data = string.gsub(data, '\\u0446', 'ц')
        data = string.gsub(data, '\\u0427', 'Ч')
        data = string.gsub(data, '\\u0447', 'ч')
        data = string.gsub(data, '\\u0428', 'Ш')
        data = string.gsub(data, '\\u0448', 'ш')
        data = string.gsub(data, '\\u0429', 'Щ')
        data = string.gsub(data, '\\u0449', 'щ')
        data = string.gsub(data, '\\u042a', 'Ъ')
        data = string.gsub(data, '\\u044a', 'ъ')
        data = string.gsub(data, '\\u042b', 'Ы')
        data = string.gsub(data, '\\u044b', 'ы')
        data = string.gsub(data, '\\u042c', 'Ь')
        data = string.gsub(data, '\\u044c', 'ь')
        data = string.gsub(data, '\\u042d', 'Э')
        data = string.gsub(data, '\\u044d', 'э')
        data = string.gsub(data, '\\u042e', 'Ю')
        data = string.gsub(data, '\\u044e', 'ю')
        data = string.gsub(data, '\\u042f', 'Я')
        data = string.gsub(data, '\\u044f', 'я')
        data = string.gsub(data, '\\u00ab', '<<')
        data = string.gsub(data, '\\u00bb', '>>')
        data = string.gsub(data, '\\u2014', '-')
	
 
 data = string.gsub(data, '\\', '')

--local x = conn:load(data)



    
     
     for title, title1, args in string.gmatch(data, '{"title":"(.-)".-%[(1080p)](http.-),') do
     

       local link = 'https://lampa.oksibutch.ru/lite/zetflix/manifest.m3u8?link=' .. http.urlencode(args)
       
-- local link = 'https://lam.maxvol.pro/lite/videodb/manifest.m3u8?link=' .. HttpUtility.UrlEncode(args) .. args
 
--url = url_for(x)
 
 
 table.insert(t, {title = link})
 end
--end
-- end
-- end
 
 
 
 
 
 --  for title, title1, url1 in string.gmatch(data, '{"title":"(.-)".-%[(1080p)](http.-),') do
 
 --url1 = string.gsub(url1, '\\', '')
   
 --  link=http.urlencode(url1)
   
   

   
   
   
 --  local x = conn:load('https://cors.nb557.workers.dev:8443/' .. url1,headers1,params)
 
-- url = url_for('GET', {file = x})
 
 
   
  -- for url2 in string.gmatch(x, '(http.-m3u8)') do
   
    
--http://lam.maxvol.pro/lite/videodb/manifest.m3u8?link=https://cdn-30bf3790.obrut.show/stream/AN/MHc0RHa/QbvNmLuR2YyVGc1RmclBXdz5ie/gTdz0mLzxGavMTM1AjMwYjMwIjO5IzNxMTYjVGOmNDOmRzY4ITMkZGZiVjYhFWO3MmYwU2L4MjNzcDOkBzMjhTZkdTMkZWZ2ATZkNDO5AzM0IzNkR2N2YjZhJGMy8ycllmdv12L
  

  
    
 --  table.insert(t, {title = 'http://lam.maxvol.pro/lite/videodb/manifest.m3u8?link=' .. link, mrl = 'http://lam.maxvol.pro/lite/videodb/manifest.m3u8?link=' .. link})
    
 --  end
  --  end
    
elseif args.q == 'turbo' then

--https://cors.nb557.workers.dev:8443/

local url = 'https://cors.nb557.workers.dev:8443/https://30bf3790.obrut.show/embed/AN?kinopoisk_id=' .. args.id3


--["Cookie"] = "wd_trust=AAAAAGnHzUNFODg4REY5QwEzAn__RdMViw",
--["X-Requested-With"] = "XMLHttpRequest",
 

--local r = {}
 
 local headers = {["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
["Accept-Language"] = "en-US,en;q=0.5",
["Accept-Encoding"] = "gzip, deflate, br",
["DNT"] = "1",
["Connection"] = "keep-alive",
["Referer"] = "https://gokino.su/",
["Upgrade-Insecure-Requests"] = "1",
["Sec-Fetch-Dest"] = "iframe",
["Sec-Fetch-Mode"] = "navigate",
["Sec-Fetch-Site"] = "cross-site",
["Pragma"] = "no-cache",
["Cache-Control"] = "no-cache"}

local headerss = {
  ["cache-control"] = "no-cache, private",
  ["content-encoding"] = "gzip",
  ["content-type"] = "text/html; charset=UTF-8",
  ["date"] = "Sat, 28 Mar 2026 12:46:13 GMT",
  ["server"] = "wd",
  ["set-cookie"] = {
    "wd_trust=; Path=/; Expires=Thu, 01-Jan-70 00:00:00 GMT; Domain=.obrut.show; Priority=High; HttpOnly; Secure; SameSite=None",
    "wd_trust=AAAAAGnHzUNFODg4REY5QwEzAn__RdMViw; Path=/; Expires=Sun, 28 Mar 2027 12:44:51 GMT; Domain=.obrut.show; Priority=High; HttpOnly; Secure; SameSite=None; Partitioned"
  },
  ["XSRF-TOKEN"] = "eyJpdiI6ImJOem1TbFBSMnhSYUlZTTN0a21OUXc9PSIsInZhbHVlIjoiVFFocEtWdUszY3I2Qi9UYU14UHp6b0lXVWsxclQyei9idzRrVE1xOGxuRjAya1NOQ1luUkgrWElNUXFuazNYRzRsS0Jnd3Rpb3JMZEQ1aERsUzFqb0Y4QmRyaTNhQUFhRksrQVl4ZEdTZm9KcG9JWXg1QU00NlExSGZSZmNMY0UiLCJtYWMiOiI1ZDE5ODJkNTFhOGQwYzI3YTVjOGMzNDAyMzQ0ZGIzMzFmOTdlZWNhYjExM2Y3MTNmNmZhZDFlZWM0OGY5YTNhIiwidGFnIjoiIn0=",
  ["turbo_player_session"] = "eyJpdiI6IkhLSXRUbzlFUnVnL1R1Qnp3cXhjQ0E9PSIsInZhbHVlIjoicFA2RUt4cW9UVC9BREVEa0NxQVp0NGs3UzN1VmkrZHZZRzBxYVhiZFhIZXQ1OXpwYjQ3d2NqNkZmTVFXVU5BTVJ2MDZSdE9xUHF6V2IrWXFUOGgxVlc0c2N6MzNySWxxczExQWhISmdJeVViNTNXL3p2dk5Cc2NvSlFHd09ORDQiLCJtYWMiOiJhOGFiYjBkNDBmYTVjMzVkYTkwMzFjZjVlZThhMjEzN2U3ZjE1N2Y3MzkyMjhmODUxOTM4OTVlZjcwMGI2Y2Q2IiwidGFnIjoiIn0=",
  ["strict-transport-security"] = "max-age=31536000",
  ["vary"] = "Origin",
  ["wd-rid"] = "wd-3c1a.6c363c3f"
}

local x = http.get(url, headers)




--url = url_for(x)

--url = urldecode(url)


x = string.gsub(x, '//ci9yL3I=', '')
 
x = string.gsub(x, '//by9vL28=', '')
 
x = string.gsub(x, '//dC90L3Q=', '')
 
x = string.gsub(x, '//Yi9iL2I=', '')

x = string.gsub(x, '//dS91L3U=', '')
	
					


local slist = string.match(x, 'new.-Player.-(eyJsYW5.-\"+)')
 
 
 if slist then
 
 slist = base64_decode(slist)
 
slist = string.gsub(slist, '\\u0410', 'А')
      slist = string.gsub(slist, '\\u0430', 'а')
      slist = string.gsub(slist, '\\u0411', 'Б')
       slist = string.gsub(slist, '\\u0431', 'б')
       slist = string.gsub(slist, '\\u0412', 'В')
      slist = string.gsub(slist, '\\u0432', 'в')
       slist = string.gsub(slist, '\\u0413', 'Г')
       slist = string.gsub(slist, '\\u0433', 'г')      slist = string.gsub(slist, '\\u0414', 'Д')
      slist = string.gsub(slist, '\\u0434', 'д')
       slist = string.gsub(slist, '\\u0415', 'Е')
       slist = string.gsub(slist, '\\u0435', 'е')      slist = string.gsub(slist, '\\u0401', 'Ё')
      slist = string.gsub(slist, '\\u0451', 'ё')
       slist = string.gsub(slist, '\\u0416', 'Ж')
       slist = string.gsub(slist, '\\u0436', 'ж')
       slist = string.gsub(slist, '\\u0417', 'З')
      slist = string.gsub(slist, '\\u0437', 'з')
       slist = string.gsub(slist, '\\u0418', 'И')
       slist = string.gsub(slist, '\\u0438', 'и')     slist = string.gsub(slist, '\\u0419', 'Й')
      slist = string.gsub(slist, '\\u0439', 'й')
       slist = string.gsub(slist, '\\u041a', 'К')
       slist = string.gsub(slist, '\\u043a', 'к')
       slist = string.gsub(slist, '\\u041b', 'Л')
       slist = string.gsub(slist, '\\u043b', 'л')
       slist = string.gsub(slist, '\\u041c', 'М')
       slist = string.gsub(slist, '\\u043c', 'м')
       slist = string.gsub(slist, '\\u041d', 'Н')
       slist = string.gsub(slist, '\\u043d', 'н')
       slist = string.gsub(slist, '\\u041e', 'О')
       slist = string.gsub(slist, '\\u043e', 'о')
       slist = string.gsub(slist, '\\u041f', 'П')
       slist = string.gsub(slist, '\\u043f', 'п')
    slist = string.gsub(slist, '\\u0420', 'Р')
    slist = string.gsub(slist, '\\u0440', 'р')
    slist = string.gsub(slist, '\\u0421', 'С')
    slist = string.gsub(slist, '\\u0441', 'с')
    slist = string.gsub(slist, '\\u0422', 'Т')
    slist = string.gsub(slist, '\\u0442', 'т')
    slist = string.gsub(slist, '\\u0423', 'У')
    slist = string.gsub(slist, '\\u0443', 'у')
    slist = string.gsub(slist, '\\u0424', 'Ф')
    slist = string.gsub(slist, '\\u0444', 'ф')
    slist = string.gsub(slist, '\\u0425', 'Х')
    slist = string.gsub(slist, '\\u0445', 'х')
    slist = string.gsub(slist, '\\u0426', 'Ц')
    slist = string.gsub(slist, '\\u0446', 'ц')
    slist = string.gsub(slist, '\\u0427', 'Ч')
    slist = string.gsub(slist, '\\u0447', 'ч')
    slist = string.gsub(slist, '\\u0428', 'Ш')
    slist = string.gsub(slist, '\\u0448', 'ш')
    slist = string.gsub(slist, '\\u0429', 'Щ')
    slist = string.gsub(slist, '\\u0449', 'щ')
    slist = string.gsub(slist, '\\u042a', 'Ъ')
    slist = string.gsub(slist, '\\u044a', 'ъ')
    slist = string.gsub(slist, '\\u042b', 'Ы')
    slist = string.gsub(slist, '\\u044b', 'ы')
    slist = string.gsub(slist, '\\u042c', 'Ь')
    slist = string.gsub(slist, '\\u044c', 'ь')
    slist = string.gsub(slist, '\\u042d', 'Э')
    slist = string.gsub(slist, '\\u044d', 'э')
    slist = string.gsub(slist, '\\u042e', 'Ю')
    slist = string.gsub(slist, '\\u044e', 'ю')
    slist = string.gsub(slist, '\\u042f', 'Я')
    slist = string.gsub(slist, '\\u044f', 'я')
    slist = string.gsub(slist, '\\u00ab', '<<')
    slist = string.gsub(slist, '\\u00bb', '>>')
    slist = string.gsub(slist, '\\u2014', '-')
 
 
 
 
 
 for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(240p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

title = string.gsub(title, '","folder":%[{"title":"', '')


 t['view'] = 'simple'
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = 'https://lampa.oksibutch.ru/lite/videodb/manifest.m3u8?link=' .. urlencode(url1)})
 
 end
 
for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(360p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')
title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')
title = string.gsub(title, '","folder":%[{"title":"', '')

 t['view'] = 'simple'
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = 'https://lampa.oksibutch.ru/lite/videodb/manifest.m3u8?link=' .. urlencode(url1)})
 
 end
 
for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(480p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

title = string.gsub(title, '","folder":%[{"title":"', '')

 t['view'] = 'simple'
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = 'https://lampa.oksibutch.ru/lite/videodb/manifest.m3u8?link=' .. urlencode(url1)})
 
 end
 
for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(720p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')

title = string.gsub(title, '","folder":%[{"title":"', '')


 t['view'] = 'simple'
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = 'https://lampa.oksibutch.ru/lite/videodb/manifest.m3u8?link=' .. urlencode(url1)})
 
 end
 
 
 for title, title1, total, url1 in string.gmatch(slist, '{"title":"(.-)","t1":"(.-)%-.-%[(1080p)](http.-),') do
 
 url1 = string.gsub(url1, '\\', '')

title1 = string.gsub(title1, '","poster":"https:\\/\\/cdn', '')
title = string.gsub(title, '","folder":%[{"title":"', '')

 t['view'] = 'simple'
 
 table.insert(t, {title = total .. ' ' .. tolazy(title1) .. ' ' .. tolazy(title), mrl = 'https://lampa.oksibutch.ru/lite/videodb/manifest.m3u8?link=' .. urlencode(url1)})

       end
    end


    
    elseif args.q == 'videodb' then
  
  
--http://93.183.95.219:11378/lite/videodb/manifest.m3u8?link=https%3a%2f%2fcdn-30bf3790.obrut.show%2fstream%2fAN%2fMHc0RHa%2fQbvNmLuR2YyVGc1RmclBXdz5ie%2fgTdz0mLzxGavkDMxMTMwYjMwIjOlVGN4AjMjRzM2MGMldTNwIGNjJTYxYDMjdzMwMWYyQ2LxIWMhFTM0ITNxkTMzMTNjdjZyETY3QmZyU2Y3E2MzYzMycDN0ITZi9ycllmdv12L&uid=ar2tfo88&nws_id=hprbcesnelxj0nj3xayznmaowet1ym6l
 
   
-- https://cdn-30bf3790.obrut.show/stream/AN/MHc0RHa/QbvNmLuR2YyVGc1RmclBXdz5ie/AO1NTbuQ3clZWauFWb6MHbopDNw1mLwgDMx8SOwEzMxAjNyAjM6gTY0cTMzAzMzQjZ3EzMhhTZxU2N5UGMhdDNjNjYjNGZvUGZ5MmM5QGOmJWYhRTYiBDO3ETYkVjZjJWN5MTMwUTMwMTM5QmMlVzLzVWayV2c2R3L
 
-- http://93.183.95.219:11378/lite/videodb/manifest.m3u8?link=https%3a%2f%2fcdn-30bf3790.obrut.show%2fstream%2fAN%2fMHc0RHa%2fQbvNmLuR2YyVGc1RmclBXdz5ie%2fgTdz0mLzxGavMTM0ITMwYjMwIjOlNmMkNDMhFWMlRWNhVDO5MzMyQzYxgDN3ImMjZ2M4I2LxIWMhFTM0ITNxkTMzMTNjdjZyETY3QmZyU2Y3E2MzYzMycDN0ITZi9ycllmdv12L&uid=ar2tfo88&nws_id=hprbcesnelxj0nj3xayznmaowet1ym6l
 
-- http://93.183.95.219:11378/lite/videodb/manifest.m3u8?link=https%3a%2f%2fcdn-30bf3790.obrut.show%2fstream%2fAN%2fMHc0RHa%2fQbvNmLuR2YyVGc1RmclBXdz5ie%2fgTdz0mLzxGavMTM0ITMwYjMwIjOxcTY0cDOzMmMxMjY3Y2NilzY1AjZzQTYhJWNkRGMiZ2L0MmNzU2N2EWZkZGZ3UDOwEDM5QWYzgDMmhjMjNTY1YWNkVjZhFzMx8ycllmdv12L&uid=ar2tfo88&nws_id=hprbcesnelxj0nj3xayznmaowet1ym6l
 
 
    local x = conn:load('https://lam.maxvol.pro/lite/videodb?kinopoisk_id=' .. args.id3)
   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(http.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
   --  url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
    -- url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

    --  url3 = string.gsub(url3, '^(.-)', 'http://lam.maxvol.pro') 
       local x = http.getz(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(http.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
   -- url4 = string.gsub(url4, '^(.-)', 'http://lam.maxvol.pro')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end



--http://api.vokino.pro/v2/search?name=чужой&year=1979

elseif args.q == 'vcdn' then

local x = conn:load('http://api.vokino.pro/v2/search?name=' .. urlencode(args.id1) .. '&year=' .. args.id2) 

local id = string.match(x, '"channels".-"details".-"id":"(.-)"') 


--http://api.vokino.pro/v2/online/videocdn/6593f8688914c04deae97e7c?token=windows_68988745062e9987f8b5b8502917b37d_1264491

local x = conn:load('http://api.vokino.pro/v2/online/videocdn/' .. id .. '?token=windows_68988745062e9987f8b5b8502917b37d_1264491')


for total, url in string.gmatch(x, '"title":"(.-)".-"stream_url":"(.-)"') do
  
      t['view'] = 'simple'
 
 
    table.insert(t, {title = total, mrl = url})
 
     end
     
   elseif args.q == 'videocdn' then
 
 


 --https://cors.fx666.workers.dev:8443/http://kb-team.club/msx/kinozal/videocdn.php?act=watch&vid=386&device=acace24b8434
 
 
 
 local x = conn:load('http://kb-team.club/msx/kinozal/videocdn.php?act=watch&vid=' .. args.id3 .. '&device=acace24b8434') 


if x then
 
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 
 

 
 for title, url1 in string.gmatch(x,'"playerLabel":"(.-)".-video.-(http.-)"') do



url1 = string.gsub(url1, '\\', '')

 t['view'] = 'simple'

   table.insert(t, {title = title, mrl = url1})

      end 
 
      
      
     for url2 in string.gmatch(x,'"label".-"action":"panel.-(http.-)"') do
      
      url2 = string.gsub(url2, '\\', '')
  
  
      
   local x = conn:load(url2)
  
   
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')


for title1, url3 in string.gmatch(x,'"playerLabel":"(.-)".-"action":"player:show".-"action.-video.-(http.-)"') do


   
url3 = string.gsub(url3, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = tolazy(title1), mrl = url3})

      end 
  
  
  for title2, url3 in string.gmatch(x,'"label":".-uddfa(.-)".-"action":"panel:(http.-)"') do
  url3 = string.gsub(url3, '\\', '')
        
   local x = conn:load(url3)
  
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
  
  
--  table.insert(t, {title = url, mrl = url})
  
 
    for title3, url4 in string.gmatch(x,'"playerLabel":"(.-)".-"action":"player:show".-video.-(http.-)"') do 
   
url4 = string.gsub(url4, '\\', '')
   
   t['view'] = 'simple'

   table.insert(t, {title = title2 .. ' ' .. tolazy(title3), mrl = url4})

      end 
      end
   end
     
 end
 
 
 

 
-- https://lampa.ip917.ru/lite/lumex/video.m3u8?playlist=%2fvalidate%2fU2FsdGVkX1-HWJXR-68d4L5FZ5G8XZbankXomi3bA2NSRN28LPBPtpORtthxOnUsx0Lg3KqSB6Kfg3EJql4hhh7YMO-Pp2SLx9TnO-tBp5myBFbjXKKEuKfrYZ2wVwdb45iSZaB5Cok7fK_Cb4QprlmNkOfV5hLruFWpJtTVIuGIf3Dk65SDRFcyJOHKPXleu07ieysuHAkAZEDcjDZUECF4FIdxBkqkYwP6CPUt4x8&csrf=636ebee3ad5caa58ecd60717b4c38dc7&max_quality=1080&uid=2hlekqiu   
--https://lamp-movie.ru
--http://lam.maxvol.pro
--http://89.110.96.198:12267/lite/lumex?kinopoisk_id=386
    
 --   http://z01.online/lite/vdbmovies?kinopoisk_id=386
    
 --   http://z01.online/lite/lumex?kinopoisk_id=386
 
 --http://z01.online/lite/videocdn?kinopoisk_id=4910542
    
--   local x = conn:load('http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3) 

   local x = conn:load('https://p01--lampac--9dxms589q2gt.code.run/lite/lumex?kinopoisk_id=' .. args.id3) 
   
   --.. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

 --  table.insert(t, {title = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3, mrl = 'http://z01.online/lite/videocdn?kinopoisk_id=' .. args.id3})


     for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"method":.-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
    
      url1 = string.gsub(url1, '\\u0026', '&')
--    url1 = string.gsub(url1, '^(.-)', 'http://lampa.vip')

  --   local x = conn:load(url1)
   
 

 
 --    local slist = string.match(x, 'quality(.-)}')
      
--if slist then

--   for  total1, url2 in string.gmatch(slist, '"(.-p)":"(http.-)"') do

  --  total1 = string.gsub(total1, ',"', '') 
--total1 = string.gsub(total1, ':{"', '')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url1})

      end 
--    end

  --  end
     
     
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do



         url2 = string.gsub(url2, '\\u0026', '&')
 
       --    url2 = string.gsub(url2, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(http.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
     --  url3 = string.gsub(url3, '^(.-)', 'http://lampa.vip') .. '&uid=guest'
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
   -- url4 = string.gsub(url4, '^(.-)', 'http://lampa.vip')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end


   
   
    elseif args.q == 'lumex' then
    
  --  http://lam.maxvol.pro
 --   http://178.20.46.40:12600

--http://lam.maxvol.pro/lite/lumex?kinopoisk_id=4910542

   local x = conn:load('https://p01--lampac--9dxms589q2gt.code.run/lite/lumex?kinopoisk_id=' .. args.id3)
   -- https://lam.akter-black.com
    
   --  local x = conn:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
 
 
-- http://fxmlparsers.in.net/VilkaDB/?id=vcdnep&vcdn_src=https://p.lumex.space/tUBmWYz7hh91/movie/87677
 
 --http://fxmlparsers.in.net/VilkaDB/?id=vcdnep&vcdn_src=https://p.lumex.space/tUBmWYz7hh91/movie/86142&translation_id=1369&varip=45.155.7.202&h=https://p.lumex.space
 
 
 
 --http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-Z3OGSNB_6LRXjDs8ksXnF60ID6sI-tsm3cQWS5QYihme3wQGUKtMNuZF2q-YVs0IyrDU2Hw2_NgmnUTPP1cwqm0LDBOZOyhcrVTdzyTL-Y49r8878YOFCqRox4uywhd1kjYFN4OUIY3e-K18tVWDLXIudWbcs3Qg2dEZ2Erpa5p81Mwe7NN09IcwocAKDUaTRxEsqoWOYjQ&varip=45.155.7.202&h=https://p.lumex.space

--http://45.155.7.202/hls/5850fd02cc56f5027cc0b69600f11f968a832831/http://mpa.education1ne.in.net/movies/2e6caf63dc352062c9306750386e5bd447d768ce/7bd886e1e75c421b281dafe98c333a74:2026021321/1080.mp4:hls:manifest.m3u8

 --http://mpa.education1ne.in.net/movies/77a3f30013f65273cdb368c0ec8d494fd1ca383b/523ef288098852d6d114c7c745bb2128:2026022205/1080.mp4:hls:manifest.m3u8
 
 
-- http://fxmlparsers.in.net/VilkaDB/?id=vcdnep&vcdn_src=https://p.lumex.space/tUBmWYz7hh91/movie/87677&varip=45.155.7.202&h=https://p.lumex.space
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
--  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
  
  
  
  
       t['view'] = 'simple'

 --  table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p) ' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  
 
      url3 = string.gsub(url3, '\\', '')
  
     url3 = string.gsub(url3, '360/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
      
url3 = string.gsub(url3, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p) '.. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '480.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p) ' .. tolazy(total), mrl = url3})
       
    end
    
   local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '360/index')
      url3 = string.gsub(url3, '360.mp4', '360.mp4')
      
     url3 = string.gsub(url3, 'hls.m3u8', '360.mp4:hls:manifest.m3u8') 
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(360p) ' .. tolazy(total), mrl = url3})
       
    end 
    
local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '240/index')
      url3 = string.gsub(url3, '360.mp4', '240.mp4')
      
      url3 = string.gsub(url3, 'hls.m3u8', '240.mp4:hls:manifest.m3u8')
      
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(240p) ' .. tolazy(total), mrl = url3})
       
    end
    
    
    
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
       --   url2 = string.gsub(url2, '^(.-)', 'http://lam.maxvol.pro')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = total1 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end
  end
  
  

 elseif args.q == 'lumexs' then
    
     local x = conn:load('https://lam.maxvol.pro/lite/lumex?content_id=' .. args.id1 .. '&kinopoisk_id=' .. args.id2 .. '&clarification=' .. args.id3 .. '&s=' .. args.id4 .. '&t=' .. args.id5)



for id1, id2, id3, id4, id5, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-http.-content_id=(.-)&.-&kinopoisk_id=(.-)&.-&clarification=(.-)&s=(.-)&t=(.-)".->(.-)</div>') do
         
  t['view'] = 'simple'
  
  table.insert(t, {title = 'Сезон ' .. args.id4 .. ' ' .. total2, mrl = '#stream/q=lumexs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 ..'&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. total2})
  
  end






      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
 
 
 
 local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '1080/index')
      url5 = string.gsub(url5, '360.mp4', '1080.mp4')
      
     url5 = string.gsub(url5, 'hls.m3u8', '1080.mp4:hls:manifest.m3u8') 
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(1080p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
 

     local x = conn:load(url4)
  
  for url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '720.mp4:hls:manifest.m3u8')
  
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(720p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
   
   local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"(http.-)"') do
  

  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '480/index')
      url5 = string.gsub(url5, '360.mp4', '480.mp4')
      
      url5 = string.gsub(url5, 'hls.m3u8', '480.mp4:hls:manifest.m3u8')
      
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = '(480p) ' .. args.id4 .. ' сезон' .. ' ' .. total3 .. ' ' .. args.id6, mrl = url5})

       
    end
  
end

   
   
--   http://z01.online/lite/filmix?title=чужой&year=1979
    
--https://vizhu.top/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
 -- https://lamp-movie.ru/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
  
  
--http://z01.online/lite/filmix?postid=173202
      
     elseif args.q == 'filmix' then

--https://api.filmix.tv/api-fx/list?search=горничная+2025

local x = conn:load('https://api.filmix.tv/api-fx/list?search=' .. urlencode(args.id1) .. '+' .. args.id2)

x = string.gsub(x, '\\', '')




for title, year, image, id in string.gmatch(x,'"id":.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)".-url":"https://.-/.-/.-/(.-)%-') do

t['view'] = 'simple'


table.insert(t, {title = title .. ' ' .. year, mrl = '#stream/q=filmixapi&id=' .. id,image = image})

end

elseif args.q == 'filmixapi' then

--local x = conn:load('http://178.20.46.40:12600/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2)

--for id in string.gmatch(x,'<div class="videos__line".-"method":"link".-"url":"http.-postid=(.-)\\u0026') do


local x = conn:load('https://api.filmix.tv/api-fx/post/' .. args.id .. '/video-links')

--table.insert(t, {title = 'https://api.filmix.tv/api-fx/post/' .. args.id .. '/video-links', mrl = '#stream/q=filmixapi&id=' .. 'https://api.filmix.tv/api-fx/post/' .. args.id .. '/video-links',image = image})

x = string.gsub(x, '\\', '')

--x = string.gsub(x, '"http.-.mp4"', '')


local video = string.match(x, '{"season":null(.-)"video"}]')



if video then

local video1 = string.match(video, '"files":%[(.-)"updated"') do

if video1 then

for url, url1, total in string.gmatch(video1,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video1,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
end
end


local video2 = string.match(video, '"files".-"files":%[(.-)"updated"') do

if video2 then


for url, url1, total in string.gmatch(video2,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video2,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end
 
 
local video3 = string.match(video, '"files".-"files".-"files":%[(.-)"updated"') do


if video3 then

for url, url1, total in string.gmatch(video3,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video3,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end
 
 local video4 = string.match(video, '"files".-"files".-"files".-"files":%[(.-)"updated"') do

if video4 then

for url, url1, total in string.gmatch(video4,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video4,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end
 
local video5 = string.match(video, '"files".-"files".-"files".-"files".-"files":%[(.-)"updated"') do

if video5 then

for url, url1, total in string.gmatch(video5,'url.-(http.-)(?hash=.-)".-quality.-:(.-),') do

for title in string.gmatch(video5,'"voiceover":"(.-)"') do

t['view'] = 'simple'
 
      table.insert(t, {title = total .. 'p ' .. title, mrl = url .. url1})
   
      end
end
 end
 end

 
 --end




--x = string.gsub(x, '"http.-.mp4"', '')

       for url1, url2, url3, url4, url5, total in string.gmatch(x,'"url":"(http.-/hls/)(.-)(/s%d+)(e%d+)(_.-)".-quality":(.-),') do


			

    title1 = string.gsub(url3, '/s', 'Сезон ')
    title = string.gsub(url4, 'e', 'серия  ')
    
    title2 = string.gsub(url2, '(.-%d)', '')
    
      t['view'] = 'simple'
      
      table.insert(t, {title = '(' .. total .. 'p)' .. title1 .. ' ' .. title .. ' ' .. title2, mrl = url1 .. url2 .. url3 .. url4 .. url5, image = image})
      

      end
	
end
   
    elseif args.q == 'kino4k' then
  
--http://wtch.ch/lite/fxapi
    
    -- local x = conn:load(args.id)
		local x = conn:load('http://wtch.ch/lite/fxapi?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
 
 
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 

    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

  if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
   if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1440p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')
       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do
--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
    
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end
   
if slist then
  
      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)</div>') do

--url5 = string.gsub(url5, '^(.-)', 'https://fin-cdn.werkecdn.me/s21')

       t['view'] = 'simple'

    table.insert(t, {title = total .. ' '  .. tolazy(total3) .. ' ' .. total2 .. '(' .. total4 .. ')', mrl = url5})

    end   
    end

    
end
end





--https://lamp-movie.ru


--http://hidxlglk.deploy.cx/lite/filmix?title=чужой+1979

elseif args.q == 'kinofit' then

local x = conn:load('http://178.20.46.40:12600/lite/filmix?title=' .. urlencode(args.id1) .. '+' .. args.id2)

for id in string.gmatch(x,'<div class="videos__line".-"method":"link".-"url":"http.-postid=(.-)\\u0026') do


id = string.gsub(id, '^(.-)', 'item/')
         
         id=base64_encode(id)
 

 
       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')


  
     for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = (total1) .. ' ' .. tolazy(total), mrl = url2})
    
        end
        end
        
  
      




     local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. id .. '&box_mac=acace24b8434')



      for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
  
       total = string.gsub(total, '<!%[CDATA%[', '')
       total = string.gsub(total, ']]>', '')
       
     local x = conn:load(url1 .. '&box_mac=acace24b8434')

    
    for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-сезон).-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
       total1 = string.gsub(total1, ']]> <![CDATA[', '')
       total1 = string.gsub(total1, ']]>', '')
   
        local x = conn:load(url2 .. '&box_mac=acace24b8434')
   

     
     for total2, total3, url3 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<playlist_url><!%[CDATA%[http.-&goto=(.-)&.-]]') do
    
 --     total2 = string.gsub(total2, '<!%[CDATA%[', '')
   --   total2 = string.gsub(total2, ']]>', '')
 
 
 t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total2) .. ' ' .. tolazy(total), mrl = '#stream/q=kinofits&id=' .. url3})
 
 end
 end
 end
 end
 
 
 elseif args.q == 'kinofits' then

local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. args.id .. '&viewseason' .. '&box_mac=acace24b8434')
 
 
      
  --    local x = conn:load(url3 .. '&box_mac=acace24b8434')
 
     
     
     for total4, url4 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]].-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do
    
       total4 = string.gsub(total4, '<!%[CDATA%[', '')
      total4 = string.gsub(total4, ']]>', '')
    
    
    
      t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total4), mrl = url4})
    
        end
      



--http://fxmlparsers.in.net/http://rezka.ag/?act=https://rezka.ag/films/drama/86937-lesnoy-pozhar-2026.html&m=1&ep=id%3D86937%26translator_id%3D238%26is_camrip%3D0%26is_ads%3D0%26is_director%3D0%26action%3Dget_movie

--https://rezka.ag/series/drama/86953-geroi-pustyni-2026.html#t:473-s:1-e:2




elseif args.q == 'hdrezkatest1' then


	local url = 'https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-/(film.-)"') do


local x = conn:load('https://app.lovefilm.cc/lite/rezka?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')


x = string.gsub(x, '\\u0026', '&')

for id, id1, title in string.gmatch(x, 'class=.-videos__movie.-"method".-"call".-"url".-http.-&id=(.-)&t=(.-)&.-class="videos__item%-title">(.-)<') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=hdrezkatestm&id=' .. id .. '&id1=' .. id1})

end
end
   
local url = 'https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)
		

for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-/(series.-)"') do


	local x = conn:load('https://app.lovefilm.cc/lite/rezka?href=' .. url .. '&account_email=naujas%40ideo.lt&uid=hlltpzjn&nws_id=oaca2v5pm1bzplbg3ymgb9fploylwqxv')



x = string.gsub(x, '\\u0026', '&')

for url in string.gmatch(x, '<div class=.-videos__season.-"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)<') do

local x = conn:load(url)

	x = string.gsub(x, '\\u0026', '&')
	
	for id, title in string.gmatch(x,'class="videos__button.-"method".-"link".-"url".-"http.-&href=series.-&id=.-&t=(.-)"}.->(.-)<') do
	
	
	for id1, id2, id3, title1 in string.gmatch(x,'<div class="videos__item videos__movie.-"method".-"call".-"url":"http.-&id=(.-)&.-&s=(.-)&e=(.-)".-class="videos__item%-title">(.-)<') do
	

	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=hdrezkatests&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

end
end
end
end






elseif args.q == 'hdrezkatest' then


	local url = 'https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load(url)


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/film.-)"') do

	
	local x = conn:load('https://hdrezka.me' .. url)


local slist = string.match(x, '<ul id="translators%-list"(.-)</ul>')
      
     if slist then
   
   for id, id1, title in string.gmatch(slist, 'data%-id="(.-)" data%-translator_id="(.-)".->(.-)<') do



t['view'] = 'simple'

table.insert(t, {title = tolazy(title), mrl = '#stream/q=hdrezkatestm&id=' .. id .. '&id1=' .. id1})

end
end
 
 local types = {
			CDNSeries = true,
			CDNMovies = false,
			[''] = true
		}
		
		local trans_id
		for type, isseries in pairs(types) do
	
	local tid, data = string.match(x, 'sof%.tv%.init' .. type .. 'Events.-, (%d+),.-({.-})%);')
	
			
			if data then

local data = json.decode(data)


--url2 = url_for(data)

	url = url_for('get', {file = data['streams'], t = t['name']})

--url = string.gsub(url, '%%3D', '=')

--url = string.gsub(url, '#self/file=%%23h', '')


--url = string.gsub(url, '//_--//JCQjISFAIyFAIyM=', '')
--url = string.gsub(url, '//_--//Xl5eIUAjIyEhIyM=', '')
--url = string.gsub(url, '//_--//IyMjI14hISMjIUBA', '')

--url = string.gsub(url, '//_--//QEBAQEAhIyMhXl5e', '')
--url = string.gsub(url, '//_--//JCQhIUAkJEBeIUAjJCRA', '')

--url = base64_decode(url)

url = urldecode(url)


for quali, url1 in string.gmatch(url, '%[(.-)%](http.-mp4)') do

t['view'] = 'simple'

--table.insert(t, {title = url2, mrl = url2})

table.insert(t, {title = quali, mrl = url1})

end
end
	end	
end
   



   
   
 
   
--local url = 'https://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
		--	local x = conn:load(url)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="http.-(/series.-)"') do


	local x = conn:load('https://hdrezka.tv' .. url)


local data_id = string.match(x, 'class="b%-simple_episode__item".-data%-id="(.-)"')
		if data_id then
			local data = string.match(x, '<ul id="translators%-list".->(.-)</ul>')
			if data then
				for id, title in string.gmatch(data, 'data%-translator_id="(.-)".->(.-)<') do
			--		local title = parser.lazy(title)
					local title = string.match(title, '%((.-)%)') or title
	
	
	
					print(id, title)
	
	local slist = string.match(x, '<ul id="simple%-episodes%-list(.-)</div>')
      
     if slist then
   
   for id1, id2, id3, title1 in string.gmatch(slist, 'data%-id="(.-)" data%-season_id="(.-)" data%-episode_id="(.-)".->(Серия.-)<') do
	
	
		t['view'] = 'simple'
		
table.insert(t, {title = 'Сезон' .. id2 .. ' ' .. tolazy(title1) .. ' ' .. title, mrl = '#stream/q=hdrezkatests&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})

end
end
end
end
end

end
 

      elseif args.q == 'hdrezkatests' then
    
    local headers = {['X-Requested-With'] = 'XMLHttpRequest'}
					local params = http.encode{
		id = args.id1,
		translator_id = args.id,
		season = args.id2,
		episode = args.id3,
		action = 'get_stream'
					}
					



					local x = http.postz('https://hdrezka.me' .. '/ajax/get_cdn_series/', headers, params)

--table.insert(t, {title = x, mrl = x})

local x = json.decode(x)

	url = url_for('get_stream', {file = x['url'], t = t['name']})



--url = string.gsub(url, '%%3D', '=')

--url = string.gsub(url, '#self/file=%%23h', '')


--url = string.gsub(url, '//_--//JCQjISFAIyFAIyM=', '')
--url = string.gsub(url, '//_--//Xl5eIUAjIyEhIyM=', '')
--url = string.gsub(url, '//_--//IyMjI14hISMjIUBA', '')

--url = string.gsub(url, '//_--//QEBAQEAhIyMhXl5e', '')
--url = string.gsub(url, '//_--//JCQhIUAkJEBeIUAjJCRA', '')

--url = base64_decode(url)

url = urldecode(url)


for quali, url3 in string.gmatch(url, '%[(.-)%](http.-mp4)') do

t['view'] = 'simple'

table.insert(t, {title = quali, mrl = url3})

end      
   
   
   
    
    	elseif args.q == 'hdrezkatestm' then
    
    local headers = {['X-Requested-With'] = 'XMLHttpRequest'}
					local params = http.encode{
						id = args.id,
						translator_id = args.id1,
						action = 'get_movie'
					}
					
					local x = http.postz('https://hdrezka.me' .. '/ajax/get_cdn_series/?t=' .. os.time(), headers, params)




local x = json.decode(x)

	url = url_for('get_movie', {file = x['url'], t = t['name']})


url = urldecode(url)




for quali, url3 in string.gmatch(url, '%[(%d+p)%](http.-mp4)') do

t['view'] = 'simple'

table.insert(t, {title = quali, mrl = url3})

end




--https://kinopub.me/

     elseif args.q == 'hdrezka' then

  --http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=search&search=чужой:+земля-2025&box_mac=acace24b8434

--local url = 'http://hdrezka.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2
		
			local x = conn:load('https://kinopub.me/engine/ajax/search.php?q=' .. urlencode(args.id1) .. '+' .. args.id2)
		
	--		table.insert(t, {title = url, mrl = url})


for url in string.gmatch(x, '<div class="b%-search__live_section".-<a href="(.-)"') do
   
      local x = conn:load(url)


          for id, title in string.gmatch(x,'data%-translator_id.-href="(.-)">(.-)</a>') do
     t['view'] = 'simple'
  
  

    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(id)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title =tolazy(title) .. ' ' .. tolazy(total), mrl = url2, image = image})
         end
         
         
for title1, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=.-&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title1) .. ' ' .. tolazy(title), mrl = '#stream/q=rezkis&id=' .. args.id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
        
end
 
 


   
   local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(url)) .. '&box_mac=acace24b8434')
    

  
      for total, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
       t['view'] = 'simple'
     table.insert(t, {title = tolazy(total), mrl = url2, image = image})
         end

    
  --  local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&box_mac=acace24b8434')
  
  
for title, id, id1, id2, id3 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[.-&stream=(.-)&translate=(.-)&season=(.-)&episode=(.-)]]') do
    
     table.insert(t, {title = tolazy(title), mrl = '#stream/q=rezki&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3, image = image})
         end
    
   end 
    
elseif args.q == 'rezkis' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. http.urlencode(base64_encode(args.id)) .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end

elseif args.q == 'rezki' then
      
    local x = conn:load('http://kb-team.club/?do=/plugin&bid=hdrezkanew-hdrezka&act=view&stream=' .. args.id .. '&translate=' .. args.id1 .. '&season=' ..args.id2 .. '&episode=' .. args.id3 .. '&box_mac=acace24b8434')
    
   for total1, url2 in string.gmatch(x,'<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do
      
      t['view'] = 'simple'
     table.insert(t, {title = tolazy(total1), mrl = url2, image = image})
         end




     elseif args.q == 'rezka' then

--https://evkh.lol/lite/rhsprem?kinopoisk_id=464475&title=франкенштейн&year=2025

--https://lampa.remagick.ru/lite/rhsprem

    		local x = conn:load('https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '+' .. args.id2)
    
  --table.insert(t, {title = 'https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '+' .. args.id2, mrl = 'https://lampa.remagick.ru/lite/rhsprem?title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
  
       local url = string.match(x, '<div class="videos__line".-method.-"url".-href=(.-)"') 
       
    local slist = string.match(x, '"quality"(.-)}')
      
    if slist then
   
   for  total1, url3 in string.gmatch(slist, '"(%d+p)":"(http.-mp4)') do
  
    --  url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'simple'

   table.insert(t, {title = '(' .. total1 .. ')', mrl = url3})

     end  
    end
  
 -- https://lampa.remagick.ru/lite/rhsprem?href=films%2fhorror%2f82897-prishlite-pomosch-2026.html
  
  
  
  
  local x = conn:load('https://lampa.remagick.ru/lite/rhsprem?href=' .. url)
  
for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')
      -- t['view'] = 'simple'
   
      local x = conn:load(url2)

  local slist = string.match(x, '"quality"(.-)}')
      
      
   
   for  total1, url3 in string.gmatch(slist, '"(%d+p)":"(http.-mp4)') do
  
   --   url3 = string.gsub(url3, '^(.-)', 'http://z01.online')
  


t['view'] = 'simple'

    table.insert(t, {title = '(' .. total1 .. ')' .. total, mrl = url3})

     end  
 end
     




   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
      local x = conn:load(url)
  

 for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      



      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
      

  

    elseif args.q == 'rez' then

   local x = conn:load('https://lampa.remagick.ru/lite/rhsprem/serial?rjson=False&title=&original_title=&href=' .. args.id3 .. '&id=' .. args.id4 .. '&t=' .. args.id5)
  
  
  

  for  id3, id4, id5,  total3 in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-&href=(.-)&id=(.-)&t=(.-)".->(.-)</div>') do

table.insert(t, {title = total3, mrl = '#stream/q=rez&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5})
end
      


   for url, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
     
       url = string.gsub(url, '\\u0026', '&')
url = string.gsub(url, '\\u002B', '+')
   
   local x = conn:load(url)
   
      for url2, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')

     url2 = string.gsub(url2, '\\u002B', '+')
    

       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total) .. tolazy(total1), mrl = url2})

     end  
     end
  
  
  
--https://lampa.persh1n.ru/lite/pidtor?kinopoisk_id=4760854&title=%D0%9A%D0%BE%D1%80%D0%BE%D0%BB%D1%8C+%D0%A2%D0%B0%D0%BB%D1%81%D1%8B&year=2025&serial=1

    elseif args.q == 'kinobase' then


   local x = conn:load('https://kinobase.org/search?query=' .. urlencode(args.id1) .. '+' .. args.id2)
   
 for title in string.gmatch(x, '<div class="poster".-<a href="/(.-)"') do
        
--https://lampa.oksibutch.ru/lite/kinobase?title=&href=film/244270-blef&t=&s=1
   

   
    url = string.gsub(title, '^(.-)', 'http://78.40.199.67:10630/lite/kinobase?title=&href=') .. '&t=&s=1'
    

     local x = conn:load(url)
   

      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
   --   local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(%d+p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630')
     t['view'] = 'simple'

url2 = string.gsub(url2, '\\u002B', '+')

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2})
    end
     end  
  

  
     for url in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)"') do
   
      local x = conn:load(url)
   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://78.40.199.67:10630')
    
       
      local x = conn:load(url2)

      
      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
    
url3 = string.gsub(url3, '\\u002B', '+')

    
         
    url3 = string.gsub(url3, '^(.-)', 'http://78.40.199.67:10630')
    
       t['view'] = 'simple'



    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3})

    end   
    end
    end
   
end




   elseif args.q == 'kinotop' then


   
local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=search&search=' .. urlencode(args.id1) .. '+' .. args.id2 .. '&box_mac=acace24b8434')
   
       for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do
 
       local x = conn:load(url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')
  
  
     for total1, url2  in string.gmatch(x, '<channel.-<title><!%[CDATA%[(%d+p)]]></title.-<stream_url><!%[CDATA%[(http.-)]]') do
    
    
     t['view'] = 'simple'
      table.insert(t, {title = total1, mrl = url2})

       end
     end
   

for url1  in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[http.-(&media=.-)]]') do


       local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinotop-kinotop&act=watch' .. url1 .. '&box_mac=acace24b8434')
       --or url1 .. '&box_mac=b8bc5bf8dea3')


     for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = (total3) .. (total4), mrl = url3})

end
   
   
  for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-сезон)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  
        local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total3, total4, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
 
     table.insert(t, {title = total2 .. (total3) .. (total4), mrl = url3})

end
end
     end
      
      

elseif args.q == 'jac' then

    

   local x = conn:load('https://lam.akter-black.com/lite/jac?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
   
       t['view'] = 'simple'
    table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     
     


		local x = conn:load('https://lam.akter-black.com/lite/jac?serial=1&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

	x = string.gsub(x, '",', '&')	
  

    for  url, title in string.gmatch(x, '"torrent.-"Link".-"magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
  
  
  
  
  
       t['view'] = 'simple'
     table.insert(t, {title = title,mrl = '#stream/q=result&id=' .. url,image = image})
     end
     


--https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=570402&title=%D0%90%D0%B2%D0%B0%D1%82%D0%B0%D1%80%3A+%D0%9F%D0%BB%D0%B0%D0%BC%D1%8F+%D0%B8+%D0%BF%D0%B5%D0%BF%D0%B5%D0%BB&year=2025
     
--  https://lam.maxvol.pro/lite/pidtor/serial/548bae27dca47ab2805465cc12ab1d9a89d15426?tr=
     
     
     
     
     
     elseif args.q == 'result' then
      args.id = args.id:lower() 
      
      local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   
        end
   
   
   
    elseif args.q == 'pidtor' then
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  
 -- table.insert(t, {title = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})

      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-?tr=).-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/pidtor?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
  


--https://lam.akter-black.com/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=

--https://lam.maxvol.pro/lite/pidtor/serial/0f20a0bfe44a6779f3e8587cc7dc2edb0318ccf7?tr=




for url2, title in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do
   url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '\\u002B', '+')

      local x = conn:load(url2)
    

    
      for url3, total  in string.gmatch(x, '"method":"link".-"url":"http.-/lite/pidtor/serial/(.-)?tr=.-class="videos__item%-title videos__season%-title">(.-)</div>') do


--url3 = string.gsub(url3, '^(.-)', 'https://lam.akter-black.com')

     url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'
     table.insert(t, {title = title .. ' ' ..  total,mrl = '#stream/q=result&id=' .. url3,image = image})
     end
     
   end
 
 
 
-- http://jacred.xyz/api/v1.0/torrents?search=чужой&relased=1979
 
 elseif args.q == 'jacred' then

local x = conn:load('http://jac.red/api/v1.0/torrents?search=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
 


 x = string.gsub(x, '",', '\\u0026')	
 
	
 
  x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
     x = string.gsub(x, '\\u041A', 'К')
       x = string.gsub(x, '\\u043A', 'к')  
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  x = string.gsub(x, '\\u041B', 'Л')
       x = string.gsub(x, '\\u041b', 'Л')
    x = string.gsub(x, '\\u043B', 'л')
       x = string.gsub(x, '\\u043b', 'л')
     
     x = string.gsub(x, '\\u041C', 'М')
       x = string.gsub(x, '\\u043C', 'м')
       x = string.gsub(x, '\\u041D', 'Н')
       x = string.gsub(x, '\\u043D', 'н')
       x = string.gsub(x, '\\u041E', 'О')
     
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
    x = string.gsub(x, '\\u043E', 'о')
       x = string.gsub(x, '\\u043e', 'о')
    
    x = string.gsub(x, '\\u041F', 'П')
       x = string.gsub(x, '\\u043F', 'п')
     
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
          x = string.gsub(x, '\\u042A', 'Ъ')
        x = string.gsub(x, '\\u044A', 'ъ')
        x = string.gsub(x, '\\u042B', 'Ы')
        x = string.gsub(x, '\\u044B', 'ы')
        x = string.gsub(x, '\\u042C', 'Ь')
        x = string.gsub(x, '\\u044C', 'ь')
        x = string.gsub(x, '\\u042D', 'Э')
        x = string.gsub(x, '\\u044D', 'э')
        x = string.gsub(x, '\\u042E', 'Ю')
        x = string.gsub(x, '\\u044E', 'ю')
        x = string.gsub(x, '\\u042F', 'Я')
     
     x = string.gsub(x, '\\u044F', 'я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')

 
 for id, title, total, total1, total2 in string.gmatch(x,'{"tracker".-"magnet:?.-btih:(.-)\\u0026.-name":"(.-)\\u0026.-"relased":(.-),.-"quality":(.-),"voices":%[(.-)]') do
 
total2 = string.gsub(total2, '\\u0026', '",')
 
 
    t['view'] = 'simple'
   
 -- https://lam.akter-black.com/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u 
 -- https://ts.maxvol.pro/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u
  
  
   table.insert(t, {title =  '(' .. total1 .. 'p) ' .. args.id1 .. ' (' .. args.id2 .. ') '  .. ' ' .. total2, mrl = 'm3u+https://ts.maxvol.pro/stream?link=' .. id .. '&m3u'})
 
--   table.insert(t, {title = '(' .. total1 .. 'p) ' .. args.id1 .. ' (' .. args.id2 .. ') '  .. ' ' .. total2, mrl = '#stream/q=jacreds&id=' .. id, image = image})
		end
 
 
 elseif args.q == 'jacreds' then

     args.id = args.id:lower() 

local x = conn:load('https://ts.maxvol.pro/stream?link=' .. args.id .. '&m3u')
 
 
 for title, url in string.gmatch(x,'EXTINF:.-,(.-)(http.-&play)') do
 
 t['view'] = 'simple'
   
 table.insert(t, {title = title, mrl = url})
		end
 
 
 elseif args.q == 'torrs' then

local x = conn:load('http://torrs.ru/search?query=' .. urlencode(args.id1) .. '&relased=' .. args.id2)
   
 --  table.insert(t, {title = 'http://torrs.ru/search?query=' .. urldecode(args.id) .. '(' .. args.id1 .. ')', mrl = '#stream/q=result&id=' .. 'http://torrs.ru/search?query=' .. urldecode(args.id) .. '(' .. args.id1 .. ')', image = image})
   
	--	local x = conn:load(url)
		x = string.gsub(x, '",', '\\u0026')	
    --    x = string.gsub(x, '&', '\\u0026')	
		
    for title, total in string.gmatch(x,'"size".-"title":"(.-)\\u0026.-"magnet":"magnet:?.-btih:(.-)\\u0026') do
      
--title = string.gsub(title, '\\u0026','&')
     -- total = string.gsub(total, '\\u0026','&')
   t['view'] = 'simple'
   
   table.insert(t, {title = title, mrl = '#stream/q=results&id=' .. total, image = image})
		end


elseif args.q == 'results' then
		
      args.id = args.id:lower() 

local x = conn:load('https://lam.akter-black.com/lite/pidtor/serial/' .. args.id .. '?tr=')
      
      
      
      
      
      --	 https://lam.akter-black.com/lite/pidtor/serial/7d2dd45792a2695ff0cc88cde4af51cd5189dfb4?tr=	
--https://lam.akter-black.com/lite/jac?serial=1&title=%D1%87%D1%83%D0%B6%D0%BE%D0%B9%20%D0%B7%D0%B5%D0%BC%D0%BB%D1%8F


    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
      t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   end
 
 
       

elseif args.q == 'anwap' then
  
  
--https://tv.anwap.today/films/search/?toch=on&slv=чужой-Alien&vid=1
  
  
--  local x = conn:load('https://tv.anwap.today/films/search/?slv=' .. urlencode(args.id1) .. '-' .. urlencode(args.id4) .. '&vid=' .. args.id5 .. '&toch=' .. args.id6)
  
  local x = conn:load('https://tv.anwap.today/films/search/?toch=on' .. '&slv=' .. urlencode(args.id1) .. '&vid=1')

  
local slist=string.match(x, '</form><div class="save">По.-id="cn"(.-)"menuniz"')
  

  if slist then
    for url, title in string.gmatch(slist, '<div class="my_razdel film".-<a href="(.-)".-alt="(.-)"') do

     local x = conn:load('https://tv.anwap.today' .. url)

    local slist=string.match(x, '<ul class="tl2">(.-)</ul>')


		if slist then
			for url1, title2 in string.gmatch(slist, '<a href="(/films/load.-)">Скачать MP4(.-)<.-</a>') do
       print(url)
	   	url1 = string.gsub(url1, '^(.-)', 'https://tv.anwap.today')
   
      t['view'] = 'simple'
        table.insert(t, {title = title2 .. tolazy(title), mrl = url1})
	
		end
		end
		end
		end
  
  
--https://tv.anwap.today/films/search/?slv=%D1%87%D1%83%D0%B6%D0%BE%D0%B9&alien&vid=1&toch=on
--https://tv.anwap.today/serials/search/?word=%D1%87%D1%83%D0%B6%D0%BE%D0%B9-alien&vid=1&t=on

local x = conn:load('https://tv.anwap.today/serials/search/?t=on' .. '&word=' .. urlencode(args.id1) .. '&vid=1') 

--local x = conn:load('https://tv.anwap.today/serials/search/?word=' .. urlencode(args.id1) .. '-' .. urlencode(args.id4) .. '&vid=' .. args.id5 .. '&toch=' .. args.id6)




   local slist=string.match(x, '</form><div class="save">По.-id="cn"(.-)"menuniz"')

	if slist then

       for url, title in string.gmatch(slist, '<div class="my_razdel film".-<a href="(.-)".-alt="(.-)"') do

    
    local x = conn:load('https://tv.anwap.today' .. url)

       local slist=string.match(x, '<ul class="tl2">(.-)"popular"')


		if slist then
			for url1, title1 in string.gmatch(slist, '<li><a href="(/serials/s.-)">(.-)</a></li>') do
       
       t['view'] = 'simple'
      
       table.insert(t, {title = tolazy(title) .. ' ' .. title1, mrl = '#stream/q=sezon&id=' .. url1})
        
        end
		end
		end	
end


elseif args.q == 'sezon' then

local page = tonumber(args.page or 1)
    
    local x = conn:load('https://tv.anwap.today' .. args.id .. '-' .. tostring(page))
		

      -- local slist=string.match(x, '<ul class="tl">(.-)</ul>')


	--	if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/down.-)">(.-)</a>') do
       print(url)
	  -- 	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=sezond&id=' .. url})
		end 
	
	
			
	local url = '#stream/page=' .. tostring(page + 1) .. '&q=sezon&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


  
    elseif args.q == 'sezond' then
  
   local x = conn:load('https://tv.anwap.today' .. args.id)
  
  
  
  local slist=string.match(x, 'tlsiconkoi.-<ul class="tlsiconkoi">(.-)</ul>')


		if slist then
			for url, title in string.gmatch(x, '<a href="(/serials/load.-)".-Скачать(.-)<span') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = 'Смотреть' .. tolazy(title), mrl = url})
	
		end
		end	







elseif args.q == 'collaps' then
  
  
  local x = conn:load('http://178.20.46.40:12600/lite/collaps?kinopoisk_id=' .. args.id3)

for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps ' .. tolazy(total), mrl = url2})


       
    end

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end






      local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)
   
   
   for title in string.gmatch(x, '"iframe_url":"http.-/embed/.-/(.-)"') do
   

      

url = string.gsub(title, '^(.-)', 'http://178.20.46.40:12600/lite/collaps?orid=')
     local x = conn:load(url)

   
   
   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

     end  
  

     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite/collaps.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end
end
end



--https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=386

elseif args.q == 'collaps2' then

local x = conn:load('https://api.bhcesh.me/franchise/details?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id3)

 
   for url in string.gmatch(x, '"iframe_url":"(http.-)"') do

local slist = string.match(x, '"voiceActing"(.-)]')

    if slist then 
    
    for total in string.gmatch(slist, '"(.-)"') do



local x = conn:load(url .. '?oneSound=' .. urlencode(total))


table.insert(t, {title = url .. '?oneSound=' .. urlencode(total), mrl = url .. '?oneSound=' .. urlencode(total)})

for url1 in string.gmatch(x, 'hls: "(http.-)"') do

table.insert(t, {title = tolazy(total), mrl = 'https://dl.showvid.ws/x-px?m=' .. url1 .. '&x-cdn=10551403'})

       
    end
end
end
end
 


elseif args.q == 'collaps-dash' then
  
 

  local x = conn:load('http://178.20.46.40:12600/lite/collaps-dash?kinopoisk_id=' .. args.id3)



   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end


elseif args.q == 'kinotochka' then
  
 

--http://91.142.72.69:9833/lite/kinotochka?kinopoisk_id=386&title=чужой&year=1979 



local x = conn:load('https://p01--lampac--9dxms589q2gt.code.run/lite/kinotochka?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(По.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')
      
    url2 = string.gsub(url2, '^(.-)', 'https://p01--lampac--9dxms589q2gt.code.run')
      t['view'] = 'simple'

   table.insert(t, {title = tolazy(total), mrl = url2})

       
    end

    
     local x = conn:load('https://p01--lampac--9dxms589q2gt.code.run/lite/kinotochka?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&serial=1')
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://p01--lampac--9dxms589q2gt.code.run')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie..-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
         url3 = string.gsub(url3, '\\u002B', '+')
         
         
         
    url3 = string.gsub(url3, '^(.-)', 'https://p01--lampac--9dxms589q2gt.code.run')
    
       t['view'] = 'simple'

    table.insert(t, {title = total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



--https://kinovibe.vip/embed/8003

--https://kinovibe.vip/api/find-by-kinopoisk.php?kinopoisk=386

--https://kinovibe.co/embed/kinopoisk/386/


  
 local url = 'https://kinovibe.vip/?do=search&mode=advanced&subaction=search&story=' .. urlencode(args.id1)

		
		local x = conn:load(url)
		
       for id1, id, id2, image, title  in string.gmatch(x, '<a class="sres%-wrap clearfix.-href="(https://.-/)(.-)(-.-)".-<img.-src="(.-)".-<h2>(.-)</h2') do
			--url = string.gsub(url, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=kinotochkav&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2, image = image})
		
		end
  
 -- https://kinovibe.vip/27131-persi-dzhekson-i-olimpiycy-2-sezon-2025.html
  
  
  
  elseif args.q == 'kinotochkav' then
  
  
  
  local x = conn:load('http://185.188.183.182/iptv/kinotochka/serii.php?film=' .. args.id1 .. args.id .. args.id2 .. '&page=')


    for title1, url2 in string.gmatch(x, '<channel.-<title>(Источник:.-)</title>.-<stream_url.-<!%[CDATA.-(http.-)]]') do
 
 t['view'] = 'simple'
  

  table.insert(t, {title = title1, mrl = url2})
		 end
  
  
  
  
  
    local x = conn:load('https://kinovibe.vip/embed/' .. args.id)



for url in string.gmatch(x, 'Playerjs.-file:"(http.-_480.mp4)') do


t['view'] = 'simple'
 
 table.insert(t, {title = '480p', mrl = url})

end
    

for url1 in string.gmatch(x, 'Playerjs.-file:"http.-(http.-.mp4)"') do


t['view'] = 'simple'
 
 table.insert(t, {title = '720p', mrl = url1})

end



 for url in string.gmatch(x, 'Playerjs.-file:"(http.-txt)"') do

   local x = conn:load(url)

--table.insert(t, {title = url, mrl = url})

--x = string.gsub(x, '[480,720]', '')


for total, title, url1 in string.gmatch(x,'"comment":"(.-Серия).-(%[.-])".-"file":"(http.-/s%d+e%d+)%_.-"') do



t['view'] = 'simple'
  
  table.insert(t, {title =  '(' .. '480' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_480.mp4'})


table.insert(t, {title = '(' .. '720' .. 'p) ' .. total .. ' ' .. title, mrl = url1 .. '_720.mp4'})



end




local x = conn:load(url)

  for title, url2, url3, url4 in string.gmatch(x,'"comment":".-(%[.-])".-"file":"(http.-/s)(%d+)e(%d+)%.mp4"') do
  
  t['view'] = 'simple'


table.insert(t, {title = 'Сезон ' .. url3.. ' ' .. 'серия ' .. url4 .. title, mrl = url2 .. url3 .. 'e' .. url4 .. '.mp4'})


end
end


elseif args.q == 'vibix' then
  
  --https://api.manhan.one/lite/vibix?kinopoisk_id=386&account_email=rsmail@ukr.net&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl
 
 local x = conn:load('https://hpmd.stull.xyz/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net')
 

 if x then
 
 for total, url, title in string.gmatch(x, 'div class="videos__item videos__movie.-"(1080p)".-(http.-)".-class="videos__item%-title">(.-)<') do
  
    url = string.gsub(url, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url .. '&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl'})





end
 for total, url, title in string.gmatch(x, 'div class="videos__item videos__movie.-"(720p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  
    url = string.gsub(url, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url .. '&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl'})

end

 for total, url, title in string.gmatch(x, 'div class="videos__item videos__movie.-"(480p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  
    url = string.gsub(url, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title, mrl = url .. '&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl'})

end
end
  
local x = conn:load('https://hpmd.stull.xyz/lite/vibix?kinopoisk_id=' .. args.id3 .. '&account_email=rsmail@ukr.net')
 
 
 -- if x then
  
    for url, title in string.gmatch(x, '<div class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do


 local x = conn:load(url .. '&account_email=rsmail@ukr.net')
 
  for total, url1, title1 in string.gmatch(x, '"(1080p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  

  url1 = string.gsub(url1, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title .. ' ' .. title1, mrl = url1 .. '&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl'})

  end
  
 local x = conn:load(url .. '&account_email=rsmail@ukr.net')
 
  for total, url1, title1 in string.gmatch(x, '"(720p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  

  url1 = string.gsub(url1, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title .. ' ' .. title1, mrl = url1 .. '&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl'})

  end 
  
  local x = conn:load(url .. '&account_email=rsmail@ukr.net')
 
  for total, url1, title1 in string.gmatch(x, '"(480p)":.-(http.-)".-class="videos__item%-title">(.-)<') do
  

  url1 = string.gsub(url1, '\\u0026', '&')
  
  t['view'] = 'simple'

 table.insert(t, {title = total .. ' ' .. title .. ' ' .. title1, mrl = url1 .. '&uid=mq1n6oda&nws_id=ulzjiobt0edgylpx40u5f7kty0lkjuxl'})

  end 
  
  
  end
  
  
  
  

-- local x = conn:load('http://api.atodo.fun/api/search?query=' .. urlencode(args.id1) .. '&year=' .. args.id2)
 
 
local x = conn:load('https://api.manhan.one/externalids?' .. 'kinopoisk_id=' .. args.id3)
 



 local imdb = string.match(x,'"imdb_id":"(.-)"')

if imdb then

local x = conn:load('http://api.atodo.fun/api/details/movie/' .. imdb)


  local tmdb = string.match(x, '"homepage".-"id":(.-),') 

if tmdb then


 local x = conn:load('http://api.atodo.fun/api/source/xinu?id=' .. tmdb .. '&imdb_id=' .. imdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=movie')
 
--  local x = conn:load('http://api.atodo.fun/api/source/xinu?imdb_id=' .. imdb .. '&type=movie')
  
-- table.insert(t, {title = 'http://api.atodo.fun/api/source/xinu?id=' .. tmdb .. '&imdb_id=' .. imdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=movie', mrl = 'http://api.atodo.fun/api/source/xinu?imdb_id=' .. imdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=movie'})
 
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
	
 
 
  local slist = string.match(x, '"type":"movie"(.-)]')
 
 if slist then
 
 for title, total, url in string.gmatch(slist,'"translation_name":"(.-)".-"(1080)":"(http.-)"') do
 
  
  url = string.gsub(url, '\\', '')
  
  t['view'] = 'simple'

 table.insert(t, {title = '(' .. total .. 'p)' .. ' ' .. title, mrl = url})

end

for title, total, url in string.gmatch(slist,'"translation_name":"(.-)".-"(720)":"(http.-)"') do
 
  
  url = string.gsub(url, '\\', '')
  
  t['view'] = 'simple'

 table.insert(t, {title = '(' .. total .. 'p)' .. ' ' .. title, mrl = url})

end

for title, total, url in string.gmatch(slist,'"translation_name":"(.-)".-"(480)":"(http.-)"') do
 
  
  url = string.gsub(url, '\\', '')
  
  t['view'] = 'simple'

 table.insert(t, {title = '(' .. total .. 'p)' .. ' ' .. title, mrl = url})

end
end
end
 end
 
 --local x = conn:load('https://api.manhan.one/externalids?' .. 'kinopoisk_id=' .. args.id3)
 


-- local imdb = string.match(x,'"imdb_id":"(tt%d+)"')
 
 
 --local x = conn:load('http://api.atodo.fun/api/details/tv/' .. imdb)

--table.insert(t, {title = 'http://api.atodo.fun/api/details/tv/' .. imdb, mrl = 'http://api.atodo.fun/api/details/tv/' .. imdb})

 -- local tmdb = string.match(x, '"homepage".-"id":(.-),') 

--if tmdb then


 local x = conn:load('http://api.atodo.fun/api/source/xinu?imdb_id=' .. imdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=tv')

--table.insert(t, {title = 'http://api.atodo.fun/api/source/xinu?imdb_id=' .. imdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=tv', mrl = 'http://api.atodo.fun/api/source/xinu?imdb_id=' .. imdb .. '&kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=tv'})



x = string.gsub(x, '}}}}}]}]}]}', '"season_id"translation_id""vibix"')


x = string.gsub(x, '}}}}}]}}}]}', '"season_id""translation_id""vibix"')

local slist = string.match(x, '"type":"show"(.-)"vibix"')

if slist then

slist = string.gsub(slist, '\\', '')

local slist1 = string.match(slist, '"translation_id"(.-)"translation_id"')

local translation = string.match(slist1,'"translation_name":"(.-)"') 




--for seasons in string.match(slist1, '"season_name":"(.-)"') do

  slist1 = string.gsub(slist1, 'qualities', translation)


--url = url_for(slist1, {
  
    for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(480)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end

for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(720)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(1080)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
 
 
 
 local slist1 = string.match(slist, '"translation_id".-"translation_id".-"translation_id"(.-)"translation_id"')

local translation = string.match(slist1,'"translation_name":"(.-)"') 




--for seasons in string.match(slist1, '"season_name":"(.-)"') do

  slist1 = string.gsub(slist1, 'qualities', translation)


--url = url_for(slist1, {
  
    for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(480)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end

for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(720)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(1080)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
 local slist1 = string.match(slist, '"translation_id".-"translation_id"(.-)"translation_id"')

local translation = string.match(slist1,'"translation_name":"(.-)"') 




--for seasons in string.match(slist1, '"season_name":"(.-)"') do

  slist1 = string.gsub(slist1, 'qualities', translation)


--url = url_for(slist1, {
  
    for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(480)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end

for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(720)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
 
for episodes, total, total1, url in string.gmatch(slist1, 'episode_name":"(.-серия)".-video":{"http":{"(.-)".-"(1080)":"(http.-)"') do 

local title =  '(' .. total1 .. 'p) ' ..  episodes .. ' ' .. total
 
 t['view'] = 'simple'
 
 table.insert(t, {title = title,mrl = url})

 end
    end  
 -- end


 










elseif args.q == 'vibix1' then
  
  
  
--  https://reyohoho-old.onrender.com/#386
  
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  
 -- for url in string.gmatch(x, '(<option player.-</option>)') do
  
  
 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed/.-)"') do
 
 
 
--  embedCode=https://graphicslab.io/sdk/v2/rendex-sdk.min.js
 
 --https://cors.fx666.workers.dev:8443/http://91.142.72.69:9833/lite/vibix?title=чужой&year=1979 
 
 --https://672431256.videoframe2.com/api/v1/embed-kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz&embedCode=https://graphicslab.io/sdk/v2/rendex-sdk.min.js


--https://m.kinobadi.im/pleer_4/pleer.php?id=/api/v1/embed/39378?domain=kino-arhiv.ucoz.club&iframe_url=https%3A%2F%2Friver-3-329.kinescopecdn.net%2F669681541%2Fembed-kp%2F5939991%3Fnc%3D491766&nc=491766

--https://m.kinobadi.im/pleer_4/pleer.php?id=/embed/4539


--https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-1-2110.kinescopecdn.net/hls/4000/4539/4539_1080p.mp4/index.m3u8

--https://river-1-2110.kinescopecdn.net/667983605/hls/4000/4539/4539_1080p.mp4/index.m3u8

--https://river-1-2110.kinescopecdn.net/hls/4000/4539/4539_1080p.mp4/index.m3u8?expires=1771002013&sign=0e528aa9c454fb4e67c4b1b887b60c49&ts=1770915600


--https://185.188.183.182/iptv/kinotochka/lesenkinolite46.php?link=https://river-3-329.kinescopecdn.net/667983605/embed/4539&nc=491748


--http://fork.tutkino.fun/xml/cdn/iframe.php?link=https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed/4539&nc=491748

--https://cors.fx666.workers.dev:8443/https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed/4539&nc=491748
 
 --https://cors.fx666.workers.dev:8443/https://667983605.videoframe2.com/api/v1/embed-kp/386?domain=gokino.su&p=cUQROp1WbVlcWowHVUBTdwjIGg1VDF0EUoSDNUDAcczDXQQVSQVTWwTVKQ1GcthCh42SGZAHAUREgsVK&v=1
 
-- https://cors.fx666.workers.dev:8443/https://667983605.videoframe2.com/api/v1/embed/?domain=gokino.su&p=cUQROp1WbVlcWowHVUBTdwjIGg1VDF0EUoSDNUDAcczDXQQVSQVTWwTVKQ1GcthCh42SGZAHAUREgsVK&v=1
 
 
 --http://185.188.183.182/iptv/kinotochka/lesenkinolite46.php?link=https://river-3-329.kinescopecdn.net/667983605/embed/4539&page=postmd5
 
 
 
-- https://apn-latest.onrender.com/https://672431256.videoframe2.com/api/v1/embed/4539/vibixinscode.html
 
 
-- https://apn-latest.onrender.com/https://river-3-329.kinescopecdn.net/667983605/embed/4539/vibixinscode.html
 
-- https://672431256.videoframe2.com/api/v1/embed/4539/vibixinscode.html
 
 --https://672431256.videoframe2.com/embed/4539/vibixinscode.html
 
 --https://apn-latest.onrender.com/https://river-3-329.kinescopecdn.net/667983605/embed/4539
 --https://667983605.videoframe2.com/api/v1/ad-tags?domain=gokino.su&iframe_url=https%3A%2F%2F667983605.videoframe2.com%2Fembed%2F4539&nc=491705&_=5i6gi5rpqqx
 
 --https://apn-latest.onrender.com/https://672431256.videoframe2.com/api/v1/embed-kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz
 
 --https://672431256.videoframe2.com/api/v1/embed-kp/386?domain=cm.vibix.biz&parent_domain=cm.vibix.biz
 
 
-- https://672431256.videoframe2.com/api/v1/embed/4539?domain=reyohoho.gitlab.io&iframe_url=https://672431256.videoframe2.com/embed/4539&nc=491719

--https://neomovies.site/api/player/vibix/embed/?src=https://672431256.videoframe2.com/embed/4539&nc=491719

 
 --https://kinescope.io/embed/46wjDpcANy2CqZFg8r86Ug/720p
 
 --https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed/UUQRLlFVXYSDzUTHb92Qa1VVMkgDEsTUDQ1GcthCh42SGZAHAUREgsVK
 
 
 
 --https://672431256.videoframe2.com/api/v1/embed-serials/5523?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com/embed-serials/5523
  
--https://river-3-329.kinescopecdn.net/api/v1/embed/4539?domain=gokino.su&iframe_url=https://river-3-329.kinescopecdn.net/667983605/embed-kp/386?nc=491717&nc=491717
 

 
 
-- http://river-3-329.kinescopecdn.net/api/v1/embed/39378?domain=kino-arhiv.ucoz.club&iframe_url=https%3A%2F%2Friver-3-329.kinescopecdn.net%2F669681541%2Fembed-kp%2F5939991%3Fnc%3D491766&nc=491766
 
 
 
 --https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https://667983605.videoframe2.com/embed/4539
 
-- &p=UUQRLlFVXYSDzUTHb92Qa1VVMkgDEsTUDQ1GcthCh42SGZAHAUREgsVK&v=1
 
 
 
 --https://667983605.videoframe2.com/api/v1/embed/4539?domain=gokino.su&iframe_url=https%3A%2F%2F667983605.videoframe2.com%2Fembed%2F4539&sig=2e46e50a334f897b7bdb7c65a9778b114114114114114114114114114114c396cec89dc8c5d29a9712dc6c8c5f4c5f4c5f493c894969ffffcaace969cc994c6d2101d5f29895fccb&ts=1771349966&nonce=k9mwi91jvte&nc=492041
 
 
 
 local x = conn:load('https://667983605.videoframe2.com/api/v1' .. url .. '?domain=gokino.su&iframe_url=https://667983605.videoframe2.com' .. url)
 
 table.insert(t, {title = 'https://667983605.videoframe2.com/api/v1' .. url .. '?domain=gokino.su&iframe_url=https://667983605.videoframe2.com' .. url, mrl = 'https://667983605.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://667983605.videoframe2.com' .. url})
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slis = string.gsub(slist, ',', '"')
 slist = string.gsub(slist, ';', '"')
 
for total, title, url in string.gmatch(slist, '%[(480p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
	
t['view'] = 'simple'
 
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')
t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(480p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 
 
for total, title, url in string.gmatch(slist, '%[(720p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(720p)]%{.-}http.-"%{.-}http.-"({.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 


for total, title, url in string.gmatch(slist, '%[(1080p)](%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'
	
 table.insert(t, {title = total .. title, mrl = url})

    end
 
 for total, title, url in string.gmatch(slist, '%[(1080p)]%{.-}http.-"%{.-}http.-"(%{.-})(http.-)"') do
 
 url = string.gsub(url, '\\', '')

t['view'] = 'simple'

 table.insert(t, {title = total .. title, mrl = url})

    end

end
    end
  
  
  
  
  
  
  
   
  local x = conn:load('https://iframe.cloud/iframe/' .. args.id3)
  
  

 for url in string.gmatch(x, '<div class="cinemaplayer.-"http.-videoframe.-(/embed%-serials.-)"') do
 

 local x = conn:load('https://667983605.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://667983605.videoframe2.com' .. url)
  
 -- table.insert(t, {title = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url, mrl = 'https://672431256.videoframe2.com/api/v1' .. url .. '?domain=reyohoho.github.io&iframe_url=https://672431256.videoframe2.com' .. url})
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
 
 
 
 local slist = string.match(x, '"playlist"(.-)"success"')

    if slist then 
 

 slist = string.gsub(slist, ',', '"')
-- slist = string.gsub(slist, ';', '"')
slist = string.gsub(slist, ']{', '"name":')
slist = string.gsub(slist, ';{', '"name1":')

-- for total1 in string.gmatch(slist, '"title":"(Сезон.-)"') do
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(480p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(720p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p)"name":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})


 end
 
 for total2, total, title, url in string.gmatch(slist, '"title":"(Серия.-)".-%[(1080p).-"name1".-"name1":(.-)}(http.-)"') do
 
 url = string.gsub(url, '\\', '')

	
t['view'] = 'simple'
 
 table.insert(t, {title = total2 .. ' ' .. total .. ' ' .. title, mrl = url})

 
 end
 
 
 
 
    end
  end





--http://178.20.46.40:12600

--https://lamp-movie.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979

--https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=386

--http://178.20.46.40:12600/lite/mirage/video?id_file=911588&token_movie=a6ef0986c7558c5792c3ad19d43611

--http://78.40.199.67:10630/lite/mirage/video?id_file=1265937&token_movie=9de4740ef5b4ff67555ff296494e31&q=1080p



--http://78.40.199.67:10630/proxy/6f687b82601c0dd158c9e0e926e86dba.m3u8



--http://78.40.199.67:10630/lite/mirage/stream.m3u8?id=1265937&q=1080p

--https://lampa.oksibutch.ru/lite/mirage/stream.m3u8?id=1265937&q=1080p


elseif args.q == 'veoveo' then
  
  
  local x = conn:load('https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
   
--table.insert(t, {title = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1), mrl = 'https://lam.maxvol.pro/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1)})
      
      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'veoveo :' .. tolazy(total), mrl = url2})

       
    end
     
--  local x = conn:load('http://178.20.46.40:12600/lite/veoveo?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1))
 
 

 
 
  
  for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method".-"url":"(http.-)".-videos__season%-title">(.-)<') do
     
   --  url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600') 
     
     
     local x = conn:load(url2)

--table.insert(t, {title = url2, mrl = url2})

for  url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total4), mrl = url3})

      end 
      end


elseif args.q == 'kinopub' then
 
-- http://fxmlparsers.in.net/https://kino.pub/?code=z2ibsw9dywo0n01eeibym950w1afbtz6&act=enter
 
 
-- https://ab-ze.xyz/api/hls/alloha?type=film&kp=386&access_token=&quality=&translation=Дублированный
 
 --https://cors.bwa.workers.dev/http://fork.pet/search/result?field=title&search=%D0%93%D1%80%D0%B5%D1%88%D0%BD%D0%B8%D0%BA%D0%B8%26year%3D2025&access_token=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
-- http://go.forkplay.me?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&code=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
--  http://fxmlparsers.in.net/https://kino.pub/?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&code=9ymeff8cft97lcdjswbuww9ri9of2bh1
  
--https://cors.bwa.workers.dev/https://api.srvkp.com/v1/items/search?q=чужой&year=1979&field=title&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6
  
 -- http://parsers.appfxml.com/https://kino.pub/?cat=search&search=Чужой&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6
  
  
 --http://parsers.appfxml.com/https://kino.pub/?cat=view&id=118846&code=9ymeff8cft97lcdjswbuww9ri9of2bh1



 --https://api.pushbr.com/v1/watching?id=118846&access_token=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
 
 --https://app.service-kp.com/v1/items/search?q=чужой&year=1979&field=title&access_token=9ymeff8cft97lcdjswbuww9ri9of2bh1
 
 --https://api.srvkp.com/v1/items/search?q=чужой&year=1979&field=title&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6
 
--http://fxmlparsers.in.net/https://kino.pub/?cat=search&search=%D0%93%D1%80%D0%B5%D1%88%D0%BD%D0%B8%D0%BA%D0%B8%26year%3D2025&access_token=z2ibsw9dywo0n01eeibym950w1afbtz6

-- http://fxmlparsers.in.net/https://kino.pub/?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9%26year%3D1979&code=z2ibsw9dywo0n01eeibym950w1afbtz6
 
 
 --http://parsers.appfxml.com/https://kino.pub/?cat=search&search=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9%26year%3D1979&code=9ymeff8cft97lcdjswbuww9ri9of2bh1
 

 
 
 --http://fork.pet/library/list?title=%D0%A7%D1%83%D0%B6%D0%BE%D0%B9&year=1979&type=movie&type=serial
 
--local x = conn:load('http://parsers.appfxml.com/https://kino.pub/?cat=search&search=' .. urlencode(args.id1 .. '&year=') .. args.id2 .. '&code=9ymeff8cft97lcdjswbuww9ri9of2bh1')

  local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=movie' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

--table.insert(t, {title = url1 .. '&box_mac=acace24b8434', mrl = url1 .. '&box_mac=acace24b8434'})


for url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[Воспроизвести]].-<playlist_url><!%[CDATA%[(http.-)]]') do


      local x = conn:load(url2 .. '&box_mac=acace24b8434')

 for title, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title), mrl = url3})
   
   end
   end
 end




 
 local url = 'http://fork.pet/library/list?title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&type=serial' 



    local x = conn:load('http://kb-team.club/?do=/plugin&bid=kinoportal-kinoportal_4k&path=' .. base64_encode(url) .. '&box_mac=acace24b8434')
       


for url1 in string.gmatch(x, '</channel.-<channel.-<title><!%[CDATA%[.-]]></title.-<playlist_url><!%[CDATA%[(http.-)]]') do

local x = conn:load(url1 .. '&box_mac=acace24b8434')

 
 
   
   for title, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)<.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   local x = conn:load(url2 .. '&box_mac=acace24b8434')
   
  for title1, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url><!%[CDATA%[(http.-)]]') do
  
  local x = conn:load(url3 .. '&box_mac=acace24b8434')
  
   for title2, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do


  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(title) .. ' ' .. tolazy(title1) .. ' (' .. tolazy(title2) .. ')', mrl = url4})
   end
   end
   end
   
end
   

elseif args.q == 'kinopubtv' then
 


local x = conn:load('http://onlinecf3.skaz.tv/lite/kinopub?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
  

 -- https://lampa.inick22.ru/lite/kinopub?kinopoisk_id=386&title=чужой&year=1979   
  
  
  for  total in string.gmatch(x, '<div class="videos__item videos.-class="videos__item%-title">(.-)</div>') do
  
  local x = string.match(x, '"quality"(.-)"subtitles"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"(http.-)"') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
         --   url2 = string.gsub(url2, '^(.-)', 'https://lampa.inick22.ru') 
     


      t['view'] = 'simple'


   table.insert(t, {title = tolazy(total1) .. ( total), mrl = url2})

       
    end
    end
 
 
 for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)
 
 
    for id, id1, id2, id3, total3 in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"http.-&postid=(.-)&title=(.-)&.-&s=(.-)&t=(.-)&.-".->(.-)</div>') do


   t['view'] = 'simple'

    

table.insert(t, {title = tolazy(total2) .. ' ' .. tolazy(total3), mrl = '#stream/q=kinopubs&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})


      end 
      end

    
    elseif args.q == 'kinopubs' then
   
   local x = conn:load('http://onlinecf3.skaz.tv/lite/kinopub?rjson=False&postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&s=' .. args.id2 .. '&t=' .. args.id3 .. '&codec=aac')
   


    for  total in string.gmatch(x, '<div class="videos__item videos.-class="videos__item%-title">(.-)</div>') do
  
  local x = string.match(x, '"quality"(.-)"subtitles"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"(http.-)"') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
         --   url2 = string.gsub(url2, '^(.-)', 'https://lampa.inick22.ru') 
     


      t['view'] = 'simple'


   table.insert(t, {title = '(' .. total1 .. ') ' .. (total), mrl = url2})

       
    end
    end




--https://lamp-movie.ru/lite/kinopub?title=чужой-1979




elseif args.q == 'filmix2' then

  -- https://nexsw.stull.xyz/lite/filmix?kinopoisk_id=386&title=чужой&year=1979&account_email=daniulov.d@yandex.ru 

local x = conn:load('https://nexsw.stull.xyz//lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2 .. '&account_email=daniulov.d@yandex.ru')


local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://nexsw.stull.xyz')
  
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
 -- url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
    
    --     for  total3, url4, total2 in string.gmatch(x, '"(.-p)":"http.-mp4.-(http.-mp4).-class="videos__item%-title">(.-)<') do
-- total3 = string.gsub(total3, ',"', '')
 --   t['view'] = 'simple'
--    table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
    
--end
-- end


    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)

local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
 
    
    if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
   
  if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
 
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
  
  
if slist then
    
      for total4, url4, total3 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-)".-class="videos__item%-title">(.-)<') do
 
 
--url4 = string.gsub(url4, '^(.-)', 'https://evkh.lol')
  
   t['view'] = 'simple'
    
     table.insert(t, {title = total .. ' ' .. tolazy(total3) .. ' ' .. total2 .. ' '.. tolazy(total4), mrl = url4})
   
   end
   end
   
end
end
   
   
   
   
 --  https://rutube.ru/api/search/video/?content_type=video&duration=movie&query=чужой&years=1979
   
   elseif args.q == 'rutube' then


--http://78.40.195.218:9118/lite/rutubemovie?title=чужой&year=1979

		local x = conn:load('https://rutube.ru/api/search/video/?content_type=video&duration=movie&query=' .. urlencode(args.id1 .. ' ' .. args.id2))
  
  

   
   for id, title in string.gmatch(x, '{"id":"(.-)","action_reason".-"title":"(.-)"') do
   
 --  if title == args.id1 then
  
 t['view'] = 'simple'

   table.insert(t, {title = title, mrl = '#stream/q=rutubes&id=' .. id})
    end
-- end
 
 elseif args.q == 'rutubes' then
 
 local x = conn:load('http://kb-team.club/msx/kinofeed/viewtube.php?id=' .. args.id)
 
       x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
	
 
 

 
-- http://kb-team.club/msx/kinofeed/viewtube.php?id=37d5799de2cf4fcc86515fa9461bd296
   
   
   for url, title in string.gmatch(x, '"action":"video.-(http.-)".-"playerLabel":"(.-)"') do
  
  url = string.gsub(url, '\\', '')
  
   
   t['view'] = 'simple'
   
   table.insert(t, {title = title, mrl = url})
    end
   
   elseif args.q == 'vkmovie' then

    -- local x = conn:load(args.id)
		local x = conn:load('https://lam.maxvol.pro/lite/vkmovie?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)



for total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-http.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality"(.-)}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-)"') do
     

     url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro')
      url4 = string.gsub(url4, '\\u002B', '+')
       t['view'] = 'simple'

   table.insert(t, {title = '(' .. total3 .. ') ' .. tolazy(total2), mrl = url4})
    end
     end  


elseif args.q == 'remux' then


--http://kb-team.club/msx/kinozal/remuxhd.php?view&plugin=cGx1Z2luJmJpZD1yZW11eGhkLXJlbXV4aGQmYWN0PWNvbnRlbnQmZ2V0ZmlsZT1hSFIwY0hNNkx5OXRaV2RoYjJKc1lXdHZMbU52YlM5bWFXeHRjeTk2WVhKMVltVjZhRzU1WlM4eU5qQTBOeTFpYkdWbUxYUm9aUzFpYkhWbVppMHlNREkyTFhkbFlpMWtiQzEzWldJdFpHeHlhWEF1YUhSdGJBPT0-&device=acace24b8434


--plugin&bid=remuxhd-remuxhd&act=content&getfile=aHR0cHM6Ly9tZWdhb2JsYWtvLmNvbS9maWxtcy96YXJ1YmV6aG55ZS8yNjA0Ny1ibGVmLXRoZS1ibHVmZi0yMDI2LXdlYi1kbC13ZWItZGxyaXAuaHRtbA==>

--https://megaoblako.com/films/zarubezhnye/26047-blef-the-bluff-2026-web-dl-web-dlrip.html



--http://kb-team.club/msx/kinozal/remuxhd.php?view&plugin=cGx1Z2luJmJpZD1yZW11eGhkLXJlbXV4aGQmYWN0PXN0cmVhbSZmaWxlPWNIVmliR2xqTDNZeWVXNHZjblp4VVdGdmQxQnQ-&device=acace24b8434



--plugin&bid=remuxhd-remuxhd&act=stream&file=cHVibGljL3YyeW4vcnZxUWFvd1Bt>

--https://cloclo60.cloud.mail.ru/weblink/view/v2yn/rvqQaowPm

--http://z01.online/lite/remux/movie?linkid=v2yn/rvqQaowPm

--http://z01.online/lite/remux/movie?linkid=a32e62fd99e4/Pobeg.iz.Shoushenka.1994.x264.BDRip.720p_enotbox.com.mkv&quality=720p&title=%d0%9f%d0%be%d0%b1%d0%b5%d0%b3+%d0%b8%d0%b7+%d0%a8%d0%be%d1%83%d1%88%d0%b5%d0%bd%d0%ba%d0%b0&original_title=The+Shawshank+Redemption

--https://megaoblako.com/index.php?story=Блеф&do=search&subaction=search

--https://megaoblako.com/ultrahd4k/5377-chuzhoy-alien-1979-ultrahd-4k-2160p.html

--https://megaoblako.com/?ysclid=mmj5drmkhr196112427


--https://lam.akter-black.com/lite/remux?kinopoisk_id=386&title=чужой&year=1979

		local x = conn:load('http://z01.online/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

--table.insert(t, {title = 'http://z01.online/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'http://z01.online/lite/remux?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})

      for  url2, total in string.gmatch(x, '<div class="videos__item videos.-"method":"link".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')
      
      

    --   url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
   
   
   
for  url3, total1 in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url3 = string.gsub(url3, '\\u0026', '&')
      url3 = string.gsub(url3, '\\u002B', '+')
      
 
 
 local x = conn:load(url3)
 
       for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url4 = string.gsub(url4, '\\u0026', '&')
      url4 = string.gsub(url4, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total), mrl = url4})

     end  
    end
end

local x = conn:load('http://z01.online/lite/remux?title=' .. urlencode(args.id1) .. '&year=' .. args.id2)

   
   
     for  url, total in string.gmatch(x, '<div class="videos__item videos.-"method":"call".-"url":"(http.-)".-class="videos__item%-title.->(.-)<') do
   
      url = string.gsub(url, '\\u0026', '&')
      url = string.gsub(url, '\\u002B', '+')
      
 
 
 local x = conn:load(url)
 
       for url2 in string.gmatch(x, '"play".-"url":"(http.-)"') do

   url2 = string.gsub(url2, '\\u0026', '&')
      url2 = string.gsub(url2, '\\u002B', '+')   
       t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total), mrl = url2})

     end  
    end



	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end