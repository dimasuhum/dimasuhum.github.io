-- seasonvar.ru plugin
-- © IconBIT 2017

require('video')
require('parser')
require('support')
require('client')
require('fxml')

--local fxml = onCreate

--https://api.embess.ws/embed/movie/486

--local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'



--https://zonafilm.ru/movies

local HOME = 'http://seasonvar.ru'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH








--HOME='http://seasonvar.ru'


--VERIFY1='5ROY6+4ajlq1yinxoxN6+3nVuVIIG7dTu1IU8+7/tzQ=' 
--VERIFY2='4eaaad8258175cc6'

--HASH='0b3c8d64977ceb5456b497f7e9fec1b9'

--HASH='4f4124dc7c6271e3418b12771e8920408ac5938f'
function onLoad()
	log.i('Hello from seasonvar.ru plugin')
	return 1
end

function onUnLoad()
	log.i('Bye from seasonvar.ru plugin')
end

function onCreate(args)
	local t={view='simple',type='folder'}
	t['menu']={}
	if args.q ~= 'genres' then
		table.insert(t['menu'],{title='@string/genres',mrl='#folder/q=genres',image='#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	if not args.q then
	--	local x=http.get(HOME)


        local x = conn:load(HOME)


		
         for url, title, total in string.gmatch(x, '<a href="(/serial.-)".-class="news_n">(.-)<.-class="news_s">(.-)<') do
           url = string.gsub(url, '^(.-)', HOME)
    --     image = string.gsub(image, '^(.-)', 'http:')
			table.insert(t,{title=tolazy(title) .. (total),mrl='#stream/q=content&id='..url, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
		end
	elseif args.q == 'serials' then
		t['message']='@string/serials'
	--	local x=http.get(HOME)
		
        local x = conn:load(HOME)
	    for url,title in string.gmatch(x,'<div itemprop="video".-href="(.-)".-class="pgs%-sinfo%-title">(.-)<') do
           url = string.gsub(url, '^(.-)', HOME)
			if not string.find(title,'<img') then
				table.insert(t,{title=title,mrl='#stream/q=content&id='..url})
			end
		end
		
		
		for id, title in string.gmatch(x, '<a.-href="(.-)" class="pst".-alt="(.-)"') do
		
			table.insert(t,{title=tolazy(title),mrl='#stream/q=content&id='..id})

		end
	elseif args.q == 'serials' then
		t['message']='@string/serials'
	--	local x=http.get(HOME)
		
        local x = conn:load(HOME)
		
        for id, title in string.gmatch(x, '<a href="(.-)".-class="news_n">(.-)<.-<span class="news_s">(.-)<') do
        url = string.gsub(url, '^(.-)', HOME)
	    --for id,title in string.gmatch(x,'<div itemprop="video".-href="(.-)".-class="pgs%-sinfo%-title">(.-)<') do
	    
			if not string.find(title,'<img') then
				table.insert(t,{title=title,mrl='#stream/q=content&id='..id})
			end
		end
	elseif args.q == 'genres' then
		t['message']='@string/genre'
	--	local x=http.get(HOME)
		
      local x = conn:load(HOME)
		
		x=string.match(x,'<select data%-filter="genre">(.-)</select>')
        for id,title in string.gmatch(x,'<option value="(%d+)">(.-)</option>') do
            table.insert(t,{title=tolazy(title),mrl='#stream/q=genre&id=' .. id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
		end
      --  local x=http.get(HOME)
        
       local x = conn:load(HOME)
        
		x=string.match(x,' <select data%-filter="country">(.-)</select>')
        for id,title in string.gmatch(x,'<option value="(%d+)">(.-)</option>') do
            table.insert(t,{title=tolazy(title),mrl='#stream/q=genre&id=' .. id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
		end
    --    local x=http.get(HOME)
        
       local x = conn:load(HOME)
        
        x=string.match(x,'<select data%-filter="golosa">(.-)</select>')
		for id,title in string.gmatch(x,'<option value="(%d+)">(.-)</option>') do
			table.insert(t,{title=tolazy(title),mrl='#stream/q=genre&id=' .. id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
		end
	elseif args.q == 'genre' then
		local fields='filter%5BquotG%5D%5B%5D='..args.id..'&filter%5BengName%5D=&filter%5Bonly%5D=&filter%5Brait%5D=kp&filter%5Bhd%5D=&filter%5Bexp%5D=&filter%5Bsub%5D=&filter%5Bblock%5D=&filter%5Bhistory%5D=&filter%5Bmark%5D=&filter%5Bnw%5D='
		local headers={}
		headers['Content-Type']='application/x-www-form-urlencoded'
		headers['X-Requested-With']='XMLHttpRequest'
		local x=http.post(HOME,headers,fields)
		
		for id,title in string.gmatch(x,'<a.-href="(.-)".->(.-)</a>') do
        id = string.gsub(id, '^(.-)', HOME)
			table.insert(t,{title=tolazy(title),mrl='#stream/q=content&id='..id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
		end
		
--http://seasonvar.ru/?mode=search&query=%D0%9F%D0%BE&page=2

        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/?mode=search&query=' .. urlencode(args.keyword) .. '&page='  .. tostring(page)

		
	--	local x = http.getz(url)
		
       local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
         url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
		
	elseif args.q == 'content' then
		t['view']='annotation'
     --   local x=http.get(args.id)
        
      local x = conn:load(args.id)
        
		--local x=http.get(HOME..args.id)
		t['name']=parse_match(x,'<h1 class="pgs%-sinfo%-title">(.-)</h1>')
		t['description']=parse_match(x,'<p itemprop="description">(.-)</p>')
		t['poster']=parse_match(x,'<meta property="og:image" content="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^(.-)', 'https:')
		end
		
		t['annotation']=parse_array(x,{'(Оригинал:.-)</span>','(Жанр:.-)</span>','(Ограничение:</span>.-)</span>','(Страна:.-)</span>','(Вышел:.-)</span>','(Режиссер:.-)</span>','(В ролях</span>.-)</span>'})
	
--//playep.pro/pl/2889?season=1&episode=1&voice=10
--http://playep.pro/player/responce.php?id=1014&season=1&episode=1&voice=10	

--http://hovels.info/bug/player/responce.php?id=5894&season=1&episode=1&voice=10

--http://nonametv.h1n.ru/videohhhghJgfDsbjhybbGGjnbgnbdvqbkjmmn6NhnJilNhgliljnvfnbhngghggfttfbmjhBGcvngfvbfngHgfnmdljgkkknUTDGhfbkjhfhbhhjjjytgjjjjjnnKhikug/seasonvar.xml


--http://divantv.zz.mu/kinoboom_dimon1978pl__2018_kino_live_profi_krad_i_portal_2018-12-22_10-32-46/SeasonVar.one/seasonvar.php?ID=38834&TYPE=.m3u

--http://divantv.zz.mu/kinoboom_dimon1978pl_no_save_2018_kino_live_profi_krad_i_portal_2018-12-22_10-32-46/SeasonVar.one/seasonvar.php?ID=38323&TYPE=.m3u

--http://datalock.ru/playlist/77e4bbd19fee35a7bd0eb0195da41b95/38323/list.txt


--http://95.181.230.125/seasonvar/svar.php?play=http://seasonvar.ru/serial-16938-Babij_bunt_ili_Vojna_v_Novoselkovo.html

--\u0413\u043b\u0430\u0432\u043d\u0430\u044f

      for url in string.gmatch(x, '<meta property="og:url" content="(http.-)"') do

    url = string.gsub(url, '^(.-)', 'http://95.181.230.125/seasonvar/svar.php?play=')

     table.insert(t,{title= 'Смотреть', mrl='#stream/q=content&id=' .. url})
            end 
  --   local x=http.get(args.id)
--    local x=string.match(x,'channels.-channels(.-)}]')
     for title, url1 in string.gmatch(x, ',"title":"(.-)".-"stream_url":"(http.-)"') do


     title = string.gsub(title, '\\u0441\\u0435\\u0440\\u0438\\u044f', 'серия')

    url1 = string.gsub(url1, '\\', '')
     t['view'] = 'simple'
      table.insert(t,{title= title, mrl= url1})
            end 



           for id in string.gmatch(x, '<link itemprop="embedUrl" href=.-/player/(.-)/"') do
           id = string.gsub(id, '^(.-)', 'm3u+http://divantv.zz.mu/kinoboom_dimon1978pl_no_save_2018_kino_live_profi_krad_i_portal_2018-12-22_10-32-46/SeasonVar.one/seasonvar.php?ID=') .. '&TYPE=.m3u'
				table.insert(t,{title= 'Смотреть', mrl= id})
            end 



    --     for id in string.gmatch(x, '<link itemprop="embedUrl" href=.-/player/(.-/)"') do
     --      id = string.gsub(id, '^(.-)', 'http://datalock.ru/playlist/77e4bbd19fee35a7bd0eb0195da41b95/') .. 'list.txt'
		--		table.insert(t,{title= id, mrl='#stream/q=content&id=' .. id})
        --    end 
      --    x = iconv(http.get(url), 'base64_decode', 'UTF-8') 
      
--file":"#2\/\/Z3JpZA==
      
      
      
         for title, id in string.gmatch(x, '{"title":"(.-)","file":"(.-)"') do
         
          title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
          
           id = string.gsub(id, '#2', '')
           id = string.gsub(id, '\\/\\/Z3JpZA==', '')
         id=http.urldecode(base64_decode(id))
    --     url1=http.urldecode(base64_decode(url1))
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title), mrl = id})
            end  
	end
	    
	return t
end