-- seasonvar.ru plugin
-- © IconBIT 2017

require('video')
require('parser')
require('support')
require('client')
require('fxml')

--local fxml = onCreate

--https://api.embess.ws/embed/movie/486

--local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'

--http://seasonvar.ru/?mode=top&period=7&genre=

--https://zonafilm.ru/movies

local HOME = 'http://seasonvar.ru'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH








--HOME='http://seasonvar.ru'


--VERIFY1='5ROY6+4ajlq1yinxoxN6+3nVuVIIG7dTu1IU8+7/tzQ=' 
--VERIFY2='4eaaad8258175cc6'

--HASH='0b3c8d64977ceb5456b497f7e9fec1b9'

--HASH='4f4124dc7c6271e3418b12771e8920408ac5938f'
function onLoad()
	log.i('Hello from seasonvar.ru plugin')
	return 1
end

function onUnLoad()
	log.i('Bye from seasonvar.ru plugin')
end

function onCreate(args)
	local t={view='simple',type='folder'}
	t['menu']={}
	if args.q ~= 'genres' then
		table.insert(t['menu'],{title='@string/genres',mrl='#folder/q=genres',image='#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	if not args.q then
	--	local x=http.get(HOME)


        local x = conn:load(HOME)


		
         for url, title, total in string.gmatch(x, '<a href="(/serial.-)".-class="news_n">(.-)<.-class="news_s">(.-)<') do
           url = string.gsub(url, '^(.-)', HOME)
    --     image = string.gsub(image, '^(.-)', 'http:')
			table.insert(t,{title=tolazy(title) .. (total),mrl='#stream/q=content&id='..url, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
		end




elseif args.q == 'genre' then

	local x = conn:load(HOME .. '/?mode=top&period=7&genre=' .. args.id)
   
   --local x= conn:load(HOME .. '/?mode=top&period=7')

	
     for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
         url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'http:')
        
    t['view'] = 'grid_poster'
		

		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end






	elseif args.q == 'serials' then
		t['message']='@string/serials'
	--	local x=http.get(HOME)
		
        local x = conn:load(HOME)
	    for url,title in string.gmatch(x,'<div itemprop="video".-href="(.-)".-class="pgs%-sinfo%-title">(.-)<') do
           url = string.gsub(url, '^(.-)', HOME)
			if not string.find(title,'<img') then
				table.insert(t,{title=title,mrl='#stream/q=content&id='..url})
			end
		end
		
		
		for id, title in string.gmatch(x, '<a.-href="(.-)" class="pst".-alt="(.-)"') do
		
			table.insert(t,{title=tolazy(title),mrl='#stream/q=content&id='..id})

		end
		
	
	
		elseif args.q == 'serials' then
		t['message']='@string/serials'
		
      local x = conn:load(HOME .. '/?mode=top')
	
     for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
         url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'http:')
        
        t['view'] = 'grid_poster'
		
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		
		
		
	elseif args.q == 'serials' then
		t['message']='@string/serials'
	--	local x=http.get(HOME)
		
        local x = conn:load(HOME)
		
        for id, title in string.gmatch(x, '<a href="(.-)".-class="news_n">(.-)<.-<span class="news_s">(.-)<') do
        url = string.gsub(url, '^(.-)', HOME)
	    --for id,title in string.gmatch(x,'<div itemprop="video".-href="(.-)".-class="pgs%-sinfo%-title">(.-)<') do
	    
			if not string.find(title,'<img') then
				table.insert(t,{title=title,mrl='#stream/q=content&id='..id})
			end
		end


	elseif args.q == 'genres' then
		t['message']='@string/genre'
	--	local x=http.get(HOME)
--		http://fxmlparsers.in.net/http://seasonvar.ru/?mode=top&period=7&genre=


 --  table.insert(t,{title='Топ',mrl='#stream/q=genre&id=' .. '', image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})

		
     -- local x = conn:load(HOME)

  --   HOME = string.gsub(HOME, HOME, HOME .. '/?mode=top&period=7&genre=')
     
     local x = conn:load(HOME .. '/?mode=top&period=7&genre=')
		
		x=string.match(x,'<select class="filter gen">(.-)</select>')
        for id,title in string.gmatch(x,'<option value="(.-)".->(.-)</option>') do
      


--?id=db&act=/?mode=top&period=7&genre=19
   
   
   --  table.insert(t,{title=title,mrl='#stream/genre=' .. id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
      
           table.insert(t,{title=tolazy(title),mrl='#stream/q=genre&id=' .. id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
		end
      --  local x=http.get(HOME)
        
  
  
  
    local x = conn:load(HOME)
        
        x=string.match(x,'<select data%-filter="golosa">(.-)</select>')
		for id,title in string.gmatch(x,'<option value="(%d+)">(.-)</option>') do
			table.insert(t,{title=tolazy(title),mrl='#stream/q=genre&id=' .. id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
		end
  
  
       local x = conn:load(HOME)
        
		x=string.match(x,'<select data%-filter="country">(.-)</select>')
        for id,title in string.gmatch(x,'<option value="(%d+)">(.-)</option>') do
            table.insert(t,{title=tolazy(title),mrl='#stream/q=genre&id=' .. id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
		end
    --    local x=http.get(HOME)
        
       
	
elseif args.q == 'genre' then
		local fields='filter%5BquotG%5D%5B%5D='..args.id..'&filter%5BengName%5D=&filter%5Bonly%5D=&filter%5Brait%5D=kp&filter%5Bhd%5D=&filter%5Bexp%5D=&filter%5Bsub%5D=&filter%5Bblock%5D=&filter%5Bhistory%5D=&filter%5Bmark%5D=&filter%5Bnw%5D='
		local headers={}
		headers['Content-Type']='application/x-www-form-urlencoded'
		headers['X-Requested-With']='XMLHttpRequest'
	--	local x=http.post(HOME,headers,fields)
	--	local x=conn:load(HOME,headres,fields)

     --    x=conn:load(x)
    --   for id,title in string.gmatch(x,'<a.-href="(.-)">(.-)</a>') do

  -- for id, title in string.gmatch(x, '<a data%-id=.-href="(/serial.-html).->(.-)</a>') do
--	id = string.gsub(id, '^(.-)', HOME)
	
	--table.insert(t,{title=tolazy(title),mrl='#stream/q=content&id='..id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})



	--end





     
	
	
	
	
    
	
	
	
	
	
	
	
	--	for id,title in string.gmatch(x,'<a.-href="(.-)">(.-)</a>') do
  --      id = string.gsub(id, '^(.-)', HOME)
		--	table.insert(t,{title=tolazy(title),mrl='#stream/q=content&id='..id, image = 'https://lh3.googleusercontent.com/bVfEqJBxGjmVZK9eGr4ZnrEzi209nevJq6oOnqrAmqLgkVHlyurvqdJBuigtaek_C2DU=w220'})
	--	end
		
--http://seasonvar.ru/?mode=search&query=%D0%9F%D0%BE&page=2

        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/?mode=search&query=' .. urlencode(args.keyword) .. '&page='  .. tostring(page)

		
	--	local x = http.getz(url)
		
       local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="pgs%-search%-wrap".-<a href="(.-)".-<img src="(.-)".-class="pgs%-search%-info".-href=.->(.-)<')do
         url = string.gsub(url, '^(.-)', HOME)
		image = string.gsub(image, '^(.-)', 'http:')
        
        t['view'] = 'grid_poster'
		
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
		
	elseif args.q == 'content' then
		t['view']='annotation'
     --   local x=http.get(args.id)
        
      local x = conn:load(args.id)
        
		--local x=http.get(HOME..args.id)
		t['name']=parse_match(x,'<h1 class="pgs%-sinfo%-title">(.-)</h1>')
		t['description']=parse_match(x,'<p itemprop="description">(.-)</p>')
		t['poster']=parse_match(x,'<meta property="og:image" content="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^(.-)', 'https:')
		end
		
		t['annotation']=parse_array(x,{'(Оригинал:.-)</span>','(Жанр:.-)</span>','(Ограничение:</span>.-)</span>','(Страна:.-)</span>','(Вышел:.-)</span>','(Режиссер:.-)</span>','(В ролях</span>.-)</span>'})
	





     
     
     local slist = string.match(x, '<ul class="tabs%-result">(.-)</ul>')
      
if slist then

   for url2, total in string.gmatch(slist, '<a href="(.-)".-Сериал (.-)<') do
   
 
-- total = string.gsub(total, total,'[%D]')
-- total = string.gsub(total, '[%s]', '')
--  total = string.gsub(total, '%%c', '')
 
  table.insert(t, {title = tolazy(total), mrl = '#stream/q=seasonvars&id=' .. url2, image = image})
		
		end
end






  local slist = string.match(x, '<ul class="tabs%-result">(.-)</ul>')
      
if slist then

   for url, total in string.gmatch(slist, '<a href="(.-)".-Сериал (.-)<') do

        

    url = string.gsub(url, '^(.-)', 'http://95.181.230.125/seasonvar/svar.php?play=' .. HOME)

 table.insert(t,{title=tolazy(total), mrl='#stream/q=content&id=' .. url})
            end
         end   
  --   local x=http.get(args.id)
--    local x=string.match(x,'channels.-channels(.-)}]')
  
  
  
  
  x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	


  
  
  
     for title, url1 in string.gmatch(x, ',"title":"(.-)".-"stream_url":"(http.-)"') do


   --  title = string.gsub(title, '\\u0441\\u0435\\u0440\\u0438\\u044f', 'серия')

    url1 = string.gsub(url1, '\\', '')
     t['view'] = 'simple'
      table.insert(t,{title= title, mrl= url1})
            end 







   
   elseif args.q == 'seasonvars' then
   
   local x = conn:load(HOME .. args.id)
        
      --  local x = conn:load(url2)
 
 for id1, total1 in string.gmatch(x,'"(/playls2.-)".-data%-translate%-percent=.->(.-)</li>') do
 
 
    --    for id1 in string.gmatch(x,'player = new Playerjs.-var pl.-"(/playls2.-)"') do
            
    local x = conn:load('http://seasonvar.ru' .. id1)
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	

    
    
            
      for title1, id2 in string.gmatch(x,'"title":"(.-)SD.-"file":"#2(.-)"') do
            
      
      id2 = string.gsub(id2, '\\/\\/b2xvbG8=', '') 
      
      id2=http.urldecode(base64_decode(id2))
       id2 = string.gsub(id2, '^(.-)', 'http:') 
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title1) .. ' ' .. total1, mrl = id2})
            end  
	end
 
 

		
        
	end
	    
	return t
end