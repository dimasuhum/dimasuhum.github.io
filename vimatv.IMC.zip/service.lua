-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--https://api.embess.ws/embed/movie/486

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; alpac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; _lampac_auth=8126ef1f-0a68-4b87-be2b-732e679461cc; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}


local HOME = 'http://kb-team.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH








PASS = '7777'

local lockpass



function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)

--if not args.q and args.keyword then
--lockpass = args.keyword
--end

--if lockpass == PASS then
--else
--return {view="keyword",message="enter access code"}
--end


	local t = {view = 'grid', type = 'folder'}
		t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end




	if not args.q then

    local url = 'https://tv.alcopa.cc/api/iptv/channels?playlist_id=all&page=1&limit=100000'

--local url = 'https://tv.alcopa.cc/api/iptv/channels?group=Общие&playlist_id=all&page=1&limit=100000'


		local x = http.getz(url, headers)

--url = url_for(x)
--url = urldecode(url)
	--	table.insert(t, {title = url, mrl = url, image = image})


local x = json.decode(x)

		for _, v in ipairs(x['channels']) do
			local url1 = 'https://tv.alcopa.cc/api/iptv/play?channel_id=' .. v['id']
	
	--t['view'] = 'simple'
	
	table.insert(t, {title = v['name'], group = v['спорт'], mrl = '#stream/q=channel&id=' .. url1, image = v['logo']})

end




          

	
	
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 
 table.insert(t, {title = 'Общие', mrl = '#stream/q=channels&id=' .. 'Общие', image = image})
 
table.insert(t, {title = 'Кино', mrl = '#stream/q=channels&id=' .. 'Кино', image = image})

table.insert(t, {title = 'Спорт', mrl = '#stream/q=channels&id=' .. 'Спорт', image = image})

table.insert(t, {title = 'Познавательные', mrl = '#stream/q=channels&id=' .. 'Познавательные', image = image})

table.insert(t, {title = 'Развлекательные', mrl = '#stream/q=channels&id=' .. 'Развлекательные', image = image})

table.insert(t, {title = 'Музыка', mrl = '#stream/q=channels&id=' .. 'Музыка', image = image})

table.insert(t, {title = 'Детские', mrl = '#stream/q=channels&id=' .. 'Детские', image = image})

table.insert(t, {title = 'Новостные', mrl = '#stream/q=channels&id=' .. 'Новостные', image = image})

table.insert(t, {title = 'Региональные', mrl = '#stream/q=channels&id=' .. 'Региональные', image = image})


--table.insert(t, {title = 'Другие', mrl = '#stream/q=channels&id=' .. 'Другие', image = image})

table.insert(t, {title = 'Взрослые', mrl = '#stream/q=channels&id=' .. 'Взрослые', image = image})

    elseif args.q == 'channels' then

--local url = 'https://tv.alcopa.cc' .. args.id

 local url = 'https://tv.alcopa.cc/api/iptv/channels?playlist_id=all&group=' .. args.id .. '&page=1&limit=100000'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; alpac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; _lampac_auth=8126ef1f-0a68-4b87-be2b-732e679461cc; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}

		local x = http.getz(url, headers)


local x = json.decode(x)

		for _, v in ipairs(x['channels']) do
			local url1 = 'https://tv.alcopa.cc/api/iptv/play?channel_id=' .. v['id']


table.insert(t, {title = v['name'], mrl = '#stream/q=channel&id=' .. url1, image = v['logo']})

end




 
    




	
--	t['view'] = 'simple'
	
--	table.insert(t, {title = v['name'], mrl = 'https://tv.alcopa.cc' .. url2, image = v['logo']})

--end





elseif args.q == 'channel' then


   local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; alpac_token=8126ef1f-0a68-4b87-be2b-732e679461cc; _lampac_auth=8126ef1f-0a68-4b87-be2b-732e679461cc; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

     local x = http.getz(args.id, headers)
 
  local url2 = string.match(x,'http.-(/proxy.-m3u8)')   

--for url2 in string.gmatch(x,'(http.-m3u8)') do


      if url2 then
    print(url2)
    return {view = 'playback', mrl = 'https://tv.alcopa.cc' .. url2, seekable = 'true', direct = 'true'}
    

--end
end




	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
--end
	end
	return t
end