-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--https://api.embess.ws/embed/movie/486

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; alpac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; _lampac_auth=a46f8a8a-8878-4fa5-8554-8296ba62260d; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}


local HOME = 'http://kb-team.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH








PASS = '7777'

local lockpass



function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)

--if not args.q and args.keyword then
--lockpass = args.keyword
--end

--if lockpass == PASS then
--else
--return {view="keyword",message="enter access code"}
--end


	local t = {view = 'grid', type = 'folder'}
		t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end




	if not args.q then

    local url = 'https://tv.alcopa.cc/api/iptv/channels?playlist_id=all&page=1&limit=100000'

--local url = 'https://tv.alcopa.cc/api/iptv/channels?group=Общие&playlist_id=all&page=1&limit=100000'


		local x = http.getz(url, headers)

--url = url_for(x)
--url = urldecode(url)
	--	table.insert(t, {title = url, mrl = url, image = image})


local x = json.decode(x)

		for _, v in ipairs(x['channels']) do
			local url1 = 'https://tv.alcopa.cc/api/iptv/play?channel_id=' .. v['id']
	
	--t['view'] = 'simple'
	
	table.insert(t, {title = v['name'], mrl = '#stream/q=channel&id=' .. url1, image = v['logo']})

end




          

	
	
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 
-- table.insert(t, {title = 'Общие', mrl = '#stream/q=channels&id=' .. 'Общие', image = image})
 
 
 
table.insert(t, {title = 'Кино', mrl = '#stream/q=channels&id=' .. 'кино', image = image})

table.insert(t, {title = 'Спорт', mrl = '#stream/q=channels&id=' .. 'спорт', image = image})

table.insert(t, {title = 'Познавательные', mrl = '#stream/q=channels&id=' .. 'познавательные', image = image})

table.insert(t, {title = 'Развлекательные', mrl = '#stream/q=channels&id=' .. 'развлекательные', image = image})

table.insert(t, {title = 'Музыка', mrl = '#stream/q=channels&id=' .. 'музыка', image = image})

table.insert(t, {title = 'Детские', mrl = '#stream/q=channels&id=' .. 'детские', image = image})

table.insert(t, {title = 'Новости', mrl = '#stream/q=channels&id=' .. 'новости', image = image})

--table.insert(t, {title = 'Региональные', mrl = '#stream/q=channels&id=' .. 'Региональные', image = image})

table.insert(t, {title = 'HD', mrl = '#stream/q=channels&id=' .. 'HD', image = image})


table.insert(t, {title = 'HD Orig', mrl = '#stream/q=channels&id=' .. 'HD Orig', image = image})

table.insert(t, {title = '4K', mrl = '#stream/q=channels&id=' .. '4K', image = image})

table.insert(t, {title = 'Другие', mrl = '#stream/q=channels&id=' .. 'другие', image = image})

table.insert(t, {title = 'Взрослые', mrl = '#stream/q=channels&id=' .. 'взрослые', image = image})

    elseif args.q == 'channels' then

--local url = 'https://tv.alcopa.cc' .. args.id

 local url = 'https://tv.alcopa.cc/api/iptv/channels?playlist_id=all&group=' .. urlencode(args.id) .. '&page=1&limit=100000'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; alpac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; _lampac_auth=a46f8a8a-8878-4fa5-8554-8296ba62260d; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}

		local x = http.getz(url, headers)


--local x = json.decode(x)

	--	for _, v in ipairs(x['channels']) do
	
	for id, name, image in string.gmatch(x,'{"id":"(.-)","name":"(.-)".-"logo":"(.-)"') do
	--		local x = json.decode(x)

--		for _, v in ipairs(x['channels']) do
			local url1 = 'https://tv.alcopa.cc/api/iptv/play?channel_id=' .. id
	
	--t['view'] = 'simple'
	
	table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. url1, image = image})

end





elseif args.q == 'channel' then


   local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; alpac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; _lampac_auth=a46f8a8a-8878-4fa5-8554-8296ba62260d; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=0"
}

     local x = http.getz(args.id, headers)
 
  local url2 = string.match(x,'http.-(/proxy.-m3u8)')   

--for url2 in string.gmatch(x,'(http.-m3u8)') do

--table.insert(t, {title = 'https://tv.alcopa.cc' .. url2, mrl = 'https://tv.alcopa.cc' .. url2})

  --    if url2 then
--    print(url2)
    return {view = 'playback', mrl = 'https://tv.alcopa.cc' .. url2, seekable = 'true', direct = 'true'}
    

--end
--end




	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
--end
	end
	return t
end