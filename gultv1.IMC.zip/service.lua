-- onlinetv plugin

require('support')
require('video')
require('parser')

HOME = 'https://zigfreed.ru'

HOME_SLASH = HOME .. '/'

--http://www.teleguide.info/download/new3/jtv.zip;
--http://iptvx.one/epg/epg_lite.xml.gz;
--http://programtv.ru/xmltv.xml.gz;
--http://epg.it999.ru/edem.xml.gz;

--TV_URL = 'https://vse-tv.net/tvguide/vse-tv-lite.xml.gz'

--TV_URL = 'https://iptvx.one/epg/epg.xml.gz, https://vse-tv.net/tvguide/vse-tv-lite.xml.gz, http://www.teleguide.info/download/new3/jtv.zip, http://epg.one/epg.xml.gz, https://zigfreed.ru/Z!/epg.xml'


--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'

--TV_URL = 'http://myott.top/api/epg.xml.gz'

--TV_URL = 'http://epg.one/epg2.xml.gz'


--TV_URL = 'http://epg.it999.ru/edem.xml.gz'

--TV_URL = 'https://italo.drm-play.com/full.xml.gz'

--TV_URL = 'https://zigfreed.ru/Z!/epg.xml'

TV_URL = 'http://epg.one/epg.xml.gz'



--TV_URL = 'https://zigfreed.ru/Z!/epg.xml'

TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

--PASS = '7777'

--local lockpass


function onLoad()
	print('Hello from onlinetv plugin')
	return 1
end

function onUnLoad()
	print('Bye from onlinetv plugin')
end

function onCreate(args)

--if not args.q and args.keyword then
--lockpass = args.keyword
--end

--if lockpass == PASS then
--else
--return {view="keyword",message="enter --access code"}
--end



	local t = {view = 'list', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	if not args.q then
	
	local genre = args.genre or '1'

--https://proxy4.rte.net.ru/http://live.guljaj.com/user/ent.php



	   local url = 'https://proxy4.rte.net.ru/http://live.guljaj.com/user/cab.php'


local params = 'user=1133&idc=' .. genre


  --  ["Host"] = "live.guljaj.com",

local headers = {

    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Content-Length"] = "",
    ["Origin"] = "http://live.guljaj.com",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://live.guljaj.com/user/cab.php",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; _ym_isad=2; mdd=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788619898%2C665940000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol-4PfTMYrAajF6CABHh5l2wmkMmQ-od0foZfHbe59lkNurTlDMXknCptH1cCDbvi-k2ZoW0_gz00YliZBM871QeYPAKM0FcmoiXdNuBF6HEwFQVFvqKZIbxSGQ6h89xd_hzTiexca8MQqXSm0bnvJFIG4cpeg%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
}


 local x = http.postz(url, headers, params)
     	
     	
--for title in string.gmatch(x, 'href.-onclick=.-(window.document.fidk.-)<a') do
     	        
        for title, idk, idc in string.gmatch(x, 'window.document.fidk.-return false.->(.-)</a>.-name=user.-<input type=hidden value=(.-)name=idk.-<input type=hidden value=(.-)name=idc') do
	
--	local name = title
        
     --   name  = string.gsub(name, ' ', '%%20')
    TV_URL1 = 'http://epg.one/epg.xml.gz'
     
   --  TV_URL1 = 'http://www.teleguide.info/download/new3/jtv.zip'
     
            local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(title)
		table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. idc .. '&id1=' .. idk, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})
	
	

		end
  


	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
		
		local url = 'https://proxy4.rte.net.ru/http://live.guljaj.com/user/cab.php'


local params = 'user=1133'

  --  ["Host"] = "live.guljaj.com",

local headers = {

    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Content-Length"] = "",
    ["Origin"] = "http://live.guljaj.com",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://live.guljaj.com/user/cab.php",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; _ym_isad=2; mdd=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788619898%2C665940000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol-4PfTMYrAajF6CABHh5l2wmkMmQ-od0foZfHbe59lkNurTlDMXknCptH1cCDbvi-k2ZoW0_gz00YliZBM871QeYPAKM0FcmoiXdNuBF6HEwFQVFvqKZIbxSGQ6h89xd_hzTiexca8MQqXSm0bnvJFIG4cpeg%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
}


 local x = http.postz(url, headers, params)
     	
		
	for title, idc in string.gmatch(x, 'window.document.fidc.-return false.->(.-)</a>.-name=user.-<input type=hidden value=(.-)name=idc') do


--TV_URL1 = 'http://www.teleguide.info/download/new3/jtv.zip'

local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(title)

   table.insert(t, {title = title, mrl = '#stream/genre=' .. idc, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})

end



elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
     local url = 'https://proxy4.rte.net.ru/http://live.guljaj.com/user/cab.php'
     
      	local params = 'sea=' .. urlencode(args.keyword) .. '&user=1133'

 --   ["Host"] = "live.guljaj.com",


local headers = {

    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Content-Length"] = "",
    ["Origin"] = "http://live.guljaj.com",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://live.guljaj.com/user/cab.php",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; _ym_isad=2; mdd=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788619898%2C665940000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; FCNEC=%5B%5B%22AKsRol-4PfTMYrAajF6CABHh5l2wmkMmQ-od0foZfHbe59lkNurTlDMXknCptH1cCDbvi-k2ZoW0_gz00YliZBM871QeYPAKM0FcmoiXdNuBF6HEwFQVFvqKZIbxSGQ6h89xd_hzTiexca8MQqXSm0bnvJFIG4cpeg%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
}


 local x = http.postz(url, headers, params)
     	
     	for title, idk, idc in string.gmatch(x, 'window.document.fidk.-return false.->(.-)</a>.-name=user.-<input type=hidden value=(.-)name=idk.-<input type=hidden value=(.-)name=idc') do
	
	
          
            local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(title)


			table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. idc .. '&id1=' .. idk, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})
			
	
		end
  

		
		elseif args.q == 'channel' then
 
 local page = tonumber(args.page or '1')
    
local offset = (page - 1) * 6 + 1
		
		for i = 1, 6 do
    
		
 local url = 'https://proxy4.rte.net.ru/http://guljaj.com/live/ru/?id=' .. args.id1 .. '&st=' .. tostring(offset + i - 1) .. '#goog_fullscreen_ad'
 
 --   ["Host"] = "guljaj.com",

local headers = {

    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Connection"] = "keep-alive",
    ["Referer"] = "http://guljaj.com/live/ru/",
    ["Cookie"] = "_ym_uid=1788532525241881385; _ym_d=1788532525; _ym_isad=2; mdd=0; FCCDCF=%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C%5B%5B32%2C%22%5B%5C%2242fb51f0-2076-4bbc-abd8-b39e4af6f45c%5C%22%2C%5B1788532735%2C302000000%5D%5D%22%5D%5D%5D; FCOEC=%5B%5B%5B28%2C%22%5B%5B%5B%5B1%2Cnull%2C%5B1788620346%2C241851000%5D%2C10%5D%5D%5D%2C%5Bnull%2C1%2C%5B1788532734%2C263659000%5D%2C0%5D%5D%22%5D%5D%5D; videos; FCNEC=%5B%5B%22AKsRol9KO22ZkG4zmQJgY8wwEmA0ZWHZXgx50IhPEXSlrpR0xZyxWImrfz6_UDtb_6_HlTbLY0wsSKOe1SnpmmrsqPVU4raPxJBNDs1zcg1czuLROQ5Q-fLQnmIt-gBXfpAhO4rNbE2_llMT_9eVZ2chE24JPlSYAg%3D%3D%22%5D%5D",
    ["Upgrade-Insecure-Requests"] = "1"
}


 
 local x = http.getz(url, headers)
 

--local video = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
 
-- video = video
 
 if i == 1 then
 
 local video1 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
 
 
 --local video1 = video
 
 return {view = 'playback', mrl = video1, seekable = 'true', direct = 'true'}	
  
 end   

if not open(video1) then
    if i == 2 then
 
local video2 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
 
 
 --local video2 = video
 
 return {view = 'playback', mrl = video2, seekable = 'true', direct = 'true'}	
  
 end   
end

if not open(video2) then
    if i == 3 then
 
 local video3 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
 
 return {view = 'playback', mrl = video3, seekable = 'true', direct = 'true'}	
  
 end   
end


if not open(video3) then
    if i == 4 then
 
 local video4 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
 
 return {view = 'playback', mrl = video4, seekable = 'true', direct = 'true'}	
  
 end   
end


if not open(video4) then
    if i == 5 then
 
 local video5 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
 
 return {view = 'playback', mrl = video5, seekable = 'true', direct = 'true'}	
  
 end   
end


if not open(video) then
    if i == 6 then
 
 local video6 = string.match(x, 'Playerjs.-file:.-(http.-m3u8)"')
 
 return {view = 'playback', mrl = video6, seekable = 'true', direct = 'true'}	
  
 end   
end




end


 
		
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end