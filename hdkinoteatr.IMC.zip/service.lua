-- hdkinoteatr plugin
-- © 2020

require('video')
require('parser')
require('support')
require('debug')
require('client')


local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH




HOME = 'http://www.hdkinoteatr.com'

function onLoad()
	print('Hello from hdkinoteatr plugin')
	return 1
end

function onUnLoad()
	print('Bye from hdkinoteatr plugin')
end

function onCreate(args)
	local t = {view='grid_poster',type='folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	    table.insert(t['menu'],{title='@string/search',mrl='#folder/q=search',image='#self/search.png'})
	    
    -- #stream/url=/series/
    -- #stream/url=/concert/
    -- #stream/url=/tv/
    -- #stream/url=/documentary/
    -- #stream/url=/year/2020/
    -- #stream/url=
    -- #stream/url=
    -- #stream/url=
    -- #stream/url=
        
        
	if not args.q then
		local page = tonumber(args.page or '1')
		local genre = args.genre or ''
	
      local url = HOME .. genre
		if page > 1 then
			url = url .. '/page/' .. tostring(page) .. '/'
		end
		
	
	
	
	--	local offset = (page - 1) * 3 + 1
	--	for  i= 1, 1 do
		  
		  local x = http.get(url)
		  
	--	  HOME .. '/' .. genre .. '/page/' .. tostring(offset + i - 1) .. '/')

	for image, name, url  in string.gmatch(x, '<div class="base shortstory".-<img src="(.-)".-alt="(.-)".-href="(.-)".-title="(.-)"') do
				if not string.find(image, '://') then
					image = HOME .. image
				end
				table.insert(t, {title = tolazy(name), mrl = '#stream/q=content&id=' .. url, image = image})
			end
	--	end
		

 --.. '&offset=' .. image
		
	
	
    
     for total, url, image, name  in string.gmatch(x, '<td class="nr".-<span>(.-)</span></td><td><a href="(/.-html)" data%-img="(/uploads/posts/.-)">(.-)</a>') do

	if not string.find(image, '://') then
					image = HOME .. image
				end
		
	--	t['view'] = 'simple'
				table.insert(t, {title = total .. tolazy(name), mrl = '#stream/q=content&id=' .. url, image = image})
			end



	
    for image, url, name  in string.gmatch(x, '<td class="nr".-class="topimg".-<img src="(/uploads/people.-)".-<a href="http.-(/people.-)">(.-)</a>') do
	if not string.find(image, '://') then
					image = HOME .. image
				end
				table.insert(t, {title = tolazy(name), mrl = '#stream/genre=' .. url, image = image})
			end
	
	

	
	
      for image, url, name  in string.gmatch(x, '<div id=".-class="listBox".-<img src="(/uploads/posts/.-)".-class="listInfo".-<a href="(/list.-)">(.-)</a>') do
	if not string.find(image, '://') then
					image = HOME .. image
				end
				table.insert(t, {title = tolazy(name), mrl = '#stream/genre=' .. url, image = image})
			end
	
	
	
	
	
	
      for image, url, name  in string.gmatch(x, '<div id="list.-class="base shortstory listItem".-<img src="(/uploads/posts/.-)".-class="btl".-<a href="(.-)".->(.-)</a>') do
	if not string.find(image, '://') then
					image = HOME .. image
				end
	
	table.insert(t, {title = tolazy(name), mrl = '#stream/q=content&id=' .. url, image = image})
			end
	
		
         table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre, image = '#self/next.png'})
		
	--local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		--table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	elseif args.q == 'genres' then
		t['view'] = 'simple'
		
  --  http://www.hdkinoteatr.com/lists/
    table.insert(t, {title = 'Коллекции пользователей', mrl = '#stream/genre=' .. '/lists/'})
    
local x = http.get(HOME .. '/top/')
    local x = string.match(x, '<ul class="btns">(.-)</ul>')
       for genre, title in string.gmatch(x, '<a href="http://.-(/.-)".->(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
		

    
        
      --  local x = http.get(HOME .. '/')
local x = http.get(HOME .. '/')
local x = string.match(x, '<ul class="cats">(.-)</ul>')
       
        for id, title in string.gmatch(x, '<li><a href="(.-)">(.-)</a></li>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. id})
		end
		
		
		
--template="http://www.hdkinoteatr.com/index.php?story=Чужой&do=search&subaction=search&page=2
		
		
   elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)


		local x = http.get(url)
		
        for image, name, url  in string.gmatch(x, '<div class="base shortstory".-<img src="(.-)".-alt="(.-)".-href="(.-)".-title="(.-)"') do
				if not string.find(image, '://') then
					image = HOME .. image
				end
				table.insert(t, {title = tolazy(name), mrl = '#stream/q=content&id=' .. url, image = image})
			end
			
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})


	elseif args.q == 'video' then
		local url = args.url
		if string.find(url, 'www%.hdkinoteatr%.com') then
		      local x = http.get(args.id)
		    --local x = (HOME .. '/')
		    --local x = http_get(url) 
            local url = string.match(x, 'onload="(.-)".-src="(.-)"') do
			--local url = string.match(x, '<iframe.-src="(.-)"')
			end
			return {view = 'playback',label = args.t, mrl = url, seekable='true', direct='true'}
		end
	    return video(url, args)
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		print(args.id)
		if not string.find(args.id, '://') then
			args.id = HOME .. args.id
		end
    	local x = http.get(args.id)
    --    x = string.gsub(x, 'смотреть онлайн', '')
		--x = string.gsub(x, '<a href="#".-title="(.-)".-class="(.-)".-onclick="(.-)">(.-)</a>','')
		t['description'] = parse_match(x, '<div id=.-class="descr".->(.-)</div>')
			t['poster'] = args.p
	    	t['annotation'] = parse_array(x, {
			
			'(Год:</span>.-)</div>',
			'(Страна:</span>.-)</div>',
			'(Жанр:</span>.-)</div>',
			'(В ролях:</span>.-)</div>'})



			
			


		
	--	t['ref'] = HOME .. args.id
--		local titles = {youtube = '@string/trailer'}
	for url in string.gmatch(x, '<div id="trailer".-<iframe src="(.-)"') do
			if url ~= '' then
				table.insert(t, {title = 'Трейлер', mrl = url})
			end
		end
       --   local x = http.get(args.id)



       for title3 in string.gmatch(x, 'kinopoiskID: "(.-)"') do


url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/lumex?kinopoisk_id=') 
       --.. '&uid=m7alois3'
 
   table.insert(t, {title = 'Lumex', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
    --     end
   -- local x = conn:load(url1)
    
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
--http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=1061474&media_type=movie&u=%2Fvalidate%2FU2FsdGVkX1-bPecpuQMSh2eM4B1rRVagE81Gnxd5gDRlNKfUdFB0vhH85e0EzwET898befa2vqwUJ89hdyvbV6oIlXyB0EoB7syF76X-YWQVvLSPD_bmkSxNyICq0hF_uxKumUKTKe2ZzKgr9bnP_mbdr4UW_4IXnq6DhQMQgMNSIv_6ph8vncdCxeTlbGEmrQq04nBq3q0NFyxYzRuLGkUXvODDDKDtIE7dohoYwOr4sAbK5-5yHWKHn2gXyuUAcYoJojhNBcQf42MepA65Ng&varip=45.155.7.202&h=https://p.lumex.space
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
  
 -- table.insert(t, {title = url2, mrl = url2})
     
      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '1080/index')
      url3 = string.gsub(url3, '360.mp4', '1080.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(1080p)lumex :' .. tolazy(total), mrl = url3})
       
    end

    local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '3600/index', '720/index')
      url3 = string.gsub(url3, '360.mp4', '720.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(720p)lumex :' .. tolazy(total), mrl = url3})
       
    end

      local x = conn:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '360/index', '480/index')
      url3 = string.gsub(url3, '360.mp4', '480.mp4')
 url3 = string.gsub(url3, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

  table.insert(t, {title = '(480p)lumex :' .. tolazy(total), mrl = url3})
       
    end
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://178.20.46.40:12600')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://178.20.46.40:12600')
    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.155.7.202&h=https://p.lumex.space'
    
     local x = conn:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"http.-(http.-mp4)') do
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '360/index', '720/index')
      url5 = string.gsub(url5, '360.mp4', '720.mp4')
 url5 = string.gsub(url5, '^(.-)', 'http://45.155.7.202/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url5})

       
    end
end
end
end





	    	for title3 in string.gmatch(x, 'kinopoiskID: "(.-)"') do

url1 = string.gsub(title3, '^(.-)', 'https://lampa.denello.ru/lite/videodb?kinopoisk_id=')
     table.insert(t, {title = 'Videodb', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
    
    --  local x = conn:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":"(http.-videodb)(.-)".-class="videos__item%-title">(.-)<') do
 

      t['view'] = 'simple'
    

 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
   --  url2 = string.gsub(url2, '^(.-)', 'https://lampa.ds220kirill.synology.me') 
       local x = conn:load(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"(http.-)".->(.-)</div>') do

   --   url3 = string.gsub(url3, '^(.-)', 'https://lampa.ds220kirill.synology.me') 
       local x = conn:load(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'https://lampa.denello.ru')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
    

		




      for title3 in string.gmatch(x, 'kinopoiskID: "(.-)"') do

    url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
      local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end
    end



       for title3 in string.gmatch(x, 'kinopoiskID: "(.-)"') do

     url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
   --    t['view'] = 'simple'
				table.insert(t,{title= tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      



     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
 --     t['view'] = 'simple'
				table.insert(t,{title= tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end
       end  
         
         


	for title, total in string.gmatch(x, '<meta property="og:title" content="(.-)%((.-)%)') do
 
      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      


     url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    
     
  --  table.insert(t, {title = 'Torrs', mrl = '#stream/q=content&id=' .. url, image = image})
       --  end
      
         
--local x = conn:load(args.id)

     local x = http.getz(url)

        for total in string.gmatch(x,'%[{"size.-trackerName.-kinozal.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        

       url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      

        local x = http.getz(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     --    t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
       --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
       -- t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	


     local x = http.getz(url)
     
      for total in string.gmatch(x,'%[{"size.-trackerName.-nnmclub.-magnet:?.-btih:(.-)"') do
        total = total:lower()
        
      url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      

        local x = http.getz(url1)

  
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     
   --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
      --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url2  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
      --  t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url2, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end	
    end
		
		
	elseif args.q == 'video' then
		return {{title = args.t, mrl = args.url}}
	elseif args.q == 'play' then
		return video(args.url, args)
	end
	return t
end
--debug_print({})