-- video.az plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://video.az'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH


--HOME = 'https://kino.video.az'

--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from video.az plugin')
	return 1
end

function onUnLoad()
	print('Bye from video.az plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/movie/lang/ru'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
	--	local x = http.getz(url)
         local x = conn:load(url)
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for url, title, image in string.gmatch(x, '<div class="item.-class="pd.-<a href="(.-)".-<h1.->(.-)</h1.-src=.-(//cdn.-jpg)') do
          
--<div class="list-1 ias_item"> <div class="item.-class="pd.-<a href="(.-)".-<h1.->(.-)</h1>

--</a> </div> <div class="row-eq-height"> <div class="col-1"> <a href="https://video.az/movie/nasha-rasplata-the-price-we-pay-2022-hdrip-20112"><img

   
      --  url = string.gsub(url, '^(.-)', HOME)
      

      
        image = string.gsub(image, '^(.-)','https:')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = conn:load(HOME .. '/movie')
		
   --     x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, 'Настройки(.-)IMDB')
		for genre, title, total in string.gmatch(x, '<li.-<a href=".-//.-(/.-)"->(.-)</li>') do
			table.insert(t, {title = tolazy(title), mrl = '#folder/genre=' .. genre})
		end
        
        
	--		table.insert(t, {title = 'Сериалы', mrl = '#folder/genre=' .. '/tvseries'})
		
        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<p>(.-)</p>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</dt>.-)</dd>', '(Страна:</dt>.-)</dd>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В главных ролях</dt>.-)</dd>'
		})
	

	
		
--content="https://cdn10.video.az/storage/movie/20/20121/thumb.jpg">

----//cdn6.video.az/storage/movie/20/20119/video.mp4"
        for url in string.gmatch(x, '<meta property="og:image" content="(http.-)"') do
		
         print(url)
		 url = string.gsub(url, 'thumb.jpg', 'video.mp4')

       table.insert(t, {title = 'Смотреть', mrl = url})
		end

   --  for url, title in string.gmatch(x, '<p>.-href="(.-)".->(.-)</a>') do

    --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
	--	end
		
		
   --    for url, title in string.gmatch(x, 'href="(https://video.az/tvseries.-)".->(.-)<') do

  --      table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
--		end




	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end