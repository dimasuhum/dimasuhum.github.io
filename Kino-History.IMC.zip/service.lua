-- Kino-History plugin

require('support')
require('video')
require('parser')

HOME = 'https://kino-history.net'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kino-history.net plugin')
	return 1
end

function onUnLoad()
	print('Bye from kino-history.net plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	--table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/filmy-pro-18-19-vek? page
	-- #stream/genre=/tureckie-istoricheskie?page
	-- #stream/genre=/filmy-pro-drevnjuju-greciju?page 


	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '?'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page' .. tostring(page)
		end
		local x = http.getz(url)
		for url, image, title in string.gmatch(x, '<div class="kartochka".-href="(.-)".-src="(.-)".-title="(.-)"') do
			image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
        local x = http.getz(HOME)
        

        
        local x = string.match(x, '<div class="top_menu".->Главная.->(.-)<li class="other%-groop"')
		for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
        
        
		

	-- #stream/q=content&id=/dvenadzatuy-chelovek-2017
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(HOME .. args.id)
		--print(x)
		t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'fullstory%-title.->(.-)<div class')
		t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(Качество:</div>.-)</div>','(Жанры:</div>.-)</div>', '(Страна:</div>.-)</div>', '(Год:</div>.-)</div>', '(Режиссер:</div>.-)</div>',
			'(Время:</div>.-)</div>', '(Перевод:</div>.-)<br', "actors = '(.-)'"
		})
    --elseif args.q == 'play' then
      -- local x = http.getz(args.url)
      -- x = string.gsub(x, '<li>Плеер 2</li><a href="(.-)"','') 
      -- local x = string.match(x, '<div class="player%-drop visible full%-text">(.-)</div>')
		for url in string.gmatch(x, '<iframe.-src="(.-)"') do
       -- print(url)

     --  addvideo(t, url, t['name'])

			table.insert(t, {title = '@string/watch', mrl = url})
		end
	elseif args.q == 'play' then
        
        --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)
	--end
	end
	return t
end