-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate



local HOME = 'https://api-web-systema.platform24.tv'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH





function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)




	local t = {view = 'grid', type = 'folder'}
		t['menu'] = {}
	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

--table.insert(t['menu'], {title = 'Поиск тв', mrl = '#folder/q=search', image = '#self/search.png'})

--https://varline.store/api/matchlist?is_complete=false&skip=0&limit=100


	if not args.q then




--https://api-web-systema.platform24.tv/v2/auth/device




local headers = {
["Host"] = "api-web-systema.platform24.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
["Accept"] = "application/json, text/plain, */*",
["Accept-Language"] = "ru-ru",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-Type"] = "application/json",
["Content-Length"] = "52",
["Origin"] = "https://tv.cyxym.net",
["Connection"] = "keep-alive",
["Referer"] = "https://tv.cyxym.net/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site"
}

local params = '{"device_id":"c99fe352-7718-4879-b92a-c6e3f61c9ccd"}'


--https://1.mediamaniya.site/tv/?page6

   local url = HOME .. '/v2/auth/device'

        local x = http.postz(url, headers, params)

      local token = string.match(x, '"access_token":"(.-)"')

	if token then


--https://api-web-systema.platform24.tv/v2/channels/channel_list?access_token=fb3590cbcd5cd28f2a57b778bdc18560b8d12f16&channels_version=2

--local x = conn:load(HOME .. '/v2/channels/channel_list?access_token=' .. token .. '&channels_version=2&format=json&includes=current_schedules')

local x = conn:load(HOME .. '/v2/channels?access_token=' .. token .. '&channels_version=2&format=json')


table.insert(t, {title = 'Поиск тв', mrl = '#stream/q=search&id1=' .. token,  image = '#self/search.png'})

	
    for name, slug, id, image in string.gmatch(x, '{"id":.-"name":"(.-)".-"slug":"(.-)".-"num":(.-),.-"cover".-"full":"(http.-)"') do

--   id  = string.gsub(id, '^(.-)', HOME)
--	image  = string.gsub(image, '^(.-)', HOME)
   
    --    t['view'] = 'simple'
	
	table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. id .. '&id1=' .. token, image = image})

end
end




	
	
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 


--https://api-web-systema.platform24.tv/v2/channels/category_list?access_token=3daf31124d35f6c5f1e7581ca0ad3f11d940a357&channels_version=2
 
 
-- table.insert(t, {title = 'Общие', mrl = '#stream/q=channels&id=' .. 'Общие', image = image})
 
 
 
table.insert(t, {title = 'Кино', mrl = '#stream/q=channels&id=' .. 'кино', image = image})

table.insert(t, {title = 'Спорт', mrl = '#stream/q=channels&id=' .. 'спорт', image = image})

table.insert(t, {title = 'Познавательные', mrl = '#stream/q=channels&id=' .. 'познавательные', image = image})

table.insert(t, {title = 'Развлекательные', mrl = '#stream/q=channels&id=' .. 'развлекательные', image = image})

table.insert(t, {title = 'Музыка', mrl = '#stream/q=channels&id=' .. 'музыка', image = image})

table.insert(t, {title = 'Детские', mrl = '#stream/q=channels&id=' .. 'детские', image = image})

table.insert(t, {title = 'Новости', mrl = '#stream/q=channels&id=' .. 'новости', image = image})

table.insert(t, {title = 'Россия', mrl = '#stream/q=channels&id=' .. 'россия', image = image})

table.insert(t, {title = 'Украина', mrl = '#stream/q=channels&id=' .. 'українські', image = image})

table.insert(t, {title = 'Беларусь', mrl = '#stream/q=channels&id=' .. 'беларускія', image = image})

table.insert(t, {title = 'HD', mrl = '#stream/q=channels&id=' .. 'HD', image = image})


table.insert(t, {title = 'HD Orig', mrl = '#stream/q=channels&id=' .. 'HD Orig', image = image})

--table.insert(t, {title = 'UHD', mrl = '#stream/q=channels&id=' .. 'UHD', image = image})

table.insert(t, {title = '4K', mrl = '#stream/q=channels&id=' .. '4K', image = image})

table.insert(t, {title = 'Другие', mrl = '#stream/q=channels&id=' .. 'другие', image = image})

table.insert(t, {title = 'Взрослые', mrl = '#stream/q=channels&id=' .. 'взрослые', image = image})

  
  
  
  
  elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
--https://api-web-systema.platform24.tv/v2/rows/1154861723526252842?offset=0&limit=50&channels_version=2&access_token=5dd5686b588774b7976cac5d14ebdab9dc573eed&text=Матч
     
    
    local headers = {
["Host"] = "api-web-systema.platform24.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
["Accept"] = "application/json, text/plain, */*",
["Accept-Language"] = "ru-ru",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-Type"] = "application/json",
["Content-Length"] = "52",
["Origin"] = "https://tv.cyxym.net",
["Connection"] = "keep-alive",
["Referer"] = "https://tv.cyxym.net/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site"
}

local params = '{"device_id":"c99fe352-7718-4879-b92a-c6e3f61c9ccd"}'


--https://1.mediamaniya.site/tv/?page6

--   local url = HOME .. '/v2/auth/device'

    --    local x = http.postz(url, headers, params)

   --   local token = string.match(x, '"access_token":"(.-)"')

--	if token then
    
    
    
    
      	local url = ('https://api-web-systema.platform24.tv/v2/rows/1154861723526252842?offset=0&limit=50&channels_version=2&access_token=' .. args.id1 .. '&format=json&text=' .. urlencode(args.keyword))
	
		local x = conn:load(url)
  
  
 local channel = string.match(x,'"channels":%[(.-)]}')
  
  for id, name, slug, image in string.gmatch(channel,'{"id":(.-),"name":"(.-)","slug":"(.-)".-"cover".-"full":"(http.-)"') do
  
  table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. id .. '&id1=' .. args.id1, image = image})
  
  end
--end  
  
  
    elseif args.q == 'channels' then

--local url = 'https://tv.alcopa.cc' .. args.id

 local url = 'https://tv.alcopa.cc/api/iptv/channels?playlist_id=all&group=' .. urlencode(args.id) .. '&page=1&limit=100000'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; alpac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; _lampac_auth=a46f8a8a-8878-4fa5-8554-8296ba62260d; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}

		local x = http.getz(url, headers)


--local x = json.decode(x)

	--	for _, v in ipairs(x['channels']) do
	
	for id, name, image in string.gmatch(x,'{"id":"(.-)","name":"(.-)".-"logo":"(.-)"') do
	--		local x = json.decode(x)

--		for _, v in ipairs(x['channels']) do
			local url1 = 'https://tv.alcopa.cc/api/iptv/play?channel_id=' .. id
	
	--t['view'] = 'simple'
	
	table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. url1, image = image})

end





elseif args.q == 'channel' then

--https://api-web-systema.platform24.tv/v2/channels/3963/stream?access_token=c80427ce3c71e33267d212856c5e6650934291d7&force_https=true&format=json&preview=true



     local x = conn:load('https://api-web-systema.platform24.tv/v2/channels/' .. args.id .. '/stream?access_token=' .. args.id1 .. '&force_https=true&format=json&preview=true')
 
-- table.insert(t, {title = 'https://api-web-systema.platform24.tv/v2/channels/' .. args.id .. '/stream?access_token=' .. args.id1 .. '&force_https=true&preview=true', mrl = '#stream/q=channel&id=' .. 'https://api-web-systema.platform24.tv/v2/channels/' .. args.id .. '/stream?access_token=' .. args.id1 .. '&force_https=true&format=json&preview=true', image = image})


 
 
 
  local url = string.match(x,'"hls":"(.-)"')   
  if url then

--table.insert(t, {title = url, mrl = '#stream/q=channel&id=' .. url, image = image})


  --    if url2 then
--    print(url2)
    return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}
    
end




	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
--end
	end
	return t
end