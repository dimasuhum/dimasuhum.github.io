-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate



local HOME = 'https://api-web-systema.platform24.tv'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH





function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)




	local t = {view = 'grid', type = 'folder'}
		t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

--table.insert(t['menu'], {title = 'Поиск тв', mrl = '#folder/q=search', image = '#self/search.png'})

--https://varline.store/api/matchlist?is_complete=false&skip=0&limit=100


	if not args.q then




--https://api-web-systema.platform24.tv/v2/auth/device




local headers = {
["Host"] = "api-web-systema.platform24.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
["Accept"] = "application/json, text/plain, */*",
["Accept-Language"] = "ru-ru",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-Type"] = "application/json",
["Content-Length"] = "52",
["Origin"] = "https://tv.cyxym.net",
["Connection"] = "keep-alive",
["Referer"] = "https://tv.cyxym.net/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site"
}

local params = '{"device_id":"c99fe352-7718-4879-b92a-c6e3f61c9ccd"}'


--https://1.mediamaniya.site/tv/?page6

   local url = HOME .. '/v2/auth/device'

        local x = http.postz(url, headers, params)

      local token = string.match(x, '"access_token":"(.-)"')

	if token then


--https://api-web-systema.platform24.tv/v2/channels/channel_list?access_token=fb3590cbcd5cd28f2a57b778bdc18560b8d12f16&channels_version=2

--local x = conn:load(HOME .. '/v2/channels/channel_list?access_token=' .. token .. '&channels_version=2&format=json&includes=current_schedules')

local x = conn:load(HOME .. '/v2/channels?access_token=' .. token .. '&channels_version=2&format=json')


--table.insert(t, {title = 'Поиск тв', mrl = '#stream/q=search&id1=' .. token,  image = '#self/search.png'})

	
    for name, slug, id, image in string.gmatch(x, '{"id":.-"name":"(.-)".-"slug":"(.-)".-"num":(.-),.-"cover".-"full":"(http.-)"') do

--local x = conn:load('https://api-web-systema.platform24.tv/v2/channels/' .. id .. '/stream?access_token=' .. token .. '&force_https=true&format=json&preview=true')
 

 -- local url = string.match(x,'"hls":"(.-)"')   
--  if url then
   
    --    t['view'] = 'simple'
	
--	table.insert(t, {title = name, mrl = url, image = image})
	
	table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. id .. '&id1=' .. token, image = image})

end
end
--end



	
	
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 


--https://api-web-systema.platform24.tv/v2/channels/category_list?access_token=3daf31124d35f6c5f1e7581ca0ad3f11d940a357&channels_version=2
 
 
 table.insert(t, {title = 'Kinowalk', mrl = '#stream/q=kinowalk', image = image})
 
 
 
table.insert(t, {title = 'Кинозал', mrl = '#stream/q=kinozal', image = image})

--table.insert(t, {title = 'strashnoehd', mrl = '#stream/q=strashnoehd', image = image})


elseif args.q == 'strashnoehd' then



local url = 'https://strashnoehd.ru'




local headers = {
    ["Host"] = "strashnoehd.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://strashnoehd.ru/",
    ["Cookie"] = "_ym_uid=1789015191575121866; _ym_d=1789015191; _ym_isad=2; mdd=0",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}


 
 local x = http.getz(url, headers)

for name, id, logo in string.gmatch(x, '<tbody><tr><td>(.-)</td>.-class="separ".-<a href="/id(.-)".-<img src="(.-)"') do

logo = string.gsub(logo, '^(.-)', 'https://strashnoehd.ru')



table.insert(t, {title = name, mrl = '#stream/q=strax&id=' .. id, image = logo})

end

  
  elseif args.q == 'strax' then

local stream = 'https://strashnoehd.ru/stream?id=' .. args.id .. '&aspect=&width=&height='


local headers1 = {
    ["Host"] = "strashnoehd.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://strashnoehd.ru/id" .. args.id,
    ["Cookie"] = "_ym_uid=1789015191575121866; _ym_d=1789015191; _ym_isad=2; mdd=0",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}


local x = http.getz(stream, headers1)

local play = string.match(x, 'Playerjs.-file.-(http.-)"')

if play then


t = {}
table.insert(t, {mrl = play, image = logo})
  
  end
  
  
  
  elseif args.q == 'kinowalk' then

local page = tonumber(args.page or '1')
    
local offset = (page - 1) * 15 + 1
		
		for i = 1, 15 do

 local url = 'https://kinowalk.hopto.org/stream-channels' .. '?page=' .. tostring(offset + i - 1) 
 
 
 
 local x = http.get(url)


for logo, name, url in string.gmatch(x, '<div class="card".-<img.-src="(http.-)".-class="channel%-name">(.-)</strong>.-class="url%-text".-(http.-)<') do

logo = string.gsub(logo, 'amp;', '')


table.insert(t, {title = tolazy(name), mrl = url, image = logo})
          
end
end


elseif args.q == 'kinozal' then


local url = 'https://smotret-online.tv/kinozals.html'

local x = http.get(url)

for name, url1, logo  in string.gmatch(x, '<div class="tv%-schedule" data%-channel%-id="(.-)" data%-link="(http.-)".-logo="(.-)"') do

local x = http.get(url1)

local iframe, channels = string.match(x, '<iframe.-src="(http.-)".-<div id="channelData"(.-)</div>')


local logos, title = string.match(channels, 'data%-logo="(.-png).-data%-id="(.-)"')

table.insert(t, {title = tolazy(title), mrl = '#stream/q=smo&id=' .. iframe, image = logo})
          
end
  
  
  
  
  elseif args.q == 'smo' then



local url = args.id



local headers = {
    ["Host"] = "cdntvmedia.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
  ["Referer"] = "https://smotret-online.tv/",

    ["Sec-Fetch-Storage-Access"] = "none",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Priority"] = "u=4"
}

 
 local x = http.getz(url, headers)

--table.insert(t, {title = x, mrl = x, image = logo})


local iframes = string.match(x, '<iframe src="http.-file=(http.-m3u8)')

if iframes then

t = {}
table.insert(t, {mrl = iframes, image = logo})

end

if not iframes then


local iframeok = string.match(x, '<iframe.-"(https://ok.ru.-)"')

 if iframeok then

 local headersok = {
    ["Host"] = "ok.ru",
    ["User-Agent"] = "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.50 Mobile Safari/537.36"
}
   
   local v = http.getz(iframeok, headersok)
   
local file = string.match(v,'hlsMaster.-(http.-)"')

if file then

t = {}
table.insert(t, {mrl = file, image = logo})

end
end



local iframe = string.match(x, '<iframe src="(http.-)"')

if iframe then



local headers1 = {
    ["Host"] = "cdntvmedia.com",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:155.0) Gecko/20100101 Firefox/155.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  ["Referer"] = args.id,
["Sec-Fetch-Storage-Access"] = "none",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}



 local x = http.getz(iframe, headers1)





x = string.gsub(x, '\\', '')

local play = string.match(x, 'var generatedFile.-"(http.-)or')

if play then


t = {}
table.insert(t, {mrl =  play, image = logo})

end
end
end
  
  
  
  
  
  elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
--https://api-web-systema.platform24.tv/v2/rows/1154861723526252842?offset=0&limit=50&channels_version=2&access_token=5dd5686b588774b7976cac5d14ebdab9dc573eed&text=Матч
     
    
    local headers = {
["Host"] = "api-web-systema.platform24.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
["Accept"] = "application/json, text/plain, */*",
["Accept-Language"] = "ru-ru",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-Type"] = "application/json",
["Content-Length"] = "52",
["Origin"] = "https://tv.cyxym.net",
["Connection"] = "keep-alive",
["Referer"] = "https://tv.cyxym.net/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site"
}

local params = '{"device_id":"c99fe352-7718-4879-b92a-c6e3f61c9ccd"}'


--https://1.mediamaniya.site/tv/?page6

--   local url = HOME .. '/v2/auth/device'

    --    local x = http.postz(url, headers, params)

   --   local token = string.match(x, '"access_token":"(.-)"')

--	if token then
    
    
    
    
      	local url = ('https://api-web-systema.platform24.tv/v2/rows/1154861723526252842?offset=0&limit=50&channels_version=2&access_token=' .. args.id1 .. '&format=json&text=' .. urlencode(args.keyword))
	
		local x = conn:load(url)
  
  
 local channel = string.match(x,'"channels":%[(.-)]}')
  
  for id, name, slug, image in string.gmatch(channel,'{"id":(.-),"name":"(.-)","slug":"(.-)".-"cover".-"full":"(http.-)"') do
  
  table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. id .. '&id1=' .. args.id1, image = image})
  
  end
--end  
  
  
    elseif args.q == 'channels' then

--local url = 'https://tv.alcopa.cc' .. args.id

 local url = 'https://tv.alcopa.cc/api/iptv/channels?playlist_id=all&group=' .. urlencode(args.id) .. '&page=1&limit=100000'


local headers = {
    ["Host"] = "tv.alcopa.cc",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "*/*",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=1780394535529199003; _ym_d=1780394535; lampac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; alpac_token=a46f8a8a-8878-4fa5-8554-8296ba62260d; _lampac_auth=a46f8a8a-8878-4fa5-8554-8296ba62260d; _ym_isad=1; _ym_visorc=w",
    ["Sec-Fetch-Dest"] = "empty",
    ["Sec-Fetch-Mode"] = "cors",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Priority"] = "u=4"
}

		local x = http.getz(url, headers)


--local x = json.decode(x)

	--	for _, v in ipairs(x['channels']) do
	
	for id, name, image in string.gmatch(x,'{"id":"(.-)","name":"(.-)".-"logo":"(.-)"') do
	--		local x = json.decode(x)

--		for _, v in ipairs(x['channels']) do
			local url1 = 'https://tv.alcopa.cc/api/iptv/play?channel_id=' .. id
	
	--t['view'] = 'simple'
	
	table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. url1, image = image})

end





elseif args.q == 'channel' then

--https://api-web-systema.platform24.tv/v2/channels/3963/stream?access_token=c80427ce3c71e33267d212856c5e6650934291d7&force_https=true&format=json&preview=true



     local x = conn:load('https://api-web-systema.platform24.tv/v2/channels/' .. args.id .. '/stream?access_token=' .. args.id1 .. '&force_https=true&format=json&preview=true')
 
-- table.insert(t, {title = 'https://api-web-systema.platform24.tv/v2/channels/' .. args.id .. '/stream?access_token=' .. args.id1 .. '&force_https=true&preview=true', mrl = '#stream/q=channel&id=' .. 'https://api-web-systema.platform24.tv/v2/channels/' .. args.id .. '/stream?access_token=' .. args.id1 .. '&force_https=true&format=json&preview=true', image = image})


 
 
 
  local url = string.match(x,'"hls":"(.-)"')   
  if url then


t = {}
table.insert(t, {mrl = url, image = image})


  --    if url2 then
--    print(url2)
  --  return {view = 'playback', mrl = url, seekable = 'true', direct = 'true'}
    
end




	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
--end
	end
	return t
end