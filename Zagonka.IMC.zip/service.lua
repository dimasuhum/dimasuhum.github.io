-- zagonka.tv plugin

require('support')
require('video')
require('parser')
require('client')


--http://abc.zagonkop.gb.net/embed/kp-386


local HOME = 'http://abc.zagonkop.gb.net'

local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from zagonka.tv plugin')
	return 1
end

function onUnLoad()
	print('Bye from zagonka.tv plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=1	
	-- #stream/page=2

	if not args.q then
    -- 	local page = tonumber(conn:load(args.page or 1))


local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}



	local page = tonumber(args.page or 1)
	

		
	--	local genre = args.genre or '/populyarnoe.html'

    local genre = args.genre or '/filmy7/'
	


		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

        local x = http.getz(url, headers)
       --  local x = conn:load(url, headers)
     
     --   for title, image, url  in string.gmatch(x, '<div class="short".-<img.-alt=.-Смотреть(.-)онлайн.-(/uploads.-jpg).-href=.-(/.-.html)') do
	
	
	for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-html).->(.-)%((.-)%)') do
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
      --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 
 table.insert(t, {title = 'Популярные сегодня', mrl = '#stream/genre=' .. '/populyarnoe-onlayn.html'})
 
 
 table.insert(t, {title = 'Рейтинговые новинки', mrl = '#stream/genre=' .. '/rating-onlayn.html'})
 
 
-- table.insert(t, {title = 'поиск по словам', mrl = '#stream/q=searchn'})
 
 
table.insert(t, {title = 'поиск актеров', mrl = '#stream/q=searchp'})
 
    local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}
         local x = http.getz(HOME, headers)
      --  local x = conn:load(HOME)
		  local slist = string.match(x, 'Навигатор(.-)Жанры')
		
for genre, total in string.gmatch(slist, '<li data%-hrf="(.-)">(.-)</li>') do

table.insert(t, {title = total, mrl = '#stream/genre=' .. genre})

end

for genre, total in string.gmatch(slist, '<a id=".-href="(.-)">(.-)</a>') do

     table.insert(t, {title = total, mrl = '#stream/genre=' .. genre})
		
	
end


local x = http.getz(HOME, headers)
   
		 local slist = string.match(x, 'ТОП(.-)</ul>')

--for genre, total in string.gmatch(x,'<li data%-hrf="(/.-/(sort.-)">(.-)</li>'

for genre, total in string.gmatch(slist, '<.-hr.-="(/.-)">(.-)<') do


table.insert(t, {title = total, mrl = '#stream/genre=' .. genre})
		
	
end		






table.insert(t, {title = 'Фильмы по жанрам', mrl = '#stream/q=genrez&id=' .. '/filmy7/'})

table.insert(t, {title = 'Сериалы по жанрам', mrl = '#stream/q=genrez&id=' .. '/serialy2/'})

table.insert(t, {title = 'Мульфильмы по жанрам', mrl = '#stream/q=genrez&id=' .. '/multfilmy1/'})

table.insert(t, {title = 'Мульсериалы по жанрам', mrl = '#stream/q=genrez&id=' .. '/multserialy1/'})



        
        
        elseif args.q == 'genrez' then
	
	local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}
	local x = http.getz(HOME .. args.id, headers)
	
	for title, genre in string.gmatch(x, '<div class="dropdown%-toggle" data%-toggle="dropdown">(.-)<.-class="dropdown%-menu".-class="indx" href="/.-/(zhanr.-)"') do
	
	t['view'] = 'simple'
    
	table.insert(t, {title = title, mrl = '#stream/q=genrezg&id=' .. args.id .. '&id1=' .. genre})
		
	end

elseif args.q == 'genrezg' then
	
	local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}

local page = tonumber(args.page or 1)
	
local url = HOME .. args.id .. args.id1
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

	local x = http.getz(url, headers)

table.insert(t, {title = 'По году', mrl = '#stream/q=god&id=' .. args.id .. '&id1=' .. args.id1, image = '#self/setting.png'})
		



for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/q=genrezg&id=' .. args.id .. '&id1=' .. args.id1 .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})




elseif args.q == 'god' then

if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
 
local headers = {
		    ["host"] = "abc.zagonkop.gb.net",
       ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["X-Requested-With"] = "XMLHttpRequest",
       ["accept"] = "text/html, */*; q=0.01",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
["Priority"] = "u=0"
}	
	
			local page = tonumber(args.page or '1')
		
       local url = HOME .. args.id .. 'god-' .. args.keyword .. '/' .. args.id1

if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

	local x = http.getz(url, headers)


table.insert(t, {title = 'По году', mrl = '#stream/q=god&id=' .. args.id .. '&id1=' .. args.id1, image = '#self/setting.png'})
	

for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/q=god&id=' .. args.id .. '&id1=' .. args.id1 .. '&keyword=' .. args.keyword .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
	
	
	



--http://zagonka.tv/index.php?video=рокки&do=search&subaction=search

--http://abc.zagonkop.gb.net/engine/ajax/xsearch/web.php?action=countResult&searchCat=video&field[rol]=Сильвестр Сталлоне&do=xsearch&xscatnum=undefined
--http://abc.zagonkop.gb.net/video/rol-Sil*vestr_Stallone/

--http://abc.zagonkop.gb.net/engine/ajax/xsearch/web.php?action=countResult&searchCat=video&field[keywords]=Терминатор&do=xsearch&xscatnum=undefined
 
 
 

 
 
       elseif args.q == 'searchp' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
		


local headers = {
    ["Host"] = "abc.zagonkop.gb.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["referer"] = "http://abc.zagonkop.gb.net/",
        ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "dle_lang=ru; PHPSESSID=568279aa32e7f07bdb3541c624ce8e45",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}




args.keyword = string.gsub(args.keyword, ' ', '_')
		
		local page = tonumber(args.page or '1')
		
       local url = 'http://abc.zagonkop.gb.net/video/rol-' .. args.keyword .. '/'
       
       if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		
       local x = http.getz(url, headers)

for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
 
 local url = '#stream/q=searchp&keyword=' .. args.keyword .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
 
 
 
  
  elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		


local headers = {
    ["Host"] = "abc.zagonkop.gb.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Referer"] = "http://abc.zagonkop.gb.net/",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "dle_lang=ru; PHPSESSID=568279aa32e7f07bdb3541c624ce8e45",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	
		
		
		local page = tonumber(args.page or '1')
		
       local url = 'http://abc.zagonkop.gb.net/engine/ajax/xsearch/f.php?q=' .. urlencode(args.keyword)
       --.. '&page=' .. tostring(page)
	

    
		local x = http.getz(url, headers)
	
 
local x = json.decode(x)

		for _, v in ipairs(x) do
	
	local url = HOME .. v['url']
	
	
	t['view'] = 'simple'
	
	table.insert(t, {title = v['text'], mrl = '#stream/q=content&id=' .. url})

end




    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			      
        
        
	-- #stream/q=content&id=/film-zvyozdnye-vrata-1994-hd



elseif args.q == 'similar' then

local headers = {
    ["Host"] = "abc.zagonkop.gb.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Referer"] = args.id,
    ["Connection"] = "keep-alive",
    ["Cookie"] = "dle_lang=ru; PHPSESSID=568279aa32e7f07bdb3541c624ce8e45",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	
	
		
        local x = http.getz(args.id, headers)


local slist = string.match(x, 'class="scrlx"(.-)class="scrlx"')

for image, url, title, total in string.gmatch(slist, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end


elseif args.q == 'actor' then

local headers = {
    ["Host"] = "abc.zagonkop.gb.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Referer"] = args.id,
    ["Connection"] = "keep-alive",
    ["Cookie"] = "dle_lang=ru; PHPSESSID=568279aa32e7f07bdb3541c624ce8e45",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	
	
		
        local x = http.getz(args.id, headers)
        
 
 for url, title in string.gmatch(x, '<div data%-hrf="(/video/r.-)">(.-)</div>') do

t['view'] = 'simple'

  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url})
  
  end



	 
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	
	
	local headers = {
    ["Host"] = "abc.zagonkop.gb.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Referer"] = args.id,
    ["Connection"] = "keep-alive",
    ["Cookie"] = "dle_lang=ru; PHPSESSID=568279aa32e7f07bdb3541c624ce8e45",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	
		
		
		
        local x = http.getz(args.id, headers)
	--	local x = conn:load(args.id)
        --x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'(Описание:</b>.-)<br>')
        t['poster'] = args.p
		t['poster'] = parse_match(x,'"dateCreated".-"image":.-(http.-jpg)')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Жанр:</td>.-)</a>'
		})




       local ids = string.match(x, '<div id="down" data%-id="(.-)"') 

if ids then

 local kp = string.match(x, '<div id="down".-data%-kp="(.-)"')

if kp then
	
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=zagonka&id=' .. args.id .. '&id1=' .. ids .. '&id2=' .. kp})

		end
     end
  
  table.insert(t, {title = 'В ролях', mrl = '#stream/q=actor&id=' .. args.id})
  table.insert(t, {title = 'Похожее', mrl = '#stream/q=similar&id=' .. args.id})
     
        elseif args.q == 'zagonka' then
     
     
local url = 'http://abc.zagonkop.gb.net/embed/' .. args.id1


--http://abc.zagonkop.gb.net/embed/kp-5499518


local headers = {
    ["Host"] = "abc.zagonkop.gb.net",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate",
    ["Referer"] = args.id,
    ["Connection"] = "keep-alive",
    ["Cookie"] = "dle_lang=ru; PHPSESSID=568279aa32e7f07bdb3541c624ce8e45",
    ["X-Requested-With"] = "XMLHttpRequest",  
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	

local x = http.getz(url, headers)

x = string.gsub(x, 'ZYzNM', '')
        x = string.gsub(x, 'ZUzls', '')
x = string.gsub(x, 'ZUzVw', '')

x = string.gsub(x, 'ZUTB5', '')

x = string.gsub(x, 'ZaTdV', '')


local x = string.match(x, 'Playerjs%(\'#2(.-)\'%)+') 
   
  if x then      
    
    --ZYzNM
--ZUzls
--ZUzVw
--ZUTB5
--ZaTdV
    
    x = base64_decode(x)
     
 x = string.gsub(x, '{v1}', '.mp4')   
     

 
 --"title\":\"<div id=\'s_1_tr_Coldfilm_e_2_\'.-"file\":.-(//.-mp4)
 
 
 for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')
 
 
 
 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(1080p) ' .. tolazy(title) .. ' ' ..tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
  
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')




 url3 = string.gsub(url3, '/240.mp4', '/720.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(720p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
  
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')




 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(480p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
  
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')



 url3 = string.gsub(url3, '/240.mp4', '/360.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(360p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3})
  
  end
 
 
-- url = url_for(x)
--url = urldecode(url)
  
  
 -- table.insert(t, {title = url, mrl = url})
 
 
 x = string.gsub(x, '_tr_2469_', '_tr_Syncmer_') 

x = string.gsub(x, '_tr_30_', '_tr_Coldfilm_') 





x = string.gsub(x, '_tr_233_', '_tr_Coldfilm_') 

x = string.gsub(x, '_tr_3025_', '_tr_Ultradox_')

x = string.gsub(x, '_tr_768_', '_tr_Ultradox_')

x = string.gsub(x, '_tr_1432_', '_tr_Rudub_')

x = string.gsub(x, '_tr_2388_', '_tr_Rudub_')

x = string.gsub(x, '_tr_286_', '_tr_Rezka_')

x = string.gsub(x, '_tr_281_', '_tr_Rg.paravozik_')

x = string.gsub(x, '_tr_10_', '_tr_Lostfilm_')

x = string.gsub(x, '_tr_380_', '_tr_Tvshows_')

x = string.gsub(x, '_tr_397_', '_tr_Пифагор_')

x = string.gsub(x, '_tr_17_', '_tr_Jaskier_')

x = string.gsub(x, '_tr_16_', '_tr_Gears Media_')

x = string.gsub(x, '_tr_6_', '_tr_Профессиональный_')

x = string.gsub(x, '_tr_7_', '_tr_Дубляж_')

x = string.gsub(x, '_tr_998_', '_tr_LE-Production_')

x = string.gsub(x, '_tr_14_', '_tr_Alexfilm_')

x = string.gsub(x, '_tr_1538_', '_tr_RED Head Sound_')

x = string.gsub(x, '_tr_1410_', '_tr_RED Head Sound_')

x = string.gsub(x, '_tr_2648_', '_tr_1Win Studio_')

x = string.gsub(x, '_tr_554_', '_tr_Newcomers_')

x = string.gsub(x, '_tr_210_', '_tr_Goldteam_')


x = string.gsub(x, '_tr_1285_', '_tr_Goldteam_')

x = string.gsub(x, '_tr_3014_', '_tr_Nonamestudio_')

x = string.gsub(x, '_tr_180_', '_tr_Viruseproject_')

x = string.gsub(x, '_tr_2836_', '_tr_Hate Studio_')

x = string.gsub(x, '_tr_2981_', '_tr_Capybara_')

x = string.gsub(x, '_tr_381_', '_tr_Оригинал_')

x = string.gsub(x, '_tr_1308_', '_tr_Оригинал_')

x = string.gsub(x, '_tr_24_', '_tr_Ideafilm_')

x = string.gsub(x, '_tr_521_', '_tr_Westfilm_')

x = string.gsub(x, '_tr_12_', '_tr_Baibako_')

x = string.gsub(x, '_tr_436_', '_tr_Kerobtv_')

x = string.gsub(x, '_tr_432_', '_tr_Kerobtv_')

x = string.gsub(x, '_tr_359_', '_tr_Lakefilms_')

x = string.gsub(x, '_tr_2963_', '_tr_Dragon Money Studio_')

x = string.gsub(x, '_tr_22_', '_tr_Кубик в Кубе_')

x = string.gsub(x, '_tr_2828_', '_tr_Закадры_')

x = string.gsub(x, '_tr_13_', '_tr_Newstudio_')

x = string.gsub(x, '_tr_2732_', '_tr_Whiskey Sound_')

x = string.gsub(x, '_tr_996_', '_tr_Flarrow Films_')

x = string.gsub(x, '_tr_563_', '_tr_Кравец_')

x = string.gsub(x, '_tr_19_', '_tr_Omskbird Records_')

x = string.gsub(x, '_tr_331_', '_tr_AMS_')


  


for season, tr, episode, url3 in string.gmatch(x, '<div.-class.-in_e.-class=\'mfs\'.-"s_(.-)_tr_(.-)_e_(.-)_.-file.-(//.-mp4)') do


 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
  end


for season, tr, episode, url3 in string.gmatch(x, '<div.-class.-in_e.-class=\'mfs\'.-"s_(.-)_tr_(.-)_e_(.-)_.-file.-(//.-mp4)') do

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
 end

  end
  
 

        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end