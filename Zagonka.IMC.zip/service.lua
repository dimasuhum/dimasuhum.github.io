-- zagonka.tv plugin

require('support')
require('video')
require('parser')
require('client')

--http://films13.zagonka.online/http://zagonka.tv

--http://zagonka9.zagonkom.gb.net/embed/kp-5304403



--local HOME = 'http://films50.zagonko.org'
--local HOME = 'http://filmixs.zagonko.org'
local HOME = 'http://zagonka9.zagonkom.gb.net'
--local HOME = 'http://zagonka1.zagonkom.gb.nethttp://film13.zagonka.online/filmy7/page2/'


--http://zagonka1.zagonkom.gb.net/filmy7/page/2/http://film14.zagonka.online/filmy7/


--local HOME = 'http://zagonka.tv'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from zagonka.tv plugin')
	return 1
end

function onUnLoad()
	print('Bye from zagonka.tv plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=1	
	-- #stream/page=2

	if not args.q then
    -- 	local page = tonumber(conn:load(args.page or 1))
	local page = tonumber(args.page or 1)
	

		
		local genre = args.genre or '/populyarnoe.html'
		
--  http://film13.zagonka.online/filmy7/http://zagonka.tv/filmy7/page/2/      

-- http://zagonka.tv/http://film13.zagonka.online/filmy7/page/2/    

		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

       --  local x = http.getz(url)
         local x = conn:load(url)
     
        for title, image, url  in string.gmatch(x, '<div class="short".-<img.-alt=.-Смотреть(.-)онлайн.-(/uploads.-jpg).-href=.-(/.-.html)') do
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       -- local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		--table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
    
    
       --  local x = http.getz(HOME)
        local x = conn:load(HOME)
--		  local x = string.match(x, '<a href="#nav">Навигатор</a>(.-)<div id="nav"')
		for title, genre, total in string.gmatch(x, '<div class="dropdown%-toggle".->(.-)<b.-<a.-href="(.-)">(.-)</a>') do


         table.insert(t, {title = total .. ':' .. title, mrl = '#stream/genre=' .. genre})
		
	end


        local x = conn:load(HOME)
--		  local x = string.match(x, '<a href="#nav">Навигатор</a>(.-)<div id="nav"')
        for title, genre, total in string.gmatch(x, '<div class="dropdown%-toggle".->(.-)<b.-Фильмы.-<a.-href="(.-)">(.-)</a>') do
        table.insert(t, {title = total .. ':' .. title, mrl = '#stream/genre=' .. genre})
		
	end
        
        local x = conn:load(HOME)
--		  local x = string.match(x, '<a href="#nav">Навигатор</a>(.-)<div id="nav"')

        for title, genre, total in string.gmatch(x, '<div class="dropdown%-toggle".->(.-)<b.-Сериалы.-<a.-href="(.-)">(.-)</a>') do
       table.insert(t, {title = total .. ':' .. title, mrl = '#stream/genre=' .. genre})
		
	end
     	local x = conn:load(HOME)
--		  local x = string.match(x, '<a href="#nav">Навигатор</a>(.-)<div id="nav"')

       for title, genre, total in string.gmatch(x, '<div class="dropdown%-toggle".->(.-)<b.-Мультфильмы.-<a.-href="(.-)">(.-)</a>') do
       
       
       table.insert(t, {title = total .. ':' .. title, mrl = '#stream/genre=' .. genre})
		
	end

       local x = conn:load(HOME)
--		  local x = string.match(x, '<a href="#nav">Навигатор</a>(.-)<div id="nav"')

       for title, genre, total in string.gmatch(x, '<div class="dropdown%-toggle".->(.-)<b.-Мультсериалы.-<a.-href="(.-)">(.-)</a>') do
       
       
       table.insert(t, {title = total .. ':' .. title, mrl = '#stream/genre=' .. genre})
		
	end


	
	
	
	
--		for title, genre, total in string.gmatch(x, '<div class="dropdown%-toggle".->(.-)<b.-<a.-href="(.-)">(.-)</a>') do
	
	
	--	table.insert(t, {title = total .. ':' .. title, mrl = '#stream/genre=' .. genre})
		
		
--	end
	
	

--http://zagonka.tv/index.php?video=рокки&do=search&subaction=search


        
  elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		
       local url = 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=' .. urlencode(args.keyword) .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
	
--url = string.gsub(title, '^(.-)', 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=') .. '&year=' .. title1 .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
  
     

		local x = conn:load(url)
		
        for title, total, image in string.gmatch(x, '{"id":(.-),"name":"(.-)".-poster":{"url":"(.-)"') do
			url = string.gsub(title, '^(.-)', HOME .. '/embed/kp-') .. '?v=1'
          --  image = string.gsub(image, '^(.-)', HOME) 
          
          
      
          
			table.insert(t, {title = total, mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    --	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
	--	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			      
        
        
	-- #stream/q=content&id=/film-zvyozdnye-vrata-1994-hd
	 
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		
       --  local x = http.getz(args.id)
		local x = conn:load(args.id)
        --x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'(Описание:</b>.-)<br>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div align="center".-src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Год:</td>.-)</div>', '(Страна:</td>.-)</a>','(Жанр:</td>.-)</a>', '(Продолжительность:</td>.-)</td>', '(Режиссер:</td>.-)</div>', '(В главных ролях:</td>.-)</td>'
		})




       for url in string.gmatch(x, '<iframe id="ipl".-data%-src="(/embed/kp-.-)"') do

   --   for url in string.gmatch(x, '<div id="mypl".-data%-kp="(.-)"') do
      
      
--http://zagonka9.zagonkom.gb.net/embed/kp-5212124
      
        --x = string.gsub(x, 'Скачать', '')
     --   for url in string.gmatch(x, '<iframe id="ipl".-src="(/embed/kp.-)"') do

          print(url) 
		url = string.gsub(url, '^(.-)', HOME) .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        

--]//mpa.education1ne.in.net/movies/6eb7e3f5f40fede7c446d843897525b272198088/3e58db8ca7cd8db08e9b545c905ae179:2025021904/480{v1}"

		if url then
			for title, total,  url1, url2 in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p)].-(//.-movies)(/.-})') do
           t['view'] = 'simple'
       
         url1 = string.gsub(url1, '^(.-)', 'http:')
         url2 = string.gsub(url2, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url1 .. url2})
			end
		end	
			
        if url then
			for title, total, url1, url2 in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p)].-(//.-movies)(/.-})') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
           url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url1 .. url2})
			end
		end	
        if url then
			for title, total, url1, url2 in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD)].-(//.-movies)(/.-})') do
            t['view'] = 'simple'
         
         url1 = string.gsub(url1, '^(.-)', 'http:')
         url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url1 .. url2})
			end
		end	
   
   


			


--Coldfilm tr_233_
--Ultradox tr_768_
--Lostfilm     
--Rezka; tr_286_
--Rudub tr_1432_

        local slist = string.match(url,'Coldfilm.-Coldfilm(.-)}]}') 


      if slist then

			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Coldfilm' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
	
		end	
    end
  
  
    
  
     local slist = string.match(url,'Ultradox.-Ultradox(.-)}]}')

      if slist then


			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Ultradox' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
			end
		end
			
  
   
  
  
       local slist = string.match(url,'Lostfilm.-Lostfilm(.-)}]}')


       if slist then

			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Lostfilm' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
		end
		end	
  
  
      local slist = string.match(url,'Rezka.-Rezka(.-)}]}')

       if slist then


			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Rezka' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
				
		end
		end	
  
     
     
     
     local slist = string.match(url,'Rudub.-Rudub(.-)}]}')
     
     
         if slist then

			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Rudub' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
		
		end	
     end
       
      
      local slist = string.match(url,'"title"(.-)}]}')
     
     
         if slist then
     for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_tr_7_e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
		
		end	
        end
       

end





        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end