-- zagonka.tv plugin

require('support')
require('video')
require('parser')
require('client')


--http://abc.zagonkop.gb.net/embed/kp-386


--local HOME = 'http://abc.zagonkop.gb.net'
local HOME = 'http://zagonka.tv'



local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from zagonka.tv plugin')
	return 1
end

function onUnLoad()
	print('Bye from zagonka.tv plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=1	
	-- #stream/page=2

	if not args.q then
    -- 	local page = tonumber(conn:load(args.page or 1))


local headers = {
    ["host"] = "zagonka.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
   ["Accept-Encoding"] = "gzip, deflate",
   ["Referer"] = "http://zagonka.tv/",
   ["Connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
["Upgrade-Insecure-Requests"] = "1",
["Priority"] = "u=0, i"
}



	local page = tonumber(args.page or 1)
	

		
	--	local genre = args.genre or '/populyarnoe.html'

    local genre = args.genre or '/filmy7/'
	


		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

        local x = http.getz(url, headers)
       --  local x = conn:load(url, headers)
     
     --  for image, url, title, total in string.gmatch(x, '<div class="short".-<img.-srcset="(/uploads/.-jpg).-<a href="(/.-html)">(.-) %((.-)%)</a>') do
	
	
	for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-html).->(.-)%((.-)%)') do
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
      --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 
 table.insert(t, {title = 'Популярные сегодня', mrl = '#stream/genre=' .. '/populyarnoe-onlayn.html'})
 
 
 table.insert(t, {title = 'Рейтинговые новинки', mrl = '#stream/genre=' .. '/rating-onlayn.html'})
 
 
-- table.insert(t, {title = 'поиск по словам', mrl = '#stream/q=searchn'})
 
 
table.insert(t, {title = 'поиск актеров', mrl = '#stream/q=searchp'})
 

 
    local headers = {
   ["host"] = "zagonka.tv",
     ["referer"] = "http://zagonka.tv/",
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0"
}
         local x = http.getz(HOME, headers)
      --  local x = conn:load(HOME)
		  local slist = string.match(x, 'Навигатор(.-)Жанры')
		
for genre, total in string.gmatch(slist, '<li data%-hrf="(.-)">(.-)</li>') do

table.insert(t, {title = total, mrl = '#stream/genre=' .. genre})

end

for genre, total in string.gmatch(slist, '<a id=".-href="(.-)">(.-)</a>') do

     table.insert(t, {title = total, mrl = '#stream/genre=' .. genre})
		
	
end


local x = http.getz(HOME, headers)
   
		 local slist = string.match(x, 'ТОП(.-)</ul>')

--for genre, total in string.gmatch(x,'<li data%-hrf="(/.-/(sort.-)">(.-)</li>'

for genre, total in string.gmatch(slist, '<.-hr.-="(/.-)">(.-)<') do


table.insert(t, {title = total, mrl = '#stream/genre=' .. genre})
		
	
end		






table.insert(t, {title = 'Фильмы по жанрам', mrl = '#stream/q=genrez&id=' .. '/filmy7/'})

table.insert(t, {title = 'Сериалы по жанрам', mrl = '#stream/q=genrez&id=' .. '/serialy2/'})

table.insert(t, {title = 'Мульфильмы по жанрам', mrl = '#stream/q=genrez&id=' .. '/multfilmy1/'})

table.insert(t, {title = 'Мульсериалы по жанрам', mrl = '#stream/q=genrez&id=' .. '/multserialy1/'})



        
        
        elseif args.q == 'genrez' then
	
	local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["host"] = "zagonka.tv",
    ["referer"] = "http://zagonka.tv/",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0"
}
	local x = http.getz(HOME .. args.id, headers)
	
	for title, genre in string.gmatch(x, '<div class="dropdown%-toggle" data%-toggle="dropdown">(.-)<.-class="dropdown%-menu".-class="indx" href="/.-/(zhanr.-)"') do
	
	t['view'] = 'simple'
    
	table.insert(t, {title = title, mrl = '#stream/q=genrezg&id=' .. args.id .. '&id1=' .. genre})
		
	end

elseif args.q == 'genrezg' then
	
	local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["host"] = "zagonka.tv",
    ["referer"] = "http://zagonka.tv/",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0"
}

local page = tonumber(args.page or 1)
	
local url = HOME .. args.id .. args.id1
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

	local x = http.getz(url, headers)

table.insert(t, {title = 'По году', mrl = '#stream/q=god&id=' .. args.id .. '&id1=' .. args.id1, image = '#self/setting.png'})
		



for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/q=genrezg&id=' .. args.id .. '&id1=' .. args.id1 .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})




elseif args.q == 'god' then

if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
 
local headers = {
		    ["host"] = "zagonka.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["referer"] = "http://zagonka.tv/",
    ["X-Requested-With"] = "XMLHttpRequest",
       ["accept"] = "text/html, */*; q=0.01",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
["Priority"] = "u=0"
}	
	
			local page = tonumber(args.page or '1')
		
       local url = HOME .. args.id .. 'god-' .. args.keyword .. '/' .. args.id1

if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

	local x = http.getz(url, headers)


table.insert(t, {title = 'По году', mrl = '#stream/q=god&id=' .. args.id .. '&id1=' .. args.id1, image = '#self/setting.png'})
	

for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/q=god&id=' .. args.id .. '&id1=' .. args.id1 .. '&keyword=' .. args.keyword .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
	
	
	



--http://zagonka.tv/index.php?video=рокки&do=search&subaction=search

--http://abc.zagonkop.gb.net/engine/ajax/xsearch/web.php?action=countResult&searchCat=video&field[rol]=Сильвестр Сталлоне&do=xsearch&xscatnum=undefined
--http://abc.zagonkop.gb.net/video/rol-Sil*vestr_Stallone/

--http://abc.zagonkop.gb.net/engine/ajax/xsearch/web.php?action=countResult&searchCat=video&field[keywords]=Терминатор&do=xsearch&xscatnum=undefined
 
 
 

 
 
       elseif args.q == 'searchp' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
		


local headers = {
    ["Host"] = "zagonka.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["referer"] = "http://zagonka.tv/",
        ["X-Requested-With"] = "XMLHttpRequest",
    ["Connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}




args.keyword = string.gsub(args.keyword, ' ', '_')
		
		local page = tonumber(args.page or '1')
		
       local url = 'http://abc.zagonkop.gb.net/video/rol-' .. args.keyword .. '/'
       
       if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		
       local x = http.getz(url, headers)

for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
 
 local url = '#stream/q=searchp&keyword=' .. args.keyword .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
 
 
 
  
  elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		


local headers = {
    ["Host"] = "zagonka tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Referer"] = "http://zagonka.tv/",
    ["Connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	
		
		
		local page = tonumber(args.page or '1')
		
       local url = 'http://abc.zagonkop.gb.net/engine/ajax/xsearch/f.php?q=' .. urlencode(args.keyword)
       --.. '&page=' .. tostring(page)
	

    
		local x = http.getz(url, headers)
	
 
local x = json.decode(x)

		for _, v in ipairs(x) do
	
	local url = HOME .. v['url']
	
	
	t['view'] = 'simple'
	
	table.insert(t, {title = v['text'], mrl = '#stream/q=content&id=' .. url})

end




    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			      
        
        
	-- #stream/q=content&id=/film-zvyozdnye-vrata-1994-hd



elseif args.q == 'similar' then

local headers = {
    ["Host"] = "zagonka.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Referer"] = args.id,
    ["Connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	
	
		
        local x = http.getz(args.id, headers)


local slist = string.match(x, 'class="scrlx"(.-)class="scrlx"')

for image, url, title, total in string.gmatch(slist, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end


elseif args.q == 'actor' then

local headers = {
    ["Host"] = "zagonka.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Referer"] = args.id,
    ["Connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	
	
		
        local x = http.getz(args.id, headers)
        
 
 for url, title in string.gmatch(x, '<div data%-hrf="(/video/r.-)">(.-)</div>') do

t['view'] = 'simple'

  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url})
  
  end



	 
	elseif args.q == 'content' then
		t['view'] = 'annotation'

local ref = '"' .. args.id .. '"'
	
	local headers = {
    ["Host"] = "zagonka.tv",	
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Referer"] = ref,
    ["Connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	
		
		
		
        local x = http.getz(args.id, headers)
	--	local x = conn:load(args.id)
        --x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'(Описание:</b>.-)<br>')
        t['poster'] = args.p
		t['poster'] = parse_match(x,'"dateCreated".-"image":.-(http.-jpg)')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Жанр:</td>.-)</a>'
		})




       local ids = string.match(x, '<div id="player" data%-id="(.-)"') 

if ids then

 local kp = string.match(x, '<div id="player".-data%-kp="(.-)"')

if kp then
	
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=zagonka&id=' .. args.id .. '&id1=' .. ids .. '&id2=' .. kp})

		end
     end
  
  table.insert(t, {title = 'В ролях', mrl = '#stream/q=actor&id=' .. args.id})
  table.insert(t, {title = 'Похожее', mrl = '#stream/q=similar&id=' .. args.id})
     
        elseif args.q == 'zagonka' then
     
     
--local url = 'http://abc.zagonkop.gb.net/embed/' .. args.id1

local url = HOME .. '/embed/' .. args.id1

--http://abc.zagonkop.gb.net/embed/kp-5499518


local ref = '"' .. args.id .. '"'

local headers = {
    ["Host"] = "zagonka.tv",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:160.0) Gecko/20100101 Firefox/160.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Referer"] = ref,
    ["Connection"] = "keep-alive",
   ["Cookie"] = "_svh=4566750adb6d176b.1795239322.57a12769c3c6b421f5ff4577b520f316d83b1109; dle_lang=ru; PHPSESSID=e3a689b2969b12cc779a1d386b3af208",
    ["X-Requested-With"] = "XMLHttpRequest",  
    ["Upgrade-Insecure-Requests"] = "1",
    ["Priority"] = "u=0, i",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
	

local x = http.getz(url, headers)

x = string.gsub(x, 'ZYzNM', '')
        x = string.gsub(x, 'ZUzls', '')
x = string.gsub(x, 'ZUzVw', '')

x = string.gsub(x, 'ZUTB5', '')

x = string.gsub(x, 'ZaTdV', '')


local x = string.match(x, 'Playerjs%(\'#2(.-)\'%)+') 
   
  if x then      
    
    --ZYzNM
--ZUzls
--ZUzVw
--ZUTB5
--ZaTdV
    
    x = base64_decode(x)
     
 x = string.gsub(x, '{v1}', '.mp4')   
     


--table.insert(t, {title = x, mrl = x})

 --"title\":\"<div id=\'s_1_tr_Coldfilm_e_2_\'.-"file\":.-(//.-mp4)
 
 
 for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')
 
 
 
 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(1080p) ' .. tolazy(title) .. ' ' ..tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
  
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')




 url3 = string.gsub(url3, '/240.mp4', '/720.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(720p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
  
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')




 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(480p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
  
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')



 url3 = string.gsub(url3, '/240.mp4', '/360.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(360p) ' .. tolazy(title) .. ' ' .. tolazy(total), mrl = url3})
  
  end
 
 
 
 
for tr, voise in string.gmatch(x, 'class=\'in_tr\'>(.-)<br>.-folder(.-)}]') do

for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
  end
end

for tr, voise in string.gmatch(x, 'class=\'in_tr\'>(.-)<br>.-folder(.-)}]') do

for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do


 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
 end 
 end



for voise in string.gmatch(x, '<div id=\'_not\'.-folder(.-)}]') do


for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия', mrl = url3})
  
  end
end


for voise in string.gmatch(x, '<div id=\'_not\'.-folder(.-)}]') do


for url3, season, episode in string.gmatch(voise,'file.-(//.-mp4).-class=\'in_e\'.-class=\'mfs\'.-"s_(.-)_tr_.-_e_(.-)_.-') do

url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

 table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия', mrl = url3})
  
  end
end



 
 end
  
 

        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end