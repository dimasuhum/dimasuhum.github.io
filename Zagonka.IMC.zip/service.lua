-- zagonka.tv plugin

require('support')
require('video')
require('parser')
require('client')





local HOME = 'http://abc.zagonkop.gb.net'

local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from zagonka.tv plugin')
	return 1
end

function onUnLoad()
	print('Bye from zagonka.tv plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=1	
	-- #stream/page=2

	if not args.q then
    -- 	local page = tonumber(conn:load(args.page or 1))


local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}



	local page = tonumber(args.page or 1)
	

		
	--	local genre = args.genre or '/populyarnoe.html'

    local genre = args.genre or '/filmy7/'
	


		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

        local x = http.getz(url, headers)
       --  local x = conn:load(url, headers)
     
     --   for title, image, url  in string.gmatch(x, '<div class="short".-<img.-alt=.-Смотреть(.-)онлайн.-(/uploads.-jpg).-href=.-(/.-.html)') do
	
	
	for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 
 
 
-- table.insert(t, {title = 'поиск по словам', mrl = '#stream/q=searchn'})
 
 
--table.insert(t, {title = 'поиск актеров', mrl = '#stream/q=searchp'})
 
    local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}
         local x = http.getz(HOME, headers)
      --  local x = conn:load(HOME)
		  local slist = string.match(x, 'Навигатор(.-)Жанры')
		
for genre, total in string.gmatch(slist, '<li data%-hrf="(.-)">(.-)</li>') do

table.insert(t, {title = total, mrl = '#stream/genre=' .. genre})

end

for genre, total in string.gmatch(slist, '<a id=".-href="(.-)">(.-)</a>') do

     table.insert(t, {title = total, mrl = '#stream/genre=' .. genre})
		
	
end


local x = http.getz(HOME, headers)
   
		 local slist = string.match(x, 'ТОП(.-)</ul>')

--for genre, total in string.gmatch(x,'<li data%-hrf="(/.-/(sort.-)">(.-)</li>'

for genre, total in string.gmatch(slist, '<.-hr.-="(/.-)">(.-)<') do


table.insert(t, {title = total, mrl = '#stream/genre=' .. genre})
		
	
end		






table.insert(t, {title = 'Фильмы по жанрам', mrl = '#stream/q=genrez&id=' .. '/filmy7/'})

table.insert(t, {title = 'Сериалы по жанрам', mrl = '#stream/q=genrez&id=' .. '/serialy2/'})

table.insert(t, {title = 'Мульфильмы по жанрам', mrl = '#stream/q=genrez&id=' .. '/multfilmy1/'})

table.insert(t, {title = 'Мульсериалы по жанрам', mrl = '#stream/q=genrez&id=' .. '/multserialy1/'})



        
        
        elseif args.q == 'genrez' then
	
	local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}
	local x = http.getz(HOME .. args.id, headers)
	
	for title, genre in string.gmatch(x, '<div class="dropdown%-toggle" data%-toggle="dropdown">(.-)<.-class="dropdown%-menu".-class="indx" href="/.-/(zhanr.-)"') do
	
	t['view'] = 'simple'
    
	table.insert(t, {title = title, mrl = '#stream/q=genrezg&id=' .. args.id .. '&id1=' .. genre})
		
	end

elseif args.q == 'genrezg' then
	
	local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}

local page = tonumber(args.page or 1)
	
local url = HOME .. args.id .. args.id1
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end

	local x = http.getz(url, headers)

for image, url, title, total in string.gmatch(x, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
        
       local url = '#stream/q=genrezg&id=' .. args.id .. '&id1=' .. args.id1 .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})




	
	
	

--http://zagonka.tv/index.php?video=рокки&do=search&subaction=search

--http://abc.zagonkop.gb.net/engine/ajax/xsearch/web.php?action=countResult&searchCat=video&field[rol]=Сильвестр Сталлоне&do=xsearch&xscatnum=undefined
--http://abc.zagonkop.gb.net/video/rol-Sil*vestr_Stallone/

--http://abc.zagonkop.gb.net/engine/ajax/xsearch/web.php?action=countResult&searchCat=video&field[keywords]=Терминатор&do=xsearch&xscatnum=undefined
 
 
 
 
 elseif args.q == 'searchn' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
		local headers = {
		    ["host"] = "abc.zagonkop.gb.net",
       ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["referer"] = "http://abc.zagonkop.gb.net/",
       ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
["Content-Length"] = ""

}

		
		local page = tonumber(args.page or '1')
		
       local url = 'http://abc.zagonkop.gb.net/engine/ajax/xsearch/web.php?'
       
       
       
       local params = [[
       action=countResult&searchCat=video&field[keywords]= .. urlencode(args.keyword) .. &do=xsearch&xscatnum=undefined
       ]]
       
       local x = http.postz(url, headers, params)
	
 
 url = url_for(x)
 url = urldecode(url)
 
 table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
 
 
       elseif args.q == 'searchp' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
		local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}

		
		local page = tonumber(args.page or '1')
		
       local url = 'http://abc.zagonkop.gb.net/engine/ajax/xsearch/web.php?'
       
       local params = [[
 action=countResult&searchCat=video&field[rol]= .. urlencode(args.keyword) .. &do=xsearch&xscatnum=undefined
       ]]
       local x = http.postz(url, headers, params)
	
 
 url = url_for(x)
 url = urldecode(url)
 
 table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
 
 
 
  
  elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
		local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}


		
		
		local page = tonumber(args.page or '1')
		
       local url = 'http://abc.zagonkop.gb.net/engine/ajax/xsearch/f.php?q=' .. urlencode(args.keyword)
       --.. '&page=' .. tostring(page)
	

     

		local x = http.getz(url, headers)
	

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 
		
        for id, title, total, url in string.gmatch(x, '{"id":"(.-)".-text":"(.-)%((.-)%).-url.-(/.-)"') do
	
	
	
	
	
	
	
	
			url = string.gsub(url, '^(.-)', HOME)
			
		local data = title .. ' (' .. total .. ')'	
		
         --   image = string.gsub(image, '^(.-)', HOME)
            
         --   title = string.gsub(title, '&nbsp;', '') 
            
           t['view'] = 'simple' 
			table.insert(t, {title = data, mrl = '#stream/q=content&id=' .. url, image = image})
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			      
        
        
	-- #stream/q=content&id=/film-zvyozdnye-vrata-1994-hd



elseif args.q == 'similar' then

local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = args.id,
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}
	
		
        local x = http.getz(args.id, headers)


local slist = string.match(x, 'class="scrlx"(.-)class="scrlx"')

for image, url, title, total in string.gmatch(slist, '<div class="short".-srcset.-(/uploads.-jpg).-<a href="(/.-)">(.-)%((.-)%)') do
	
	
			url = string.gsub(url, '^(.-)', HOME)
            image = string.gsub(image, '^(.-)', HOME)
            
            title = string.gsub(title, '&nbsp;', '') 
            
            
			table.insert(t, {title = title .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end


elseif args.q == 'actor' then

local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = args.id,
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}
	
		
        local x = http.getz(args.id, headers)
        
 
 for url, title in string.gmatch(x, '<div data%-hrf="(/video/r.-)">(.-)</div>') do

t['view'] = 'simple'

  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url})
  
  end



	 
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	
	
	local headers = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = args.id,
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}
	
		
        local x = http.getz(args.id, headers)
	--	local x = conn:load(args.id)
        --x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'(Описание:</b>.-)<br>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div align="center".-src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Жанр:</td>.-)</a>'
		})




       local ids = string.match(x, '<div id="down" data%-id="(.-)"') 

if ids then

 local kp = string.match(x, '<div id="down".-data%-kp="(.-)"')

if kp then
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=zagonka&id=' .. args.id .. '&id1=' .. ids .. '&id2=' .. kp})

		end
     end
  
  table.insert(t, {title = 'В ролях', mrl = '#stream/q=actor&id=' .. args.id})
  table.insert(t, {title = 'Похожее', mrl = '#stream/q=similar&id=' .. args.id})
     
        elseif args.q == 'zagonka' then
     
local url = 'http://abc.zagonkop.gb.net/engine/ajax/down.php'
  
  local headerss = {
     ["host"] = "abc.zagonkop.gb.net",
     ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["referer"] = args.id,
    ["x-requested-with"] = "XMLHttpRequest",
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive"

}
  
  local params = http.encode{
		id = args.id1,
		kpid = args.id2
					}
  
  local x = http.postz(url, headerss, params)
  
--  url = url_for(x)
 -- url = urldecode(url)
  
  
 -- table.insert(t, {title = url, mrl = url})
  
 
 for title, total, url3 in string.gmatch(x, '<div class="dbord".-HD(.-)<.-class=\'mfs\'>(.-)<div class=\'fllq\'.-<a.-href=.-(//.-mp4)') do
 
 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(1080p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '<div class="dbord".-HD(.-)<.-class=\'mfs\'>(.-)<div class=\'fllq\'.-<a.-href=.-(//.-mp4)') do

 url3 = string.gsub(url3, '/240.mp4', '/720.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(720p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '<div class="dbord".-HD(.-)<.-class=\'mfs\'>(.-)<div class=\'fllq\'.-<a.-href=.-(//.-mp4)') do

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(480p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '<div class="dbord".-HD(.-)<.-class=\'mfs\'>(.-)<div class=\'fllq\'.-<a.-href=.-(//.-mp4)') do

 url3 = string.gsub(url3, '/240.mp4', '/360.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(360p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end


x = string.gsub(x, '_tr_233_', '_tr_Coldfilm_') 

x = string.gsub(x, '_tr_3025_', '_tr_Ultradox_')

x = string.gsub(x, '_tr_768_', '_tr_Ultradox_')

x = string.gsub(x, '_tr_1432_', '_tr_Rudub_')

x = string.gsub(x, '_tr_2388_', '_tr_Rudub_')

x = string.gsub(x, '_tr_286_', '_tr_Rezka_')

x = string.gsub(x, '_tr_281_', '_tr_Rg.paravozik_')

x = string.gsub(x, '_tr_10_', '_tr_Lostfilm_')

x = string.gsub(x, '_tr_380_', '_tr_Tvshows_')

x = string.gsub(x, '_tr_397_', '_tr_Пифагор_')

x = string.gsub(x, '_tr_17_', '_tr_Jaskier_')

x = string.gsub(x, '_tr_16_', '_tr_Gears Media_')

x = string.gsub(x, '_tr_6_', '_tr_Профессиональный_')

x = string.gsub(x, '_tr_7_', '_tr_Дубляж_')

x = string.gsub(x, '_tr_998_', '_tr_LE-Production_')

x = string.gsub(x, '_tr_14_', '_tr_Alexfilm_')

x = string.gsub(x, '_tr_1538_', '_tr_RED Head Sound_')

x = string.gsub(x, '_tr_1410_', '_tr_RED Head Sound_')

x = string.gsub(x, '_tr_2648_', '_tr_1Win Studio_')

x = string.gsub(x, '_tr_554_', '_tr_Newcomers_')

x = string.gsub(x, '_tr_210_', '_tr_Goldteam_')


x = string.gsub(x, '_tr_1285_', '_tr_Goldteam_')

x = string.gsub(x, '_tr_3014_', '_tr_Nonamestudio_')

x = string.gsub(x, '_tr_180_', '_tr_Viruseproject_')

x = string.gsub(x, '_tr_2836_', '_tr_Hate Studio_')

x = string.gsub(x, '_tr_2981_', '_tr_Capybara_')

x = string.gsub(x, '_tr_381_', '_tr_Оригинал_')

x = string.gsub(x, '_tr_1308_', '_tr_Оригинал_')

x = string.gsub(x, '_tr_24_', '_tr_Ideafilm_')

x = string.gsub(x, '_tr_521_', '_tr_Westfilm_')

x = string.gsub(x, '_tr_12_', '_tr_Baibako_')

x = string.gsub(x, '_tr_436_', '_tr_Kerobtv_')

x = string.gsub(x, '_tr_432_', '_tr_Kerobtv_')

x = string.gsub(x, '_tr_359_', '_tr_Lakefilms_')

x = string.gsub(x, '_tr_2963_', '_tr_Dragon Money Studio_')

x = string.gsub(x, '_tr_22_', '_tr_Кубик в Кубе_')

x = string.gsub(x, '_tr_2828_', '_tr_Закадры_')

x = string.gsub(x, '_tr_13_', '_tr_Newstudio_')

x = string.gsub(x, '_tr_2732_', '_tr_Whiskey Sound_')

x = string.gsub(x, '_tr_996_', '_tr_Flarrow Films_')

x = string.gsub(x, '_tr_563_', '_tr_Кравец_')

x = string.gsub(x, '_tr_19_', '_tr_Omskbird Records_')

x = string.gsub(x, '_tr_331_', '_tr_AMS_')

for season, tr, episode, url3 in string.gmatch(x, '<div class="dep".-<div id=\'s_(.-)_tr_(.-)_e_(.-)_\'.-<a.-href=.-(//.-mp4)') do

 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
  end


for season, tr, episode, url3 in string.gmatch(x, '<div class="dep".-<div id=\'s_(.-)_tr_(.-)_e_(.-)_\'.-<a.-href=.-(//.-mp4)') do

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
  end




        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end