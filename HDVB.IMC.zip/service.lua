-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')


local HOME = 'https://hlg3hlb43cxtksb9eqg9securestreaming.apivb.com'
local HOME1 = 'https://api.movielab.media/api/v1/'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/country/СССР/
	-- #stream/genre=/country/Индия/
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/genre/боевик
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/url=/show/
    -- #stream/genre=/show/
	if not args.q then



--https://kinopoiskapiunofficial.tech/api/v2.2/films/386&apiKey=2a4a0808-81a3-40ae-b0d3-e11335ede616
--ApiKeyAuth (apiKey)	

--https://apivb.com/api/movies_updates.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc

		local page = tonumber(args.page or 1)
		
--https://api.movielab.media/api/v1/catalog/1/movies?page=1
		
	--	local genre = args.genre or 'search/movies?genres=all'
		local genre = args.genre or '/api/movies_updates.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc'
		local url = HOME .. genre
	--	if page > 1 then
			url = url .. '&page=' .. tostring(page)
	 --end

--https://hlg3hlb43cxtksb9eqg9securestreaming.apivb.com/api/filter.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&title=чужой

		
    	local x = conn:load('https://hlg3hlb43cxtksb9eqg9securestreaming.apivb.com/api/movies_updates.json?token=d16fe09ddd4d031b06a32a2e535147fc' .. '&page=' .. tostring(page))

  --  local x = conn:load(url)
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
   x = string.gsub(x, '\\u2013', '-')
	x = string.gsub(x, '\\u2116', '№')
	
        for title, title1, id in string.gmatch(x, '"title_ru":"(.-)".-"title_en":".-".-"year":(.-),.-"kinopoisk_id":(.-),') do
		

  	local x = conn:load('https://apivb.com/api/filter.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. id)
   

   

     
for image in string.gmatch(x, '"poster":"(.-)"') do
     image = string.gsub(image, '\\', '')
     
		image = string.gsub(image, 'https://www.themoviedb.org', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org')
		
		
		
		
			table.insert(t, {title=title .. ' (' .. title1 .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
      end
   
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		
		

	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'

--https://api.movielab.media/api/v1/collections?collection_type=all&sort=likes_count_asc&page=1


--https://api.movielab.media/api/v1/search/collections?title=%D0%A3%D0%B6%D0%B0%D1%81&page=1&limit=15






   table.insert(t, {title = 'Поиск по коллекциям', mrl = '#stream/q=coll', image = '#self/search.png'})

table.insert(t, {title = 'Поиск по актерам', mrl = '#stream/q=actors', image = '#self/search.png'})

table.insert(t, {title = 'Поиск по годам', mrl = '#stream/q=years', image = '#self/search.png'})





table.insert(t, {title = 'Случайные', mrl = '#stream/q=random&id=' .. 'search/random?limit=50'})

table.insert(t, {title = 'Коллекции', mrl = '#stream/q=collections&id=' .. 'collection_type=all&sort=likes_count_asc'})

		
       table.insert(t, {title = 'Ужасы', mrl = '#stream/q=genre&id=' .. '28'})
		
       table.insert(t, {title = 'Триллер', mrl = '#stream/q=genre&id=' .. '27'})
		
       table.insert(t, {title = 'Комедия', mrl = '#stream/q=genre&id=' .. '13'})
		
       table.insert(t, {title = 'Драма', mrl = '#stream/q=genre&id=' .. '10'})

		
       table.insert(t, {title = 'Фантастика', mrl = '#stream/q=genre&id=' .. '29'})
		
       table.insert(t, {title = 'Приключения', mrl = '#stream/q=genre&id=' .. '22'})

		
       table.insert(t, {title = 'Фэнтези', mrl = '#stream/q=genre&id=' .. '31'})
		
       table.insert(t, {title = 'История', mrl = '#stream/q=genre&id=' .. '12'})

table.insert(t, {title = 'Боевик', mrl = '#stream/q=genre&id=' .. '3'})
		
       table.insert(t, {title = 'Военный', mrl = '#stream/q=genre&id=' .. '5'})


        table.insert(t, {title = 'Мелодрама', mrl = '#stream/q=genre&id=' .. '17'})
		
       table.insert(t, {title = 'Криминал', mrl = '#stream/q=genre&id=' .. '16'})

table.insert(t, {title = 'Биография', mrl = '#stream/q=genre&id=' .. '2'})
		
       table.insert(t, {title = 'Спорт', mrl = '#stream/q=genre&id=' .. '25'})
 
        table.insert(t, {title = 'Семейный', mrl = '#stream/q=genre&id=' .. '24'})
		
       table.insert(t, {title = 'Детектив', mrl = '#stream/q=genre&id=' .. '6'})

table.insert(t, {title = 'Музыка', mrl = '#stream/q=genre&id=' .. '18'})
		
       table.insert(t, {title = 'Детский', mrl = '#stream/q=genre&id=' .. '7'})









table.insert(t, {title = 'Документальный', mrl = '#stream/q=genre&id=' .. '9'})
		
       table.insert(t, {title = 'Мультфильм', mrl = '#stream/q=genre&id=' .. '19'})

table.insert(t, {title = 'Короткометражный', mrl = '#stream/q=genre&id=' .. '15'})
		
       table.insert(t, {title = 'Церемония', mrl = '#stream/q=genre&id=' .. '32'})






--https://api.movielab.media/api/v1/search/random?page=1&limit=50

     elseif args.q == 'random' then


    local page = tonumber(args.page or 1)

    local x = conn:load(HOME1 .. args.id .. '&page=' .. tostring(page))

   
       for id, title1, title, image in string.gmatch(x, '"kinopoisk_id":(.-),.-"year":(.-),.-title_ru":"(.-),"title_en":".-".-"poster":"(.-)"') do
  
  
  title = string.gsub(title, '\\', '')
title = string.gsub(title, '"', '')
  
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. title1 .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
   
  
        
	local url = '#stream/page=' .. tostring(page + 1) .. '&q=random&id=' .. args.id
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		

			
     elseif args.q == 'genre' then


    local page = tonumber(args.page or 1)

    local x = conn:load(HOME1 .. 'search/movies?sort_by=asc&genres=' .. args.id .. '&page=' .. tostring(page))

   
       for id, title1, title, image in string.gmatch(x, '"kinopoisk_id":(.-),.-"year":(.-),.-title_ru":"(.-),"title_en":".-".-"poster":"(.-)"') do
  
  
  title = string.gsub(title, '\\', '')
title = string.gsub(title, '"', '')
  
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. title1 .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
   
  
        
	local url = '#stream/page=' .. tostring(page + 1) .. '&q=genre&id=' .. args.id
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	
	
	
	
    elseif args.q == 'collections' then


    local page = tonumber(args.page or 1)

    local x = conn:load(HOME1 .. 'collections?' .. args.id .. '&page=' .. tostring(page))

	
	for title, id, image in string.gmatch(x, '"name":"(.-)".-"id":(.-),"image_url":"(.-)"') do
	
	table.insert(t, {title=title, mrl = '#stream/q=collection&id=' .. id, image = image})
		end
   
   
   local url = '#stream/page=' .. tostring(page + 1) .. '&q=collections&id=' .. args.id
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
   
   
   
  elseif args.q == 'collection' then


    local page = tonumber(args.page or 1)

    local x = conn:load(HOME1 .. 'collections/' .. args.id .. '?movies_limit=20' .. '&page=' .. tostring(page))
    
    for id, title1, title, image in string.gmatch(x, '"kinopoisk_id":(.-),.-"year":(.-),.-title_ru":"(.-),"title_en":".-".-"poster":"(.-)"') do
  
  
  title = string.gsub(title, '\\', '')
title = string.gsub(title, '"', '')
  
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. title1 .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
   
 
    
        
	local url = '#stream/page=' .. tostring(page + 1) .. '&q=collection&id=' .. args.id
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	
--	https://api.movielab.media/api/v1/search/actors/8816?page=1&limit=15
	
   
   
   
   elseif args.q == 'actor' then
	
	
	local page = tonumber(args.page or 1)

    local x = conn:load(HOME1 .. 'search/actors/' .. args.id .. '?limit=20' .. '&page=' .. tostring(page))
    
    for id, title1, title, image in string.gmatch(x, '"kinopoisk_id":(.-),.-"year":(.-),.-title_ru":"(.-),"title_en":".-".-"poster":"(.-)"') do
  
  
  title = string.gsub(title, '\\', '')
title = string.gsub(title, '"', '')
  
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. title1 .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
   
 
    
        
	local url = '#stream/page=' .. tostring(page + 1) .. '&q=actor&id=' .. args.id
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
	
	
	
--https://api.movielab.media/api/v1/search/actors?name=%D0%A1%D1%82%D0%B0%D0%BB%D0%BB%D0%BE%D0%BD%D0%B5&sort_by=asc&page=1
	
	
    elseif args.q == 'actors' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')

	
	local x = conn:load(HOME1 .. 'search/actors?name=' .. urlencode(args.keyword) .. '&page=' .. tostring(page))
	
	for id, title, image in string.gmatch(x, '"id":(.-),"name":"(.-)".-"poster":"(.-)"') do
	
	table.insert(t, {title=title, mrl = '#stream/q=actor&id=' .. id, image = image})
		end
   
   local url = '#stream/q=actors&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		
 --   https://api.movielab.media/api/v1/search/movies?sort_by=asc&years=2025&page=1&limit=15


    elseif args.q == 'years' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')

	local x = conn:load(HOME1 .. 'search/movies?sort_by=asc&years=' .. urlencode(args.keyword) .. '&page=' .. tostring(page))
	
    for id, title1, title, image in string.gmatch(x, '"kinopoisk_id":(.-),.-"year":(.-),.-title_ru":"(.-),"title_en":".-".-"poster":"(.-)"') do
  
  
  title = string.gsub(title, '\\', '')
title = string.gsub(title, '"', '')
  
   --t['view'] = 'grid_poster'

			table.insert(t, {title=title .. ' (' .. title1 .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
   
    
    
    
    
    local url = '#stream/q=years&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		

    
    elseif args.q == 'coll' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
	--	local url = 'https://api.movielab.media/api/v1/search/collections?title=' .. urlencode(args.keyword) .. '&page=' .. tostring(page)
	
	local x = conn:load(HOME1 .. 'search/collections?title=' .. urlencode(args.keyword) .. '&page=' .. tostring(page))
	
	for title, id, image in string.gmatch(x, '"name":"(.-)".-"id":(.-),"image_url":"(.-)"') do
	
	table.insert(t, {title=title, mrl = '#stream/q=collection&id=' .. id, image = image})
		end
   
   local url = '#stream/q=coll&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
  -- local url = '#stream/page=' .. tostring(page + 1) .. '&q=coll&id=' .. urlencode(args.keyword)
	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
		
		
		
			
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = 'https://apivb.com/api/filter.json?metod=search&token=d16fe09ddd4d031b06a32a2e535147fc&title=' .. urlencode(args.keyword) .. '&page=' .. tostring(page)
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
  x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	x = string.gsub(x, '\\u2013', '-')
   x = string.gsub(x, '\\u2116', '№')
   
       for title, total, total1, id in string.gmatch(x, '"title_ru":"(.-)".-title_en":"(.-)".-"year":(.-),.-kinopoisk_id":(.-),') do
  


  	local x = conn:load('https://apivb.com/api/filter.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. id)
  
     
for image in string.gmatch(x, '"poster":"(.-)"') do
     image = string.gsub(image, '\\', '')
     
		image = string.gsub(image, 'https://www.themoviedb.org', 'http://fxmlparsers.in.net/?wimg=http://image.tmdb.org')
		
		
			table.insert(t, {title=title .. '/' .. total .. ' (' .. total1 .. ')', mrl = '#stream/q=content&id=' .. id, image = image})
		end
      end
   
		
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
		local x = conn:load('https://apivb.com/api/filter.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id)
		
		
		
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	
		
		x = string.gsub(x, '\\u00a0', ' ')
x = string.gsub(x, '\\u2013', '-')
x = string.gsub(x, '\\u2116', '№')
		
		
		
		
    --	local x = http.getz(args.id)
		
       -- x = string.gsub(x, 'onclick', '')
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)смотреть онлайн</h1>')
		t['description'] = parse_match(x, '"description":"(.-)"')
			t['poster'] = args.p
			
         --   t['poster'] = parse_match(x,'"poster":"(.-)"')
	--	if t['poster'] then
		
--t['poster'] = string.gsub(t['poster'], '\\', '')
		
	--		t['poster'] = string.gsub(t['poster'], '^/', HOME)
	--	end
			

--"genre":{"26":"Ужасы","11":"Фантастика","13":"Триллер","10":"Зарубежный"}
	
	--	x = string.gsub(x, '"genre":{".-":"', 'Жанр :')
	

			
	    	t['annotation'] = parse_array(x, {

			'(Жанр:</h4>.-)</p>',
			'(Перевод:</h4>.-)</p>',
			'(Качество:</h4>.-)</p>',
			'(Время:</h4>.-)</p>',
			'(Бюджет:</h4>.-)</p>'})
   

   
  -- for title in string.gmatch(x, '"iframe_url":"(http.-)"') do
   









    for title3  in string.gmatch(x, '"kinopoisk_id":(.-),') do   
      

       url1 = string.gsub(title3, '^(.-)', 'http://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 
 
  --  table.insert(t, {title = 'Hdvb(v2)', mrl = '#stream/q=content&id=' .. url1, image = image})
       -- end
   --  end
   local x = conn:load(url1)
     
       for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   
      local x = conn:load(url2 .. url3)



for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/360/index.m3u8')
    
    --  t['view'] = 'simple'

    table.insert(t, {title = '360p ' .. tolazy(total2), mrl = url4})

end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/480/index.m3u8')
    
   --   t['view'] = 'simple'

    table.insert(t, {title = '480p ' .. tolazy(total2), mrl = url4})
end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/720/index.m3u8')
    
    --  t['view'] = 'simple'

    table.insert(t, {title = '720p ' .. tolazy(total2), mrl = url4})
end

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
    --  t['view'] = 'simple'

    table.insert(t, {title = '1080p ' .. tolazy(total2), mrl = url4})

      end 
   
      end

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
     --  t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end

end


      
   
   
  
        
   
   
      for title in string.gmatch(x, '"kinopoisk_id":(.-),') do   

 --  for title, total in string.gmatch(x,'<h1 class="view%-caption">(.-)смотреть.-Год.-title.->(.-)</a>') do    
   
 --   title = urlencode(title)
      
 --     title = string.gsub(title, '+', '%%20')
	
   
 --  url = string.gsub(title, '^(.-)', 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=') .. '&year=' .. total .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
  
  --   local x = conn:load(url)
     
      
  --  for total1, total2 in string.gmatch(x, 'docs.-{"id":(.-),.-name":"(.-)"') do
    

  
     url1 = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
      local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end
    end
 --   end
    
    
    
    
     for title3  in string.gmatch(x, '"kinopoisk_id":(.-),') do   
 
     table.insert(t, {title = 'Источники', mrl = '#stream/q=video&id=' .. title3})
     end
 
elseif args.q == 'video' then
   
   local x = conn:load('https://api.bhcesh.me/list?token=eedefb541aeba871dcfc756e6b31c02e&kinopoisk_id=' .. args.id)

 
    
     for title, title1, title3 in string.gmatch(x, '"id".-"name":"(.-)".-"year":(.-),.-"kinopoisk_id":"(.-)"') do
    
    title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
title = string.gsub(title, '\\u2116', '№')
     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')

 



   url1 = string.gsub(title, '^(.-)', 'https://lampa.persh1n.ru/lite/kinobase?title=') .. '&year=' .. title1
    --.. '&uid=m7alois3'
   
  -- table.insert(t, {title = url1, mrl = url1})

  
 
     local x = conn:load(url1)
    
      for total in string.gmatch(x, 'videos__movie.-"play".-"url".-/proxy.-class="videos__item%-title">(.-)</div>') do
  
      local x = string.match(x, '"quality":{(.-)}')
    
    for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)') do
  

  total1 = string.gsub(total1, ',"', '')
 
    url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
    --  t['view'] = 'simple'

   table.insert(t, {title = tolazy(total1) .. ' (' .. tolazy(total) .. ')', mrl = url2})

     end  
    end

--https://lampa.persh1n.ru/lite/kinobase?title=%d0%b1%d1%83%d0%bc%d0%b0%d0%b6%d0%bd%d1%8b%d0%b9+%d0%b4%d0%be%d0%bc&year=2017&s=1
  

   
     for url2, total1  in string.gmatch(x, 'videos__season.-"method":"link".-"url".-http.-(/lite.-)".-videos__season%-title">(.-сезон)<') do

     --    url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lampa.persh1n.ru')
    
       
    
      local x = conn:load(url2)

      
       

      for url3, total2 in string.gmatch(x, 'videos__movie selector.-"method":"play".-"url".-(/proxy.-mp4).-class="videos__item%-title">(.-серия)</div>') do
      
 --   local x = string.match(x, '"quality"(.-)}}')
    
  --  for  total3, url3 in string.gmatch(x, '"(.-p)":"http.-(/proxy/.-mp4)"') do
  
 -- total3 = string.gsub(total3, ',"', '')
         
    url3 = string.gsub(url3, '^(.-)', 'https://lampa.persh1n.ru')
    
     --  t['view'] = 'simple'


     

    table.insert(t, {title = total1 .. ' ' .. tolazy(total2), mrl = url3})

    end   
    end
    
     

--http://178.20.46.40:12600/lite/filmix?kinopoisk_id=386

    --  url1 = string.gsub(title3, '^(.-)', 'https://mylam.ru/lite/vdbmovies?kinopoisk_id=') 
     
     
      url1 = string.gsub(title3, '^(.-)', 'http://178.20.46.40:12600/lite/veoveo?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
   
   local x = conn:load(url1)
     
       for  url2, total2 in string.gmatch(x, 'class="videos__item videos__movie.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do

      t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2), mrl = url2})

      end 



     for  url2, total2 in string.gmatch(x, 'class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-сезон)<') do
     
     local x = conn:load(url2)

for total3, url3, total4 in string.gmatch(x, '<div class="videos__item videos__movie.-media="" s=.-e="(.-)".-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)<') do

     t['view'] = 'simple'

    table.insert(t, {title = 'veoveo :' .. tolazy(total2) .. tolazy(total3) .. ' серия' .. tolazy(total4), mrl = url4})

      end 
      end



url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
     t['view'] = 'simple'
				table.insert(t,{title= 'alloha : ' ..  tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end





--  https://lampa.ds220kirill.synology.me

      
     url1 = string.gsub(title3, '^(.-)', 'https://lampa.denello.ru/lite/videodb?kinopoisk_id=')
     --.. '&title=' .. title .. '&year=' .. title1 
  
  
    
      local x = conn:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'https://lampa.denello.ru')
     
     
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'https://lampa.denello.ru') 
       local x = conn:load(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'https://lampa.denello.ru') 
       local x = conn:load(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'https://lampa.denello.ru')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
    



     
     url1 = string.gsub(title3, '^(.-)', 'https://lam.maxvol.pro/lite/vdbmovies?kinopoisk_id=') 
     --.. '&uid=m7alois3'


    local x = conn:load(url1)

       for total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-/proxy.-mp4.-class="videos__item%-title">(.-)</div>') do
  
  
  
      local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-mp4)"') do
      
  url2 = string.gsub(url2, '\\u0026', '&')
     url2 = string.gsub(url2, '\\u002B', '+')
  
            url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro') 
     
    

      t['view'] = 'simple'


   table.insert(t, {title = 'vdbmovies' .. ':'.. tolazy(total1) .. ( total), mrl = url2})

       
    end
    end
    

    
  
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    

      local x = conn:load(url2)

     
      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
  
         url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
    
       
    
     local x = conn:load(url3)
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do
    url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
  
            url4 = string.gsub(url4, '^(.-)', 'https://lam.maxvol.pro') 
     
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end

     



     url1 = string.gsub(title3, '^(.-)', 'https://mylam.ru/lite/filmix?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
  
      local x = conn:load(url1)
      
     for  url3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

   table.insert(t, {title = 'filmix' .. ':'.. tolazy(total2), mrl = url3})

     end  


      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for url5, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'filmix :' .. total .. ' '  .. tolazy(total3) .. total2, mrl = url5})

       
    end

end
end


    



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/remux?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

    local x = conn:load(url1)

    

      for  url2, total in string.gmatch(x, '"url".-(http.-)quality.-class="videos__item%-title">(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      
       url2 = string.gsub(url2, '&', '')
      
      local x = conn:load(url2)
      
       for  url3 in string.gmatch(x, '"play".-"url":.-(http.-)"') do

       t['view'] = 'simple'

   table.insert(t, {title = 'remux :' .. tolazy(total), mrl = url3})

     end  
    end






   
    

    
    
 
 
 
 
 
    url = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&search=') .. '-' .. title1
      --.. '&box_mac=acace24b8434'
			
			
			
			
      local x = conn:load(url .. '&box_mac=acace24b8434' or url .. '&box_mac=b8bc5bf8dea3')

     
     for url1 in string.gmatch(x, 'fxml.-<channel>.-(http.-)]]') do

 --    total1=base64_decode(total1)
     
--     total1 = string.gsub(total1, 'item/', '')


--http://kb-team.club/?do=%2Fplugin&bid=kinofit-kinofit_4k&search=%D1%87%D1%83%D0%B6%D0%BE%D0%B9-1979&box_mac=acace24b8434
       
    local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
     
     
   --   for title in string.gmatch(x, '"id":(.-),') do

    --     print(url)
		 
   --      title = string.gsub(title, '^(.-)', 'item/')
         
      --   title=base64_encode(title)
 

   --    url1 = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=')
       
      
   --    local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')


     
     
     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = total .. (total1), mrl = url2})
    
        end
        end
        end
  
    
url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
    --.. '&rjson=true'

    local x = conn:load(url1)



      for  url2, url3,  total, total1 in string.gmatch(x, '"play".-"url":"(http.-pidtor)(.-)".-class="videos__item%-title">(.-)<.-<!%-%-(.-)%-') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total) .. ' ' .. total1, mrl = url2 .. url3})

       
    end
    
url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 
      


         url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 

    


   
    
    
    

  url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=') 
  --.. '&uid=m7alois3'
    
    
      local x = conn:load(url1)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=') 

    local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vibix :' .. tolazy(total1) .. total2, mrl = url3})

       
    end

end


--https://mylam.ru

      url1 = string.gsub(title3, '^(.-)', 'https://mylam.ru/lite/rezka?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

     local x = conn:load(url1)
 
  
  
       for  url3, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. tolazy(total1), mrl = url3})
  --   end
     end  
  
         local x = conn:load(url1)

     
     for url3, total2  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
     
     url3 = string.gsub(url3, '\\u0026', '&')

     url3 = string.gsub(url3, '\\u002B', '+')

  
     local x = conn:load(url1)

   for url4, total3  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')

     url4 = string.gsub(url4, '\\u002B', '+')
     

      local x = conn:load(url3)

      for url5, total4  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')

     url5 = string.gsub(url5, '\\u002B', '+')
     
    
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. total2 .. ' '  .. tolazy(total3) .. ' ' .. total4, mrl = url5})

       
    end
end
end

end
  

  

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end