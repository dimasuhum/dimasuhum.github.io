-- vk catcast plugin

require('support')
require('video')
require('parser')
require('client')


--https://api.catcast.tv/api/channels/getbyshortname/kinovselennajatv



--https://api.catcast.tv/api/channels/37925/getcurrentprogram

local HOME = 'http://api.catcast.tv'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH






--HOME = 'http://api.catcast.tv'
--https://catcast.tv/player/34816
--https://api.catcast.tv/api/channels?type=tv&count
--http://api.catcast.tv/api/channels/player/34816
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from vk catcast plugin')
	return 1
end

function onUnLoad()
	print('Bye from vk catcast plugin')
end

function onCreate(args)
	local t = {view = 'grid_large', type = 'folder'}
--	t['menu'] = {}
--	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
--	end
	  --  table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2

	if not args.q then


        

         table.insert(t, {title = 'Scream HD', mrl = 'https://nsk19.peers.tv/streaming/scream_hd/16/gvh1w/playlist.m3u8?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJhY2Nlc3MiLCJleHAiOjE2NzgzODQ5NjAsImlhdCI6MTY3ODI5ODU2MCwiY2lkIjo4MSwidWlkIjo1NjM1MTkwNzUsInJlZyI6ZmFsc2UsImlwIjoxNjA0NTc4NjQxfQ.kFH7vzcJ1Aj6m0wITgNWYiQxDMEkxstJLMm8GbciYtE', image = 'https://avatars.mds.yandex.net/i?id=b2507c644aff1b4444fe58e1c3d7835c_l-3891756-images-thumbs&n=13'})

         table.insert(t, {title = 'Кошмар HD', mrl = 'https://ok.ru/videoembed/4488962121424?autoplay=1', image = 'https://avatars.mds.yandex.net/i?id=b2507c644aff1b4444fe58e1c3d7835c_l-3891756-images-thumbs&n=13'})

          local url = 'https://smotret.tv/razvlekatelnye/iframes/good-films.html'
          url = url

		local x = http.getz(url)
        for url in string.gmatch(x, 'var player=new Playerjs.-file.-(http.-)"') do

         table.insert(t, {title = 'good-films', mrl = url, image = 'https://avatars.mds.yandex.net/i?id=b2507c644aff1b4444fe58e1c3d7835c_l-3891756-images-thumbs&n=13'})
		end 
         
  
  
       table.insert(t, {title = '1filmmax-melodrama', mrl = 'https://vk.com/video_ext.php?oid=-179968034&id=456239035&hash=5c4921f785774d13&autoplay=1', image = 'https://avatars.mds.yandex.net/i?id=b2507c644aff1b4444fe58e1c3d7835c_l-3891756-images-thumbs&n=13'})


         
        table.insert(t, {title = '1filmmax-comedy', mrl = 'https://ok.ru/videoembed/4644191084240?autoplay=1', image = 'https://avatars.mds.yandex.net/i?id=b2507c644aff1b4444fe58e1c3d7835c_l-3891756-images-thumbs&n=13'})

       table.insert(t, {title = '1filmmax-fantastika', mrl = 'https://ok.ru/videoembed/3987041558224?autoplay=1', image = 'https://avatars.mds.yandex.net/i?id=b2507c644aff1b4444fe58e1c3d7835c_l-3891756-images-thumbs&n=13'})

      table.insert(t, {title = 'Мульт-Бум', mrl = 'https://vk.com/video_ext.php?oid=-179968034&id=456239020&hash=da2a0a768a8062a8&hd=2&autoplay=1', image = 'https://avatars.mds.yandex.net/i?id=b2507c644aff1b4444fe58e1c3d7835c_l-3891756-images-thumbs&n=13'})

         


       local url = 'https://smotret.tv/razvlekatelnye/iframes/kineko.html'
          url = url

		local x = http.getz(url)
        for url in string.gmatch(x, 'var player=new Playerjs.-file:"(https.-)"') do

         table.insert(t, {title = 'кинеко', mrl = url, image = 'https://avatars.mds.yandex.net/i?id=b2507c644aff1b4444fe58e1c3d7835c_l-3891756-images-thumbs&n=13'})
		end 

		
	
        local url = 'https://smotret.tv/razvlekatelnye/iframe/strah-hd.php'
        url = url

		local x = http.getz(url)
          for url in string.gmatch(x, 'var player=new Playerjs.-file:"(http.-)"') do

         table.insert(t, {title = 'Страх HD', mrl = url, image = 'https://avatars.mds.yandex.net/i?id=b2507c644aff1b4444fe58e1c3d7835c_l-3891756-images-thumbs&n=13'})
		end 
	
        
         
     	local url = 'https://raw.githubusercontent.com/dimasuhum/dimasuhum.github.io/master/catcast.txt'
		
			url = url
			
			
		local x = http.getz(url)
		for url  in string.gmatch(x, '<div class="channel%-item".-<a href="(.-)"') do
		--.-"channel%-item__name">(.-)</div>') do
		
     --   url = string.gsub(url, '^(.-)', 'https://api.catcast.tv/api/channels/getbyshortname')


    --    image = string.gsub(image, '\\', '')
         
	--	  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		
		
		
          local x = conn:load('https://api.catcast.tv/api/channels/getbyshortname' .. url)
		

        for url, title,  image  in string.gmatch(x, 'false,"id":(.-),"data".-"name":"(.-)".-"logo":"(http.-)"') do
    
--https://v2.catcast.tv/content/170962/index.m3u8
--https://autopilot.catcast.tv/mobile.m3u8?channel_id=170962&server=v2.catcast.tv



        url = string.gsub(url, '^(.-)', 'https://api.catcast.tv/api/channels/') .. '/getcurrentprogram'

   --     url = string.gsub(url, '^(.-)', 'http://sp-social.ru/arh/cat1.php?name=')


        image = string.gsub(image, '\\', '')
  title = string.gsub(title, '\\u0410','А')
        title = string.gsub(title, '\\u0430','а')
        title = string.gsub(title, '\\u0411','Б')
title = string.gsub(title, '\\u0431','б')
title = string.gsub(title, '\\u0412','В')
title = string.gsub(title, '\\u0432','в')
title = string.gsub(title, '\\u0413','Г')
title = string.gsub(title, '\\u0433','г')
title = string.gsub(title, '\\u0414','Д')
title = string.gsub(title, '\\u0434','д')
title = string.gsub(title, '\\u0415','Е')
title = string.gsub(title, '\\u0435','е')
title = string.gsub(title, '\\u0401','Ё')
title = string.gsub(title, '\\u0451','ё')
title = string.gsub(title, '\\u0416','Ж')
title = string.gsub(title, '\\u0436','ж')
title = string.gsub(title, '\\u0417','З')
title = string.gsub(title, '\\u0437','з')
title = string.gsub(title, '\\u0418','И')
title = string.gsub(title, '\\u0438','и')
title = string.gsub(title, '\\u0419','Й')
title = string.gsub(title, '\\u0439','й')
title = string.gsub(title, '\\u041a','К')
title = string.gsub(title, '\\u043a','к')
title = string.gsub(title, '\\u041b','Л')
title = string.gsub(title, '\\u043b','л')
title = string.gsub(title, '\\u041c','М')
title = string.gsub(title, '\\u043c','м')
title = string.gsub(title, '\\u041d','Н')
title = string.gsub(title, '\\u043d','н')
title = string.gsub(title, '\\u041e','О')
title = string.gsub(title, '\\u043e','о')
title = string.gsub(title, '\\u041f','П')
title = string.gsub(title, '\\u043f','п')
title = string.gsub(title, '\\u0420','Р')
title = string.gsub(title, '\\u0440','р')
title = string.gsub(title, '\\u0421','С')
title = string.gsub(title, '\\u0441','с')
title = string.gsub(title, '\\u0422','Т')
title = string.gsub(title, '\\u0442','т')
title = string.gsub(title, '\\u0423','У')
title = string.gsub(title, '\\u0443','у')
title = string.gsub(title, '\\u0424','Ф')
title = string.gsub(title, '\\u0444','ф')
title = string.gsub(title, '\\u0425','Х')
title = string.gsub(title, '\\u0445','х')
title = string.gsub(title, '\\u0426','Ц')
title = string.gsub(title, '\\u0446','ц')
title = string.gsub(title, '\\u0427','Ч')
title = string.gsub(title, '\\u0447','ч')
title = string.gsub(title, '\\u0428','Ш')
title = string.gsub(title, '\\u0448','ш')
title = string.gsub(title, '\\u0429','Щ')
title = string.gsub(title, '\\u0449','щ')
title = string.gsub(title, '\\u042a','Ъ')
title = string.gsub(title, '\\u044a','ъ')
title = string.gsub(title, '\\u042b','Ы')
title = string.gsub(title, '\\u044b','ы')
title = string.gsub(title, '\\u042c','Ь')
title = string.gsub(title, '\\u044c','ь')
title = string.gsub(title, '\\u042d','Э')
title = string.gsub(title, '\\u044d','э')
title = string.gsub(title, '\\u042e','Ю')
title = string.gsub(title, '\\u044e','ю')
title = string.gsub(title, '\\u042f','Я')
title = string.gsub(title, '\\u044f','я')
title = string.gsub(title, '\\u00ab','<<')
title = string.gsub(title, '\\u00bb','>>')
title = string.gsub(title, '\\u2014','-')
        
		  table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end
    	end
		
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'

        local x = http.getz(HOME)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
     -- local x = string.match(x, 'каналы.-<ul class="submenu">(.-)</ul>')
        for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
	--	local x = http.getz(HOME1)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
     -- local x = string.match(x, '<ul class="menu">(.-)</nav>')
      --  for genre, title in string.gmatch(x, '<a href="(.-)".->(.-)</a>') do
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
	--	end

	-- #stream/q=content&id=http://tv.tivix.co/24-cartoon-network.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
          t['ref'] = args.id
	
          --x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1>(.-)<span itemprop="name">(.-)</span></h1>')
		t['description'] = parse_match(x, '</h2>.-<p>(.-)</p>')
		--	t['poster'] = args.p
	   t['poster'] = parse_match(x,'<img class="logo%-mobile scale%-with%-grid" src="(.-)"')
	--	if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
	    	t['annotation'] = parse_array(x, {
			'(Оригинальное название</strong>:.-)',
			'(В ролях:</strong>.-)',
			'(Выпущено</strong>:.-)',
			'(Жанр</strong>:.-)<br>',
			'(Режиссер</strong>:.-)<br>'})
			
        
        
        for title, url in string.gmatch(x, '"program_name":"(.-)".-"full_mobile_url":"(http.-)"') do
		
         print(url, title)
        title = string.gsub(title, '\\u0410','А')
        title = string.gsub(title, '\\u0430','а')
        title = string.gsub(title, '\\u0411','Б')
title = string.gsub(title, '\\u0431','б')
title = string.gsub(title, '\\u0412','В')
title = string.gsub(title, '\\u0432','в')
title = string.gsub(title, '\\u0413','Г')
title = string.gsub(title, '\\u0433','г')
title = string.gsub(title, '\\u0414','Д')
title = string.gsub(title, '\\u0434','д')
title = string.gsub(title, '\\u0415','Е')
title = string.gsub(title, '\\u0435','е')
title = string.gsub(title, '\\u0401','Ё')
title = string.gsub(title, '\\u0451','ё')
title = string.gsub(title, '\\u0416','Ж')
title = string.gsub(title, '\\u0436','ж')
title = string.gsub(title, '\\u0417','З')
title = string.gsub(title, '\\u0437','з')
title = string.gsub(title, '\\u0418','И')
title = string.gsub(title, '\\u0438','и')
title = string.gsub(title, '\\u0419','Й')
title = string.gsub(title, '\\u0439','й')
title = string.gsub(title, '\\u041a','К')
title = string.gsub(title, '\\u043a','к')
title = string.gsub(title, '\\u041b','Л')
title = string.gsub(title, '\\u043b','л')
title = string.gsub(title, '\\u041c','М')
title = string.gsub(title, '\\u043c','м')
title = string.gsub(title, '\\u041d','Н')
title = string.gsub(title, '\\u043d','н')
title = string.gsub(title, '\\u041e','О')
title = string.gsub(title, '\\u043e','о')
title = string.gsub(title, '\\u041f','П')
title = string.gsub(title, '\\u043f','п')
title = string.gsub(title, '\\u0420','Р')
title = string.gsub(title, '\\u0440','р')
title = string.gsub(title, '\\u0421','С')
title = string.gsub(title, '\\u0441','с')
title = string.gsub(title, '\\u0422','Т')
title = string.gsub(title, '\\u0442','т')
title = string.gsub(title, '\\u0423','У')
title = string.gsub(title, '\\u0443','у')
title = string.gsub(title, '\\u0424','Ф')
title = string.gsub(title, '\\u0444','ф')
title = string.gsub(title, '\\u0425','Х')
title = string.gsub(title, '\\u0445','х')
title = string.gsub(title, '\\u0426','Ц')
title = string.gsub(title, '\\u0446','ц')
title = string.gsub(title, '\\u0427','Ч')
title = string.gsub(title, '\\u0447','ч')
title = string.gsub(title, '\\u0428','Ш')
title = string.gsub(title, '\\u0448','ш')
title = string.gsub(title, '\\u0429','Щ')
title = string.gsub(title, '\\u0449','щ')
title = string.gsub(title, '\\u042a','Ъ')
title = string.gsub(title, '\\u044a','ъ')
title = string.gsub(title, '\\u042b','Ы')
title = string.gsub(title, '\\u044b','ы')
title = string.gsub(title, '\\u042c','Ь')
title = string.gsub(title, '\\u044c','ь')
title = string.gsub(title, '\\u042d','Э')
title = string.gsub(title, '\\u044d','э')
title = string.gsub(title, '\\u042e','Ю')
title = string.gsub(title, '\\u044e','ю')
title = string.gsub(title, '\\u042f','Я')
title = string.gsub(title, '\\u044f','я')
title = string.gsub(title, '\\u00ab','<<')
title = string.gsub(title, '\\u00bb','>>')
title = string.gsub(title, '\\u2014','-')
        
	url = string.gsub(url, '\\', '')		
            
			t = video(url, args)
			if t['view'] ~= 'error' then
				break
			end
            
			
     --    t['view'] = 'grid'
         table.insert(t, {title = title, mrl = url})

		end
		
		
		
	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end