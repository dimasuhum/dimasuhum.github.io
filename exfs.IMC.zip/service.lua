-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://ex-fs.net'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/country/СССР/
	-- #stream/genre=/country/Индия/
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/genre/боевик
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/url=/show/
    -- #stream/genre=/show/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/films/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		
		
        
	--	local x = http.getz(url)
	
        local x = conn:load(url)
		
   
   
       for url, image, title, total in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/films.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<.-class="MiniPostInfo".-<a href.->(.-)<') do

			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title) .. '(' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
   
   
        if genre == '/series/' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
        end
        end
   
        local x = conn:load(url)
   
        for url, image, title, total in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/series.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<.-class="MiniPostInfo".-<a href.->(.-)<') do

			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title) .. '(' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
		
		
		if genre == '/cartoon/' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
        end
		end
   
        local x = conn:load(url)
   
   
        for url, image, title, total in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/cartoon.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<.-class="MiniPostInfo".-<a href.->(.-)<') do

			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title) .. '(' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
   
   
   
         if genre == '/show/' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
        end
		end
		
   
        local x = conn:load(url)
   
   
        for url, image, title, total in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/show.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<.-class="MiniPostInfo".-<a href.->(.-)<') do

			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title) .. '(' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
         



         for url, image, title in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/actors.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<') do


     --     for url, title in string.gmatch(x, '<div class="MiniPostName".-<a href=".-(/actors.-html)".-title="(.-)"') do

      --   t['view'] = 'simple'

			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end

   
   

   
    	for url, image, title in string.gmatch(x, '<div class="MiniPostAct".-<a href="(.-)".-<img src=.-src=(http.-jpg).-class="MiniPostNameAct".-<a href.->(.-)<') do

		--	image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end	
	
	
         for url, title in string.gmatch(x, '<td class="alldoppole_td1".-<a href="https://.-(/.-)" title="Просматреть все кинопосты.->(.-)</a>') do 
         
         t['view'] = 'simple'

			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end


--<td class="alldoppole_td1"><a href="https://ex-fs.net/year/2004/" title="Просматреть все кинопосты 2004 года">2004</a>

		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
   --    table.insert(t, {title = 'Актёры', mrl = '#stream/genre=' .. '/actors/'})
		
		local x = conn:load(HOME)
		
		
		local x = string.match(x, '<ul class="nav pt pull%-left".-<ul id="six" class="submenu">(.-)</ul>')
    	for genre, title in string.gmatch(x, '<li><a href="(.-)">(.-)<') do
        	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end


         local x = conn:load(HOME)
		
		
		local x = string.match(x, '<a href="/films/".-<ul id="six" class="submenu">(.-)<form class="SearchForm"')
		
         for genre, title in string.gmatch(x, '<li><a href="(.-)">(.-)<') do
        	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="SeaRchresultPost".-href="(.-)".-<img src=.-src=(http.-jpg).-class="SeaRchresultPostTitle".-href=.->(.-)<') do
      --   url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
		local x = conn:load(args.id)
	
		
       -- x = string.gsub(x, 'onclick', '')
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x, '<div class="FullstorySubFormTitle".-Сюжет:.-class="FullstorySubFormText">(.-)</div>')
		--	t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="FullstoryFormLeft".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			

			
			
			
	    	t['annotation'] = parse_array(x, {
			'(Оригинальное название:</h4>.-)</p>',
			'(Год:</h4>.-)</p>',
			'(Страна:</h4>.-)</p>',
			'(Жанр:</h4>.-)</p>',
			'(Перевод:</h4>.-)</p>',
			'(Качество:</h4>.-)</p>',
			'(Время:</h4>.-)</p>',
			'(Бюджет:</h4>.-)</p>'})
   
   
   
   
--chromecast: "https://hye1eaipby4w.takedwn.ws/01_13_23/01/13/17/T26L6IMP/J5KTEQ75.mp4/master.m3u8?chromecast"
        
        for url in string.gmatch(x, 'id="tab6".-<iframe src="(https://api.-)".-</iframe') do

			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end
		
		
        for url in string.gmatch(x, 'id="tab8".-<iframe src="(.-)"') do
          print(url)
		 url = string.gsub(url, '^(.-)', 'http://smartportaltv.ru/0/index.php?url=')

			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end
		
		
		
        for url in string.gmatch(x, 'id="tab10".-<iframe src="(https://api.-)".-</iframe') do

			table.insert(t, {title = 'Трейлер', mrl = '#stream/q=content&id=' .. url})
		end


--https://950-8ca-2500g0.streamalloha.live/hs/49/1674942766/4694jqFHTgroSr9A8O1Smg/623/705623/index-f1-v1-f4-a1.m3u8

         for title, url in string.gmatch(x, '<title>.-CDATA(.-])].-<stream_url.-CDATA.-(http.-m3u8)') do
         
         t['view'] = 'simple'
         
         
        url = string.gsub(url, 'master', 'index-f1-v1-f4-a1')
         table.insert(t, {title = title, mrl = url})
       --   addvideo(t, url, t['name'], titles, id)
          
        end



        for title, url, total in string.gmatch(x, '<title.-CDATA(.-])].-<playlist_url.-(http.-)].-</br.-</br.-</br>(.-)</center>') do
         t['view'] = 'simple'
          table.insert(t, {title = tolazy(title) .. tolazy(total), mrl = '#stream/q=content&id=' .. url})
        end










       for title, url in string.gmatch(x, 'title: "(.-)".-hls: "(https://.-m3u8)"') do
        --	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url .. '?chromecast'})
        end

     	for url, title in string.gmatch(x, '"hls":"(https.-m3u8)".-"title":"(.-)"') do

			print(url)
        t['view'] = 'simple'
      --  t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url .. '?chromecast'})
        end	
       for title, url, total in string.gmatch(x, '"episode".-"hlsList".-"(.-)".-(https.-)".-"title".-"(.-)"') do

			print(url)
        t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url .. '?chromecast'})
        end
		
		for title, url, total in string.gmatch(x, '"episode".-"hlsList".-,"(.-)".-(https.-)".-"title".-"(.-)"') do
			print(url)
         t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url .. '?chromecast'})
        end

        
         
			
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url .. '?chromecast'})
        end
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-,"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url .. '?chromecast'})
        end

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end