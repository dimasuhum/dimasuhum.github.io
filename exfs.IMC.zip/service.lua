-- EX-FS plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--https://api.embess.ws/embed/movie/486

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'





local HOME = 'https://ex-fs.net'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



function onLoad()
	print('Hello from ex-fs plugin')
	return 1
end

function onUnLoad()
	print('Bye from ex-fs plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/genre=/year/2020/
	-- #stream/genre=/country/СССР/
	-- #stream/genre=/country/Индия/
    -- #stream/url=/country/%D0%98%D0%BD%D0%B4%D0%B8%D1%8F/
	-- #stream/genre=/series/
	-- #stream/genre=/films/
    -- #stream/genre=/cartoon/
    -- #stream/genre=/genre/боевик
    -- #stream/genre=/director/
    -- #stream/genre=/actors/
    -- #stream/genre=/actors/13430-nikolas-keydzh.html
    -- #stream/url=/series/
    -- #stream/url=/cartoon/
    -- #stream/url=/films/
    -- #stream/url=/genre/%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0/
    -- #stream/url=/show/
    -- #stream/genre=/show/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/film/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
		end
		
		
        
	--	local x = http.getz(url)
	
        local x = conn:load(url)
		
     
   
       for url, image, title, total in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/film.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<.-class="MiniPostInfo".-<a href.->(.-)<') do

			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
   
   
        if genre == '/serial/' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
        end
        end
   
        local x = conn:load(url)
   
        for url, image, title, total in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/serial.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<.-class="MiniPostInfo".-<a href.->(.-)<') do

			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title) .. '(' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
		
		
		if genre == '/multfilm/' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
        end
		end
   
        local x = conn:load(url)
   
   
        for url, image, title, total in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/multfilm.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<.-class="MiniPostInfo".-<a href.->(.-)<') do

			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title) .. '(' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
   
   
   
         if genre == '/tv-show/' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
        end
		end
		
   
        local x = conn:load(url)
   
   
        for url, image, title, total in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/tv-show.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<.-class="MiniPostInfo".-<a href.->(.-)<') do

			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title) .. '(' .. total .. ')', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
         



         for url, image, title in string.gmatch(x, '<div class="MiniPost".-<a href=.-(/actors.-html).-src=(http.-jpg).-class="MiniPostName".-<a href=.->(.-)<') do


     --     for url, title in string.gmatch(x, '<div class="MiniPostName".-<a href=".-(/actors.-html)".-title="(.-)"') do

      --   t['view'] = 'simple'

			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end

   
   

   
    	for url, image, title in string.gmatch(x, '<div class="MiniPostAct".-<a href="(.-)".-<img src=.-src=(http.-jpg).-class="MiniPostNameAct".-<a href.->(.-)<') do

		--	image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end	
	
	
         for url, title in string.gmatch(x, '<td class="alldoppole_td1".-<a href="https://.-(/.-)" title="Просматреть все кинопосты.->(.-)</a>') do 
         
         t['view'] = 'simple'

			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end


--<td class="alldoppole_td1"><a href="https://ex-fs.net/year/2004/" title="Просматреть все кинопосты 2004 года">2004</a>

		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
   --    table.insert(t, {title = 'Актёры', mrl = '#stream/genre=' .. '/actors/'})
		
		local x = conn:load(HOME)
		
		
		local x = string.match(x, 'Категории.-<ul id="six" class="submenu">(.-)</ul>')
    	for genre, title in string.gmatch(x, '<li><a href="(.-)">(.-)<') do
        	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = 'Категории' .. ': ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
		end


         local x = conn:load(HOME)
		
		
		local x = string.match(x, 'Фильмы.-<ul id="six" class="submenu">(.-)</ul>')
		
         for genre, title in string.gmatch(x, '<li><a href="(.-)">(.-)<') do
        	genre=http.urldecode(urlencode(genre))
--urlencode
			table.insert(t, {title = 'Фильмы' .. ': ' .. tolazy(title), mrl = '#stream/genre=' .. genre})
			end
			
			table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serials/'})
			
		table.insert(t, {title = 'Мультфильмы', mrl = '#stream/genre=' .. '/multfilm/'})
		
        table.insert(t, {title = 'Передачи и шоу', mrl = '#stream/genre=' .. '/tv-show/'})
			
			
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)


		local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<div class="SeaRchresultPost".-href="(.-)".-<img src=.-src=(http.-jpg).-class="SeaRchresultPostTitle".-href=.->(.-)<') do
      --   url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
  
        
	-- #stream/q=content&id=http://ex-fs.net/show/100767-lenoks-hill.html
    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
	--	local x = conn:load(args.id)
    	local x = http.getz(args.id)
		
       -- x = string.gsub(x, 'onclick', '')
		--print(x)
        -- t['ref'] = HOME .. args.id
		 t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)смотреть онлайн</h1>')
		t['description'] = parse_match(x, '<div class="FullstorySubFormTitle".-Сюжет:.-class="FullstorySubFormText">(.-)</div>')
		--	t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="FullstoryFormLeft".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			

			
			
			
	    	t['annotation'] = parse_array(x, {
			'(Оригинальное название:</h4>.-)</p>',
			'(Год:</h4>.-)</p>',
			'(Страна:</h4>.-)</p>',
			'(Жанр:</h4>.-)</p>',
			'(Перевод:</h4>.-)</p>',
			'(Качество:</h4>.-)</p>',
			'(Время:</h4>.-)</p>',
			'(Бюджет:</h4>.-)</p>'})
   
   

   
   
         
  
  
   
   
        for url  in string.gmatch(x, 'kinopoiskID: "(.-)"') do
   
		 print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Zagonka плеер', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-(//video.zagonka.org/movies/.-})') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-(//video.zagonka.org/movies/.-})') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
           url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
			
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
		
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
         url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-(//video.zagonka.org/tvseries/.-}),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
		
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-(//video.zagonka.org/tvseries/.-})".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
          url = string.gsub(url, '{v1}', '.mp4')
          
          
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
    
       
        
        
    end
   
   
   
   
   
   
  
        for url  in string.gmatch(x, 'kinopoiskID: "(.-)"') do
   
   
      url = string.gsub(url, '^(.-)', 'https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=')
    --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
       local x = http.getz(url)
   

   
       for title, url  in string.gmatch(x, 'url.-http.-kinovibe.co.-%-(.-).html.-embed.-(http.-)"') do
   
       url = string.gsub(url, '\\', '')
   
       title = string.gsub(title, 'series', '')
         
    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})

       end
       end
   

        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
         
        t['view'] = 'simple'
         
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
     
         t['view'] = 'simple'
     
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
         t['view'] = 'simple'
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end



		
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-id:"playerjshd".-file:"(.-txt)"') do
         -- print(url)
      --    t['view'] = 'grid'
       --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' ..  url})
    --table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})
--		end

       local x = http.getz(url)



           for title, url in string.gmatch(x, '"comment":"(.-)".-file.-(https://s.-mp4)"') do
			print(url)  

          url = string.gsub(url, '_[480,720]', '')
          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title), mrl = url})
        end



		for title, url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do

          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title) .. ' (480p)'  , mrl = url .. url1 .. '_480.mp4'})
   

        end
	
	
          for title,  url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do
		--	print(url)  

      --    url = string.gsub(url, '(.-)', url) .. '_720.mp4'
          t['view'] = 'grid'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title) .. ' (720p)', mrl = url .. url1 .. '_720.mp4'})
   
   --     table.insert(t, {title = tolazy(title) .. (total), mrl = url})
        end
	
      end
   
   
   
   
   
   

   
   
   
       for title, total in string.gmatch(x,'<h1 class="view%-caption">(.-)смотреть.-Год.-title.->(.-)</a>') do    
   
    title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')
	
	
	url = string.gsub(title, '^(.-)', 'https://torrs.ru/search?query=') .. '(' .. total .. ')'
    
     
     table.insert(t, {title = 'Источники', mrl = '#stream/q=content&id=' .. url, image = image})
         end

   
   
   
   
   for title, title1 in string.gmatch(x, '%[{"size".-"name":"(.-)".-"relased":(.-),') do

     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')


    --   title1 = urlencode(title1)
      
   --   title1 = string.gsub(title1, '+', '%%20')
        url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/http://kinopoisk.ru/?id=search&search=') .. '+'  .. '(' .. title1 .. ')'
  
         local x = conn:load(url)
    
     
       for title3  in string.gmatch(x, '"fxml".-playlist_url.-?id=info&cid=(.-)"') do

         url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 

      
         local x = conn:load(url1)

   
   
   
       for  url2, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :' .. tolazy(total2), mrl = url2})

      end 
 
     
  

      
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. total3, mrl = url4})

       
    end

end
end





      url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/fancdn?kinopoisk_id=')
      --.. '&uid=m7alois3'
    
    
      local x = conn:load(url1)
   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url1 = string.gsub(url1, '\\u0026', '&')
  --  url1 = string.gsub(url1, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'


 --   table.insert(t, {title = url2, mrl = url2})

   table.insert(t, {title = 'fancdn :' .. tolazy(total), mrl = url2})

       
    end

    
     
     
     
     

      url1 = string.gsub(title3, '^(.-)', 'http://93.183.92.183:9118/lite/fancdn?kinopoisk_id=') .. '&uid=m7alois3'
    
     local x = conn:load(url1)
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
    
       
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://93.183.92.183:9118')
    
       
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://93.183.92.183:9118')
    
       t['view'] = 'simple'


     

    table.insert(t, {title = 'fancdn :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end   
    end
    end








    url1 = string.gsub(title3, '^(.-)', 'http://93.183.92.183:9118/lite/lumex?kinopoisk_id=') .. '&uid=m7alois3'
    
    
    local x = conn:load(url1)
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/lite.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
       t['view'] = 'simple'

   table.insert(t, {title = 'lumex :' .. tolazy(total), mrl = url2})

       
    end
     

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://93.183.92.183:9118')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'http://93.183.92.183:9118')
    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://93.183.92.183:9118')
    
  --    url4 = string.gsub(url4, 'rjson=False&', '')
    
    
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end





   --    title1 = string.gsub(title1, '%%20', '-')

    url1 = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&search=') .. '-' .. title1
     
     url1 = string.gsub(url1, '%%20', '-')
     
     
     --.. '&box_mac=acace24b8434'
			
	
		   local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')


     for total1 in string.gmatch(x, 'fxml.-<channel>.-http.-&goto=(.-)]]') do




    total1=base64_decode(total1)
     
    total1 = string.gsub(total1, 'item/', '')
     
  

  
     url2 = string.gsub(total1, '^(.-)', 'https://api.manhan.one/rc/filmix?postid=')
  
  
        local x = conn:load(url2)
      
     for  url3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

   table.insert(t, {title = 'filmix' .. ':'.. tolazy(total2), mrl = url3})

     end  


      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url4)


      for url5, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'filmix :' .. total .. ' '  .. tolazy(total3) .. total2, mrl = url5})

       
    end

end
end
end








    url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title='alloha' .. ':' .. tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
      t['view'] = 'simple'
				table.insert(t,{title= 'alloha :' .. tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end






     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/zetflix?kinopoisk_id=') 

    
       local x = conn:load(url1)
   
   
   for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total), mrl = url2})

       
    end
    
    
    
        for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn:load(url3)


      for url4, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end






  url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=') .. '&uid=m7alois3'
    
    
      local x = conn:load(url1)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=') 

    local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total1) .. total2, mrl = url3})

       
    end

end


        url1 = string.gsub(title, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=') .. '+' .. title1 .. '+'
	
    	 local x = conn:load(url1)
      
      	for url2 in string.gmatch(x, '<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn:load(url2)
    
    
    for total, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<logo.-<!%[CDATA%[.-</logo.-<description><!%[CDATA%[.-</description>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	
	     local x = conn:load(url3)
	     
	     for total1, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. total1 .. ' ' .. total, mrl = url4, image = image})
         end
	     end
    end
    	




end
end
    
   
   
   
   
   
   
   
   
   --    for title in string.gmatch(x, 'kinopoiskID: "(.-)"') do
        
     --    url = string.gsub(title, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=')
    
     --  table.insert(t, {title = 'Источники', mrl = '#stream/q=content&id=' .. url})
    
    --   end
    
    
           for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   
      --   for url  in string.gmatch(x, 'kinopoiskID: "(.-)"') do

         url = string.gsub(url, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=')



      --   url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=')

    --    url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=0&kinopoisk_id=')
    
    --    table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
    
     --   end

      local x =  http.getz(url)
       
    
      
       
       for total, url, title in string.gmatch(x, '"method":"play","url".-(1080p).-(http.-)".-class="videos__item%-title">(.-)<') do
       
   --    local title = json.decode(title)
   --    print(title)
       
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
			
			
      for total, url, title in string.gmatch(x, '"method":"play","url".-(720p).-(http.-)".-class="videos__item%-title">(.-)<') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
   
      for total, url, title in string.gmatch(x, '"method":"play","url".-(480p).-(http.-)".-class="videos__item%-title">(.-)<') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for total, url, title in string.gmatch(x, '"method":"play","url".-(360p).-(http.-)".-class="videos__item%-title">(.-)<') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end
--end
        
        
          for url2  in string.gmatch(x, 'current_page".-"data":%[{"id.-"kinopoisk_id":(.-),') do
       

        url = string.gsub(url2, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=22&kid=')
       
        local x = http.getz(url)


       for title, url3 in string.gmatch(x, '\'title\': \'(Season) (.-)\',') do


        local x = http.getz('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)
  
  
     
      
   --   local x = http.getz('https://bwa-cloud.apn.monster/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)


  
        for url5, total5  in string.gmatch(x, 'method":"link".-(&t=.-)".->(.-)</div>') do


       local x = http.getz('http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3 .. url5)



       for url4, total2  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do

        total2 = string.gsub(total2, '\\u0441\\u0435\\u0440\\u0438\\u044F', 'серия')

       t['view'] = 'simple'
   
   

      table.insert(t, {title = title .. ' ' .. url3 .. (total2) .. (total5), mrl = url4})
    

	end
    end
    end
    end
         
   
   
   
   
         
  
  

  

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end