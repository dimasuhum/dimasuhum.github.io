-- tvshare plugin

require('support')
require('video')
require('parser')

--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'

TV_URL = 'http://epgtut.tk/epg.xml.gz,https://epg.sky-high.fun/epgnew/epg_full.xml,http://sh3304149.c.had.su/epg/xmltv.xml.gz'

TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

PASS = '7777'

local lockpass

--http://4k.pixel-tv.ru/
--HOME = 'http://tvshare.xyz'
HOME = 'http://4k.pixel-tv.ru'

HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from tvshare plugin')
	return 1
end

function onUnLoad()
	print('Bye from tvshare plugin')
end

function onCreate(args)

if not args.q and args.keyword then
lockpass = args.keyword
end

if lockpass == PASS then
else
return {view="keyword",message="enter access code"}
end


--http://7818d3af2a5e.akciatv.org/playlists/uplist/18a36304f0e0babbf62c6f9de232fa24/playlist.m3u8

	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

	-- #stream/genre=?do=/fml&bid=393-1_m3u8

	if not args.q then


		local genre = args.genre or '/?do=/fml&bid=393-1_m3u8'
		
		
		if genre == '/?do=/fml&bid=393-1_m3u8' then
		local url = HOME .. genre
		
			url = url 
		end	
		
		local url = HOME .. genre
		
			url = url 
	
		local x = http.getz(url)
         

		for  url, title in string.gmatch(x, '<a id=\'ch.-href=.-show_player.-(http.-m3u8)".->(.-)</a>') do
 
   --      url = string.gsub(url, '^(.-)', 'http://tvshare.ottrast.com')
    --     url = string.gsub(url, '4M2QW6FNNVPBNV', 'XMMNV9GLGD7QHV')
         
          local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(title)
			table.insert(t, {title = title, mrl = url, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})


		end





	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


    --    local x = http.getz(HOME)

    --    local x = string.match(x, '<ul class="sf%-menu">(.-)</ul>')
     --   for genre, title in string.gmatch(x, '<img onerror=.-<a href="http://4k.pixel%-tv.ru(/.-)">(.-)</a>') do
	--		table.insert(t, {title = HOME .. genre, mrl = '#stream/genre=' .. genre})
--		end



--http://4k.pixel-tv.ru/?do=/fml&bid=396-4_m3u8
--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=R9GE8NWD8ZUR3X


--http://4k.pixel-tv.ru/?do=/fml&bid=395-3_m3u8
--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=4QVM6BYGGAY5DE



--http://4k.pixel-tv.ru/?do=/fml&bid=394-2_m3u8

--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=NEU5946P95537K



--http://4k.pixel-tv.ru/?do=/fml&bid=393-1_m3u8

--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=3ZWD4NP4DZXGFE





--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=4M2QW6FNNVPBNV


--<a href="http://4k.pixel-tv.ru/?do=/fml&bid=395-3_m3u8"> 3.m3u8</a>



        table.insert(t, {title = 'Tv', mrl = 'm3u+' .. 'http://7818d3af2a5e.akciatv.org/playlists/uplist/18a36304f0e0babbf62c6f9de232fa24/playlist.m3u8'})


       table.insert(t, {title = 'Tv1', mrl = 'm3u+' .. 'http://42e9f50e7f8d.faststreem.org/playlists/uplist/ba01bf4d5b024a1a9246b30ae819403e/playlist.m3u8'})

       table.insert(t, {title = 'Tv2', mrl = 'm3u+' .. 'http://759da4410d50.akciatv.org/playlists/uplist/91a1c6979591cb48b14943d68ee2e7c2/playlist.m3u8'})

       table.insert(t, {title = 'Tv3', mrl = 'm3u+' .. 'http://22e4aa8ee0a6.akciatv.org/playlists/uplist/7566b5348008050134d7a8e987cdaf02/playlist.m3u8'})

       
  
  
  
       

--http://tvshare.ottrast.com/iptv/BVUQ8NGMAULPM3/11037/index.m3u8

--http://5dbec566.megogo.xyz/iptv/4M2QW6FNNVPBNV/19184/index.m3u8&quot;,1,4

--XMMNV9GLGD7QHV



	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end