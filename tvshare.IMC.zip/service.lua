-- tvshare plugin

require('support')
require('video')
require('parser')

--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'

TV_URL = 'https://iptvx.one/epg/epg.xml.gz, http://epg.it999.ru/edem.xml.gz'

TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

PASS = '7777'

local lockpass


--HOME = 'http://tvshare.xyz'
HOME = 'http://4k.pixel-tv.ru'

HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from tvshare plugin')
	return 1
end

function onUnLoad()
	print('Bye from tvshare plugin')
end

function onCreate(args)

if not args.q and args.keyword then
lockpass = args.keyword
end

if lockpass == PASS then
else
return {view="keyword",message="enter access code"}
end




	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end



	if not args.q then


		local genre = args.genre or '/?do=/fml&bid=391-playlist_m3u8'
		local url = HOME .. genre
		
			url = url 
	
		local x = http.getz(url)
         

		for  url, title, image in string.gmatch(x, '<a id=\'ch.-href=.-"http.-(/iptv.-m3u8)".->(.-)</a>.-background:url.-(http.-jpg)') do
 
         url = string.gsub(url, '^(.-)', 'http://tvshare.ottrast.com')
         url = string.gsub(url, '4M2QW6FNNVPBNV', 'XMMNV9GLGD7QHV')
         
          local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(title)
			table.insert(t, {title = title, mrl = url, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})


		end






	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
	

        table.insert(t, {title = 'Russia', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia.IMC.zip'})
        
        
        table.insert(t, {title = 'Belarus', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Belarus.IMC.zip'})

        table.insert(t, {title = 'Ukraine', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Ukraine.IMC.zip'})
        table.insert(t, {title = 'Russia-Federal', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Federal.IMC.zip'})

        
        table.insert(t, {title = 'Russia-Cinema', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Cinema.IMC.zip'})

        table.insert(t, {title = 'Russia-Horror', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Horror.IMC.zip'})

        table.insert(t, {title = 'Russia-Serials', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Serials.IMC.zip'})
        

        table.insert(t, {title = 'Music', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Music.IMC.zip'})


        table.insert(t, {title = 'Sport', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Sport.IMC.zip'})
        
        table.insert(t, {title = 'Russia-4K', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-4K.IMC.zip'})

        
        table.insert(t, {title = 'Russia-FUN', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-FUN.IMC.zip'})

        
        table.insert(t, {title = 'Russia-Kids', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Kids.IMC.zip'})

        
        table.insert(t, {title = 'Russia-News', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-News.IMC.zip'})

        
        table.insert(t, {title = 'Russia-Regional', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Regional.IMC.zip'})
        
        table.insert(t, {title = 'XXX', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/XXX.IMC.zip'})
        
--http://78.129.228.178/iptv/28TS7EKCRM2KMV/871/index.m3u8

--http://tvshare.ottrast.com/iptv/BVUQ8NGMAULPM3/11037/index.m3u8

--http://5dbec566.megogo.xyz/iptv/4M2QW6FNNVPBNV/19184/index.m3u8&quot;,1,4

--XMMNV9GLGD7QHV



	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end