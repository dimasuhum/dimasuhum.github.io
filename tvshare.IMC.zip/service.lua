-- tvshare plugin

require('support')
require('video')
require('parser')

--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'

TV_URL = 'http://epgtut.tk/epg.xml.gz,https://epg.sky-high.fun/epgnew/epg_full.xml,http://sh3304149.c.had.su/epg/xmltv.xml.gz'

TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

PASS = '7777'

local lockpass

--http://4k.pixel-tv.ru/
--HOME = 'http://tvshare.xyz'
HOME = 'http://4k.pixel-tv.ru'

HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from tvshare plugin')
	return 1
end

function onUnLoad()
	print('Bye from tvshare plugin')
end

function onCreate(args)

if not args.q and args.keyword then
lockpass = args.keyword
end

if lockpass == PASS then
else
return {view="keyword",message="enter access code"}
end




	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

	-- #stream/genre=?do=/fml&bid=393-1_m3u8

	if not args.q then


		local genre = args.genre or '/?do=/fml&bid=393-1_m3u8'
		
		
		if genre == '/?do=/fml&bid=393-1_m3u8' then
		local url = HOME .. genre
		
			url = url 
		end	
		
		local url = HOME .. genre
		
			url = url 
	
		local x = http.getz(url)
         

		for  url, title in string.gmatch(x, '<a id=\'ch.-href=.-show_player.-(http.-m3u8)".->(.-)</a>') do
 
   --      url = string.gsub(url, '^(.-)', 'http://tvshare.ottrast.com')
    --     url = string.gsub(url, '4M2QW6FNNVPBNV', 'XMMNV9GLGD7QHV')
         
          local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(title)
			table.insert(t, {title = title, mrl = url, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})


		end






	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


    --    local x = http.getz(HOME)

    --    local x = string.match(x, '<ul class="sf%-menu">(.-)</ul>')
     --   for genre, title in string.gmatch(x, '<img onerror=.-<a href="http://4k.pixel%-tv.ru(/.-)">(.-)</a>') do
	--		table.insert(t, {title = HOME .. genre, mrl = '#stream/genre=' .. genre})
--		end



--http://4k.pixel-tv.ru/?do=/fml&bid=396-4_m3u8
--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=R9GE8NWD8ZUR3X


--http://4k.pixel-tv.ru/?do=/fml&bid=395-3_m3u8
--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=4QVM6BYGGAY5DE



--http://4k.pixel-tv.ru/?do=/fml&bid=394-2_m3u8

--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=NEU5946P95537K



--http://4k.pixel-tv.ru/?do=/fml&bid=393-1_m3u8

--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=3ZWD4NP4DZXGFE






--https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=4M2QW6FNNVPBNV


--<a href="http://4k.pixel-tv.ru/?do=/fml&bid=395-3_m3u8"> 3.m3u8</a>



        table.insert(t, {title = 'Tv', mrl = 'm3u+' .. 'https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=4M2QW6FNNVPBNV'})


       table.insert(t, {title = 'Tv1', mrl = 'm3u+' .. 'https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=3ZWD4NP4DZXGFE'})

       table.insert(t, {title = 'Tv2', mrl = 'm3u+' .. 'https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=NEU5946P95537K'})

       table.insert(t, {title = 'Tv3', mrl = 'm3u+' .. 'https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=4QVM6BYGGAY5DE'})

       
  
  
  
       table.insert(t, {title = 'Tv4', mrl = 'm3u+' .. 'https://sh1708063.b.had.su/ParsXML/Edem-m3u.php?key=R9GE8NWD8ZUR3X'})


        table.insert(t, {title = 'RuTv', mrl = 'https://raw.githubusercontent.com/dimasuhum/dimasuhum.github.io/master/IPTVtest.m3u'})	


        table.insert(t, {title = 'Russia', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia.IMC.zip'})
        
        
        table.insert(t, {title = 'Belarus', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Belarus.IMC.zip'})

        table.insert(t, {title = 'Ukraine', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Ukraine.IMC.zip'})
        table.insert(t, {title = 'Russia-Federal', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Federal.IMC.zip'})

        
        table.insert(t, {title = 'Russia-Cinema', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Cinema.IMC.zip'})

        table.insert(t, {title = 'Russia-Horror', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Horror.IMC.zip'})

        table.insert(t, {title = 'Russia-Serials', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Serials.IMC.zip'})
        

        table.insert(t, {title = 'Music', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Music.IMC.zip'})


        table.insert(t, {title = 'Sport', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Sport.IMC.zip'})
        
        table.insert(t, {title = 'Russia-4K', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-4K.IMC.zip'})

        
        table.insert(t, {title = 'Russia-FUN', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-FUN.IMC.zip'})

        
        table.insert(t, {title = 'Russia-Kids', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Kids.IMC.zip'})

        
        table.insert(t, {title = 'Russia-News', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-News.IMC.zip'})

        
        table.insert(t, {title = 'Russia-Regional', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/Russia-Regional.IMC.zip'})
        
        table.insert(t, {title = 'XXX', mrl = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/XXX.IMC.zip'})
        
--http://78.129.228.178/iptv/28TS7EKCRM2KMV/871/index.m3u8

--http://tvshare.ottrast.com/iptv/BVUQ8NGMAULPM3/11037/index.m3u8

--http://5dbec566.megogo.xyz/iptv/4M2QW6FNNVPBNV/19184/index.m3u8&quot;,1,4

--XMMNV9GLGD7QHV



	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end