-- Edem plugin

require('support')
require('video')
require('parser')


function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)
	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

	if not args.q then

		local url = 'https://sh1708063.b.had.su/ParsXML/hls/Edem/full-pls-free.php#.m3u'

			url = url
			
		local x = http.getz(url)

		for image, title, url in string.gmatch(x, '"Хорватия | Croatia".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end



	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end