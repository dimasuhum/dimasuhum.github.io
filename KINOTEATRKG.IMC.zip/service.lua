-- kinoteatr.kg plugin

require('support')
require('video')
require('parser')

HOME = 'https://kinoteatr.kg'

HOME1 = 'https://doc.kinoteatr.kg'
HOME_SLASH = HOME .. '/'
HOME_SLASH1 = HOME1 .. '/'
function onLoad()
	print('Hello from kinoteatr.kg plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinoteatr.kg plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	    table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	-- #stream/page=1
	-- #stream/page=2
	
	
	
	
	
	-- #stream/genre=/index.php/category/view?id=1
	-- #stream/genre=/index.php/category/mult?id=1
	if not args.q then
    
		local page = tonumber(args.page or 1)
        local genre = args.genre or '/index.php/film/index'

		local url = HOME .. genre
        if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		
		
        if page > 1 then
			url = url .. '&page=' .. tostring(page)
		end
        if page > 1 then
			url = url .. '&page=' .. tostring(page) .. '&per-page=100'
		end
        if page > 1 then
			url = url .. '&page=' .. tostring(page) .. '?per-page=24'
		end
        if page > 1 then
			url = url .. '&page=' .. tostring(page) .. '&per-page=12'
		end
        if page > 1 then
			url = url .. '&page=' .. tostring(page) .. '&per-page=30'
		end
        if page > 1 then
			url = url .. '&page=' .. tostring(page) .. '&per-page=18'
		end
        if page > 1 then
			url = url .. '?page=' .. tostring(page) .. '?per-page=18'
		end
		
		
		
		
	--	if genre == '/index.php/category/mult?id=1' then
 --       local url = HOME .. genre
	--	if page > 1 then
	--		url = url .. '&page=' .. tostring(page) .. '&per-page=21'
--http://kinoteatr.kg/index.php/category/mult?id=1&page=2&per-page=21
			
	--	end
--		end
    --	local x = http.getz(url)
--		for url, image, title  in string.gmatch(x, '<div class=" card   bg%-danger ".-<a href="(/index.php/.-)".-<img.-src="(.-)".-<h6 class="  text%-white text%-center pt%-2".->(.-)<') do
	--		url = string.gsub(url, '^/', HOME_SLASH)
        --    image = string.gsub(image, '^/', HOME_SLASH)
        --    image = string.gsub(image, ' ', '%%20')
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
    --    local x = http.getz(url)
		
    --    for url, image, title  in string.gmatch(x, '<div class="card%-body".-<a href="(.-)".-<img.-src="(.-)".-class="card%-title text%-danger".-<b>(.-)</b') do
	--		url = string.gsub(url, '^/', HOME_SLASH)
      --      image = string.gsub(image, '^/', HOME_SLASH)
       --     image = string.gsub(image, ' ', '%%20')
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		
        local x = http.getz(url)
		

             
		for url, image, title  in string.gmatch(x, '<div class="card".-<a href="(/index.php.-)".-<img.-src="(.-)" alt="(.-)"') do
			url = string.gsub(url, '^/', HOME_SLASH)
          image = string.gsub(image, '^/', HOME_SLASH)
           image = string.gsub(image, ' ', '%%20')
 

			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
--		local x = http.getz(url)
		

		for url, image, title  in string.gmatch(x, ' <div class="col%-6 col%-lg%-3 pb%-2".-<a href="(.-)".-<img.-src="(.-)".-<h6 class=.-text%-white text%-center pt%-2".->(.-)</h6>') do
			url = string.gsub(url, '^/', HOME_SLASH)
          image = string.gsub(image, '^/', HOME_SLASH)
           image = string.gsub(image, ' ', '%%20')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    	
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
	
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
      --  table.insert(t, {title = 'Фильмы', mrl = '#stream/genre=' .. '/index.php/category/index'}) 
        local x = http.getz(HOME)
		
        table.insert(t, {title = 'Фильмы 60fps', mrl = '#stream/genre=' .. '/index.php/film/60fps'})
        
        table.insert(t, {title = 'Мульты 60fps', mrl = '#stream/genre=' .. '/index.php/mult/60fps'})
     --   local x = http.getz(HOME1)
   --      for genre in string.gmatch(x, '<li class="nav%-item".-<a.-href="http://doc.kinoteatr.kg(.-)') do
		--	table.insert(t, {title = 'Документальные', mrl = '#stream/genre=' .. '/index.php/site/index'}) 
	--	end
        
        
     --   table.insert(t, {title = 'Документальные', mrl = '#stream/genre=' .. '/index.php/site/index'})
        
        table.insert(t, {title = 'Все мульты', mrl = '#stream/genre=' .. '/index.php/mult/index'})
        --table.insert(t, {title = 'Фильмы HD', mrl = '#stream/genre=' .. '/index.php/film/index'}) 


        local x = http.getz(HOME)
       
        local x = string.match(x, '<nav id="w1".->(.-)</nav>')
		for genre, title in string.gmatch(x, '<a class="dropdown%-item" href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre}) 
		end
     --   local x = http.getz(HOME .. '/index.php/category/mults')

        --local x = string.match(x, '<div class="carou%-menu clearfix to%-mob">(.-)</div>')
	--	for genre, title, total in string.gmatch(x, '<div class="col%-lg%-8".-<a href="(.-)".-<b>(.-)</b>.-<b>(.-)<') do
		--	table.insert(t, {title = title .. ' ('.. total .. ')', mrl = '#stream/genre=' .. genre}) 
	--	end
  --      local x = http.getz(HOME .. '/index.php/category/docs')

        --local x = string.match(x, '<div class="carou%-menu clearfix to%-mob">(.-)</div>')
	--	for genre, title, total in string.gmatch(x, '<div class="col%-lg%-9".-<a href="(.-)".-<b>(.-)</b>.-<b>(.-)<') do
	--		table.insert(t, {title = title .. ' ('.. total .. ')', mrl = '#stream/genre=' .. genre}) 
--		end
        
      
   --     local x = http.getz(HOME)
       
   --     local x = string.match(x, '<ul id="w2" class="navbar%-nav ml%-auto nav">(.-)<a class="nav%-link" href="/index.php/site/login"')
    --    for genre, title in string.gmatch(x, '<a.-href="(.-)">(.-)</a>') do
	--		table.insert(t, {title = title, mrl = '#stream/genre=' .. genre}) 
--		end


        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php/search?q=' .. urlencode(args.keyword) .. '&page=' .. tostring(page)

		
		local x = http.getz(url)
		
        for url, image, title  in string.gmatch(x, '<div class="col%-lg%-5".-<a href="(.-)".-<img.-src="(.-)".-<h2 class="card%-title">(.-)<') do
			url = string.gsub(url, '^/', HOME_SLASH)
          image = string.gsub(image, '^/', HOME_SLASH)
           image = string.gsub(image, ' ', '%%20')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})



	-- #stream/q=content&id=/28525-pereval-dyatlova.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h2 class="text%-center p%-3">(.-)/.-</h2>')
		t['description'] = parse_match(x,'Описание.-<p>(.-)</p>')
         t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Год:</strong>.-)</p>','(Страна:</strong>.-)</p>','(Качество:</b>.-)<br>', '(Жанр:</strong>.-)</p>', '(Продолжительность:</b>.-)<br>', '(Режиссер:</b>.-)<br>', '(Актеры .. : .. </h3>.-)</p>', '(Мировая премьера:</span>.-)</div>'
		})
       -- x = string.gsub(x, 'Скачать', '')
 
--  http://kinoteatr.kg/video1/Filmu/7King%20Kong.2005.60fps.mp4
  
         for url in string.gmatch(x, 'Тизер:.-<source src="(/video.-)"') do

       
        url = string.gsub(url, '^(.-)',HOME) 
        url = string.gsub(url, ' ', '%%20') 
          table.insert(t, {title = 'Трейлер', mrl = url})
		end



       for url in string.gmatch(x, '<div class="embed.-nodownload.-<source src="(/video.-)"') do
         -- print(url)
      
        url = string.gsub(url, '^(.-)',HOME) 
       
        url = string.gsub(url, ' ', '%%20') 
          table.insert(t, {title = 'Смотреть', mrl = url})
		end

		
	elseif args.q == 'play' then
        
       -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)
	--end
	end
	return t
end