-- tevas plugin

require('support')
require('video')
require('parser')
require('client')



--https://eecdd71349_domain/eecdd71349_path/eecdd71349_file.js?23452&v=3&u=eecdd71349_uid&a=https://tevas.tv/kino/download/?f=Punkt_naznacheniya_poezd_13_2024.mp4


--https://iqslgbok.deploy.cx/?ip=188.114.96.3/https://tevas.tv/kino/download/?f=Punkt_naznacheniya_poezd_13_2024.mp4

--https://iqslgbok.deploy.cx/?ip=188.114.96.3/https://tevas.tv/kino/download/

--https://cors557.deno.dev/?ip=188.114.96.3/https://tevas.tv/kino/download/?f=Ty_prosto_kosmos_2024.mp4

--https://reyohoho.ru/https://tevas.tv/kino/download


--https://cors.nb557.workers.dev:8443/?ip=188.114.96.3/https://tevas.tv/kino/download/?f=Ty_prosto_kosmos_2024.mp4

--https://eecdd71349_domain/eecdd71349_path/eecdd71349_file.js?23452&v=3&u=eecdd71349_uid&a=https://tevas.tv/kino/download/?f=Ty_prosto_kosmos_2024.mp4


--https://eecdd71349_domain/bens/vinos.js?23452&u=eecdd71349_uid&a=https://tevas.tv/kino/download/

--https://receivedachest.com/services/?id=140737&a=https://tevas.tv/kino/download/

--https://raketa.live/?apk/kino/download/

local HOME = 'https://pult.tevas.dev'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
--conn['encoding'] = 'windows-1251'
conn['encoding'] = 'utf-8'
--conn['encoding'] = 'UTF-8'
conn['root'] = HOME_SLASH



--HOME = 'https://cors.nb557.workers.dev:8443/https://tevas.tv'


--HOME = 'https://tevas.ru'
--HOME = 'https://tevas.live'
--HOME = 'https://tevas.party'
--HOME = 'https://tevas.store'
--HOME = 'https://tevas.org'
--HOME = 'https://tevas.stream'
--HOME = 'https://tevas.cpads.ru'
--HOME = 'https://tevas.mobi'
--HOME = 'https://tevas.cpads.ru'
--HOME1 = 'https://vezonchik.ru'
--HOME_SLASH = HOME .. '/'
--HOME_SLASH1 = HOME1 .. '/'



function onLoad()
	print('Hello from tevas plugin')
	return 1
end

function onUnLoad()
	print('Bye from tevas plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'} 
         
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
		
	
	-- #stream/sort=top
	-- #stream/sort=mysort
	-- #stream/sort=boe
	-- #stream/sort=hor	
	-- #stream/sort=nov
	-- #stream/sort=bio
	-- #stream/sort=ves
	-- #stream/sort=voe	
	
	-- #stream/sort=det
	-- #stream/sort=kid
	-- #stream/sort=dok
	-- #stream/sort=dra	
	-- #stream/sort=ist
	-- #stream/sort=kom
	-- #stream/sort=kri
	-- #stream/sort=mel		
	-- #stream/sort=mul
	-- #stream/sort=pri
	-- #stream/sort=sem
	-- #stream/sort=spo
	-- #stream/sort=tri
	-- #stream/sort=fan
	-- #stream/sort=fen	
	-- #stream/genre=/kino/download/?page=
	if not args.q then
		

    local page = tonumber(args.page or 1)     

       --  local genre = args.genre
      local genre = args.genre or '/kino/download/?'
     
      local url = HOME .. '/kino/download/?'
          --     local x = conn:load(HOME .. '/kino/download/?')
     local x = conn:load(url)
   
      local total = string.match(x, '<a.-href=.-(big.-)"') 
      
      
      total = string.gsub(total, 'amp;', '')
 
   --   local genre = args.genre or '/kino/download/?' .. total
      
   --  table.insert(t, {title = url, mrl = '#stream/genre=' .. url, image = image}) 
  --  end
  
  
  
  -- #stream/genre=/kino/download/?sort=hor .. '&' .. total
     	
     	
     	
       local url1 = HOME .. genre .. '&' .. total 


--table.insert(t, {title = url1, mrl = '#stream/q=content&id=' .. url1, image = image}) 

    --   if genre == url1 then

         if page > 1 then
			url1 = url1 .. '&page=' .. tostring(page)
		end
 --  end
     --   local x = conn:load(url1 .. '&page=' .. tostring(page))

      local x = conn:load(url1)

--https://pusk.tevas.dev/kino/download/?sort=mysort&big=049&page=2

  --    local x = conn:load(url)

      for url2, image, title  in string.gmatch(x, '<a href="(?f.-.mp4).-class="v vi p".-<img src=.-(/stuff.-jpg).-<span>(.-)</span>') do
                    

 url2 = string.gsub(url2, 'amp;', '')
 
 
 
       url2 = string.gsub(url2, '^(.-)', HOME .. '/kino/download/')
	
		image = string.gsub(image, '^(.-)', HOME .. '/kino')
	
	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url2 .. '&id1=' .. total, image = image}) 
	
	--table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url2, image = image}) 
		end
	--	end
		
		
	--	local x = http.get(url)

    --   for url, image, title  in string.gmatch(x, '<a href="(all/.-)".-src="(.-)".-<span>(.-)<')do 
      --  url = string.gsub(url, '^(.-)', HOME .. '/serial/')
	--	image = string.gsub(image, '^(.-)', HOME .. '/serial/')
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
	--	end
     --   for url, image, title  in string.gmatch(x, '<a href="(all/.-)".-src="(.-)".-<span>(.-)<')do 
      --  url = string.gsub(url, '^(.-)', HOME .. '/serial/')
	--	image = string.gsub(image, '^(.-)', HOME .. '/serial/')
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image}) 
	--	end
       -- for url, title in string.gmatch(x,'<a href="(.-/)".-class="i s01">(Сезон.-)<
   
   
      local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre 
       
		table.insert(t, {title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})




	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
    
        local x = http.getz(HOME .. '/kino/')
        
--https://tevas.org/kino/download/?sort=hor&big=033
        
 
 
    for genre, total, title in string.gmatch(x, '<a rel="nofollow.-href="(/kino/download/?)(.-)".-class="i vi">(.-)<') do
     
   total = string.gsub(total, 'amp;', '')
genre = string.gsub(genre, 'amp;', '')
      
     table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. total})
        end
 
        for genre, total, title in string.gmatch(x, '<a href="download/(?.-&)(.-)".->(.-)</div>') do
    --    table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. '/kino/download/' .. genre})
         total = string.gsub(total, 'amp;', '')
         genre = string.gsub(genre, '^(.-)','/kino/download/')
        table.insert(t, {title = HOME .. genre .. total, mrl = '#stream/genre=' .. genre .. total})
        end
         
--    <div class="clear"></div>  <a href="/search/"><div class="i s2">Поиск</div></a>     --    <script type="text/javascript"
		
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search/search.php?' .. '&p=' .. tostring(page) .. '&q=' .. urlencode(args.keyword) 
		
		local x = conn:load(url)
		
--	href="/kino/download/?f=Chujoy_Zavet.mp4&amp;sea=37119185228133239&amp;big=709"><div	
		
		
		
        for url, total, total1, image, title  in string.gmatch(x, '<a href=".-(?f.-mp4)&(.-)&(.-)".-src=.-/.-(/.-)".-<span>(.-)</span>')do 
        
        total = string.gsub(total, 'amp;', '')
        total1 = string.gsub(total1, 'amp;', '')
        url = string.gsub(url, '^(.-)', HOME .. '/kino/download/')
		image = string.gsub(image, '^(.-)', HOME .. '/kino')
		
		
    --    for url, image, title  in string.gmatch(x, '<a href=.-(/kino.-mp4).-src=.-(/.-jpg).-<span>(.-)</')do 
     --   url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content1&id=' .. url .. '&id1=' .. total .. '&id2=' .. total1, image = image}) 
		end
    
    local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
  
    --	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. 'p=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
	
	
	
			
	-- #stream/q=content&id=https://mulltik.me/6248-mikki-maus-mir-priklyucheniy.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id .. '&' .. args.id1)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1. ->(.-)</h1>') 
		t['description'] = parse_match(x, '<div style="padding:.-<br.-<br.-<br.-br>(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div align="center".-src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Фильм:.-)<br>', '(Год:.-)<br>', '(Перевод:.-)<br>', '(Качество:.-)<br>',
		})

        --x = string.gsub(x, 'скачать', '')
        
        for url, title in string.gmatch(x,'<a href="(0.-)".-class="i s01">(Сезон.-)<') do
          print(url) 
          url = string.gsub(url, '^(.-)', args.id)
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
		
         table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
		 end
		 
		  for url, title in string.gmatch(x, '<a href="(?f=.-mp4).-class="i epi vn">(Серия.-)<') do
		 url = string.gsub(url, '^(.-)', args.id)
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
           t['view'] = 'simple'
         table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
		 end
		 
		 
        for url in string.gmatch(x, '<a rel="noindex nofollow" href="?f=(.-mp4)') do
  
  
--https://bigsgppgs.tevas.dev/kino/download/all/Odisseya_TEVAS_2026.mp4
  

  
  --//bigsgppgs.tevas.dev/kino/download/all/Karina_2024.mp4    
          print(url) 
          url = string.gsub(url, '^(.-)', 'https://big.tevas.tech/kino/download/top/')
--https://get.tevas.fans/kino/download/top/Beskraynij_bassejn_2023.mp4
          
--https://big.tevas.tech/kino/download/top/Beglec_2023.mp4
			--addvideo(t, url, t['name'])
	--	url = '#stream/q=play&url=' .. url	
		
         table.insert(t, {title = url, mrl = url})
		 end
		 
		 
--//get.tevas.fans/kino/download/top/Vedma_reinkarnaciya_2023.mp4
--https:/kino/download/top/Za_predelami_neona_2022.mp4

--https://get.tevas.fans/kino/download/top//kino/download/top/Beskraynij_bassejn_2023.mp4
--<video playsinline="1" preload="metadata" src="//get.tevas.tech/kino/download/top/Na_krayu_2022.mp4"


--var player = new Playerjs({id:"player", file:"//{v3}/kino/download/all/Karina_2024.mp4


        for url in string.gmatch(x, 'new Playerjs.-file:.-(/kino.-.mp4)') do
          print(url) 
          url = string.gsub(url, '^(.-)', 'https://bigsgppgs.tevas.dev')
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
		
         table.insert(t, {title = 'Смотреть', mrl = url})
		 end



elseif args.q == 'content1' then
		t['view'] = 'annotation'
		local x = conn:load(args.id .. '&' .. args.id1 .. '&' .. args.id2)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1. ->(.-)</h1>') 
		t['description'] = parse_match(x, '<div style="padding:.-<br.-<br.-<br.-br>(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div align="center".-src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Фильм:.-)<br>', '(Год:.-)<br>', '(Перевод:.-)<br>', '(Качество:.-)<br>',
		})
		
		
		for url in string.gmatch(x, 'new Playerjs.-file:.-(/kino.-.mp4)') do
          print(url) 
          url = string.gsub(url, '^(.-)', 'https://bigsgppgs.tevas.dev')
			--addvideo(t, url, t['name'])
		--url = '#stream/q=play&url=' .. url	
		
         table.insert(t, {title = 'Смотреть', mrl = url})
		 end
        
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	   return video(args.url, args)

	end
	return t
end