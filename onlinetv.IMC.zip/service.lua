-- onlinetv plugin

require('support')
require('video')
require('parser')

TV_URL = 'http://epg.it999.ru/edem.xml.gz'
TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

PASS = '7777'

local lockpass





function onLoad()
	print('Hello from onlinetv plugin')
	return 1
end

function onUnLoad()
	print('Bye from onlinetv plugin')
end

function onCreate(args)

if not args.q and args.keyword then
lockpass = args.keyword
end

if lockpass == PASS then
else
return {view="keyword",message="enter access code"}
end



	local t = {view = 'grid', type = 'folder'}
--	t['menu'] = {}
--	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
--	end

	if not args.q then
	

	
			local url = 'https://zigfreed.ru/onlinetv/channels/ch.js'
		
			url = url
		local x = http.getz(url)
         
        for title in string.gmatch(x, 'var accessToken = \'(.-)\'') do
		for  url, total in string.gmatch(x, 'OPTION value="(https.-)\'.->(.-)\'') do
          
            local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(total)
			table.insert(t, {title = total, mrl = url .. title, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})
			
			
			
		--	table.insert(t, {title = total, mrl = url .. title})

		end
        end

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end