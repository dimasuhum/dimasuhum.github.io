-- onlinetv plugin

require('support')
require('video')
require('parser')

HOME = 'https://zigfreed.ru'

HOME_SLASH = HOME .. '/'


TV_URL = 'https://iptvx.one/epg/epg.xml.gz,https://zigfreed.ru/Z!/epg.xml'
TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

PASS = '7777'

local lockpass


function onLoad()
	print('Hello from onlinetv plugin')
	return 1
end

function onUnLoad()
	print('Bye from onlinetv plugin')
end

function onCreate(args)

if not args.q and args.keyword then
lockpass = args.keyword
end

if lockpass == PASS then
else
return {view="keyword",message="enter access code"}
end



	local t = {view = 'grid', type = 'folder'}
--	t['menu'] = {}
	if args.q ~= 'genres' then
	--	table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

	if not args.q then
	
--https://zigfreed.ru/onlinetv


       local genre = args.genre or '/onlinetv/'
	   local url = HOME .. genre
     	url = url 
     	
     	local x = http.getz(url)

	
         for url in string.gmatch(x, '<script src="(/iptv/.-onl.js)"') do

          url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = 'Активация tv', mrl = '#stream/q=content&id=' .. url, image = image})
		end

       local genre = args.genre or '/iptv/'
	   local url = HOME .. genre
     	url = url 
     	
     	local x = http.getz(url)

	
         for url in string.gmatch(x, '<script src="(/iptv/.-js)"') do

          url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = 'Активация m3u', mrl = '#stream/q=content&id=' .. url, image = image})
		end



--https://zigfreed.ru/iptv/

--<script src="/iptv/p9gBGd7Her.js"


--document.location.href="/onlinetv/?act=bSnvBEH6FX"
    --   if genre == '/iptv/get/' then
        local url = 'https://zigfreed.ru/iptv/get/'
     --   local url = HOME .. genre
     	url = url 
     --	end
     	local x = http.getz(url)

	
          for url in string.gmatch(x, '<div class="pricing".-class="pricing".-<h3>.-<p>(http.-m3u)') do
         table.insert(t, {title = 'Дополненный', mrl = url, image = 'https://avatars.mds.yandex.net/i?id=66a2eda074d26358f33e46144529cfa2_l-5232112-images-thumbs&n=13'})
		end
--	   end
	
			local url = 'https://zigfreed.ru/onlinetv/channels/ch.js'
		
			url = url
		local x = http.getz(url)
         
        for title in string.gmatch(x, 'var accessToken = \'(.-)\'') do
		for  url, total in string.gmatch(x, 'OPTION value="(https.-)\'.->(.-)\'') do
          
            local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(total)
			table.insert(t, {title = total, mrl = url .. title, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})
			
			
			
		--	table.insert(t, {title = total, mrl = url .. title})

		end
        end

    elseif args.q == 'content' then
		
		local x = http.getz(args.id)

        for url in string.gmatch(x, 'document.-href="(/onlinetv/?.-)"') do
        url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = 'Активация tv', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
       for url in string.gmatch(x, 'document.-href="(/payment/?.-)"') do
        url = string.gsub(url, '^(.-)', HOME)

			table.insert(t, {title = 'Активация m3u', mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
		
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end