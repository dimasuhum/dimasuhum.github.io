-- fast-film plugin

require('support')
require('video')
require('parser')



HOME = 'http://stvplay.mooo.com:81'

HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
        table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
        
	if not args.q then
	

		local page = tonumber(args.page or 1)
		
		

		
		local genre = args.genre or '/vk/vk.php?owner=-95619595'
		local url = HOME .. genre

		if page > 1 then
			url = url .. '&page=' .. tostring(page)
		end
		local x = http.getz(url)
        for total, url, image in string.gmatch(x, '</channel.-<channel.-title>.-%[CDATA%[(.-)].-playlist_url>.-%[CDATA%[(http.-)].-<img src=.-(http.-)\'>') do


       local x = http.getz(url)
   
        for total1, url in string.gmatch(x, 'title>.-%[CDATA%[(1080p).-<stream_url>.-%[CDATA%[(https.-)]') do
   
      table.insert(t, {title = total, mrl = url, image = image})
    
        end
   end
		
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = http.getz(HOME .. '/vk/vk.xml')
		
--http://stvplay.mooo.com:81/vk/vk.php?all=1&owner=-bdkino

		for title, genre in string.gmatch(x,'</channel.-<channel.-<title>(.-)</title.-<playlist_url>.-%[CDATA%[http://.-(/vk/vk.php?.-)]') do
		
          genre = string.gsub(genre, 'all=1&', '')
		
        table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		
		
          local x= HOME .. '/vk/vk.php?search=%D1%84%D0%B8%D0%BB%D1%8C%D0%BC%D1%8B%204k' 

           
		for total, url, image in string.gmatch(x, '</channel.-<channel.-title>.-%[CDATA%[(.-)].-playlist_url>.-%[CDATA%[(http.-)].-<img src=.-(http.-)\'>') do
		
        table.insert(t, {title = 'Фильмы 4k', mrl = '#stream/genre=' .. '/vk/vk.php?search=%D1%84%D0%B8%D0%BB%D1%8C%D0%BC%D1%8B%204k'})
        
      end
      
       table.insert(t, {title = 'Фильмы 4k', mrl = '#stream/genre=' .. '/vk/vk.php?owner=-184447514'})  

       table.insert(t, {title = 'Фильмы Vk', mrl = '#stream/genre=' .. '/vk/vk.php?owner=-56028029'}) 

       table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/vk/vk.php?owner=-46105176'}) 
       
       table.insert(t, {title = 'КиноHd', mrl = '#stream/genre=' .. '/vk/vk.php?owner=-113071474'}) 



--http://stvplay.mooo.com:81/vk/vk.php?owner=-113071474

      
        elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/vk/vk.php?search=' .. urlencode(args.keyword) .. '&page=' .. tostring(page)


		 local x = http.getz(url)
     
       for total, url, image in string.gmatch(x, '</channel.-<channel.-title>.-%[CDATA%[(.-)].-playlist_url>.-%[CDATA%[(http.-)].-<img src=.-(http.-)\'>') do


       local x = http.getz(url)
   
        for total1, url in string.gmatch(x, 'title>.-%[CDATA%[(1080p).-<stream_url>.-%[CDATA%[(https.-)]') do
   
      table.insert(t, {title = total, mrl = url, image = image})
    
        end
   end
   
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
        


	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end