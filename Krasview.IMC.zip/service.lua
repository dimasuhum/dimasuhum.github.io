-- kadu plugin

require('support')
require('video')
require('parser')
require('client')


local HOME = 'https://zseek.ru'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'windows-1251'
conn['root'] = HOME_SLASH



--HOME = 'https://zloekino.su'
--HOME = 'https://krasview.ru'
--HOME = 'http://hlamer.ru'
--HOME = 'https://wseries.ru'
--HOME = 'https://oveg.ru'

--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kadu plugin')
	return 1
end

function onUnLoad()
	print('Bye from kadu plugin')
end

function onCreate(args)


	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	   table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/genre=/movie/tag/bdrip
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/movie'

		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end


        local x = conn:load(url)


        
		for url, title, image  in string.gmatch(x, '<li id=\'c.-<a href=.-(http.-)\' title=\'(.-)\'.-<img.-srcset=\'(http.-jpg)') do
	    	print(url)
	  -- 	url = string.gsub(url, '^(.-)', HOME)
       --    image = string.gsub(image, '^/', HOME_SLASH)
			
			
		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	
        
	
--https://oveg.ru/series/Game_of_Thrones/?category=-1
	
	
	
	
        
	
	
	
		
       -- for url, image,   title in string.gmatch(x, '<div class="card%-body row text%-left".-<a href="(.-)".-data%-src="(.-)".-class="col%-md%-8".-<a href.->(.-)<') do
	--	print(url)
	--	url = string.gsub(url, '^/',HOME_SLASH)
          -- image = string.gsub(image, '^/', HOME_SLASH)
			
			
		--  table.insert(t, {title = tolazy(title), mrl = '#folder/genre' .. url, image = image})
	--	end
         
         
    --    for title,  url, total in string.gmatch(x, '<div class="playlist__heading"<a href=.->(.-)<.-class="strong" href="(.-)">(.-)<') do
	--	print(url)
	--	url = string.gsub(url, '^/',HOME_SLASH)
          -- image = string.gsub(image, '^/', HOME_SLASH)
			
			
	--	  table.insert(t, {title = tolazy(title) .. (total), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
         
		  
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


       table.insert(t, {title = 'Подборки', mrl = '#stream/q=coll&id=' .. '/set'})		

         table.insert(t, {title = 'Фильмы :Топ по Кинопоиску', mrl = '#stream/genre=' .. '/movie/kinopoisk'})
         
         table.insert(t, {title = 'Фильмы :Последние', mrl = '#stream/genre=' .. '/movie/fresh'})
         table.insert(t, {title = 'Фильмы :Топ за всё время', mrl = '#stream/genre=' .. '/movie/top'})
         table.insert(t, {title = 'Фильмы :Обсуждаемые', mrl = '#stream/genre=' .. '/movie/discussions'})

         
         
         
         table.insert(t, {title = 'Сериалы :Топ по Кинопоиску', mrl = '#stream/genre=' .. '/series/kinopoisk'})
         
         table.insert(t, {title = 'Сериалы :Последние', mrl = '#stream/genre=' .. '/series/fresh'})
         table.insert(t, {title = 'Сериалы :Топ за всё время', mrl = '#stream/genre=' .. '/series/top'})
         table.insert(t, {title = 'Сериалы :Обсуждаемые', mrl = '#stream/genre=' .. '/series/discussions'})
    --     table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/anime'})


table.insert(t, {title = 'Фильмы по жанрам', mrl = '#stream/q=genrez&id=' .. '/movie'})
	
      table.insert(t, {title = 'Сериалы по жанрам', mrl = '#stream/q=genrezs&id=' .. '/series'})
	   
       
      
--https://oveg.ru/#search/kino/%D0%A0%D0%BE%D0%B9
--https://oveg.ru/#search/kino/?category=-2051
--https://oveg.ru/series/tag/%D0%A3%D0%B6%D0%B0%D1%81%D1%8B


elseif args.q == 'genrez' then

local x=conn:load(HOME .. '/movie')
       local x = string.match(x, '<select id=\'genres\'(.-)</select>')
        
        
       for genre, title in string.gmatch(x, '<option value=\'(.-)\'>(.-)</option>') do
       
       t['view'] = 'simple'
	
			table.insert(t, {title = title, mrl = '#stream/q=genrezz&id=' .. genre})
	end



elseif args.q == 'genrezz' then

local page = tonumber(args.page or '1')


local headers = {
    ["Host"] = "zseek.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Content-Length"] = "",
    ["Origin"] = "https://zseek.ru",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://zseek.ru/movie",
    ["Cookie"] = "guest=1276788291%7C1779346961; adtech_uid=82be1c1d-0002-4480-909a-e413ee6aa359%3Azseek.ru; top100_id=t1.3137744.753755851.1779346967747; t3_sid_3137744=s1.1374929074.1779346967748.1779347528457.1.8.6.1..; no_auth=1; user-hal=0; _ym_uid=1779346975930334178; _ym_d=1779346975; tmr_lvid=4b66f3e7c4af0623d08f541b94c96d48; tmr_lvidTS=1779346975197; tmr_detect=0%7C1779347532212; _ym_isad=1; domain_sid=8eAlp2PZ0uvYH4Z3VEDqI%3A1779347532477; _sltm=7e7a7079fcdbc8c3a74de065287b04f8~0; _sltb=0; _ym_visorc=b; genres15=" .. args.id,
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local params = [[
movie%5Bgenres%5D%5B%5D= .. args.id
]]


	local url = HOME .. '/movie'

		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end

local x = http.postz(url, headers, params)

--for title in string.gmatch(x, '<li id=\'c(.-)</li>') do
        
        x = iconv(x, 'windows-1251', 'utf-8')
        
        
		for url, image, title in string.gmatch(x, '<li id=\'c.-<a href=.-(http.-)\'.-<img.-srcset=\'(http.-jpg).-alt.-<div>(.-)<span>') do
	    --	print(url)
	--  	url = string.gsub(url, '^(.-)', HOME)
       --    image = string.gsub(image, '^/', HOME_SLASH)
	
--	url = url_for(x)
--	url = urldecode(url)
			
	--	table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
		
		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		


local url = '#stream/q=genrezz&id=' .. args.id .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})






elseif args.q == 'genrezs' then

local x=conn:load(HOME .. '/series')
       local x = string.match(x, '<select id=\'genres\'(.-)</select>')
        
        
       for genre, title in string.gmatch(x, '<option value=\'(.-)\'>(.-)</option>') do
       
       t['view'] = 'simple'
	
			table.insert(t, {title = title, mrl = '#stream/q=genrezzs&id=' .. genre})
	end



elseif args.q == 'genrezzs' then

local page = tonumber(args.page or '1')


local headers = {
    ["Host"] = "zseek.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Content-Type"] = "application/x-www-form-urlencoded",
    ["Content-Length"] = "",
    ["Origin"] = "https://zseek.ru",
    ["Connection"] = "keep-alive",
    ["Referer"] = "https://zseek.ru/series",
    ["Cookie"] = "guest=1276788291%7C1779346961; adtech_uid=82be1c1d-0002-4480-909a-e413ee6aa359%3Azseek.ru; top100_id=t1.3137744.753755851.1779346967747; t3_sid_3137744=s1.1374929074.1779346967748.1779347528457.1.8.6.1..; no_auth=1; user-hal=0; _ym_uid=1779346975930334178; _ym_d=1779346975; tmr_lvid=4b66f3e7c4af0623d08f541b94c96d48; tmr_lvidTS=1779346975197; tmr_detect=0%7C1779347532212; _ym_isad=1; domain_sid=8eAlp2PZ0uvYH4Z3VEDqI%3A1779347532477; _sltm=7e7a7079fcdbc8c3a74de065287b04f8~0; _sltb=0; _ym_visorc=b; genres17=" .. args.id,
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "same-origin",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local params = [[
movie%5Bgenres%5D%5B%5D= .. args.id
]]


	local url = HOME .. '/series'

		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end

local x = http.postz(url, headers, params)

--for title in string.gmatch(x, '<li id=\'c(.-)</li>') do
        
        x = iconv(x, 'windows-1251', 'utf-8')
        
        
		for url, image, title in string.gmatch(x, '<li id=\'c.-<a href=.-(http.-)\'.-<img.-srcset=\'(http.-jpg).-alt.-<div>(.-)<span>') do
	    --	print(url)
	  --	url = string.gsub(url, '^(.-)', HOME)
       --    image = string.gsub(image, '^/', HOME_SLASH)
	
--	url = url_for(x)
--	url = urldecode(url)
			
	--	table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
		
		  table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		


local url = '#stream/q=genrezzs&id=' .. args.id .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})






elseif args.q == 'coll' then

local page = tonumber(args.page or '1')

local url = HOME .. args.id

		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end

local x = conn:load(url)
    
        for url, title, image  in string.gmatch(x, '<li id=\'set.-<a href=.-(/set.-)\' title=\'(.-)\'.-<img.-srcset=.-(https.-jpg)') do
	    --	print(url)
	  -- 	url = string.gsub(url, '^(.-)', HOME)
           
			
			
		  table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end

local url = '#stream/q=coll&id=' .. args.id .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

		
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		
	
		
		local url = HOME .. '/kino?mode=search&ajax&query=' .. urlencode(args.keyword) 
		--.. '?page=' .. tostring(page)
		--.. '&do=search&subaction=search'
		
if page > 1 then
			url = url .. '&page=' .. tostring(page)
		end

		local x = conn:load(url)
	
	
         for url, image, title in string.gmatch(x, '<li id=\'c.-<a href=.-(http.-)\'.-<img.-srcset=.-(http.-jpg).->(.-)<span>') do
		
      --  for url, title, image in string.gmatch(x, '<li id=\'c.-<a href=.-(http.-)\'.-title=\'(.-)\'.-<img.-srcset=.-(http.-jpg)') do
      --   url = string.gsub(url, '^(.-)', HOME)
	--	image = string.gsub(image, '^/', HOME_SLASH1)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '?page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
      
      
      
      
         
	-- #stream/q=content&id=http://tv.tivix.co/24-cartoon-network.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	--	local x = http.getz(args.id)
		local x = conn:load(args.id)

		
     --    x = iconv(http.get(args.id), 'windows-1251', 'UTF-8')		
      --    t['ref'] = args.id
	
        --  x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1>(.-)</h1>')
		t['description'] = parse_match(x, 'itemprop="description">(.-)<br>')
		--	t['poster'] = args.p
		
--<div id='photo-container'><div><a href='https://image.krasview.ru/channel/66378/5b0621ea2750f96b_original.jpg' class='highslide'><img id='avatar' src='https://image.krasview.ru/channel/66378/5b0621ea2750f96b.jpg'
			t['poster'] = parse_match(x,' <img id=\'avatar\' src=.-(https.-jpg)')
	--	if t['poster'] then
		--	t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
		
			
	    	t['annotation'] = parse_array(x, {'(Год</b>:.-)</a>', '(Страна</b>:.-)</a>', '(Производство</b>:.-)</a>', '(Дата премьеры в мире</b>:.-)<br>', '(Режиссёр</b>:.-)</a>', '(Актер</b>:.-)<br>',})




for id in string.gmatch(x, '<div id=\'movie\'.-<ul class=.-video%-gallery.-itemscope itemtype=.-id=\'v%-(.-)\'') do

--t['view'] = 'simple'

table.insert(t, {title = 'Смотреть', mrl = '#stream/q=krasviewvideo&id=' .. id})

end
  
  
  for id in string.gmatch(x, '<div id=\'series\'.-<ul class=.-video%-gallery.-itemscope itemtype=.-id=\'v%-(.-)\'') do

--t['view'] = 'simple'

table.insert(t, {title = 'Смотреть', mrl = '#stream/q=krasviews&id=' .. args.id})

end
  
  
  
  elseif args.q == 'krasviews' then

local page = tonumber(args.page or 1)

      local x = conn:load(args.id .. '?page=' .. tostring(page))



   for id, title in string.gmatch(x, '<li itemprop=\'itemListElement\' itemscope itemtype=.-id=\'v%-(.-)\'.-alt=\'(.-)\'') do

t['view'] = 'simple'

table.insert(t, {title = title, mrl = '#stream/q=krasviewvideo&id=' .. id})


end

local url = '#folder/page=' .. tostring(page + 1) .. '&q=krasviews&id=' .. args.id
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})


  
  
    
    elseif args.q == 'krasviewvideo' then

local headers = {
    ["Host"] = "zedfilm.ru",
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    ["Accept-Language"] = "en-US,en;q=0.5",
    ["Accept-Encoding"] = "gzip, deflate, br",
    ["Referer"] = "https://zedfilm.ru/",
    ["DNT"] = "1",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "iframe",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "cross-site",
    ["Pragma"] = "no-cache",
    ["Cache-Control"] = "no-cache"
}
     args.id = string.gsub(args.id, '^(.-)', 'https://zedfilm.ru/') 
 
   --table.insert(t, {title = id, mrl = id})
   
     local x = http.getz(args.id, headers)
 
 for url1 in string.gmatch(x, 'video_Init.-\'(.-)\'') do
 
 
    url1 = base64_decode(url1)
   
 
   for url2 in string.gmatch(url1, '"url2":"(http.-)"') do
    
    
      url2 = string.gsub(url2, 'media', 'm')
      
      if url2 then
    print(url2)
    return {view = 'playback', mrl = url2, seekable = 'true', direct = 'true'}
 end
      
 
end
end


    
    
    
		
	elseif args.q == 'play' then
	--	return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
       return video(args.url, args)
--	end
	end
	return t
end