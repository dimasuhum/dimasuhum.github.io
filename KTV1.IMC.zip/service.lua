-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate

--https://api.embess.ws/embed/movie/486

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'





local HOME = 'http://kb-team.club'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH








PASS = '7777'

local lockpass



function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)

if not args.q and args.keyword then
lockpass = args.keyword
end

if lockpass == PASS then
else
return {view="keyword",message="enter access code"}
end


	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then



	if not args.q then

--http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434

t['view'] = 'simple'

   table.insert(t, {title = 'Федеральные', mrl = '#folder/q=iptv1', image = '#self/film.png'})

table.insert(t, {title = 'Плюсовые', mrl = '#folder/q=iptv2', image = '#self/film.png'})


table.insert(t, {title = 'Информационные', mrl = '#folder/q=iptv3', image = '#self/film.png'})

table.insert(t, {title = 'Развлекательные', mrl = '#folder/q=iptv4', image = '#self/film.png'})

table.insert(t, {title = 'Музыкальные', mrl = '#folder/q=iptv5', image = '#self/film.png'})

table.insert(t, {title = 'Познавательные', mrl = '#folder/q=iptv6', image = '#self/film.png'})

table.insert(t, {title = 'Спортивные', mrl = '#folder/q=iptv7', image = '#self/film.png'})

table.insert(t, {title = 'Детские', mrl = '#folder/q=iptv8', image = '#self/film.png'})

table.insert(t, {title = 'UHD | 4K', mrl = '#folder/q=iptv9', image = '#self/film.png'})

table.insert(t, {title = 'Киноканалы', mrl = '#folder/q=iptv10', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры KBC', mrl = '#folder/q=iptv11', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры BCU', mrl = '#folder/q=iptv12', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры BOX', mrl = '#folder/q=iptv13', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры MM', mrl = '#folder/q=iptv14', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры Play-x', mrl = '#folder/q=iptv15', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры Olsib', mrl = '#folder/q=iptv16', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры CineMan', mrl = '#folder/q=iptv17', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры SKY HIGH', mrl = '#folder/q=iptv18', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры Fresh', mrl = '#folder/q=iptv19', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры Magic', mrl = '#folder/q=iptv20', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры Kernel TV', mrl = '#folder/q=iptv21', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры VeleS', mrl = '#folder/q=iptv22', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры Liberty', mrl = '#folder/q=iptv23', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры NEXT', mrl = '#folder/q=iptv24', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры KLI', mrl = '#folder/q=iptv25', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры Чебур ТВ', mrl = '#folder/q=iptv26', image = '#self/film.png'})

table.insert(t, {title = 'Кинотеатры Catcast', mrl = '#folder/q=iptv27', image = '#self/film.png'})






   --   local url = 'http://kb-team.club/?do=/plugin&bid=federaltv&m3u'
		--	url = url

     elseif args.q == 'iptv1' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Федеральные".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end
		
elseif args.q == 'iptv2' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Плюсовые".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end


elseif args.q == 'iptv3' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Информационные".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end

    elseif args.q == 'iptv4' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Развлекательные".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end
		
elseif args.q == 'iptv5' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Музыкальные".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end

elseif args.q == 'iptv6' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Познавательные".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end
		
elseif args.q == 'iptv7' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Спортивные".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end
				
		
elseif args.q == 'iptv8' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Детские".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end

elseif args.q == 'iptv9' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="UHD | 4K".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end
		
		
	elseif args.q == 'iptv10' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Киноканалы".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end	
		


elseif args.q == 'iptv11' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры KBC".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end	

elseif args.q == 'iptv12' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры BCU".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end	


elseif args.q == 'iptv13' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры BOX".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end	
		
elseif args.q == 'iptv14' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры MM".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			
		
elseif args.q == 'iptv15' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры Play%-x".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			

elseif args.q == 'iptv16' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры Olsib".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end		
		
		
	elseif args.q == 'iptv17' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры CineMan".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			
		
	elseif args.q == 'iptv18' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры SKY HIGH".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			
		
	elseif args.q == 'iptv19' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры Fresh".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			
			
	elseif args.q == 'iptv20' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры Magic".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end				
			
elseif args.q == 'iptv21' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры Kernel TV".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end		
		
	elseif args.q == 'iptv22' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры VeleS".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			
		elseif args.q == 'iptv23' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры Liberty".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			
		
		
		elseif args.q == 'iptv24' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры NEXT".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			
	
	
	
			
		elseif args.q == 'iptv25' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры KLI".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			





			elseif args.q == 'iptv26' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры Чебур ТВ".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			
		
		
		elseif args.q == 'iptv27' then

		local x = conn:load('http://kb-team.club/?do=/plugin&bid=federaltv&m3u&box_mac=acace24b8434')

		for image, title, url in string.gmatch(x, 'EXTINF:.-group%-title="Кинотеатры Catcast".-tvg%-logo="(.-)".-,(.-)(http.-)#') do
          

			table.insert(t, {title = title, mrl = url, image = image})
		
		end			
		
		
		
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
end
	end
	return t
end

