-- Octopus plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate


local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local HOME = 'http://my.ultradox.team'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'windows-1251'
--conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



--HOME = 'http://my.ultradox.press'

--HOME_SLASH = HOME .. '/'
--windows-1251

function onLoad()
	print('Hello from octopusfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from octopusfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/page=/nerufilm/	
	-- #stream/genre=/hd/
	-- #stream/genre=/webrips/
	-- #stream/genre=/camrip/
    -- #stream/url=/serial/
	-- #stream/url=/rufilm/
	-- #stream/url=/hd/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/nerufilm/hd/'
		local url = HOME .. genre
		--local url1 = HOME1 .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
			--url1 = url1 .. '/page/' .. tostring(page) .. '/'
		end
        
	--	local x = http.getz(url)
        local x = conn:load(url)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-src=.-(/uploads/.-jpg)".-<span>(.-)</span>') do
	
          image = string.gsub(image, '^(.-)', HOME)
	
	--		image = string.gsub(image, '^(.-)', 'http://ultradox.asia')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		--local x = http.getz(url1)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
		--	image = string.gsub(image, '^/', HOME_SLASH1)
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x =  conn:load(HOME)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
	--	x = string.match(x, 'div class="top__menu_ul">(.-)</div>')
    --    for genre, title in string.gmatch(x,'<a href="(.-)">(.-)</a>') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. '/'})
	--	end
        table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serial/'})
        table.insert(t, {title = 'HDRIP / BDRIP', mrl = '#stream/genre=' .. '/nerufilm/hd/'})
        table.insert(t, {title = 'НАШЕ КИНО', mrl = '#stream/genre=' .. '/rufilm/'})
        table.insert(t, {title = 'CAMRIP / TS', mrl = '#stream/genre=' .. '/nerufilm/camrip/'})
        table.insert(t, {title = 'WEB-DL', mrl = '#stream/genre=' .. '/nerufilm/webrips/'})
        table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/anime/'})
        
    
    
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		
		

		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)


	--	local x = http.getz(url)
        local x = conn:load(url)
        x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		
        for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-src=.-(/uploads/.-jpg)".-<span>(.-)</span>') do
        
         url = string.gsub(url, '^(.-)', HOME)
        
			image = string.gsub(image, '^(.-)', 'http://ultradox.asia')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
			
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
    
        
	-- #stream/q=content&id=http://m.octopusfilm.su/16160-sila-prirody-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x =  conn:load(args.id)
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'(Сюжет:.-)<br>')
		t['poster'] = parse_match(x,'<div class="full%-story__top__info%-poster".-img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(Год:</span>.-)</li>', '(Страна:</span>.-)</li>',  '(Перевод:</span>.-)</li>', '(Жанр:</span>.-)</li>', '(Качество:</span>.-)</li>', '(Режиссерский состав:</span>.-)</li>', '(В Ролях:</span>.-)</li>', 
		})

--href='https://www.kinopoisk.ru/film/178710
   
   
   
   
         
   
   
   
       for url in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
   
   
      url = string.gsub(url, '^(.-)', 'https://fancdn.net/ember/')
  
    table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
        end
    
    
       for title, url in string.gmatch(x, '"title":"(.-)".-"file":"(http.-m3u8)"') do
   
   
          t['view'] = 'simple'
   
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
        
       url = string.gsub(url, '\\', '')
    
    
       table.insert(t, {title = title, mrl = url})

         end
    
    
    
    
    
    
      for url in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
          
    

     url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=') 
         table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

         end

         
         
        for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   


         url = string.gsub(url, '^(.-)', 'https://bwa-cloud.apn.monster/lite/zetflix?id=0&kinopoisk_id=')

    --    url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=0&kinopoisk_id=')
        

      local x =  http.getz(url)
       
      
       
       for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(1080p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(720p).-(http.-mp4)') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(480p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(360p).-(http.-mp4)') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end
--end
        
        
          for url1, url2  in string.gmatch(x, 'current_page".-"data":%[{"id":(.-),"kinopoisk_id":(.-),') do
       
	--	url = string.gsub(url2, '^(.-)', 'https://voidboost.net/embed/')
	
	
	
	
        url = string.gsub(url2, '^(.-)', 'https://player.cdnvideohub.com/playerjs?partner=9&kid=')
       
        local x = http.getz(url)
    --x = string.match(x, '<select name="season".->(.-)</select>')
    
   --     for url, title in string.gmatch(x, '<option value="(.-)".-(Сезон.-)</option>') do


       for title, url3 in string.gmatch(x, '\'title\': \'(Сезон) (.-)\',') do

    --   url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=' .. url1 .. '&kinopoisk_id=' .. url2 .. '&title=&original_title=&s=')
        




        local x = http.getz('https://bwa-cloud.apn.monster/lite/zetflix?id=' .. url1 .. '&kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)

  --   local x = http.getz('http://79.137.204.8:9118/lite/zetflix?id=' .. url1 .. '&kinopoisk_id=' .. url2 .. '&title=&original_title=&s=' .. url3)



       for url, total  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do
       

       t['view'] = 'simple'

       table.insert(t, {title = title .. ' ' .. url3 .. (total), mrl = url})
    
    	end
	end
    end

    
    
    
    
    
    
    
    
    
    
    
      for url in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
		 print(url)
	
    	url = string.gsub(url, '^(.-)', 'https://cdnmovies-stream.online/kinopoisk/') .. '/iframe?domain=kinobd.net'
    	
    	

			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
			
		end

      --   local x = http.getz(url)
         
         for url in string.gmatch(x, 'player.-:.-#2(.-)"') do
       
       
         print(url)

         url = string.gsub(url, '\\/\\/Ni14UVdNaDdlcnRMcDh0X005aHVVRGsxTTBWcllK', '')
         url = string.gsub(url, '\\/\\/d05wMndCVE5jUFJRdlRDMF9DcHhDc3FfOFQxdTlR', '')
         url = string.gsub(url, '\\/\\/bWQtT2QyRzlSV09nU2E1SG9CU1NiV3JDeUlxUXlZ', '')
         url = string.gsub(url,'\\/\\/a3p1T1lRcUJfUVNPTC14ek5fS3oza2tna0hoSGl0', '')
         url = string.gsub(url,'VfR0xFc1h4bnBVNExqamQwUmVZLVZI', '')
         url = string.gsub(url,'\\/\\/UnlUd3RmMT', '')




         url=http.urldecode(base64_decode(url))
  


        
        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(240p)](http.-.m3u8)') do
			
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
      
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        
		        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(360p)](http.-.m3u8)') do
			
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
			
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(480p)](http.-.m3u8)') do
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
           --  title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(720p)](http.-.m3u8)') do
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
         --    title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(1080p)](http.-.m3u8)') do
       title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')
         --    title = tolazy(title)
            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        end
    
    
    
    
          
  
  
  
  
        
  
    
--http://smartportaltv.ru/30/2.php?name=https://vid1665816108768.vb17121coramclean.pw/movie/43565112c2e4eec1fb44141ae768a7c9/iframe
    
	--	for url, url1 in string.gmatch(x, ' <iframe.-src="(.-/movie/)(.-/iframe)?d=ultradox.ru"') do
	--	 print(url) 
--		url = string.gsub(url, '^(.-)', 'http://smartportaltv.ru/30/2.php?name=') .. url1
	--	table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

	--	end
		
         for url in string.gmatch(x, '<div class="full%-story__ratings".-<img src=.-kinopoisk.ru/rating/(.-).gif') do
        
           print(url)
             
			url = string.gsub(url, '^(.-)', 'https://voidboost.net/embed/')
        --   url = string.gsub(url, ')', '')
       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
        local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do

            
          local slist=string.match(x, '<select name="season".->(.-)</select>')
          
           if slist then
          
             for url1, title in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
             

             
            local slist=string.match(x, '<select name="episode".->(.-)</select>')
            
           if slist then
            for url2, total in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do
         

          t['view'] = 'simple'
        	table.insert(t, {title = title .. ':' .. (total) .. ' (' .. total1 .. ')', mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
			end
			end
   	    	end	
   	    	end
            end	
   	    	end
    

--https://voidboost.net/movie/149fa08a44c989e65e37289b4c796736/iframe?h=baskino.me

          local slist=string.match(x,'<select name="translator.->Перевод.->(.-)</div>')

            if slist then
     
             for url3, total1 in string.gmatch(slist, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
             
             
          t['view'] = 'simple'
        	table.insert(t, {title = total1, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/movie/' .. url3 .. '/iframe?'})
             
            end
            end
    
          
	--		for url1, title in string.gmatch(x, '<option value="(.-)".->(Сезон.-)</option>') do
	--		end
     --     local x = string.match(x, '<select name="episode".->(.-)</select>')
			
     --      for url2, total in string.gmatch(x, '<option value="(.-)".->(Серия.-)</option>') do
	--	   end
            
         
    --      local x = string.match(x, '<select name="translator.->Перевод.->(.-)</div>')
      --      for url3, total1 in string.gmatch(x, '<option data%-token="(.-)" data%-d=.->(.-)</option>') do
    
         
         
       -- 	table.insert(t, {title = 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2, mrl = '#stream/q=content&id=' .. 'https://voidboost.net/serial/' .. url3 .. '/iframe?s=' .. url1 .. '&e=' .. url2})
	--		end

   		
   		
       for url  in string.gmatch(x, 'var CDNplayerConfig.-file.-#2(.-)\'') do
     --    print(url)
		 url = string.gsub(url, '//_//', '')
         url = string.gsub(url, 'Xl4jQEAhIUAjISQ=', '')
         url = string.gsub(url, 'JCQkIyMjIyEhISEhISE=', '')
         url = string.gsub(url, 'QCFeXiFAI0BAJCQkJCQ=', '')
         




         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, url in string.gmatch(url, '(360p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
			
        if url then
			for title, url in string.gmatch(url, '(480p).-(http.-.mp4)') do
             t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
				
               table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(720p).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p)].-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end	
        if url then
			for title, url in string.gmatch(url, '(1080p Ultra).-(http.-.mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title),mrl= url})
			end
		end
			end
		
		
		
		
		
--http://zagonka1.zagonkom.gb.net/embed/kp-1112513?v=1

--http://zagonka.tv/embed/kp-1316601_1?v=1

   
   
   
   
   
   
        for url in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
		 print(url) 
		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
		table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
     
     
        
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        
		if url then
			for title, total,  url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(360p).-or (//video.zagonka.org/movies/.-mp4)') do
           t['view'] = 'simple'
       
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
			
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
        if url then
			for title, total, url in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD).-or (//video.zagonka.org/movies/.-mp4)') do
            t['view'] = 'simple'
         
         url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url})
			end
		end	
     

        if url then
           
           
        for url in string.gmatch(url,'Ultradox.-Ultradox(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Ultradox)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        
       
       



        if url then
           
           
        for url in string.gmatch(url,'Coldfilm.-Coldfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Coldfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
       
       
    
    
    
        if url then
           
           
        for url in string.gmatch(url,'Lostfilm.-Lostfilm(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
        if url then
        for url in string.gmatch(url,'Rudub.-Rudub(.-)}]}') do
           
     --   for title, total in string.gmatch(url, 'Ultradox.-"title":".-class=\'in_tr\'>(Ultradox)<br><div class=\'mfs\'>(.-сезон)') do
        
        
        
			for total1, url, total2 in string.gmatch(url, '"file".-(360p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
        

     
			for total1, url, total2 in string.gmatch(url, '"file".-(480p)].-or (//video.zagonka.org/tvseries/.-.mp4),.-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1)  .. ' (' .. tolazy(total2) .. ')',mrl= url})
		
          end


    
			for total1, url, total2 in string.gmatch(url, '"file".-(HD)].-or (//video.zagonka.org/tvseries/.-mp4)".-class=\'in_e\'>(.-)&') do
            t['view'] = 'simple'
          url = string.gsub(url, '^(.-)', 'http:')
				table.insert(t,{title='(Lostfilm)' .. tolazy(total1) .. ' (' .. tolazy(total2) .. ')',mrl= url})
			end
		end	
        end
    
       
        
        
    end
   
--Lostfilm Rezka Rudub
     
     
 --  http://sp-social.ru/19/divan.php?name=  
     
         for url in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
		 print(url) 
		 
        url = string.gsub(url, '^(.-)', 'http://sp-social.ru/19/divan.php?name=') 


--		url = string.gsub(url, '^(.-)', 'http://sp-social.ru/kinopoisk/2.php?name=')
       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end
		
	for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end	

        
		 
		

         
     local x = conn:load(args.id)
     for title, url in string.gmatch(x, '<title.-CDATA%[(.-)].-<stream.-(https.-master.m3u8)') do
         t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})
       
		end
		
		
	--local x = conn:load(args.id)	
    -- for title in string.gmatch(x, '<h1.->(.-)</h1>') do
       
       --  title=http.urlencode(title)

        -- title = string.gsub(title, '+', '%%20')
    
    
        --  url = string.gsub(title, '^(.-)', 'http://stvplay.mooo.com:81/vk/vk.php?search=')
    

   
     --  local x = http.getz(url)
       
  -- for url, total in string.gmatch(x, '</channel.-<channel.-playlist_url>.-(http.-)].-description>.-<h3>(.-)</h3>') do


      -- local x = http.getz(url)
   
      --  for total1, url in string.gmatch(x, '<title>.-(1080p).-<stream_url>.-(https.-)]') do
   
     -- table.insert(t, {title = total, mrl = url})
    
      --  end
   --end
  -- end
		
		
	elseif args.q == 'play' then
		return video(args.url, args)
	end
	return t
end
