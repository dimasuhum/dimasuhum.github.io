-- Octopus plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')




local fxml = onCreate
--src="//bigpkcqnm.tevas.tech/kino/download/top/Voron_fhd_2024.mp4

--https://my.ultradox.fun/42643-bespredelnye-puteshestviya-vo-vremeni-2023.html


--https://bigpkcqnm.tevas.tech/kino/download/Bespredelnye_puteshestvija_vo_vremeny_2023.mp4

--https://tevas.tv/kino/download/?f=Bespredelnye_puteshestviya_vo_vremeni_2023.mp4&sea=268962182929&big=885

--https://tevas.tv/kino/download/?f=Poltergejst_drugoe_izmerenie_2024.mp4


--https://my.ultradox.fun/42889-poltergeyst-drugoe-izmerenie-2023.html

--https://bigpkcqnm.tevas.tech/kino/download/Zaklyate_slugy_satany_fhd_2017.mp4

--https://tevas.tv/serial/zhizn_po_vyzovu/01_1080/?f=tevas_zhizn_po_vyzovu_fhd_01_05.mp4&big=885

--https://tevas.tv/kino/download/?f=Ubijstvennaya_zhara_2024.mp4


--<meta property="og:image" content="https://www.kinopoisk.ru/rating/846892/.gif" /


--<meta property="og:image" content="https://www.kinopoisk.ru/rating/1112513.gif

--https://api.tobaco.ws/embed/kp/846892

--https://my.ultradox.fun/42962-ubiystvennaya-zhara-2024.html

--https://tevas.tv/serial/top/vlastelin_kolec_kolca_vlasti/01/?f=tevas_vlastelin_kolec_kolca_vlasti_01_01.mp4&big=884


--https://bigpkcqnm.tevas.tech/kino/download/vlastelin_kolec_kolca_vlasti_1_1.mp4


--https://my.ultradox.fun/42330-vlastelin-kolec-kolca-vlasti-2-sezon.html


local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local HOME = 'https://ultradox.today'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'windows-1251'
local conn1 = client.new()
conn1['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH
conn1['root'] = HOME_SLASH



--HOME = 'http://my.ultradox.press'

--HOME_SLASH = HOME .. '/'
--windows-1251

function onLoad()
	print('Hello from octopusfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from octopusfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
--	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/page=/nerufilm/	
	-- #stream/genre=/hd/
	-- #stream/genre=/webrips/
	-- #stream/genre=/camrip/
    -- #stream/url=/serial/
	-- #stream/url=/rufilm/
	-- #stream/url=/hd/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/nerufilm/hd/'
		local url = HOME .. genre
		--local url1 = HOME1 .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
			--url1 = url1 .. '/page/' .. tostring(page) .. '/'
		end
        
	--	local x = http.getz(url)
       local x = conn:load(url)
      --  x = iconv(x, 'windows-1251', 'UTF-8')
		for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-src=.-(/uploads/.-jpg)".-<span>(.-)</span>') do
	
          image = string.gsub(image, '^(.-)', HOME)
            if image and not string.find(image, '://') then
				image = HOME .. image
			end
	
	--		image = string.gsub(image, '^(.-)', 'http://ultradox.asia')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		--local x = http.getz(url1)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
		--	image = string.gsub(image, '^/', HOME_SLASH1)
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x =  conn:load(HOME)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
	--	x = string.match(x, 'div class="top__menu_ul">(.-)</div>')
    --    for genre, title in string.gmatch(x,'<a href="(.-)">(.-)</a>') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. '/'})
	--	end
        table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serial/'})
        table.insert(t, {title = 'HDRIP / BDRIP', mrl = '#stream/genre=' .. '/nerufilm/hd/'})
        table.insert(t, {title = 'НАШЕ КИНО', mrl = '#stream/genre=' .. '/rufilm/'})
        table.insert(t, {title = 'CAMRIP / TS', mrl = '#stream/genre=' .. '/nerufilm/camrip/'})
        table.insert(t, {title = 'WEB-DL', mrl = '#stream/genre=' .. '/nerufilm/webrips/'})
        table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/anime/'})
        
    
    
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
--	args.keyword = encoding.default(utf-8)		local page = tonumber(args.page or '1')

       local url = 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=' .. urlencode(args.keyword) .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
	
--url = string.gsub(title, '^(.-)', 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=') .. '&year=' .. title1 .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
  
     

	--	local x = conn1:load(url)
		
  --      for title, total, image in string.gmatch(x, '{"id":(.-),"name":"(.-)".-poster":{"url":"(.-)"') do
      
   --   url1 = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=') .. '&box_mac=acace24b8434'
          --  image = string.gsub(image, '^(.-)', HOME) 
          
          
      
          
	--		table.insert(t, {title = total, mrl = '#stream/q=content&id=' .. url1, image = image})
		
	--	end
		
    --	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
--		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
    
   	-- #stream/q=content&id=https://api.kinopoisk.dev/v1.4/movie/386?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
   	
	-- #stream/q=content&id=http://m.octopusfilm.su/16160-sila-prirody-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	
		local x =  conn:load(args.id)
	--	local x = http.getz(args.id)
		
       -- x = iconv(x, 'windows-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'(Сюжет:.-)<br>')
		t['poster'] = parse_match(x,'<div class="full%-story__top__info%-poster".-img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(Год:</span>.-)</li>', '(Страна:</span>.-)</li>',  '(Перевод:</span>.-)</li>', '(Жанр:</span>.-)</li>', '(Качество:</span>.-)</li>', '(Режиссерский состав:</span>.-)</li>', '(В Ролях:</span>.-)</li>', 
		})

--http://hidxlglk.deploy.cx/lite/fancdn?kinopoisk_id=386

 

 

 --   for title3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
    --  title = urlencode(title)
     
  --    title = string.gsub(title, '+', '%%20')
      
    
  --     url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
       
  --   local x = conn1:load(args.id)
     
  --    local x = conn1:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
    --  for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

   --   local x = conn1:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
  -- for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
  --  table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
 --    end
  --  end
--  end
  
  
  
    
    
    
  -- local x = conn:load(args.id)



  
      for url, url1 in string.gmatch(x, '(https://vid.-)(/movie.-)"') do

  --  url = urlencode(url)
 --   url1 = urlencode(url1)
    
       url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. url1
       --.. '&play=1'

    --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
--	end
       local x = conn1:load(url)


         for url2 in string.gmatch(x, '"parser":"(http.-)"') do 
         
        url2 = string.gsub(url2, '\\', '')

      local x = conn1:load(url2)

         for title, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
         for title, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
        for title, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')
     url = string.gsub(url, '480', '720')

       table.insert(t, {title = '720p', mrl = url})

       end
       
      for title, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')
     url = string.gsub(url, '480', '1080')

       table.insert(t, {title = '1080p', mrl = url})

       end
       
       end
     	end



     


    
 
     local x = conn:load(args.id)
 
     for title3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
  
--http://smotret24.ru/online.js
--http://178.20.46.40:12600/lite/filmix?kinopoisk_id=386

      url1 = string.gsub(title3, '^(.-)', 'https://mylam.ru/lite/vdbmovies?kinopoisk_id=') 


  --  table.insert(t, {title = url1, mrl = '#stream/q=content&id=' .. url1, image = image})

    table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=content&id=' .. url1, image = image})
        end
    --   end
        
        
       local x = conn1:load(args.id)
   
     for total1 in string.gmatch(x, '"method":"play".-"url":"http.-class="videos__item%-title">(.-)<') do
      
   
      local x = string.match(x, '"quality"(.-)"translate"')
      
      
   for total,  url2 in string.gmatch(x, '"(.-p)":"(http.-mp4)"') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :'.. tolazy(total) .. ' ' .. tolazy(total1), mrl = url2})

      end 
    end
    
    
    
        for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-videos__season%-title.->(.-сезон)</div>') do


      local x = conn1:load(url2)

   

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url".-"(http.-)".->(.-)</div>') do

     local x = conn1:load(url3)


      for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(http.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do

  --   url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end
 
 
 
    local x = conn:load(args.id)
 
     for total in string.gmatch(x, '<a href="magnet:.-btih:(.-)&') do
    
       total = string.lower(total)
      url = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      
 --  table.insert(t, {title = url, mrl = url})
        local x = conn1:load(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
     --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
     --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        
	end
	end
      
 
   

  
  
		elseif args.q == 'video' then
		return {{title = args.t, mrl = args.url}}
		
	elseif args.q == 'play' then
		return video(args.url, args)
	end
	return t
end
