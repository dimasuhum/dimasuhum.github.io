-- Octopus plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')




local fxml = onCreate
--src="//bigpkcqnm.tevas.tech/kino/download/top/Voron_fhd_2024.mp4

--https://my.ultradox.fun/42643-bespredelnye-puteshestviya-vo-vremeni-2023.html


--https://bigpkcqnm.tevas.tech/kino/download/Bespredelnye_puteshestvija_vo_vremeny_2023.mp4

--https://tevas.tv/kino/download/?f=Bespredelnye_puteshestviya_vo_vremeni_2023.mp4&sea=268962182929&big=885

--https://tevas.tv/kino/download/?f=Poltergejst_drugoe_izmerenie_2024.mp4


--https://my.ultradox.fun/42889-poltergeyst-drugoe-izmerenie-2023.html

--https://bigpkcqnm.tevas.tech/kino/download/Zaklyate_slugy_satany_fhd_2017.mp4

--https://tevas.tv/serial/zhizn_po_vyzovu/01_1080/?f=tevas_zhizn_po_vyzovu_fhd_01_05.mp4&big=885

--https://tevas.tv/kino/download/?f=Ubijstvennaya_zhara_2024.mp4


--<meta property="og:image" content="https://www.kinopoisk.ru/rating/846892/.gif" /


--<meta property="og:image" content="https://www.kinopoisk.ru/rating/1112513.gif

--https://api.tobaco.ws/embed/kp/846892

--https://my.ultradox.fun/42962-ubiystvennaya-zhara-2024.html

--https://tevas.tv/serial/top/vlastelin_kolec_kolca_vlasti/01/?f=tevas_vlastelin_kolec_kolca_vlasti_01_01.mp4&big=884


--https://bigpkcqnm.tevas.tech/kino/download/vlastelin_kolec_kolca_vlasti_1_1.mp4


--https://my.ultradox.fun/42330-vlastelin-kolec-kolca-vlasti-2-sezon.html


local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


local HOME = 'http://my.ultradox.xyz'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'windows-1251'
local conn1 = client.new()
conn1['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH
conn1['root'] = HOME_SLASH



--HOME = 'http://my.ultradox.press'

--HOME_SLASH = HOME .. '/'
--windows-1251

function onLoad()
	print('Hello from octopusfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from octopusfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
--	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/page=/nerufilm/	
	-- #stream/genre=/hd/
	-- #stream/genre=/webrips/
	-- #stream/genre=/camrip/
    -- #stream/url=/serial/
	-- #stream/url=/rufilm/
	-- #stream/url=/hd/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/nerufilm/hd/'
		local url = HOME .. genre
		--local url1 = HOME1 .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
			--url1 = url1 .. '/page/' .. tostring(page) .. '/'
		end
        
	--	local x = http.getz(url)
       local x = conn:load(url)
      --  x = iconv(x, 'windows-1251', 'UTF-8')
		for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-src=.-(/uploads/.-jpg)".-<span>(.-)</span>') do
	
          image = string.gsub(image, '^(.-)', HOME)
            if image and not string.find(image, '://') then
				image = HOME .. image
			end
	
	--		image = string.gsub(image, '^(.-)', 'http://ultradox.asia')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		--local x = http.getz(url1)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
		--	image = string.gsub(image, '^/', HOME_SLASH1)
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x =  conn:load(HOME)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
	--	x = string.match(x, 'div class="top__menu_ul">(.-)</div>')
    --    for genre, title in string.gmatch(x,'<a href="(.-)">(.-)</a>') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. '/'})
	--	end
        table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serial/'})
        table.insert(t, {title = 'HDRIP / BDRIP', mrl = '#stream/genre=' .. '/nerufilm/hd/'})
        table.insert(t, {title = 'НАШЕ КИНО', mrl = '#stream/genre=' .. '/rufilm/'})
        table.insert(t, {title = 'CAMRIP / TS', mrl = '#stream/genre=' .. '/nerufilm/camrip/'})
        table.insert(t, {title = 'WEB-DL', mrl = '#stream/genre=' .. '/nerufilm/webrips/'})
        table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/anime/'})
        
    
    
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
--	args.keyword = encoding.default(utf-8)		local page = tonumber(args.page or '1')

       local url = 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=' .. urlencode(args.keyword) .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
	
--url = string.gsub(title, '^(.-)', 'https://api.kinopoisk.dev/v1.4/movie/search?page=1&limit=10&query=') .. '&year=' .. title1 .. '&token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
  
     

		local x = conn1:load(url)
		
        for title, total, image in string.gmatch(x, '{"id":(.-),"name":"(.-)".-poster":{"url":"(.-)"') do
      
      url1 = string.gsub(title, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=') .. '&box_mac=acace24b8434'
          --  image = string.gsub(image, '^(.-)', HOME) 
          
          
      
          
			table.insert(t, {title = total, mrl = '#stream/q=content&id=' .. url1, image = image})
		
		end
		
    --	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
--		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
    
   	-- #stream/q=content&id=https://api.kinopoisk.dev/v1.4/movie/386?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
   	
	-- #stream/q=content&id=http://m.octopusfilm.su/16160-sila-prirody-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	
		local x =  conn:load(args.id)
	--	local x = http.getz(args.id)
		
       -- x = iconv(x, 'windows-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'(Сюжет:.-)<br>')
		t['poster'] = parse_match(x,'<div class="full%-story__top__info%-poster".-img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
			'(Год:</span>.-)</li>', '(Страна:</span>.-)</li>',  '(Перевод:</span>.-)</li>', '(Жанр:</span>.-)</li>', '(Качество:</span>.-)</li>', '(Режиссерский состав:</span>.-)</li>', '(В Ролях:</span>.-)</li>', 
		})

--http://hidxlglk.deploy.cx/lite/fancdn?kinopoisk_id=386

 

 

    for title, title1, title3  in string.gmatch(x,'<h1.->(.-)%((.-)%).-class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do

      title = urlencode(title)
     
      title = string.gsub(title, '+', '%%20')
      
  
       url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
     
      local x = conn1:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
      for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

      local x = conn1:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
   for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
    table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
     end
    end
  end
  
  
  
    
    
    
--local x = conn:load(args.id)



  
      for url, url1 in string.gmatch(x, '(https://vid.-)(/movie.-)"') do

  --  url = urlencode(url)
 --   url1 = urlencode(url1)
    
       url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. url1
       --.. '&play=1'

    --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
--	end
       local x = conn1:load(url)


         for url2 in string.gmatch(x, '"parser":"(http.-)"') do 
         
        url2 = string.gsub(url2, '\\', '')

      local x = conn1:load(url2)

         for title, url in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       
         for title, url in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
        for title, url in string.gmatch(x, '(720p).-(http.-m3u8)') do
		
         print(url)
		 url = string.gsub(url, '\\', '')


       table.insert(t, {title = title, mrl = url})

       end
       end
     	end




    for title3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
  
    
    
    url1 = string.gsub(title3, '^(.-)', 'https://lam.maxvol.pro/lite/lumex?kinopoisk_id=') 
       --.. '&uid=m7alois3'
 
    table.insert(t, {title = 'Lumex', mrl = '#stream/q=content&id=' .. url1, image = image})
         end
    --     end
    local x = conn1:load(args.id)
    
     
       for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-)</div>') do
  
  
  
  
      url2 = string.gsub(url2, '\\u0026', '&')
  --   url2 = urldecode(url2)
      
    url2 = string.gsub(url2, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.67.229.77&h=https://p.lumex.space'
  
 -- table.insert(t, {title = url2, mrl = url2})
     
      local x = conn1:load(url2)
  
  for  url3 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '240/index', '1080/index')
      url3 = string.gsub(url3, '240.mp4', '1080.mp4')
  url3 = string.gsub(url3, '^(.-)', 'http://45.67.229.77/hls/')
  
       t['view'] = 'simple'

  -- table.insert(t, {title = url3, mrl = url3})

   table.insert(t, {title = 'lumex :' .. tolazy(total), mrl = url3})
       
    end
     end

     
     for url2, total1  in string.gmatch(x, 'class="videos__item videos__season.-"link".-"url".-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'https://lam.maxvol.pro')
    
   --   url2 = string.gsub(url2, 'rjson=False&', '')
    
      local x = conn1:load(url2)

      for url3, total2  in string.gmatch(x, 'class="videos__button selector.-"link".-"url".-(/lite.-)".->(.-)</div>') do
         
         url3 = string.gsub(url3, '\\u0026', '&')
 
       url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
    
  --   url3 = string.gsub(url3, 'rjson=False&', '')
    
     local x = conn1:load(url3)


      for url4, total3  in string.gmatch(x, 'class="videos__item videos__movie selector.-"play".-"url".-playlist=(.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=vcdn&tid=&media_type=&u=') .. '&varip=45.67.229.77&h=https://p.lumex.space'
    
     local x = conn1:load(url4)
  
  for  url5 in string.gmatch(x, '"url":.-"http.-(http.-m3u8)"') do
  
      url5 = string.gsub(url5, '\\', '')
     url5 = string.gsub(url5, '240/index', '720/index')
      url5 = string.gsub(url5, '240.mp4', '720.mp4')
  url5 = string.gsub(url5, '^(.-)', 'http://45.67.229.77/hls/')
  
       t['view'] = 'simple'
   
   
    table.insert(t, {title = 'lumex :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url5})

       
    end
end
end
end
   local x = conn:load(args.id)

       for url in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
  
  
  
        url = string.gsub(url, '^(.-)', 'https://kinovibe.co/api/find-by-kinopoisk.php?kinopoisk=')
    --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
    
       local x = http.getz(url)
   

   
       for title, url  in string.gmatch(x, 'url.-http.-kinovibe.co.-%-(.-).html.-embed.-(http.-)"') do
   
       url = string.gsub(url, '\\', '')
   
       title = string.gsub(title, 'series', '')
         
    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})

       end
       end
   

        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
         
        t['view'] = 'simple'
         
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
     
         t['view'] = 'simple'
     
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
         t['view'] = 'simple'
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end



		
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-id:"playerjshd".-file:"(.-txt)"') do
         -- print(url)
      --    t['view'] = 'grid'
       --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' ..  url})
    --table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' ..  url})
--		end

       local x = http.getz(url)



           for title, url in string.gmatch(x, '"comment":"(.-)".-file.-(https://s.-mp4)"') do
			print(url)  

          url = string.gsub(url, '_[480,720]', '')
          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title), mrl = url})
        end



		for title, url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do

          t['view'] = 'grid'

   
       table.insert(t, {title = tolazy(title) .. ' (480p)'  , mrl = url .. url1 .. '_480.mp4'})
   

        end
	
	
          for title,  url, url1 in string.gmatch(x, '"comment":"(.-)".-file.-(https.-video_mp4)(/.-)_.-480') do
		--	print(url)  

      --    url = string.gsub(url, '(.-)', url) .. '_720.mp4'
          t['view'] = 'grid'
   --     t['viewtype'] = 'playlist'
   
       table.insert(t, {title = tolazy(title) .. ' (720p)', mrl = url .. url1 .. '_720.mp4'})
   
   --     table.insert(t, {title = tolazy(title) .. (total), mrl = url})
        end
	
      end



         for total in string.gmatch(x, '<a href="magnet:.-btih:(.-)&') do
    
       total = string.lower(total)
      url = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      
 --  table.insert(t, {title = url, mrl = url})
        local x = conn1:load(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
     --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
     --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        
	end
	end		
  
  
  
  
	
		
		
--http://zagonka1.zagonkom.gb.net/embed/kp-1112513?v=1

--http://zagonka.tv/embed/kp-1316601_1?v=1

   
   
   
   
--local x = conn:load(args.id)
   
    --    for url in string.gmatch(x, '<div class="full%-story__ratings".-<img src=--".-kinopoisk.ru/rating/(.-).gif"') do
	--	 print(url) 
--		url = string.gsub(url, '^(.-)', 'http://zagonka1.zagonkom.gb.net/embed/kp-') .. '?v=1'
	--	table.insert(t, {title = 'Zagonka', mrl = '#stream/q=content&id=' .. url})

--		end
     
   

--var zpjs=new Playerjs({id:"zpjs",file:"#2

--local url = conn1:load(args.id)
     
    --    local x = conn:load(args.id)
     
         for url in string.gmatch(x,'var zpjs=new Playerjs.-zpjs.-file.-#2(.-)"') do
         url = string.gsub(url, '//OyokXiZAISV8', '')
         

         url=http.urldecode(base64_decode(url))
        



		
		if url then
			for title, total,  url1, url2 in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div>.-class=\'fllq\'.-"file".-(360p).-(//.-movies)(/.-})') do
           t['view'] = 'simple'
       
         url1 = string.gsub(url1, '^(.-)', 'http:')
         url2 = string.gsub(url2, '{v1}', '.mp4')
         
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url1 .. url2})
			end
		end	
			
        if url then
			for title, total, url1, url2 in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(480p)].-(//.-movies)(/.-})') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
           url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url1 .. url2})
			end
		end	
        if url then
			for title, total, url1, url2 in string.gmatch(url, '"title":.-class=\'mfs\'>(.-)</div><div class=\'fllq\'.-"file".-(HD)].-(//.-movies)(/.-})') do
            t['view'] = 'simple'
         
         url1 = string.gsub(url1, '^(.-)', 'http:')
         url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title=tolazy(title) .. ' (' .. tolazy(total) .. ')',mrl= url1 .. url2})
			end
		end	
   
   

        local slist = string.match(url,'Coldfilm.-Coldfilm(.-)}]}') 


      if slist then

			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Coldfilm' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
	
		end	
    end
  
  
    
  
     local slist = string.match(url,'Ultradox.-Ultradox(.-)}]}')

      if slist then


			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Ultradox' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
			end
		end
			
  
   
  
  
       local slist = string.match(url,'Lostfilm.-Lostfilm(.-)}]}')


       if slist then

			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Lostfilm' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
		end
		end	
  
  
      local slist = string.match(url,'Rezka.-Rezka(.-)}]}')

       if slist then


			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Rezka' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
				
		end
		end	
  
     
     
     
     local slist = string.match(url,'Rudub.-Rudub(.-)}]}')
     
     
         if slist then

			for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_.-e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Rudub' .. ' ' ..  'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
		
		end	
     end
       
      
      local slist = string.match(url,'"title"(.-)}]}')
     
     
         if slist then
     for url1, url2, total, total1 in string.gmatch(slist, '"file".-%[HD.-(//.-tvseries)(/.-})".-"title":"<div id=\'s_(.-)_tr_7_e_(.-)_\'') do
            t['view'] = 'simple'
          url1 = string.gsub(url1, '^(.-)', 'http:')
		
          url2 = string.gsub(url2, '{v1}', '.mp4')
				table.insert(t,{title= 'Сезон :' .. total .. ' ' .. 'серия :' .. total1,mrl= url1 .. url2})
		
		end	
        end
       

end


     
  
     for title3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
  
    url1 = string.gsub(title3, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=')

     table.insert(t, {title = 'Источники', mrl = '#stream/q=content&id=' .. url1})
     end
    
    
    local x = conn1:load(args.id)


     for title3, title, title1  in string.gmatch(x, '"current_page":.-"id".-"kinopoisk_id":(.-),.-"name_russian":"(.-)".-"year.-:"(.-)"') do
    
    title = string.gsub(title, '\\u0410', 'А')
      title = string.gsub(title, '\\u0430', 'а')
       
       title = string.gsub(title, '\\u0411', 'Б')
       title = string.gsub(title, '\\u0431', 'б')  
       title = string.gsub(title, '\\u0412', 'В')
      title = string.gsub(title, '\\u0432', 'в')
       title = string.gsub(title, '\\u0413', 'Г')
       title = string.gsub(title, '\\u0433', 'г')  
      title = string.gsub(title, '\\u0414', 'Д')
      title = string.gsub(title, '\\u0434', 'д')
       title = string.gsub(title, '\\u0415', 'Е')
       title = string.gsub(title, '\\u0435', 'е')  
      title = string.gsub(title, '\\u0401', 'Ё')
      title = string.gsub(title, '\\u0451', 'ё')
       title = string.gsub(title, '\\u0416', 'Ж')
       title = string.gsub(title, '\\u0436', 'ж')  
       title = string.gsub(title, '\\u0417', 'З')
      title = string.gsub(title, '\\u0437', 'з')
       title = string.gsub(title, '\\u0418', 'И')
       title = string.gsub(title, '\\u0438', 'и')  
       title = string.gsub(title, '\\u0419', 'Й')
      title = string.gsub(title, '\\u0439', 'й')
       title = string.gsub(title, '\\u041a', 'К')
       title = string.gsub(title, '\\u043a', 'к')  
       title = string.gsub(title, '\\u041b', 'Л')
       title = string.gsub(title, '\\u043b', 'л')
       title = string.gsub(title, '\\u041c', 'М')
       title = string.gsub(title, '\\u043c', 'м')
       title = string.gsub(title, '\\u041d', 'Н')
       title = string.gsub(title, '\\u043d', 'н')
       title = string.gsub(title, '\\u041e', 'О')
       title = string.gsub(title, '\\u043e', 'о')
       title = string.gsub(title, '\\u041f', 'П')
       title = string.gsub(title, '\\u043f', 'п')
       title = string.gsub(title, '\\u0420', 'Р')
       title = string.gsub(title, '\\u0440', 'р')
       title = string.gsub(title, '\\u0421', 'С')
       title = string.gsub(title, '\\u0441', 'с')
       title = string.gsub(title, '\\u0422', 'Т')
       title = string.gsub(title, '\\u0442', 'т')
       title = string.gsub(title, '\\u0423', 'У')
       title = string.gsub(title, '\\u0443', 'у')
       title = string.gsub(title, '\\u0424', 'Ф')
        title = string.gsub(title, '\\u0444', 'ф')
        title = string.gsub(title, '\\u0425', 'Х')
        title = string.gsub(title, '\\u0445', 'х')
        title = string.gsub(title, '\\u0426', 'Ц')
        title = string.gsub(title, '\\u0446', 'ц')
        title = string.gsub(title, '\\u0427', 'Ч')
        title = string.gsub(title, '\\u0447', 'ч')
        title = string.gsub(title, '\\u0428', 'Ш')
        title = string.gsub(title, '\\u0448', 'ш')
        title = string.gsub(title, '\\u0429', 'Щ')
        title = string.gsub(title, '\\u0449', 'щ')
        title = string.gsub(title, '\\u042a', 'Ъ')
        title = string.gsub(title, '\\u044a', 'ъ')
        title = string.gsub(title, '\\u042b', 'Ы')
        title = string.gsub(title, '\\u044b', 'ы')
        title = string.gsub(title, '\\u042c', 'Ь')
        title = string.gsub(title, '\\u044c', 'ь')
        title = string.gsub(title, '\\u042d', 'Э')
        title = string.gsub(title, '\\u044d', 'э')
        title = string.gsub(title, '\\u042e', 'Ю')
        title = string.gsub(title, '\\u044e', 'ю')
        title = string.gsub(title, '\\u042f', 'Я')
        title = string.gsub(title, '\\u044f', 'я')
        title = string.gsub(title, '\\u00ab', '<<')
        title = string.gsub(title, '\\u00bb', '>>')
        title = string.gsub(title, '\\u2014', '-')

     title = urlencode(title)
      
      title = string.gsub(title, '+', '%%20')

   
   
   
   
   
    
   
      
       url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/hdvb?kinopoisk_id=') 
    
       
      local x = conn1:load(url1)

     
       for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
   
      local x = conn1:load(url2 .. url3)

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :' .. tolazy(total2), mrl = url4})

      end 
      end
      

      
 
     for url2, url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url3 = string.gsub(url3, '\\u0026', '&')

     local x = conn1:load(url2 .. url3)

      for url4, url5, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-hdvb)(.-)".->(.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
     local x = conn1:load(url4 .. url5)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url6 = string.gsub(url6, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = url6})
    end
end
end
 




           
       url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/mirage?kinopoisk_id=')
    
    
    local x = conn1:load(url1)
       for  url2, url3,  total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"url":"(http.-mirage)(.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')

    
       local x = conn1:load(url2 .. url3)
    
      local x = string.match(x, '"quality"(.-)}}')
      for  total3, url4 in string.gmatch(x, '"(.-p)":"(http.-)"') do
    
    
    
       t['view'] = 'simple'

    table.insert(t, {title = 'mirage :' .. tolazy(total2) .. '(' .. tolazy(total3) .. ')', mrl = url3})

      end 
      end
     
  

      
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

     url2 = string.gsub(url2, '\\u0026', '&')
     
   --  table.insert(t, {title = url2, mrl = url2})
     
      local x = conn1:load(url2)


      for url3, url4, total1, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"url":"(http.-mirage)(.-)".-voice_name":"(.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
      local x = conn1:load(url3 .. url4)
     local x = string.match(x, '"quality"(.-)}}')
      for  total3, url5 in string.gmatch(x, '"(.-p)":"(http.-)"') do
    
    
       t['view'] = 'simple'

    table.insert(t, {title = 'mirage :'  .. total .. ' '  .. tolazy(total2) .. '(' .. total3 .. ')' .. '(' .. total1 .. ')', mrl = url5})

    end
end
end



  
       
url1 = string.gsub(title3, '^(.-)', 'https://api.manhan.one/lite/filmix?id=258687&kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
  
      local x = conn1:load(url1)
      
     for  url3, total2 in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

   table.insert(t, {title = 'filmix' .. ':'.. tolazy(total2), mrl = url3})

     end  


      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn1:load(url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn1:load(url4)


      for url5, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'filmix :' .. total .. ' '  .. tolazy(total3) .. total2, mrl = url5})

       
    end

end
end



url1 = string.gsub(title3, '^(.-)', 'http://147.45.77.28:9118/lite/videodb?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 
  
  
    
      local x = conn1:load(url1)

   
   for  url2, url3, total in string.gmatch(x, '"method".-"url":.-(/lite.-link=)(.-)".-class="videos__item%-title">(.-)<') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://147.45.77.28:9118')
     
     
      url3 = urldecode(url3)
    

      t['view'] = 'simple'
    
 --    table.insert(t, {title = url2 .. url3, mrl = url2 .. url3})
 
    table.insert(t, {title = 'Videodb' .. ':'.. tolazy(total), mrl = url2 .. url3})

      end 
    

  --  local x = conn:load(url1)


      for  url2, total in string.gmatch(x, '"method".-"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
 
     url2 = string.gsub(url2, '^(.-)', 'http://147.45.77.28:9118') 
       local x = conn:load(url2)
  

    for  url3, total1 in string.gmatch(x, '<div class="videos__button.-"method".-"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

      url3 = string.gsub(url3, '^(.-)', 'http://147.45.77.28:9118') 
       local x = conn1:load(url3)

   
      for  url4, url5, total2 in string.gmatch(x, '"method":"play".-"url".-(/lite.-serial=)(.-)".-class="videos__item%-title">(.-эпизод)<') do
  
    url4 = string.gsub(url4, '^(.-)', 'http://147.45.77.28:9118')
    
      url5 = string.gsub(url5, '\\u0026', '&') 
     url5 = urldecode(url5)
      t['view'] = 'simple'
 
 
 --    table.insert(t, {title = url4 .. url5, mrl = url4 .. url5})
 
    table.insert(t, {title = 'Videodb' .. ':' .. tolazy(total) .. ' ' .. total2 .. '('.. total1 .. ')', mrl = url4 .. url5})

     end
     end
    end
    



     
     url1 = string.gsub(title3, '^(.-)', 'http://194.169.160.7:42401/lite/vdbmovies?kinopoisk_id=') .. '&uid=m7alois3'


--table.insert(t, {title = url1, mrl = '#stream/q=content&id=' .. url1, image = image})


 --   table.insert(t, {title = 'Vdbmovies', mrl = '#stream/q=content&id=' .. url1, image = image})
   --    end
 --      end

    local x = conn1:load(url1)

       for  url1, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-)</div>') do
  
      url1 = string.gsub(url1, '\\u0026', '&')
    url1 = string.gsub(url1, '^(.-)', 'http://194.169.160.7:42401')


      t['view'] = 'simple'


   table.insert(t, {title = 'vdbmovies' .. ':'.. tolazy(total), mrl = url1})

       
    end

    
  
     
     for url2, total1  in string.gmatch(x, '"method":"link".-"url":"http.-(/lite.-)".-videos__season%-title">(.-сезон)</div>') do

    --     url2 = string.gsub(url2, '\\u0026', '&')
 
        url2 = string.gsub(url2, '^(.-)', 'http://194.169.160.7:42401')
    
  --    table.insert(t, {title = url2, mrl = '#stream/q=content&id=' .. url2, image = image})
 --   end
  
      local x = conn1:load(url2)

     

      for url3, total2  in string.gmatch(x, 'class="videos__button.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do
         
   --  table.insert(t, {title = url3, mrl = '#stream/q=content&id=' .. url3, image = image})
         
     --    url3 = string.gsub(url3, '\\u0026', '&')
 
      url3 = string.gsub(url3, '^(.-)', 'http://194.169.160.7:42401')
    
       
    
     local x = conn1:load(url3)
      
    for url4, total3 in string.gmatch(x, '<div class="videos__item videos__movie.-"method":"play".-"url".-(/proxy.-mp4)".-class="videos__item%-title">(.-cерия)</div>') do
         url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '^(.-)', 'http://194.169.160.7:42401')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vdbmovies :' .. total1 .. ' ' .. total3 .. ' ' .. tolazy(total2), mrl = url4})

    end   
    end
    end
  





    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/pidtor?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1
    --.. '&rjson=true'

    local x = conn1:load(url1)



      for  url2, url3,  total, total1 in string.gmatch(x, '"play".-"url":"(http.-pidtor)(.-)".-class="videos__item%-title">(.-)<.-<!%-%-(.-)%-') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'pidtor :' .. tolazy(total) .. ' ' .. total1, mrl = url2 .. url3})

       
    end





       url1 = string.gsub(title3, '^(.-)', 'https://lampa.maxvol.pro/lite/pidtor?kinopoisk_id=') .. '&serial=1&title=' .. title .. '&year=' .. title1

    local x = conn1:load(url1)



       for url2 in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">.-сезон</div>') do


      local x = conn1:load(url2)
    

      for url3, total2  in string.gmatch(x, 'class="videos__item videos__season selector.-"method":"link".-"url":"(http.-)".-videos__season%-title">(.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
   
   
       local x = conn1:load(url3)
   

   for total3, total4, url4, total5 in string.gmatch(x, 'class="videos__item videos__movie.-media.-s="(.-)".-e="(.-)".-"method":"play".-"url":"(http.-)".-videos__item%-title">(.-)</div>') do
   
   
   
     url4 = string.gsub(url4, '\\u0026', '&')
    url4 = string.gsub(url4, '\\u002B', '+')
   
   
       t['view'] = 'simple'

    table.insert(t, {title = 'pidtor : ' .. tolazy(total2) .. 'Сезон :' .. total3 .. 'серия :' .. total4 .. ' ' .. total5, mrl = url4})

     end  
    end
    end






      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/remux?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

    local x = conn1:load(url1)

    

      for  url2, total in string.gmatch(x, '"url".-(http.-)quality.-class="videos__item%-title">(.-)<') do
      
      url2 = string.gsub(url2, '\\u0026', '&')
      
       url2 = string.gsub(url2, '&', '')
      
      local x = conn1:load(url2)
      
       for  url3 in string.gmatch(x, '"play".-"url":.-(http.-)"') do

       t['view'] = 'simple'

   table.insert(t, {title = 'remux :' .. tolazy(total), mrl = url3})

     end  
    end




      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)".-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 
      


         url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=2160'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 2160p ' .. tolazy(total1), mrl = url2})
   
      end 
    

     url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=1080'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
 
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 1080p ' .. tolazy(total1), mrl = url2})
   
      end 


    url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=720'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 720p ' .. tolazy(total1), mrl = url2})
   
      end 


      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/jac?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1 .. '&quality=480'

      local x = conn1:load(url1)


       for  url2, total1 in string.gmatch(x, '"torrent".-"Link".-magnet:.-btih:(.-)&.-class="videos__torrent%-title">(.-)<') do
      
         url2 = url2:lower() 
         
    url2 = string.gsub(url2, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/s') .. '?tr='
     
       t['view'] = 'simple'

   table.insert(t, {title = 'jac :' .. ' 480p ' .. tolazy(total1), mrl = url2})
   
      end 
      



    
       url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=') 

    
     local x = conn1:load(url1)
   
   for  url2,  total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total), mrl = url2})

       
    end
    
      for url2, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn1:load(url2)

      for url3, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = conn1:load(url3)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

    end
end
end



   
       url1 = string.gsub(title, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/lesenfilmix.php?kinopoisk=') .. '+' .. title1 .. '+'
    
    local x = conn1:load(url1)
      
      	for url2 in string.gmatch(x, '<playlist_url><!%[CDATA%[(http.-)]]') do
	

       local x = conn1:load(url2)
    
    
    for total, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
	
	--     local x = conn1:load(url3)
	     
--	     for total1, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<stream_url><!%[CDATA%[(http.-)]]') do

    
    	t['view'] = 'simple'
    	
     table.insert(t, {title = 'kinopub :' .. total, mrl = url3, image = image})
         end
	     end
 --   end
    
    
     


  
    url1 = string.gsub(title, '^(.-)', 'http://185.188.183.182/iptv/kinotochka/atodo.php?perewod=') 
   
     local x = conn1:load(url1)
      
         

       for  url2 in string.gmatch(x, '</playlist_name><channel>.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[(http.-)]]') do

      local x = conn1:load(url2)
      
      
     for  url3 in string.gmatch(x, '<title><!%[CDATA%[дальше]].-<playlist_url><!%[CDATA%[(http.-)]]') do

       local x = conn1:load(url3)
       
      for total, url4 in string.gmatch(x, '<title><!%[CDATA%[(.-)]].-<parser><!%[CDATA%[(http.-)|url"') do
        
        local x = conn1:load(url4)

     for  url5 in string.gmatch(x, '</playlist_name>url":"(http.-)"') do
     t['view'] = 'simple'
      table.insert(t, {title = 'atodo :' .. tolazy(total), mrl = url5})

     end
     end
     end
    end

         

       for  url2 in string.gmatch(x, '</playlist_name><channel>.-<title><!%[CDATA%[.-]].-<playlist_url><!%[CDATA%[(http.-)]]') do

      local x = conn1:load(url2)
      
      
     for  url3 in string.gmatch(x, '<title><!%[CDATA%[дальше]].-<playlist_url><!%[CDATA%[(http.-)]]') do
     
       local x = conn1:load(url3)
       
      for total, url4 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]].-<playlist_url><!%[CDATA%[(http.-)]]') do
      
      local x = conn1:load(url4)

    for total1, url5 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]].-<playlist_url><!%[CDATA%[(http.-)]]') do

       local x = conn1:load(url5)
       
     for total2, url6 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]].-<parser><!%[CDATA%[(http.-)|url"') do


       local x = conn1:load(url6)
       
     for url7 in string.gmatch(x, '</playlist_name>url":"(http.-)"') do
     
     t['view'] = 'simple'
      table.insert(t, {title = 'atodo :' .. tolazy(total) .. ' ' ..  tolazy(total1) .. ' ' .. tolazy(total2), mrl = url7})

     end
     end
     end
    end
    end
    end








  
     



    url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=alloha-aloha&act=view&id=')
  
       local x = conn1:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   

        for total2, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
      
       local x = conn1:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
       
   

         for total3, url3 in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url>.-%[CDATA%[(http.-)]]') do
   
       t['view'] = 'simple'
				table.insert(t,{title='alloha' .. ':' .. tolazy(total2) .. ' ' .. (total3),mrl = url3})
			end
          end
      --    end
    --    end




     for total, url2  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Сезон.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
   
   
      local x = conn1:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
  
  
  
    for total1, url3  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    
       local x = conn1:load(url3 .. '&box_mac=acace24b8434' or url3 .. '&box_mac=b8bc5bf8dea3')
  
    for total2, url4  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(Серия.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
      local x = conn1:load(url4 .. '&box_mac=acace24b8434' or url4 .. '&box_mac=b8bc5bf8dea3')
    
    for total3, url5  in string.gmatch(x, '<channel>.-<title>(.-)</title>.-<stream_url><!%[CDATA%[(http.-)]]') do

      
      t['view'] = 'simple'
				table.insert(t,{title= 'alloha :' .. tolazy(total) .. ' ' .. (total1) .. ' ' .. (total2) .. ' ' .. (total3),mrl = url5})
			end
          end
          end
         end




       

  url1 = string.gsub(title3, '^(.-)', 'http://hidxlglk.deploy.cx/lite/collaps?kinopoisk_id=') .. '&uid=m7alois3'
    
    
      local x = conn1:load(url1)

   
     for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
    url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
      t['view'] = 'simple'

   table.insert(t, {title = 'collaps' .. ':'.. tolazy(total), mrl = url2})

       
    end

    
     
     for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

         url2 = string.gsub(url2, '\\u0026', '&')
 
           url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')
    
    
      local x = conn1:load(url2)


      for url3, total2  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"method":"play".-"url".-(/proxy.-)".-class="videos__item%-title">(.-серия)</div>') do
      
    
         url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '^(.-)', 'http://hidxlglk.deploy.cx')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'collaps' .. total1 .. ' '  .. tolazy(total2), mrl = url3})

       
    end

end



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/vibix?kinopoisk_id=') 

    local x = conn1:load(url1)


      for  url2, total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  

       t['view'] = 'simple'

   table.insert(t, {title = 'vibix :' .. tolazy(total), mrl = url2})

       
    end
     
  
  
    
    
       for url2, total1  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = conn1:load(url2)



      for url3, total2  in string.gmatch(x, 'class="videos__item videos__movie selector.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url3 = string.gsub(url3, '\\u0026', '&')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'vibix :' .. tolazy(total1) .. total2, mrl = url3})

       
    end

end



      url1 = string.gsub(title3, '^(.-)', 'https://lam.akter-black.com/lite/rezka?kinopoisk_id=') .. '&title=' .. title .. '&year=' .. title1

     local x = conn1:load(url1)
 
  
  
       for  url3, total1 in string.gmatch(x, '<div class="videos__item videos__movie.-"stream":"(http.-)".-class="videos__item%-title">(.-)</div>') do
  
      url3 = string.gsub(url3, '\\u0026', '&')
    url3 = string.gsub(url3, '\\u002B', '+')
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. tolazy(total1), mrl = url3})
  --   end
     end  
  
         local x = conn1:load(url1)

     
     for url3, total2  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do
     
     url3 = string.gsub(url3, '\\u0026', '&')

     url3 = string.gsub(url3, '\\u002B', '+')

  
     local x = conn1:load(url1)

   for url4, total3  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')

     url4 = string.gsub(url4, '\\u002B', '+')
     

      local x = conn1:load(url3)

      for url5, total4  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"(http.-)".-class="videos__item%-title">(Серия.-)</div>') do

     url5 = string.gsub(url5, '\\u0026', '&')

     url5 = string.gsub(url5, '\\u002B', '+')
     
    
       t['view'] = 'simple'

    table.insert(t, {title = 'rezka :' .. total2 .. ' '  .. tolazy(total3) .. ' ' .. total4, mrl = url5})

       
    end
end
end


end

    
    
  
  
  
  
  
		elseif args.q == 'video' then
		return {{title = args.t, mrl = args.url}}
		
	elseif args.q == 'play' then
		return video(args.url, args)
	end
	return t
end
