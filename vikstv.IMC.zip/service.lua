-- vikstv plugin

require('support')
require('video')
require('parser')

HOME = 'http://ip.viks.tv'
--HOME = 'http://ip.tivix.co'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from vikstv plugin')
	return 1
end

function onUnLoad()
	print('Bye from vikstv plugin')
end

function onCreate(args)
	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
	

	
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

	if not args.q then
	--	local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
	--	if page > 1 then
			url = url
			--.. 'page/' .. tostring(page)
	--	end
		local x = http.getz(url)
         
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for url, title, image  in string.gmatch(x, '<div class="all_tv".-<a href="(.-)" title="(.-)".-<img.-src="(.-)"') do
          image = string.gsub(image, '^(.-)', HOME)

          url = string.gsub(url, '^(.-)', HOME)
			local url = '#stream/q=content&id=' .. url
			table.insert(t, {title = tolazy(title), mrl = url, image = image})
		end
	--		table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		
--		end
--		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
--		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = http.getz(HOME)
		
   --     x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, '<div class="chiiinnna".-Все каналы.->(.-)<div class="miccjiia"')
		for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
        
        
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)

		
		
        for url in string.gmatch(x, 'var kodk="(http.-m3u8)') do

		
     --    print(url)
         
         url = string.gsub(url, 'http://50.7.144.158:8585', 'http://s1.ttranslit.com:8081')
         
         
         url = string.gsub(url, '^(.-)', 'http://179.43.176.219:8082/api/v1/tv/sign?url=')
	
     --    table.insert(t, {title = 'СМОТРЕТЬ', mrl = '#stream/q=content&id=' .. url, image = image})
    --     end
        local url = '#stream/q=content&id=' .. url
         table.insert(t, {title = 'СМОТРЕТЬ', mrl = url})
         end
         for url in string.gmatch(x, '"signed_url":"(http.-)"') do
        
        print(url)
			t = video(url, args)
			if t['view'] ~= 'error' then
				break
			end
				table.insert(t,{mrl = url})
        end  
         
    --    end






--http://s1.ttranslit.com:8081

    --   table.insert(t, {title = url, mrl = url})

			
--		end
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end