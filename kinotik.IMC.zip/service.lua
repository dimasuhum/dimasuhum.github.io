-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')


local HOME = 'https://m.kinotik.us'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH


--HOME = 'https://m.kinotik.us'

--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
      --  table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
        
        

	-- #stream/page=2
	-- #stream/genre=/kino_tevas/serial_alfa
        
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/kino_tevas/category/mysort'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/' .. tostring(page)
		end
		if genre == '/kino_tevas/category/top' then
        local url = HOME .. genre
		if page > 1 then
			url = url .. '/' .. tostring(page)
		end
		end
        if genre == '/kino_tevas/serial_alfa' then
        local url = HOME .. genre
		
			url = url
		end
		
	--	local x = http.getz(url)
         local x = conn:load(url)
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
       
         for url,image, title in string.gmatch(x, '<a href=.-/kino_tevas/video/(.-mp4).-background%-image.-(https.-jpg).-<b>(.-)<') do

       
	--	for  url,image, title in string.gmatch(x, '<div class="clear".-href="(.-)".-src="(.-)".-class="namefilm">(.-)<') do
   
        url = string.gsub(url, '^(.-)', 'http://big.tevas.fun/kino/download/')
          
      --  url = string.gsub(url, '^(.-)', 'http://big.tevas.fun/kino/download/top/')
      --  image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = url, image = image})
		
		end
		
        
		
	--	local x = conn:load(url)
        for url, image, title in string.gmatch(x, '<a.-href=.-(/kino_tevas/serial/all/.-/).-src="(.-)".->(.-)</a>') do
          
        url = string.gsub(url, '^(.-)', HOME)
        image = string.gsub(image, '^(.-)', HOME)
       table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})

		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
		


--https://m.kinotik.us/kino_tevas/category/top   
		table.insert(t, {title = 'TOP', mrl = '#stream/genre=' .. '/kino_tevas/category/top'})
		
   --    table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/kino_tevas/serial_alfa'})
		
        
         local x = conn:load(HOME .. '/kino_tevas/')
		
    --    x = iconv(x, 'WINDOWS-1251', 'UTF-8')
	--	local x = string.match(x, '<ul class="reset top%-menu">(.-)</ul>')
		for genre, title in string.gmatch(x, '<a class="p_m link_href" href="(.-)_amp.-".-alt=.->(.-)</a>') do
			table.insert(t, {title = title, mrl = '#folder/genre=' .. genre})
		end
        
    --    local x = http.get(HOME .. '/kino-podborka.html')
   --     x = iconv(http.get(HOME .. '/kino-podborka.html'), 'WINDOWS-1251', 'UTF-8')
        --x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--local x = string.match(x, '<nav class="side%-box to%-mob">(.-)</nav>')
	--	for genre, title in string.gmatch(x, '<a href="(.-)".-<span class="podborki%-title">(.-)</span>') do
	--		table.insert(t, {title = title, mrl = '#folder/genre=' .. genre})
--		end


-- https://m.kinotik.us/poisk/?q=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8   
 
 		
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/poisk/?q=' .. urlencode(args.keyword)

		
		local x = conn:load(url)
		
        for url, image, title in string.gmatch(x, '<a href=.-/kino/video/.-/(.-)html.-<img.-src="(.-)".-class ="p_title_film".->(.-)<') do

          
        url = string.gsub(url, '^(.-)', 'http://big.tevas.fun/kino/download/') .. 'mp4'
			table.insert(t, {title = tolazy(title), mrl = url, image = image}) 
		end
    	local url = '#folder/q=search&keyword=' .. 'p=' .. tostring(page + 1) .. '&q=' .. urlencode(args.keyword)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
	
 
	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
    	local x = conn:load(args.id)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = HOME .. args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="m%-desc full%-text clearfix slice%-this slice slice%-masked">(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})



           for url, image, title in string.gmatch(x, '<a class="p_t link_href" href="(/kino_tevas/sez.-)".-<img src="(.-)".-> (Сезон.-)</div>') do
          url = string.gsub(url, '^(.-)', HOME)  
          image = string.gsub(image, '^(.-)', HOME)  
           table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end

		for url in string.gmatch(x, '<a href=.-(//big.-mp4)') do
          url = string.gsub(url, '^(.-)', 'http:')  
           table.insert(t, {title = 'Смотреть', mrl = url})


		end

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end