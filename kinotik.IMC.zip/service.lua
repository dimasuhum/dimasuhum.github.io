-- fast-film plugin

require('support')
require('video')
require('parser')
require('client')



local HOME = 'https://m.anwap.tube'
--local HOME = 'https://m.anwap.band'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'UTF-8'
conn['root'] = HOME_SLASH


--HOME = 'https://m.anwap.bio'
--HOME = 'https://m.anwap.tube'
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from anwap plugin')
	return 1
end

function onUnLoad()
	print('Bye from anwap plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
    table.insert(t['menu'], {title = 'Поиск сериалов', mrl = '#folder/q=/serials/search', image = '#self/search.png'})
	
	
	-- #stream/page=2
	-- #stream/page=&2
	-- #stream/page=&1
	-- #stream/genre=/films/r3-
	-- #stream/genre=/films/p-
	-- #stream/genre=/serial/page/
	-- #stream/genre=/films/top
	-- #stream/genre=/serials/top
	-- #stream/genre=/serials/god-2023
	-- #stream/genre=/films/collection/11
	-- #stream/genre=/films/god-2023
	-- #stream/genre=/films/collection/67
	
	
	if not args.q then
		local page = tonumber(args.page or 1)
		
--		local genre = args.genre or '/'
		
		local genre = args.genre or '/films/p'
        local url = HOME .. genre .. '-' .. tostring(page)
  
         if genre == '/films/collections' then
			url = HOME .. genre .. '/' .. tostring(page)
		end
		if genre == '/serials/collections' then
			url = HOME .. genre .. '/' .. tostring(page)
		end

        
        		
        if genre == '/films/top' then
        url = HOME .. genre .. '&' .. tostring(page)
		end
        
		
		
        if genre == '' then
			url = HOME .. genre .. '/' .. tostring(page)
		end
      

		
        if genre == '/serials/' then
			url = HOME .. genre .. 'p-' .. tostring(page)
		end
		
		
         print(url)

         local x = conn:load(url)
    	--local x = http.getz(url)

         for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-alt="(.-)"') do
	
         url = string.gsub(url, '^(.-)', HOME)
	
		--	url = string.gsub(url, '^(.-)', 'https://kinotik.biz/kino/video/')
			
            --image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
        
         
	
	
		
        for url, title in string.gmatch(x, '<a href="(/serials/down.-)">(.-серия)</a>') do
       print(url)
	   	url = string.gsub(url, '^(.-)', HOME)
        t['view'] = 'simple'
        table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url})
		end 
		
 --   <div class="list_gallery"> 
 
         if genre == '/films/collections' then
        local url = HOME .. genre .. '/' .. tostring(page)
      
        local x = conn:load(url)
        x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)</h2>') do
         image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
        end
    
--https://m.anwap.movie/serials/years
    
    
    
       
       if genre == '/serials/collections' then
        local url = HOME .. genre .. '/' .. tostring(page)
      
        local x = conn:load(url)
        x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for url, image,  title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)</h2>') do
         image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
        end

        if genre == args.genre or '' then
        local url = HOME .. genre .. '/' .. tostring(page)
      
        local x = conn:load(url)
  
        
         for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href="(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', HOME)
			
            --image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
        end
        
       if genre ==  '/films/years' then
        local url = HOME .. genre

      
        local x = conn:load(url)

         for url,  title in string.gmatch(x, '<a href=.-(/films/god.-)".-<strong>(.-)</strong>') do

            t['view'] = 'simple'
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre' .. url, image = image})
		end
        end  


     if genre ==  '/serials/years' then
        local url = HOME .. genre

      
        local x = conn:load(url)

         for url,  title in string.gmatch(x, '<a href=.-(/serials/god.-)".-<strong>(.-)</strong>') do

        t['view'] = 'simple'
            
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre' .. url, image = image})
		end
       end  

	
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
       
      
    --    local x = conn:load(HOME .. '/films/top')

	--	x = string.match(x, '<ul class="perehod">(.-)</ul>')
	--	for genre, title in string.gmatch(x, 'href="(.-)">(.-)</a>') do
		

		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
	--	end
      
      
      
      
       

 
    --  table.insert(t, {title = 'ФИЛЬМЫ : топ', mrl = '#stream/genre=' .. '/films/top'})
 
--table.insert(t, {title = 'ФИЛЬМЫ : топ:1', mrl = '#stream/genre=' .. '/films/top/like'})

--table.insert(t, {title = 'ФИЛЬМЫ : топ:кп', mrl = '#stream/genre=' .. '/films/top/kp'})

--table.insert(t, {title = 'ФИЛЬМЫ : топ:imdb', mrl = '#stream/genre=' .. '/films/top/imdb'})


 
       table.insert(t, {title = 'ФИЛЬМЫ : подборка', mrl = '#stream/genre=' .. '/films/collections'})
       
       table.insert(t, {title = 'СЕРИАЛЫ : подборка', mrl = '#stream/genre=' .. '/serials/collections'})
       
  --     table.insert(t, {title = 'ФИЛЬМЫ : по годам', mrl = '#stream/genre=' .. '/films/years'})


   --   table.insert(t, {title = 'СЕРИАЛЫ : по годам', mrl = '#stream/genre=' .. '/serials/years'})
 
 
       
        local x = conn:load(HOME .. '/films/genre')
        --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
        
        

        
		x = string.match(x, '<div class="list_gallery">(.-)</div>')
		for genre, image, title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)<.-</a>') do
		
		
		image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = 'ФИЛЬМЫ' .. ':' .. title, mrl = '#stream/genre=' .. genre, image = image})
		end
		
		
        local x = conn:load(HOME .. '/films/countries')
        --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
		--x = string.match(x, '<div class="zag2">(.-)</div>')
		for genre, title in string.gmatch(x, '<a href="(/films/.-)".-<strong>(.-)</strong>') do
		
		
		
			table.insert(t, {title ='ФИЛЬМЫ' .. ':' .. title, mrl = '#stream/genre=' .. genre})
		end
		
        table.insert(t, {title = 'ВСЕ СЕРИАЛЫ', mrl = '#stream/genre=' .. '/serials/'})
        
     --   table.insert(t, {title = 'СЕРИАЛЫ : Тор за сегодня', mrl = '#stream/genre=' .. '/serials/top'})
       
  --     table.insert(t, {title = 'СЕРИАЛЫ : Тор ANWAP', mrl = '#stream/genre=' .. '/serials/top/like'})
       
   --    table.insert(t, {title = 'СЕРИАЛЫ : Тор КиноПоиск', mrl = '#stream/genre=' .. '/serials/top/kp'})


     --  table.insert(t, {title = 'СЕРИАЛЫ : Тор imdb', mrl = '#stream/genre=' .. '/serials/top/imdb'})
        
        local x = conn:load(HOME .. '/serials/genre')
        --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
         x = string.match(x, '<div class="list_gallery">(.-)</div>')
        for genre, image, title in string.gmatch(x, '<a href="(.-)".-<img src="(.-)".-<h2>(.-)<.-</a>') do
        
        image = string.gsub(image, '^(.-)', HOME)
        
			table.insert(t, {title = 'СЕРИАЛЫ' .. ':' .. title, mrl = '#stream/genre=' .. genre, image = image})
		end
		
		
		
		
        local x = conn:load(HOME .. '/serials/countries')
        --x = iconv(http.get(HOME), 'WINDOWS-1251', 'UTF-8')
		--x = string.match(x, '<div class="zag2">(.-)</div>')
		for genre, title in string.gmatch(x, '<a href="(/serials/.-)".-<strong>(.-)</strong>') do
			table.insert(t, {title ='СЕРИАЛЫ' .. ':' .. title, mrl = '#stream/genre=' .. genre})
		end


--https://m.anwap.tube/films/search/?slv=%D1%80%D0%BE%D0%BA%D0%BA%D0%B8&vid=1&page=2
--https://m.anwap.tube/serials/search/?word=%D0%BF%D0%B8&vid=1


     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/films/search/?slv=' .. urlencode(args.keyword) .. '&vid=1' .. '&page=' .. tostring(page)


		local x = conn:load(url)
		
                 for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href=".-(/films/.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', 'https://kinotik.biz/kino/video/')
				
           image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})


    elseif args.q == '/serials/search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/serials/search/?word=' .. urlencode(args.keyword) .. '&vid=1' .. '&page=' .. tostring(page)


       local x = conn:load(url)
		
     for url, image,  title in string.gmatch(x, '<div class="my_razdel film".-<a href=".-/serials/(.-)".-<img src="(.-)".-title="(.-)"') do
			url = string.gsub(url, '^(.-)', 'https://kinotik.biz/kino/serial/')
			
            --image = string.gsub(image, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		
	--	end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})


	-- #stream/q=content&id=http://79.137.204.8:9118/lite/zetflix?kinopoisk_id=1209839&title=&original_title=&s=1
	-- #stream/q=content&id=https://cors557.deno.dev/http://79.137.204.8:9118/lite/zetflix?kinopoisk_id=1209839&title=&original_title=&s=1
	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
        t['name'] = parse_match(x,'<h1.-alt.->(.-)</span>')
		t['description'] = parse_match(x, '<div class="filmopis screen3".-<p>(.-)</p>')
		

			t['poster'] = args.p
			
            t['poster'] = parse_match(x,'<div class="filmopis screen".-<img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
			
			
			
	    	t['annotation'] = parse_array(x, {'(Оригинал:</td>.-)</td>', 
			'(Год:</td>.-)</a>',
			'(Качество:</td>.-)</a>',
			'(Перевод:</td>.-)</td>',
			'(Время:</td>.-)</td>',
			'(Страна:</td>.-)</td>',
			'(Жанр:</td>.-)</td>',
			'(Режиссер:</td>.-)</td>','(Актеры:</td>.-)</td>','(Премьера :</span>.-)</li>'})
			

         for title in string.gmatch(x, '<div class="filmopis screen".-<img src.-alt="(.-)/.-"') do
 --      for title in string.gmatch(x, '<iframe.-src="https://api.-title="(.-)"') do
        title=http.urlencode(title)

         title = string.gsub(title, '+', '%%20')
    
    
          url = string.gsub(title, '^(.-)', 'http://stvplay.mooo.com:81/vk/vk.php?search=')
    
     --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
    
     --   end
   
       local x = http.getz(url)
       
   for url, total in string.gmatch(x, '</channel.-<channel.-playlist_url>.-(http.-)].-description>.-<h3>(.-)</h3>') do

 --    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})
    
      --  end
 --  end
       local x = http.getz(url)
   
        for total1, url in string.gmatch(x, '<title>.-(1080p).-<stream_url>.-(https.-)]') do
   
      table.insert(t, {title = total1 ..  ' ' ..  total, mrl = url})
    
        end
   end
   end



	
         for url in string.gmatch(x, '<h1.-alt.->(.-)</span>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
          
        local x = http.getz(url)
        
   --  table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
   --   end
    

         for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
	
        print(url)
	
    	url = string.gsub(url, '^(.-)', 'https://cdnmovies-stream.online/kinopoisk/') .. '/iframe?domain=kinobd.net'
    	
    	

			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
			
		end
        end
      --   local x = http.getz(url)
         
         for url in string.gmatch(x, 'player.-:.-#2(.-)"') do
       
       
         print(url)

         url = string.gsub(url, '\\/\\/Ni14UVdNaDdlcnRMcDh0X005aHVVRGsxTTBWcllK', '')
         url = string.gsub(url, '\\/\\/d05wMndCVE5jUFJRdlRDMF9DcHhDc3FfOFQxdTlR', '')
         url = string.gsub(url, '\\/\\/bWQtT2QyRzlSV09nU2E1SG9CU1NiV3JDeUlxUXlZ', '')
         url = string.gsub(url,'\\/\\/a3p1T1lRcUJfUVNPTC14ek5fS3oza2tna0hoSGl0', '')
         url = string.gsub(url,'VfR0xFc1h4bnBVNExqamQwUmVZLVZI', '')
         url = string.gsub(url,'\\/\\/UnlUd3RmMT', '')




         url=http.urldecode(base64_decode(url))
  


        
        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(240p)](http.-.m3u8)') do
			

           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
      
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        
		        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(360p)](http.-.m3u8)') do
			

            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
			
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(480p)](http.-.m3u8)') do
			
           --  title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(720p)](http.-.m3u8)') do
			
         --    title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(1080p)](http.-.m3u8)') do
			
         --    title = tolazy(title)
            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        end
	
	
	
	
	
        for url in string.gmatch(x, '<h1.-alt.->(.-)</span>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
          
        
        
     table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
      end
    

         for url1, url2  in string.gmatch(x, 'current_page".-"data":%[{"id":(.-),"kinopoisk_id":(.-),') do
       
		url = string.gsub(url2, '^(.-)', 'https://voidboost.net/embed/')
       
       
        local x = http.getz(url)
    --x = string.match(x, '<select name="season".->(.-)</select>')
    
        for url, title in string.gmatch(x, '<option value="(.-)".-(Сезон.-)</option>') do
  

       url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=' .. url1 .. '&kinopoisk_id=' .. url2 .. '&title=&original_title=&s=')
        

         
     local x = http.getz(url)



       for url, total  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do
       

       t['view'] = 'simple'

       table.insert(t, {title = title .. (total), mrl = url})
    
    	end
	end
    end

	
	
	
	
	
		

     for url in string.gmatch(x, '<h1.-alt.->(.-)</span>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
         local x = http.getz(url)
         for url, url1  in string.gmatch(x, 'current_page".-"data":%[{"id":(.-),"kinopoisk_id":(.-),') do
  

        url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=') .. '&kinopoisk_id=' .. url1
        

      local x =  http.getz(url)
       
      
       
       for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(1080p).-(http.-mp4)') do
        --    t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(720p).-(http.-mp4)') do
         --  t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(480p).-(http.-mp4)') do
        --    t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(360p).-(http.-mp4)') do
        --   t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end

end







          for url in string.gmatch(x, '<h1.-alt.->(.-)</span>') do
          url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/title?q=')
    
         local x = http.getz(url)
    
       for  url  in string.gmatch(x, 'current_page".-"data":%[{"id".-"kinopoisk_id":(.-),') do
  
  
  
   --     print(url) 
		url = string.gsub(url, '^(.-)', 'https://videocdn.tv/api/short?api_token=bVycnMuy5Dfe0IkzXt87eeVa9EtIkUl5&kinopoisk_id=')
       
        local x = http.getz(url)
       for  url  in string.gmatch(x, '"iframe_src":"(.-)"') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
  
       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})

		end
    end
    end
  

  
  
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(360p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       
       
        for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(480p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
  
      for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(720p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
  
       for title, total, total1,total2, url  in string.gmatch(x, '{"id":"(.-)_(.-)","comment".-<i>(.-)<.-"file":.-%[(1080p)](.-mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https:')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title .. ' Сезон' .. ' : ' .. total .. ' серия' .. ' ('.. total1 .. ') ' .. (total2), mrl = url})

		end
	
		
       for title, url  in string.gmatch(x, 'movie.-%[(360p)].-(cloud-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
     	 for title, url  in string.gmatch(x, 'movie.-%[(480p)].-(cloud.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
	for title, url  in string.gmatch(x, 'movie.-%[(720p)].-(cloud.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
	
		
        for title, url  in string.gmatch(x, 'movie.-%[(1080p)].-(cloud.-.mp4)') do
  
        url = string.gsub(url, '^(.-)', 'https://')
  
        url = string.gsub(url, '\\', '')
       t['view'] = 'simple'
       table.insert(t, {title = title, mrl = url})

		end
		

		
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
		return video(args.url, args)
	end
	return t
end