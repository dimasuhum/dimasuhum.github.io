-- Moonwalk plugin
-- © IconBIT 2018

require('video')
require('parser')
require('support')
require('client')

local HOME = 'http://torrs.ru'

 local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

function onLoad()
	print("Hello from Moonwalk plugin")
	return 1
end

function onUnLoad()
	print("Bye from Moonwalk plugin")
end

function onCreate(args)
	local t = {}
	
t['menu'] = {}
--	if args.q ~= 'genres' then
--		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
--	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	if args.keyword then

	
		t['view'] = 'simple'
		t['type'] = 'folder'
		keyword = args.keyword
		local title = args.keyword
	--	title = string.gsub(title, '^%s+','')
--		title = string.gsub(title, '%s+$','')
		t['message'] = 'Результат поиска: ' .. title
	--	t['message'] = args.keyword
		
		--.. '&do=search&subaction=search'
		--.. tostring(page)


		local page = tonumber(args.page or '1')
     local url = HOME .. '/search?query=' .. urlencode(title)
--local x = conn:load('http://torrs.ru/search?query=' .. urldecode(title))

		local x = conn:load(url)
	x = string.gsub(x, '",', '\\u0026')	
    for title, total in string.gmatch(x,'"size".-"title":"(.-)".-"magnet":"magnet:?.-btih:(.-)\\u0026') do
      
   --   total = string.gsub(total, '\\u0026','&')
      
        total = total:lower()
        
--https://lam.akter-black.com/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u


--  url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      
     table.insert(t, {title = title, mrl = '#stream/q=video&id=' .. total, image = image})
		end




elseif args.q == 'search' then
    

    
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search?query=' .. urlencode(title)
--local x = conn:load('http://torrs.ru/search?query=' .. urldecode(title))

		local x = conn:load(url)
		x = string.gsub(x, '",', '\\u0026')	
    for title, total in string.gmatch(x,'"size".-"title":"(.-)".-"magnet":"magnet:?.-btih:(.-)\\u0026') do
      
      total = string.gsub(total, '\\u0026','&')
      
        total = total:lower()
        
--https://lam.akter-black.com/ts/stream?link=734f3bbf403daeff23023d2c2858acf28b705414&m3u


    --   url1 = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      
     table.insert(t, {title = title, mrl = '#stream/q=video&id=' .. total, image = image})
		end



		
		
	elseif args.q == 'video' then


--table.insert(t, {title = 'https://lam.akter-black.com/ts/stream?link=' .. args.id .. '&m3u', mrl =  'https://lam.akter-black.com/ts/stream?link=' .. args.id .. '&m3u', image = image})


		local x = conn:load('https://lam.akter-black.com/ts/stream?link=' .. args.id .. '&m3u')
	--	local x = conn:load(args.id)





   --   url = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      
 --  table.insert(t, {title = url, mrl = url})
    --    local x = conn1:load(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
        t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
        t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
       t['view'] = 'simple'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.net/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        
	end


	elseif args.q == 'play' then
		--args['ref']= 'http://' .. string.match(args.url, '://(.-)/')
		args['ref'] = 'https://cinema-hd.tv'
		return video(args.url, args)
	else
		t['view'] = 'keyword'
		t['message'] = '@string/search_text'
		t['keyword'] = keyword
	end
	
	return t
end
