from filmix import FilmixClient

api = FilmixClient()

token_result = api.token_request()

api._user_dev_name = 'Xaomi R8'
api._user_dev_id = api.create_dev_id()
api._user_dev_token = token_result['code']

#code = token_result['user_code']

#print(api.create_dev_id())
#print(api.token_request())

params = {'page': 1,
'orderby': 'date',
'orderdir': 'desc',
'per_page': '30',
'filters': '',
}

#print(api.get_catalog_items(**params))

#print(api.get_popular_items())

#print(api.get_movie_info('149467'))

#print(api.decode_link('aH=Dc0oOKBxsIPnhKYXkyAX5gixUyBDOcb6BmGXkXPdDX0JkvzjGmUm5CPXSX0krI0CUvuMbmYmGCi1oCV6bIb1jgB6WFB1sgYFGKUMhIUnWjZxN=jM7=3hWXGJTcV1yKZhsXGMhK0QrIZ5gKY9hX01BcGQ7yEJpCBqW'))

#print(api.get_movie_info('6379'))

#print(api.get_search_catalog('supernatural'))


print(api.get_filter('categories'))
