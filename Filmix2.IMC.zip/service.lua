-- filmix plugin
-- © iconBIT 2020

require('video')
require('parser')
require('support')
require('client')
require('fxml')

local fxml = onCreate

--http://z01.online/lite/filmix?kinopoisk_id=386&title=чужой&year=1979
--https://filmix.my/film/drama/178338-v-formula-1-2025.html

local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'


--.(vip|cyou)|

--http://filmixapp.vip/api/v2/post/179667?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380

 --http://filmixapp.cyou/api/v2/post/179667?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380

--http://filmixapp.cyou/api/v2/person/1537?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380


--http://filmixapp.vip/api/v2/catalog/?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380

--http://filmixapp.vip/api/v2/playlist/?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380


--local HOME = 'https://filmix.fm'
local HOME = 'https://filmix.my'
local HOME_PATH = HOME .. '/'


local HOME1 = 'https://cors.apn.monster/http://filmixapp.cyou/api/v2'
local HOME2 = 'https://cors.apn.monster/http://filmixapp.vip/api/v2'

local conn = client.new()
local conn1 = client.new()
conn['encoding'] = 'windows-1251'
conn1['encoding'] = 'utf-8'

conn['root'] = HOME_SLASH

--HOME = 'https://filmix.co'
--HOME = 'https://filmix.site'
--HOME = 'https://filmix.zone'
--HOME = 'https://filmix.today'
--HOME = 'https://filmix.ink'
--HOME = 'https://filmix.online'
--HOME = 'https://filmix.email'
--HOME = 'https://filmix.agency'
--HOME = 'https://filmix.casa'
--HOME = 'https://filmix.ltd'
--HOME = 'https://filmix.wiki'
--HOME = 'https://filmix.click'
--HOME = 'https://filmix.ac'
--HOME = 'http://filmix.vip:8080'
HOME_PATTERN = string.gsub(HOME, '%.', '%%.')
--HOME_PATH = HOME .. '/'
-- https://filmix.red/?box_mac=1234

FILMIXNET = ''

-- #stream/q=content&id=https://filmix.biz/multseries/animes/138925-igra-darvina-2020.html
-- file:///sdcard/filmix.IMC.zip?q=content&id=https://filmix.biz/multseries/animes/138925-igra-darvina-2020.html

print(HOME)
print(HOME_PATTERN)
print(HOME_PATH)

UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0'

function onLoad()
	print('Hello from filmix plugin')
	return 1
end

function onUnLoad()
	print('Bye from filmix plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder', menu = {}}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
--~ 
if args.q ~= 'years' then
--~ 	
--table.insert(t['menu'],{title = '@string/years', mrl = '#folder/q=years', image = '#self/list.png'})
--~ 
end
--	table.insert(t['menu'], {title = '@string/preferences', mrl = '#folder/q=setup', image = '#self/settings.png'})
	
	-- #self/page=2
	-- #stream/genre=/boevik/&page=2
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'
		local url = HOME .. genre
	--	if page > 1 then
		
		if page > 1 then
			if genre == '/' then
				url = url .. 'pages/' .. tostring(page) .. '/'
			else
				url = url .. 'page/' .. tostring(page) .. '/'
			end
		end
     	if genre == '' then
        local url = HOME .. genre
        if page > 1 then
		url = url .. '/page/' .. tostring(page) .. '/'
        end
        end
		  
	    
		print(url)
		local x = conn:load(url)
		--if x then io.open('/sdcard/page.txt', 'w+'):write(x):close() end
		
      local x = conn1:load(HOME1 .. genre .. 'catalog?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380' .. '&page=' .. tostring(page))

--	http://filmixapp.vip/api/v2/catalog?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380
	
      for url, title, total, image   in string.gmatch(x, '"id":(.-),.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)"') do
	
	
--url = string.gsub(url, '^(.-)', HOME .. '/post/')
	image = string.gsub(image, '\\', '')

	
		
			table.insert(t, {title = title .. ' ' .. total, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
		

		 for  image, url, title   in string.gmatch(x, '<article class="persone line shortstory".-<img src="(.-)".-<a href=".-(/person.-)">(.-)</a>') do
    --    t['view'] = 'simple'
		 table.insert(t, {title = title, mrl = '#stream/genre=' .. url, image = image})
		end
		
        
		
        
   
    	
		
         local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})

		
		

	-- #self/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		
--https://filmix.zone/playlists

   --  local x = conn:load(HOME .. '/playlists')
     
 --  local x = string.match(x, '<ul class="category%-menu playlists%-menu">(.-)</ul>')

   
   
  --  for genre, title in string.gmatch(x, '<a href="(.-)">(.-)</a>') do

--genre = string.gsub(genre, '^(.-)', HOME)
   
   
    --  table.insert(t, {title = 'Подборка :'.. title, mrl = '#stream/q=coll&id=' .. genre})		
    --  end
      
    
--https://filmix.my/playlists/page/2/
    
    table.insert(t, {title = 'Подборка', mrl = '#stream/q=coll&id=' .. '/playlists'})	
    
    
--http://filmixapp.vip/api/v2/catalog?filter=s0-g2&orderby=year&user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380

--http://filmixapp.vip/api/v2/post/13661?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380


table.insert(t, {title = 'Сейчас смотрят', mrl = '#stream/q=genrez&id=' .. '/top_views?component=category_full'})


table.insert(t, {title = 'Новинки', mrl = '#stream/q=genrez&id=' .. '/catalog?orderby=year'})

table.insert(t, {title = 'Фильмы :'.. 'Популярные', mrl = '#stream/q=genrez&id=' .. '/popular?&component=category_full'})

table.insert(t, {title = 'Сериалы :'.. 'Популярные', mrl = '#stream/q=genrez&id=' .. '/popular?section=7&component=category_full'})







table.insert(t, {title = 'В топе', mrl = '#stream/q=genrez&id=' .. '/catalog?orderby=rating&orderdir=desc&component=category_full'})



 
    
    
      
      
      
table.insert(t, {title = 'Фильмы :'.. 'Все', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g000'})


table.insert(t, {title = 'Фильмы :'.. '4K', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-q4'})

table.insert(t, {title = 'Фильмы :'.. 'Аниме', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g21'})

table.insert(t, {title = 'Фильмы :'.. 'Биография', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g76'})		
table.insert(t, {title = 'Фильмы :'.. 'Боевики', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g3'})

table.insert(t, {title = 'Фильмы :'.. 'Вестерн', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g81'})


table.insert(t, {title = 'Фильмы :'.. 'Военный', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g20'})		
table.insert(t, {title = 'Фильмы :'.. 'Детектив', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g18'})

table.insert(t, {title = 'Фильмы :'.. 'Детский', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g84'})

      table.insert(t, {title = 'Фильмы :'.. 'Для взрослых', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g100'})		
table.insert(t, {title = 'Фильмы :'.. 'Документальные', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g15'})

table.insert(t, {title = 'Фильмы :'.. 'Дорамы', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g102'})

table.insert(t, {title = 'Фильмы :'.. 'Драмы', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g1'})		
table.insert(t, {title = 'Фильмы :'.. 'Исторический', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g75'})

table.insert(t, {title = 'Фильмы :'.. 'Комедия', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g6'})


table.insert(t, {title = 'Фильмы :'.. 'Короткометражка', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g80'})		
table.insert(t, {title = 'Фильмы :'.. 'Криминал', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g71'})

table.insert(t, {title = 'Фильмы :'.. 'Мелодрама', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g12'})
      
table.insert(t, {title = 'Фильмы :'.. 'Мистика', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g5'})		
table.insert(t, {title = 'Фильмы :'.. 'Музыка', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g96'})

table.insert(t, {title = 'Фильмы :'.. 'Мюзикл', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g72'})

table.insert(t, {title = 'Фильмы :'.. 'Новости', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g103'})		
table.insert(t, {title = 'Фильмы :'.. 'Оригинал', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-83'})

table.insert(t, {title = 'Фильмы :'.. 'Отечественные', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g79'})


table.insert(t, {title = 'Фильмы :'.. 'Передачи с ТВ', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g16'})		
table.insert(t, {title = 'Фильмы :'.. 'Приключения', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g74'})

table.insert(t, {title = 'Фильмы :'.. 'Реальное ТВ', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g99'})

      table.insert(t, {title = 'Фильмы :'.. 'Русские', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-c6'})		
table.insert(t, {title = 'Фильмы :'.. 'СССР', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-c64'})

table.insert(t, {title = 'Фильмы :'.. 'Семейный', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g73'})

table.insert(t, {title = 'Фильмы :'.. 'Спорт', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g77'})		
table.insert(t, {title = 'Фильмы :'.. 'Ток-шоу', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g98'})

table.insert(t, {title = 'Фильмы :'.. 'Триллеры', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g8'})


table.insert(t, {title = 'Фильмы :'.. 'Ужасы', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g2'})		
table.insert(t, {title = 'Фильмы :'.. 'Фантастика', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g13'})

table.insert(t, {title = 'Фильмы :'.. 'Фильм-нуар', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g97'})

table.insert(t, {title = 'Фильмы :'.. 'Фэнтези', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s0-g4'})







table.insert(t, {title = 'Сериалы :'.. 'Все', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g000'})		
table.insert(t, {title = 'Сериалы :'.. '4K', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-q4'})

table.insert(t, {title = 'Сериалы :'.. 'Аниме', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g21'})

table.insert(t, {title = 'Сериалы :'.. 'Биография', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g76'})		
table.insert(t, {title = 'Сериалы :'.. 'Боевики', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g3'})

table.insert(t, {title = 'Сериалы :'.. 'Вестерн', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g81'})


table.insert(t, {title = 'Сериалы :'.. 'Военный', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g20'})		
table.insert(t, {title = 'Сериалы :'.. 'Детектив', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g18'})

table.insert(t, {title = 'Сериалы :'.. 'Детский', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g84'})

      table.insert(t, {title = 'Сериалы :'.. 'Для взрослых', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g100'})		
table.insert(t, {title = 'Сериалы :'.. 'Документальные', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g15'})

table.insert(t, {title = 'Сериалы :'.. 'Дорамы', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g102'})

table.insert(t, {title = 'Сериалы :'.. 'Драмы', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g1'})		
table.insert(t, {title = 'Сериалы :'.. 'Исторический', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g75'})

table.insert(t, {title = 'Сериалы :'.. 'Комедия', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g6'})


table.insert(t, {title = 'Сериалы :'.. 'Короткометражка', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g80'})		
table.insert(t, {title = 'Сериалы :'.. 'Криминал', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g71'})

table.insert(t, {title = 'Сериалы :'.. 'Мелодрама', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g12'})
      
table.insert(t, {title = 'Сериалы :'.. 'Мистика', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g5'})		
table.insert(t, {title = 'Сериалы :'.. 'Музыка', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g96'})

table.insert(t, {title = 'Сериалы :'.. 'Мюзикл', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g72'})

table.insert(t, {title = 'Сериалы :'.. 'Новости', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g103'})		
table.insert(t, {title = 'Сериалы :'.. 'Оригинал', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g83'})

table.insert(t, {title = 'Сериалы :'.. 'Отечественные', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g79'})


table.insert(t, {title = 'Сериалы :'.. 'Передачи с ТВ', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g16'})		
table.insert(t, {title = 'Сериалы :'.. 'Приключения', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g74'})

table.insert(t, {title = 'Сериалы :'.. 'Реальное ТВ', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g99'})

      table.insert(t, {title = 'Сериалы :'.. 'Русские', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-c6'})		
table.insert(t, {title = 'Сериалы :'.. 'СССР', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-c64'})

table.insert(t, {title = 'Сериалы :'.. 'Семейный', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g73'})

table.insert(t, {title = 'Сериалы :'.. 'Спорт', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g77'})		
table.insert(t, {title = 'Сериалы :'.. 'Ток-шоу', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g98'})

table.insert(t, {title = 'Сериалы :'.. 'Триллеры', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g8'})


table.insert(t, {title = 'Сериалы :'.. 'Ужасы', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g2'})		
table.insert(t, {title = 'Сериалы :'.. 'Фантастика', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g13'})

table.insert(t, {title = 'Сериалы :'.. 'Фильм-нуар', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g97'})

table.insert(t, {title = 'Сериалы :'.. 'Фэнтези', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s7-g4'})

table.insert(t, {title = 'Мультсериалы', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s93'})	

table.insert(t, {title = 'Мультфильмы :'.. 'Все', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s14-g000'})		
table.insert(t, {title = 'Мультфильмы :'.. '4K', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s14-q4'})

table.insert(t, {title = 'Мультфильмы :'.. 'Зарубежные', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s14-c996'})		

table.insert(t, {title = 'Мультфильмы :'.. 'Русские', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s14-c6'})		
table.insert(t, {title = 'Мультфильмы :'.. 'СССР', mrl = '#stream/q=genre&id=' .. '/catalog?filter=s14-c64'})




 --   https://filmix.my/playlists/films/page/2/

--https://filmix.my/playlist/13661-novye-filmy-i-multfilmy-pro-novyy-god-i-rozhdestvo

--http://filmixapp.vip/api/v2/catalog?section=13661&user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380


elseif args.q == 'coll' then

local page = tonumber(args.page or 1)

  -- local x = conn:load('https://filmix.my' .. args.id)



		
    local genre = args.genre or args.id
		local url = HOME .. genre
   	if page > 1 then
		url = url .. '/page/' .. tostring(page) .. '/'
        end
	
	local x = conn:load(url)

	
     

  --   local x = string.match(x, '<ul class="slider%-wrap overview"(.-)</ul>')

   for  url, image, title in string.gmatch(x, '<article.-data.-id=.-class="short".-<a href=".-(/playlist.-)".-<img src="(.-)".-alt="(.-)"') do


--url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
--	image = string.gsub(image, '\\', '')



	table.insert(t, {title = title, mrl = '#stream/q=collect&id=' .. url, image = image})
		end	


	
  local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&q=coll&id=' .. args.id
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})

  
 
 
 elseif args.q == 'collect' then

local page = tonumber(args.page or 1)


    local genre = args.genre or args.id
		local url = HOME .. genre
   	if page > 1 then
		url = url .. '/page/' .. tostring(page) .. '/'
        end
	
	local x = conn:load(url)


--for title in string.gmatch(x, '<article(.-)</article') do
		
      for url, image, title  in string.gmatch(x, '<article.-"shortstory line".-data%-id="(.-)".-<img src="(.-)".-alt="(.-)"') do

--url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
--	image = string.gsub(image, '\\', '')



	table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
    
		
		local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&q=collect&id=' .. args.id
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})



    elseif args.q == 'years' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')

	local x = conn1:load(HOME1 .. args.id .. '-y' .. urlencode(args.keyword) ..'&user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380' .. '&page=' .. tostring(page))




table.insert(t, {title = 'Фильтр:все', mrl = '#stream/q=genre&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:новинки', mrl = '#stream/q=filter&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:топ', mrl = '#stream/q=filter1&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:год', mrl = '#stream/q=years&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:топ-год', mrl = '#stream/q=yearsi&id=' .. args.id, image = '#self/settings.png'})
	
    for url, title, total, image   in string.gmatch(x, '"id":(.-),.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)"') do
	
	
--url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
	image = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' ' .. total, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
    
    
    
    
    local url = '#stream/q=years&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})






elseif args.q == 'yearsi' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')

	local x = conn1:load(HOME1 .. args.id .. '-y' .. urlencode(args.keyword) .. '&orderby=rating&user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380' .. '&page=' .. tostring(page))




table.insert(t, {title = 'Фильтр:все', mrl = '#stream/q=genre&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:новинки', mrl = '#stream/q=filter&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:топ', mrl = '#stream/q=filter1&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:год', mrl = '#stream/q=years&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:топ-год', mrl = '#stream/q=yearsi&id=' .. args.id, image = '#self/settings.png'})

	
    for url, title, total, image   in string.gmatch(x, '"id":(.-),.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)"') do
	
	
--url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
	image = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' ' .. total, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
    
    
    
    
    local url = '#stream/q=yearsi&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)

	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})







elseif args.q == 'genrez' then

		local page = tonumber(args.page or 1)
	
	
		
		local x = conn1:load(HOME1 ..  args.id .. '&user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380' .. '&page=' .. tostring(page))




	
      for url, title, total, image   in string.gmatch(x, '"id":(.-),.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)"') do
	
	
--url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
	image = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' ' .. total, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
		
	
local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&q=genrez&id=' .. args.id
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})




      elseif args.q == 'genre' then

		local page = tonumber(args.page or 1)
	
	
		
		local x = conn1:load(HOME1 ..  args.id .. '&user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380' .. '&page=' .. tostring(page))



table.insert(t, {title = 'Фильтр:все', mrl = '#stream/q=genre&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:новинки', mrl = '#stream/q=filter&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:топ', mrl = '#stream/q=filter1&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:год', mrl = '#stream/q=years&id=' .. args.id, image = '#self/settings.png'})
	
table.insert(t, {title = 'Фильтр:топ-год', mrl = '#stream/q=yearsi&id=' .. args.id, image = '#self/settings.png'})
	
	
      for url, title, total, image   in string.gmatch(x, '"id":(.-),.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)"') do
	
	
--url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
	image = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' ' .. total, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
		
	

local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&q=genre&id=' .. args.id
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})






      elseif args.q == 'filter' then

		local page = tonumber(args.page or 1)
	
	
		
		local x = conn1:load(HOME1 ..  args.id .. '&orderby=year&user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380' .. '&page=' .. tostring(page))


table.insert(t, {title = 'Фильтр:все', mrl = '#stream/q=genre&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:новинки', mrl = '#stream/q=filter&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:топ', mrl = '#stream/q=filter1&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:год', mrl = '#stream/q=years&id=' .. args.id, image = '#self/settings.png'})

	
table.insert(t, {title = 'Фильтр:топ-год', mrl = '#stream/q=yearsi&id=' .. args.id, image = '#self/settings.png'})
	
	
      for url, title, total, image   in string.gmatch(x, '"id":(.-),.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)"') do
	
	
--url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
	image = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' ' .. total, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
	


local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&q=filter&id=' .. args.id
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})




      elseif args.q == 'filter1' then

		local page = tonumber(args.page or 1)
	
	
		
		local x = conn1:load(HOME1 ..  args.id .. '&orderby=rating&user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380' .. '&page=' .. tostring(page))


table.insert(t, {title = 'Фильтр:все', mrl = '#stream/q=genre&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:новинки', mrl = '#stream/q=filter&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:топ', mrl = '#stream/q=filter1&id=' .. args.id, image = '#self/settings.png'})

table.insert(t, {title = 'Фильтр:год', mrl = '#stream/q=years&id=' .. args.id, image = '#self/settings.png'})
	
table.insert(t, {title = 'Фильтр:топ-год', mrl = '#stream/q=yearsi&id=' .. args.id, image = '#self/settings.png'})
   
   
   for url, title, total, image   in string.gmatch(x, '"id":(.-),.-"title":"(.-)".-"year":(.-),.-"poster":"(.-)"') do
	
   
 --  url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
	image = string.gsub(image, '\\', '')

			table.insert(t, {title = title .. ' ' .. total, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
	


local title = L'page' .. ' ' .. tostring(page + 1)
		local url = '#stream/page=' .. tostring(page + 1) .. '&q=filter1&id=' .. args.id
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})

		

		
		
		
	elseif args.q == 'search' then
		if not args.keyword and not args.year then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		if args.keyword then
			t['message'] = args.keyword
		else
			t['message'] = args.year
		end
--~ 		if FILMIXNET == '' then
--~ 			conn:load(HOME_PATH)
--~ 		end
		local page = tonumber(args.page or 1)
		local r = {}
		local headers = {}
		headers['User-Agent'] = UserAgent
		headers['Referer'] = HOME
		if FILMIXNET ~= '' then
			headers['Cookie'] = 'FILMIXNET=' .. FILMIXNET .. ';'
		end
		
		local url = HOME .. '/search/' .. (args.keyword or args.year)
		conn:load(url, headers, r)
		--r['set-cookie'] = string.gsub(r['set-cookie'], '[a-z_]+=deleted[^\n]+', '')
		FILMIXNET = string.match(r['set-cookie'] or '', 'FILMIXNET=(.-);') or FILMIXNET
		
		local data =
		{
			scf = 'fx',
			search_start = page,
			['do'] = 'search', subaction = 'search',
			years_ot = 1902, years_do = os.date('%Y'),
			kpi_ot = 1, kpi_do = 10,
			imdb_ot = 1, imdb_do = 10,
			sort_name = '', undefined = 'asc',
			sort_date = '', sort_favorite = '',
			simple = '1'
		}
		if args.keyword then
			data['story'] = args.keyword
		else
			data['years_ot'] = args.year
			data['years_do'] = args.year
		end
		data = http.encode(data)
		
		headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		headers['X-Requested-With'] = 'XMLHttpRequest'
		headers['Referer'] = url
		--headers['Cookie'] = r['set-cookie']
		headers['Cookie'] = 'FILMIXNET=' .. FILMIXNET .. ';'
		print(headers['Cookie'])
		
		local x = http.post(HOME .. '/engine/ajax/sphinx_search.php', headers, data, responses)
		--print(r['set-cookie'])
		--print(x)
		
		
     --  for title in string.gmatch(x, '<meta charset=(.-)var user_data') do
		
--for title in string.gmatch(x, '<div class="short"(.-)</a>') do
		
		
		
		for url, image, title in string.gmatch(x, '<div class="short">.-data%-id="(.-)".-src="(.-)".-<a itemprop="url" href=".-".->(.-)</a>') do
	
 --    url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
			image = string.gsub(image, '^/', HOME_PATH)
		
	--	table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
			table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end
		local title = L'page' .. ' ' .. tostring(page + 1)
		local url
		if args.keyword then


       url = '#stream/q=search&page=' .. tostring(page + 1) .. '&keyword=' .. urlencode(args.keyword)

	--		url = '#stream/q=search&page=' .. tostring(page + 1) .. '&keyword=' .. urlencode(args.keyword)
		else
			url = '#stream/q=search&page=' .. tostring(page + 1) .. '&year=' .. urlencode(args.year)
		end
		table.insert(t, {title = title, mrl = url, image = '#self/next.png'})
			
   
   
     elseif args.q == 'actor' then
    
    local x = conn1:load(args.id .. '?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380')
  
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')

		x = string.gsub(x, '\\u2013', '-')

  
  
  
  
  t['view'] = 'simple'
local x = string.match(x, '"found_actors"(.-)]')

for url, title in string.gmatch(x, '"id":(.-),"name":"(.-)"') do

--  https://thumbs.filmix.my/persons/w220/Брэд Питт.jpg

 url = string.gsub(url, '^(.-)', HOME1 .. '/person/')

    table.insert(t, {title = title, mrl = '#stream/q=actors&id=' .. url, image = image})
		end	
  
  
  elseif args.q == 'actors' then
    
    local x = conn1:load(args.id .. '?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380')
  
  local x = string.match(x, '"movies"(.-)]')
  
  for url, title, image in string.gmatch(x, '"id":(.-),"title":"(.-)".-"poster":"(.-)"') do
  
  
--url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
	image = string.gsub(image, '\\', '')
  
  table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end	
  
        elseif args.q == 'pohoj' then
    
    local x = conn:load(args.id)


--table.insert(t, {title = args.id, mrl = '#stream/q=content&id=' .. args.id, image = image})


     local slist = string.match(x, '<ul class="slider%-wrap overview"(.-)</ul>')


if slist then

for url, image, title in string.gmatch(slist, '<a href="https://.-/.-/.-/(.-)-v.-html".-<img src="(.-)".-alt="(.-)"') do


--url = string.gsub(url, '^(.-)', HOME1 .. '/post/')
	image = string.gsub(image, '\\', '')



	table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url, image = image})
		end	

end

	-- #stream/q=content&id=https://filmix.quest/multseries/animes/138925-igra-darvina-2020.html

    
	elseif args.q == 'content' then
		t['view'] = 'annotation'
        
--http://filmixapp.cyou/api/v2/post/180743?user_dev_id=a0625ba1b05bb157&user_dev_name=Kodi+18.9+%28Linux%29_bb157&user_dev_token=312d49d3a497a488609f411dc8005380
        
  --  http://filmixapp.cyou/api/v2/post/132423?user_dev_apk=2.0.1&user_dev_id=&user_dev_name=Xiaomi&user_dev_os=11&user_dev_token=&user_dev_vendor=Xiaomi
    
		local x = conn1:load(HOME1 .. '/post/' .. args.id .. '?user_dev_apk=2.0.1&user_dev_id=&user_dev_name=Xiaomi&user_dev_os=11&user_dev_token=312d49d3a497a488609f411dc8005380&user_dev_vendor=Xiaomi')
    	
 --  table.insert(t, {title = HOME1 .. '/post/' .. args.id .. '?user_dev_apk=2.0.1&user_dev_id=&user_dev_name=Xiaomi&user_dev_os=11&user_dev_token=312d49d3a497a488609f411dc8005380&user_dev_vendor=Xiaomi', mrl = '#stream/q=actor&id=' .. HOME1 .. '/post/' .. args.id .. '?user_dev_apk=2.0.1&user_dev_id=&user_dev_name=Xiaomi&user_dev_os=11&user_dev_token=&user_dev_vendor=Xiaomi', image = image})
    
    
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')

		x = string.gsub(x, '\\u2013', '-')

    	x = string.gsub(x, '"categories":%[', 'Жанр :')

    	
    	
    	
	--	local r = {}
	--	local x = conn:load(args.id, r)
		t['name'] = parse_match(x, 'class="name" itemprop="name">(.-)</')
		t['description'] = parse_match(x, '"short_story":"(.-)"')
		t['poster'] = parse_match(x, 'class="fullstory.-<img src="(.-)"')
		t['poster'] = string.gsub(t['poster'] or '', '^/', HOME_PATH)
		t['annotation'] = parse_array(x, {
			'(Жанр :.-)]', '(В ролях:.-)</div>', '(Сценарий:.-)</div>', '(Продюсер: .-)</div>',
			'(Жанр:.-)</div>', '(Страна:.-)</div>', '(Год:.-)</div>', '(Время:.-)</div>', '(Перевод:.-)</div>'
		})

for url in string.gmatch(x, '{"id":(.-),"section"') do

url = string.gsub(url, '^(.-)', HOME1 .. '/post/')


table.insert(t, {title = 'Актёры', mrl = '#stream/q=actor&id=' .. url, image = image})
end

--http.-/.-/.-(/.-)(/.-/)181695-tihaya-noch-smertelnaya-noch-2025.html"
 
--https://filmix.my/seria/uzhasu/180787-v-ono-dobro-pozhalovat-v-derri-2025.html
 
     for id, id1, id2, id3 in string.gmatch(x, '{"id":(.-),.-section.-"alt_name":"(.-)".-"post_url":"http.-/.-/.-(/.-)(/.-/)') do


 id2 = string.gsub(id2, '\\', '')
 id2 = string.gsub(id2, 'filmi', 'film')
id3 = string.gsub(id3, '\\', '')

url = string.gsub(id2, '^(.-)', HOME) .. id3 .. id .. '-v-' .. id1 .. '.html'


table.insert(t, {title = 'Похожие', mrl = '#stream/q=pohoj&id=' .. url, image = image})
end



--for id in string.gmatch(x, '"post_url":"http.-/.-/.-(/.-)"') do

--id = string.gsub(id, '\\', '')
-- id = string.gsub(id, 'filmi', 'film')

--id = string.gsub(id, '^(.-)', HOME)

--table.insert(t, {title = 'Похожие', mrl = '#stream/q=pohoj&id=' .. id, image = image})
--end


--<div class="related-block-title">Смотреть похожие Фильмы





--for url, title, title1 in string.gmatch(x, '"id":(.-),.-"title":"(.-)".-"year":(.-),') do
	
    --    url = string.gsub(url, '^(.-)', 'https://lam.maxvol.pro/lite/filmix?postid=')
	  
--	  table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
 --    end
     

for id, title, title1 in string.gmatch(x, '{"id":(.-),.-section.-"title":"(.-)".-"year":(.-),') do

   --   title = urlencode(title)
     
    --  title = string.gsub(title, '+', '%%20')
      
   --  url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

   --  local x = conn1:load(url)

  --  for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do


--url1 = string.gsub(title3, '^(.-)', 'http://peppega.ru/lite/vokino?kinopoisk_id=') 

--.. '&balancer=filmix'

--table.insert(t, {title = 'Смотреть', mrl = '#stream/q=filmix&id1=' .. title .. '&id2='.. title1, image = image})

table.insert(t, {title = 'Смотреть', mrl = '#stream/q=filmix&id=' .. id .. '&id1=' .. title .. '&id2=' .. title1, image = image})

end


for id, title, title1 in string.gmatch(x, '{"id":(.-),.-section.-"title":"(.-)".-"year":(.-),') do

id = string.gsub(id, '^(.-)', 'item/')


table.insert(t, {title = 'Плеер', mrl = '#stream/q=kinofit&id=' .. id, image = image})
end



--http://peppega.ru/lite/vokino?kinopoisk_id=386&balancer=filmix
	
  -- for title, title1 in string.gmatch(x, '<h1.->(.-)</h1>.-alt=".-,(.-)"') do

   for id, title, title1 in string.gmatch(x, '{"id":(.-),.-section.-"title":"(.-)".-"year":(.-),') do


id = string.gsub(id, '^(.-)', 'https://lamp-movie.ru/lite/filmix?postid=')

    local x = conn1:load(id)

--table.insert(t, {title = id, mrl = id})
    
    
    local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
  --  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
  --  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
  --  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-mp4).-class="videos__item%-title">(.-)<') do
  
  --  t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  

     
  --   local x = conn:load('http://peppega.ru/lite/filmix?kinopoisk_id=' .. args.id3 .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
    
      for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn1:load(url3)


--table.insert(t, {title = url3, mrl = '#stream/q=filmixz&id=' .. url3})

      for id, id1, id2, id3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)&postid=(.-)&.-&s=(.-)&t=(.-)".->(.-)</div>') do


--t['view'] = 'simple'

table.insert(t, {title = total .. ' ' .. total2, mrl = '#stream/q=filmixz&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})


end
end
end


   elseif args.q == 'filmixz' then


--https://lamp-movie.ru/lite/filmix?rjson=False&postid=169903&title=&original_title=&s=1&t=0

     local x = conn1:load(args.id .. '&postid=' .. args.id1 .. '&title=&original_title=&s=' .. args.id2 .. '&t=' .. args.id3)



local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

     end  
    end
    
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
      t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

      end 
    end 
    
  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(720p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

     end  
    end  
   
local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(480p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

       end
    end 
  






         




	elseif args.q == 'kinofit' then




--args.id = string.gsub(args.id, '^(.-)', 'item/')
         
   --      args.id=base64_encode(args.id)
 

 
       local x = conn1:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. base64_encode(args.id) .. '&box_mac=acace24b8434')


     
     
     for total, url1  in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do


         local x = conn1:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')

      

      for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]]></title>.-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do

      t['view'] = 'simple'
      
      table.insert(t, {title = (total1) .. ' ' .. tolazy(total), mrl = url2})
    
        end
        end
        
  
      




     local x = conn1:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. base64_encode(args.id) .. '&box_mac=acace24b8434')



      for total, url1 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
  
       total = string.gsub(total, '<!%[CDATA%[', '')
       total = string.gsub(total, ']]>', '')
       
     local x = conn1:load(url1 .. '&box_mac=acace24b8434')

    
    for total1, url2 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-сезон).-<playlist_url><!%[CDATA%[(http.-)]]') do
  

  
       total1 = string.gsub(total1, ']]> <![CDATA[', '')
       total1 = string.gsub(total1, ']]>', '')
   
        local x = conn:load(url2 .. '&box_mac=acace24b8434')
   

     
     for total2, total3, url3 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-серия)(.-)]]></title>.-<playlist_url><!%[CDATA%[http.-&goto=(.-)&.-]]') do
    
 --     total2 = string.gsub(total2, '<!%[CDATA%[', '')
   --   total2 = string.gsub(total2, ']]>', '')
 
 
 t['view'] = 'simple'
 
 table.insert(t, {title = tolazy(total1) .. ' ' .. tolazy(total2) .. ' ' .. tolazy(total), mrl = '#stream/q=kinofits&id=' .. url3})
 
 end
 end
 end
-- end
 
 
 elseif args.q == 'kinofits' then

local x = conn1:load('http://kb-team.club/?do=/plugin&bid=kinofit-kinofit_4k&goto=' .. args.id .. '&viewseason' .. '&box_mac=acace24b8434')
 
 
      
  --    local x = conn:load(url3 .. '&box_mac=acace24b8434')
 
     
     
     for total4, url4 in string.gmatch(x, '</channel>.-<channel>.-<title><!%[CDATA%[(.-p)]].-<playlist_url></playlist_url>.-<stream_url><!%[CDATA%[(http.-)]]') do
    
       total4 = string.gsub(total4, '<!%[CDATA%[', '')
      total4 = string.gsub(total4, ']]>', '')
    
    
    
      t['view'] = 'simple'
      
      table.insert(t, {title = tolazy(total4), mrl = url4})
    
        end






      
   --   local x = conn1:load(args.id)
   


     elseif args.q == 'filmix' then

  --    local x = conn1:load('http://parsers.appfxml.com/https://www.kinopoisk.ru/?id=search&search=' .. urlencode(args.id1) .. ',' .. args.id2)

--url = string.gsub(title, '^(.-)', 'http://parsers.appfxml.com/https://www.kinopoisk.ru/s?id=search&search=') .. ',' .. title1

   --  local x = conn1:load(url)

  --  for title3  in string.gmatch(x, '"fxml".-"playlist_url":"http.-kinopoisk.-id=info&cid=(.-)"') do

--id = string.gsub(id, '^(.-)', 'https://lamp-movie.ru/lite/filmix?postid=')

--local x = conn1:load('https://evkh.lol/lite/filmix?kinopoisk_id=' .. title3 .. '&title=' .. urlencode(args.id1) 


local x = conn1:load('https://evkh.lol/lite/filmix?postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2)
   
  -- table.insert(t, {title = 'https://evkh.lol/lite/filmix?postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2, mrl = 'https://evkh.lol/lite/filmix?postid=' .. args.id .. '&title=' .. urlencode(args.id1) .. '&year=' .. args.id2})
   
   
   
   
local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')
    
    if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1440p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
 if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
   t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(720p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
  
  
if slist then
     for total3, url4, total2 in string.gmatch(slist, '<div class="videos__item videos__movie.-"play".-"quality".-"(480p)":"(http.-)".-class="videos__item%-title">(.-)<') do
  
    t['view'] = 'simple'
    
     table.insert(t, {title = tolazy(total3) .. ' ' .. tolazy(total2), mrl = url4})
   
   end
   end
 
 
 
   
 for url3, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"(http.-)".-class="videos__item%-title videos__season%-title">(.-)</div>') do


      local x = conn1:load(url3)
   
   
     
for id, id1, id2, id3, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"(http.-)&postid=(.-)&.-&s=(.-)&t=(.-)".->(.-)</div>') do

    t['view'] = 'simple'
 
 
 
    
table.insert(t, {title = total .. ' ' .. total2, mrl = '#stream/q=filmixzz&id=' .. id .. '&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3})


end
end
--end




elseif args.q == 'filmixzz' then


--https://lamp-movie.ru/lite/filmix?rjson=False&postid=169903&title=&original_title=&s=1&t=0

     local x = conn1:load(args.id .. '&postid=' .. args.id1 .. '&title=&original_title=&s=' .. args.id2 .. '&t=' .. args.id3)



local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(2160p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

     end  
    end
    
   local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(1080p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
      t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

      end 
    end 
    
  local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(720p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

     end  
    end  
   
local slist = string.match(x, '<div class="videos__line">(.-)/div></div></div>')

if slist then

      for total4, url5, total3  in string.gmatch(slist, '<div class="videos__item videos__movie selector.-"method":"play.-quality.-"(480p)":"(http.-)".-class="videos__item%-title">(.-)</div>') do

 
 total4 = string.gsub(total4, ',"', '')
   
       t['view'] = 'simple'

    table.insert(t, {title = tolazy(total3) .. ' (' .. total4 .. ')', mrl = url5})

       end
    end 






	
	
	

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end

