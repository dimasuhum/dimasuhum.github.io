import sys
import zipfile
import os
import tempfile

for path in sys.path:
	if 'filmix.IMC.zip' in path:
		with zipfile.ZipFile(path) as zip:
			dest = tempfile.tempdir + os.sep + 'filmix'
			try:
				os.mkdir(dest)
			except:
				print('Directory exists!')
			members = ['filmixcert/__init__.py', 'filmixcert/certificate.pem', 'filmixcert/plainkey.pem']
			zip.extractall(dest, members)
			sys.path.insert(0, dest)
			break

from imc import url_for, get_image, __imcdevice__, __imcpackage__, get_setting, set_setting, get_str
from filmix import FilmixClient

api = FilmixClient()
token_result = api.token_request()

user_dev_id = get_setting('user_dev_id')
if user_dev_id is None:
	user_dev_id = api.create_dev_id()
	set_setting('user_dev_id', user_dev_id)

print(__imcdevice__)
print(user_dev_id)

api._user_dev_name = __imcdevice__
api._user_dev_id = user_dev_id
api._user_dev_token = token_result['code']

filter_items = {}
filter_data = {}
filter_prefix = {
	'countries' : 'c',
	'categories' : 'g',
	'years' : 'y',
	'rip' : 'q',
	'translation' : 't'
}

def get_filter_items(filter_id):
	if filter_id in filter_items:
		return filter_items[filter_id]
	
	_items = api.get_filter('cat', filter_id)
	
	prefix = filter_prefix[filter_id]
	items = {}
	
	for key, value in _items.items():
		start = 1 if filter_id != 'years' else 0
		new_key = prefix + key[start:]
		items[new_key] = value;
	
	filter_items[filter_id] = items
	
	return items

def get_image(name):
	return '#self/{0}&package={1}'.format(name, __imcpackage__)

def main(args):
	t = {'view' : 'simple', 'type' : 'folder'}
	t['items'] = items = []
	
	items.append({'title' : '@string/movies', 'url' : url_for('list_catalog', {'section' : 0})})
	items.append({'title' : '@string/serials', 'url' : url_for('list_catalog', {'section' : 7})})
	items.append({'title' : '@string/multfilms', 'url' : url_for('list_catalog', {'section' : 14})})
	items.append({'title' : '@string/multserials', 'url' : url_for('list_catalog', {'section' : 93})})

	items.append({'title' : '@string/popular', 'url' : url_for('list_catalog', {'type' : 'popular'})})
	items.append({'title' : '@string/top', 'url' : url_for('list_catalog', {'type' : 'top_views'})})
	
	items.append({'title' : '@string/search', 'url' : url_for('list_catalog', {'type' : 'search'}), 'icon' : get_image('search.png')})
	
	return t

#self/section=0&__func__=list_catalog
#self/section=7&__func__=list_catalog
def list_catalog(args):
	type = args.get('type', 'catalog')
	page = int(args.get('page', 1))
	
	if type == 'catalog':
		section = int(args.get('section', 0))
		filters = args.get('filters', '')
		params = {
			'page': page,
			'orderby': 'date',
			'section' : section,
			'orderdir': 'desc',
			'per_page': '15',
			'filters': filters
		}
		result = api.get_catalog_items(**params)
	elif type == 'popular':
		result = api.get_popular_items(page)
	elif type == 'top_views':
		result = api.get_top_views_items(page)
	elif type == 'search':
		if 'keyword' in args:
			result = api.get_search_catalog(args['keyword'], 1)
			if len(result['items']) == 0:
				return {'view' : 'message', 'message' : '@string/not_available'}
		else:
			return {'view' : 'keyword', 'message' : '@string/search_text'}
	#print(result)
	
	t = {'view' : 'posters', 'type' : 'folder'}
	t['menu'] = menu = []	
	
	if type == 'catalog':
		menu.append({
			'title' : '@string/filter',
			'url' : url_for('select_filter', {'section' : str(section)}),
			'icon' : get_image('good.png')
		})
	
	menu.append({
		'title' : '@string/search',
		'url' : url_for('list_catalog', {'type' : 'search'}),
		'icon' : get_image('search.png')
	})
	
	t['items'] = items = []
	for item in result['items']:
		url = url_for('movie', {'id' : item['id']})
		#print(url)
		annotation = []
		items.append({'title' : item['title'], 'url' : url, 'icon' : item['poster'], 'annotation' : annotation})
	
	if type != 'search' and len(items) >= 15:
		args['page'] = str(page + 1)
		items.append({
			'title' : get_str('page') + ' ' + args['page'],
			'url' : url_for(args),
			'icon' : get_image('next.png')
		})
	
	return t

#self/__func__=select_filter
def select_filter(args):
	t = {'view' : 'select', 'message' : '@string/select_filter'}
	
	t['items'] = items = []
	
	params = {'section' : args.get('section', '0')}

	for filter_id in filter_prefix.keys():
		params['filter_id'] = filter_id
		items.append({'title' : '@string/{}'.format(filter_id), 'url' : url_for('filter_cat', params)})
	
	return t
	
#self/__func__=filter_cat&filter_id=categories&section=7
#self/__func__=filter_cat&filter_id=years&section=0
def filter_cat(args):
	t = {'view' : 'simple', 'type' : 'folder'}
	
	t['items'] = items = []
	
	filters = args.get('filters', '')
	filters = filters.split('-') if filters else []
	
	params = {'section' : args.get('section', None)}
	
	filter_id = args['filter_id']
	f = get_filter_items(filter_id)

	for key, value in f.items():
		ff = filters.copy()
		ff.append(key)
		params['filters'] = '-'.join(ff)
		items.append({'title' : value, 'url' : url_for('list_catalog', params)})
	
	return t

#self/id=149466&__func__=movie
#self/id=148345&__func__=movie
def movie(args):
	movie_info = api.get_movie_info(args['id'])
	#print(movie_info)
	
	t = {'view' : 'annotation', 'type' : 'folder'}
	
	t['menu'] = menu = []
	menu.append({'title' : '@string/search', 'url' : url_for('list_catalog', {'type' : 'search'}), 'icon' : get_image('search.png')})
	
	t['title'] = movie_info['title']
	t['poster'] = movie_info['poster']
	t['description'] = movie_info['short_story']
	
	t['annotation'] = annotation = []
	names = ['original_title', 'year', 'directors', 'actors', 'duration', 'date']
	for name in names:
		if name in movie_info:
			label = get_str(name)
			value = movie_info[name]
			if isinstance(value, list):
				annotation.append(label + ': ' + ', '.join(value))
			elif len(str(value)) > 0:
				annotation.append(label + ': ' + str(value))
	
	t['items'] = items = []
	player_links = movie_info['player_links']
	
	if 'movie' in player_links and isinstance(player_links['movie'], list):
		watch = get_str('watch')
		for movie in player_links['movie']:
			title = watch
			if 'translation' in movie and len(movie['translation']) > 0:
				title += ' (' + movie['translation'] + ')'
			url = url_for('video', {'link' : movie['link'], 'title' : t['title']})
			items.append({'title' : title, 'url' : url})
	
	if 'playlist' in player_links and isinstance(player_links['playlist'], dict):
		season = get_str('season')
		episode = get_str('episode')
		playlist = player_links['playlist']
		for s in playlist:
			temp_title = season + ' ' + s + '. ' + episode + ' '
			translations = playlist[s]
			for translation in translations:
				movies = translations[translation]
				for e in movies:
					movie = movies[e]
					title = temp_title + e + ' (' + translation + ')'
					qualities = '['
					for quality in movie['qualities']:
						if len(qualities) > 1:
							qualities += ','
						qualities += str(quality)
					qualities += ']'
					url = url_for('video', {'link' : movie['link'], 'title' : title, 'qualities' : qualities})
					items.append({'title' : title, 'url' : url})
	
	return t

def video(args):
	t = {'view' : 'select', 'message' : '@string/select_quality'}
	t['items'] = items = []
	
	link = api.decode_link(args['link'])
	
	if 'qualities' in args:
		link = link % args['qualities']
	
	sub_a = link.find('[')
	sub_b = link.find(']')
	
	qualities = link[sub_a + 1:sub_b].split(',')
	
	for quality in qualities:
		if len(quality) > 0:
			title = args['title'] + ' - ' + quality + 'P'
			url = link.replace(link[sub_a:sub_b + 1], quality)
			items.append({'title' : title, 'url' : url, 'type' : 'video', 'quality' : quality})
			
	if len(items) == 1:
		del t['view']
			
	return t
