-- fast-film plugin

require('support')
require('video')
require('parser')

--HOME = 'https://vezonchik.space'
--HOME = 'https://vezonchik.host'

HOME = 'https://vezon.club'
--HOME = 'https://vezon.ru'
--PASS = '8080'

--local lockpass


HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from fast-film plugin')
	return 1
end

function onUnLoad()
	print('Bye from fast-film plugin')
end

function onCreate(args)
--if not args.q and args.keyword then
--lockpass = args.keyword
--end

--if lockpass == PASS then
--else
--return {view="keyword",message="enter --access code"}
--end


	local t = {view = 'grid_large', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	-- #stream/page=2
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/video/'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
		
        if genre == '/video/?sort=all' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=all'
		end
        if genre == '/video/?sort=azi' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=azi'
		end
    	if genre == '/video/?sort=stu' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=stu'
		end	
        if genre == '/video/?sort=tit' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=tit'
		end
    	if genre == '/video/?sort=ass' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=ass'
		end	
        if genre == '/video/?sort=plu' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=plu'
		end	
	if genre == '/video/?sort=dom' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=dom'
		end	
        if genre == '/video/?sort=gru' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=gru'
		end		
    	if genre == '/video/?sort=mil' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=mil'
		end	
        if genre == '/video/?sort=har' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=har'
		end		
        if genre == '/video/?sort=int' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=int'
		end		
    	if genre == '/video/?sort=cla' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=cla'
		end	
        if genre == '/video/?sort=bds' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=bds'
		end					
        if genre == '/video/?sort=ana' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=ana'
		end		
    	if genre == '/video/?sort=les' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=les'
		end	
        if genre == '/video/?sort=bru' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=bru'
		end		
        if genre == '/video/?sort=blo' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=blo'
		end		
    	if genre == '/video/?sort=red' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=red'
		end	
        if genre == '/video/?sort=big' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=big'
		end		
        if genre == '/video/?sort=sma' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=sma'
		end		
    	if genre == '/video/?sort=toy' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=toy'
		end	
        if genre == '/video/?sort=job' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=job'
		end		
        if genre == '/video/?sort=tri' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=tri'
		end		
    	if genre == '/video/?sort=mas' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=mas'
		end	
        if genre == '/video/?sort=fet' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=fet'
		end		
        if genre == '/video/?sort=pub' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=pub'
		end		
    	if genre == '/video/?sort=pus' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=pus'
		end	
        if genre == '/video/?sort=dou' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=dou'
		end		
        if genre == '/video/?sort=tat' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=tat'
		end		
    	if genre == '/video/?sort=org' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=org'
		end	
        if genre == '/video/?sort=rgy' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=rgy'
		end		
        if genre == '/video/?sort=cas' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=cas'
		end		
    	if genre == '/video/?sort=squ' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=squ'
		end	
        if genre == '/video/?sort=fin' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=fin'
		end		
        if genre == '/video/?sort=old' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=old'
		end		
    	if genre == '/video/?sort=oil' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=oil'
		end	
        if genre == '/video/?sort=rom' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=rom'
		end		
        if genre == '/video/?sort=par' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=par'
		end		
    	if genre == '/video/?sort=cos' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=cos'
		end	
        if genre == '/video/?sort=pon' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=pon'
		end		
        if genre == '/video/?sort=fis' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=fis'
		end		
    	if genre == '/video/?sort=swi' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=swi'
		end	
        if genre == '/video/?sort=cum' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=cum'
		end		
        if genre == '/video/?sort=sol' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=sol'
		end		
    	if genre == '/video/?sort=pov' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=pov'
		end	
        if genre == '/video/?sort=cre' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=cre'
		end		
        if genre == '/video/?sort=han' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=han'
		end		
    	if genre == '/video/?sort=rol' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=rol'
		end	
        if genre == '/video/?sort=rus' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=rus'
		end	
        if genre == '/video/?sort=str' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=str'
		end		
    	if genre == '/video/?sort=wif' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=wif'
		end	
        if genre == '/video/?sort=web' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=web'
		end	
        if genre == '/video/?sort=ani' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=ani'
		end		
    	if genre == '/video/?sort=hen' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=hen'
		end	
        if genre == '/video/?sort=sub' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=sub'
		end	
        if genre == '/video/?sort=joi' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=joi'
		end		
    	if genre == '/video/?sort=asm' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=asm'
		end	
        if genre == '/video/?sort=vin' then
        url = HOME .. '/video/' .. '?page=' .. tostring(page) .. '&sort=vin'
		end	

		local x = http.getz(url)
         
       -- x = iconv(http.get(url), 'WINDOWS-1251', 'UTF-8')
		for image, url, title in string.gmatch(x, '<style>.-background%-image:.-(/video.-jpg).-<a href="(?f.-.mp4)".-style="margin:.->(.-)</div>') do
		
          url = string.gsub(url, '^(.-)', HOME .. '/video/')
          image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
		local url = '#folder/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
         local x = http.getz(HOME .. '/video/')
		
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		local x = string.match(x, '<select id="cats".-Выбор категории.->(.-)</select>')
		for genre, title in string.gmatch(x, '<option value="(.-)">(.-)</option>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. '/video/?sort=' .. genre})
		end
        

	-- #stream/q=content&id=/15387-predchuvstvie-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
     --   x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--print(x)
		t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<div class="m%-desc full%-text clearfix slice%-this slice slice%-masked">(.-)</div>')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
		t['annotation'] = parse_array(x, {
			'(Качество:</span>.-)</div>','(Жанр:</span>.-)</div>', '(Страна:</span>.-)</div>', '(Год:</span>.-)</div>', '(Режиссер:</span>.-)</div>',
			'(Время:</span>.-)</div>', '(Перевод:</u>.-)<br', '(В ролях:</span>.-)</div>'
		})
        for url in string.gmatch(x, 'player = new Playerjs.-file:"(//.-mp4)"') do
		
         print(url)
		 url = string.gsub(url, '^(.-)', 'https:')

			t = video(url, args)
			if t['view'] ~= 'error' then
				break
			end
       
         table.insert(t, {mrl = url})

			
		end

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end