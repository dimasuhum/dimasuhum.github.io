-- topcinema plugin

require('support')
require('video')
require('parser')
require('client')


--https://zombie-film.live/
local HOME = 'https://zombie-film.live'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



--HOME = 'https://zombie-film.net'
--HOME = 'https://zombie-film.live'
--http://zombie-film.live/
--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from topcinema plugin')
	return 1
end

function onUnLoad()
	print('Bye from topcinema plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
--	end
--	 #stream/page=2
	-- #stream/genre=/person/sandra-bullok
	
	-- #stream/genre=/blog/america-serials/page
    -- #stream/genre=/blog/brazilian-serials/page
	-- #stream/url=/blog/brazilian-serials/
	-- #stream/url=/america-serials/svetila-the-luminaries.html
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/films'
		
        --local url1 = url
        --url1 = url
        
        local url = HOME .. genre
		if page > 1 then
			url = url .. '?page=' .. tostring(page)
		end
	--	local x = http.getz(HOME .. genre .. '?page=' .. tostring(page))
	--	local x = http.getz(url)
		
         local x = conn:load(url)
      --  x = iconv(x, 'utf-8', 'UTF-8')


		 for url, image, title  in string.gmatch(x, '<a class="video%-item%-img" href="(.-)".-src="(//.-)".-class="video%-item%-title".->(.-)<') do


		 
--http://img.zombie-film.live/information/6/9/5/7/5/0/0/0/0/0/260x364_69575.jpg?t=1638549212
	    	 image = string.gsub(image, '^(.-)', 'http:')
			image = string.gsub(image, 'placeholder', '260x364')
            
            url = string.gsub(url, '^(.-)', HOME)


		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
         end
       
       
    --     for url, image, title  in string.gmatch(x, '<div class="col%-6 col%-sm%-4 col%-md%-3 col%-xl%-2".-class="video%-item%-img".-href="(.-)".-src="(//.-)".-class="video%-item%-title".->(.-)<') do


--http://img.zombie-film.live/information/6/9/5/7/5/0/0/0/0/0/260x364_69575.jpg?t=1638549212
	  --  	 image = string.gsub(image, '^(.-)', 'http:')
	--		image = string.gsub(image, 'placeholder', '260x364')
			
         --   url = string.gsub(url, '^(.-)', HOME)       
       --   table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})

    --    table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})


       --  end
	
    	for url, image, title in string.gmatch(x, 'class="video%-item%-img" href="(/person.-)".-src="(.-)".-class="video%-item%-title".->(.-)<') do
        image = string.gsub(image, '^(.-)', 'http:')
		image = string.gsub(image, 'placeholder', '260x364')
        --   url = string.gsub(url, '^(.-)', HOME)
            
          table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. url, image = image})
		end
		
		
		
		
		
         for url, title, total  in string.gmatch(x, '<div class="col%-12 col%-sm%-6 col%-lg%-4 px%-sm%-20 d%-flex flex%-wrap flex%-column".-href="(.-)".-<h5 class="card%-title">(.-)</h5>.-class="h6 text%-base">(.-)<') do
			--image = string.gsub(url, '^/', HOME_SLASH)
            --url = string.gsub(url, '^/', HOME_SLASH)
			table.insert(t, {title = tolazy(title) .. '(' .. total .. ')', mrl = '#folder/genre=' .. url })
    	end


     --   for url, title, image  in string.gmatch(x, '<div class="pl%-xl%-10 pr%-xl%-10".-href="(.-)".-class="fs%-14 mb%-10 text%-center">(.-)<.-src="(.-)"') do
          --  url = string.gsub(url, '^/', HOME_SLASH)
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
    --	end

		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'

--https://zombie-film.live/ozvuchky


   --     table.insert(t, {title = 'Озвучки', mrl = '#stream/genre=' .. '/ozvuchky'})
   
   
       table.insert(t, {title = 'Новинки', mrl = '#stream/genre=' .. '/kinonovinki'})
      table.insert(t, {title = ' Фильмы 2024', mrl = '#stream/genre=' .. '/tag-films-2024'})
        table.insert(t, {title = ' Фильмы 2023', mrl = '#stream/genre=' .. '/tag-films-2023'})
        table.insert(t, {title = ' Фильмы 2022', mrl = '#stream/genre=' .. '/tag-films-2022'})	 
       table.insert(t, {title = 'Фильмы 2021', mrl = '#stream/genre=' .. '/films-2021'})
		table.insert(t, {title = ' Фильмы 2020', mrl = '#stream/genre=' .. '/tag-films-2020'})	 
     table.insert(t, {title = 'Фильмы 2019', mrl = '#stream/genre=' .. '/films-2019'})
	table.insert(t, {title = 'Все фильмы', mrl = '#stream/genre=' .. '/films'})	 
	 table.insert(t, {title = 'Арт-хаус (фильмы)', mrl = '#stream/genre=' .. '/films/art-haus'})	 
     table.insert(t, {title = 'Блокбастеры (фильмы)', mrl = '#stream/genre=' .. '/films/blokbastery'})
	table.insert(t, {title = 'Детективы (фильмы)', mrl = '#stream/genre=' .. '/films/detektivy'})	 
     table.insert(t, {title = 'Документальные фильмы', mrl = '#stream/genre=' .. '/films/dokumentalnye'})	 
	 table.insert(t, {title = 'Зарубежные (фильмы)', mrl = '#stream/genre=' .. '/films/zarubezhnye'})	 
     table.insert(t, {title = 'Комедии (фильмы)', mrl = '#stream/genre=' .. '/films/komedii'})
	table.insert(t, {title = 'Криминал (фильмы)', mrl = '#stream/genre=' .. '/films/kriminal'})	 
     table.insert(t, {title = 'Мистические (фильмы)', mrl = '#stream/genre=' .. '/films/misticheskie'})	 	 
		table.insert(t, {title = 'Полнометражные (фильмы)', mrl = '#stream/genre=' .. '/films/polnometrazhnye'})	 
     table.insert(t, {title = 'Развлекательные (фильмы)', mrl = '#stream/genre=' .. '/films/razvlekatelnye'})
	table.insert(t, {title = 'Семейные (фильмы)', mrl = '#stream/genre=' .. '/films/semeynye'})	 
     table.insert(t, {title = 'Триллеры (фильмы)', mrl = '#stream/genre=' .. '/films/trillery'})	 
	 table.insert(t, {title = 'Фантастика (фильмы)', mrl = '#stream/genre=' .. '/films/fantastika'})	 
     table.insert(t, {title = 'Биогрические (фильмы)', mrl = '#stream/genre=' .. '/films/biograficheskie'})
	table.insert(t, {title = 'Боевики (фильмы)', mrl = '#stream/genre=' .. '/films/boeviki'})	 
     table.insert(t, {title = 'Военные (фильмы)', mrl = '#stream/genre=' .. '/films/voennye'})	 	 
      table.insert(t, {title = 'Детские (фильмы)', mrl = '#stream/genre=' .. '/films/detskie'})	 
     table.insert(t, {title = 'Драмы (фильмы)', mrl = '#stream/genre=' .. '/films/dramy'})
	table.insert(t, {title = 'Исторические (фильмы)', mrl = '#stream/genre=' .. '/films/istoricheskie'})	 
     table.insert(t, {title = 'Концерт', mrl = '#stream/genre=' .. '/films/koncert'})	 
	 table.insert(t, {title = 'Мелодрама (фильмы)', mrl = '#stream/genre=' .. '/films/melodramy'})	 
     table.insert(t, {title = 'Музыка (фильмы)', mrl = '#stream/genre=' .. '/films/muzyka'})
	table.insert(t, {title = 'Приключения (фильмы)', mrl = '#stream/genre=' .. '/films/priklyucheniya'})	 
     table.insert(t, {title = 'Русские (фильмы)', mrl = '#stream/genre=' .. '/films/russkie'})	 	
      table.insert(t, {title = 'Спорт (фильмы)', mrl = '#stream/genre=' .. '/films/sportivnye'})	 
     table.insert(t, {title = 'Ужасы (фильмы)', mrl = '#stream/genre=' .. '/films/uzhasy'})
	table.insert(t, {title = 'Фентези (фильмы)', mrl = '#stream/genre=' .. '/films/fentezi'})	 
     table.insert(t, {title = 'Эротика (фильмы)', mrl = '#stream/genre=' .. '/films/erotika'})
     
 
       table.insert(t, {title = 'Сериалы 2023', mrl = '#stream/genre=' .. '/tag-series-2023'})
     
      table.insert(t, {title = 'Сериалы 2022', mrl = '#stream/genre=' .. '/tag-series-2022'})
     
      table.insert(t, {title = 'Сериалы 2021', mrl = '#stream/genre=' .. '/tag-series-2021'})
     
	 table.insert(t, {title = 'Сериалы 2020', mrl = '#stream/genre=' .. '/tag-series-2020'})	 
     table.insert(t, {title = 'Сериалы 2019', mrl = '#stream/genre=' .. '/tag-series-2019'})
	table.insert(t, {title = 'Телешоу', mrl = '#stream/genre=' .. '/tv-show'})	 
     table.insert(t, {title = 'Все сериалы', mrl = '#stream/genre=' .. '/series'})	 	
	table.insert(t, {title = ' Биографические (сериалы)', mrl = '#stream/genre=' .. '/series/biograficheskie'})	 
     table.insert(t, {title = 'Боевики (сериалы)', mrl = '#stream/genre=' .. '/series/boeviki'})
	table.insert(t, {title = '(Военные сериалы)', mrl = '#stream/genre=' .. '/series/voennye'})	 
     table.insert(t, {title = 'Документальные (сериалы)', mrl = '#stream/genre=' .. '/series/dokumentalnye'})	 	
	 table.insert(t, {title = 'Зарубежные (сериалы)', mrl = '#stream/genre=' .. '/series/zarubezhnye'})	 
     table.insert(t, {title = 'Комедии (сериалы)', mrl = '#stream/genre=' .. '/series/komedii'})
	table.insert(t, {title = 'Комедии (сериалы)', mrl = '#stream/genre=' .. '/series/melodramy'})	 
     table.insert(t, {title = 'Приключения (сериалы)', mrl = '#stream/genre=' .. '/series/priklyucheniya'})	 	
	table.insert(t, {title = 'Русские (сериалы)', mrl = '#stream/genre=' .. '/series/russkie'})	 
     table.insert(t, {title = 'Триллеры (сериалы)', mrl = '#stream/genre=' .. '/series/trillery'})
	table.insert(t, {title = 'Фантастика (сериалы)', mrl = '#stream/genre=' .. '/series/fantastika'})	 
     table.insert(t, {title = 'Блогбастеры (сериалы)', mrl = '#stream/genre=' .. '/series/blokbastery'})	 	
      table.insert(t, {title = 'Вестерны (сериалы)', mrl = '#stream/genre=' .. '/series/vesterny'})	 
     table.insert(t, {title = 'Детективы (сериалы)', mrl = '#stream/genre=' .. '/series/detektivy'})
	table.insert(t, {title = 'Драмы (сериалы)', mrl = '#stream/genre=' .. '/series/dramy'})	 
     table.insert(t, {title = 'Исторические (сериалы)', mrl = '#stream/genre=' .. '/series/istoricheskie'})	 	
	table.insert(t, {title = 'Криминал (сериалы)', mrl = '#stream/genre=' .. '/series/kriminal'})	 
     table.insert(t, {title = 'Мистические (сериалы)', mrl = '#stream/genre=' .. '/series/misticheskie'})
	table.insert(t, {title = 'Развлекательные (сериалы)', mrl = '#stream/genre=' .. '/series/razvlekatelnye'})	 
     table.insert(t, {title = 'Семейные (сериалы)', mrl = '#stream/genre=' .. '/series/semeynye'})	 	
     table.insert(t, {title = 'Ужасы (сериалы)', mrl = '#stream/genre=' .. '/series/uzhasy'})	 
     table.insert(t, {title = 'Фентези (сериалы)', mrl = '#stream/genre=' .. '/series/fentezi'})
     
        table.insert(t, {title = 'Мульфильмы 2023', mrl = '#stream/genre=' .. '/tag-cartoons-2023'})
       table.insert(t, {title = 'Мульфильмы 2022', mrl = '#stream/genre=' .. '/tag-cartoons-2022'})
      table.insert(t, {title = 'Мульфильмы 2021', mrl = '#stream/genre=' .. '/tag-cartoons-2021'})
	table.insert(t, {title = 'Мульфильмы 2020', mrl = '#stream/genre=' .. '/tag-cartoons-2020'})	 
     table.insert(t, {title = 'Мультфильмы 2019', mrl = '#stream/genre=' .. '/tag-cartoons-2019'})	 	
	table.insert(t, {title = 'Мультсериалы', mrl = '#stream/genre=' .. '/multserialy'})	 
     table.insert(t, {title = 'Для взрослых(мульты)', mrl = '#stream/genre=' .. '/multfilmy-vzroslye'})
	table.insert(t, {title = 'Все (мульты)', mrl = '#stream/genre=' .. '/cartoons'})	 
     table.insert(t, {title = 'Аниме (мульты)', mrl = '#stream/genre=' .. '/animation'})	 
     table.insert(t, {title = 'Вестерны (мульты)', mrl = '#stream/genre=' .. '/cartoons/vesterny'})	 
     table.insert(t, {title = 'Детские (мульты)', mrl = '#stream/genre=' .. '/cartoons/detskie'})	 	
	table.insert(t, {title = 'Исторические (мульты)', mrl = '#stream/genre=' .. '/cartoons/istoricheskie'})	 
     table.insert(t, {title = 'Мульфильм(мульты)', mrl = '#stream/genre=' .. '/cartoons/multfilm'})
	table.insert(t, {title = 'Приключения (мульты)', mrl = '#stream/genre=' .. '/cartoons/priklyucheniya'})	 
     table.insert(t, {title = 'Русские (мульты)', mrl = '#stream/genre=' .. '/cartoons/russkie'})	 
     table.insert(t, {title = 'Фантастика (мульты)', mrl = '#stream/genre=' .. '/cartoons/fantastika'})	 
     table.insert(t, {title = 'Военные (мульты)', mrl = '#stream/genre=' .. '/cartoons/voennye'})	 	
	table.insert(t, {title = 'Зарубежные (мульты)', mrl = '#stream/genre=' .. '/cartoons/zarubezhnye'})	 
     table.insert(t, {title = 'Комедии (мульты)', mrl = '#stream/genre=' .. '/cartoons/komedii'})
	table.insert(t, {title = 'Полнометражные (мульты)', mrl = '#stream/genre=' .. '/cartoons/polnometrazhnye'})	 
     table.insert(t, {title = 'Развлекательные (мульты)', mrl = '#stream/genre=' .. '/cartoons/razvlekatelnye'})	 
     table.insert(t, {title = 'Семейные (мульты)', mrl = '#stream/genre=' .. '/cartoons/semeynye'})	 
     table.insert(t, {title = 'Фэнтези (мульты)', mrl = '#stream/genre=' .. '/cartoons/fentezi'})
     
     
     
	table.insert(t, {title = 'Подборки', mrl = '#stream/genre=' .. '/collection'})	 
     table.insert(t, {title = 'Знаменитости', mrl = '#stream/genre=' .. '/person'})
--	table.insert(t, {title = '(мульты)', mrl = '#folder/genre=' .. '/series/blokbastery'})	 
    -- table.insert(t, {title = '(мульты)', mrl = '#folder/genre=' .. '/series/blokbastery'})	 
     
     
     
     
		 
		 
       -- local x = http.getz(HOME)
	--	x = string.match(x, '<ul class="row no%-gutters mt%-10 btn%-link%-list"(.-)</ul>')
       -- for genre, title in string.gmatch(x,'<a.-href="(.-)">(.-)</a>') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
	--	end
	
--https://zombie-film.live/search?search=%D0%92%D0%BE%D1%80



     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/search?search=' .. urlencode(args.keyword) .. '?page='  .. tostring(page)

		
		local x = conn:load(url)
      --  x = iconv(x, 'utf-8', 'UTF-8')
		 for url, image, title  in string.gmatch(x, 'class="video%-item%-img".-href="(.-)".-src="(.-)".-class="video%-item%-title".-href.->(.-)<') do

	    	 image = string.gsub(image, '^(.-)', 'http:')
			image = string.gsub(image, 'placeholder', '260x364')
            
            url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '?page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
			
		
	-- #stream/q=content&id=https://zombie-film.net/multfilm-velikiy-sever
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = conn:load(args.id)
      --  local x = http.getz(args.id)
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
     	t['description'] = parse_match(x,'{"title":".-zombie%-film.live. (.-)","keywords"')
    --   t['description'] = parse_match(x,'itemprop="description.->(.-)</p>')
        t['poster'] = args.p
	--	t['poster'] = parse_match(x,'<link rel="image_src" href="(.-)"')
	--	if t['poster'] then
		--	t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
		t['annotation'] = parse_array(x, {
			'%[{"id".-"name":"(.-)".-"poster"', '%[{"id".-"name":".-".-"name":"(.-)".-"poster"', 
'(Жанр:</div>.-)</ul>'
		})


--"view":{"id":92299,"kpId":"4626783"

       for url in string.gmatch(x, '"view":{"id":.-,"kpId":"(.-)"') do
        print(url)
        
        url = string.gsub(url, '^(.-)', 'https://kinobd.net/api/films/search/kp_id?q=')
			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end
        
		 for url  in string.gmatch(x, 'current_page".-"data":%[{"id":.-,"kinopoisk_id":(.-),') do
   

        url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=0&kinopoisk_id=')
        

      local x =  http.getz(url)
       
      
       
       for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(1080p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(720p).-(http.-mp4)') do
           t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(480p).-(http.-mp4)') do
            t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
      for title, total, url in string.gmatch(x, '"method":"play","url".-"title":"(.-)".-(360p).-(http.-mp4)') do
          t['view'] = 'simple'
				table.insert(t,{title=tolazy(title) .. total,mrl= url})
			end
end
--end
        
        
        for url1, url2  in string.gmatch(x, 'current_page".-"data":%[{"id":(.-),"kinopoisk_id":(.-),') do
       
		url = string.gsub(url2, '^(.-)', 'https://voidboost.net/embed/')
       
       
        local x = http.getz(url)
    --x = string.match(x, '<select name="season".->(.-)</select>')
    
        for url, title in string.gmatch(x, '<option value="(.-)".-(Сезон.-)</option>') do
  

       url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=' .. url1 .. '&kinopoisk_id=' .. url2 .. '&title=&original_title=&s=')
        

         
     local x = http.getz(url)



       for url, total  in string.gmatch(x, 'method":"play","url":"(.-)","title":"(.-)",') do
       

       t['view'] = 'simple'

       table.insert(t, {title = title .. (total), mrl = url})
    
    	end
	end
    end


    
    
    
    
    
    
    
    
    
    
    
      for url in string.gmatch(x, '"view":{"id":.-,"kpId":"(.-)"') do
		 print(url)
	
    	url = string.gsub(url, '^(.-)', 'https://cdnmovies-stream.online/kinopoisk/') .. '/iframe?domain=kinobd.net'
    	
    	

			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
			
		end

      --   local x = http.getz(url)
         
         for url in string.gmatch(x, 'player.-:.-#2(.-)"') do
       
       
         print(url)

         url = string.gsub(url, '\\/\\/Ni14UVdNaDdlcnRMcDh0X005aHVVRGsxTTBWcllK', '')
         url = string.gsub(url, '\\/\\/d05wMndCVE5jUFJRdlRDMF9DcHhDc3FfOFQxdTlR', '')
         url = string.gsub(url, '\\/\\/bWQtT2QyRzlSV09nU2E1SG9CU1NiV3JDeUlxUXlZ', '')
         url = string.gsub(url,'\\/\\/a3p1T1lRcUJfUVNPTC14ek5fS3oza2tna0hoSGl0', '')
         url = string.gsub(url,'VfR0xFc1h4bnBVNExqamQwUmVZLVZI', '')
         url = string.gsub(url,'\\/\\/UnlUd3RmMT', '')




         url=http.urldecode(base64_decode(url))
  


        
        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(240p)](http.-.m3u8)') do
			

           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
      
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        
		        if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(360p)](http.-.m3u8)') do
			

            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title = tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
			
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(480p)](http.-.m3u8)') do
			
           --  title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(720p)](http.-.m3u8)') do
			
         --    title = tolazy(title)
           t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
                if url then
			for title, total, url in string.gmatch(url, '{"title":"(.-)".-%[(1080p)](http.-.m3u8)') do
			
         --    title = tolazy(title)
            t['view'] = 'simple'
       url = string.gsub(url, '\\', '')
       
				table.insert(t,{title=tolazy(title) .. '(' .. total .. ')',mrl= url})
			end
		end	
        end
    


        for url in string.gmatch(x, '"view":{"id":.-,"kpId":"(.-)"') do
		 print(url)
		 
        url = string.gsub(url, '^(.-)', 'http://sp-social.ru/19/divan.php?name=') 

       table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id=' .. url})
		end
		
	for title, url in string.gmatch(x, '#EXTINF:.-,(.-)(http.-)#EXTINF') do
       t['view'] = 'simple'

       table.insert(t, {title = title, mrl = url})

		end	




		  for url in string.gmatch(x, '<link rel="canonical".-href.-https.-(/serial.-)"') do
            url = string.gsub(url, '^/',  HOME_SLASH) .. '-sezon-1'		
            table.insert(t, {title = 'Смотреть сериал', mrl = '#stream/q=content&id=' .. url})
    	end

    for url in string.gmatch(x, '<link rel="canonical".-href.-https.-(/tv.-)"') do
            url = string.gsub(url, '^/',  HOME_SLASH) .. '-sezon-1'		
            table.insert(t, {title = 'Смотреть тв-шоу', mrl = '#stream/q=content&id=' .. url})
    	end
    
    

	
        for url in string.gmatch(x, '<link rel="canonical".-href.-https.-(/multfilm.-)"') do
            url = string.gsub(url, '^/',  HOME_SLASH) .. '-sezon-1'		
            table.insert(t, {title = 'Смотреть мультсериал', mrl = '#stream/q=content&id=' .. url})
    	end		

      
      
      
      
       for title, url, total in string.gmatch(x, '"episode".-"hlsList".-"(.-)".-(https.-)".-"title".-"(.-)"') do

			print(url)
   --     t['view'] = 'simple'
      --  t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb=
        end
		
		for title, url, total in string.gmatch(x, '"episode".-"hlsList".-,"(.-)".-(https.-)".-"title".-"(.-)"') do
			print(url)
    --     t['view'] = 'simple'
      --  t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb='})
        end
--src="https://api1617026518.tobaco.ws
--https://api1584276060.tobaco.ws/embed/kp/737843


         for url, title in string.gmatch(x, '"ovsEmbededHtml":"https://api.-(/embed.-)".-"title":"(.-)"') do

         url = string.gsub(url, '^(.-)',  'https://api.getcodes.ws')
       --  t['view'] = 'simple'

          table.insert(t, {title = title, mrl = '#stream/q=content&id='  .. url})
		end
		
       for url in string.gmatch(x, '<iframe.-src="(.-)"') do 
       -- t['view'] = 'grid'
       -- t['viewtype'] = 'playlist'
			table.insert(t, {title = 'Смотреть', mrl = '#stream/q=content&id='  .. url})
		end
		
        
        for title, url in string.gmatch(x, 'title: "(.-)".-hls: "(https://.-m3u8)"') do
        --	print(url)
       
      -- url = string.gsub(url, '\\', '')
     --   t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end

     	for url, title in string.gmatch(x, '"hls":"(https.-m3u8)".-"title":"(.-)"') do

			print(url)
      --  t['view'] = 'simple'
      --  t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end	
       for title, url, total in string.gmatch(x, '"episode".-"hlsList".-"(.-)".-(https.-)".-"title".-"(.-)"') do

			print(url)
     --   t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb='})
        end
		
		for title, url, total in string.gmatch(x, '"episode".-"hlsList".-,"(.-)".-(https.-)".-"title".-"(.-)"') do
			print(url)
       --  t['view'] = 'simple'
     --   t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        --.. '?x-nb='})
        end

        
         
			
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
      --  t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-,"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
    --    t['view'] = 'simple'
    --    t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        --.. '?x-nb='})
        end
        
        
       elseif args.q == 'play' then
       return video(args.url, args)

	end
	return t
end