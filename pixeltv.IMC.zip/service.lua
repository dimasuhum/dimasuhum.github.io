-- pixeltv plugin

require('support')
require('video')
require('parser')

--TV_URL = 'https://iptvx.one/epg/epg.xml.gz'

TV_URL = 'https://iptvx.one/epg/epg.xml.gz, http://epg.it999.ru/edem.xml.gz'

TV_ARCH = '{proto}://{host}{path}?utc={utc}&lutc={lutc}'
TV_ARCH_AGO = 4

PASS = '7777'

local lockpass


HOME = 'http://4k.pixel-tv.ru'


HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from pixeltv plugin')
	return 1
end

function onUnLoad()
	print('Bye from pixeltv plugin')
end

function onCreate(args)

if not args.q and args.keyword then
lockpass = args.keyword
end

if lockpass == PASS then
else
return {view="keyword",message="enter access code"}
end




	local t = {view = 'grid', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
--		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

	if not args.q then
	

		local genre = args.genre or '/?do=/fml&bid=391-playlist_m3u8'
		local url = HOME .. genre
		
			url = url 
	
		local x = http.getz(url)
         

		for  url, title, image in string.gmatch(x, '<a id=\'ch.-href=.-"(http.-m3u8)".->(.-)</a>.-background:url.-(http.-jpg)') do
          
          local meta = '#tv/url=' .. urlencode(TV_URL) .. '&name=' .. urlencode(title)
			table.insert(t, {title = title, mrl = url, group = group, meta = meta, arch = TV_ARCH, ago = TV_ARCH_AGO})


		end

	

	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end