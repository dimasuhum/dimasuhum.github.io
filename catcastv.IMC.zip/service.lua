-- Edem plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')

local fxml = onCreate



local HOME = 'https://api-web-systema.platform24.tv'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH





function onLoad()
	print('Hello from Edem plugin')
	return 1
end

function onUnLoad()
	print('Bye from Edem plugin')
end

function onCreate(args)




	local t = {view = 'large', type = 'folder'}
		t['menu'] = {}
	if args.q ~= 'genres' then
--		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end

--table.insert(t['menu'], {title = 'Поиск тв', mrl = '#folder/q=search', image = '#self/search.png'})

--https://varline.store/api/matchlist?is_complete=false&skip=0&limit=100


	if not args.q then


local page = tonumber(args.page or 1)


--https://raw.githubusercontent.com/dimasuhum/dimasuhum.github.io/refs/heads/master/24htv

--https://24htv.platform24.tv/v2/channels/629/stream?access_token=433b86f0a37ba04f1b92326033ea6691ca9c2c5e&format=json&preview=true



  local url = 'https://api.catcast.tv/api/channels?type=tv&online=true&sort_by=viewers'


if page > 1 then
			url = url .. '&page=' .. tostring(page)

end

--local url = 'https://raw.githubusercontent.com/Nikita34196/tv1/refs/heads/main/24h-tv.m3u8'
        local x = conn:load(url)

	
      x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
        x = string.gsub(x, '\\u0131', 'i')
        x = string.gsub(x, '\\u0130', 'i')
        x = string.gsub(x, '\\u00e8', 'e')
	        x = string.gsub(x, '\\u0406', 'i')

	
    for title, image, id in string.gmatch(x, '{"id":.-,"name":"(.-)","time":".-","background":.-,"logo":"http.-".-{"entity_id":.-"full_path":"(http.-)".-{"entity_id":(.-),') do

image  = string.gsub(image, '\\', '')


	
	table.insert(t, {title = title, mrl = '#stream/q=channel&id=' .. id, image = image})

end
--end
--end


local url = '#folder/page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
	
	
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
 


--https://api-web-systema.platform24.tv/v2/channels/category_list?access_token=3daf31124d35f6c5f1e7581ca0ad3f11d940a357&channels_version=2
 
  table.insert(t, {title = 'Эфирные', mrl = '#stream/q=channels', image = image})
 
 table.insert(t, {title = 'Плюсовые', mrl = '#stream/q=channels1', image = image})
 
 table.insert(t, {title = 'Инфомационные', mrl = '#stream/q=channels9', image = image})
 
table.insert(t, {title = 'Кино', mrl = '#stream/q=channels2', image = image})

table.insert(t, {title = 'Спорт', mrl = '#stream/q=channels3', image = image})

table.insert(t, {title = 'Познавательные', mrl = '#stream/q=channels4', image = image})

table.insert(t, {title = 'Развлекательные', mrl = '#stream/q=channels5', image = image})

table.insert(t, {title = 'Музыка', mrl = '#stream/q=channels6', image = image})

table.insert(t, {title = 'Детские', mrl = '#stream/q=channels7', image = image})

table.insert(t, {title = 'Семейные', mrl = '#stream/q=channels8', image = image})

table.insert(t, {title = 'Мужские', mrl = '#stream/q=channels10', image = image})

table.insert(t, {title = 'Женские', mrl = '#stream/q=channels11', image = image})

table.insert(t, {title = 'Хобби', mrl = '#stream/q=channels12', image = image})

table.insert(t, {title = 'Бывший СССР', mrl = '#stream/q=channels13', image = image})

table.insert(t, {title = 'Региональные', mrl = '#stream/q=channels14', image = image})

table.insert(t, {title = 'Эротические', mrl = '#stream/q=channels15', image = image})



  
  
  
  
  elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		
--https://api-web-systema.platform24.tv/v2/rows/1154861723526252842?offset=0&limit=50&channels_version=2&access_token=5dd5686b588774b7976cac5d14ebdab9dc573eed&text=Матч
     
    
    local headers = {
["Host"] = "api-web-systema.platform24.tv",
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0",
["Accept"] = "application/json, text/plain, */*",
["Accept-Language"] = "ru-ru",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-Type"] = "application/json",
["Content-Length"] = "52",
["Origin"] = "https://tv.cyxym.net",
["Connection"] = "keep-alive",
["Referer"] = "https://tv.cyxym.net/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "cross-site"
}

local params = '{"device_id":"c99fe352-7718-4879-b92a-c6e3f61c9ccd"}'


--https://1.mediamaniya.site/tv/?page6

--   local url = HOME .. '/v2/auth/device'

    --    local x = http.postz(url, headers, params)

   --   local token = string.match(x, '"access_token":"(.-)"')

--	if token then
    
    
    
    
      	local url = ('https://api-web-systema.platform24.tv/v2/rows/1154861723526252842?offset=0&limit=50&channels_version=2&access_token=' .. args.id1 .. '&format=json&text=' .. urlencode(args.keyword))
	
		local x = conn:load(url)
  
  
 local channel = string.match(x,'"channels":%[(.-)]}')
  
  for id, name, slug, image in string.gmatch(channel,'{"id":(.-),"name":"(.-)","slug":"(.-)".-"cover".-"full":"(http.-)"') do
  
  table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. id .. '&id1=' .. args.id1, image = image})
  
  end
--end  
  
  
    elseif args.q == 'channels' then

--group-title="Эфирные" tvg-logo

  local url = 'https://raw.githubusercontent.com/dimasuhum/dimasuhum.github.io/refs/heads/master/24htv'

        local x = conn:load(url)

	
    for image, name, id in string.gmatch(x, '#EXTINF:.-group%-title="Эфирные".-tvg%-logo="(.-)",(.-)http.-/ch(.-)/.-m3u8') do

--local x = conn:load('https://24htv.platform24.tv/v2/channels/' .. id .. '/stream?access_token=433b86f0a37ba04f1b92326033ea6691ca9c2c5e&force_https=true&format=json&preview=true')
 

 -- local url = string.match(x,'"hls":"(.-)"')   
--  if url then
   
    --   t['view'] = 'simple'
	
--	table.insert(t, {title = name, mrl = url, image = image})
	
	table.insert(t, {title = name, mrl = '#stream/q=channel&id=' .. id, image = image})

end








elseif args.q == 'channel' then

--https://api-web-systema.platform24.tv/v2/channels/3963/stream?access_token=c80427ce3c71e33267d212856c5e6650934291d7&force_https=true&format=json&preview=true



     local x = conn:load('https://api.catcast.tv/api/channels/' .. args.id .. '/getcurrentprogram')
 
 x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
        x = string.gsub(x, '\\u0131', 'i')
        x = string.gsub(x, '\\u0130', 'i')
        x = string.gsub(x, '\\u00e8', 'e')
	        x = string.gsub(x, '\\u0406', 'i')
	        
	        
-- table.insert(t, {title = 'https://api-web-systema.platform24.tv/v2/channels/' .. args.id .. '/stream?access_token=' .. args.id1 .. '&force_https=true&preview=true', mrl = '#stream/q=channel&id=' .. 'https://api-web-systema.platform24.tv/v2/channels/' .. args.id .. '/stream?access_token=' .. args.id1 .. '&force_https=true&format=json&preview=true', image = image})


-- "full_mobile_url":"https://autopilot.catcast.tv/mobile.m3u8?channel_id=37532&token=50e95a57da2a830cd33c807ed707cf2e&server=v2.catcast.tv"
 
 
-- local x = json.decode(x)
 
 local title, url = string.match(x,'"program_name":"(.-)".-"full_mobile_url":"(.-)"')   
  if url then
  
  url  = string.gsub(url, '\\', '')

--table.insert(t, {title = url, mrl = '#stream/q=channel&id=' .. url, image = image})


  --    if url2 then
--    print(url2)
    return {view = 'playback', title = title, mrl = url, seekable = 'true', direct = 'true'}
    
end




	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)
--end
	end
	return t
end