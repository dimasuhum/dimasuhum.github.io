-- KINO-HORROR plugin

require('support')
require('video')
require('parser')

HOME = 'https://film-uzhasov.ru'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kino-horror plugin')
	return 1
end

function onUnLoad()
	print('Bye from kino-horror plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
--	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2


	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/2022'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page-' .. tostring(page)
		end
        local x = http.getz(url)
		
		for url, image, title in string.gmatch(x, '<li class="kinofilm%-item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
			image = string.gsub(image, '^(.-)', HOME)
			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    
    
       for url, image, title in string.gmatch(x, '<div class="kinofilm%-item%-best".-<a href="(.-)".-<img src="(.-.jpg)".-class="kino_name%-best".-<a href.->(.-)</a>') do
			image = string.gsub(image, '^(.-)', HOME)
			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    
    
          
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		

		table.insert(t, {title = 'Лучшее за 10 лет', mrl = '#stream/genre=' .. '/best'})
        local x = http.getz(HOME)
		local x = string.match(x, '<div class="left%-col">(.-)<div class="footer"')
		for genre, title in string.gmatch(x,'<a href="(/.-)".-<span>(.-)</span>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
   
   
   
   
   
   
   
   
         
	-- #stream/q=content&id=/toksichnyj-mstitel
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<span id="opisanie_filma".-<p>(.-)<div class="ads%-bottom"')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
	--	t['annotation'] = parse_array(x, {
		--	'(Страна:</span>.-)</p>', '(Режиссер:</span>(.-)</p>', '(В ролях:</span>.-)</p>', 
	--	})

      
		for url in string.gmatch(x, '<iframe.-src="(https://www.youtube.-)"') do

			table.insert(t, {title = 'Трейлер', mrl = url})
		end


--https://kinovibe.co/embed/kinopoisk/386/
--https://svd3.kvb.cool/video_mp4/trailer/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVgTHF7bgtxWA::/DomovenokKuzya2024::/720.mp4
	
--https://svd13.kvb.cool/video_mp4/films/1979/Alien/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVgTHF7bwB2VA::/Alien1979_720.mp4
	
	
       for url in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
          print(url)
          

         url = string.gsub(url, '^(.-)', 'https://kinovibe.co/embed/kinopoisk/') .. '/'
	
   -- 	table.insert(t, {title = 'kinovide плеер', mrl = '#stream/q=content&id=' .. url})

   --    end

        local x =  http.getz(url)

	
       for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end
	 end
		
          for url in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
          print(url)
          


         url = string.gsub(url, '^(.-)', 'http://hidxlglk.deploy.cx/lite/zetflix?kinopoisk_id=')



       table.insert(t, {title = 'zetflix плеер', mrl = '#stream/q=content&id=' .. url})

       end
        

for  total in string.gmatch(x, '<div class="videos__item videos__movie.-"play".-"url".-hidxlglk.-class="videos__item%-title">(.-)</div>') do
  
  
     local x = string.match(x, '"quality"(.-)"translate"')
      
      
   
   for  total1, url2 in string.gmatch(x, '"(.-p)":"http.-(/proxy.-m3u8)"') do
      
      url2 = string.gsub(url2, '^(.-)', 'http://hidxlglk.deploy.cx')

      
      
      
       t['view'] = 'simple'

    table.insert(t, {title = 'zetflix' .. ':'.. tolazy(total) .. '(' .. total1 .. ')', mrl = url2})

     end 
    end
    
    
 --   local x = conn:load(url1)
        for url2, url3, total1  in string.gmatch(x, '"method":"link".-"url":"(http.-zetflix)(.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do


      local x = http.getz(url2 .. url3)

      for url4, total2  in string.gmatch(x, '<div class="videos__button.-"method":"link".-"url":"(http.-)".->(.-)</div>') do

     local x = http.getz(url4)


      for url4, total3  in string.gmatch(x, '"method":"play".-"url":"(http.-m3u8)".-class="videos__item%-title">(.-серия)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
    
      t['view'] = 'simple'

    table.insert(t, {title = 'zetflix :' .. total1 .. ' '  .. total3 .. tolazy(total2), mrl = url4})

       
    end

end
end



--https://kinobadi.bid
        
         for url in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
        
        url = string.gsub(url, '^(.-)', 'https://kinobadi.bid/hd_pars/pleer_on.php?url&kp=')
	
         table.insert(t, {title = 'Vibix', mrl = '#stream/q=content&id=' .. url})
    
	
	    end
	--   end
	
	--	local x = http.getz(url)
	
		for url  in string.gmatch(x, '<iframe.-src="(/pleer.-)"') do
	
		url = string.gsub(url, '^(.-)', 'https://kinobadi.bid')
 
    --	table.insert(t, {title = 'Vibix', mrl = '#stream/q=content&id=' .. url})
    
    --	end
	--	end
		
        
	    
		local x = http.getz(url)


        for title in string.gmatch(x, '"title":"(.-)"') do


        local x = string.match(x, '"file":(.-)}')


		
		
         for total, url  in string.gmatch(x, '%[(.-)](http.-mp4)') do
		t['view'] = 'simple'
        table.insert(t, {title = title .. ' ' .. (total), mrl = url})
        end
        end
	end
--	end
	
	
		
        
                
        
        for title in string.gmatch(x, '<h1.->(.-)</h1>') do

        title=http.urlencode(title)

         title = string.gsub(title, '+', '%%20')
    
    
          url = string.gsub(title, '^(.-)', 'http://stvplay.mooo.com:81/vk/vk.php?search=')
    
     --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
    
     --   end
   
       local x = http.getz(url)
       
   for url, total in string.gmatch(x, '</channel.-<channel.-playlist_url>.-(http.-)].-description>.-<h3>(.-)</h3>') do

 --    table.insert(t, {title = title, mrl = '#stream/q=content&id=' .. url})
    
      --  end
 --  end
       local x = http.getz(url)
   
        for total1, url in string.gmatch(x, '<title>.-(1080p).-<stream_url>.-(https.-)]') do
   
      table.insert(t, {title = total1 ..  ' ' ..  total, mrl = url})
    
        end
   end
   end
        
        
        
          
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	     return video(args.url, args)

	end
	return t
end