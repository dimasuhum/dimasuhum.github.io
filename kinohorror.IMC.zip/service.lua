-- KINO-HORROR plugin

require('support')
require('video')
require('parser')

HOME = 'https://film-uzhasov.ru'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kino-horror plugin')
	return 1
end

function onUnLoad()
	print('Bye from kino-horror plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
--	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2


	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/2022'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page-' .. tostring(page)
		end
        local x = http.getz(url)
		
		for url, image, title in string.gmatch(x, '<li class="kinofilm%-item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
			image = string.gsub(image, '^(.-)', HOME)
			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
          
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
        local x = http.getz(HOME)
		local x = string.match(x, '<div class="left%-col">(.-)<div class="footer"')
		for genre, title in string.gmatch(x,'<a href="(/.-)".-<span>(.-)</span>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
   
   
   
   
   
   
   
   
         
	-- #stream/q=content&id=/toksichnyj-mstitel
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<span id="opisanie_filma".-<p>(.-)<div class="ads%-bottom"')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
	--	t['annotation'] = parse_array(x, {
		--	'(Страна:</span>.-)</p>', '(Режиссер:</span>(.-)</p>', '(В ролях:</span>.-)</p>', 
	--	})

      
		for url in string.gmatch(x, '<iframe.-src="(https://www.youtube.-)"') do

			table.insert(t, {title = 'Трейлер', mrl = url})
		end
		
          for url in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
          print(url)
		 url = string.gsub(url, '^(.-)', 'http://79.137.204.8:9118/lite/zetflix?id=0&kinopoisk_id=')

	--		table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url})
	--	end
      
      local x =  http.getz(url)
       
       
    --   for url in string.gmatch(x, '"method":"link".-"url":"(.-)"') do
         --   t['view'] = 'simple'
			--	table.insert(t,{title = 'Смотреть сериал',mrl = '#stream/q=content&id=' .. url})
			
      -- end
       
       
       for title, total, url in string.gmatch(x, '"title":"(.-)".-(1080p).-(http.-mp4)') do
         --   t['view'] = 'simple'
				table.insert(t,{title=tolazy(total) .. tolazy(title),mrl= url})
			end
      for title, total, url in string.gmatch(x, '"title":"(.-)".-(720p).-(http.-mp4)') do
         --   t['view'] = 'simple'
				table.insert(t,{title=tolazy(total) .. tolazy(title),mrl= url})
			end
      for title, total, url in string.gmatch(x, '"title":"(.-)".-(480p).-(http.-mp4)') do
        --    t['view'] = 'simple'
				table.insert(t,{title=tolazy(total) .. tolazy(title),mrl= url})
			end
      for title, total, url in string.gmatch(x, '"title":"(.-)".-(360p).-(http.-mp4)') do
       --     t['view'] = 'simple'
				table.insert(t,{title=tolazy(total) .. tolazy(title),mrl= url})
			end
end

          
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	     return video(args.url, args)

	end
	return t
end