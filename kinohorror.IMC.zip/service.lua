-- KINO-HORROR plugin

require('support')
require('video')
require('parser')

HOME = 'https://film-uzhasov.ru'
HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kino-horror plugin')
	return 1
end

function onUnLoad()
	print('Bye from kino-horror plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
--	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2


	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/2022'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page-' .. tostring(page)
		end
        local x = http.getz(url)
		
		for url, image, title in string.gmatch(x, '<li class="kinofilm%-item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
			image = string.gsub(image, '^(.-)', HOME)
			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    
    
       for url, image, title in string.gmatch(x, '<div class="kinofilm%-item%-best".-<a href="(.-)".-<img src="(.-.jpg)".-class="kino_name%-best".-<a href.->(.-)</a>') do
			image = string.gsub(image, '^(.-)', HOME)
			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    
    
          
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		

		table.insert(t, {title = 'Лучшее за 10 лет', mrl = '#stream/genre=' .. '/best'})
        local x = http.getz(HOME)
		local x = string.match(x, '<div class="left%-col">(.-)<div class="footer"')
		for genre, title in string.gmatch(x,'<a href="(/.-)".-<span>(.-)</span>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
   
   
   
   
   
   
   
   
         
	-- #stream/q=content&id=/toksichnyj-mstitel
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<span id="opisanie_filma".-<p>(.-)<div class="ads%-bottom"')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
	--	t['annotation'] = parse_array(x, {
		--	'(Страна:</span>.-)</p>', '(Режиссер:</span>(.-)</p>', '(В ролях:</span>.-)</p>', 
	--	})

      
		for url in string.gmatch(x, '<iframe.-src="(https://www.youtube.-)"') do

			table.insert(t, {title = 'Трейлер', mrl = url})
		end


--https://kinovibe.co/embed/kinopoisk/386/
--https://svd3.kvb.cool/video_mp4/trailer/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVgTHF7bgtxWA::/DomovenokKuzya2024::/720.mp4
	
--https://svd13.kvb.cool/video_mp4/films/1979/Alien/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVgTHF7bwB2VA::/Alien1979_720.mp4
	
	
       for url in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
          print(url)
          

         url = string.gsub(url, '^(.-)', 'https://kinovibe.co/embed/kinopoisk/') .. '/'
	
   -- 	table.insert(t, {title = 'kinovide плеер', mrl = '#stream/q=content&id=' .. url})

   --    end

        local x =  http.getz(url)

	
       for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end
	 end
		
          for url in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
          print(url)
          


         url = string.gsub(url, '^(.-)', 'http://178.20.46.40:12600/lite/hdvb?kinopoisk_id=')



       table.insert(t, {title = 'Hdvb', mrl = '#stream/q=content&id=' .. url})

       end
        

      
      for  url2, total2 in string.gmatch(x, '"method":"call".-"url":"http.-(/lite.-)".-class="videos__item%-title">(.-)</div>') do
  
      url2 = string.gsub(url2, '\\u0026', '&')
   url2 = string.gsub(url2, '\\u002B', '+')
   
      local x = http.get('http://178.20.46.40:12600' .. url2)

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/360/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '360p ' .. tolazy(total2), mrl = url4})

end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/480/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '480p ' .. tolazy(total2), mrl = url4})
end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/720/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '720p ' .. tolazy(total2), mrl = url4})
end

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
      t['view'] = 'simple'

    table.insert(t, {title = '1080p ' .. tolazy(total2), mrl = url4})

      end 
   
      end
      

      
 
     for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url2 = string.gsub(url2, '\\u0026', '&')
url2 = string.gsub(url2, '\\u002B', '+')


     local x = http.get('http://178.20.46.40:12600' .. url2)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     
     local x = http.get('http://178.20.46.40:12600' .. url4)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"http.-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do




     url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
    
       t['view'] = 'simple'

    table.insert(t, {title = 'hdvb :'  .. total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = 'http://178.20.46.40:12600' .. url6})
    end
end
end




--https://kinobadi.bid
        
         for id in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
        
     --   url = string.gsub(url, '^(.-)', 'https://player0.flixcdn.space/show/kinopoisk/') .. '?domain=piratka.tv'
	
         table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id=' .. id})
    
	
	    end

      elseif args.q == 'flixcdn' then
      
local x = http.get('https://player0.flixcdn.space/show/kinopoisk/' .. args.id .. '?domain=piratka.tv')



local slist = string.match(x, '<select name="translator"(.-)movies')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
         
local x = http.get('https://player0.flixcdn.space/show/kinopoisk/' .. args.id .. '?domain=piratka.tv&translation=' .. id5)



    local slist = string.match(x, 'file.-:(.-)CDNquality')

    if slist then
 
 for title1, url in string.gmatch(slist, '%[(.-)](http.-m3u8)') do

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   end
end
 end



 
local x = http.get('https://player0.flixcdn.space/show/kinopoisk/' .. args.id .. '?domain=piratka.tv&autoplay=1&extrans=1')



local slist = string.match(x, '<select name="season"(.-)</select>')
  
      if slist then
                                             for id2, title1 in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
                                    

  local slist = string.match(x, '<select name="episode"(.-)</select>')
  
      if slist then
                                            for id4, title2 in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do





  local slist = string.match(x, '<select name="translator"(.-)series')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
 id5 = string.gsub(id5, '^(.-)', 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id .. '?domain=piratka.tv&autoplay=1&extrans=1&translation=') 
 
 

    t['view'] = 'simple'

   table.insert(t, {title = title1 .. ' ' .. title2 .. ' ' .. title, mrl = '#stream/q=flixcdns&id=' .. args.id .. '&id5=' .. id5 .. '&id1=' .. title .. '&id2=' .. id2 .. '&id4=' .. id4})

  end
   end
   end
   end
    end
 end
   
   
    
    elseif args.q == 'flixcdns' then  
    
    local x = http.get(args.id5 .. '&season=' .. args.id2 .. '&episode=' .. args.id4)
    
      local slist = string.match(x, 'file.-:(.-)CDNquality')

    if slist then
 
 for title, url in string.gmatch(slist, '%[(.-)](http.-m3u8)') do

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
   end
      
      
      
      
      
      
        
        
          
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	     return video(args.url, args)

	end
	return t
end