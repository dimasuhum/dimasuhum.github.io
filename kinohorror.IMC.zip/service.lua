-- KINO-HORROR plugin

require('support')
require('video')
require('parser')
require('client')

HOME = 'https://film-uzhasov.ru'
HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH

function onLoad()
	print('Hello from kino-horror plugin')
	return 1
end

function onUnLoad()
	print('Bye from kino-horror plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
--	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2


	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/2022'
		local url = HOME .. genre
		if page > 1 then
			url = url .. '/page-' .. tostring(page)
		end
        local x = http.getz(url)
		
		for url, image, title in string.gmatch(x, '<li class="kinofilm%-item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
			image = string.gsub(image, '^(.-)', HOME)
			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    
    
       for url, image, title in string.gmatch(x, '<div class="kinofilm%-item%-best".-<a href="(.-)".-<img src="(.-.jpg)".-class="kino_name%-best".-<a href.->(.-)</a>') do
			image = string.gsub(image, '^(.-)', HOME)
			url = string.gsub(url, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
    
    
          
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		

		table.insert(t, {title = 'Лучшее за 10 лет', mrl = '#stream/genre=' .. '/best'})
        local x = http.getz(HOME)
		local x = string.match(x, '<div class="left%-col">(.-)<div class="footer"')
		for genre, title in string.gmatch(x,'<a href="(/.-)".-<span>(.-)</span>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end
   
   
   
   
   
   
   
   
         
	-- #stream/q=content&id=/toksichnyj-mstitel
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
		--print(x)
	--	t['ref'] = args.id
		t['name'] = parse_match(x,'<h1.->(.-)</h1>')
		t['description'] = parse_match(x,'<span id="opisanie_filma".-<p>(.-)<div class="ads%-bottom"')
        t['poster'] = args.p
		--t['poster'] = parse_match(x,'<div class="m%-img".-img src="(.-)"')
		--if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		--end
	--	t['annotation'] = parse_array(x, {
		--	'(Страна:</span>.-)</p>', '(Режиссер:</span>(.-)</p>', '(В ролях:</span>.-)</p>', 
	--	})

      
		for url in string.gmatch(x, '<iframe.-src="(https://www.youtube.-)"') do

			table.insert(t, {title = 'Трейлер', mrl = url})
		end


--https://kinovibe.co/embed/kinopoisk/386/
--https://svd3.kvb.cool/video_mp4/trailer/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVgTHF7bgtxWA::/DomovenokKuzya2024::/720.mp4
	
--https://svd13.kvb.cool/video_mp4/films/1979/Alien/Y1xjV3ZsaHh2OBo3ECwxD3cdJToEAxUR_YkVgTHF7bwB2VA::/Alien1979_720.mp4
	
	
       for url in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
          print(url)
          

         url = string.gsub(url, '^(.-)', 'https://kinovibe.co/embed/kinopoisk/') .. '/'
	
   -- 	table.insert(t, {title = 'kinovide плеер', mrl = '#stream/q=content&id=' .. url})

   --    end

        local x =  http.getz(url)

	
       for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-(https://s.-.mp4)"') do
         -- print(url) 
          table.insert(t, {title = '480p', mrl = url})
		end
        for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:"(https://s.-mp4),') do
         -- print(url) 
     --    t['view'] = 'grid'
          table.insert(t, {title = '480p', mrl = url})
		end
     	for url in string.gmatch(x, 'var mainPlayer = new Playerjs.-file:.-mp4.-(https://s.-.mp4)"') do
         -- print(url)
      --    t['view'] = 'grid'
          table.insert(t, {title = '720p', mrl = url})
		end
	 end
		
          for id3 in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
          print(url)
          


     --    url = string.gsub(url, '^(.-)', 'http://178.20.46.40:12600/lite/hdvb?kinopoisk_id=')



       table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvb&id3=' .. id3})

       end
        

      
      
        
     --    for id in string.gmatch(x, '<p class="source".-<a href="https://www.kinopoisk.ru/film/(.-)/"') do
        
     --   url = string.gsub(url, '^(.-)', 'https://player0.flixcdn.space/show/kinopoisk/') .. '?domain=piratka.tv'
	
    --     table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id=' .. id})
    
	
	--    end

      



  elseif args.q == 'flixcdn' then

 
-- https://cdn0.cdnhub.help/show/kinopoisk/386?domain=piratka.tv
 
 
          local x = http.get('https://player0.flixcdn.space/show/kinopoisk/' .. args.id .. '?domain=nginx.cis-bel-back.orb.local')

--local x = conn:load('https://cdn0.cdnhub.help/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv')

local slist = string.match(x, '<select name="translator"(.-)movies')
 
 
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
         
         local x = http.get('https://player0.flixcdn.space/show/kinopoisk/' .. args.id .. '?domain=nginx.cis-bel-back.orb.local&translation=' .. id5)


 


  --  local slist = string.match(x, 'charset(.-)window.PlayerjsEvents')



    if x then
 
 for title1, url in string.gmatch(x, '%[(240)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
   
   for title1, url in string.gmatch(x, '%[(360)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
  
for title1, url in string.gmatch(x, '%[(480)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
   
for title1, url in string.gmatch(x, '%[(720)](http.-m3u8)') do

url = string.gsub(url, '/480.mp4', '/720.mp4') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   
for title1, url in string.gmatch(x, '%[(1080)](http.-m3u8)') do

url = string.gsub(url, '/480.mp4', '/1080.mp4') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   
   
   end
end
 end



 
          local x = http.get('https://player0.flixcdn.space/show/kinopoisk/' .. args.id .. '?domain=nginx.cis-bel-back.orb.local&autoplay=1&extrans=1')



local slist = string.match(x, '<select name="season"(.-)</select>')
  
      if slist then
                                             for id2, title1 in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
                                    

  local slist = string.match(x, '<select name="episode"(.-)</select>')
  
      if slist then
                                            for id4, title2 in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do





  local slist = string.match(x, '<select name="translator"(.-)series')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
 id5 = string.gsub(id5, '^(.-)', 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id .. '?domain=nginx.cis-bel-back.orb.local&autoplay=1&extrans=1&translation=') 
 
 

    t['view'] = 'simple'

   table.insert(t, {title = title1 .. ' ' .. title2 .. ' ' .. title, mrl = '#stream/q=flixcdns&id3=' .. args.id3 .. '&id5=' .. id5 .. '&id1=' .. title .. '&id2=' .. id2 .. '&id4=' .. id4})

  end
   end
   end
   end
    end
 end
   
   
    
    elseif args.q == 'flixcdns' then  
    
    local x = http.get(args.id5 .. '&season=' .. args.id2 .. '&episode=' .. args.id4)
    
   --   local slist = string.match(x, 'file.-:(.-)CDNquality')

  --  if slist then
 
 
 for title, url in string.gmatch(x, '%[(240)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
 
 for title, url in string.gmatch(x, '%[(360)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
   
for title, url in string.gmatch(x, '%[(480)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end

for title, url in string.gmatch(x, '%[(720)](http.-m3u8)') do

url = string.gsub(url, '/480.mp4', '/720.mp4') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end

for title, url in string.gmatch(x, '%[(1080)](http.-m3u8)') do

url = string.gsub(url, '/480.mp4', '/1080.mp4') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
      
      
elseif args.q == 'hdvb' then
      
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

      for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"http.-(vid.-)(/movie.-)"') do
      
      
if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)


local id, key = string.match(x, '"file":"%~(.-)".-"key":"(.-)"')

local href = string.match(x, '"href":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'



local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)

         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. title, mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. title, mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. title, mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. title, mrl = url3})

       end
       end
 end
 end
     
    
    
    
    
    
     
     local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
     
    -- table.insert(t, {title = 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3, mrl = '#stream/q=hdvbs&id1=' .. 'https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3})
     
     
x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

     
     
     
  --   table.insert(t, {title = url, mrl = '#stream/q=hdvbs&id1=' .. url})
     
   
    --  for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') do
      
      local origin, url = string.match(x, '"type":"serial".-"iframe_url":"http.-(vid.-)(/serial.-)"') 

if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

 
      url = string.gsub(url, '^(.-)', 'https://' .. origin)

local headers = {
    ["Host"] = origin,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=177873309816283985; _ym_d=1778733098; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)

x = string.gsub(x, '\\', '')

local id, key = string.match(x, '"file":"(.-)".-"key":"(.-)"')

if id then
if key then


local href = string.match(x, '"href":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.' .. href)

local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. origin,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. origin .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')







for id1, text in string.gmatch(x, '"file":"%~(.-)".-"text2":"(.-)"') do

--local text = string.match(x, '"file".-"text2":"(.-)"')


id1 = string.gsub(id1, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'


local x = http.postz(id1, headers1)



for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. text, mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. text, mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. text, mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. text, mrl = url3})

       end
     
end
     
end
end
end
end
      
   
   
   
   elseif args.q == 'hdvbf' then
      
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

      for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"http.-(vid.-)(/movie.-)"') do
      
if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

-- https://lam.maxvol.pro/proxy/5ae371e16655f3ef2bae8d4a28d56b8d.m3u8

-- http://78.40.195.218:9118/lite/hdvb/serial?iframe=https%3a%2f%2fvid1733431681.entouaedon.com%2fserial%2f4e6eb80724f81b2fc89bf9c3f8507021e1f9a9dba4c9d493288c81a9f86943a3%2fiframe&t=BaibaKo&s=1&e=1
 
      url = string.gsub(url, '^(.-)', 'https://lam.maxvol.pro/lite/hdvb/video?iframe=' .. 'https://' .. origin)

--table.insert(t, {title = url, mrl = url})

local x = http.getz(url)


x = string.gsub(x, '\\', '')


local url2 = string.match(x,'method.-"play".-"url":"http.-(/proxy.-m3u8)"')
   
 
  
   local x = conn:load('https://lam.maxvol.pro' .. url2)

 
   x = string.gsub(x, '\\', '')
   

 
         for url3 in string.gmatch(x, 'RESOLUTION.-640.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. title, mrl = url3})

       end
       
         for url3 in string.gmatch(x, 'RESOLUTION.-858.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. title, mrl = url3})

      
       end
        for url3 in string.gmatch(x, 'RESOLUTION.-1280.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
		 
t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. title, mrl = url3})


       end
       
for url3 in string.gmatch(x, 'RESOLUTION.-1920.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. title, mrl = url3})


       end
       end
     
  end
  end
    
    
    
    
    
     
     local x = conn:load('http://78.40.195.218:9118/lite/hdvb?kinopoisk_id=' .. args.id3)
     
     
  --   table.insert(t, {title = url, mrl = '#stream/q=hdvbs&id1=' .. url})
     
  -- table.insert(t, {title = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3, mrl = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3})


for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url2 = string.gsub(url2, '\\u0026', '&')
url2 = string.gsub(url2, '\\u002B', '+')


     local x = conn:load('http://78.40.195.218:9118' .. url2)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     
     local x = conn:load('http://78.40.195.218:9118' .. url4)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"http.-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do




     url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
    
       t['view'] = 'simple'

    table.insert(t, {title = total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = 'http://78.40.195.218:9118' .. url6})
    end
end
end



     
        
          
	elseif args.q == 'play' then
        
       --return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	     return video(args.url, args)

	end
	return t
end