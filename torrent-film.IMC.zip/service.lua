-- filmhd.newmulti-torrent.ru plugin

require('support')
require('video')
require('parser')
--require('magnet')
--require('url')


HOME = 'https://torrent-film.online'



HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from filmhd.newmulti-torrent.ru plugin')
	return 1
end

function onUnLoad()
	print('Bye from filmhd.newmulti-torrent.ru plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=20
	-- #stream/genre=/forum/portal.php?c=11&start=


	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/zarubezhnyye-filmy/'


		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' ..  tostring(page) .. '/'
		end 

        local x = http.get(url)

       for image, url, title  in string.gmatch(x, '<div class="movie%-img img%-box".-<img src="(.-)".-class="movie%-title" href="(.-)">(.-)</a>') do
         
        image = string.gsub(image, '^(.-)', HOME)

        
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	

	
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
    elseif args.q == 'genres' then
		t['view']='simple'
		t['message']='@string/genres'
	
        local x = http.getz(HOME)
   
    	x = string.match(x, '<nav class="nav".->(.-)</nav>')
        for genre, title in string.gmatch(x,'<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end


   
    --   for title, genre in string.gmatch(x,'<channel.-<title.-%[CDATA%[(.-)].-<playlist_url.-%[CDATA%[http.-php(.-)]') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
	--	end

--template="https://torrent-film.online/index.php?story=Рокки&do=search&subaction=search"
   
   
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)

        local x = http.getz(url)
		
		
        for url, image, title  in string.gmatch(x, '<a class="sres%-wrap clearfix" href="(.-)".-<img src="(.-)" alt="(.-)"') do
         
        image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
   
   
   
   
   
    	
	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
    --    x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
        t['name'] = parse_match(x,'<h1.-><a class="maintitle".->(.-)</a>')
		t['description'] = parse_match(x, '<div class="m%-desc full%-text clearfix">(.-)</div>')
			t['poster'] = args.p
	    	t['annotation'] = parse_array(x, {'(Страна:</div>.-)</div>', '(Год выхода:</div>.-)</div>',
			'(Жанр:</div>.-)</div>',
			'(Режиссер</b>:.-)<br/>',
			'(В ролях:</div>.-)</div>',})
			
	
      for title in string.gmatch(x, '<a href="magnet.-btih:(.-)&') do
  
     
     title = string.lower(title)
      
     url = string.gsub(title, '^(.-)', 'https://ts.moviecorn.one/stream/file.m3u?link=') .. '&m3u'
   

  --  t['view']='simple'
  
   --    table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
      
   --   end
  --  table.insert(t, {title = title, mrl = url})
        
    
       local x = http.get(url)
   
    
      for title, url  in string.gmatch(x, 'EXTINF:.-,(.-)(http.-play)') do
    
     	table.insert(t, {title = title, mrl = url .. '&hitid='})

         end
        end
         
         
	elseif args.q == 'url' then
       -- return {view = 'open with', label = args.t, mrl = url, seekable = 'true', direct = 'true'}  
       return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
	--	return video(args.url, args)
	end
	return t
end
    