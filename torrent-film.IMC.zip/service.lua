-- filmhd.newmulti-torrent.ru plugin

require('support')
require('video')
require('parser')
--require('magnet')
--require('url')
require('client')



local HOME = 'https://torrent-film.online'
local HOME_SLASH = HOME .. '/'

local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH



--HOME = 'https://torrent-film.online'



--HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from filmhd.newmulti-torrent.ru plugin')
	return 1
end

function onUnLoad()
	print('Bye from filmhd.newmulti-torrent.ru plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=20
	-- #stream/genre=/forum/portal.php?c=11&start=


	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/'


		local url = HOME .. genre
		if page > 1 then
			url = url .. 'page/' ..  tostring(page) .. '/'
		end 

     --   local x = http.get(url)

  
       local x = conn:load(url)

  
       for url, image, title  in string.gmatch(x, '<a class="poster grid%-item.-href="(.-)".-<img src="(/uploads.-)".-alt="(.-)"') do
         
        image = string.gsub(image, '^(.-)', HOME)

        
		table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
	

	
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
    elseif args.q == 'genres' then
		t['view']='simple'
		t['message']='@string/genres'
	
     --   local x = http.getz(HOME)
        local x = conn:load(HOME)
    	x = string.match(x, '<ul class="side%-block__content side%-block__menu">(.-)</ul>')
        for genre, title in string.gmatch(x,'<a href="(.-)">(.-)</a>') do
			table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
		end


   
    --   for title, genre in string.gmatch(x,'<channel.-<title.-%[CDATA%[(.-)].-<playlist_url.-%[CDATA%[http.-php(.-)]') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre})
	--	end

--template="https://torrent-film.online/index.php?story=Рокки&do=search&subaction=search"
   
   
     elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
		local page = tonumber(args.page or '1')
		local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
		--.. tostring(page)

     --   local x = http.getz(url)
		
        local x = conn:load(url)
        for url, image, title  in string.gmatch(x, '<a class="poster grid%-item.-href="(.-)".-<img src="(/uploads.-)".-alt="(.-)"') do
         
        image = string.gsub(image, '^(.-)', HOME)
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		
		end
    	local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
   
   
   
   
   
    	
	-- #stream/q=content&id=/6128-trolli-mirovoy-tur-2020-smotret-multfilm-onlayn.html

	elseif args.q == 'content' then
		t['view'] = 'annotation'

         local x = conn:load(args.id)
	--	local x = http.getz(args.id)
    --    x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
        t['name'] = parse_match(x,'<h1.-><a class="maintitle".->(.-)</a>')
		t['description'] = parse_match(x, '<div class="page__text full%-text clearfix">(.-%.).-</div>')
			t['poster'] = args.p
	    	t['annotation'] = parse_array(x, {'<div class="pmovie__year">(.-)</div>', '(Год выхода:</div>.-)</div>',
			'(Жанр:</span>.-)</li>',
			'(Режиссер</b>:.-)<br/>',
			'(Актеры:</span>.-)</li>',})



	
      for total in string.gmatch(x, '<a href="magnet:?.-:btih:(.-)"') do
  
     
     total = string.lower(total)
       url = string.gsub(total, '^(.-)','https://lam.akter-black.com/ts/stream?link=') .. '&m3u'
      

        local x = http.get(url)

  
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.avi).-avi%?link=(.-)&play') do
     --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
        end
   
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mkv).-mkv%?link=(.-)&play') do
     --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
    
       end
    
       for total1, url  in string.gmatch(x, 'EXTINF:.-,(.-.mp4).-mp4%?link=(.-)&play') do
     --    t['view'] = 'grid'
      
     table.insert(t, {title = total1, mrl = 'https://stream.moviecorn.one/play?hash=' .. url, image = 'https://yt3.googleusercontent.com/-iljYWNiW0cL-j4hC0nuqUg9znK4uyf05tD0E-LslZK1fJof2NYK33TWBd0PgEduta-hIBkc8_c=s900-c-k-c0x00ffffff-no-rj'})
   
      end  
	end
         
         
	elseif args.q == 'url' then
       -- return {view = 'open with', label = args.t, mrl = url, seekable = 'true', direct = 'true'}  
       return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'} 
	--	return video(args.url, args)
	end
	return t
end
    