-- Octopus plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')




local fxml = onCreate
--src="//bigpkcqnm.tevas.tech/kino/download/top/Voron_fhd_2024.mp4

--https://my.ultradox.fun/42643-bespredelnye-puteshestviya-vo-vremeni-2023.html


--https://bigpkcqnm.tevas.tech/kino/download/Bespredelnye_puteshestvija_vo_vremeny_2023.mp4

--https://tevas.tv/kino/download/?f=Bespredelnye_puteshestviya_vo_vremeni_2023.mp4&sea=268962182929&big=885

--https://tevas.tv/kino/download/?f=Poltergejst_drugoe_izmerenie_2024.mp4


--https://my.ultradox.fun/42889-poltergeyst-drugoe-izmerenie-2023.html

--https://bigpkcqnm.tevas.tech/kino/download/Zaklyate_slugy_satany_fhd_2017.mp4

--https://tevas.tv/serial/zhizn_po_vyzovu/01_1080/?f=tevas_zhizn_po_vyzovu_fhd_01_05.mp4&big=885

--https://tevas.tv/kino/download/?f=Ubijstvennaya_zhara_2024.mp4


--<meta property="og:image" content="https://www.kinopoisk.ru/rating/846892/.gif" /


--<meta property="og:image" content="https://www.kinopoisk.ru/rating/1112513.gif

--https://api.tobaco.ws/embed/kp/846892

--https://my.ultradox.fun/42962-ubiystvennaya-zhara-2024.html

--https://tevas.tv/serial/top/vlastelin_kolec_kolca_vlasti/01/?f=tevas_vlastelin_kolec_kolca_vlasti_01_01.mp4&big=884


--https://bigpkcqnm.tevas.tech/kino/download/vlastelin_kolec_kolca_vlasti_1_1.mp4


--https://my.ultradox.fun/42330-vlastelin-kolec-kolca-vlasti-2-sezon.html


local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'

local HOME = 'https://1.ultadox.studio'
--local HOME = 'https://ultradox.today'
local HOME_SLASH = HOME .. '/'

local conn1 = client.new()
conn1['encoding'] = 'windows-1251'
local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH
conn1['root'] = HOME_SLASH



--HOME = 'http://my.ultradox.press'

--HOME_SLASH = HOME .. '/'
--windows-1251

function onLoad()
	print('Hello from octopusfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from octopusfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/page=/nerufilm/	
	-- #stream/genre=/hd/
	-- #stream/genre=/webrips/
	-- #stream/genre=/camrip/
    -- #stream/url=/serial/
	-- #stream/url=/rufilm/
	-- #stream/url=/hd/
	if not args.q then
		local page = tonumber(args.page or 1)
		local genre = args.genre or '/nerufilm/hd/'
		local url = HOME .. genre
		--local url1 = HOME1 .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
			--url1 = url1 .. '/page/' .. tostring(page) .. '/'
		end
        
	--	local x = http.getz(url)
       local x = conn:load(url)
    --   x = iconv(x, 'windows-1251', 'utf-8')
       

       
		for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-src=.-(/uploads/.-)".-<span>(.-)</span>') do
	
          image = string.gsub(image, '^(.-)', HOME)
            if image and not string.find(image, '://') then
				image = HOME .. image
			end
	
	--		image = string.gsub(image, '^(.-)', 'http://ultradox.asia')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
		
		--local x = http.getz(url1)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
		--	image = string.gsub(image, '^/', HOME_SLASH1)
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x =  conn:load(HOME)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
	--	x = string.match(x, 'div class="top__menu_ul">(.-)</div>')
    --    for genre, title in string.gmatch(x,'<a href="(.-)">(.-)</a>') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. '/'})
	--	end
        table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serial/'})
        table.insert(t, {title = 'HDRIP / BDRIP', mrl = '#stream/genre=' .. '/nerufilm/hd/'})
        table.insert(t, {title = 'НАШЕ КИНО', mrl = '#stream/genre=' .. '/rufilm/'})
        table.insert(t, {title = 'CAMRIP / TS', mrl = '#stream/genre=' .. '/nerufilm/camrip/'})
        table.insert(t, {title = 'WEB-DL', mrl = '#stream/genre=' .. '/nerufilm/webrips/'})
        table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/anime/'})
        
    
    
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
    
    local page = tonumber(args.page or 1)

--https://1ultradox.ctudio/index.php?story=Чужой&do=search&subaction=search&page=2


--	local args.keyword =  conn1:load(args.id)
		
   local page = tonumber(args.page or '1')

       local url = HOME .. '/index.php?story=' .. args.keyword .. '&do=search&subaction=search'
--	local x =  conn1:load(args.id)
     local x = conn:load(url)
      --  x = iconv(x, 'windows-1251', 'utf-8')
		for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-src=.-(/uploads/.-jpg)".-<span>(.-)</span>') do
    
    	url = string.gsub(url, '^(.-)', HOME)
          image = string.gsub(image, '^(.-)', HOME)
            if image and not string.find(image, '://') then
				image = HOME .. image
			end
	
	--		image = string.gsub(image, '^(.-)', 'http://ultradox.asia')
			table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
		end
     
     
     
     
     local url = '#folder/q=search&keyword=' .. args.keyword .. '&page=' .. tostring(page + 1)
  	table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
    
   	-- #stream/q=content&id=https://api.kinopoisk.dev/v1.4/movie/386?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
   	
	-- #stream/q=content&id=http://m.octopusfilm.su/16160-sila-prirody-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	
		local x =  conn:load(args.id)
	--	local x = http.getz(args.id)
		
       -- x = iconv(x, 'windows-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
	--	t['name'] = parse_match(x,'<h1.->(.-)скачать')
		t['description'] = parse_match(x,'(Сюжет:.-)<br>')
		t['poster'] = parse_match(x,'<div class="full%-story__top__info%-poster".-img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
		 '(Страна:</span>.-)</li>', '(Жанр:</span>.-)</li>', '(В Ролях:</span>.-)</li>', 
		})

--http://hidxlglk.deploy.cx/lite/fancdn?kinopoisk_id=386

 
--http://hidxlglk.deploy.cx/lite/hdvb/video.m3u8?kinopoisk_id=386&title=&original_title=&iframe=https%3a%2f%2fvid1768273722.fotpro135alto.com%2fmovie%2fd3d32b0257555ee658f1f6da50d11588%2fiframe&play=true
 

 --   for title3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
    --  title = urlencode(title)
     
  --    title = string.gsub(title, '+', '%%20')
      
    
  --    url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=')
       
  --   local x = conn1:load(args.id)
     
  --    local x = conn1:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
   --   for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

  --   local x = conn1:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
  -- for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
  --  table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
   --  end
--    end
--  end
  
  
  
    
    
    
  -- local x = conn:load(args.id)


--http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=https%3A%2F%2Fvid1766063946.fotpro135alto.com%2Fmovie%2Fb769608e827cd9ea273474cbd8b02f9a%2Fiframe&translator_id=89&play=1
  
   
  -- http://fxmlparsers.in.net/VilkaDB/?id=file&u=https%3A%2F%2Fvid1766063946.fotpro135alto.com%2Fmovie%2Fb769608e827cd9ea273474cbd8b02f9a%2Fiframe%3Fd%3Dkinokrad.my&v=%7ErFGbJFEHVYL-95UHmkgLlLlOyKuzYqhmMNkeOf963xg3bTqbS-PtqHOs1XE4yzuygi0Im9aGx1Te6mWXUyLXnT3kxq6xYWlKxuRlH9bommA4wKO50tXb0eJ%2B%24lbblfSwOC9GYHyCuTNi6wuan7NARmJIOn%2BegnqISrMEpYw%2B0umpTswmIK5DGqnaKdQYb%24-Jq5Xi939dsQq%24p1Huyqf40Knp5IkSVPzpJNYxA5W3ZrS0meCNeILOpJ4ZoMqgHxycJidhcgqeHKSbpFmoPzEnRg%21%21&key=HCk3DvqPKveqejHqn7mmkjuIfgVr-GNpHbRsndAPBsuIwOSyOnNAFOB9d8cuxt6S&tid=83533&href=fotpro135alto.com
   
   
   
   
      for url, url1 in string.gmatch(x, '(https://vid.-)(/movie.-)"') do

    url = urlencode(url)
    url1 = urlencode(url1)
    
  
 -- https://lam.akter-black.com/lite/hdvb/video?iframe=
 
--  id = string.gsub(url, '^(.-)', 'http://178.20.46.40:12600/lite/hdvb/video?iframe=') .. url1
  
    --   url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. url1
 
  local x = conn:load('http://178.20.46.40:12600/lite/hdvb/video?iframe=' .. url .. url1)
       
 -- table.insert(t, {title = id, mrl = id})
  
 --   for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
   --   url3 = string.gsub(url3, '\\u0026', '&')
 --  url3 = string.gsub(url3, '\\u002B', '+')
  
  --    local x = conn:load(url2 .. url3)

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/360/index.m3u8')
    
  --    t['view'] = 'simple'

    table.insert(t, {title = '360p ', mrl = url4})

end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/480/index.m3u8')
    
   --   t['view'] = 'simple'

    table.insert(t, {title = '480p ', mrl = url4})
end


for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/720/index.m3u8')
    
    --  t['view'] = 'simple'

    table.insert(t, {title = '720p ', mrl = url4})
end

    for  url4 in string.gmatch(x, '"play".-"url":"(http.-)"') do
    
    url4 = string.gsub(url4, '/index.m3u8', '/1080/index.m3u8')
    
   --   t['view'] = 'simple'

    table.insert(t, {title = '1080p ', mrl = url4})

      end 
   
      end




local x = conn:load(args.id)
 
     for id3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
  

    table.insert(t, {title = 'Hdvb2', mrl = '#stream/q=hdvbf&id3=' .. id3, image = image})
        end
     

--https://lam.maxvol.pro/proxy/lbxJUDzFAKrzJxN7u6otg5a9PkQo442mvmrCP1CLfMQrehq88gsfdl7/OmB62NEJoHpFFhseWw0NsWZhlXiUwGHOzca\u002BR8evJkRw/8mva/0Bf5V8Yz/Q1AnIfe6qSADu1tX5UXazcoWJyLbIjbe7Io5psSY4NF7koE2/WnnZWWq4nGEJi2CVqiASbsK4DeXF\u002Bz4gtsdOvIUo00swVCYqPgEMU4PQv5pI5X0aqYBFvJVBElL6xy9p\u002BzluUR2fQJrRA6rrDNM600cJKCVB3KlBqA==.mp4
    
 
     local x = conn:load(args.id)
 
     for id3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
  

    table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id3=' .. id3, image = image})
        end

        
        
 
 
 
       
 
 
 --https://stream.moviecorn.net/play?hash=1ce6102260e66f227102977c87f2f87dbb510a11
 
    local x = conn:load(args.id)

     for total in string.gmatch(x, '<a href="magnet:.-btih:(.-)&') do
    
       total = string.lower(total)
  
     total = string.gsub(total, '^(.-)', 'https://lam.akter-black.com/lite/pidtor/serial/') .. '?tr='

  --   table.insert(t, {title = title, mrl = '#stream/q=videot&id=' .. total, image = image})
--		end	
	
--    elseif args.q == 'videot' then

  --    args.id = args.id:lower() 

   local x = conn:load(total)
      

    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
    --  t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   end
        end
      
 
   elseif args.q == 'flixcdn' then

 
-- https://cdn0.cdnhub.help/show/kinopoisk/386?domain=piratka.tv
 
 
 local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv')



local slist = string.match(x, '<select name="translator"(.-)movies')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
         
    local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv&translation=' .. id5)



    local slist = string.match(x, 'file.-:(.-)CDNquality')

    if slist then
 
 for title1, url in string.gmatch(slist, '%[(.-)](http.-m3u8)') do

 t['view'] = 'simple'

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   end
end
 end



 
    local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv&autoplay=1&extrans=1')



local slist = string.match(x, '<select name="season"(.-)</select>')
  
      if slist then
                                             for id2, title1 in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
                                    

  local slist = string.match(x, '<select name="episode"(.-)</select>')
  
      if slist then
                                            for id4, title2 in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do





  local slist = string.match(x, '<select name="translator"(.-)series')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
 id5 = string.gsub(id5, '^(.-)', 'https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv&autoplay=1&extrans=1&translation=') 
 
 

    t['view'] = 'simple'

   table.insert(t, {title = title1 .. ' ' .. title2 .. ' ' .. title, mrl = '#stream/q=flixcdns&id3=' .. args.id3 .. '&id5=' .. id5 .. '&id1=' .. title .. '&id2=' .. id2 .. '&id4=' .. id4})

  end
   end
   end
   end
    end
 end
   
   
    
    elseif args.q == 'flixcdns' then  
    
    local x = conn:load(args.id5 .. '&season=' .. args.id2 .. '&episode=' .. args.id4)
    
      local slist = string.match(x, 'file.-:(.-)CDNquality')

    if slist then
 
 for title, url in string.gmatch(slist, '%[(.-)](http.-m3u8)') do

 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
   end



  elseif args.q == 'hdvbf' then

    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	




      for title, url, id in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"(http.-)".-"translator_id":(.-),') do


 
      url = string.gsub(url, '\\', '')

--http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=https://vid1766135200.fotpro135alto.com/serial/56e881da922e06b2a74d84e242afcf65f05f4fe9f090bfa4e5a1a82d2b3e48d8/iframe&translate=Дубляж Ultradox&translator_id=218


       
--url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. '&translator_id=' .. id
       --.. '&play=1'

    --   table.insert(t, {title = url, mrl = '#stream/q=content&id=' .. url, image = image})
--	end
       local x = conn:load('http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=' .. urlencode(url) .. '&translator_id=' .. id)


         for url2 in string.gmatch(x, '"parser":"(http.-)"') do 
         
        url2 = string.gsub(url2, '\\', '')

      local x = conn:load(url2)



         for total, url3 in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	 




t['view'] = 'simple'
       table.insert(t, {title = total .. ' ' .. title, mrl = url3})

       end
       
         for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

   t['view'] = 'simple'
   
       table.insert(t, {title = total .. ' ' .. title, mrl = url3})

       end
        for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480', '720')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

t['view'] = 'simple'

       table.insert(t, {title = '720p' .. ' ' .. title, mrl = url3})

       end
       
      for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do

		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480', '1080')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	
     
 t['view'] = 'simple'
 
       table.insert(t, {title = '1080p' .. ' ' .. title, mrl = url3})

       end
       end
       end
     
     
     
     local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)
     
     
     x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	


     
     
     
     
     for title, url, id in string.gmatch(x, '"translator":"(.-)".-"type":"serial".-"iframe_url":"(http.-)".-"translator_id":(.-),') do
     
     
     url = string.gsub(url, '\\', '')



url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. '&translate=' .. urldecode(title) .. '&translator_id=' .. id
     
     
     local x = conn:load(url)

x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
       
       x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')  
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')  
      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')  
      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')  
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')  
       x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')  
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
       x = string.gsub(x, '\\u0420', 'Р')
       x = string.gsub(x, '\\u0440', 'р')
       x = string.gsub(x, '\\u0421', 'С')
       x = string.gsub(x, '\\u0441', 'с')
       x = string.gsub(x, '\\u0422', 'Т')
       x = string.gsub(x, '\\u0442', 'т')
       x = string.gsub(x, '\\u0423', 'У')
       x = string.gsub(x, '\\u0443', 'у')
       x = string.gsub(x, '\\u0424', 'Ф')
        x = string.gsub(x, '\\u0444', 'ф')
        x = string.gsub(x, '\\u0425', 'Х')
        x = string.gsub(x, '\\u0445', 'х')
        x = string.gsub(x, '\\u0426', 'Ц')
        x = string.gsub(x, '\\u0446', 'ц')
        x = string.gsub(x, '\\u0427', 'Ч')
        x = string.gsub(x, '\\u0447', 'ч')
        x = string.gsub(x, '\\u0428', 'Ш')
        x = string.gsub(x, '\\u0448', 'ш')
        x = string.gsub(x, '\\u0429', 'Щ')
        x = string.gsub(x, '\\u0449', 'щ')
        x = string.gsub(x, '\\u042a', 'Ъ')
        x = string.gsub(x, '\\u044a', 'ъ')
        x = string.gsub(x, '\\u042b', 'Ы')
        x = string.gsub(x, '\\u044b', 'ы')
        x = string.gsub(x, '\\u042c', 'Ь')
        x = string.gsub(x, '\\u044c', 'ь')
        x = string.gsub(x, '\\u042d', 'Э')
        x = string.gsub(x, '\\u044d', 'э')
        x = string.gsub(x, '\\u042e', 'Ю')
        x = string.gsub(x, '\\u044e', 'ю')
        x = string.gsub(x, '\\u042f', 'Я')
        x = string.gsub(x, '\\u044f', 'я')
        x = string.gsub(x, '\\u00ab', '<<')
        x = string.gsub(x, '\\u00bb', '>>')
        x = string.gsub(x, '\\u2014', '-')
	


         for title1, title2, id1, id2, id3, id4, id5, id6, id7 in string.gmatch(x, '"information":"(.-)<br>(.-)".-"parser":"http.-?id=file&u=(.-)&v=(.-)&key=(.-)&.-&href=(.-)&ep=(.-)&season=(.-)&fid=(.-)"') do 
         
       -- url2 = string.gsub(url2, '\\', '')
title2 = string.gsub(title2, '<br>', ' ')
 
 t['view'] = 'simple'
 
 
     table.insert(t, {title = title1 .. ' ' .. title2, mrl = '#stream/q=hdvbs&id1=' .. id1 .. '&id2=' .. id2 .. '&id3=' .. id3 .. '&id4=' .. id4 .. '&id5=' .. id5 .. '&id6=' .. id6 .. '&id7=' .. id7 .. '&id8=' .. title1 .. '&id9=' .. title2})
     
     end
     end
     
     
     elseif args.q == 'hdvbs' then
     
     
      local x = conn:load('http://fxmlparsers.in.net/VilkaDB/?id=file&u=' .. args.id1 .. '&v=' .. args.id2 .. '&key=' ..args.id3 .. '&tid=&href=' .. args.id4 .. '&ep=' .. args.id5 .. '&season=' .. args.id6 .. '&fid=' .. args.id7)





         for total, url3 in string.gmatch(x, '(360p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')

url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

t['view'] = 'simple'
       table.insert(t, {title = total .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})

       end
       
         for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

   t['view'] = 'simple'
   
       table.insert(t, {title = total .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})


       end
        for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480', '720')

url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	

t['view'] = 'simple'

       table.insert(t, {title = '720p' .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})


       end
       
      for total, url3 in string.gmatch(x, '(480p).-(http.-m3u8)') do
		
         print(url3)
		 url3 = string.gsub(url3, '\\', '')
     url3 = string.gsub(url3, '480', '1080')
url3 = string.gsub(url3, '^(.-)', 'http://5.180.45.229/hls/')	
     
     
     
 t['view'] = 'simple'
 
       table.insert(t, {title = '1080p ' .. ' ' .. args.id8 .. ' ' .. args.id9, mrl = url3})


       end
       
  
		elseif args.q == 'video' then
		return {{title = args.t, mrl = args.url}}
		
	elseif args.q == 'play' then
		return video(args.url, args)
	end
	return t
end
