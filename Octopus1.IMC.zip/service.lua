-- Octopus plugin

require('support')
require('video')
require('parser')
require('client')
require('fxml')




local fxml = onCreate
--src="//bigpkcqnm.tevas.tech/kino/download/top/Voron_fhd_2024.mp4

--https://my.ultradox.fun/42643-bespredelnye-puteshestviya-vo-vremeni-2023.html


--https://bigpkcqnm.tevas.tech/kino/download/Bespredelnye_puteshestvija_vo_vremeny_2023.mp4

--https://tevas.tv/kino/download/?f=Bespredelnye_puteshestviya_vo_vremeni_2023.mp4&sea=268962182929&big=885

--https://tevas.tv/kino/download/?f=Poltergejst_drugoe_izmerenie_2024.mp4


--https://my.ultradox.fun/42889-poltergeyst-drugoe-izmerenie-2023.html

--https://bigpkcqnm.tevas.tech/kino/download/Zaklyate_slugy_satany_fhd_2017.mp4

--https://tevas.tv/serial/zhizn_po_vyzovu/01_1080/?f=tevas_zhizn_po_vyzovu_fhd_01_05.mp4&big=885

--https://tevas.tv/kino/download/?f=Ubijstvennaya_zhara_2024.mp4


--<meta property="og:image" content="https://www.kinopoisk.ru/rating/846892/.gif" /


--<meta property="og:image" content="https://www.kinopoisk.ru/rating/1112513.gif

--https://api.tobaco.ws/embed/kp/846892

--https://my.ultradox.fun/42962-ubiystvennaya-zhara-2024.html

--https://tevas.tv/serial/top/vlastelin_kolec_kolca_vlasti/01/?f=tevas_vlastelin_kolec_kolca_vlasti_01_01.mp4&big=884


--https://bigpkcqnm.tevas.tech/kino/download/vlastelin_kolec_kolca_vlasti_1_1.mp4


--https://my.ultradox.fun/42330-vlastelin-kolec-kolca-vlasti-2-sezon.html


local REPO = 'https://github.com/dimasuhum/dimasuhum.github.io/raw/master/'

--local HOME = 'https://ultradox.top'
--local HOME = 'http://octopushome.su'

local HOME = 'https://021.ultadox.space'
local HOME_SLASH = HOME .. '/'

local conn1 = client.new()
conn1['encoding'] = 'windows-1251'
local conn = client.new()
conn['encoding'] = 'utf-8'
conn['root'] = HOME_SLASH
conn1['root'] = HOME_SLASH



--HOME = 'http://my.ultradox.press'

--HOME_SLASH = HOME .. '/'
--windows-1251

function onLoad()
	print('Hello from octopusfilm plugin')
	return 1
end

function onUnLoad()
	print('Bye from octopusfilm plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})
	
	-- #stream/page=2
	-- #stream/page=/nerufilm/	
	-- #stream/genre=/hd/
	-- #stream/genre=/webrips/
	-- #stream/genre=/camrip/
    -- #stream/url=/serial/
	-- #stream/url=/rufilm/
	-- #stream/url=/hd/
	if not args.q then
		local page = tonumber(args.page or 1)
	--	local genre = args.genre or '/nerufilm/hd/'
		
		local genre = args.genre or '/hd/'
		
		local url = HOME .. genre
		--local url1 = HOME1 .. genre
		if page > 1 then
			url = url .. 'page/' .. tostring(page) .. '/'
			--url1 = url1 .. '/page/' .. tostring(page) .. '/'
		end
        
	--	local x = http.getz(url)
       local x = conn:load(url)
    --   x = iconv(x, 'windows-1251', 'utf-8')
       

       
		for url, image, title, total in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-src=.-(/uploads/.-)".-<span>(.-)%((%d+)%)</span>') do
	
          image = string.gsub(image, '^(.-)', HOME)
            if image and not string.find(image, '://') then
				image = HOME .. image
			end
	
--	url = string.gsub(url, '^(.-)', HOME)
	
	
	--		image = string.gsub(image, '^(.-)', 'http://ultradox.asia')
			table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
		
		--local x = http.getz(url1)
       -- x = iconv(x, 'WINDOWS-1251', 'UTF-8')
		--for url, image, title in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-<img src="(.-)" alt="(.-)"') do
		--	image = string.gsub(image, '^/', HOME_SLASH1)
		--	table.insert(t, {title = tolazy(title), mrl = '#stream/q=content&id=' .. url, image = image})
	--	end
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'
		local x =  conn:load(HOME)
      --  x = iconv(x, 'WINDOWS-1251', 'UTF-8')
	--	x = string.match(x, 'div class="top__menu_ul">(.-)</div>')
    --    for genre, title in string.gmatch(x,'<a href="(.-)">(.-)</a>') do
		--	table.insert(t, {title = title, mrl = '#stream/genre=' .. genre .. '/'})
	--	end
        table.insert(t, {title = 'Сериалы', mrl = '#stream/genre=' .. '/serial-hd/'})
        table.insert(t, {title = 'HDRIP / BDRIP', mrl = '#stream/genre=' .. '/hd/'})
        table.insert(t, {title = 'НАШЕ КИНО', mrl = '#stream/genre=' .. '/rufilm/'})
        table.insert(t, {title = 'CAMRIP / TS', mrl = '#stream/genre=' .. '/camrip/'})
        table.insert(t, {title = 'WEB-DL', mrl = '#stream/genre=' .. '/webrips/'})
        table.insert(t, {title = 'Аниме', mrl = '#stream/genre=' .. '/anime/'})
        
    
    
    elseif args.q == 'search' then
		if not args.keyword then
			return {view = 'keyword', message = '@string/search_text', keyword = keyword}
		end
		t['message'] = args.keyword
    
    local page = tonumber(args.page or 1)

--https://1ultradox.ctudio/index.php?story=Чужой&do=search&subaction=search&page=2


--	local args.keyword =  conn1:load(args.id)
		
   local page = tonumber(args.page or '1')

       local url = HOME .. '/index.php?story=' .. urlencode(args.keyword) .. '&do=search&subaction=search'
       --.. '&page=' .. tostring(page)
       
    --   if page > 1 then
		--	url = HOME .. '/index.php?' .. 'page=' .. tostring(page) .. '&story=' .. urlencode(args.keyword) .. '&do=search&subaction=search' 

	--	end
       
       if page > 1 then
			url = HOME .. '/index.php?' .. '&do=search&subaction=search' .. '&from_page=' .. tostring(page) .. '&story=' .. urlencode(args.keyword)

		end
       
--	local x =  conn1:load(args.id)
     local x = conn:load(url)
      --  x = iconv(x, 'windows-1251', 'utf-8')
		for url, image, title, total in string.gmatch(x, '<div class="top__slider_div__item".-<a href="(.-)".-src=.-(/uploads/.-)".-<span>(.-)%((%d+)%)</span>') do
	
          image = string.gsub(image, '^(.-)', HOME)
            if image and not string.find(image, '://') then
				image = HOME .. image
			end
	url = string.gsub(url, '^(.-)', HOME)
	
	--		image = string.gsub(image, '^(.-)', 'http://ultradox.asia')
			table.insert(t, {title = tolazy(title) .. ' (' .. total .. ')', mrl = '#stream/q=content&id=' .. url .. '&id1=' .. title .. '&id2=' .. total, image = image})
		end
     
     
     local url = '#folder/q=search&keyword=' .. urlencode(args.keyword) .. '&page=' .. tostring(page + 1)
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl= url, image = '#self/next.png'})
     
     
    
   	-- #stream/q=content&id=https://api.kinopoisk.dev/v1.4/movie/386?token=99N2KGM-G66MES4-K9WB2VV-YRP0BWG'
   	
	-- #stream/q=content&id=http://m.octopusfilm.su/16160-sila-prirody-2020.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
	
		local x =  conn:load(args.id)
	--	local x = http.getz(args.id)
		
       -- x = iconv(x, 'windows-1251', 'UTF-8')
		--print(x)
	--	t['ref'] = args.id
	--	t['name'] = parse_match(x,'<h1.->(.-)скачать')
		t['description'] = parse_match(x,'(Сюжет:.-)<br>')
		t['poster'] = parse_match(x,'<div class="full%-story__top__info%-poster".-img src="(.-)"')
		if t['poster'] then
			t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
		end
		t['annotation'] = parse_array(x, {
		 '(Страна:</span>.-)</li>', '(Жанр:</span>.-)</li>', '(В Ролях:</span>.-)</li>', 
		})

--http://hidxlglk.deploy.cx/lite/fancdn?kinopoisk_id=386

 
--http://hidxlglk.deploy.cx/lite/hdvb/video.m3u8?kinopoisk_id=386&title=&original_title=&iframe=https%3a%2f%2fvid1768273722.fotpro135alto.com%2fmovie%2fd3d32b0257555ee658f1f6da50d11588%2fiframe&play=true
 

 --   for title3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
    --  title = urlencode(title)
     
  --    title = string.gsub(title, '+', '%%20')
      
 --   http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&content=aHR0cHM6Ly92aWQxNzU5NjU0ODA0LmZvdHBybzEzNWFsdG8uY29tL21vdmllLy9pZnJhbWU=&userdata=1&kp=386&box_mac=acace24b8434
    
    
  --    url1 = string.gsub(title3, '^(.-)', 'http://kb-team.club/?do=/plugin&bid=megahdvb-megahdvb&act=play&kp=386&box_mac=acace24b8434')
       
  --   local x = conn1:load(args.id)
     
  --    local x = conn1:load(url1 .. '&box_mac=acace24b8434' or url1 .. '&box_mac=b8bc5bf8dea3')
   
   
   --   for total3, url2 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<playlist_url><!%[CDATA%[(http.-)]]') do
    
    

  --   local x = conn1:load(url2 .. '&box_mac=acace24b8434' or url2 .. '&box_mac=b8bc5bf8dea3')
   
  -- for total4, url3 in string.gmatch(x, '<channel>.-<title><!%[CDATA%[(.-)]]></title>.-<stream_url><!%[CDATA%[(http.-)]]') do 
    
    
  --  table.insert(t, {title = tolazy(total3) .. ' ' .. total4, mrl = url3})
   --  end
--    end
--  end
  
  
  
    
    
    
  -- local x = conn:load(args.id)


--http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=https%3A%2F%2Fvid1766063946.fotpro135alto.com%2Fmovie%2Fb769608e827cd9ea273474cbd8b02f9a%2Fiframe&translator_id=89&play=1
  
   
  -- http://fxmlparsers.in.net/VilkaDB/?id=file&u=https%3A%2F%2Fvid1766063946.fotpro135alto.com%2Fmovie%2Fb769608e827cd9ea273474cbd8b02f9a%2Fiframe%3Fd%3Dkinokrad.my&v=%7ErFGbJFEHVYL-95UHmkgLlLlOyKuzYqhmMNkeOf963xg3bTqbS-PtqHOs1XE4yzuygi0Im9aGx1Te6mWXUyLXnT3kxq6xYWlKxuRlH9bommA4wKO50tXb0eJ%2B%24lbblfSwOC9GYHyCuTNi6wuan7NARmJIOn%2BegnqISrMEpYw%2B0umpTswmIK5DGqnaKdQYb%24-Jq5Xi939dsQq%24p1Huyqf40Knp5IkSVPzpJNYxA5W3ZrS0meCNeILOpJ4ZoMqgHxycJidhcgqeHKSbpFmoPzEnRg%21%21&key=HCk3DvqPKveqejHqn7mmkjuIfgVr-GNpHbRsndAPBsuIwOSyOnNAFOB9d8cuxt6S&tid=83533&href=fotpro135alto.com
   
   
   
   
      for url, url1 in string.gmatch(x, '(https://vid.-)(/movie.-)"') do

    url = urlencode(url)
    url1 = urlencode(url1)
    
  

 
--  id = string.gsub(url, '^(.-)', 'http://178.20.46.40:12600/lite/hdvb/video?iframe=') .. url1
  
    --   url = string.gsub(url, '^(.-)', 'http://fxmlparsers.in.net/VilkaDB/?id=hdvb&src=') .. url1
 
  local x = conn:load('http://178.20.46.40:12600/lite/hdvb/video?iframe=' .. url .. url1)
       
 -- table.insert(t, {title = id, mrl = id})
  
 --   for  url2, url3, total2 in string.gmatch(x, '"method":"call".-"url":"(http.-hdvb)(.-)".-class="videos__item%-title">(.-)</div>') do
  
   --   url3 = string.gsub(url3, '\\u0026', '&')
 --  url3 = string.gsub(url3, '\\u002B', '+')
  
  --    local x = conn:load(url2 .. url3)

    for  url4 in string.gmatch(x, '"play".-"url":"http.-(/proxy.-)"') do
    
   url4 = string.gsub(url4, '^(.-)', 'http://178.20.46.40:12600')
    
  --    t['view'] = 'simple'

    table.insert(t, {title = '1080p ', mrl = url4})

end
end





local x = conn:load(args.id)
 
    
  --    for url, url1 in string.gmatch(x, '<iframe.-http.-(vid.-)/.-(/.-)"') do

 --   url = urlencode(url)
 --   url1 = urlencode(url1)
    
    for id3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
  
table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvbf&id3=' .. id3, image = image})

  --  table.insert(t, {title = 'Hdvb', mrl = '#stream/q=hdvbf&id=' .. url .. '&id1=' .. url1, image = image})
        end
     

--https://lam.maxvol.pro/proxy/lbxJUDzFAKrzJxN7u6otg5a9PkQo442mvmrCP1CLfMQrehq88gsfdl7/OmB62NEJoHpFFhseWw0NsWZhlXiUwGHOzca\u002BR8evJkRw/8mva/0Bf5V8Yz/Q1AnIfe6qSADu1tX5UXazcoWJyLbIjbe7Io5psSY4NF7koE2/WnnZWWq4nGEJi2CVqiASbsK4DeXF\u002Bz4gtsdOvIUo00swVCYqPgEMU4PQv5pI5X0aqYBFvJVBElL6xy9p\u002BzluUR2fQJrRA6rrDNM600cJKCVB3KlBqA==.mp4
    
    local x = conn:load(args.id)
 
 
 
     for id3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
 
table.insert(t, {title = 'Zagonka', mrl = '#stream/q=zagonka&id3=' .. id3 .. '&id1=' .. args.id1 .. '&id2=' .. args.id2})
 
 
 end
 
   --  local x = conn:load(args.id)
 
 
 
  --   for id3 in string.gmatch(x, '<div class="full%-story__ratings".-<img src=".-kinopoisk.ru/rating/(.-).gif"') do
  

 --   table.insert(t, {title = 'Flixcdn', mrl = '#stream/q=flixcdn&id3=' .. id3, image = image})
   --     end

        
        
 
 
 
       
 

 --https://stream.moviecorn.net/play?hash=1ce6102260e66f227102977c87f2f87dbb510a11
 
    local x = conn:load(args.id)

     for total in string.gmatch(x, '<a href="magnet:.-btih:(.-)&') do
    
       total = string.lower(total)
  
     total = string.gsub(total, '^(.-)', 'https://lam.maxvol.pro/lite/pidtor/serial/') .. '?tr='

  --   table.insert(t, {title = title, mrl = '#stream/q=videot&id=' .. total, image = image})
--		end	
	
--    elseif args.q == 'videot' then

  --    args.id = args.id:lower() 

   local x = conn:load(total)
      
if x then

    for url, title  in string.gmatch(x, '<div class="videos__item videos.-"method":"play".-"url":"(http.-)".-class="videos__item%-title">(.-)</div>') do
      
      url = string.gsub(url, '\\u0026', '&')
    --  t['view'] = 'simple'
      
      table.insert(t, {title = title, mrl = url})
   end
        end
      end
 
  
  elseif args.q == 'flixcdn' then

 
-- https://cdn0.cdnhub.help/show/kinopoisk/386?domain=piratka.tv
 
 local x = conn:load('https://tarantino.factorios.live/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local')
 
 
 --local x = conn:load('https://player0.flixcdn.space/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local')

--local x = conn:load('https://cdn0.cdnhub.help/show/kinopoisk/' .. args.id3 .. '?domain=piratka.tv')

local slist = string.match(x, '<select name="translator"(.-)movies')
 
 
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
         
    local x = conn:load('https://tarantino.factorios.live/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local&translation=' .. id5)


 


  --  local slist = string.match(x, 'charset(.-)window.PlayerjsEvents')



    if x then
 
 for title1, url in string.gmatch(x, '%[(240)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'

--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
   
   for title1, url in string.gmatch(x, '%[(360)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
  
for title1, url in string.gmatch(x, '%[(480)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})

   end
   
for title1, url in string.gmatch(x, '%[(720)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   
for title1, url in string.gmatch(x, '%[(1080)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 

 t['view'] = 'simple'


--table.insert(t, {title = url, mrl = url})

table.insert(t, {title = title1 .. 'p ' .. title, mrl = url})


   end
   
   
   end
end
 end



 
    local x = conn:load('https://tarantino.factorios.live/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local&autoplay=1&extrans=1')



local slist = string.match(x, '<select name="season"(.-)</select>')
  
      if slist then
                                             for id2, title1 in string.gmatch(slist, '<option value="(.-)".->(Сезон.-)</option>') do
                                    

  local slist = string.match(x, '<select name="episode"(.-)</select>')
  
      if slist then
                                            for id4, title2 in string.gmatch(slist, '<option value="(.-)".->(Серия.-)</option>') do





  local slist = string.match(x, '<select name="translator"(.-)series')
 
    if slist then
 
 
 for id5, title in string.gmatch(slist, '<option value="(.-)".->(.-)</option>') do
 
 id5 = string.gsub(id5, '^(.-)', 'https://tarantino.factorios.live/show/kinopoisk/' .. args.id3 .. '?domain=nginx.cis-bel-back.orb.local&autoplay=1&extrans=1&translation=') 
 
 

    t['view'] = 'simple'

   table.insert(t, {title = title1 .. ' ' .. title2 .. ' ' .. title, mrl = '#stream/q=flixcdns&id3=' .. args.id3 .. '&id5=' .. id5 .. '&id1=' .. title .. '&id2=' .. id2 .. '&id4=' .. id4})

  end
   end
   end
   end
    end
 end
   
   
    
    elseif args.q == 'flixcdns' then  
    
    local x = conn:load(args.id5 .. '&season=' .. args.id2 .. '&episode=' .. args.id4)
    
   --   local slist = string.match(x, 'file.-:(.-)CDNquality')

  --  if slist then
 
 
 for title, url in string.gmatch(x, '%[(240)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
 
 for title, url in string.gmatch(x, '%[(360)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end
   
for title, url in string.gmatch(x, '%[(480)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end

for title, url in string.gmatch(x, '%[(720)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end

for title, url in string.gmatch(x, '%[(1080)](http.-m3u8)') do

url = string.gsub(url, 'cdn3', 'cdn1') 
 t['view'] = 'simple'

table.insert(t, {title = title .. 'p ' .. args.id1, mrl = url})


   end



 

    elseif args.q == 'hdvb' then
      

local url = 'https://' .. args.id .. '/movie' .. args.id1

if url then

local headers = {
    ["Host"] = args.id,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)


local id, key = string.match(x, '"file":"%~(.-)".-"key":"(.-)"')

if id then
if key then


local href = string.match(x, '"href":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'



local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. args.id,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. args.id .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)

         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p)', mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p)', mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p)', mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p)', mrl = url3})

       end
       end
  end
  end
    
    
    
    
    
    
     local url = 'https://' .. args.id .. '/serial' .. args.id1
         

if url then


url = string.gsub(url, '\\', '')



local headers = {
    ["Host"] = args.id,
    ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    ["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    ["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
    ["Accept-Encoding"] = "gzip, deflate, br, zstd",
    ["Connection"] = "keep-alive",
    ["Cookie"] = "_ym_uid=177873309816283985; _ym_d=1778733098; _ym_isad=2",
    ["Upgrade-Insecure-Requests"] = "1",
    ["Sec-Fetch-Dest"] = "document",
    ["Sec-Fetch-Mode"] = "navigate",
    ["Sec-Fetch-Site"] = "none",
    ["Sec-Fetch-User"] = "?1",
    ["Priority"] = "u=0, i"
}

local x = http.getz(url, headers)

x = string.gsub(x, '\\', '')

local id, key = string.match(x, '"file":"(.-)".-"key":"(.-)"')

if id then
if key then


local href = string.match(x, '"href":"(.-)"')


id = string.gsub(id, '^(.-)', 'https://vid11.' .. href)

local headers1 = {
    ["Host"] = "vid11." .. href,
["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
["Accept"] = "*/*",
["Accept-Language"] = "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
["Accept-Encoding"] = "gzip, deflate, br, zstd",
["Content-type"] = "application/x-www-form-urlencoded",
["X-CSRF-TOKEN"] = key,
["Origin"] = "https://" .. args.id,
["Connection"] = "keep-alive",
["Referer"] = "https://" .. args.id .. "/",
["Sec-Fetch-Dest"] = "empty",
["Sec-Fetch-Mode"] = "cors",
["Sec-Fetch-Site"] = "same-site",
["Content-Length"] = ""}



local x = http.postz(id, headers1)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')







for id1, text in string.gmatch(x, '"file":"%~(.-)".-"text2":"(.-)"') do

--local text = string.match(x, '"file".-"text2":"(.-)"')


id1 = string.gsub(id1, '^(.-)', 'https://vid11.' .. href .. '/playlist/') .. '.txt'


local x = http.postz(id1, headers1)



for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '360/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. text, mrl = url3})

       end
       
         for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '480/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. text, mrl = url3})

       end
        for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '720/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. text, mrl = url3})

       end
       
      for url3 in string.gmatch(x, '(http.-m3u8)') do
		
		 url3 = string.gsub(url3, 'index', '1080/index')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. text, mrl = url3})

       end
     
end
    
end
end
end
  
  
  
  
elseif args.q == 'hdvbf' then
      
    local x = conn:load('https://apivb.com/api/videos.json?full=true&token=d16fe09ddd4d031b06a32a2e535147fc&id_kp=' .. args.id3)


x = string.gsub(x, '\\u0410', 'А')
      x = string.gsub(x, '\\u0430', 'а')
      x = string.gsub(x, '\\u0411', 'Б')
       x = string.gsub(x, '\\u0431', 'б')
       x = string.gsub(x, '\\u0412', 'В')
      x = string.gsub(x, '\\u0432', 'в')
       x = string.gsub(x, '\\u0413', 'Г')
       x = string.gsub(x, '\\u0433', 'г')      x = string.gsub(x, '\\u0414', 'Д')
      x = string.gsub(x, '\\u0434', 'д')
       x = string.gsub(x, '\\u0415', 'Е')
       x = string.gsub(x, '\\u0435', 'е')      x = string.gsub(x, '\\u0401', 'Ё')
      x = string.gsub(x, '\\u0451', 'ё')
       x = string.gsub(x, '\\u0416', 'Ж')
       x = string.gsub(x, '\\u0436', 'ж')
       x = string.gsub(x, '\\u0417', 'З')
      x = string.gsub(x, '\\u0437', 'з')
       x = string.gsub(x, '\\u0418', 'И')
       x = string.gsub(x, '\\u0438', 'и')     x = string.gsub(x, '\\u0419', 'Й')
      x = string.gsub(x, '\\u0439', 'й')
       x = string.gsub(x, '\\u041a', 'К')
       x = string.gsub(x, '\\u043a', 'к')
       x = string.gsub(x, '\\u041b', 'Л')
       x = string.gsub(x, '\\u043b', 'л')
       x = string.gsub(x, '\\u041c', 'М')
       x = string.gsub(x, '\\u043c', 'м')
       x = string.gsub(x, '\\u041d', 'Н')
       x = string.gsub(x, '\\u043d', 'н')
       x = string.gsub(x, '\\u041e', 'О')
       x = string.gsub(x, '\\u043e', 'о')
       x = string.gsub(x, '\\u041f', 'П')
       x = string.gsub(x, '\\u043f', 'п')
    x = string.gsub(x, '\\u0420', 'Р')
    x = string.gsub(x, '\\u0440', 'р')
    x = string.gsub(x, '\\u0421', 'С')
    x = string.gsub(x, '\\u0441', 'с')
    x = string.gsub(x, '\\u0422', 'Т')
    x = string.gsub(x, '\\u0442', 'т')
    x = string.gsub(x, '\\u0423', 'У')
    x = string.gsub(x, '\\u0443', 'у')
    x = string.gsub(x, '\\u0424', 'Ф')
    x = string.gsub(x, '\\u0444', 'ф')
    x = string.gsub(x, '\\u0425', 'Х')
    x = string.gsub(x, '\\u0445', 'х')
    x = string.gsub(x, '\\u0426', 'Ц')
    x = string.gsub(x, '\\u0446', 'ц')
    x = string.gsub(x, '\\u0427', 'Ч')
    x = string.gsub(x, '\\u0447', 'ч')
    x = string.gsub(x, '\\u0428', 'Ш')
    x = string.gsub(x, '\\u0448', 'ш')
    x = string.gsub(x, '\\u0429', 'Щ')
    x = string.gsub(x, '\\u0449', 'щ')
    x = string.gsub(x, '\\u042a', 'Ъ')
    x = string.gsub(x, '\\u044a', 'ъ')
    x = string.gsub(x, '\\u042b', 'Ы')
    x = string.gsub(x, '\\u044b', 'ы')
    x = string.gsub(x, '\\u042c', 'Ь')
    x = string.gsub(x, '\\u044c', 'ь')
    x = string.gsub(x, '\\u042d', 'Э')
    x = string.gsub(x, '\\u044d', 'э')
    x = string.gsub(x, '\\u042e', 'Ю')
    x = string.gsub(x, '\\u044e', 'ю')
    x = string.gsub(x, '\\u042f', 'Я')
    x = string.gsub(x, '\\u044f', 'я')
    x = string.gsub(x, '\\u00ab', '<<')
    x = string.gsub(x, '\\u00bb', '>>')
    x = string.gsub(x, '\\u2014', '-')
 x = string.gsub(x, '\\u049a', 'Қ')
x = string.gsub(x, '\\u049b', 'қ')
x = string.gsub(x, '\\u049b', 'Қ')
x = string.gsub(x, '\\u049a', 'қ')

      for title, origin, url in string.gmatch(x, '"translator":"(.-)".-"type":"movie".-"iframe_url":"http.-(vid.-)(/movie.-)"') do
      
if origin then 
if url then


url = string.gsub(url, '\\', '')

origin = string.gsub(origin, '\\', '')

-- https://lam.maxvol.pro/proxy/5ae371e16655f3ef2bae8d4a28d56b8d.m3u8

-- http://78.40.195.218:9118/lite/hdvb/serial?iframe=https%3a%2f%2fvid1733431681.entouaedon.com%2fserial%2f4e6eb80724f81b2fc89bf9c3f8507021e1f9a9dba4c9d493288c81a9f86943a3%2fiframe&t=BaibaKo&s=1&e=1
 
      url = string.gsub(url, '^(.-)', 'https://lam.maxvol.pro/lite/hdvb/video?iframe=' .. 'https://' .. origin)

--table.insert(t, {title = url, mrl = url})

local x = http.getz(url)


x = string.gsub(x, '\\', '')


local url2 = string.match(x,'method.-"play".-"url":"http.-(/proxy.-m3u8)"')
   
 
  
   local x = conn:load('https://lam.maxvol.pro' .. url2)

 
   x = string.gsub(x, '\\', '')
   

 
         for url3 in string.gmatch(x, 'RESOLUTION.-640.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'simple'
       table.insert(t, {title = '(360p) ' .. title, mrl = url3})

       end
       
         for url3 in string.gmatch(x, 'RESOLUTION.-858.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')

t['view'] = 'simple'
       table.insert(t, {title = '(480p) ' .. title, mrl = url3})

      
       end
        for url3 in string.gmatch(x, 'RESOLUTION.-1280.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
		 
t['view'] = 'simple'
       table.insert(t, {title = '(720p) ' .. title, mrl = url3})


       end
       
for url3 in string.gmatch(x, 'RESOLUTION.-1920.-http.-(/proxy.-m3u8)') do
		
--	url3 = string.gsub(url3, '\\', '')
	
		 url3 = string.gsub(url3, '^(.-)', 'https://lam.maxvol.pro')
	

t['view'] = 'simple'
       table.insert(t, {title = '(1080p) ' .. title, mrl = url3})


       end
       end
     
  end
  end
    
    
    
    
    
     
     local x = conn:load('http://78.40.195.218:9118/lite/hdvb?kinopoisk_id=' .. args.id3)
     
     
  --   table.insert(t, {title = url, mrl = '#stream/q=hdvbs&id1=' .. url})
     
  -- table.insert(t, {title = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3, mrl = 'https://lam.maxvol.pro/lite/hdvb?kinopoisk_id=' .. args.id3})


for url2, total  in string.gmatch(x, '<div class="videos__item videos__season.-"method":"link".-"url":"http.-(/lite.-)".-class="videos__item%-title videos__season%-title">(.-сезон)</div>') do

    url2 = string.gsub(url2, '\\u0026', '&')
url2 = string.gsub(url2, '\\u002B', '+')


     local x = conn:load('http://78.40.195.218:9118' .. url2)

      for url4, total2  in string.gmatch(x, '<div class="videos__button selector.-"method":"link".-"url":"http.-(/lite.-)".->(.-)</div>') do

     url4 = string.gsub(url4, '\\u0026', '&')
     url4 = string.gsub(url4, '\\u002B', '+')
     
     local x = conn:load('http://78.40.195.218:9118' .. url4)


      for url6, total3  in string.gmatch(x, '<div class="videos__item videos__movie selector.-"stream":"http.-(/lite.-)".-class="videos__item%-title">(.-серия)</div>') do




     url6 = string.gsub(url6, '\\u0026', '&')
    url6 = string.gsub(url6, '\\u002B', '+')
    
       t['view'] = 'simple'

    table.insert(t, {title = total2 .. ' '  .. tolazy(total) .. ' ' .. total3, mrl = 'http://78.40.195.218:9118' .. url6})
    end
end
end


  
  
  
  
elseif args.q == 'zagonka' then
 


--args.id1 = string.gsub(args.id1, ':', '') 
args.id1 = string.gsub(args.id1, ' ', '%%20') 
		
 -- args.id1 = urlencode(args.id1)
 
-- args.id1 = string.gsub(args.id1, '+', '%%20') 
   
       local url = 'http://abc.zagonkop.gb.net/engine/ajax/xsearch/f.php?q=' .. args.id1
       --.. '%%20' .. args.id2

--table.insert(t, {title = url, mrl = url})	

local headers = {    
      ["host"] = "abc.zagonkop.gb.net",
      ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0",
       ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["referer"] = "http://abc.zagonkop.gb.net/",
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive"
}



local x = http.getz(url, headers)


local x = json.decode(x)

		for _, v in ipairs(x) do
		--	local url = 'http://rutube.ru/video/' .. v['id'] .. '/'
	
	t['view'] = 'simple'
	
	table.insert(t, {title = v['text'], mrl = '#stream/q=zagonkaz&id1=' .. v['id'] .. '&id=' .. v['url']})

end






--for ids, urls in string.gmatch(x, '{"id":"(.-)".-url.-(/.-)"') do

--{"id":"(.-)","text":"(.-)","url":"\/135628-ubivat-nado-vovremja-1998-onlayn.html"

--local ids, urls = string.match(x, '{"id":"(.-)".-url.-(/.-)"')

--urls = string.gsub(urls, '^(.-)', 'http://abc.zagonkop.gb.net') 

 
--t['view'] = 'simple'

--table.insert(t, {title = urldecode(args.id1) .. '(' .. args.id2 .. ')', mrl = '#stream/q=zagonkaz&id=' .. urls .. '&id1=' .. ids .. '&id2=' .. args.id2})

--end


elseif args.q == 'zagonkaz' then

  local url1 = 'http://abc.zagonkop.gb.net/embed/' .. args.id1


--http://abc.zagonkop.gb.net/embed/kp-5499518


local headersz = {
    ["accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
    ["accept-encoding"] = "gzip, deflate",
    ["accept-language"] = "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    ["connection"] = "keep-alive",
    ["cookie"] = "dle_lang=ru; PHPSESSID=8dcb5970b7d99293033c0445abe3631c",
    ["host"] = "abc.zagonkop.gb.net",
    ["referer"] = 'http://abc.zagonkop.gb.net' .. args.id,
    ["user-agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 Edg/147.0.0.0"
}



  local x = http.getz(url1, headersz)


--local id = string.match(x, 'data%-id="(.-)"')

--table.insert(t, {title = id, mrl = id})


x = string.gsub(x, 'ZYzNM', '')
        x = string.gsub(x, 'ZUzls', '')
x = string.gsub(x, 'ZUzVw', '')

x = string.gsub(x, 'ZUTB5', '')

x = string.gsub(x, 'ZaTdV', '')


local x = string.match(x, 'Playerjs%(\'#2(.-)\'%)+') 
   
  if x then      
    
    
    x = base64_decode(x)
     
 x = string.gsub(x, '{v1}', '.mp4')   

 
 
 for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<.-class=\'mfs\'>(.-)<div class=\'fllq\'.-file.-(//.-mp4)') do
 
 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(1080p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/720.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(720p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(480p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end

for title, total, url3 in string.gmatch(x, '"title\\":.-<div id=\'tr_.-HD(.-)<(.-)class=\'fllq\'.-file.-(//.-mp4)') do
 
 total = string.gsub(total, 'div', '') 
 
 total = string.gsub(total, 'class=\'mfs\'>', '')
 
 total = string.gsub(total, '<', '') 
 total = string.gsub(total, '+ SUB', '')
 
total = string.gsub(total, '/>', '')

 url3 = string.gsub(url3, '/240.mp4', '/360.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

  table.insert(t, {title = '(360p)' .. tolazy(title) .. tolazy(total), mrl = url3})
  
  end
 
 
-- url = url_for(x)
--url = urldecode(url)
  
  
 -- table.insert(t, {title = url, mrl = url})
 
 
 x = string.gsub(x, '_tr_2469_', '_tr_Syncmer_') 

x = string.gsub(x, '_tr_30_', '_tr_Coldfilm_') 





x = string.gsub(x, '_tr_233_', '_tr_Coldfilm_') 

x = string.gsub(x, '_tr_3025_', '_tr_Ultradox_')

x = string.gsub(x, '_tr_768_', '_tr_Ultradox_')

x = string.gsub(x, '_tr_1432_', '_tr_Rudub_')

x = string.gsub(x, '_tr_2388_', '_tr_Rudub_')

x = string.gsub(x, '_tr_286_', '_tr_Rezka_')

x = string.gsub(x, '_tr_281_', '_tr_Rg.paravozik_')

x = string.gsub(x, '_tr_10_', '_tr_Lostfilm_')

x = string.gsub(x, '_tr_380_', '_tr_Tvshows_')

x = string.gsub(x, '_tr_397_', '_tr_Пифагор_')

x = string.gsub(x, '_tr_17_', '_tr_Jaskier_')

x = string.gsub(x, '_tr_16_', '_tr_Gears Media_')

x = string.gsub(x, '_tr_6_', '_tr_Профессиональный_')

x = string.gsub(x, '_tr_7_', '_tr_Дубляж_')

x = string.gsub(x, '_tr_998_', '_tr_LE-Production_')

x = string.gsub(x, '_tr_14_', '_tr_Alexfilm_')

x = string.gsub(x, '_tr_1538_', '_tr_RED Head Sound_')

x = string.gsub(x, '_tr_1410_', '_tr_RED Head Sound_')

x = string.gsub(x, '_tr_2648_', '_tr_1Win Studio_')

x = string.gsub(x, '_tr_554_', '_tr_Newcomers_')

x = string.gsub(x, '_tr_210_', '_tr_Goldteam_')


x = string.gsub(x, '_tr_1285_', '_tr_Goldteam_')

x = string.gsub(x, '_tr_3014_', '_tr_Nonamestudio_')

x = string.gsub(x, '_tr_180_', '_tr_Viruseproject_')

x = string.gsub(x, '_tr_2836_', '_tr_Hate Studio_')

x = string.gsub(x, '_tr_2981_', '_tr_Capybara_')

x = string.gsub(x, '_tr_381_', '_tr_Оригинал_')

x = string.gsub(x, '_tr_1308_', '_tr_Оригинал_')

x = string.gsub(x, '_tr_24_', '_tr_Ideafilm_')

x = string.gsub(x, '_tr_521_', '_tr_Westfilm_')

x = string.gsub(x, '_tr_12_', '_tr_Baibako_')

x = string.gsub(x, '_tr_436_', '_tr_Kerobtv_')

x = string.gsub(x, '_tr_432_', '_tr_Kerobtv_')

x = string.gsub(x, '_tr_359_', '_tr_Lakefilms_')

x = string.gsub(x, '_tr_2963_', '_tr_Dragon Money Studio_')

x = string.gsub(x, '_tr_22_', '_tr_Кубик в Кубе_')

x = string.gsub(x, '_tr_2828_', '_tr_Закадры_')

x = string.gsub(x, '_tr_13_', '_tr_Newstudio_')

x = string.gsub(x, '_tr_2732_', '_tr_Whiskey Sound_')

x = string.gsub(x, '_tr_996_', '_tr_Flarrow Films_')

x = string.gsub(x, '_tr_563_', '_tr_Кравец_')

x = string.gsub(x, '_tr_19_', '_tr_Omskbird Records_')

x = string.gsub(x, '_tr_331_', '_tr_AMS_')


  


for season, tr, episode, url3 in string.gmatch(x, '<div.-class.-in_e.-class=\'mfs\'.-"s_(.-)_tr_(.-)_e_(.-)_.-file.-(//.-mp4)') do


 url3 = string.gsub(url3, '/240.mp4', '/1080.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

 table.insert(t, {title = '(1080p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
  end


for season, tr, episode, url3 in string.gmatch(x, '<div.-class.-in_e.-class=\'mfs\'.-"s_(.-)_tr_(.-)_e_(.-)_.-file.-(//.-mp4)') do

 url3 = string.gsub(url3, '/240.mp4', '/480.mp4:hls:manifest.m3u8') 
 
 url3 = string.gsub(url3, '^(.-)', 'http:') 
 
t['view'] = 'simple'

table.insert(t, {title = '(480p) ' .. season .. ' Сезон ' .. episode .. ' серия ' .. tr, mrl = url3})
  
 end
 
 end

  
  
  
  
		elseif args.q == 'video' then
		return {{title = args.t, mrl = args.url}}
		
	elseif args.q == 'play' then
		return video(args.url, args)
	end
	return t
end
