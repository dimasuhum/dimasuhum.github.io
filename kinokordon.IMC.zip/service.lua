-- kinokordon plugin

require('support')
require('video')
require('parser')


HOME = 'https://ru.kinokordon.net'




HOME_SLASH = HOME .. '/'

function onLoad()
	print('Hello from kinokordon plugin')
	return 1
end

function onUnLoad()
	print('Bye from kinokordon plugin')
end

function onCreate(args)
	local t = {view = 'grid_poster', type = 'folder'}
	t['menu'] = {}
	if args.q ~= 'genres' then
		table.insert(t['menu'], {title = '@string/genres', mrl = '#folder/q=genres', image = '#self/list.png'})
	end
	  --  table.insert(t['menu'], {title = '@string/search', mrl = '#folder/q=search', image = '#self/search.png'})

	-- #stream/page=2
	-- #stream/gente=/muzykalnye_kanaly
	-- #stream/gente=/novostnye_kanaly
	-- #stream/genre=/razvlekatelnyye_kanaly
	-- #stream/genre=/sputnikovye_kanaly
	-- #stream/genre=/pornokino/classikxxx/

	if not args.q then
		local page = tonumber(args.page or 1)

         local genre = args.genre or '/porn-news/'
     	local url = HOME .. genre
		if page > 1 then
        
			url = url .. 'page/' .. tostring(page) .. '/'
		end

		
			
		local x = http.getz(url)

        for url, title, image in string.gmatch(x, '<a class="thumb d%-flex fd%-column grid%-item thumb%-%-model".-href="(.-)".-class="thumb__title line%-clamp">(.-)<.-data%-src="(.-)"') do
        


		  table.insert(t, {title = title, mrl =  '#stream/q=content&id=' .. url, image = image})
		end
    

		
		
		
		local url = '#stream/page=' .. tostring(page + 1) .. '&genre=' .. genre
		table.insert(t,{title = L'page' .. ' ' .. tostring(page + 1), mrl = url, image = '#self/next.png'})
		
	-- #folder/q=genres
	elseif args.q == 'genres' then
		t['message'] = '@string/genre'
		t['view'] = 'simple'


        table.insert(t, {title = 'ТОП-100', mrl = '#stream/genre=' .. '/top100.html'})
        local x = http.getz(HOME)

      local x = string.match(x, '<ul class="menu js%-this%-in%-mobile%-menu">(.-)</ul>')
        for genre, title in string.gmatch(x, '<a href=".-//.-(/.-)".->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end
		local x = http.getz(HOME .. '/tags/')

        for genre, title in string.gmatch(x, '<a href="http.-(/tags/.-)" title=.->(.-)</a>') do
			table.insert(t, {title = tolazy(title), mrl = '#stream/genre=' .. genre})
		end

	-- #stream/q=content&id=http://tv.tivix.co/24-cartoon-network.html
	elseif args.q == 'content' then
		t['view'] = 'annotation'
		local x = http.getz(args.id)
       -- x = iconv(http.get(args.id), 'WINDOWS-1251', 'UTF-8')		
          t['ref'] = args.id
	
          --x = string.gsub(x, 'Смотреть онлайн', '')
		t['name'] = parse_match(x,'<h1>(.-)<span itemprop="name">(.-)</span></h1>')
		t['description'] = parse_match(x, '</h2>.-<p>(.-)</p>')
			t['poster'] = args.p
--	   t['poster'] = parse_match(x,'<img class="logo%-mobile scale%-with%-grid" src="(.-)"')
	--	if t['poster'] then
			--t['poster'] = string.gsub(t['poster'], '^/', HOME_SLASH)
	--	end
	    	t['annotation'] = parse_array(x, {
			'(Оригинальное название</strong>:.-)',
			'(В ролях:</strong>.-)',
			'(Выпущено</strong>:.-)',
			'(Жанр</strong>:.-)<br>',
			'(Режиссер</strong>:.-)<br>'})
			
        
        for title, url in string.gmatch(x, '"title".-"(.-)".-"file".-(https.-mp4)') do

          -- print(url)

			table.insert(t, {title = title, mrl = url})
		end
		
        for title, url in string.gmatch(x, 'title: "(.-)".-hls: "(https://.-m3u8)"') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
        t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        end

     	for url, title in string.gmatch(x, '"hls":"(https.-m3u8)".-"title":"(.-)"') do

			print(url)
        t['view'] = 'grid'
        t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        end	
    for title, url, total in string.gmatch(x, '"episode".-"hlsList".-"(.-)".-(https.-)".-"title".-"(.-)"') do

			print(url)
        t['view'] = 'grid'
        t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        end
		
		for title, url, total in string.gmatch(x, '"episode".-"hlsList".-,"(.-)".-(https.-)".-"title".-"(.-)"') do
			print(url)
         t['view'] = 'grid'
        t['viewtype'] = 'playlist'
        table.insert(t, {title = title .. ' ' .. total, mrl = url})
        end

        
         
			
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
        t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        end
        
        for title, url in string.gmatch(x, 'source.-cc.-hlsList.-,"(.-)".-(https.-m3u8)') do
		--	print(url)
       
      -- url = string.gsub(url, '\\', '')
        t['view'] = 'grid'
        t['viewtype'] = 'playlist'
        table.insert(t, {title = title, mrl = url})
        end
	elseif args.q == 'play' then
        
      -- return {view = 'playback', label = args.t, mrl = url, seekable = 'true', direct = 'true'}
	    return video(args.url, args)

	end
	return t
end